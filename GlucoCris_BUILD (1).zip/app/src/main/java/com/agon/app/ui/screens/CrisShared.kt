package com.agon.app.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.agon.app.Routes
import com.agon.app.data.AppData
import com.agon.app.data.CrisCloud
import com.agon.app.data.CrisGemini
import com.agon.app.data.CrisMemory
import com.agon.app.data.CrisPrefs
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Reminder
import com.agon.app.data.formatClock
import com.agon.app.data.formatDateTime
import com.agon.app.data.toMgDl
import com.agon.app.data.uid
import com.agon.app.localai.CrisConnectivityManager
import com.agon.app.localai.CrisLocalAi
import com.agon.app.localai.CrisSafetyGuard
import com.agon.app.localai.CrisSearchPolicy
import com.agon.app.localai.CrisMath
import com.agon.app.localai.CrisToolRegistry
import com.agon.app.localai.CrisWebSearch
import com.agon.app.localai.SearchIntent
import com.agon.app.localai.WebPrep
import com.agon.app.localai.LocalAiSettings
import com.agon.app.localai.LocalMemoryManager
import com.agon.app.localai.LocalSpeech
import kotlin.math.roundToInt

internal data class CrisTurnResult(
    val reply: String,
    val pending: PendingAction?,
    val memory: CrisMemory,
    val navigateTo: String? = null,
    /** Origem da resposta (ver CrisLocalAi.SRC_*), usada para rotular a conversa. */
    val source: String = "",
    /** Foto e fontes da resposta (ver CrisWebSearch.mediaOf). */
    val media: String = "",
)

/** Remove marcações técnicas para a conversa ficar natural. */
internal fun cleanCrisText(t: String): String = t
    .replace("\\n", "\n")
    .replace(Regex("```[\\s\\S]*?```"), "")
    .replace(Regex("\\*\\*?([^*]+)\\*\\*?"), "$1")
    .replace(Regex("(?m)^\\s*#+\\s*"), "")
    .replace(Regex("\n{3,}"), "\n\n")
    .trim()

/** Resumo curto dos registros, enviado para a IA entender o contexto. */
internal fun buildCrisContext(data: AppData): String {
    val s = data.settings
    val g = data.glucose.sortedByDescending { it.at }
    val i = data.insulin.sortedByDescending { it.at }
    return buildString {
        append("Meta de glicose no app: ${s.targetLow}-${s.targetHigh} mg/dL.\n")
        if (g.isEmpty()) append("Sem glicemias registradas.\n") else {
            append("Últimas glicemias: ")
            append(g.take(6).joinToString("; ") {
                "${toMgDl(it.value, it.unit).roundToInt()} mg/dL (${GLUCOSE_CONTEXT_LABEL[it.context] ?: it.context}, ${formatDateTime(it.at)})"
            })
            append(".\n")
            val week = g.filter { it.at >= System.currentTimeMillis() - 7L * 86_400_000 }
            if (week.isNotEmpty()) {
                val avg = week.map { toMgDl(it.value, it.unit) }.average().roundToInt()
                append("Média dos últimos 7 dias: $avg mg/dL em ${week.size} medições.\n")
            }
        }
        if (i.isNotEmpty()) {
            append("Últimas insulinas: ")
            append(i.take(4).joinToString("; ") { "${it.name} ${it.dose} ${it.unit} (${formatDateTime(it.at)})" })
            append(".\n")
        }
        val r = data.reminders.filter { it.enabled }
        if (r.isNotEmpty()) append("Lembretes ativos: " + r.joinToString("; ") { "${it.title} ${formatClock(it.hour, it.minute)}" } + ".\n")
        if (data.medications.isNotEmpty()) append("Medicamentos cadastrados: " + data.medications.filter { it.active }.joinToString(", ") { it.name } + ".\n")
        
        val ps = data.settings
        if (ps.diabetesType.isNotBlank()) append("Tipo de diabetes (perfil): ${ps.diabetesType}.\n")
        if (ps.insulinBasalName.isNotBlank() || ps.insulinMealName.isNotBlank() || ps.insulinKind.isNotBlank()) {
            append("Insulinas no perfil: ")
            append(listOfNotNull(
                ps.insulinKind.takeIf { it.isNotBlank() },
                ps.insulinBasalName.takeIf { it.isNotBlank() }?.let { "basal=$it" },
                ps.insulinMealName.takeIf { it.isNotBlank() }?.let { "refeição=$it" },
            ).joinToString("; "))
            append(".\n")
        }
        if (ps.allergies.isNotBlank()) append("Alergias do perfil (informadas pelo usuário): ${ps.allergies}.\n")
        if (ps.foodRestrictions.isNotBlank()) append("Restrições alimentares do perfil: ${ps.foodRestrictions}.\n")
        if (ps.profileMedications.isNotEmpty()) {
            append("Medicamentos de uso contínuo (perfil): " + ps.profileMedications.joinToString(", ") { it.name } + ".\n")
        }
        if (ps.heightCm.isNotBlank() || ps.weightKg.isNotBlank()) {
            append("Altura/peso (perfil): ${ps.heightCm.ifBlank { "?" }} cm / ${ps.weightKg.ifBlank { "?" }} kg.\n")
        }

        val meals = data.meals.sortedByDescending { it.at }
        if (meals.isNotEmpty()) {
            val todayStart = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
                set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
            }.timeInMillis
            val todayMeals = meals.filter { it.at >= todayStart }
            val carbToday = todayMeals.mapNotNull { it.carbs }.sum()
            append("Diário alimentar hoje: ${todayMeals.size} refeição(ões), ~${"%.0f".format(carbToday)} g de carboidrato.\n")
            val lastM = meals.first()
            append("Última refeição: ${lastM.description}" + (lastM.carbs?.let { " (~${it} g carb)" } ?: "") + " (${formatDateTime(lastM.at)}).\n")
        } else append("Sem refeições no diário alimentar.\n")
        val lastGlu = g.firstOrNull()?.let { toMgDl(it.value, it.unit) }
        if (lastGlu != null && lastGlu < 70) {
            append("ATENÇÃO: última glicemia baixa (${lastGlu.roundToInt()} mg/dL). Priorize segurança; não sugira exercício nem redução de alimentação sem cuidado.\n")
        }
    }
}

/**
 * Processa uma fala/mensagem: ações do app são locais e seguras (com confirmação);
 * conversa vai para a IA natural; sem internet, cai na Cris local.
 */
internal suspend fun crisRespond(
    context: Context,
    vm: GlucoViewModel,
    text: String,
    memory: CrisMemory,
    pending: PendingAction?,
    history: List<CrisMsg>,
    voice: Boolean,
    summary: String = "",
    onPartial: ((String) -> Unit)? = null,
): CrisTurnResult {
    val data = vm.data.value
    val low = text.lowercase()
    // Segurança: emergências e autoagressão não passam pela IA generativa
    CrisSafetyGuard.precheck(text)?.let { return CrisTurnResult(it, null, memory, source = CrisLocalAi.SRC_SAFETY) }
    // Atalhos locais rápidos (não passam pela nuvem)
    when {
        listOf("localizador", "achar insulina", "onde achar insulina", "farmácia perto", "farmacia perto").any { it in low } ->
            return CrisTurnResult("Abrindo o localizador de insulina.", null, memory, Routes.LOCATOR)
        listOf("calculadora de bolus", "calcular bolus", "bolus").any { it in low } && "não" !in low ->
            return CrisTurnResult("Abrindo a calculadora de bolus (só com os seus fatores).", null, memory, Routes.FOOD_BOLUS)
        listOf("abrir alimentos", "diário alimentar", "contar carb", "contagem de carb").any { it in low } ->
            return CrisTurnResult("Abrindo a alimentação.", null, memory, Routes.FOOD)
        listOf("registrar glicemia", "abrir glicose", "lançar glicemia").any { it in low } ->
            return CrisTurnResult("Abrindo a glicose pra você registrar.", null, memory, Routes.GLUCOSE)
        listOf("resumo da semana", "como está minha glicose").any { it in low } -> {
            val week = data.glucose.filter { it.at >= System.currentTimeMillis() - 7L * 86_400_000 }
            val msg = if (week.isEmpty()) "Ainda não há glicemias nesta semana no app."
            else {
                val avg = week.map { toMgDl(it.value, it.unit) }.average().roundToInt()
                "Nesta semana: ${week.size} medições, média cerca de $avg mg/dL. Quer que eu abra o relatório?"
            }
            return CrisTurnResult(msg, null, memory)
        }
    }
    // Memória de longo prazo (só por pedido explícito) e ferramentas internas (dados reais do app)
    if (pending == null) {
        LocalMemoryManager.handleCommand(context, text)?.let { return CrisTurnResult(it, null, memory, source = CrisLocalAi.SRC_APP) }
        CrisToolRegistry.tryAnswer(text, data)?.let { return CrisTurnResult(it.text, null, memory, source = CrisLocalAi.SRC_APP) }
        // Contas simples ("quanto é 25 vezes 48?") saem exatas, mesmo sem modelo e sem internet
        CrisMath.tryAnswer(text)?.let { return CrisTurnResult(it, null, memory, source = CrisLocalAi.SRC_CALC) }
    }
    // Autorização de pesquisa pedida na mensagem anterior (consulta com dados pessoais)
    if (pending == null) {
        CrisWebSearch.consumeConsent(text)?.let { original ->
            val un = com.agon.app.data.firstName(data.settings.displayName)
            val web = CrisWebSearch.prepare(context, original, un, consented = true, modelReady = CrisLocalAi.isReady(context))
            val ctxConsent = if (LocalAiSettings.onlineHealthContextAllowed(context)) {
                buildCrisContext(data)
            } else "Dados de saúde do app não foram compartilhados (privacidade).\n"
            val geminiConsent = try {
                if (CrisGemini.isConfigured() && com.agon.app.localai.CrisConnectivityManager.isOnline(context)) {
                    CrisGemini.chatAsCris(
                        context, original,
                        history.takeLast(16).map { it.fromUser to it.text },
                        ctxConsent, un, webContext = web.promptBlock,
                    )
                } else null
            } catch (_: Exception) { null }
            if (!geminiConsent.isNullOrBlank()) {
                val body = CrisSafetyGuard.postcheck(cleanCrisText(geminiConsent))
                val refused = body == CrisSafetyGuard.DOSE_REFUSAL
                val foot = if (refused || web.hits.isEmpty()) "" else CrisWebSearch.footer(web, voice, CrisWebSearch.userAskedSources(original))
                return CrisTurnResult(body + foot, null, memory, source = CrisLocalAi.SRC_ONLINE, media = if (refused) "" else CrisWebSearch.mediaOf(web))
            }
            crisLocalWithWeb(context, original, history, data, memory, un, voice, web, summary, onPartial)?.let { return it }
        }
    }
    val (answer, newPending) = CrisBrain.reply(text, data, memory, pending, localOnly = true)
    return when {
        answer == "CONFIRM_CREATE_REMINDER" && pending is PendingAction.CreateReminder -> {
            vm.saveReminder(
                Reminder(
                    id = uid(), kind = pending.kind, title = pending.title, hour = pending.hour, minute = pending.minute,
                    days = pending.days, enabled = true, soundId = "suave", notes = "Criado com a Cris IA",
                ),
            )
            CrisTurnResult("Prontinho! Salvei o lembrete ${pending.title.lowercase()} às ${formatClock(pending.hour, pending.minute)}. Se quiser mudar, é só ir na aba Lembretes.", null, memory)
        }
        answer == "PAUSE_REMINDER" -> {
            val active = data.reminders.filter { it.enabled }
            active.forEach { vm.toggleReminder(it.id) }
            CrisTurnResult(if (active.isEmpty()) "Você não tem nenhum lembrete ativo agora." else "Pausei ${active.size} lembrete(s). Quando quiser, é só me pedir pra ativar de novo.", null, memory)
        }
        answer == "ENABLE_REMINDER" -> {
            val paused = data.reminders.filter { !it.enabled }
            paused.forEach { vm.toggleReminder(it.id) }
            CrisTurnResult(if (paused.isEmpty()) "Todos os seus lembretes já estão ligados." else "Reativei ${paused.size} lembrete(s) pra você.", null, memory)
        }
        answer == "NAV_GLUCOSE" -> CrisTurnResult("Abrindo a glicose pra você.", null, memory, Routes.GLUCOSE)
        answer == "NAV_INSULIN" -> CrisTurnResult("Abrindo a insulina.", null, memory, Routes.INSULIN)
        answer == "NAV_REMINDERS" -> CrisTurnResult("Abrindo seus lembretes.", null, memory, Routes.REMINDERS)
        answer == "NAV_LOCATOR" -> CrisTurnResult("Claro! Abrindo o localizador pra achar insulina perto de você.", null, memory, Routes.LOCATOR)
        answer == "NAV_FOOD" -> CrisTurnResult("Abrindo a alimentação.", null, memory, Routes.FOOD)
        answer == "NAV_BOLUS" -> CrisTurnResult("Abrindo a calculadora de bolus.", null, memory, Routes.FOOD_BOLUS)
        answer == "NAV_REPORT" -> CrisTurnResult("Abrindo o relatório.", null, memory, Routes.REPORT)
        answer == "PREF_SHORT_ON" -> {
            val m = memory.copy(shortAnswers = true); CrisPrefs.saveMemory(context, m)
            CrisTurnResult("Combinado, vou ser mais direta.", null, m)
        }
        answer == "PREF_SHORT_OFF" -> {
            val m = memory.copy(shortAnswers = false); CrisPrefs.saveMemory(context, m)
            CrisTurnResult("Tá bom, explico com mais calma quando precisar.", null, m)
        }
        answer == "PREF_CLEAR" -> {
            val m = CrisMemory(speakReplies = memory.speakReplies); CrisPrefs.saveMemory(context, m)
            CrisTurnResult("Pronto, apaguei suas preferências deste aparelho.", null, m)
        }
        answer.startsWith("PREF_NOTE:") -> {
            val note = answer.removePrefix("PREF_NOTE:")
            val m = memory.copy(noteToSelf = note, memoryEnabled = true); CrisPrefs.saveMemory(context, m)
            CrisTurnResult("Anotado! Vou lembrar que $note.", null, m)
        }
        answer == CrisBrain.CLOUD -> {
            val userName = com.agon.app.data.firstName(data.settings.displayName)
            // Serviços online só recebem o resumo de saúde se a usuária autorizou nas configurações da IA
            val ctx = if (LocalAiSettings.onlineHealthContextAllowed(context)) {
                buildCrisContext(data) + if (memory.noteToSelf.isNotBlank()) "Preferência da pessoa: ${memory.noteToSelf}\n" else ""
            } else "Dados de saúde do app não foram compartilhados (privacidade). Responda de forma geral e não invente registros.\n"
            val online = com.agon.app.localai.CrisConnectivityManager.isOnline(context)
            // 1) GEMINI É O CÉREBRO: responde sozinha e, quando o assunto é atual, PESQUISA NO GOOGLE por conta própria.
            //    Pergunta com dado pessoal (glicemia, dose, nome...) vai sem a ferramenta de pesquisa, para nada disso virar busca.
            val canSearch = LocalAiSettings.webSearchEnabled(context) && !CrisSearchPolicy.hasPersonalData(text, userName)
            val gem = try {
                if (CrisGemini.isConfigured() && online) {
                    CrisGemini.chatAsCrisFull(
                        context, text,
                        history.takeLast(16).map { it.fromUser to it.text },
                        ctx, userName, allowSearch = canSearch,
                    )
                } else null
            } catch (_: Exception) { null }
            if (gem != null && gem.text.isNotBlank()) {
                val body = CrisSafetyGuard.postcheck(cleanCrisText(gem.text))
                val refused = body == CrisSafetyGuard.DOSE_REFUSAL
                // Fontes só quando a pessoa pede
                val wantSources = !refused && gem.sources.isNotEmpty() && CrisWebSearch.userAskedSources(text)
                val foot = if (wantSources) "\n\n🌐 Fonte: " + gem.sources.take(2).joinToString(" · ") { it.first } else ""
                val media = if (wantSources) gem.sources.take(3).joinToString("\n") { "SRC\t" + it.first.replace('\t', ' ').replace('\n', ' ').take(30) + "\t" + it.second } else ""
                return CrisTurnResult(body + foot, null, memory, source = CrisLocalAi.SRC_ONLINE, media = media)
            }
            // 2) Reserva (Gemini indisponível): pesquisa aberta + IA local. Avisa o motivo para a falha não ficar escondida.
            val geminiNote = if (CrisGemini.isConfigured() && online)
                "\n\n⚠️ A IA online (Gemini) não respondeu: ${CrisGemini.lastError.ifBlank { "sem detalhe" }}. Respondi pelo modo alternativo."
            else ""
            // Ordem de reserva: todos os modelos Gemini -> Tavily/pesquisa -> IA local (por último).
            // Com o Gemini fora do ar, qualquer pergunta geral passa pela pesquisa ANTES da IA local
            // (prepare() trata "sem modelo" como "pesquise as perguntas gerais").
            val web = CrisWebSearch.prepare(context, text, userName, modelReady = CrisLocalAi.isReady(context) && geminiNote.isEmpty())
            web.askConsent?.let { return CrisTurnResult(it, null, memory, source = CrisLocalAi.SRC_APP) }
            crisLocalWithWeb(context, text, history, data, memory, userName, voice, web, summary, onPartial)?.let {
                return if (geminiNote.isNotEmpty()) it.copy(reply = it.reply + geminiNote) else it
            }
            // 2) Servidor Cris já existente
            val cloud = CrisCloud.chat(
                text,
                history.takeLast(16).map { CrisCloud.Turn(it.fromUser, it.text) },
                ctx,
                voice,
                userName,
            )
            if (cloud != null) {
                CrisTurnResult(CrisSafetyGuard.postcheck(cleanCrisText(cloud)), null, memory, source = CrisLocalAi.SRC_ONLINE)
            } else {
                // 3) Cris local básica (CrisBrain)
                val (fb, p2) = CrisBrain.reply(text, data, memory, pending, localOnly = false)
                // A mensagem genérica antiga prometia "conversar sobre qualquer assunto" depois; aqui dizemos a verdade sobre o motivo
                val honest = if (fb.startsWith("Estou sem internet agora")) CrisLocalAi.limitationNotice(context) else fb
                CrisTurnResult(cleanCrisText(honest), p2, memory, source = CrisLocalAi.SRC_BASIC)
            }
        }
        else -> CrisTurnResult(cleanCrisText(answer), newPending, memory)
    }
}

/** IA local responde; se houve pesquisa, os fatos entram no prompt e as fontes reais são anexadas. */
private suspend fun crisLocalWithWeb(
    context: Context,
    text: String,
    history: List<CrisMsg>,
    data: AppData,
    memory: CrisMemory,
    userName: String,
    voice: Boolean,
    web: WebPrep,
    summary: String = "",
    onPartial: ((String) -> Unit)? = null,
): CrisTurnResult? {
    val showSources = CrisWebSearch.userAskedSources(text)
    // Fatos atuais: prioriza resposta direta das fontes (Wikidata/Wikipédia) — evita alucinação
    if (web.intent == SearchIntent.CURRENT && web.hits.isNotEmpty()) {
        val direct = CrisWebSearch.composeDirectFact(web, voice, showSources)
        if (direct != null) {
            return CrisTurnResult(direct, null, memory, source = CrisLocalAi.SRC_LOCAL_WEB, media = CrisWebSearch.mediaOf(web))
        }
    }
    // Também para GENERAL com fato de cargo bem pontuado (score alto = Wikidata)
    if (web.intent == SearchIntent.GENERAL && web.hits.any { it.score >= 100 }) {
        val direct = CrisWebSearch.composeDirectFact(web, voice, showSources)
        if (direct != null) {
            return CrisTurnResult(direct, null, memory, source = CrisLocalAi.SRC_LOCAL_WEB, media = CrisWebSearch.mediaOf(web))
        }
    }
    // ONLINE PRIMEIRO: com internet e pesquisa com resultado, a resposta sai das fontes consultadas e o modelo local nem é chamado
    // (evita espera e o aviso de falha do modelo). O modelo local fica para quando estiver sem internet ou sem resultado da pesquisa.
    if (web.hits.isNotEmpty() && com.agon.app.localai.CrisConnectivityManager.isOnline(context)) {
        val online = CrisSafetyGuard.postcheck(CrisWebSearch.composeWithoutModel(web, voice, CrisLocalAi.isReady(context), showSources, onlineFirst = true))
        val refused = online == CrisSafetyGuard.DOSE_REFUSAL
        return CrisTurnResult(online, null, memory, source = CrisLocalAi.SRC_ONLINE, media = if (refused) "" else CrisWebSearch.mediaOf(web))
    }
    val partialCb: (String) -> Unit = { p: String ->
        onPartial?.invoke(CrisSafetyGuard.postcheck(cleanCrisText(p)))
    }
    val local = CrisLocalAi.chat(
        context, text, history.takeLast(8).map { it.fromUser to it.text }, data, memory, userName,
        extraBlock = web.promptBlock, summary = summary, onPartial = partialCb,
    )
    if (!local.isNullOrBlank()) {
        val body = CrisSafetyGuard.postcheck(cleanCrisText(local))
        val refused = body == CrisSafetyGuard.DOSE_REFUSAL
        val foot = if (refused) "" else CrisWebSearch.footer(web, voice, showSources)
        val note = if (web.limitation.isNotBlank()) "\n\nℹ️ ${web.limitation}" else ""
        val src = if (web.hits.isNotEmpty() && !refused) CrisLocalAi.SRC_LOCAL_WEB else CrisLocalAi.SRC_LOCAL
        return CrisTurnResult(body + foot + note, null, memory, source = src, media = if (refused) "" else CrisWebSearch.mediaOf(web))
    }
    if (web.hits.isNotEmpty()) return CrisTurnResult(CrisWebSearch.composeWithoutModel(web, voice, CrisLocalAi.isReady(context), showSources), null, memory, source = CrisLocalAi.SRC_ONLINE, media = CrisWebSearch.mediaOf(web))
    return null
}

internal fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** Reconhecimento de voz em pt-BR com nível do microfone em tempo real. */
internal class CrisListener(
    private val context: Context,
    private val onLevel: (Float) -> Unit,
    private val onPartial: (String) -> Unit,
    private val onResult: (String) -> Unit,
    private val onFail: (String) -> Unit,
) {
    private var recognizer: SpeechRecognizer? = null

    /** Tenta primeiro o reconhecedor no aparelho (offline, Android 13+); se o pacote pt-BR faltar, cai no padrão. */
    fun start() = startInternal(preferOnDevice = true)

    private fun startInternal(preferOnDevice: Boolean) {
        stop()
        val onDevice = if (preferOnDevice) LocalSpeech.createOnDevice(context) else null
        if (onDevice == null && !SpeechRecognizer.isRecognitionAvailable(context)) {
            onFail("O reconhecimento de voz não está disponível neste aparelho.")
            return
        }
        val usingOnDevice = onDevice != null
        val r = onDevice ?: SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { onLevel(0f) }
            override fun onError(error: Int) {
                onLevel(0f)
                if (usingOnDevice && LocalSpeech.isLanguageError(error)) {
                    // Pacote de voz pt-BR offline não instalado: tenta o reconhecedor padrão do sistema
                    startInternal(preferOnDevice = false)
                    return
                }
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Não te ouvi. Toque na esfera e fale de novo."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Preciso da permissão do microfone."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        if (CrisConnectivityManager.isOnline(context)) "Não consegui entender a voz agora. Tente de novo."
                        else "Sem internet e sem pacote de voz offline em português. Instale o pacote de pt-BR em Configurações > Idioma > Voz do Android, ou digite."
                    else -> "Não consegui ouvir. Toque e tente de novo."
                }
                stop()
                onFail(msg)
            }
            override fun onResults(results: Bundle?) {
                val said = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                stop()
                if (said.isNotBlank()) onResult(said) else onFail("Não te ouvi. Toque e fale de novo.")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (p.isNotBlank()) onPartial(p)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }
        r.startListening(intent)
    }

    fun stop() {
        val r = recognizer ?: return
        recognizer = null
        try { r.cancel() } catch (_: Exception) {}
        try { r.destroy() } catch (_: Exception) {}
    }
}
