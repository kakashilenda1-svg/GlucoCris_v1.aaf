package com.agon.app.insights

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.agon.app.data.AppData
import com.agon.app.data.formatDate
import com.agon.app.data.formatDateTime
import com.agon.app.data.formatTime
import java.io.File
import kotlin.math.roundToInt

/** Relatório médico em PDF (A4, várias páginas), feito só com os dados que a pessoa registrou. */
object MedicalPdf {
    private const val W = 595
    private const val H = 842
    private const val M = 40f

    private class Writer(val doc: PdfDocument, val footer: String) {
        var pageNo = 0
        lateinit var page: PdfDocument.Page
        lateinit var c: Canvas
        var y = 0f
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10.5f; color = 0xFF1F2937.toInt() }
        val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 8.5f; color = 0xFF6B7280.toInt() }
        val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10.5f; color = 0xFF111827.toInt(); typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val h1 = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 20f; color = 0xFF5B21B6.toInt(); typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val h2 = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 13f; color = 0xFF5B21B6.toInt(); typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val line = Paint().apply { color = 0xFFE5E7EB.toInt(); strokeWidth = 1f }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)

        init { newPage() }

        fun newPage() {
            if (pageNo > 0) finishPage()
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            c = page.canvas
            y = M + 8f
        }

        private fun finishPage() {
            c.drawLine(M, H - 34f, W - M, H - 34f, line)
            c.drawText(footer, M, H - 20f, small)
            val t = "Página $pageNo"
            c.drawText(t, W - M - small.measureText(t), H - 20f, small)
            doc.finishPage(page)
        }

        fun finish() = finishPage()

        fun ensure(h: Float) { if (y + h > H - 46f) newPage() }
        fun gap(h: Float = 8f) { y += h }

        fun title(t: String) { ensure(30f); c.drawText(t, M, y + 16f, h1); y += 28f }
        fun section(t: String) { ensure(40f); y += 8f; c.drawText(t, M, y + 12f, h2); y += 17f; c.drawLine(M, y, W - M, y, line); y += 8f }

        fun wrap(text: String, p: Paint, maxW: Float): List<String> {
            val out = mutableListOf<String>()
            for (raw in text.split("\n")) {
                var cur = ""
                for (word in raw.split(" ")) {
                    val test = if (cur.isEmpty()) word else "$cur $word"
                    if (p.measureText(test) <= maxW) cur = test
                    else { if (cur.isNotEmpty()) out.add(cur); cur = word }
                }
                out.add(cur)
            }
            return out
        }

        fun para(text: String, p: Paint = body, indent: Float = 0f) {
            val lh = p.textSize + 4f
            for (l in wrap(text, p, W - 2 * M - indent)) {
                ensure(lh); c.drawText(l, M + indent, y + p.textSize, p); y += lh
            }
        }

        /** Linha de tabela com colunas de larguras fixas. */
        fun row(cols: List<String>, widths: List<Float>, p: Paint = body, shade: Boolean = false) {
            ensure(16f)
            if (shade) { fill.color = 0xFFF5F3FF.toInt(); c.drawRect(M, y - 1f, W - M, y + 14f, fill) }
            var x = M + 4f
            cols.forEachIndexed { i, t ->
                var s = t
                while (s.length > 1 && p.measureText(s) > widths[i] - 6f) s = s.dropLast(1)
                c.drawText(s, x, y + 10f, p)
                x += widths[i]
            }
            y += 15f
        }
    }

    fun build(ctx: Context, data: AppData, days: Int, now: Long = System.currentTimeMillis()): File {
        val s = data.settings
        val from = now - days * Insights.DAY_MS
        val reads = Insights.readingsBetween(data, from, now)
        val st = Insights.stats(reads, s.targetLow, s.targetHigh)
        val buckets = Insights.byHour(reads, s.targetLow, s.targetHigh)

        val doc = PdfDocument()
        val w = Writer(doc, "Gluco Cris · relatório gerado em ${formatDateTime(now)} · não substitui avaliação médica")

        w.title("Relatório de glicemia")
        w.para("Paciente: ${s.displayName}", w.bold)
        val info = listOfNotNull(
            s.birthDate.takeIf { it.isNotBlank() }?.let { "Nascimento: $it" },
            s.diabetesType.takeIf { it.isNotBlank() }?.let { "Tipo de diabetes: $it" },
            s.insulinKind.takeIf { it.isNotBlank() }?.let { "Insulina: $it" },
            s.weightKg.takeIf { it.isNotBlank() }?.let { "Peso: $it kg" },
        )
        if (info.isNotEmpty()) w.para(info.joinToString("  ·  "))
        w.para("Período: ${formatDate(from)} a ${formatDate(now)} ($days dias)  ·  Meta: ${s.targetLow}–${s.targetHigh} mg/dL")

        w.section("Resumo do período")
        if (st == null) {
            w.para("Não há medições próprias registradas neste período.")
        } else {
            val cw = listOf(250f, 250f)
            w.row(listOf("Medições", "${st.count} (${"%.1f".format(st.count / days.toDouble())} por dia)"), cw, shade = true)
            w.row(listOf("Glicemia média", "${st.mean.roundToInt()} mg/dL"), cw)
            w.row(listOf("Desvio padrão", "${st.sd.roundToInt()} mg/dL"), cw, shade = true)
            w.row(listOf("Variabilidade (CV)", "${st.cv.roundToInt()}%  ${if (st.cv <= 36) "(estável, até 36%)" else "(alta, acima de 36%)"}"), cw)
            w.row(listOf("Mínima / máxima", "${st.min.roundToInt()} / ${st.max.roundToInt()} mg/dL"), cw, shade = true)
            w.row(listOf("A1c estimada (GMI)", "${"%.1f".format(java.util.Locale("pt", "BR"), st.gmi)}%"), cw)
            w.gap(2f)
            w.para(
                "A A1c estimada vem da fórmula GMI = 3,31 + 0,02392 × glicemia média, aplicada às medições registradas. " +
                    "É uma ESTIMATIVA e pode diferir do exame de hemoglobina glicada de laboratório" +
                    (if (st.count < 30) "; com poucas medições (${st.count}) ela é ainda menos confiável." else "."),
                w.small,
            )

            w.section("Tempo nas faixas")
            val parts = listOf(
                Triple("Muito baixa (< ${minOf(54, s.targetLow)})", st.veryLowPct, 0xFFC2410C.toInt()),
                Triple("Baixa (< ${s.targetLow})", st.lowPct, 0xFFF59E0B.toInt()),
                Triple("Na meta (${s.targetLow}–${s.targetHigh})", st.inRangePct, 0xFF16A34A.toInt()),
                Triple("Alta (> ${s.targetHigh})", st.highPct, 0xFFEF4444.toInt()),
                Triple("Muito alta (> ${maxOf(250, s.targetHigh)})", st.veryHighPct, 0xFF991B1B.toInt()),
            )
            w.ensure(30f)
            var x = M
            val total = W - 2 * M
            parts.forEach { (_, pct, col) ->
                val wd = (total * (pct / 100.0)).toFloat()
                if (wd > 0f) { w.fill.color = col; w.c.drawRect(x, w.y, x + wd, w.y + 16f, w.fill); x += wd }
            }
            w.y += 24f
            parts.forEach { (label, pct, col) ->
                w.ensure(14f)
                w.fill.color = col; w.c.drawRect(M, w.y + 1f, M + 9f, w.y + 10f, w.fill)
                w.c.drawText("$label: ${pct.roundToInt()}%", M + 15f, w.y + 9f, w.body)
                w.y += 14f
            }

            w.section("Padrões por horário do dia")
            Insights.dayParts(reads).forEach { dp ->
                w.para("• ${dp.label}: ${dp.mean?.let { "${it.roundToInt()} mg/dL em média (${dp.count} medições)" } ?: "sem medições"}")
            }
            // Gráfico de barras: média por hora
            w.gap(6f); w.ensure(110f)
            val chartTop = w.y; val chartH = 80f; val bw = (W - 2 * M) / 24f
            val maxV = maxOf(250.0, buckets.maxOf { it.mean })
            w.fill.color = 0xFFDCFCE7.toInt()
            val yHigh = chartTop + chartH * (1f - (s.targetHigh / maxV).toFloat())
            val yLow = chartTop + chartH * (1f - (s.targetLow / maxV).toFloat())
            w.c.drawRect(M, yHigh, W - M, yLow, w.fill)
            buckets.forEach { b ->
                if (b.count > 0) {
                    val hgt = chartH * (b.mean / maxV).toFloat()
                    w.fill.color = when { b.mean < s.targetLow -> 0xFFF59E0B.toInt(); b.mean > s.targetHigh -> 0xFFEF4444.toInt(); else -> 0xFF16A34A.toInt() }
                    w.c.drawRect(M + b.hour * bw + 1.5f, chartTop + chartH - hgt, M + (b.hour + 1) * bw - 1.5f, chartTop + chartH, w.fill)
                }
            }
            listOf(0, 6, 12, 18, 23).forEach { h -> w.c.drawText(Insights.hourLabel(h), M + h * bw, chartTop + chartH + 11f, w.small) }
            w.y = chartTop + chartH + 18f
            w.para("Faixa verde clara = meta. Barras = média das medições feitas em cada hora.", w.small)

            val lows = Insights.criticalLowHours(buckets)
            val highs = Insights.criticalHighHours(buckets)
            w.gap(2f)
            w.para("Horários críticos de hipoglicemia: " + (if (lows.isEmpty()) "nenhum padrão identificado." else lows.joinToString("; ") { "${Insights.hourLabel(it.hour)} (${it.lows} de ${it.count} medições baixas)" }))
            w.para("Horários críticos de hiperglicemia: " + (if (highs.isEmpty()) "nenhum padrão identificado." else highs.joinToString("; ") { "${Insights.hourLabel(it.hour)} (${it.highs} de ${it.count} medições altas)" }))
        }

        // Insulinas
        w.section("Insulinas aplicadas no período")
        val ins = data.insulin.filter { !it.id.startsWith("demo-") && it.kind == "aplicacao" && it.at in from..now }
        if (ins.isEmpty()) w.para("Nenhuma aplicação registrada.")
        else {
            val cw = listOf(230f, 80f, 90f, 100f)
            w.row(listOf("Insulina", "Aplicações", "Dose média", "Total"), cw, w.bold)
            ins.groupBy { it.name }.entries.sortedByDescending { it.value.size }.forEachIndexed { i, (name, list) ->
                w.row(listOf(name, "${list.size}", "${"%.1f".format(list.map { it.dose }.average())} UI", "${"%.1f".format(list.sumOf { it.dose })} UI"), cw, shade = i % 2 == 0)
            }
        }

        // Medicamentos
        w.section("Medicamentos em uso")
        val meds = data.medications.filter { it.active && !it.id.startsWith("demo-") }
        val profMeds = s.profileMedications.filter { it.name.isNotBlank() }
        if (meds.isEmpty() && profMeds.isEmpty()) w.para("Nenhum medicamento cadastrado.")
        meds.forEach { w.para("• ${it.name} — ${it.dose}${if (it.schedule.isNotBlank()) " — ${it.schedule}" else ""}") }
        profMeds.forEach { w.para("• ${it.name}${if (it.dose.isNotBlank()) " — ${it.dose}" else ""}${if (it.frequency.isNotBlank()) " — ${it.frequency}" else ""}") }

        // Refeições com mais carboidratos
        w.section("Refeições com mais carboidratos")
        val meals = data.meals.filter { !it.id.startsWith("demo-") && it.carbs != null && it.at in from..now }.sortedByDescending { it.carbs }.take(8)
        if (meals.isEmpty()) w.para("Nenhuma refeição com carboidratos registrada neste período.")
        meals.forEach { w.para("• ${formatDate(it.at)} ${formatTime(it.at)} · ${it.description.take(70)} · ${"%.0f".format(it.carbs)} g") }

        // Alimentos que mais elevam a glicose
        val resp = FoodResponse.compute(data, now).filter { ((it.rise2h ?: it.rise1h) ?: 0.0) > 0.0 }.take(5)
        if (resp.isNotEmpty()) {
            w.section("Alimentos com maior subida da glicose (pessoal)")
            resp.forEach { r ->
                w.para("• ${r.name}: +${(r.rise1h ?: 0.0).roundToInt()} mg/dL após 1 h, +${(r.rise2h ?: 0.0).roundToInt()} mg/dL após 2 h (${r.meals} refeição(ões))")
            }
            w.para("Resposta da refeição inteira; com poucas refeições o resultado é só um indício.", w.small)
        }

        // Resumo diário
        if (reads.isNotEmpty()) {
            w.section("Resumo por dia")
            val cw = listOf(90f, 70f, 80f, 80f, 80f, 100f)
            w.row(listOf("Dia", "Medições", "Média", "Mínima", "Máxima", "Na meta"), cw, w.bold)
            reads.groupBy { formatDate(it.at) }.entries.toList().takeLast(31).forEachIndexed { i, (day, list) ->
                val v = list.map { it.mg }
                val inR = v.count { it >= s.targetLow && it <= s.targetHigh } * 100 / v.size
                w.row(listOf(day, "${v.size}", "${v.average().roundToInt()}", "${v.min().roundToInt()}", "${v.max().roundToInt()}", "$inR%"), cw, shade = i % 2 == 0)
            }
        }

        w.gap(10f)
        w.para("Este relatório resume o que foi registrado no aplicativo e serve de apoio à consulta. Ele não faz diagnóstico nem indica doses de insulina; condutas devem ser definidas pela equipe de saúde.", w.small)
        w.finish()

        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val f = File(dir, "relatorio_medico_gluco_cris.pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        return f
    }
}
