package com.agon.app.ui.screens

import android.content.Context
import android.content.ContextWrapper
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/** Entrar com digital ou rosto. O PIN continua existindo como alternativa (e é pedido se a biometria falhar). */
object BiometricHelper {
    private const val AUTH = BiometricManager.Authenticators.BIOMETRIC_WEAK

    /** O aparelho tem sensor e pelo menos uma digital/rosto cadastrado? */
    fun available(ctx: Context): Boolean = try {
        BiometricManager.from(ctx).canAuthenticate(AUTH) == BiometricManager.BIOMETRIC_SUCCESS
    } catch (_: Exception) {
        false
    }

    fun activityOf(ctx: Context): FragmentActivity? {
        var c: Context? = ctx
        while (c is ContextWrapper) {
            if (c is FragmentActivity) return c
            c = c.baseContext
        }
        return null
    }

    /** Mostra o pedido do sistema. [onSuccess] só roda se a biometria foi reconhecida. */
    fun prompt(ctx: Context, title: String, subtitle: String, onSuccess: () -> Unit, onFail: (() -> Unit)? = null) {
        val activity = activityOf(ctx)
        if (activity == null || !available(ctx)) {
            onFail?.invoke()
            return
        }
        try {
            val executor = ContextCompat.getMainExecutor(activity)
            val bp = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    onFail?.invoke()
                }
            })
            val info = BiometricPrompt.PromptInfo.Builder()
                .setTitle(title)
                .setSubtitle(subtitle)
                .setAllowedAuthenticators(AUTH)
                .setNegativeButtonText("Usar PIN")
                .build()
            bp.authenticate(info)
        } catch (_: Exception) {
            onFail?.invoke()
        }
    }
}
