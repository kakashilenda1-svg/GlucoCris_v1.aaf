package com.agon.app.ui.screens

import android.content.Context

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import androidx.core.content.FileProvider
import java.io.File
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.INTENSITY_LABEL
import com.agon.app.data.MEAL_LABEL
import com.agon.app.data.Medication
import com.agon.app.data.formatDate
import com.agon.app.data.formatDateTime
import com.agon.app.data.fmtNum
import com.agon.app.data.ptNumber
import com.agon.app.data.rangeStatus
import com.agon.app.data.toMgDl
import com.agon.app.data.uid
import com.agon.app.reminders.GlucoseAlerts
import com.agon.app.reminders.GlucoseWidgetProvider
import com.agon.app.reminders.QuickGlucoseNotifier
import com.agon.app.reminders.SOUND_PRESETS
import com.agon.app.reminders.SoundPlayer
import com.agon.app.ui.components.BackTitle
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.ConfirmDialog
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GField
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.theme.glucoColors
import kotlin.math.roundToInt

@Composable
fun MedsScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    var editing by remember { mutableStateOf<Medication?>(null) }
    var creating by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var dose by remember { mutableStateOf("") }
    var schedule by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf<String?>(null) }

    fun load(m: Medication?) {
        name = m?.name ?: ""
        dose = m?.dose ?: ""
        schedule = m?.schedule ?: ""
        notes = m?.notes ?: ""
        error = null
    }

    ScrollScreen {
        BackTitle("Medicamentos", { nav.popBackStack() })
        Text("Lista pessoal de ${data.settings.displayName}. Serve para organização — não é uma prescrição.", color = g.muted, fontSize = 13.sp)
        if (!creating && editing == null) data.medications.forEach { m ->
            GCard(Modifier.padding(top = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                        Text(m.name, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Text("${m.dose} · ${m.schedule}", color = g.muted, fontSize = 13.sp)
                        if (m.notes.isNotBlank()) Text(m.notes, color = g.ink, fontSize = 13.sp)
                        Text(if (m.active) "Ativo neste aparelho" else "Inativo", color = if (m.active) g.green else g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Switch(checked = m.active, onCheckedChange = { vm.saveMedication(m.copy(active = it)) })
                }
                Row(Modifier.padding(top = 4.dp)) {
                    Text("Editar", color = g.violet, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { editing = m; creating = false; load(m) })
                    Text("Excluir", color = g.red, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp).clickable { confirm = m.id })
                }
            }
        }
        if (!creating && editing == null) {
            PrimaryButton("Novo medicamento", g.blue, { creating = true; load(null) }, Modifier.padding(top = 12.dp))
        } else {
            GCard(Modifier.padding(top = 12.dp)) {
                Text(if (editing == null) "Novo medicamento" else "Editar medicamento", color = g.ink, fontWeight = FontWeight.ExtraBold)
                GField("Nome", name, { name = it }, "Ex.: Metformina")
                GField("Dose", dose, { dose = it }, "Ex.: 500 mg")
                GField("Horário / orientação", schedule, { schedule = it }, "Ex.: café e jantar")
                GField("Observações", notes, { notes = it }, "Opcional")
                error?.let { Text(it, color = g.red, fontSize = 13.sp) }
                PrimaryButton("Salvar", g.blue, {
                    error = when {
                        name.isBlank() -> "Informe o nome do medicamento."
                        dose.isBlank() -> "Informe a dose."
                        schedule.isBlank() -> "Informe como e quando usar."
                        else -> null
                    }
                    if (error == null) {
                        vm.saveMedication(Medication(editing?.id ?: uid(), name.trim(), dose.trim(), schedule.trim(), notes.trim(), editing?.active ?: true))
                        creating = false
                        editing = null
                    }
                }, Modifier.padding(top = 8.dp))
                PrimaryButton("Cancelar edição", g.muted, { creating = false; editing = null }, Modifier.padding(top = 8.dp))
            }
        }
    }
    confirm?.let { id ->
        ConfirmDialog("Excluir medicamento", "Esta ação não pode ser desfeita.", "Excluir", { vm.deleteMedication(id); confirm = null }) { confirm = null }
    }
}

fun buildReport(vm: GlucoViewModel, days: Int, ctx: Context? = null): String {
    val data = vm.data.value
    val s = data.settings
    val cutoff = System.currentTimeMillis() - days.toLong() * 86_400_000L
    val glucose = data.glucose.filter { it.at >= cutoff }.sortedByDescending { it.at }
    val insulin = data.insulin.filter { it.at >= cutoff }.sortedByDescending { it.at }
    val meals = data.meals.filter { it.at >= cutoff }.sortedByDescending { it.at }
    val symptoms = data.symptoms.filter { it.at >= cutoff }.sortedByDescending { it.at }
    val meds = data.medications.filter { it.active }
    val lines = mutableListOf<String>()
    lines += "RELATÓRIO GLUCO"
    lines += "Paciente: ${s.displayName}"
    lines += "Emitido em: ${formatDateTime(System.currentTimeMillis())}"
    lines += "Período: últimos $days dias (a partir de ${formatDate(cutoff)})"
    lines += "Meta informada: ${s.targetLow}–${s.targetHigh} mg/dL"
    lines += ""
    lines += "RESUMO DA GLICEMIA"
    if (glucose.isEmpty()) lines += "Sem medições no período."
    else {
        val mgs = glucose.map { toMgDl(it.value, it.unit) }
        val inRange = mgs.count { rangeStatus(it, s.targetLow, s.targetHigh) == "ok" }
        val above = mgs.count { rangeStatus(it, s.targetLow, s.targetHigh) == "high" }
        val below = mgs.count { rangeStatus(it, s.targetLow, s.targetHigh) == "low" }
        lines += "Medições: ${glucose.size}"
        lines += "Média: ${mgs.average().roundToInt()} mg/dL"
        lines += "Mínima: ${mgs.min().roundToInt()} mg/dL"
        lines += "Máxima: ${mgs.max().roundToInt()} mg/dL"
        lines += "Tempo na meta (medidas entre ${s.targetLow} e ${s.targetHigh} mg/dL): $inRange de ${mgs.size} · ${((inRange * 100.0) / mgs.size).roundToInt()}%"
        lines += "Acima da meta: $above · Abaixo da meta: $below"
        // A1c estimada pela média das medições (fórmula ADAG: (média + 46,7) / 28,7)
        val eA1c = (mgs.average() + 46.7) / 28.7
        val sparse = days < 14 || mgs.size < 14
        lines += "A1c estimada: ${ptNumber(eA1c, 1)}%" + if (sparse) " (poucos dados no período: estimativa pouco confiável; prefira 30 ou 90 dias)" else ""
        lines += "A estimativa vem só da média das medições e não substitui o exame de hemoglobina glicada."
    }
    lines += ""
    lines += "MEDIÇÕES"
    if (glucose.isEmpty()) lines += "Sem medições no período."
    glucose.forEach { e ->
        val extra = if (e.unit == "mmol/L") " (registrado ${fmtNum(e.value)} mmol/L)" else ""
        val note = if (e.notes.isBlank()) "" else " · ${e.notes}"
        lines += "${formatDateTime(e.at)} · ${toMgDl(e.value, e.unit).roundToInt()} mg/dL$extra · ${GLUCOSE_CONTEXT_LABEL[e.context] ?: e.context}$note"
    }
    lines += ""
    lines += "INSULINA"
    if (insulin.isEmpty()) lines += "Sem registros no período."
    insulin.forEach { e ->
        lines += "${formatDateTime(e.at)} · ${if (e.kind == "aplicacao") "Aplicação" else "Lembrete"} · ${e.name} · ${fmtNum(e.dose)} UI${if (e.notes.isBlank()) "" else " · ${e.notes}"}"
    }
    lines += ""
    lines += "MEDICAMENTOS ATIVOS"
    if (meds.isEmpty()) lines += "Nenhum cadastrado."
    meds.forEach { m -> lines += "${m.name} · ${m.dose} · ${m.schedule}${if (m.notes.isBlank()) "" else " · ${m.notes}"}" }
    lines += ""
    lines += "REFEIÇÕES"
    if (meals.isEmpty()) lines += "Sem registros no período."
    meals.forEach { m ->
        lines += "${formatDateTime(m.at)} · ${MEAL_LABEL[m.type] ?: m.type} · ${m.description}${m.carbs?.let { " · ${fmtNum(it)} g carb." } ?: ""}"
    }
    lines += ""
    lines += "SINTOMAS"
    if (symptoms.isEmpty()) lines += "Sem registros no período."
    symptoms.forEach { sy ->
        lines += "${formatDateTime(sy.at)} · ${sy.name} · ${INTENSITY_LABEL[sy.intensity] ?: sy.intensity}${if (sy.notes.isBlank()) "" else " · ${sy.notes}"}"
    }
    lines += ""
    lines += "Observação: relatório gerado pelo aplicativo Gluco Cris ❤️ a partir de registros informados pela usuária. Não constitui diagnóstico."
    if (ctx != null) {
        try {
            val wToday = waterTodayTotal(ctx)
            val wWeek = waterWeekTotal(ctx)
            val wGoal = effectiveWaterGoal(ctx)
            lines += ""
            lines += "— Cris Hidrata —"
            lines += "Água hoje: $wToday ml (meta efetiva $wGoal ml)"
            lines += "Água (últimos 7 dias no aparelho): $wWeek ml"
        } catch (_: Exception) { }
    }
    lines += "Este texto organiza registros feitos no aplicativo. Não interpreta exames nem substitui orientação médica."
    return lines.joinToString("\n")
}

@Composable
fun ReportScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val context = LocalContext.current
    var days by remember { mutableIntStateOf(7) }
    var text by remember { mutableStateOf("") }
    var copied by remember { mutableStateOf(false) }
    val reportCtx = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(data, days) { text = buildReport(vm, days, reportCtx) }
    ScrollScreen {
        BackTitle("Relatório", { nav.popBackStack() })
        Text("Relatório em português, com datas no formato brasileiro, pronto para a equipe de saúde de ${data.settings.displayName}.", color = g.muted, fontSize = 13.sp)
        ChipRow(listOf("7" to "7 dias", "14" to "14 dias", "30" to "30 dias", "90" to "90 dias"), days.toString()) { days = it.toInt() }
        GCard(Modifier.padding(top = 8.dp)) {
            Text("Pré-visualização", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(text, color = g.ink, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 6.dp))
        }
        PrimaryButton("Compartilhar texto", g.violet, {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Relatório Gluco Cris ❤️ — ${data.settings.displayName}")
                putExtra(Intent.EXTRA_TEXT, text)
            }
            context.startActivity(Intent.createChooser(send, "Compartilhar relatório"))
        }, Modifier.padding(top = 12.dp))
        PrimaryButton("Compartilhar PDF", g.green, {
            val doc = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(595, 842, 1).create()
            var page = doc.startPage(pageInfo)
            var canvas = page.canvas
            val paint = Paint().apply { textSize = 10f; isAntiAlias = true }
            var y = 40f
            text.lines().forEach { line ->
                if (y > 800f) {
                    doc.finishPage(page)
                    page = doc.startPage(pageInfo)
                    canvas = page.canvas
                    y = 40f
                }
                canvas.drawText(line.take(95), 40f, y, paint)
                y += 14f
            }
            doc.finishPage(page)
            val bos = java.io.ByteArrayOutputStream()
            doc.writeTo(bos)
            doc.close()
            val dir = File(context.cacheDir, "share").apply { mkdirs() }
            val f = File(dir, "relatorio_gluco_cris.pdf")
            f.writeBytes(bos.toByteArray())
            val uri = try {
                FileProvider.getUriForFile(context, context.packageName + ".fileprovider", f)
            } catch (_: Exception) {
                android.net.Uri.fromFile(f)
            }
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "application/pdf"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "Relatório Gluco Cris")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(send, "Compartilhar PDF"))
        }, Modifier.padding(top = 8.dp))
        PrimaryButton("Compartilhar planilha (CSV)", g.green, {
            val csv = buildString {
                append('\uFEFF')
                appendLine("Relatório Gluco Cris")
                text.lines().forEach { appendLine(it.replace(";", ",")) }
            }
            val dir = File(context.cacheDir, "share").apply { mkdirs() }
            val f = File(dir, "relatorio_gluco_cris.csv")
            f.writeText(csv)
            val uri = try {
                FileProvider.getUriForFile(context, context.packageName + ".fileprovider", f)
            } catch (_: Exception) {
                android.net.Uri.fromFile(f)
            }
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/csv"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(send, "Compartilhar planilha"))
        }, Modifier.padding(top = 8.dp))
        PrimaryButton("Copiar", g.blue, {
            val clipboard = context.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as ClipboardManager
            clipboard.setPrimaryClip(ClipData.newPlainText("Relatório Gluco Cris ❤️", text))
            copied = true
        }, Modifier.padding(top = 8.dp))
        if (copied) Text("Relatório copiado.", color = g.green, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        Text("GLUCO · uso clínico de apoio", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp))
    }
}

@Composable
fun SettingsScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val context = LocalContext.current
    val s = data.settings
    var low by remember(s.targetLow) { mutableStateOf(s.targetLow.toString()) }
    var high by remember(s.targetHigh) { mutableStateOf(s.targetHigh.toString()) }
    var unit by remember(s.preferredUnit) { mutableStateOf(s.preferredUnit) }
    var name by remember(s.displayName) { mutableStateOf(s.displayName) }
    var message by remember { mutableStateOf<String?>(null) }
    var pin by remember { mutableStateOf("") }
    var pin2 by remember { mutableStateOf("") }
    var confirmReset by remember { mutableStateOf(false) }
    var confirmWipe by remember { mutableStateOf(false) }

    ScrollScreen {
        BackTitle("Ajustes", { nav.popBackStack() })
        Text("GLUCO", color = g.violet, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
        Text("Gluco Cris ❤️", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        Text("Aplicativo pessoal de acompanhamento. Os dados ficam neste aparelho.", color = g.muted, fontSize = 13.sp)

        SectionTitle("Aparência")
        GCard {
            Text("Seguir o sistema", color = g.ink, fontWeight = FontWeight.Bold)
            ChipRow(
                listOf("sistema" to "Seguir o sistema", "claro" to "Tema claro", "escuro" to "Tema escuro"),
                when (s.darkMode) { true -> "escuro"; false -> "claro"; null -> "sistema" },
            ) { choice ->
                vm.updateSettings { it.copy(darkMode = when (choice) { "escuro" -> true; "claro" -> false; else -> null }) }
            }
        }
        SectionTitle("Meta de glicose")
        GCard {
            Text("Usada nos gráficos, alertas de cor e relatórios. Ajuste com a equipe de saúde.", color = g.muted, fontSize = 13.sp)
            GField("Mínimo (mg/dL)", low, { low = it }, "70", numeric = true)
            GField("Máximo (mg/dL)", high, { high = it }, "180", numeric = true)
            Text("Unidade preferida nos novos registros", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
            ChipRow(listOf("mg/dL" to "mg/dL", "mmol/L" to "mmol/L"), unit) { unit = it }
            GField("Nome na tela inicial", name, { name = it }, "Maria Cristina")
            Text("O nome na tela inicial é personalização. O PIN é a proteção. São coisas diferentes.", color = g.muted, fontSize = 12.sp)
            message?.let { Text(it, color = if (it.startsWith("A meta deve")) g.red else g.green, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
            PrimaryButton("Salvar meta", g.violet, {
                val lo = low.toIntOrNull()
                val hi = high.toIntOrNull()
                if (lo == null || hi == null || lo < 40 || hi > 400 || lo >= hi) {
                    message = "A meta deve ter mínimo entre 40 e o máximo, e máximo até 400 mg/dL."
                } else {
                    vm.updateSettings { it.copy(targetLow = lo, targetHigh = hi, preferredUnit = unit, displayName = name.ifBlank { "Maria Cristina" }) }
                    message = "Meta atualizada."
                }
            }, Modifier.padding(top = 8.dp))
        }
        SectionTitle("Proteção de acesso")
        GCard {
            Text(if (s.pinEnabled) "PIN de 4 dígitos ativo" else "Sem PIN", color = g.ink, fontWeight = FontWeight.Bold)
            Text("A personalização visual não substitui o PIN. Seus registros ficam neste aparelho.", color = g.muted, fontSize = 12.sp)
            if (s.pinEnabled) {
                val bioAvailable = remember { BiometricHelper.available(context) }
                SettingToggleRow(
                    "Entrar com digital ou rosto",
                    if (bioAvailable) "Mais rápido que o PIN. O PIN continua valendo se a biometria falhar."
                    else "Este aparelho não tem digital ou rosto cadastrado. Cadastre nos ajustes do Android para usar.",
                    s.biometricEnabled && bioAvailable,
                ) { on ->
                    if (!on) {
                        vm.updateSettings { it.copy(biometricEnabled = false) }
                        message = "Entrada por biometria desligada."
                    } else if (!bioAvailable) {
                        message = "Cadastre uma digital ou rosto nos ajustes do Android primeiro."
                    } else {
                        // Confirma que funciona antes de ligar
                        BiometricHelper.prompt(
                            context, "Ativar biometria", "Confirme com sua digital ou rosto",
                            onSuccess = {
                                vm.updateSettings { it.copy(biometricEnabled = true) }
                                message = "Entrada por digital ou rosto ativada."
                            },
                        )
                    }
                }
                PrimaryButton("Remover PIN", g.red, {
                    vm.updateSettings { it.copy(pinEnabled = false, pin = "", biometricEnabled = false) }
                    vm.lock()
                    message = "PIN removido."
                }, Modifier.padding(top = 8.dp))
                PrimaryButton("Bloquear agora", g.violetDeep, { vm.lock() }, Modifier.padding(top = 8.dp))
            } else {
                GField("Novo PIN", pin, { if (it.length <= 4 && it.all { c -> c.isDigit() }) pin = it }, "4 números", numeric = true)
                GField("Confirmar PIN", pin2, { if (it.length <= 4 && it.all { c -> c.isDigit() }) pin2 = it }, "4 números", numeric = true)
                Text("Digite o novo PIN abaixo e toque em Ativar PIN.", color = g.muted, fontSize = 12.sp)
                PrimaryButton("Ativar PIN", g.violet, {
                    message = when {
                        pin.length != 4 -> "O PIN deve ter exatamente 4 números."
                        pin != pin2 -> "A confirmação do PIN não confere."
                        else -> {
                            vm.updateSettings { it.copy(pinEnabled = true, pin = pin) }
                            "Proteção por PIN ativada. A tela inicial continua personalizada para ${s.displayName} — o PIN é a trava de acesso."
                        }
                    }
                    if (pin.length == 4 && pin == pin2) {
                        pin = ""
                        pin2 = ""
                    }
                }, Modifier.padding(top = 8.dp))
            }
        }
        SectionTitle("Alertas de glicemia")
        GCard {
            Text("Avisos ligados aos valores medidos (a aba Lembretes só avisa horários). Cada situação avisa uma vez.", color = g.muted, fontSize = 13.sp)
            var lowOn by remember { mutableStateOf(GlucoseAlerts.lowOn(context)) }
            var lowH by remember { mutableIntStateOf(GlucoseAlerts.lowHours(context)) }
            var highOn by remember { mutableStateOf(GlucoseAlerts.highOn(context)) }
            var highH by remember { mutableIntStateOf(GlucoseAlerts.highHours(context)) }
            var missOn by remember { mutableStateOf(GlucoseAlerts.missOn(context)) }
            var missH by remember { mutableIntStateOf(GlucoseAlerts.missHour(context)) }
            SettingToggleRow("Glicemia baixa", "Avisa se a última medição está abaixo da meta e passou o tempo escolhido sem nova medida.", lowOn) {
                lowOn = it; GlucoseAlerts.setLowOn(context, it)
            }
            if (lowOn) ChipRow(listOf("1" to "1 hora", "2" to "2 horas", "3" to "3 horas"), lowH.toString()) {
                lowH = it.toInt(); GlucoseAlerts.setLowHours(context, lowH)
            }
            SettingToggleRow("Glicemia alta", "Avisa se a última medição está acima da meta e passou o tempo escolhido sem nova medida.", highOn) {
                highOn = it; GlucoseAlerts.setHighOn(context, it)
            }
            if (highOn) ChipRow(listOf("2" to "2 horas", "3" to "3 horas", "4" to "4 horas", "6" to "6 horas"), highH.toString()) {
                highH = it.toInt(); GlucoseAlerts.setHighHours(context, highH)
            }
            SettingToggleRow("Sem medir hoje", "Avisa se ainda não houver nenhuma medição no dia a partir do horário escolhido.", missOn) {
                missOn = it; GlucoseAlerts.setMissOn(context, it)
            }
            if (missOn) ChipRow(listOf("12" to "12h", "16" to "16h", "18" to "18h", "20" to "20h", "22" to "22h"), missH.toString()) {
                missH = it.toInt(); GlucoseAlerts.setMissHour(context, missH)
            }
            Text("Em caso de sintomas, siga o plano da sua equipe de saúde. Os alertas são um apoio e não substituem a medição.", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
        SectionTitle("Registro rápido de glicemia")
        GCard {
            Text("Registre a glicemia sem abrir o app: pela barra de notificações ou por um widget na tela inicial.", color = g.muted, fontSize = 13.sp)
            var quickOn by remember { mutableStateOf(QuickGlucoseNotifier.isOn(context)) }
            SettingToggleRow("Atalho na barra de notificações", "Fica fixo na barra: toque em \"Registrar glicemia\", digite o valor e envie.", quickOn) {
                quickOn = it; QuickGlucoseNotifier.setOn(context, it)
            }
            Text(
                if (GlucoseWidgetProvider.isPlaced(context)) "Widget na tela inicial: já adicionado."
                else "Widget: segure um espaço vazio da tela inicial, toque em Widgets e escolha \"Gluco Cris ❤️\".",
                color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
            )
        }
        SectionTitle("Sons dos alertas")
        GCard {
            Text("Toque para ouvir. O som de cada lembrete é escolhido na aba Lembretes.", color = g.muted, fontSize = 13.sp)
            SOUND_PRESETS.forEach { preset ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                        Text(preset.name, color = g.ink, fontWeight = FontWeight.Bold)
                        Text(preset.description, color = g.muted, fontSize = 12.sp)
                    }
                    Text("Ouvir", color = g.violet, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { SoundPlayer.play(context, preset.id) })
                }
            }
        }
        SectionTitle("Atualização do aplicativo")
        GCard {
            Text("Versão instalada: 1.0", color = g.ink, fontWeight = FontWeight.Bold)
            Text(
                "Toque para verificar se existe uma versão mais recente. A verificação usa apenas fontes oficiais configuradas.",
                color = g.muted,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 4.dp),
            )
            var updateMsg by remember { mutableStateOf<String?>(null) }
            PrimaryButton("🔄 Atualizar aplicativo", g.violet, {
                // Ainda não há servidor de distribuição configurado.
                // Estrutura preparada; não simula atualização inexistente.
                updateMsg = "Nenhuma atualização disponível no momento. Quando houver uma nova versão oficial, ela será indicada aqui."
            }, Modifier.padding(top = 8.dp))
            updateMsg?.let {
                Text(it, color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }

        SectionTitle("Dados")
        PrimaryButton("Restaurar dados de exemplo", g.orange, { confirmReset = true }, Modifier.padding(top = 4.dp))
        PrimaryButton("Apagar dados deste aparelho", g.red, { confirmWipe = true }, Modifier.padding(top = 8.dp))
        Text("Gluco Cris ❤️ · presente para ${s.displayName}", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 16.dp))
    }
    if (confirmReset) {
        ConfirmDialog(
            "Restaurar dados de exemplo",
            "Isso remove medições, insulina, lembretes e o PIN, e restaura exemplos iniciais.",
            "Restaurar",
            { vm.resetAll(); confirmReset = false },
        ) { confirmReset = false }
    }
    if (confirmWipe) {
        ConfirmDialog(
            "Apagar dados deste aparelho",
            "Isso remove medições, insulina, lembretes e o PIN, e restaura exemplos iniciais.",
            "Apagar",
            { vm.resetAll(); confirmWipe = false },
        ) { confirmWipe = false }
    }
}


@Composable
private fun SettingToggleRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val g = glucoColors()
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        androidx.compose.foundation.layout.Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, color = g.ink, fontWeight = FontWeight.Bold)
            Text(desc, color = g.muted, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
