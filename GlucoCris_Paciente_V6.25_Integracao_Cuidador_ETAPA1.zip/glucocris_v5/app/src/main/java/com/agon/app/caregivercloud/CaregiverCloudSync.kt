package com.agon.app.caregivercloud

import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.tasks.await

/**
 * Integração remota do Gluco Cris Paciente com o backend do Cuidador.
 * Nenhum dado é enviado automaticamente por esta classe: a interface deve obter
 * consentimento explícito antes de habilitar chamadas de sincronização.
 * Região e caminhos correspondem ao backend/firebase do projeto Cuidador.
 */
class CaregiverCloudSync(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val functions: FirebaseFunctions = FirebaseFunctions.getInstance("southamerica-east1"),
) {
    private val patientUid: String
        get() = auth.currentUser?.takeIf { !it.isAnonymous }?.uid
            ?: error("Entre na sua conta Gluco Cris antes de compartilhar.")

    suspend fun createPairingCode(): PairingCode {
        val data = functions.getHttpsCallable("createPairingCode").call().await().data as? Map<*, *>
            ?: error("Resposta inválida ao criar código.")
        return PairingCode(data["code"] as? String ?: error("Código ausente."),
            data["qrPayload"] as? String ?: error("QR ausente."),
            (data["expiresInMin"] as? Number)?.toInt() ?: 10)
    }

    suspend fun approveCaregiver(caregiverUid: String, permissions: CaregiverPermissions) {
        require(caregiverUid.isNotBlank() && caregiverUid != patientUid)
        functions.getHttpsCallable("respondRequest").call(mapOf(
            "caregiverUid" to caregiverUid, "approve" to true, "permissions" to permissions.asMap()
        )).await()
    }

    suspend fun denyCaregiver(caregiverUid: String) {
        require(caregiverUid.isNotBlank() && caregiverUid != patientUid)
        functions.getHttpsCallable("respondRequest").call(mapOf(
            "caregiverUid" to caregiverUid, "approve" to false, "permissions" to emptyMap<String, Boolean>()
        )).await()
    }

    suspend fun updateCaregiverPermissions(caregiverUid: String, permissions: CaregiverPermissions) {
        functions.getHttpsCallable("updatePermissions").call(mapOf(
            "caregiverUid" to caregiverUid, "permissions" to permissions.asMap()
        )).await()
    }

    suspend fun revokeCaregiver(caregiverUid: String) {
        functions.getHttpsCallable("revokeCaregiver").call(mapOf("caregiverUid" to caregiverUid)).await()
    }

    /** Envia uma leitura em mg/dL com ID estável. Chamador só deve usar após consentimento. */
    suspend fun publishReading(id: String, valueMgDl: Int, measuredAtMs: Long, source: String) {
        require(id.isNotBlank() && id.length <= 64)
        require(valueMgDl in 20..600)
        require(source == "manual" || source == "cgm")
        val ref = db.document("patients/$patientUid/readings/$id")
        ref.set(mapOf(
            "value" to valueMgDl,
            "unit" to "mg/dL",
            "source" to source,
            "originTs" to Timestamp(measuredAtMs / 1000, ((measuredAtMs % 1000) * 1_000_000).toInt()),
            "serverTs" to FieldValue.serverTimestamp(),
        )).await()
    }

    /** Publica somente metadados de exibição e limites; não inclui telefone nem notas clínicas. */
    suspend fun publishPatientProfile(displayName: String, low: Int, high: Int, urgentLow: Int, urgentHigh: Int) {
        require(displayName.length <= 80)
        require(urgentLow in 20..low && low < high && high < urgentHigh && urgentHigh <= 600)
        db.document("patients/$patientUid").set(mapOf(
            "displayName" to displayName.take(80),
            "thresholds" to mapOf("urgentLow" to urgentLow, "low" to low, "targetLow" to low,
                "targetHigh" to high, "high" to high, "urgentHigh" to urgentHigh),
        ), com.google.firebase.firestore.SetOptions.merge()).await()
    }

    suspend fun publishSyncStatus(pendingCount: Int, cgmState: String, lastCgmAtMs: Long?) {
        require(pendingCount >= 0)
        require(cgmState in setOf("ok", "no_readings", "disconnected"))
        db.document("patients/$patientUid/syncStatus/status").set(mapOf(
            "lastSyncAt" to FieldValue.serverTimestamp(),
            "pendingCount" to pendingCount,
            "cgmState" to cgmState,
            "lastCgmReadingAt" to lastCgmAtMs?.let { Timestamp(it / 1000, 0) },
        )).await()
    }

    suspend fun pendingRequests() = db.collection("patients/$patientUid/requests")
        .whereEqualTo("status", "pending").get().await()

    suspend fun activeCaregivers() = db.collection("patients/$patientUid/links")
        .whereEqualTo("status", "active").get().await()
}

data class PairingCode(val code: String, val qrPayload: String, val expiresInMin: Int)

data class CaregiverPermissions(
    val currentGlucose: Boolean = false,
    val history: Boolean = false,
    val charts: Boolean = false,
    val cgm: Boolean = false,
    val trends: Boolean = false,
    val gmi: Boolean = false,
    val cgmCoverage: Boolean = false,
    val hba1cCurrent: Boolean = false,
    val hba1cHistory: Boolean = false,
    val reports: Boolean = false,
    val alerts: Boolean = false,
    val diary: Boolean = false,
    val carePlan: Boolean = false,
    val emergencyContacts: Boolean = false,
    val extraInfo: Boolean = false,
) {
    fun asMap() = mapOf(
        "currentGlucose" to currentGlucose, "history" to history, "charts" to charts,
        "cgm" to cgm, "trends" to trends, "gmi" to gmi, "cgmCoverage" to cgmCoverage,
        "hba1cCurrent" to hba1cCurrent, "hba1cHistory" to hba1cHistory,
        "reports" to reports, "alerts" to alerts, "diary" to diary,
        "carePlan" to carePlan, "emergencyContacts" to emergencyContacts, "extraInfo" to extraInfo,
    )
}
