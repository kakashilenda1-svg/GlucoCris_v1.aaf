# Integração Gluco Cris Paciente + Cuidador

Este diretório contém o backend do Cuidador e uma proposta de regras Firestore mescladas com as regras de backup do Paciente. O arquivo `firestore.rules.MERGED_CANDIDATE` é uma candidata para revisão/testes; o `firestore.rules` original do Paciente não foi substituído.

## Fluxo previsto
- O Paciente autentica com Firebase Authentication (UID individual).
- O Paciente gera um código temporário; o Cuidador solicita acesso usando esse código.
- O Paciente aprova individualmente o cuidador e escolhe permissões.
- Cada UID de paciente mantém seus próprios dados em `patients/{uid}`. Uma conta de cuidador pode ter vários documentos em `users/{cuidadorUid}/patients/{patientUid}`.
- As Cloud Functions processam medições, criam alertas e enviam FCM apenas aos cuidadores com a permissão `alerts`.
- A permissão `currentGlucose` controla se o valor numérico pode aparecer no texto da notificação.

## Limitação importante
A classe Android `CaregiverCloudSync` adicionada ao Paciente é uma camada de integração explícita. Ela não envia dados automaticamente e ainda precisa ser conectada à interface de consentimento e ao fluxo de gravação local. Isso evita enviar dados de saúde sem uma autorização clara.

## Firebase
O backend usa região `southamerica-east1`, Cloud Functions v2, Admin SDK e Firebase Cloud Messaging. **Cloud Functions/FCM via Functions v2 exigem que o projeto Firebase esteja no plano Blaze e com faturamento configurado**. Não faça upgrade sem revisar custos e limites. O arquivo de regras candidato deve ser validado no Emulator Suite e revisado antes de publicar.

## Alertas
O backend cria alertas para leituras fora dos limites configurados e usa ID determinístico em janelas de 30 minutos para reduzir duplicatas. Limites padrão no backend: urgente baixo 54, baixo 70, alto 180 e urgente alto 250 mg/dL. Os limites precisam ser revisados com orientação clínica individual; o app não substitui atendimento médico.

## Próxima etapa obrigatória
Integrar `publishReading` ao fluxo de salvamento/sincronização com consentimento persistente, criar telas de código/solicitações/permissões no Paciente e executar testes com dois UIDs de paciente e um UID de cuidador. Não publicar as regras candidatas antes desses testes.
