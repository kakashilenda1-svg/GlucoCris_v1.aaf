package com.agon.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.Routes

private data class NavItem(val route: String, val label: String, val icon: ImageVector)

/** Barra do layout roxo: 5 abas, com a aba atual em um círculo neon (medidas da imagem de referência). */
@Composable
fun PurpleNavBar(current: String, onSelect: (String) -> Unit) {
    val items = listOf(
        NavItem(Routes.HOME, "Início", Icons.Filled.Home),
        NavItem(Routes.INSULIN, "Insulina", Icons.Filled.Vaccines),
        NavItem(Routes.GLUCOSE, "Glicose", Icons.Filled.WaterDrop),
        NavItem(Routes.FOOD, "Aliment", Icons.Filled.Restaurant),
        NavItem(Routes.MORE, "Mais", Icons.Filled.MoreHoriz),
    )
    // Histórico e Lembretes ficam no menu Mais; ali a aba "Mais" fica marcada.
    val selectedRoute = if (current == Routes.REMINDERS || current == Routes.HISTORY) Routes.MORE else current
    val shape = RoundedCornerShape(30.dp)
    Box(Modifier.fillMaxWidth().background(Color(0xFF060016)).navigationBarsPadding().padding(start = 10.dp, end = 10.dp, bottom = 4.dp, top = 2.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(62.dp)
                .shadow(12.dp, shape, clip = false, ambientColor = Color(0xFF7A2BFF), spotColor = Color(0xFF7A2BFF))
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFF1A0540), Color(0xFF10022B))))
                .border(2.dp, Brush.horizontalGradient(listOf(Color(0xFF8A3BFF), Color(0xFF5A1FD0), Color(0xFF8A3BFF))), shape),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items.forEach { item ->
                val sel = selectedRoute == item.route
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .tourTarget("tab_" + item.route)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(item.route) },
                    contentAlignment = Alignment.Center,
                ) {
                    if (sel) {
                        Box(
                            Modifier
                                .size(56.dp)
                                .shadow(14.dp, CircleShape, clip = false, ambientColor = Color(0xFFB51BFF), spotColor = Color(0xFFB51BFF))
                                .clip(CircleShape)
                                .background(Brush.radialGradient(listOf(Color(0xFF6A2BE0), Color(0xFF3A12A0))))
                                .border(2.dp, Brush.linearGradient(listOf(Color(0xFFD7A8FF), Color(0xFF7B3DFF))), CircleShape),
                        )
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(item.icon, item.label, tint = if (sel) Color.White else Color(0xFFCDB8F6), modifier = Modifier.size(24.dp))
                        Text(
                            item.label,
                            color = if (sel) Color.White else Color(0xFFE8DCFF),
                            fontSize = 10.sp,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 2.dp),
                        )
                    }
                }
            }
        }
    }
}

/** Barra do layout azul: 7 abas, aba atual em azul com traço embaixo (medidas da imagem de referência). */
@Composable
fun BlueNavBar(current: String, onSelect: (String) -> Unit) {
    val items = listOf(
        NavItem(Routes.HOME, "Início", Icons.Filled.Home),
        NavItem(Routes.INSULIN, "Insulina", Icons.Filled.Vaccines),
        NavItem(Routes.GLUCOSE, "Glicose", Icons.Filled.WaterDrop),
        NavItem(Routes.FOOD, "Aliment", Icons.Filled.Restaurant),
        NavItem(Routes.MORE, "Mais", Icons.Filled.MoreHoriz),
    )
    // Histórico e Lembretes ficam no menu Mais.
    val selectedRoute = if (current == Routes.REMINDERS || current == Routes.HISTORY) Routes.MORE else current
    val shape = RoundedCornerShape(22.dp)
    val activeBlue = Color(0xFF2E8BFF)
    Box(Modifier.fillMaxWidth().background(Color(0xFF030F26)).navigationBarsPadding().padding(start = 7.dp, end = 7.dp, bottom = 5.dp, top = 2.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(58.dp)
                .shadow(10.dp, shape, clip = false, ambientColor = Color(0xFF1F6FE0), spotColor = Color(0xFF1F6FE0))
                .clip(shape)
                .background(Brush.verticalGradient(listOf(Color(0xFF0A2250), Color(0xFF061634))))
                .border(1.5.dp, Brush.verticalGradient(listOf(Color(0xFF2D6FCC), Color(0xFF133B7A))), shape),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
            items.forEach { item ->
                val sel = selectedRoute == item.route
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .tourTarget("tab_" + item.route)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSelect(item.route) },
                    contentAlignment = Alignment.Center,
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(item.icon, item.label, tint = if (sel) activeBlue else Color.White, modifier = Modifier.size(22.dp))
                        Text(
                            item.label,
                            color = if (sel) activeBlue else Color.White,
                            fontSize = 9.sp,
                            fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            softWrap = false,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                    if (sel) {
                        Box(
                            Modifier
                                .align(Alignment.BottomCenter)
                                .padding(bottom = 3.dp)
                                .width(44.dp)
                                .height(3.dp)
                                .clip(RoundedCornerShape(2.dp))
                                .background(activeBlue),
                        )
                    }
                }
            }
        }
    }
}
