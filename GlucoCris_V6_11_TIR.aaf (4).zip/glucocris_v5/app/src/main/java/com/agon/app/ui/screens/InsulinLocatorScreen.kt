package com.agon.app.ui.screens

import android.content.Intent
import android.net.Uri

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.agon.app.data.insulin.BrazilGeo
import com.agon.app.data.insulin.ChannelType
import com.agon.app.data.insulin.City
import com.agon.app.data.insulin.InsulinCatalog
import com.agon.app.data.insulin.LocatorResult
import com.agon.app.data.insulin.LocatorScope
import com.agon.app.data.insulin.PriceTier
import com.agon.app.data.insulin.SortMode
import com.agon.app.data.insulin.SupplyNetwork
import com.agon.app.data.HealthPlace
import com.agon.app.data.PlaceFinder
import com.agon.app.data.PlaceKind
import com.agon.app.data.insulin.SupplyPoint
import com.agon.app.ui.theme.glucoColors
import com.agon.app.viewmodel.LocatorViewModel

private const val MAX_VISIBLE = 120

@Composable
fun InsulinLocatorScreen(
    nav: NavHostController,
    lvm: LocatorViewModel = viewModel(),
) {
    val g = glucoColors()
    val focus = LocalFocusManager.current
    var selectedPoint by remember { mutableStateOf<SupplyPoint?>(null) }
    var history by remember { mutableStateOf(listOf<String>()) }
    var citySearch by remember { mutableStateOf("") }
    var showCityPicker by remember { mutableStateOf(false) }
    var realPlaces by remember { mutableStateOf<List<HealthPlace>>(emptyList()) }
    var realLoading by remember { mutableStateOf(false) }
    var realError by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current

    val reference: City? = lvm.cityId?.let { BrazilGeo.cityById(it) }
        ?: lvm.uf?.let { BrazilGeo.capitalOf(it) }

    val result: LocatorResult = remember(lvm.query, reference?.id) {
        SupplyNetwork.search(lvm.query, reference)
    }
    val visiblePoints = result.points.take(MAX_VISIBLE)

    // Locais reais (OSM) — busca rápida: raio menor, farmácias primeiro, mostra assim que chegar
    LaunchedEffect(lvm.cityId) {
        val city = lvm.cityId?.let { BrazilGeo.cityById(it) }
        if (city == null) {
            realPlaces = emptyList()
            realError = null
            realLoading = false
            return@LaunchedEffect
        }
        realLoading = true
        realError = null
        realPlaces = emptyList()
        val prevTimeout = com.agon.app.data.LocatorConfig.mirrorTimeoutMs
        val prevHedge = com.agon.app.data.LocatorConfig.hedgeDelayMs
        val prevBudget = com.agon.app.data.LocatorConfig.sourceBudgetMs
        val prevAttempts = com.agon.app.data.LocatorConfig.maxAttempts
        com.agon.app.data.LocatorConfig.mirrorTimeoutMs = 4_000L
        com.agon.app.data.LocatorConfig.hedgeDelayMs = 200L
        com.agon.app.data.LocatorConfig.sourceBudgetMs = 8_000L
        com.agon.app.data.LocatorConfig.maxAttempts = 1
        try {
            // Fase 1: só farmácias, raio 3 km (bem mais rápido no Overpass)
            PlaceFinder.searchFlow(
                context = context,
                lat = city.lat,
                lon = city.lon,
                radiusKm = 3,
                only = setOf(com.agon.app.data.SRC_FARMACIAS),
            ).collect { state ->
                val filtered = state.places
                    .filter { it.kind == PlaceKind.FARMACIA || it.kind == PlaceKind.UBS }
                    .sortedBy { it.distanceKm }
                    .take(30)
                if (filtered.isNotEmpty()) {
                    realPlaces = filtered
                    realLoading = false
                }
                if (state.finished) realLoading = false
            }
            // Fase 2: se ainda vazio, amplia para 5 km com UBS/unidades
            if (realPlaces.isEmpty()) {
                realLoading = true
                PlaceFinder.searchFlow(
                    context = context,
                    lat = city.lat,
                    lon = city.lon,
                    radiusKm = 5,
                ).collect { state ->
                    val filtered = state.places
                        .filter {
                            it.kind == PlaceKind.FARMACIA || it.kind == PlaceKind.UBS || it.kind == PlaceKind.HOSPITAL
                        }
                        .sortedBy { it.distanceKm }
                        .take(40)
                    if (filtered.isNotEmpty()) {
                        realPlaces = filtered
                        realLoading = false
                    }
                    if (state.finished) {
                        realLoading = false
                        if (realPlaces.isEmpty()) {
                            realError = "Não encontramos estabelecimentos com endereço nesta área. Tente outro município."
                        }
                    }
                }
            }
        } catch (e: Exception) {
            realLoading = false
            if (realPlaces.isEmpty()) {
                realError = "Falha ao buscar locais. Verifique a conexão e tente de novo."
            }
        } finally {
            com.agon.app.data.LocatorConfig.mirrorTimeoutMs = prevTimeout
            com.agon.app.data.LocatorConfig.hedgeDelayMs = prevHedge
            com.agon.app.data.LocatorConfig.sourceBudgetMs = prevBudget
            com.agon.app.data.LocatorConfig.maxAttempts = prevAttempts
        }
    }


    LaunchedEffect(lvm.text) {
        val t = lvm.text.trim()
        if (t.length < 2) return@LaunchedEffect
        kotlinx.coroutines.delay(120)
        if (lvm.text.trim() != t) return@LaunchedEffect
        if (t !in history) history = (listOf(t) + history).take(12)
        val hits = InsulinCatalog.search(t)
        if (hits.size == 1) {
            lvm.productId = hits.first().id
        }
    }

    fun commitSearch() {
        val t = lvm.text.trim()
        if (t.isBlank()) {
            focus.clearFocus()
            return
        }
        if (t !in history) history = (listOf(t) + history).take(12)
        // Tenta casar com produto do catálogo (ex: "lantus", "nph", "novorapid")
        val hits = InsulinCatalog.search(t)
        if (hits.size == 1) {
            lvm.productId = hits.first().id
        } else if (hits.isNotEmpty()) {
            // mantém texto; a busca por texto no SupplyNetwork já filtra
            lvm.productId = "all"
        }
        focus.clearFocus()
        selectedPoint = null
    }

    Column(Modifier.fillMaxSize().background(g.bg)) {
        // Top bar — igual estilo original + cores v2
        Row(
            Modifier.fillMaxWidth().background(g.card).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = g.ink,
                modifier = Modifier.size(28.dp).clickable { nav.popBackStack() },
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Localizador de Insulinas", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = g.ink)
                Text(
                    when (lvm.scope) {
                        LocatorScope.BRASIL -> "Todo o Brasil"
                        LocatorScope.UF -> BrazilGeo.ufByCode(lvm.uf ?: "")?.name ?: lvm.uf ?: ""
                        LocatorScope.CIDADE -> BrazilGeo.cityById(lvm.cityId ?: "")?.label ?: ""
                    },
                    fontSize = 12.sp, color = g.muted,
                )
            }
            Icon(
                Icons.Default.FilterList, "Filtros",
                tint = if (lvm.filtersExpanded || lvm.activeFilterCount > 0) g.violet else g.muted,
                modifier = Modifier.size(26.dp).clickable { lvm.filtersExpanded = !lvm.filtersExpanded },
            )
        }

        // Campo de busca
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(g.inputBg)
                .border(1.dp, g.line, RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Default.Search, null, tint = g.muted, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            BasicTextField(
                value = lvm.text,
                onValueChange = { lvm.text = it },
                singleLine = true,
                textStyle = TextStyle(color = g.ink, fontSize = 15.sp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { commitSearch() }),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    if (lvm.text.isEmpty()) {
                        Text("Digite o nome: Lantus, NPH, Humalog, Tresiba…", color = g.muted, fontSize = 14.sp)
                    }
                    inner()
                },
            )
            if (lvm.text.isNotEmpty()) {
                Icon(
                    Icons.Default.Close, "Limpar", tint = g.muted,
                    modifier = Modifier.size(18.dp).clickable { lvm.text = "" },
                )
            }
        }

        // Atalhos rápidos por tipo (mais fácil de achar)
        Text(
            "Tipo de insulina",
            fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = g.muted,
            modifier = Modifier.padding(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 4.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            item {
                MiniChip("Todas", selected = lvm.categoryIds.isEmpty() && lvm.productId == "all", g = g) {
                    lvm.categoryIds = emptySet()
                    lvm.productId = "all"
                }
            }
            item { MiniChip("NPH", selected = "nph" in lvm.categoryIds, g = g) { lvm.toggleCategory("nph") } }
            item { MiniChip("Regular", selected = "regular" in lvm.categoryIds, g = g) { lvm.toggleCategory("regular") } }
            item { MiniChip("Rápida / bolus", selected = "analogo_rapido" in lvm.categoryIds, g = g) { lvm.toggleCategory("analogo_rapido") } }
            item { MiniChip("Basal longa", selected = "analogo_longo" in lvm.categoryIds, g = g) { lvm.toggleCategory("analogo_longo") } }
            item { MiniChip("Pré-mistura", selected = "pre_mistura" in lvm.categoryIds, g = g) { lvm.toggleCategory("pre_mistura") } }
        }

        // Produtos do catálogo (filtrados pelo tipo quando houver)
        val productsForChips = remember(lvm.categoryIds) {
            if (lvm.categoryIds.isEmpty()) InsulinCatalog.products
            else InsulinCatalog.products.filter { it.categoryId in lvm.categoryIds }
        }
        Text(
            "Marca / produto",
            fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = g.muted,
            modifier = Modifier.padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 4.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            item {
                MiniChip("Todas", selected = lvm.productId == "all", g = g) {
                    lvm.productId = "all"
                }
            }
            items(productsForChips) { p ->
                MiniChip(
                    p.brandName,
                    selected = lvm.productId == p.id,
                    g = g,
                ) {
                    lvm.productId = if (lvm.productId == p.id) "all" else p.id
                }
            }
        }

        // Histórico de buscas recentes
        if (history.isNotEmpty()) {
            Text(
                "Buscas recentes",
                fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = g.muted,
                modifier = Modifier.padding(start = 12.dp, end = 12.dp, top = 8.dp, bottom = 4.dp),
            )
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(history) { h ->
                    MiniChip(h, selected = false, g = g) {
                        lvm.text = h
                        commitSearch()
                    }
                }
            }
        }

        // Localização: Brasil / UF / Cidade
        Text(
            "Onde buscar",
            fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = g.muted,
            modifier = Modifier.padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 4.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            item {
                MiniChip("Brasil", selected = lvm.scope == LocatorScope.BRASIL, g = g) {
                    lvm.selectBrazil()
                    showCityPicker = false
                }
            }
            items(BrazilGeo.ufs) { uf ->
                MiniChip(
                    uf.code,
                    selected = lvm.uf == uf.code,
                    g = g,
                ) {
                    if (lvm.uf == uf.code && lvm.scope == LocatorScope.UF) {
                        lvm.selectBrazil()
                    } else {
                        lvm.selectUf(uf.code)
                        showCityPicker = true
                        citySearch = ""
                    }
                }
            }
        }

        // Cidades do estado selecionado
        if (lvm.uf != null) {
            val cities = remember(lvm.uf, citySearch) {
                val base = BrazilGeo.citiesOf(lvm.uf!!)
                if (citySearch.isBlank()) base
                else base.filter { it.name.lowercase().contains(citySearch.lowercase()) }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BasicTextField(
                    value = citySearch,
                    onValueChange = { citySearch = it },
                    singleLine = true,
                    textStyle = TextStyle(color = g.ink, fontSize = 13.sp),
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(g.inputBg)
                        .border(1.dp, g.line, RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    decorationBox = { inner ->
                        if (citySearch.isEmpty()) Text("Filtrar município…", color = g.muted, fontSize = 13.sp)
                        inner()
                    },
                )
            }
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                item {
                    MiniChip(
                        "Todo o estado",
                        selected = lvm.scope == LocatorScope.UF && lvm.cityId == null,
                        g = g,
                    ) { lvm.selectUf(lvm.uf!!) }
                }
                items(cities) { city ->
                    MiniChip(
                        city.name,
                        selected = lvm.cityId == city.id,
                        g = g,
                    ) { lvm.selectCity(city.id, city.uf) }
                }
            }
        }

        // Painel de filtros (canais, gratuito, ordenação)
        AnimatedVisibility(lvm.filtersExpanded) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(g.card)
                    .border(1.dp, g.line, RoundedCornerShape(14.dp))
                    .padding(12.dp),
            ) {
                Text("Canais de acesso", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = g.ink)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ChannelType.entries.forEach { ch ->
                        MiniChip(
                            ch.short,
                            selected = ch.id in lvm.channelIds,
                            g = g,
                        ) { lvm.toggleChannel(ch.id) }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MiniChip(
                        if (lvm.onlyFree) "Só gratuito" else "Todos os preços",
                        selected = lvm.onlyFree,
                        g = g,
                    ) { lvm.onlyFree = !lvm.onlyFree }
                    MiniChip(
                        "Ordenar: ${lvm.sort.label}",
                        selected = false,
                        g = g,
                    ) {
                        lvm.sort = when (lvm.sort) {
                            SortMode.PROXIMIDADE -> SortMode.CONFIABILIDADE
                            SortMode.CONFIABILIDADE -> SortMode.PRECO
                            SortMode.PRECO -> SortMode.PROXIMIDADE
                        }
                    }
                    if (lvm.activeFilterCount > 0) {
                        MiniChip("Limpar filtros", selected = false, g = g) { lvm.clearFilters() }
                    }
                }
            }
        }

        // Resumo leve + quantidade offline
        val offlineCities = remember { com.agon.app.data.insulin.BrazilGeo.cities.size }
        val offlineChannels = ChannelType.entries.size
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "${result.points.size} locais · ${result.citiesCovered} cidades · ${result.matchedProducts.size} insulinas",
                fontSize = 12.sp, color = g.muted, modifier = Modifier.weight(1f),
            )
        }
        Text(
            "Base offline: $offlineCities municípios · $offlineChannels canais",
            fontSize = 11.sp, color = g.muted,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 0.dp),
        )
        if (result.points.size > MAX_VISIBLE) {
            Text(
                "Mostrando $MAX_VISIBLE de ${result.points.size}. Refine por estado ou município.",
                fontSize = 11.sp, color = g.orange,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
            )
        }

        LazyColumn(
            state = rememberLazyListState(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f),
        ) {
            // —— Locais reais com endereço (quando município selecionado) ——
            if (lvm.cityId != null) {
                item {
                    Text(
                        "Locais reais próximos",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = g.ink,
                        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp),
                    )
                    Text(
                        "Farmácias, UBS e hospitais com endereço do mapa (OpenStreetMap). Confirme no local se a insulina desejada está disponível.",
                        fontSize = 12.sp,
                        color = g.muted,
                        lineHeight = 16.sp,
                    )
                }
                if (realLoading && realPlaces.isEmpty()) {
                    item {
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = g.violet)
                            Spacer(Modifier.width(10.dp))
                            Text("Buscando farmácias próximas…", color = g.muted, fontSize = 13.sp)
                        }
                    }
                }
                if (realError != null && realPlaces.isEmpty()) {
                    item {
                        Text(realError ?: "", color = g.orange, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
                    }
                }
                items(realPlaces, key = { "real-" + it.id }) { place ->
                    RealPlaceCard(place = place, g = g)
                }
                item {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Canais de acesso (orientação por tipo)",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = g.ink,
                        modifier = Modifier.padding(top = 8.dp, bottom = 2.dp),
                    )
                    Text(
                        "Indica onde esse tipo de insulina costuma ser dispensada (SUS, Farmácia Popular, CEAF ou rede privada).",
                        fontSize = 12.sp,
                        color = g.muted,
                        lineHeight = 16.sp,
                    )
                }
            } else {
                item {
                    Text(
                        "Dica: selecione um estado e um município para ver farmácias e UBS com endereço real.",
                        fontSize = 12.sp,
                        color = g.orange,
                        modifier = Modifier.padding(vertical = 6.dp),
                        lineHeight = 16.sp,
                    )
                }
            }

            if (visiblePoints.isEmpty() && lvm.cityId == null) {
                item {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "Nenhum ponto encontrado.\nAmplie o escopo ou mude a insulina/filtros.",
                            color = g.muted, fontSize = 14.sp, lineHeight = 20.sp,
                        )
                    }
                }
            }
            items(visiblePoints, key = { it.id }) { point ->
                SupplyPointCard(
                    point = point,
                    products = result.matchedProducts.filter { it.id in point.productIds },
                    selected = selectedPoint?.id == point.id,
                    onClick = { selectedPoint = if (selectedPoint?.id == point.id) null else point },
                    g = g,
                )
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}


@Composable
private fun RealPlaceCard(
    place: HealthPlace,
    g: com.agon.app.ui.theme.GlucoColors,
) {
    val context = LocalContext.current
    val accent = when (place.kind) {
        PlaceKind.FARMACIA -> g.green
        PlaceKind.UBS -> g.blue
        PlaceKind.HOSPITAL -> g.red
        PlaceKind.CLINICA -> g.violet
    }
    fun openMaps() {
        val uri = if (place.lat != 0.0 && place.lon != 0.0) {
            Uri.parse("geo:${place.lat},${place.lon}?q=${place.lat},${place.lon}(${Uri.encode(place.name)})")
        } else {
            Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode("${place.name} ${place.address}"))
        }
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
    }
    fun dial() {
        if (place.phone.isBlank()) return
        runCatching { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${place.phone}"))) }
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(g.card)
            .border(1.dp, g.line, RoundedCornerShape(14.dp))
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    when (place.kind) {
                        PlaceKind.FARMACIA -> Icons.Default.LocalPharmacy
                        PlaceKind.UBS -> Icons.Default.LocalHospital
                        else -> Icons.Default.MedicalServices
                    },
                    null,
                    tint = accent,
                    modifier = Modifier.size(18.dp),
                )
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(place.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = g.ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(place.kind.label, fontSize = 12.sp, color = accent, fontWeight = FontWeight.Medium)
            }
            if (place.distanceKm > 0) {
                Text(String.format("%.1f km", place.distanceKm), fontSize = 11.sp, color = g.muted)
            }
        }
        if (place.address.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(place.address, fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
        }
        if (place.phone.isNotBlank() || place.hours.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            if (place.phone.isNotBlank()) {
                Text("Tel: ${place.phone}", fontSize = 12.sp, color = g.muted)
            }
            if (place.hours.isNotBlank()) {
                Text(place.hours, fontSize = 12.sp, color = g.muted)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "Abrir no mapa",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(g.violet)
                    .clickable { openMaps() }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            )
            if (place.phone.isNotBlank()) {
                Text(
                    "Ligar",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = g.violet,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, g.violet, RoundedCornerShape(10.dp))
                        .clickable { dial() }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                )
            }
        }
    }
}

@Composable
private fun MiniChip(
    label: String,
    selected: Boolean,
    g: com.agon.app.ui.theme.GlucoColors,
    onClick: () -> Unit,
) {
    Text(
        label,
        fontSize = 12.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        color = if (selected) Color.White else g.ink,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) g.violet else g.card)
            .border(1.dp, if (selected) g.violet else g.line, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp),
    )
}

@Composable
private fun SupplyPointCard(
    point: SupplyPoint,
    products: List<com.agon.app.data.insulin.InsulinProduct>,
    selected: Boolean,
    onClick: () -> Unit,
    g: com.agon.app.ui.theme.GlucoColors,
) {
    val context = LocalContext.current
    val channel = point.channel
    val icon: ImageVector = when (channel) {
        ChannelType.FARMACIA_POPULAR -> Icons.Default.LocalPharmacy
        ChannelType.ATENCAO_BASICA -> Icons.Default.LocalHospital
        ChannelType.CEAF -> Icons.Default.MedicalServices
        ChannelType.PRIVADA -> Icons.Default.LocalPharmacy
    }
    val accent = when (channel.priceTier) {
        PriceTier.GRATUITO, PriceTier.GRATUITO_PROCESSO -> g.green
        PriceTier.PMC_CMED -> g.blue
    }
    val primaryProduct = products.firstOrNull()
    val category = primaryProduct?.let { InsulinCatalog.categoryById(it.categoryId) }

    fun openUrl(url: String) {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }
    fun dial(phone: String) {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
        }
    }

    // Busca do estabelecimento no Google Maps (cidade + tipo), centrado nas coordenadas
    fun mapsSearchUrl(): String {
        val place = when (channel) {
            ChannelType.FARMACIA_POPULAR ->
                "Farmácia Popular Aqui Tem ${point.city.name} ${point.city.uf}"
            ChannelType.ATENCAO_BASICA ->
                "UBS farmácia ${point.city.name} ${point.city.uf}"
            ChannelType.CEAF ->
                "Farmácia CEAF ${point.city.name} ${point.city.uf}"
            ChannelType.PRIVADA ->
                "farmácia drogaria ${point.city.name} ${point.city.uf}"
        }
        val q = Uri.encode(place)
        // Abre a busca do estabelecimento centrada nas coordenadas da cidade
        return "https://www.google.com/maps/search/$q/@${point.city.lat},${point.city.lon},14z"
    }

    // Site / diretório para achar o estabelecimento (não página genérica fora do ar)
    fun establishmentFindUrl(): String {
        val cityUf = Uri.encode("${point.city.name} ${point.city.uf}")
        return when (channel) {
            ChannelType.FARMACIA_POPULAR ->
                // Busca Google do credenciado no município (painel MS costuma falhar)
                "https://www.google.com/search?q=" + Uri.encode("Aqui Tem Farmácia Popular ${point.city.name} ${point.city.uf} endereço")
            ChannelType.ATENCAO_BASICA ->
                "https://www.google.com/search?q=" + Uri.encode("UBS ${point.city.name} ${point.city.uf} farmácia endereço telefone")
            ChannelType.CEAF ->
                "https://www.google.com/search?q=" + Uri.encode("Farmácia CEAF ${point.city.uf} ${point.city.name} endereço")
            ChannelType.PRIVADA ->
                "https://www.google.com/search?q=" + Uri.encode("farmácia ${point.city.name} ${point.city.uf} insulina endereço")
        }
    }

    fun establishmentLabel(): String = when (channel) {
        ChannelType.FARMACIA_POPULAR -> "Buscar Farmácia Popular"
        ChannelType.ATENCAO_BASICA -> "Buscar UBS / farmácia"
        ChannelType.CEAF -> "Buscar farmácia CEAF"
        ChannelType.PRIVADA -> "Buscar farmácia"
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(g.card)
            .border(1.dp, if (selected) g.violet else g.line, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, null, tint = accent, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(channel.short, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = g.ink)
                Text("${point.city.name} — ${point.city.uf}", fontSize = 12.sp, color = g.muted)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    channel.priceTier.label.substringBefore(" —").substringBefore(" pelo"),
                    fontSize = 11.sp, fontWeight = FontWeight.Medium, color = accent,
                )
                if (point.distanceKm > 0) {
                    Text(String.format("%.0f km", point.distanceKm), fontSize = 11.sp, color = g.muted)
                }
            }
        }

        AnimatedVisibility(selected) {
            Column(Modifier.padding(top = 12.dp)) {
                // Endereço em destaque
                Text("Endereço / como encontrar", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = g.ink)
                Spacer(Modifier.height(4.dp))
                Text(
                    point.addressHint,
                    fontSize = 14.sp,
                    color = g.ink,
                    lineHeight = 20.sp,
                    fontWeight = FontWeight.Medium,
                )
                Text(point.coverage, fontSize = 12.sp, color = g.muted, modifier = Modifier.padding(top = 4.dp))
                Spacer(Modifier.height(10.dp))

                // Bloco de produto
                if (primaryProduct != null) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(g.inputBg)
                            .padding(12.dp),
                    ) {
                        Text("Princípio ativo: ${primaryProduct.activeIngredient}", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        Text("Marca/fabricante: ${primaryProduct.manufacturer}", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        if (category != null) {
                            Text("Categoria oficial: ${category.name}", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        }
                        val apres = primaryProduct.presentations.joinToString(", ")
                        val conc = primaryProduct.concentrations.joinToString(", ")
                        Text("Apresentações: $apres ($conc)", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(primaryProduct.publicNote, fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        if (category != null) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Início ${category.onset} · pico ${category.peak} · duração ${category.duration}",
                                fontSize = 12.sp, fontWeight = FontWeight.Medium, color = g.green,
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }

                Text("Documentos e condições para retirada", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = g.ink)
                Spacer(Modifier.height(6.dp))
                point.conditions.forEach { c ->
                    Text("• $c", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                }

                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("✓  ", fontSize = 14.sp, color = g.green, fontWeight = FontWeight.Bold)
                    Text("Como achar o estabelecimento", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = g.ink)
                }
                Text(
                    "A base orienta o canal de acesso no município. Use os botões abaixo para buscar o estabelecimento em ${point.city.name}/${point.city.uf} ou ligar no Disque Saúde.",
                    fontSize = 12.sp, color = g.muted, lineHeight = 16.sp,
                )

                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionBtn(
                        label = establishmentLabel(),
                        filled = true,
                        g = g,
                        modifier = Modifier.weight(1f),
                    ) { openUrl(establishmentFindUrl()) }
                    ActionBtn(
                        label = "Disque Saúde 136",
                        filled = false,
                        g = g,
                        modifier = Modifier.weight(1f),
                    ) { dial("136") }
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    "Fechar",
                    fontSize = 14.sp, fontWeight = FontWeight.Medium, color = g.green,
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .clickable(onClick = onClick)
                        .padding(8.dp),
                )
            }
        }
    }
}

@Composable
private fun ActionBtn(
    label: String,
    filled: Boolean,
    g: com.agon.app.ui.theme.GlucoColors,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(24.dp))
            .background(if (filled) g.green else Color.Transparent)
            .border(1.dp, if (filled) g.green else g.line, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = if (filled) Color.White else g.ink,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
