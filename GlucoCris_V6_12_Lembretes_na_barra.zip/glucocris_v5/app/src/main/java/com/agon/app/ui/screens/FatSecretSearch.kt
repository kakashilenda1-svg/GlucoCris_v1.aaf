package com.agon.app.ui.screens

import com.agon.app.BuildConfig
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Busca alimentos no FatSecret pelo proxy (Cloudflare Worker, rota /fatsecret).
 * A chave do FatSecret fica so no servidor; o app so conhece o endereco do proxy.
 * Nunca lanca excecao: em qualquer falha devolve lista vazia.
 */
suspend fun searchFatSecret(query: String): List<FoodItem> = withContext(Dispatchers.IO) {
    val base = BuildConfig.TAVILY_PROXY_URL.trim().trimEnd('/')
    if (base.isBlank() || query.isBlank()) return@withContext emptyList()
    try {
        val c = (URL("$base/fatsecret").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = 6000
            readTimeout = 9000
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "GlucoCris (Android; nutrition search)")
            val tok = BuildConfig.TAVILY_APP_TOKEN.trim()
            if (tok.isNotBlank()) setRequestProperty("X-App-Token", tok)
        }
        c.outputStream.use { it.write(JSONObject().put("query", query).toString().toByteArray(Charsets.UTF_8)) }
        if (c.responseCode != 200) return@withContext emptyList()
        val arr = JSONObject(c.inputStream.bufferedReader().readText()).optJSONArray("items")
            ?: return@withContext emptyList()
        val out = mutableListOf<FoodItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val name = o.optString("name", "")
            if (name.isBlank()) continue
            val brand = o.optString("brand", "")
            val grams = o.optDouble("grams", 100.0).let { if (it > 0) it else 100.0 }
            val kcal = o.optDouble("kcal", 0.0)
            out.add(
                FoodItem(
                    id = "fs-" + o.optString("id", name),
                    name = name,
                    brand = brand,
                    serving = o.optString("serving", "100 g").ifBlank { "100 g" },
                    servingGrams = grams,
                    kcal = kcal,
                    kj = kcal * 4.184,
                    carbs = o.optDouble("carbs", 0.0),
                    protein = o.optDouble("protein", 0.0),
                    fat = o.optDouble("fat", 0.0),
                    source = "FatSecret",
                    sourceKey = "fatsecret",
                    isGeneric = o.optBoolean("generic", brand.isBlank()),
                    reliability = "media",
                )
            )
        }
        out
    } catch (_: Exception) {
        emptyList()
    }
}
