import java.util.Properties

val localProps = Properties().apply {
    val f = rootProject.file("local.properties")
    if (f.exists()) f.inputStream().use { load(it) }
}
// gemini.api.key NAO e mais embutido no APK. A chave fica so no Cloudflare Worker (segredo GEMINI_API_KEY).
// Nao lemos nem embutimos a chave no BuildConfig.
// Pesquisa na web (Tavily): o APK NÃO recebe a chave da Tavily. Recebe só o endereço do proxy (backend/tavily-proxy),
// que guarda a chave como segredo do servidor. Vem do local.properties (tavily.proxy.url) ou da variável TAVILY_PROXY_URL (CI).
// Padrão: proxy Cloudflare Workers do Gluco Cris (só o endereço público; a chave da Tavily fica no servidor).
val defaultTavilyProxyUrl = "https://gluco-cris-tavily-proxy.alanholivier.workers.dev"
val tavilyProxyUrl: String = (localProps.getProperty("tavily.proxy.url", "") ?: "").ifBlank { System.getenv("TAVILY_PROXY_URL") ?: "" }.ifBlank { defaultTavilyProxyUrl }.trim()
// Token opcional do app para o proxy (freio contra uso por terceiros; não é segredo forte, pois vai no APK).
val tavilyAppToken: String = (localProps.getProperty("tavily.app.token", "") ?: "").ifBlank { System.getenv("TAVILY_APP_TOKEN") ?: "" }.trim()
val geminiModel: String = localProps.getProperty("gemini.model", "gemini-3.8-flash") ?: "gemini-3.8-flash"

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("org.jetbrains.kotlin.plugin.serialization")
    id("com.google.gms.google-services")
}

android {
    namespace = "com.agon.app"
    compileSdk = 36
    buildToolsVersion = "36.0.0"

    defaultConfig {
        buildConfigField("String", "TAVILY_PROXY_URL", "\"$tavilyProxyUrl\"")
        buildConfigField("String", "TAVILY_APP_TOKEN", "\"$tavilyAppToken\"")
        buildConfigField("String", "GEMINI_MODEL", "\"$geminiModel\"")
        applicationId = "com.agon.app"
        minSdk = 24
        targetSdk = 36
        // Cada build do GitHub Actions ganha um versionCode maior (1000 + numero da execucao),
        // para o APK novo sempre instalar POR CIMA do anterior, sem desinstalar (mesma assinatura debug.keystore).
        val ciRun = System.getenv("GITHUB_RUN_NUMBER")?.toIntOrNull()
        versionCode = if (ciRun != null) 1000 + ciRun else 81
        versionName = "1.29.2-v6.17-tela-cheia"
        // APK universal: um unico arquivo com arm64-v8a (celulares) + x86_64 (emuladores).
        // armeabi-v7a nao entra porque a biblioteca de IA local (llama.cpp) so tem binarios 64 bits.
        ndk {
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }

    signingConfigs {
        getByName("debug") {
            storeFile = file("${rootProject.projectDir}/debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("debug")
        }
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    // Evita falha de empacotamento por arquivos duplicados entre bibliotecas (ML Kit, Firebase, llama.cpp)
    packaging {
        resources {
            excludes += setOf(
                "/META-INF/{AL2.0,LGPL2.1}",
                "/META-INF/INDEX.LIST",
                "/META-INF/DEPENDENCIES",
                "/META-INF/LICENSE*",
                "/META-INF/NOTICE*",
            )
        }
        jniLibs {
            pickFirsts += setOf("**/libc++_shared.so")
        }
    }
}

kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    // ATENCAO: Compose 1.12+ (BOM 2026.08.00 em diante) exige compileSdk 37 + AGP 9.1.1.
    // Enquanto o projeto estiver em AGP 8.x / compileSdk 36, use no maximo a BOM 2026.04.01 (Compose 1.11).
    implementation(platform("androidx.compose:compose-bom:2026.04.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-graphics")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("androidx.compose.ui:ui-tooling-preview")

    implementation("androidx.activity:activity-compose:1.12.2")
    implementation("androidx.activity:activity-ktx:1.12.2")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.10.0")
    implementation("androidx.lifecycle:lifecycle-runtime-compose:2.10.0")

    implementation("androidx.navigation:navigation-compose:2.9.7")

    implementation("androidx.core:core-ktx:1.15.0")

    // Entrar com digital ou rosto (BiometricPrompt)
    implementation("androidx.biometric:biometric:1.1.0")
    // BiometricPrompt precisa de uma FragmentActivity (a MainActivity passa a herdar dela)
    implementation("androidx.fragment:fragment:1.8.5")

    implementation("io.coil-kt.coil3:coil-compose:3.3.0")
    implementation("io.coil-kt.coil3:coil-network-okhttp:3.3.0")

    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.9.0")

    implementation("androidx.datastore:datastore-preferences:1.2.0")

    // Download da IA local em segundo plano (continua com o app fechado)
    implementation("androidx.work:work-runtime-ktx:2.10.0")

    implementation("org.osmdroid:osmdroid-android:6.1.20")

    // Scanner de código de barras
    implementation("androidx.camera:camera-camera2:1.4.1")
    implementation("androidx.camera:camera-lifecycle:1.4.1")
    implementation("androidx.camera:camera-view:1.4.1")
    // ListenableFuture (retorno de ProcessCameraProvider.getInstance) precisa estar no classpath de compilação
    implementation("com.google.guava:guava:33.3.1-android")
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
    implementation("com.google.mlkit:image-labeling:17.0.9")

    // IA local (Cris IA): llama.cpp (llamacpp-kotlin) + OCR offline (ML Kit)
    implementation("io.github.ljcamargo:llamacpp-kotlin:0.4.0")
    implementation("com.google.mlkit:text-recognition:16.0.1")

    // Login com Google
    implementation("com.google.android.gms:play-services-auth:21.3.0")

    // Firebase (plano gratuito Spark): Authentication + Firestore. Sem Analytics e sem serviços pagos.
    implementation(platform("com.google.firebase:firebase-bom:34.0.0"))
    implementation("com.google.firebase:firebase-auth")
    implementation("com.google.firebase:firebase-firestore")

    debugImplementation("androidx.compose.ui:ui-tooling")

    // Testes de unidade da lógica de status/fallback da Cris (JVM puro, sem serviços externos)
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.10.2")
}
