package com.agon.app.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.R
import com.agon.app.Routes
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.formatDateTime
import com.agon.app.data.formatLongDate
import com.agon.app.data.greeting
import com.agon.app.data.rangeStatus
import com.agon.app.data.statusLabel
import com.agon.app.data.toMgDl
import com.agon.app.data.weekdayLong
import com.agon.app.love.LOVE_PHONE_DISPLAY
import com.agon.app.love.LOVE_PHONE_TEL
import com.agon.app.love.MAIN_LOVE_MESSAGE
import com.agon.app.love.SAMU_TEL
import com.agon.app.love.openDialer
import com.agon.app.love.openWhatsApp
import com.agon.app.love.phraseForToday
import com.agon.app.ui.components.ActionButton
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GlucoseChart
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.components.tourTarget
import com.agon.app.ui.theme.glucoColors
import kotlin.math.roundToInt

@Composable
fun HomeScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val context = LocalContext.current
    val settings = data.settings
    var phrase by remember { mutableStateOf("") }
    var showMood by remember { mutableStateOf(false) }
    var waterBarVisible by remember { mutableStateOf(true) }
    val scrollWatcher = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -6f) waterBarVisible = false
                else if (available.y > 6f) waterBarVisible = true
                return Offset.Zero
            }
        }
    }
    LaunchedEffect(Unit) { phrase = phraseForToday(context) }
    if (showMood) {
        MoodSheet(settings.mood, onDismiss = { showMood = false }) { id ->
            vm.updateSettings { it.copy(mood = id, moodAt = System.currentTimeMillis()) }
            showMood = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val latest = data.glucose.maxByOrNull { it.at }
    val mg = latest?.let { toMgDl(it.value, it.unit) }
    val status = mg?.let { rangeStatus(it, settings.targetLow, settings.targetHigh) }
    val statusColor = when (status) {
        "ok" -> g.green
        "low" -> g.orange
        "high" -> g.red
        else -> g.muted
    }

    val weekMsTop = 7L * 24 * 60 * 60 * 1000
    val sinceTop = System.currentTimeMillis() - weekMsTop
    val weekGCount = data.glucose.count { it.at >= sinceTop }
    val weekICount = data.insulin.count { it.at >= sinceTop }
    // Tempo no alvo unificado (mesma regra do Painel de padrões / Estatísticas; ignora demo)
    val tirPct: Int? = com.agon.app.insights.Insights.timeInRangePct(
        data, days = 7, low = settings.targetLow, high = settings.targetHigh,
    )
    val firstName = com.agon.app.data.firstName(settings.displayName).ifBlank { "Maria" }
    val greetText = "${greeting()}, $firstName!"
    val isBlue = settings.blueTheme
    val mood = com.agon.app.data.moodOf(settings.mood)
    val latestLine = latest?.let { "${GLUCOSE_CONTEXT_LABEL[it.context] ?: it.context} - ${formatDateTime(it.at)}" } ?: ""

    val bgBrush = if (isBlue) {
        Brush.verticalGradient(listOf(Color(0xFF031636), Color(0xFF04132C), Color(0xFF020B1E)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFF0B0126), Color(0xFF070018), Color(0xFF050014)))
    }

    BoxWithConstraints(Modifier.fillMaxSize().nestedScroll(scrollWatcher).background(bgBrush)) {
        // A caixa agora vai até o topo da tela (atrás da barra de status): desconta a barra para o layout continuar igual.
        val viewportH = maxHeight - WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            HomeTop(
                pal = if (isBlue) BluePalette else PurplePalette,
                viewportH = viewportH,
                phrase = phrase,
                greetText = greetText,
                mg = mg?.roundToInt(),
                statusText = status?.let { statusLabel(it) } ?: "",
                dateText = latest?.let { formatDateTime(it.at) } ?: "",
                weekG = weekGCount,
                weekI = weekICount,
                tirPct = tirPct,
                moodEmoji = mood?.emoji,
                moodLabel = mood?.label,
                onProfile = { nav.navigate(Routes.PROFILE) },
                onSwitch = { vm.updateSettings { it.copy(blueTheme = !it.blueTheme) } },
                onHelp = { nav.navigate(Routes.HELP_CENTER) },
                onMood = { showMood = true },
                onLast = { nav.navigate(Routes.glucoseForm(null)) },
                onGlucose = { Routes.goTab(nav, Routes.GLUCOSE) },
                onInsulin = { Routes.goTab(nav, Routes.INSULIN) },
            )

            // ---- Abaixo da dobra (rolável): o conteúdo anterior do app, sem alterações ----
            // Atalho da Cris IA logo abaixo da mensagem (mesma organização nos dois temas).
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(
                        Brush.horizontalGradient(
                            if (isBlue) listOf(Color(0xFF0A47A6), Color(0xFF1A86F5)) else listOf(Color(0xFF5D12B9), Color(0xFFB51BFF)),
                        ),
                    )
                    .clickable { nav.navigate(Routes.CRIS_IA) }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Image(
                        painter = painterResource(if (isBlue) R.drawable.blue_cris_head else R.drawable.robot_pink),
                        contentDescription = null,
                        modifier = Modifier.size(30.dp).clip(CircleShape),
                        contentScale = ContentScale.Fit,
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("Conversar com a Cris IA", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Text("Sua assistente de cuidado", color = Color.White.copy(alpha = 0.88f), fontSize = 12.sp)
                }
                Text("›", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 12.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(g.red)
                .clickable { openDialer(context, SAMU_TEL) }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.LocalHospital, null, tint = Color.White)
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text(" Emergência — SAMU 192", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text(
                    "Abre o discador com 192. Não aciona o atendimento sozinho e não garante que a chamada seja completada.",
                    color = Color.White.copy(alpha = 0.92f),
                    fontSize = 12.sp,
                )
            }
        }

        // Resumo semanal rápido
        run {
            val weekMs = 7L * 24 * 60 * 60 * 1000
            val since = System.currentTimeMillis() - weekMs
            val weekG = data.glucose.filter { it.at >= since }
            val weekI = data.insulin.filter { it.at >= since }
            val low = settings.targetLow
            val high = settings.targetHigh
            val inRange = weekG.count {
                val mgv = toMgDl(it.value, it.unit)
                mgv >= low && mgv <= high
            }
            val pct = if (weekG.isNotEmpty()) inRange * 100 / weekG.size else null
            GCard(Modifier.padding(top = 12.dp).clickable { nav.navigate(Routes.CRIS_IA) }) {
                Text("Resumo dos últimos 7 dias", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                Text(
                    if (weekG.isEmpty() && weekI.isEmpty()) "Sem registros nesta semana. Toque para falar com a Cris IA."
                    else "Glicemias: ${weekG.size}" + (pct?.let { " · $it% na meta do app" } ?: "") + " · Insulinas: ${weekI.size}",
                    color = g.muted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 4.dp),
                )
                Text("Abrir Cris IA para consulta em 1 minuto →", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }

        SectionTitle("Evolução", "Ver estatísticas") { nav.navigate(Routes.STATS) }
        GCard { GlucoseChart(data.glucose, settings.targetLow, settings.targetHigh) }

        val active = data.reminders.filter { it.enabled }.sortedWith(compareBy({ it.hour }, { it.minute }))
        SectionTitle("Próximo lembrete", "Ver todos") { Routes.goTab(nav, Routes.REMINDERS) }
        GCard {
            if (active.isEmpty()) {
                Text("Nenhum lembrete ativo.", color = g.muted, fontSize = 14.sp)
            } else {
                active.take(3).forEach { r ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(r.title, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Text(
                            "${com.agon.app.data.formatClock(r.hour, r.minute)} · ${com.agon.app.data.daysLabel(r.days)}",
                            color = g.muted,
                            fontSize = 12.sp,
                        )
                        Text(
                            (if (r.kind == "glicose") "Medição de glicose" else "Aplicação de insulina") +
                                if (r.notes.isNotEmpty()) " · ${r.notes}" else "",
                            color = g.violetDeep,
                            fontSize = 12.sp,
                        )
                    }
                }
            }
        }

        SectionTitle("Histórico resumido", "Ver todos") { Routes.goTab(nav, Routes.HISTORY) }
        GCard {
            val recent = data.glucose.sortedByDescending { it.at }.take(4)
            if (recent.isEmpty()) {
                Text("Sem registros.", color = g.muted, modifier = Modifier.padding(12.dp))
            } else {
                recent.forEach { e ->
                    val v = toMgDl(e.value, e.unit)
                    val st = rangeStatus(v, settings.targetLow, settings.targetHigh)
                    val c = when (st) { "ok" -> g.green; "low" -> g.orange; else -> g.red }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { nav.navigate(Routes.glucoseForm(e.id)) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(v.roundToInt().toString(), color = c, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.padding(end = 10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(GLUCOSE_CONTEXT_LABEL[e.context] ?: e.context, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${com.agon.app.data.formatDate(e.at)} · ${com.agon.app.data.formatTime(e.at)}", color = g.muted, fontSize = 12.sp)
                        }
                        Text(statusLabel(st), color = c, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(64.dp))
        }

        // Barra de hidratação fixa sobre a tela (os dois temas).
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 10.dp, end = 10.dp, bottom = 12.dp)) {
            WaterMiniBar(
                visible = waterBarVisible,
                onOpenFull = { nav.navigate(Routes.WATER) },
                modifier = Modifier.tourTarget("home_water"),
            )
        }
    }
}

// ───────────────────────── Auxiliares visuais da tela inicial ─────────────────────────

/** Deixa o conteúdo [extra] dp mais largo de cada lado do padding da tela (os cartões da referência encostam mais na borda). */
private fun Modifier.bleed(extra: Dp): Modifier = this.layout { measurable, constraints ->
    val e = extra.roundToPx()
    val w = constraints.maxWidth + 2 * e
    val p = measurable.measure(constraints.copy(minWidth = w, maxWidth = w))
    layout(constraints.maxWidth, p.height) { p.place(-e, 0) }
}

/** Texto de uma linha que diminui a fonte até caber na largura disponível. */
@Composable
private fun FitOneLine(
    text: String,
    color: Color,
    maxSp: Float,
    minSp: Float,
    modifier: Modifier = Modifier,
    weight: FontWeight? = null,
    textAlign: TextAlign? = null,
) {
    val measurer = rememberTextMeasurer()
    BoxWithConstraints(modifier) {
        val maxW = constraints.maxWidth
        var sp = maxSp
        while (sp > minSp) {
            val w = measurer.measure(text = text, style = TextStyle(fontSize = sp.sp, fontWeight = weight), softWrap = false, maxLines = 1).size.width
            if (w <= maxW) break
            sp -= 0.5f
        }
        Text(text, color = color, fontSize = sp.sp, fontWeight = weight, maxLines = 1, softWrap = false, textAlign = textAlign)
    }
}

private fun DrawScope.glowStroke(p: Path, c: Color, scale: Float = 1f) {
    val u = 1.dp.toPx() * scale
    drawPath(p, c.copy(alpha = 0.10f), style = Stroke(width = 14f * u, cap = StrokeCap.Round))
    drawPath(p, c.copy(alpha = 0.26f), style = Stroke(width = 7f * u, cap = StrokeCap.Round))
    drawPath(p, c.copy(alpha = 0.95f), style = Stroke(width = 1.6f * u, cap = StrokeCap.Round))
}

/** Cores de um tema da tela inicial. A organização é a mesma; só as cores (e o robô) mudam. */
private class HomePalette(
    val blue: Boolean,
    val waveA: Color, val waveB: Color, val waveGlow: Color,
    val btnFill: List<Color>, val btnBorder: List<Color>, val btnGlow: Color,
    val chevBg: Color, val chevBorder: Color,
    val c1: List<Color>, val c1Border: List<Color>, val c1Glow: Color, val c1Wave: Color,
    val c2: List<Color>, val c2Border: List<Color>, val c2Glow: Color, val c2Wave: Color,
    val c3: List<Color>, val c3Border: List<Color>, val c3Glow: Color, val c3Wave: Color,
    val msg: List<Color>, val msgBorder: List<Color>, val msgGlow: Color,
    val msgTitle: Color, val msgText: Color, val msgPhrase: Color, val msgLabel: Color,
)

private val PurplePalette = HomePalette(
    blue = false,
    waveA = Color(0xFFB65CFF), waveB = Color(0xFFD18CFF), waveGlow = Color(0x66B040FF),
    btnFill = listOf(Color(0xFF6A2BE0), Color(0xFF3A0F9E)), btnBorder = listOf(Color(0xFFD7A8FF), Color(0xFF8A4BFF)), btnGlow = Color(0xFFB51BFF),
    chevBg = Color(0x33200A6A), chevBorder = Color(0xFFB070FF),
    c1 = listOf(Color(0xFF2A3FA8), Color(0xFF18227A), Color(0xFF11185E)), c1Border = listOf(Color(0xFF4F83FF), Color(0xFF7D3BFF)), c1Glow = Color(0xFF4A63FF), c1Wave = Color(0xFF7B5CFF),
    c2 = listOf(Color(0xFF5B24D6), Color(0xFF3A14A8), Color(0xFF2A0C7A)), c2Border = listOf(Color(0xFFC04BFF), Color(0xFF8A2BFF)), c2Glow = Color(0xFFB51BFF), c2Wave = Color(0xFFE08CFF),
    c3 = listOf(Color(0xFF2332A0), Color(0xFF18228A), Color(0xFF111A66)), c3Border = listOf(Color(0xFF5F6BFF), Color(0xFF9B2BFF)), c3Glow = Color(0xFF7A2BFF), c3Wave = Color(0xFF9B5BFF),
    msg = listOf(Color(0xFFF4CCFF), Color(0xFFE6B6FF), Color(0xFFDDA7FF)), msgBorder = listOf(Color(0xFFFFFFFF), Color(0xFFE79BFF)), msgGlow = Color(0xFFFF8BFF),
    msgTitle = Color(0xFF481078), msgText = Color(0xFF2B1055), msgPhrase = Color(0xFF5A1E9E), msgLabel = Color(0xFF7A4FA8),
)

private val BluePalette = HomePalette(
    blue = true,
    waveA = Color(0xFF4FA3FF), waveB = Color(0xFF8CC8FF), waveGlow = Color(0x663A8CFF),
    btnFill = listOf(Color(0xFF2B7BE0), Color(0xFF0F3A9E)), btnBorder = listOf(Color(0xFFA8D0FF), Color(0xFF4B8AFF)), btnGlow = Color(0xFF2E8BFF),
    chevBg = Color(0x330A3A6A), chevBorder = Color(0xFF70B0FF),
    c1 = listOf(Color(0xFF1D5CB8), Color(0xFF12408A), Color(0xFF0C2D68)), c1Border = listOf(Color(0xFF5FA8FF), Color(0xFF1F5FC0)), c1Glow = Color(0xFF2E8BFF), c1Wave = Color(0xFF5CB3FF),
    c2 = listOf(Color(0xFF1E6BD6), Color(0xFF154AA8), Color(0xFF0E3278)), c2Border = listOf(Color(0xFF6CB8FF), Color(0xFF2F7BE8)), c2Glow = Color(0xFF2E8BFF), c2Wave = Color(0xFF8CC8FF),
    c3 = listOf(Color(0xFF16457F), Color(0xFF0F3468), Color(0xFF0B2A5E)), c3Border = listOf(Color(0xFF3F8DE8), Color(0xFF1A4F9C)), c3Glow = Color(0xFF2E8BFF), c3Wave = Color(0xFF5CB3FF),
    msg = listOf(Color(0xFFD6E8FF), Color(0xFFC2DCFF), Color(0xFFB0D0FF)), msgBorder = listOf(Color(0xFFFFFFFF), Color(0xFF9CC8FF)), msgGlow = Color(0xFF8CC8FF),
    msgTitle = Color(0xFF0F2F66), msgText = Color(0xFF12243F), msgPhrase = Color(0xFF1F4F9C), msgLabel = Color(0xFF3F6FB0),
)

/** Ondas neon do cabeçalho. */
private fun DrawScope.headerWaves(pal: HomePalette) {
    val w = size.width
    val u = 1.dp.toPx()
    val c = Offset(w * 0.82f, 150f * u)
    drawCircle(Brush.radialGradient(listOf(pal.waveGlow, Color.Transparent), center = c, radius = 230f * u), radius = 230f * u, center = c)
    val p1 = Path().apply {
        moveTo(w * 0.50f, -40f * u)
        cubicTo(w * 0.58f, 20f * u, w * 0.74f, 60f * u, w * 1.04f, 92f * u)
    }
    glowStroke(p1, pal.waveA)
    val p2 = Path().apply {
        moveTo(-10f * u, 176f * u)
        cubicTo(w * 0.18f, 196f * u, w * 0.40f, 166f * u, w * 0.62f, 200f * u)
        cubicTo(w * 0.80f, 224f * u, w * 0.92f, 206f * u, w * 1.04f, 168f * u)
    }
    glowStroke(p2, pal.waveB)
}

/** Onda decorativa dentro de um cartão (parte de baixo). */
private fun DrawScope.cardWave(color: Color, fromLeft: Float, y0: Float, y1: Float) {
    val w = size.width
    val h = size.height
    val p = Path().apply {
        moveTo(w * fromLeft, h * y0)
        cubicTo(w * (fromLeft + 0.25f), h * (y0 - 0.22f), w * 0.72f, h * (y1 + 0.16f), w * 1.02f, h * y1)
    }
    glowStroke(p, color, 0.55f)
}

@Composable
private fun HomeCircleButton(pal: HomePalette, onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier
            .size(34.dp)
            .shadow(6.dp, CircleShape, clip = false, ambientColor = pal.btnGlow, spotColor = pal.btnGlow)
            .clip(CircleShape)
            .background(Brush.linearGradient(pal.btnFill))
            .border(2.dp, Brush.linearGradient(pal.btnBorder), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun HomeChevron(pal: HomePalette, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(20.dp)
            .clip(CircleShape)
            .background(pal.chevBg)
            .border(1.dp, pal.chevBorder, CircleShape),
        contentAlignment = Alignment.Center,
    ) { Text("›", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.offset(y = (-1).dp)) }
}

@Composable
private fun SparkArrow(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 30.dp, height = 24.dp)) {
        val u = 0.8.dp.toPx()
        val line = Path().apply {
            moveTo(1f * u, 27f * u); lineTo(11f * u, 16f * u); lineTo(18f * u, 21f * u); lineTo(32f * u, 5f * u)
        }
        drawPath(line, color, style = Stroke(width = 3f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
        val head = Path().apply { moveTo(24f * u, 4f * u); lineTo(33f * u, 4f * u); lineTo(33f * u, 13f * u) }
        drawPath(head, color, style = Stroke(width = 3f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
private fun HomeTop(
    pal: HomePalette,
    viewportH: Dp,
    phrase: String,
    greetText: String,
    mg: Int?,
    statusText: String,
    dateText: String,
    weekG: Int,
    weekI: Int,
    tirPct: Int?,
    moodEmoji: String?,
    moodLabel: String?,
    onProfile: () -> Unit,
    onSwitch: () -> Unit,
    onHelp: () -> Unit,
    onMood: () -> Unit,
    onLast: () -> Unit,
    onGlucose: () -> Unit,
    onInsulin: () -> Unit,
) {
    val k = 1f
    val fs = androidx.compose.ui.platform.LocalDensity.current.fontScale.coerceIn(1f, 1.5f)
    fun h(v: Float) = (v * k).dp
    val cardShape = RoundedCornerShape(18.dp)
    val white90 = Color.White.copy(alpha = 0.92f)

    Column(Modifier.fillMaxWidth().drawBehind { headerWaves(pal) }) {
        Spacer(Modifier.height(h(4f)))
        // Cabeçalho
        Row(Modifier.fillMaxWidth().height(34.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Text("GlucoCris", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
                Text("❤️", fontSize = 19.sp)
            }
            Row(Modifier.offset(x = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                HomeCircleButton(pal, onProfile, Modifier.tourTarget("home_profile")) {
                    Icon(Icons.Filled.Person, contentDescription = "Perfil", tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(10.dp))
                HomeCircleButton(pal, onSwitch, Modifier.tourTarget("home_theme")) {
                    Text("⇄", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.width(12.dp))
                HomeCircleButton(pal, onHelp, Modifier.tourTarget("home_help")) {
                    Text("?", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                }
            }
        }

        // Cabeçalho ilustrado
        Row(Modifier.fillMaxWidth().height(h(112f)), verticalAlignment = Alignment.CenterVertically) {
            if (pal.blue) {
                Box(
                    Modifier
                        .size(64.dp)
                        .shadow(6.dp, RoundedCornerShape(16.dp), clip = false, ambientColor = pal.btnGlow, spotColor = pal.btnGlow)
                        .clip(RoundedCornerShape(16.dp))
                        .background(Brush.linearGradient(listOf(Color(0xFF1D5CB8), Color(0xFF0C2D68))))
                        .border(1.dp, Color(0xFF7CC0FF), RoundedCornerShape(16.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    Image(
                        painter = painterResource(R.drawable.blue_cris_head),
                        contentDescription = "Ícone GlucoCris",
                        modifier = Modifier.size(52.dp),
                        contentScale = ContentScale.Fit,
                    )
                }
            } else {
                Image(
                    painter = painterResource(R.drawable.neon_app_robot),
                    contentDescription = "Ícone GlucoCris",
                    modifier = Modifier
                        .size(64.dp)
                        .shadow(6.dp, RoundedCornerShape(16.dp), clip = false, ambientColor = Color(0xFFB51BFF), spotColor = Color(0xFFB51BFF))
                        .clip(RoundedCornerShape(16.dp))
                        .border(1.dp, Color(0xFFC77CFF), RoundedCornerShape(16.dp)),
                    contentScale = ContentScale.Crop,
                )
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text("$greetText 🥰", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 25.sp)
                Text("Você está indo muito bem!", color = Color.White.copy(alpha = 0.92f), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
            if (pal.blue) {
                Image(
                    painter = painterResource(R.drawable.blue_hero_robot),
                    contentDescription = "Cris, o robô azul",
                    modifier = Modifier.size(width = 132.dp, height = h(112f)).offset(x = 6.dp, y = 4.dp),
                    contentScale = ContentScale.Fit,
                    alignment = Alignment.BottomEnd,
                )
            } else {
                Image(
                    painter = painterResource(R.drawable.neon_hero_robot),
                    contentDescription = "Cris segurando um coração",
                    modifier = Modifier.size(h(112f)).offset(x = 6.dp, y = 4.dp),
                    contentScale = ContentScale.Crop,
                )
            }
        }

        Spacer(Modifier.height(12.dp))

        // Linha 1: Última medição | Seu humor
        Row(Modifier.fillMaxWidth().height((158f * fs).dp).bleed(0.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier
                    .weight(1.04f)
                    .fillMaxHeight()
                    .shadow(5.dp, cardShape, clip = false, ambientColor = pal.c1Glow, spotColor = pal.c1Glow)
                    .clip(cardShape)
                    .background(Brush.linearGradient(pal.c1))
                    .drawBehind { cardWave(pal.c1Wave, 0.45f, 0.95f, 0.78f) }
                    .border(2.dp, Brush.linearGradient(pal.c1Border), cardShape)
                    .clickable(onClick = onLast),
            ) {
                Column(Modifier.fillMaxSize().padding(start = 12.dp, end = 10.dp, top = 10.dp, bottom = 10.dp)) {
                    Row(Modifier.height(22.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("💧", fontSize = 16.sp)
                        Spacer(Modifier.width(8.dp))
                        FitOneLine("Última medição", white90, 13f, 10f, Modifier.weight(1f), FontWeight.SemiBold)
                    }
                    if (mg != null) {
                        Row(Modifier.padding(start = 6.dp, top = 2.dp), verticalAlignment = Alignment.Bottom) {
                            Text(mg.toString(), color = Color(0xFF2BE36F), fontWeight = FontWeight.ExtraBold, fontSize = 36.sp, lineHeight = 40.sp)
                            Text("mg/dL", color = Color.White.copy(alpha = 0.78f), fontSize = 14.sp, modifier = Modifier.padding(start = 5.dp, bottom = 6.dp))
                        }
                        Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(18.dp).clip(CircleShape).background(Color(0xFF2BE36F)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Check, null, tint = Color(0xFF0B1A2E), modifier = Modifier.size(13.dp))
                            }
                            Spacer(Modifier.width(8.dp))
                            Text(statusText, color = Color(0xFF2BE36F), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                        Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Outlined.AccessTime, null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(13.dp))
                            Spacer(Modifier.width(7.dp))
                            FitOneLine(dateText, Color.White.copy(alpha = 0.92f), 11f, 8f, Modifier.weight(1f))
                        }
                    } else {
                        Spacer(Modifier.height(18.dp))
                        Text("Sem medição", color = Color.White.copy(alpha = 0.85f), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Toque para registrar", color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
                if (mg != null) SparkArrow(Color(0xFF2BE36F), Modifier.align(Alignment.TopEnd).padding(end = 12.dp, top = 40.dp))
            }

            Column(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .shadow(5.dp, cardShape, clip = false, ambientColor = pal.c2Glow, spotColor = pal.c2Glow)
                    .clip(cardShape)
                    .background(Brush.linearGradient(pal.c2))
                    .drawBehind { cardWave(pal.c2Wave, 0.0f, 0.93f, 0.80f) }
                    .border(2.dp, Brush.linearGradient(pal.c2Border), cardShape)
                    .clickable(onClick = if (pal.blue) onGlucose else onMood)
                    .padding(horizontal = 10.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                if (pal.blue) {
                    // Tema azul: TIR no lugar do humor
                    Row(Modifier.height(22.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🎯", fontSize = 16.sp)
                        Spacer(Modifier.width(7.dp))
                        Text("Tempo no alvo", color = white90, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text(
                            if (tirPct != null) "$tirPct%" else "—",
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 36.sp,
                        )
                    }
                    Text(
                        "últimos 7 dias",
                        color = Color.White.copy(alpha = 0.75f),
                        fontWeight = FontWeight.Medium,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(bottom = 4.dp),
                    )
                } else {
                    // Tema rosa: mantém humor
                    Row(Modifier.height(22.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("💜", fontSize = 16.sp)
                        Spacer(Modifier.width(7.dp))
                        Text("Seu humor", color = white90, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                    }
                    Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                        Text(moodEmoji ?: "😊", fontSize = 40.sp)
                    }
                    Text(
                        moodLabel ?: "Toque aqui",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(bottom = 4.dp),
                    )
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Linha 2: Glicemias | Insulinas
        Row(Modifier.fillMaxWidth().height((98f * fs).dp).bleed(0.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            @Composable
            fun SmallCard(emoji: String, title: String, value: Int, modifier: Modifier, onClick: () -> Unit) {
                Box(
                    modifier
                        .fillMaxHeight()
                        .shadow(5.dp, cardShape, clip = false, ambientColor = pal.c3Glow, spotColor = pal.c3Glow)
                        .clip(cardShape)
                        .background(Brush.linearGradient(pal.c3))
                        .drawBehind { cardWave(pal.c3Wave, 0.30f, 0.98f, 0.55f) }
                        .border(2.dp, Brush.linearGradient(pal.c3Border), cardShape)
                        .clickable(onClick = onClick),
                ) {
                    Column(Modifier.padding(start = 12.dp, end = 8.dp, top = 10.dp)) {
                        Row(Modifier.height(20.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(emoji, fontSize = 15.sp)
                            Spacer(Modifier.width(7.dp))
                            FitOneLine(title, white90, 12f, 9f, Modifier.weight(1f), FontWeight.SemiBold)
                        }
                        Text(
                            value.toString(),
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 30.sp,
                            lineHeight = 34.sp,
                            modifier = Modifier.padding(start = 5.dp, top = 8.dp),
                        )
                    }
                    HomeChevron(pal, Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = 10.dp))
                }
            }
            SmallCard("📊", "Glicemias (7 dias)", weekG, Modifier.weight(1f), onGlucose)
            if (pal.blue) {
                SmallCard("💉", "Insulinas (7 dias)", weekI, Modifier.weight(1f), onInsulin)
            } else {
                // Tema rosa: TIR no lugar de Insulinas
                Box(
                    Modifier
                        .weight(1f)
                        .fillMaxHeight()
                        .shadow(5.dp, cardShape, clip = false, ambientColor = pal.c3Glow, spotColor = pal.c3Glow)
                        .clip(cardShape)
                        .background(Brush.linearGradient(pal.c3))
                        .drawBehind { cardWave(pal.c3Wave, 0.30f, 0.98f, 0.55f) }
                        .border(2.dp, Brush.linearGradient(pal.c3Border), cardShape)
                        .clickable(onClick = onGlucose),
                ) {
                    Column(Modifier.padding(start = 12.dp, end = 8.dp, top = 10.dp)) {
                        Row(Modifier.height(20.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("🎯", fontSize = 15.sp)
                            Spacer(Modifier.width(7.dp))
                            FitOneLine("Tempo no alvo", white90, 12f, 9f, Modifier.weight(1f), FontWeight.SemiBold)
                        }
                        Text(
                            if (tirPct != null) "$tirPct%" else "—",
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 30.sp,
                            lineHeight = 34.sp,
                            modifier = Modifier.padding(start = 5.dp, top = 8.dp),
                        )
                    }
                    HomeChevron(pal, Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = 10.dp))
                }
            }
        }

        Spacer(Modifier.height(12.dp))

        // Mensagem fixa e, abaixo dela, a frase carinhosa do dia.
        val msgShape = RoundedCornerShape(18.dp)
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp)
                .shadow(5.dp, msgShape, clip = false, ambientColor = pal.msgGlow, spotColor = pal.msgGlow)
                .clip(msgShape)
                .background(Brush.linearGradient(pal.msg))
                .border(1.5.dp, Brush.linearGradient(pal.msgBorder), msgShape)
                .padding(top = 10.dp, bottom = 8.dp, end = 12.dp),
        ) {
            Row(Modifier.fillMaxWidth().height(22.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Text("❤️", fontSize = 15.sp)
                Spacer(Modifier.width(8.dp))
                Text("Uma mensagem para você", color = pal.msgTitle, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                Spacer(Modifier.width(8.dp))
                Text("❤️", fontSize = 15.sp)
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.Top) {
                Image(
                    painterResource(R.drawable.neon_love_hearts),
                    contentDescription = "Corações",
                    modifier = Modifier.size(72.dp).offset(x = 4.dp, y = 2.dp),
                    contentScale = ContentScale.Crop,
                )
                Text(
                    MAIN_LOVE_MESSAGE,
                    color = pal.msgText,
                    fontSize = 13.sp,
                    lineHeight = 17.sp,
                    modifier = Modifier.weight(1f).padding(start = 6.dp, top = 4.dp),
                )
            }
            if (phrase.isNotEmpty()) {
                Text(
                    phrase,
                    color = pal.msgPhrase,
                    fontSize = 13.sp,
                    fontStyle = FontStyle.Italic,
                    lineHeight = 18.sp,
                    modifier = Modifier.fillMaxWidth().padding(start = 14.dp, top = 8.dp),
                )
                Text(
                    "Frase carinhosa de hoje",
                    color = pal.msgLabel,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(start = 14.dp, top = 2.dp),
                )
            }
        }
    }
}
