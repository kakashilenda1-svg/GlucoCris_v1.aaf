package com.agon.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.ui.components.BackTitle
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.theme.AccessibilityPrefs
import com.agon.app.ui.theme.glucoColors

/** Ajustes de acessibilidade, todos MANUAIS: nada muda sozinho. */
@Composable
fun AccessibilityScreen(nav: NavHostController) {
    val g = glucoColors()
    val ctx = LocalContext.current
    val level = AccessibilityPrefs.level.value
    val contrast = AccessibilityPrefs.highContrast.value
    val big = AccessibilityPrefs.bigTouch.value

    ScrollScreen {
        BackTitle("Acessibilidade", { nav.popBackStack() })
        Text(
            "Você escolhe aqui. Nada muda sozinho e a escolha vale só neste aparelho.",
            color = g.muted, fontSize = 13.sp,
        )

        SectionTitle("Tamanho do texto")
        GCard {
            ChipRow(AccessibilityPrefs.LABELS.mapIndexed { i, l -> i.toString() to l }, level.toString()) {
                AccessibilityPrefs.setLevel(ctx, it.toInt())
            }
            Text(
                "Soma-se ao tamanho de fonte do Android. Veja o efeito agora, neste texto de exemplo.",
                color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
            )
            Text("Glicemia 112 mg/dL · dentro da meta", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
        }

        SectionTitle("Contraste e toque")
        GCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Contraste alto", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Textos de apoio e linhas ficam mais escuros e fáceis de ler.", color = g.muted, fontSize = 12.sp)
                }
                Switch(checked = contrast, onCheckedChange = { AccessibilityPrefs.setHighContrast(ctx, it) })
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Botões de baixo maiores", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("A barra de abas fica mais alta, com área de toque maior.", color = g.muted, fontSize = 12.sp)
                }
                Switch(checked = big, onCheckedChange = { AccessibilityPrefs.setBigTouch(ctx, it) })
            }
        }

        PrimaryButton("Voltar ao padrão", g.muted, { AccessibilityPrefs.reset(ctx) }, Modifier.padding(top = 16.dp))
    }
}
