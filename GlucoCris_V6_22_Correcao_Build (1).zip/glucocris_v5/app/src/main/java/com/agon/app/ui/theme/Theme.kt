package com.agon.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf

val LocalGluco = staticCompositionLocalOf { LightGlucoColors }

@Composable
fun glucoColors(): GlucoColors = LocalGluco.current

@Composable
fun AgonAppTheme(
    darkTheme: Boolean = false,
    blueTheme: Boolean = false,
    content: @Composable () -> Unit,
) {
    val g = when {
        blueTheme && darkTheme -> BlueDarkGlucoColors
        blueTheme -> BlueLightGlucoColors
        darkTheme -> DarkGlucoColors
        else -> LightGlucoColors
    }
    val scheme = if (darkTheme) {
        darkColorScheme(
            primary = g.violet,
            onPrimary = g.bg,
            secondary = g.blue,
            tertiary = g.green,
            background = g.bg,
            onBackground = g.ink,
            surface = g.bg,
            onSurface = g.ink,
            surfaceVariant = g.card,
            onSurfaceVariant = g.ink,
            outline = g.line,
            error = g.red,
        )
    } else {
        lightColorScheme(
            primary = g.violet,
            onPrimary = g.card,
            secondary = g.blue,
            tertiary = g.green,
            background = g.bg,
            onBackground = g.ink,
            surface = g.bg,
            onSurface = g.ink,
            surfaceVariant = g.card,
            onSurfaceVariant = g.ink,
            outline = g.line,
            error = g.red,
        )
    }
    // Acessibilidade manual (botão "Aa"): contraste alto deixa textos de apoio e linhas bem visíveis.
    val gFinal = if (AccessibilityPrefs.highContrast.value) g.copy(muted = g.ink, line = g.ink.copy(alpha = 0.55f)) else g
    val base = androidx.compose.ui.platform.LocalDensity.current
    val density = androidx.compose.ui.unit.Density(base.density, base.fontScale * AccessibilityPrefs.scale())
    CompositionLocalProvider(
        LocalGluco provides gFinal,
        androidx.compose.ui.platform.LocalDensity provides density,
    ) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
