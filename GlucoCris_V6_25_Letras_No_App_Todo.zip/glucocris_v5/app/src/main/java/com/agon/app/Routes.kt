package com.agon.app

import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController

object Routes {
    const val HOME = "inicio"
    const val GLUCOSE = "glicose"
    const val INSULIN = "insulina"
    const val REMINDERS = "lembretes"
    const val HISTORY = "historico"
    const val MORE = "mais"
    const val PROFILE = "perfil"
    const val STATS = "estatisticas"
    const val CARE = "cuidados"
    const val MEDS = "medicamentos"
    const val REPORT = "relatorio"
    const val SETTINGS = "ajustes"
    const val LOCATOR = "localizador"
    const val CRIS_IA = "cris_ia"
    const val CRIS_VOICE = "cris_voz"
    const val CRIS_AI_SETTINGS = "cris_ia_config"
    const val CRIS_MODEL_CHOOSER = "cris_ia_modelo"
    const val GLUCOSE_FORM = "glicose_form"
    const val INSULIN_FORM = "insulina_form"
    const val FOOD = "alimentacao"
    const val FOOD_SEARCH = "alimentacao_busca"
    const val FOOD_DETAIL = "alimentacao_detalhe"
    const val FOOD_DIARY = "alimentacao_diario"
    const val FOOD_REPORTS = "alimentacao_relatorios"
    const val FOOD_BARCODE = "alimentacao_barcode"
    const val FOOD_SMART_SCAN = "alimentacao_scanner_inteligente"
    const val FOOD_RECIPES = "alimentacao_receitas"
    const val FOOD_RECIPE_DETAIL = "alimentacao_receita_detalhe"
    const val FOOD_MEAL_PLAN_DETAIL = "alimentacao_plano_detalhe"
    const val HELP_CENTER = "central_ajuda"
    const val FOOD_TOOLS = "alimentacao_ferramentas"
    const val FOOD_CUSTOM = "alimentacao_meus_alimentos"
    const val FOOD_MEAL_BUILDER = "alimentacao_montar"
    const val FOOD_FAV_MEALS = "alimentacao_favoritas"
    const val FOOD_BOLUS = "alimentacao_bolus"
    const val FOOD_GLUCOSE_LINK = "alimentacao_glicemia_link"
    const val FOOD_PLATE = "alimentacao_prato"
    const val WATER = "agua"
    const val PATTERNS = "painel_padroes"
    const val MEDICAL_REPORT = "relatorio_medico"
    const val CAREGIVER = "modo_cuidador"
    const val HBA1C = "hemoglobina_glicada"
    const val FOOD_RESPONSE = "resposta_glicemica_alimentos"
    const val WEEKLY = "resumo_semanal_cris"
    const val SENSORS = "sensores"
    const val SYSTEM_DIAGNOSIS = "diagnostico_sistema"
    const val LOCAL_BACKUP = "backup_local"
    const val NOTIFICATIONS = "central_notificacoes"
    const val ANALYSIS = "analises"
    const val ACCESSIBILITY = "acessibilidade"

    val tabs = listOf(HOME, GLUCOSE, INSULIN, REMINDERS, HISTORY, FOOD, MORE)

    fun glucoseForm(id: String?) = if (id == null) GLUCOSE_FORM else "glicose_form?id=$id"
    fun insulinForm(id: String?) = if (id == null) INSULIN_FORM else "insulina_form?id=$id"

    fun goTab(nav: NavHostController, route: String) {
        nav.navigate(route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun tabOf(route: String?): String = when {
        route == null -> HOME
        route.startsWith(GLUCOSE_FORM) || route == GLUCOSE -> GLUCOSE
        route.startsWith(INSULIN_FORM) || route == INSULIN -> INSULIN
        route == REMINDERS -> REMINDERS
        route == HISTORY -> HISTORY
        route == HOME -> HOME
        route == FOOD || route.startsWith("alimentacao") -> FOOD
        route == PROFILE -> MORE
        else -> MORE
    }

    fun titleOf(route: String?, id: String? = null): String = when {
        route == null -> ""
        route.startsWith(GLUCOSE_FORM) -> if (id != null) "Editar glicose" else "Nova glicose"
        route.startsWith(INSULIN_FORM) -> if (id != null) "Editar insulina" else "Nova insulina"
        route == GLUCOSE -> "Glicose"
        route == INSULIN -> "Insulina"
        route == REMINDERS -> "Lembretes"
        route == HISTORY -> "Histórico"
        route == MORE -> "Organização"
        route == PROFILE -> "Perfil"
        route == STATS || route == ANALYSIS -> "Análises"
        route == NOTIFICATIONS -> "Central de notificações"
        route == ACCESSIBILITY -> "Acessibilidade"
        route == CARE -> "Alimentação e sintomas"
        route == MEDS -> "Medicamentos"
        route == REPORT -> "Relatório"
        route == PATTERNS -> "Painel de padrões"
        route == MEDICAL_REPORT -> "Relatório médico"
        route == CAREGIVER -> "Modo cuidador"
        route == HBA1C -> "Hemoglobina glicada (HbA1c)"
        route == FOOD_RESPONSE -> "Resposta por alimento"
        route == WEEKLY -> "Resumo semanal da Cris"
        route == SENSORS -> "Sensores"
        route == SETTINGS -> "Ajustes"
        route == LOCATOR -> "Localizador de Insulinas"
        route == CRIS_IA -> "Cris IA ❤️"
        route == CRIS_VOICE -> "Cris · voz"
        route == CRIS_AI_SETTINGS -> "IA da Cris"
        route == CRIS_MODEL_CHOOSER -> "Trocar modelo da IA"
        route == FOOD || route.startsWith("alimentacao") -> "Alimentação e Nutrição"
        else -> ""
    }
}
