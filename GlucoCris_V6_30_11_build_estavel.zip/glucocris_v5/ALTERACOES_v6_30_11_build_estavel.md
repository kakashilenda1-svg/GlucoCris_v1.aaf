# v6.30.11 — Correção do erro de build (GitHub Actions)

Erro: "Could not find com.google.protobuf:protobuf-java:3.25.5 / javawriter:2.5.0 / jsr305:3.0.2 / kotlin-stdlib-jdk8:2.1.0"
(dependências do próprio plugin do Android, procuradas em dl.google.com, Maven Central e plugins.gradle.org). BUILD FAILED em 7s na tentativa 3.

Causa provável: falha momentânea de download na 1ª tentativa; o Gradle guarda o "não achei" no cache e as tentativas seguintes falham em segundos.

Correções (nenhuma funcionalidade do app foi alterada):
- settings.gradle.kts: espelho do Maven Central (Google) como repositório de reserva, em plugins e dependências.
- .github/workflows/build.yml: 3 tentativas; a partir da 2ª limpa o cache de dependências e usa --refresh-dependencies; erro de código não é repetido.
- versionName 1.34.9-v6.30.11-build-estavel.
