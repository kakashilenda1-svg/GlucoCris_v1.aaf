# v6.30.28 — terceiro layout da tela inicial (claro / vidro azul)

O botão ⇄ do topo agora alterna entre 3 layouts: roxo → azul → claro → roxo.

- Tela inicial do layout claro: ui/screens/HomeGlass.kt (HomeTopGlass), medidas tiradas do print de referência (841 px de largura, escaladas pela largura da tela).
- Barra inferior do layout claro: GlassNavBar em ui/components/GlucoNavBars.kt.
- Cartão Cris Hidrata no estilo claro: WaterMiniBar(glassScale = ...) em WaterTrackerScreen.kt (os outros layouts não mudam).
- Nova opção Settings.lightLayout (Models.kt); o claro usa blueTheme = true + lightLayout = true. Quem já usava roxo ou azul continua igual.
- Imagens novas (res/drawable-nodpi/home3_*.png) recortadas do print: fundo do topo (sem número no glicosímetro), logo, robô Cris, ícones.
- O número do glicosímetro, a saudação, os valores e as barras de progresso mostram dados reais (não os do print).
- Textos de Ajuda e do tour atualizados para os 3 layouts.

Compilação: NÃO verificada (sem Android SDK/Gradle e sem internet no ambiente). Rodar ./gradlew assembleDebug.
