# v6.27 — Sincronização Paciente ↔ Cuidador (Gluco Cris ⇄ Gluco Cris Cuidador)

Nada foi removido: `applicationId`, backup (`users/{uid}/records`), Cris IA, login, biometria, Modo cuidador por SMS/WhatsApp e glicosímetro Bluetooth seguem como estavam.
**Não compilado nem testado aqui** (sem Android SDK, Gradle nem Firebase). Rode `./gradlew testDebugUnitTest assembleDebug` e o teste de regras antes de usar com dados reais.

## Como os dois apps conversam
```
Gluco Cris (paciente)                         Firebase (mesmo projeto)                    Gluco Cris Cuidador
 glicemia salva / sensor / Bluetooth ──►  patients/{uid}/readings/{id}  ──► Functions ──►  current/latest, trend,
 (CuidadorCloud.syncIfEnabled)             patients/{uid} (nome, limites)     dailySummary,   alertas + push (FCM)
 limites, HbA1c, plano, "Estou bem"        syncStatus, hba1c, carePlan        stats, alerts
 Tela "Cuidador online": código ──────►  createPairingCode ──► cuidador digita ──► requestAccess ──► você aprova (respondRequest)
```
- `pid` = UID do Firebase Auth do paciente (a mesma conta do backup). O cuidador é outra conta (e-mail/senha).
- Fonte: leituras `sensor-*` (Libre/Dexcom/Nightscout) → `cgm`; digitadas e glicosímetro Bluetooth (`ble-*`) → `manual` (campo `deviceId` diz `bluetooth`/`libre`/…). GMI/cobertura/tempo na meta do Cuidador usam só `cgm`.
- O id do documento = id da leitura no app (idempotente). Valor inteiro 20–600 mg/dL (mmol/L é convertido); fora disso não é enviado.
- Gatilhos de envio: depois de cada sincronização do app (≈ na hora de salvar), no trabalho periódico de 30 min (app fechado) e logo após cada importação de sensor com o app fechado.
- Limites: o app Cuidador recebe `targetLow/High` dos Ajustes e `urgentLow/High` dos limites do Modo cuidador (grave baixo/alto), sempre coerentes (urgente baixo < baixo; urgente alto > alto). Fuso (`tzOffsetMin`) vai junto para fechar o "dia" certo.

## O que o paciente ganhou
`Mais ▸ Modo cuidador / família ▸ Cuidador online`: ligar/desligar, gerar código (10 min, uso único), aprovar/recusar pedidos escolhendo permissões (Básico/Tudo/Nada), editar permissões, retirar acesso, botão **Estou bem**, plano de ação, mostrar contato de confiança como contato de emergência, **apagar tudo que compartilhei** (LGPD).

## Passo a passo (uma vez)
1. **Mesmo projeto Firebase** nos dois apps (`gluco-cris`). No console, registre também o app `br.com.glucocris.cuidador` e baixe o `google-services.json` dele para a pasta `app/` do Cuidador. Ative **E-mail/senha** em Authentication (o paciente já usa Google/e-mail).
2. **Plano Blaze é obrigatório** para publicar Cloud Functions (pareamento, permissões, alertas, push). Até a v6.26 o projeto estava no Spark e o texto do `BACKUP_FIREBASE.md` pede para não fazer upgrade: essa regra **não vale mais se você quer o Cuidador online**. O uso de um paciente cabe na cota gratuita diária do Blaze, mas o Blaze exige cartão e um orçamento/alerta de cobrança (recomendo criar um alerta de R$ 5).
3. Na pasta do projeto: `cd functions && npm install && cd ..`, depois  
   `firebase deploy --only firestore:rules,firestore:indexes,functions`  
   (região das funções: `southamerica-east1`, a mesma do Firestore.)
4. **Regras unificadas**: o novo `firestore.rules` substitui o da v6.26 (guardado em `firestore.rules.antes-v6.27`). O ramo `users/{uid}/records` do backup é idêntico. Rode o teste de regras do Cuidador: `cd functions && npx firebase emulators:exec --only firestore "npx mocha ../backend-tests/rules.cuidador.test.js --timeout 20000"`.
5. Instale o app novo, entre na conta, ligue **Cuidador online** e gere o código. No app Cuidador: cadastrar conta ▸ digitar o código ▸ você aprova no Gluco Cris.

## Limites conhecidos (honestos)
- **Editar ou excluir uma glicemia depois de enviada não muda o que o cuidador vê** (as regras do Cuidador só permitem criar leitura; e o servidor já somou no resumo/alertas). O botão "Apagar tudo que compartilhei" limpa o servidor.
- **Primeira ativação envia só as últimas 3 h; depois de ficar offline, no máximo as últimas 6 h.** Reenviar horas antigas dispararia alertas e push de valores que já passaram. Consequência: GMI/cobertura só aparecem depois de dias de uso (14 dias de dados).
- O importador de sensor do Gluco Cris grava **1 leitura a cada 15 min** (por desenho). O Cuidador foi configurado para esse intervalo (`cgmIntervalMin = 15`); não é "tempo real a cada minuto".
- Sensor com o app fechado: o Android limita trabalho periódico (mín. 15 min, e mais em economia de bateria). Isso vale para os dois lados; o app não consegue prometer latência fixa.
- Glicosímetro Bluetooth só importa com o app aberto/buscando (limite da v6.26); então o cuidador só vê essas leituras depois que entram no app.
- Se o **Modo cuidador por SMS/WhatsApp** também estiver ligado, o contato pode receber o aviso pelos dois caminhos. São independentes; desligue um se preferir.
- Seguem só no aparelho (não vão ao Cuidador): insulina, refeições, sintomas, medicamentos, CPF, Cris IA. Informações adicionais (`extraInfo`) não foram implementadas porque o app Cuidador não tem tela para elas.
- `validReading` nas regras ficou um pouco mais rígido que o original: exige também as 5 chaves obrigatórias (value, unit, source, originTs, serverTs). O envio do app sempre as traz.
- Troca de conta no Gluco Cris reinicia o controle de envio (`CuidadorPrefs.resetSyncState`); o vínculo antigo continua no servidor da conta anterior.

## Arquivos
Novos: `cloud/CuidadorOnline.kt` (lógica pura + preferências), `cloud/CuidadorCloud.kt` (Firestore/Functions), `ui/screens/CuidadorOnlineScreen.kt`, `functions/` (backend do Cuidador), `firestore.indexes.json`, `backend-tests/`, `app/src/test/.../CuidadorOnlineTest.kt`.
Alterados (mudanças mínimas): `GlucoViewModel.kt` (1 chamada após sincronizar), `CloudSyncWorker.kt` (1 linha), `SensorSync.kt` (envio após importar com app fechado), `InsightScreens.kt` (cartão de entrada), `Routes.kt`, `MainActivity.kt`, `app/build.gradle.kts` (`firebase-functions`; versão 1.31.0-v6.27-cuidador-online), `firestore.rules`, `firebase.json`.

## Lado do app Cuidador
O protocolo (`docs/01_PROTOCOLO_INTEGRACAO.md`) dizia "Etapa 1 pendente". Auditei o V6.26: os pontos de encaixe batem com o que está acima, e o app Cuidador **não precisou de alteração de código**. Só confirme: mesmo projeto Firebase, `google-services.json` do app `br.com.glucocris.cuidador`, e `firebase deploy` das funções feito.
