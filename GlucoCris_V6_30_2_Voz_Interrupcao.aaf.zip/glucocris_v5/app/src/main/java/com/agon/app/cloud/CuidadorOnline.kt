package com.agon.app.cloud

import android.content.Context
import com.agon.app.data.AppData
import com.agon.app.data.GlucoseEntry
import com.agon.app.data.toMgDl
import com.agon.app.reminders.Caregiver
import com.agon.app.sensors.SensorConfig
import kotlin.math.roundToInt

/**
 * Lógica PURA (sem Firebase) da ponte Paciente -> app "Gluco Cris Cuidador".
 * Mantida separada para ser testada na JVM (ver CuidadorOnlineTest).
 *
 * Contrato com o backend do Cuidador (firestore.rules + functions/index.js):
 *  - patients/{pid}/readings/{uuid}: value Int 20..600, unit "mg/dL", source "cgm"|"manual", originTs, serverTs.
 *    Só CRIAÇÃO é aceita (update/delete = false), então cada leitura vai UMA vez.
 *  - patients/{pid}: só displayName, thresholds, cgmExpected, cgmIntervalMin, tzOffsetMin, staleAfterMin.
 */
object CuidadorOnline {
    const val SOURCE_CGM = "cgm"
    const val SOURCE_MANUAL = "manual"

    const val MIN_MG = 20
    const val MAX_MG = 600

    /** Primeira ativação: só as últimas horas (cada leitura antiga dispararia alerta/push no cuidador). */
    const val FIRST_BACKFILL_MS = 3 * 3_600_000L

    /** Depois de ficar offline: reenvia no máximo as últimas horas (evita alerta de valor muito antigo). */
    const val MAX_PENDING_MS = 6 * 3_600_000L

    /** Leituras por lote de gravação (limite do Firestore é 500). */
    const val BATCH = 100

    /** Leituras de sensor (Libre/Dexcom/Nightscout) têm id "sensor-..."; glicosímetro BT ("ble-...") e digitadas são "manual". */
    fun sourceOf(id: String): String = if (id.startsWith("sensor-")) SOURCE_CGM else SOURCE_MANUAL

    /** Detalhe opcional (campo deviceId das regras): de onde veio a leitura. */
    fun deviceOf(id: String): String? = when {
        id.startsWith("sensor-dexcom") -> "dexcom"
        id.startsWith("sensor-libre") -> "libre"
        id.startsWith("sensor-nightscout") -> "nightscout"
        id.startsWith("ble-") -> "bluetooth"
        else -> null
    }

    /** Valor em mg/dL inteiro aceito pelas regras, ou null se fora de 20..600. */
    fun readingMg(e: GlucoseEntry): Int? {
        val mg = toMgDl(e.value, e.unit).roundToInt()
        return if (mg in MIN_MG..MAX_MG) mg else null
    }

    fun isDemo(e: GlucoseEntry) = e.id.startsWith("demo-")

    /**
     * Leituras a enviar: não-demo, valor válido, dentro da janela, ainda não enviadas, da mais antiga para a mais nova
     * (o backend só atualiza "glicemia atual" quando a leitura é a mais recente).
     */
    fun pending(entries: List<GlucoseEntry>, sent: Set<String>, now: Long, windowMs: Long): List<GlucoseEntry> =
        entries.asSequence()
            .filter { !isDemo(it) && it.id !in sent && readingMg(it) != null }
            .filter { it.at <= now + 5 * 60_000L && now - it.at <= windowMs }
            .sortedBy { it.at }
            .toList()

    /** Limites do app Cuidador a partir dos ajustes do paciente (garante urgentLow < low e urgentHigh > high). */
    fun thresholds(targetLow: Int, targetHigh: Int, severeLow: Int, severeHigh: Int): Map<String, Int> {
        val low = targetLow.coerceIn(40, 130)
        val high = targetHigh.coerceIn(low + 10, 400)
        val urgentLow = minOf(severeLow, low - 1).coerceAtLeast(30)
        val urgentHigh = maxOf(severeHigh, high + 1).coerceAtMost(600)
        return mapOf(
            "urgentLow" to urgentLow, "low" to low, "targetLow" to low,
            "targetHigh" to high, "high" to high, "urgentHigh" to urgentHigh,
        )
    }

    /** Deslocamento do fuso em minutos (o backend usa para fechar o "dia" do resumo). Ex.: Brasília = -180. */
    fun tzOffsetMin(now: Long = System.currentTimeMillis()): Int =
        java.util.TimeZone.getDefault().getOffset(now) / 60_000

    /** Estado do CGM para o painel "Sincronização" do cuidador: ok | no_readings | disconnected. */
    fun cgmState(configured: Boolean, lastCgmMs: Long, now: Long, intervalMin: Int): String = when {
        !configured -> "disconnected"
        lastCgmMs <= 0L -> "no_readings"
        now - lastCgmMs > (intervalMin * 2 + 10) * 60_000L -> "no_readings"
        else -> "ok"
    }

    /** Permissões conhecidas pelo backend (functions/index.js PERMS) com rótulo em português. */
    val PERMISSIONS: List<Pair<String, String>> = listOf(
        "currentGlucose" to "Glicemia atual",
        "history" to "Histórico de glicemia",
        "charts" to "Gráficos",
        "cgm" to "Dados do sensor (CGM)",
        "trends" to "Tendência (setas)",
        "gmi" to "GMI (estimativa de HbA1c)",
        "cgmCoverage" to "Cobertura do sensor",
        "hba1cCurrent" to "HbA1c de exame (último)",
        "hba1cHistory" to "Histórico de HbA1c",
        "reports" to "Relatórios",
        "alerts" to "Alertas de glicemia",
        "diary" to "Diário de ocorrências",
        "carePlan" to "Plano de ação",
        "emergencyContacts" to "Contatos de emergência",
        "extraInfo" to "Informações adicionais",
    )

    val PRESET_BASIC = setOf("currentGlucose", "trends", "alerts")
    val PRESET_FULL = PERMISSIONS.map { it.first }.toSet()
}

/** Preferências locais da ponte (não vão para backup: dizem respeito a este aparelho/conta). */
object CuidadorPrefs {
    private const val PREFS = "gluco_cuidador_online_v1"
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun enabled(ctx: Context) = sp(ctx).getBoolean("enabled", false)
    fun setEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("enabled", v).apply()

    fun ownerUid(ctx: Context): String = sp(ctx).getString("owner_uid", "") ?: ""
    fun setOwnerUid(ctx: Context, v: String) = sp(ctx).edit().putString("owner_uid", v).apply()

    /** ids já gravados no Firestore, com o instante da leitura ("id|at"), para não reenviar. */
    fun sent(ctx: Context): Map<String, Long> =
        (sp(ctx).getString("sent", "") ?: "").lineSequence().mapNotNull {
            val p = it.split('|'); if (p.size == 2) p[1].toLongOrNull()?.let { at -> p[0] to at } else null
        }.toMap()

    fun saveSent(ctx: Context, m: Map<String, Long>, now: Long) {
        val keep = m.filter { now - it.value <= CuidadorOnline.MAX_PENDING_MS * 4 }.entries.sortedByDescending { it.value }.take(3000)
        sp(ctx).edit().putString("sent", keep.joinToString("\n") { "${it.key}|${it.value}" }).apply()
    }

    fun hba1cSent(ctx: Context): Set<String> = sp(ctx).getStringSet("hba1c_sent", emptySet()) ?: emptySet()
    fun setHba1cSent(ctx: Context, s: Set<String>) = sp(ctx).edit().putStringSet("hba1c_sent", s).apply()

    fun lastProfileHash(ctx: Context) = sp(ctx).getInt("profile_hash", 0)
    fun setLastProfileHash(ctx: Context, h: Int) = sp(ctx).edit().putInt("profile_hash", h).apply()

    fun shareContact(ctx: Context) = sp(ctx).getBoolean("share_contact", false)
    fun setShareContact(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("share_contact", v).apply()

    /** Apaga o controle de envio (troca de conta ou desligar): na próxima ativação recomeça do zero. */
    fun resetSyncState(ctx: Context) = sp(ctx).edit().remove("sent").remove("hba1c_sent").remove("profile_hash").apply()

    fun lastOk(ctx: Context) = sp(ctx).getLong("last_ok", 0L)
    fun setLastOk(ctx: Context, v: Long) = sp(ctx).edit().putLong("last_ok", v).apply()
    fun lastMsg(ctx: Context) = sp(ctx).getString("last_msg", "") ?: ""
    fun setLastMsg(ctx: Context, v: String) = sp(ctx).edit().putString("last_msg", v).apply()
}

/** Entrada de dados do paciente usada pelo envio (isola AppData/SensorConfig/Caregiver do código de rede). */
data class CuidadorSnapshot(
    val readings: List<GlucoseEntry>,
    val displayName: String,
    val targetLow: Int,
    val targetHigh: Int,
    val severeLow: Int,
    val severeHigh: Int,
    val cgmConfigured: Boolean,
    val lastCgmMs: Long,
    val hba1c: List<Triple<String, Double, Long>>, // id, %, data da coleta
    val hba1cLab: Map<String, String>,
) {
    companion object {
        fun of(ctx: Context, d: AppData): CuidadorSnapshot = CuidadorSnapshot(
            readings = d.glucose,
            displayName = d.settings.displayName.ifBlank { "Paciente" }.take(80),
            targetLow = d.settings.targetLow,
            targetHigh = d.settings.targetHigh,
            severeLow = Caregiver.severeLow(ctx),
            severeHigh = Caregiver.severeHigh(ctx),
            cgmConfigured = SensorConfig.isConfigured(ctx) && SensorConfig.provider(ctx) != SensorConfig.NONE,
            lastCgmMs = d.glucose.filter { it.id.startsWith("sensor-") }.maxOfOrNull { it.at } ?: 0L,
            hba1c = d.hba1c.map { Triple(it.id, it.percent, it.at) },
            hba1cLab = d.hba1c.associate { it.id to it.lab },
        )
    }
}
