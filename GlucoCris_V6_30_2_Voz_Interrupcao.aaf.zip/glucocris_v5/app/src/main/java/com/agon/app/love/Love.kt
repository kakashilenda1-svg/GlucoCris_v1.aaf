package com.agon.app.love

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import com.agon.app.data.PrefsJson
import org.json.JSONObject
import java.time.LocalDate

/**
 * Frases prontas, guardadas no aplicativo. Funcionam sem internet.
 * A ordem é fixa: uma por dia, avançando sem repetir até o fim da coleção.
 */
val LOVE_PHRASES = listOf(
    "O seu cuidado com você também é um cuidado com a gente.",
    "Estou ao seu lado nos dias bons e nos dias que pedem mais paciência.",
    "Parceiros de verdade se escolhem de novo a cada manhã.",
    "Que hoje você se lembre: não precisa dar conta de tudo sozinha.",
    "Meu amor por você não depende do dia ser fácil.",
    "Conta comigo para o café, para o silêncio e para o que vier.",
    "Cuidar de você é a parte mais bonita do meu dia.",
    "Mesmo longe um instante, meu carinho fica com você.",
    "Você não está sozinha em nenhum número, em nenhuma hora.",
    "Amor também é perguntar como você está e esperar a resposta.",
    "Que o dia de hoje seja leve, e que eu possa ser o seu descanso.",
    "Somos time: quando um cansa, o outro segura a mão.",
    "Obrigado por existir na minha vida com tanta doçura.",
    "Seu sorriso ainda é o meu lugar favorito.",
    "Pode apoiar o seu dia no meu ombro. Ele é seu.",
    "Eu escolho você com calma, com pressa e com toda a certeza.",
    "Parceria é isso: estar perto mesmo quando o dia não colabora.",
    "Que cada medição lembre só uma coisa: você é amada.",
    "Não existe rotina que apague o carinho que eu tenho por você.",
    "Hoje eu te desejo paz, água fresca e o meu abraço.",
    "Amor da minha vida, vá no seu tempo. Eu espero com você.",
    "Ser seu companheiro é o privilégio mais bonito que eu tenho.",
    "Se o dia pesar, divide comigo. A gente carrega junto.",
    "Você é a minha casa, em qualquer horário.",
    "Meu cuidado não faz barulho, mas não sai do seu lado.",
    "Que a gente continue simples, próximo e inteiro.",
    "Te amar é a minha forma preferida de começar o dia.",
    "Pode contar com a minha mão, a minha voz e a minha paciência.",
    "Nada do que você sente precisa ser enfrentado em silêncio.",
    "Eu te admiro por cuidar de você com tanta coragem.",
    "O nosso amor cabe no dia comum, e é nele que ele brilha.",
    "Se precisar de um colo hoje, ele já está reservado.",
    "Parceiros, amigos, amantes: a gente é tudo isso, todo dia.",
    "Que esta frase encontre você sorrindo, mesmo que só um pouco.",
    "Meu coração aprendeu o seu nome e não quer saber de outro.",
    "Estou aqui. Nem sempre perto, sempre seu.",
    "O carinho de hoje é o mesmo de ontem, só com um beijo a mais.",
    "Você torna o ordinário em algo que eu quero guardar.",
    "Descansa quando precisar. Eu continuo aqui, do seu lado.",
    "Amar você é o plano inteiro. O resto a gente resolve junto.",
    "Bom dia, meu amor. Que a sua manhã comece com a minha torcida por você.",
    "Você é forte, mas não precisa ser forte o tempo todo. Eu estou aqui.",
    "Cada dia ao seu lado é um dia que eu agradeço.",
    "Respira fundo. Seja qual for o número de hoje, o meu amor é o mesmo.",
    "Eu me orgulho de você mais do que sei dizer.",
    "Que o seu dia tenha pausas, água, risadas e o meu carinho.",
    "Quando o mundo apertar, lembra que você tem um lugar seguro em mim.",
    "Hoje eu escolho você de novo, como em todos os outros dias.",
    "Você cuida de tudo com tanto amor. Deixa eu cuidar de você também.",
    "Um dia de cada vez, e eu com você em todos eles.",
    "Seu jeito de enfrentar os dias me inspira.",
    "Que a gente nunca perca o costume de rir das pequenas coisas.",
    "Eu te amo no dia bom, no dia difícil e no dia que ninguém percebe.",
    "Meu abraço está sempre pronto para quando você precisar.",
    "Você faz a minha vida ser mais bonita só por estar nela.",
    "Se hoje foi cansativo, amanhã a gente recomeça juntos.",
    "Obrigado por me deixar fazer parte da sua rotina e do seu cuidado.",
    "Você merece descanso, carinho e um dia sem pressa.",
    "Estar com você é a minha parte favorita de qualquer dia.",
    "Que o seu coração fique leve hoje. O meu já está cheio de você.",
    "Nenhum dia comum é comum quando você está nele.",
    "Pode errar, pode cansar, pode recomeçar. Eu continuo do seu lado.",
    "Você é a minha calma no meio da correria.",
    "Cuidar de você é o meu jeito de dizer que amo, todos os dias.",
    "Que você sinta hoje o quanto é importante para mim.",
    "Do seu lado, até os dias difíceis ficam mais fáceis de atravessar.",
    "Eu te vejo, eu te ouço e eu te amo do jeito que você é.",
    "Seu esforço diário não passa despercebido. Eu admiro cada passo.",
    "Que a noite chegue tranquila e o seu sono seja de paz.",
    "Com você, eu aprendi que amor é presença.",
    "Não importa a hora, o meu pensamento passa por você.",
    "Você é a pessoa com quem eu quero dividir todos os dias.",
    "Hoje o recado é simples: você é muito amada.",
    "Vamos fazer do dia de hoje um dia leve, só nosso.",
    "Seu cuidado com a sua saúde é uma forma linda de amor-próprio.",
    "Eu estou torcendo por você, hoje e sempre.",
    "Se precisar conversar, é só chamar. Eu escuto com todo o carinho.",
    "O que a gente construiu juntos é o meu maior orgulho.",
    "Que a sua força de hoje volte para você em forma de alegria.",
    "Aonde você for, o meu carinho vai junto.",
    "Você é a minha melhor companhia, na alegria e no cansaço.",
    "Que hoje você ouça de você mesma o que eu digo todo dia: você é capaz.",
    "Mais um dia, mais um motivo para te agradecer por tudo.",
    "A gente é feito de pequenos cuidados, e eu escolho os seus.",
    "Pode contar comigo para rir, para chorar e para caminhar do seu lado.",
    "Seu bem-estar é um dos meus maiores desejos.",
    "Que cada gesto de cuidado seu volte em dobro em amor.",
    "Eu amo a sua coragem, a sua doçura e o seu jeito de ser.",
    "Que nada hoje pese mais do que o nosso carinho.",
    "Nos dias de silêncio e nos dias de festa, eu escolho você.",
    "A sua vida é preciosa para mim. Cuide dela com a ternura que merece.",
    "Sempre que a rotina cansar, lembra: a gente é time.",
    "Que a sua tarde seja gentil e que eu possa fazer parte dela.",
    "Meu amor, hoje é dia de se orgulhar de tudo o que você já superou.",
    "Você é meu lar, meu abraço e meu melhor motivo para sorrir.",
    "Que a gente continue se escolhendo, com calma e com muito amor.",
    "Eu te amo hoje com a mesma força de quando tudo começou.",
    "Você não precisa ser perfeita. Você já é tudo o que eu quero.",
    "Que o seu dia termine do jeito que merece: em paz e com carinho.",
    "Com amor, paciência e parceria, a gente vai longe.",
)

const val MAIN_LOVE_MESSAGE =
    "Amor lembre-se que nem todos os dias são iguais, temos dias bons e dias ruins mas somos amigos, amantes, companheiros e parceiros todos os dias. Eu te amo mais que a minha própria vida."

const val LOVE_PHONE_DISPLAY = "+55 11 93208-9685"
const val LOVE_PHONE_TEL = "+5511932089685"
const val LOVE_WHATSAPP = "https://wa.me/5511932089685"
const val SAMU_TEL = "192"

private val Context.loveStore by preferencesDataStore(name = "gluco_love")
private val DATE_KEY = stringPreferencesKey("phrase_date")
private val INDEX_KEY = intPreferencesKey("phrase_index")

// ---- Portabilidade de dados por conta (backup completo / troca de conta) ----

suspend fun loveDumpAll(context: Context): String = PrefsJson.fromPreferences(context.loveStore.data.first()).toString()

suspend fun loveRestoreAll(context: Context, text: String) {
    val o = try { JSONObject(text) } catch (_: Exception) { return }
    context.loveStore.edit { PrefsJson.applyPreferences(it, o) }
}

suspend fun loveWipeAll(context: Context) {
    context.loveStore.edit { it.clear() }
}

/** Mesma frase o dia inteiro; no dia seguinte, a próxima da coleção. Sem rede. */
suspend fun phraseForToday(context: Context): String {
    val today = LocalDate.now().toString()
    val prefs = context.loveStore.data.first()
    val savedDate = prefs[DATE_KEY]
    val savedIndex = prefs[INDEX_KEY] ?: -1
    if (savedDate == today && savedIndex in LOVE_PHRASES.indices) return LOVE_PHRASES[savedIndex]
    val next = if (savedIndex < 0) 0 else (savedIndex + 1) % LOVE_PHRASES.size
    context.loveStore.edit {
        it[DATE_KEY] = today
        it[INDEX_KEY] = next
    }
    return LOVE_PHRASES[next]
}

/**
 * Não liga sozinho. Abre o discador com o número preenchido para a pessoa confirmar.
 * Chamada direta não foi implementada: o Android exige confirmação no discador.
 */
fun openDialer(context: Context, tel: String) {
    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$tel")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "Não foi possível abrir o discador neste aparelho.", Toast.LENGTH_LONG).show()
    }
}

/** Abre a conversa no WhatsApp, ou a página do link, sem enviar nenhuma mensagem. */
fun openWhatsApp(context: Context) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(LOVE_WHATSAPP)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "Não foi possível abrir o WhatsApp neste aparelho.", Toast.LENGTH_LONG).show()
    }
}
