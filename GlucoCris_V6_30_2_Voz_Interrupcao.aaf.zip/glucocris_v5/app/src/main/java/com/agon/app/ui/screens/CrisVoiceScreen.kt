package com.agon.app.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import com.agon.app.data.CrisChatLine
import com.agon.app.data.CrisMemory
import com.agon.app.data.CrisPrefs
import com.agon.app.data.CrisSpeaker
import com.agon.app.data.GlucoViewModel
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

// Cores do modo voz — alinhadas ao Gluco Cris (violeta / lilás / blush), não verde.
private val V_BG_CENTER = Color(0xFF2A1A55)
private val V_BG_EDGE = Color(0xFF120A28)
private val V_GRID = Color(0x1AA78BFA)
private val V_DOT = Color(0xFFC4B5FD)          // lilás claro
private val V_DOT_ACCENT = Color(0xFF8B5CF6)   // violeta
private val V_DOT_WARM = Color(0xFFF0ABFC)     // blush / rosa-violeta (destaque ao falar)
private val V_ACCENT = Color(0xFF7C3AED)       // violeta Gluco Cris
private val V_TEXT = Color(0xFFF5F3FF)
private val V_MUTED = Color(0xFFB8A9D9)
private val V_PANEL = Color(0xFF3B2A6B)

private enum class VoicePhase { IDLE, LISTENING, THINKING, SPEAKING }

/** tint: 0 = lilás, 1 = violeta, 2 = blush (pontos que “pulsam” mais ao falar). */
private class SpherePoint(val x: Float, val y: Float, val z: Float, val lon: Float, val tint: Int)

private val SPHERE: List<SpherePoint> = run {
    val n = 560
    val golden = PI * (3 - sqrt(5.0))
    (0 until n).map { i ->
        val y = 1 - (i / (n - 1f)) * 2
        val r = sqrt(1 - y * y)
        val theta = golden * i
        val x = (cos(theta) * r).toFloat()
        val z = (sin(theta) * r).toFloat()
        val tint = when {
            (i * 37) % 17 == 0 -> 2
            (i * 19) % 11 == 0 -> 1
            else -> 0
        }
        SpherePoint(x, y, z, atan2(z, x), tint)
    }
}

@Composable
fun CrisVoiceScreen(vm: GlucoViewModel, nav: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var phase by remember { mutableStateOf(VoicePhase.IDLE) }
    var caption by remember { mutableStateOf("") }
    var userLine by remember { mutableStateOf("") }
    var hint by remember { mutableStateOf<String?>(null) }
    var micGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    var micBlocked by remember { mutableStateOf(false) }
    var memory by remember { mutableStateOf(CrisMemory()) }
    var pending by remember { mutableStateOf<PendingAction?>(null) }
    val history = remember { mutableListOf<CrisMsg>() }
    var micLevel by remember { mutableFloatStateOf(0f) }
    var leaving by remember { mutableStateOf(false) }

    val speaker = remember { CrisSpeaker(context) }
    val listenerHolder = remember { arrayOfNulls<CrisListener>(1) }

    /** true = escuta aberta só para interromper a Cris enquanto ela fala (barge-in). */
    var bargeIn by remember { mutableStateOf(false) }

    fun startListening(fromBargeIn: Boolean = false) {
        if (leaving) return
        if (!fromBargeIn) speaker.stop()
        hint = null
        if (!fromBargeIn) userLine = ""
        bargeIn = false
        phase = VoicePhase.LISTENING
        listenerHolder[0]?.start()
    }

    /** Resumo dos últimos assuntos do usuário — ajuda a Cris a emendar a conversa. */
    fun conversationSummary(): String {
        val topics = history.asReversed().filter { it.fromUser }.take(8).map { it.text.trim().take(100) }.filter { it.isNotBlank() }
        if (topics.isEmpty()) return ""
        return "Assuntos recentes desta conversa por voz (continue o fio se fizer sentido):\n" +
            topics.asReversed().joinToString("\n") { "• $it" }
    }

    suspend fun handleSpeech(said: String) {
        val cleaned = said.trim()
        if (cleaned.isEmpty()) {
            if (!leaving) startListening()
            return
        }
        bargeIn = false
        speaker.stop()
        phase = VoicePhase.THINKING
        userLine = cleaned
        // Histórico amplo: a Cris vê o que já foi falado nesta sessão e no chat salvo
        val before = history.toList()
        history.add(CrisMsg(true, cleaned))
        val r = crisRespond(
            context, vm, cleaned, memory, pending, before,
            voice = true,
            summary = conversationSummary(),
        )
        memory = r.memory
        pending = r.pending
        history.add(CrisMsg(false, r.reply))
        // Mantém conversa longa no aparelho (memória da sessão)
        while (history.size > 120) history.removeAt(0)
        CrisPrefs.saveChat(context, history.map { CrisChatLine(it.fromUser, it.text) })
        if (leaving) return
        caption = r.reply
        if (r.navigateTo != null) {
            if (memory.speakReplies) {
                phase = VoicePhase.SPEAKING
                speaker.speak(r.reply.take(120)) { }
            }
            leaving = true
            nav.popBackStack()
            nav.navigate(r.navigateTo)
            return
        }
        if (memory.speakReplies) {
            phase = VoicePhase.SPEAKING
            val finished = speaker.speak(r.reply) { phase = VoicePhase.SPEAKING }
            if (leaving) return
            // Se interrompida (finished == false), já deve estar ouvindo pelo barge-in
            if (!leaving && phase != VoicePhase.LISTENING && phase != VoicePhase.THINKING) startListening()
        } else {
            phase = VoicePhase.IDLE
            if (!leaving) startListening()
        }
    }

    if (listenerHolder[0] == null) {
        listenerHolder[0] = CrisListener(
            context,
            onLevel = { lvl ->
                micLevel = lvl
                // Enquanto a Cris fala: voz forte no microfone → interrompe e passa a ouvir
                if (phase == VoicePhase.SPEAKING && lvl > 0.55f) {
                    speaker.stop()
                    bargeIn = false
                    phase = VoicePhase.LISTENING
                    hint = null
                }
            },
            onPartial = { partial ->
                userLine = partial
                // Barge-in: usuário começou a falar com texto reconhecido → para a fala da Cris
                if (phase == VoicePhase.SPEAKING && partial.trim().length >= 3) {
                    speaker.stop()
                    bargeIn = false
                    phase = VoicePhase.LISTENING
                    hint = null
                }
            },
            onResult = { said ->
                bargeIn = false
                if (phase == VoicePhase.SPEAKING) speaker.stop()
                scope.launch { handleSpeech(said) }
            },
            onFail = { msg ->
                // Durante barge-in, "não ouvi" é normal (eco/TTS) — não mostra erro nem para a fala
                if (bargeIn && phase == VoicePhase.SPEAKING) {
                    bargeIn = false
                    return@CrisListener
                }
                if (phase == VoicePhase.LISTENING) {
                    phase = VoicePhase.IDLE
                    hint = msg
                    // Conversa contínua: tenta ouvir de novo após falha leve
                    if (msg.contains("Não te ouvi") || msg.contains("Não consegui")) {
                        scope.launch {
                            kotlinx.coroutines.delay(400)
                            if (!leaving && phase == VoicePhase.IDLE) startListening()
                        }
                    }
                }
            },
        )
    }

    // Enquanto a Cris fala, abre o microfone para permitir interrupção natural
    LaunchedEffect(phase) {
        if (phase == VoicePhase.SPEAKING && micGranted && !leaving) {
            kotlinx.coroutines.delay(550) // evita capturar o início do TTS
            if (phase == VoicePhase.SPEAKING && !leaving) {
                bargeIn = true
                listenerHolder[0]?.start()
            }
        }
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        micGranted = ok
        if (ok) {
            micBlocked = false
            startListening()
        } else {
            val act = context.findActivity()
            micBlocked = !(act != null && ActivityCompat.shouldShowRequestPermissionRationale(act, Manifest.permission.RECORD_AUDIO))
            hint = if (micBlocked) "O microfone está bloqueado. Libere nas configurações para conversar por voz." else "Sem o microfone eu não consigo te ouvir."
        }
    }

    fun onOrbTap() {
        when (phase) {
            VoicePhase.IDLE -> if (micGranted) startListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
            VoicePhase.LISTENING -> { listenerHolder[0]?.stop(); phase = VoicePhase.IDLE; micLevel = 0f }
            VoicePhase.SPEAKING -> {
                speaker.stop()
                phase = VoicePhase.IDLE
                if (micGranted) startListening()
            }
            VoicePhase.THINKING -> {
                hint = "Cancelado. Pode falar."
                phase = VoicePhase.IDLE
                if (micGranted) startListening()
            }
        }
    }

    LaunchedEffect(Unit) {
        memory = CrisPrefs.loadMemory(context)
        history.addAll(CrisPrefs.loadChat(context).map { CrisMsg(it.fromUser, it.text) })
        if (micGranted) {
            val first = vm.data.value.settings.displayName.split(" ").firstOrNull().orEmpty()
            val hello = "Oi${if (first.isNotBlank()) ", $first" else ""}! Tô aqui. Pode falar comigo."
            caption = hello
            phase = VoicePhase.SPEAKING
            scope.launch {
                if (memory.speakReplies) speaker.speak(hello) { phase = VoicePhase.SPEAKING }
                if (!leaving) startListening()
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            leaving = true
            listenerHolder[0]?.stop()
            speaker.release()
        }
    }

    // Energia da esfera conforme o estado
    var time by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { now -> time = (now - start) / 1_000_000_000f }
        }
    }
    val targetEnergy = when (phase) {
        VoicePhase.IDLE -> 0.06f
        VoicePhase.LISTENING -> 0.18f + micLevel * 0.8f
        VoicePhase.THINKING -> 0.22f + 0.12f * sin(time * 4f)
        VoicePhase.SPEAKING -> 0.45f + 0.3f * sin(time * 9f) * sin(time * 3.3f)
    }
    val energy by animateFloatAsState(targetEnergy, tween(180), label = "energy")

    Box(
        Modifier.fillMaxSize().background(Brush.radialGradient(listOf(V_BG_CENTER, V_BG_EDGE), radius = 1400f)),
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Cris", color = V_TEXT, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    Text("conversa por voz", color = V_MUTED, fontSize = 13.sp)
                }
                Text(
                    if (memory.speakReplies) "Voz ligada" else "Voz desligada",
                    color = V_MUTED, fontSize = 12.sp,
                    modifier = Modifier
                        .padding(end = 10.dp)
                        .clickable {
                            scope.launch {
                                memory = memory.copy(speakReplies = !memory.speakReplies)
                                CrisPrefs.saveMemory(context, memory)
                                if (!memory.speakReplies) speaker.stop()
                            }
                        },
                )
                RoundIcon(Icons.Filled.Close, "Fechar") { leaving = true; listenerHolder[0]?.stop(); speaker.stop(); nav.popBackStack() }
            }

            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Canvas(
                    Modifier.fillMaxWidth().aspectRatio(1f).padding(24.dp)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onOrbTap() },
                ) {
                    // Grade de fundo
                    val step = 36.dp.toPx()
                    var gx = 0f
                    while (gx <= size.width) { drawLine(V_GRID, Offset(gx, 0f), Offset(gx, size.height), 1f); gx += step }
                    var gy = 0f
                    while (gy <= size.height) { drawLine(V_GRID, Offset(0f, gy), Offset(size.width, gy), 1f); gy += step }

                    val cx = size.width / 2
                    val cy = size.height / 2
                    val baseR = size.minDimension * 0.36f
                    // Halo que “respira” com a energia da voz (violeta → lilás)
                    drawCircle(V_DOT_ACCENT.copy(alpha = 0.06f + energy * 0.12f), baseR * (1.28f + energy * 0.18f), Offset(cx, cy))
                    drawCircle(V_DOT_WARM.copy(alpha = 0.04f + energy * 0.10f), baseR * (1.18f + energy * 0.12f), Offset(cx, cy))
                    drawCircle(V_DOT.copy(alpha = 0.12f), baseR * 1.48f, Offset(cx, cy), style = androidx.compose.ui.graphics.drawscope.Stroke(1.4f))

                    // Gira mais rápido ao ouvir/falar; onda de superfície acompanha a energia
                    val rotY = time * (0.40f + energy * 0.55f)
                    val tilt = 0.38f + 0.10f * sin(time * 0.35f) + energy * 0.06f * sin(time * 2.1f)
                    val cosY = cos(rotY); val sinY = sin(rotY)
                    val cosX = cos(tilt); val sinX = sin(tilt)
                    val dot = 2.6.dp.toPx()
                    val projected = SPHERE.map { p ->
                        val wave = 1f +
                            energy * 0.28f * sin(p.lon * 3f + p.y * 4f + time * 3.6f) +
                            energy * 0.12f * sin(p.y * 9f - time * 5.5f) +
                            energy * 0.06f * sin(p.lon * 7f + time * 4.2f)
                        val x0 = p.x * wave; val y0 = p.y * wave; val z0 = p.z * wave
                        val x1 = x0 * cosY + z0 * sinY
                        val z1 = -x0 * sinY + z0 * cosY
                        val y2 = y0 * cosX - z1 * sinX
                        val z2 = y0 * sinX + z1 * cosX
                        floatArrayOf(x1, y2, z2, p.tint.toFloat())
                    }.sortedBy { it[2] }
                    projected.forEach { a ->
                        val persp = 2.6f / (2.6f - a[2])
                        val px = cx + a[0] * baseR * persp
                        val py = cy + a[1] * baseR * persp
                        val depth = (a[2] + 1f) / 2f
                        val alpha = 0.12f + depth * 0.88f
                        val tint = a[3].toInt()
                        val c = when (tint) {
                            2 -> V_DOT_WARM
                            1 -> V_DOT_ACCENT
                            else -> V_DOT
                        }
                        // Pontos blush/violeta “pulam” um pouco mais quando há energia de voz
                        val pulse = if (tint > 0) 1f + energy * 0.35f else 1f + energy * 0.12f
                        val r = dot * (0.45f + depth * 0.9f) * persp * pulse
                        if (depth > 0.7f) drawCircle(c.copy(alpha = alpha * 0.28f), r * 2.5f, Offset(px, py))
                        drawCircle(c.copy(alpha = alpha), r, Offset(px, py))
                    }
                }
            }

            // Legenda
            Column(Modifier.fillMaxWidth().padding(horizontal = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                val shown = when (phase) {
                    VoicePhase.LISTENING -> userLine
                    VoicePhase.THINKING -> userLine.ifBlank { caption }
                    else -> caption
                }
                val clipped = if (shown.length > 170) "…" + shown.takeLast(170).substringAfter(" ") else shown
                val words = clipped.trim().split(" ")
                Text(
                    buildAnnotatedString {
                        if (words.size > 1 && phase != VoicePhase.LISTENING) {
                            append(words.dropLast(1).joinToString(" ") + " ")
                            withStyle(SpanStyle(color = V_ACCENT)) { append(words.last()) }
                        } else {
                            append(clipped)
                        }
                    },
                    color = V_TEXT,
                    fontSize = if (clipped.length > 90) 20.sp else 26.sp,
                    lineHeight = if (clipped.length > 90) 27.sp else 33.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.heightIn(min = 70.dp),
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    when (phase) {
                        VoicePhase.IDLE -> if (micGranted) "Toque na esfera para falar" else "Toque para permitir o microfone"
                        VoicePhase.LISTENING -> "Ouvindo…"
                        VoicePhase.THINKING -> "Pensando…"
                        VoicePhase.SPEAKING -> "Falando · toque para interromper"
                    },
                    color = V_MUTED,
                    fontSize = 14.sp,
                )
                hint?.let { Text(it, color = Color(0xFFFFC48A), fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp)) }
            }

            if (!micGranted) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp).clip(RoundedCornerShape(18.dp)).background(V_PANEL).padding(16.dp),
                ) {
                    Text("Para conversar por voz", color = V_TEXT, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("A Cris usa o microfone só enquanto você fala com ela. Nada é gravado no aparelho.", color = V_MUTED, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    Text(
                        if (micBlocked) "Abrir configurações" else "Permitir microfone",
                        color = V_BG_EDGE,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(top = 12.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(V_ACCENT)
                            .clickable {
                                if (micBlocked) {
                                    context.startActivity(
                                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                                    )
                                } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            }
                            .padding(vertical = 14.dp),
                        textAlign = TextAlign.Center,
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RoundIcon(Icons.AutoMirrored.Filled.Chat, "Ver conversa") { leaving = true; nav.popBackStack() }
                Box(
                    Modifier.size(76.dp).clip(CircleShape)
                        .background(if (phase == VoicePhase.LISTENING) V_ACCENT else V_PANEL)
                        .border(2.dp, V_ACCENT.copy(alpha = 0.6f), CircleShape)
                        .clickable { onOrbTap() },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (phase == VoicePhase.LISTENING || phase == VoicePhase.SPEAKING) Icons.Filled.Stop else Icons.Filled.Mic,
                        "Falar",
                        tint = if (phase == VoicePhase.LISTENING) V_BG_EDGE else V_TEXT,
                        modifier = Modifier.size(34.dp),
                    )
                }
                Spacer(Modifier.size(52.dp))
            }
        }
    }
}

@Composable
private fun RoundIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(52.dp).clip(CircleShape).background(V_PANEL.copy(alpha = 0.7f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, label, tint = V_TEXT)
    }
}
