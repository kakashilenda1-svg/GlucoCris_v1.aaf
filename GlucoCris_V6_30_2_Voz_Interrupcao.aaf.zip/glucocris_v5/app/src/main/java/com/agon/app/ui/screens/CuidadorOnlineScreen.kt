package com.agon.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.cloud.CuidadorCarePlan
import com.agon.app.cloud.CuidadorCloud
import com.agon.app.cloud.CuidadorLink
import com.agon.app.cloud.CuidadorOnline
import com.agon.app.cloud.CuidadorPrefs
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.formatDateTime
import com.agon.app.reminders.Caregiver
import com.agon.app.ui.components.BackTitle
import com.agon.app.ui.components.ConfirmDialog
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GField
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * "Cuidador online": liga o Gluco Cris ao app Gluco Cris Cuidador (outra pessoa acompanha, com a SUA permissão).
 * Diferente do "Modo cuidador" por SMS/WhatsApp, aqui os dados vão para o servidor (Firebase) e o cuidador os vê no app dele.
 */
@Composable
fun CuidadorOnlineScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val data by vm.data.collectAsStateWithLifecycle()

    var enabled by remember { mutableStateOf(CuidadorPrefs.enabled(ctx)) }
    var askEnable by remember { mutableStateOf(false) }
    var askDeleteAll by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf("") }
    var pairing by remember { mutableStateOf<String?>(null) }
    var secondsLeft by remember { mutableStateOf(0) }
    var busy by remember { mutableStateOf(false) }
    var approveFor by remember { mutableStateOf<com.agon.app.cloud.CuidadorRequest?>(null) }
    var editPerms by remember { mutableStateOf<CuidadorLink?>(null) }
    var askRevoke by remember { mutableStateOf<CuidadorLink?>(null) }
    var plan by remember { mutableStateOf(CuidadorCarePlan()) }
    var shareContact by remember { mutableStateOf(CuidadorPrefs.shareContact(ctx)) }
    val signedIn = CuidadorCloud.uid() != null

    val requests by remember(enabled) { CuidadorCloud.observeRequests() }.collectAsState(initial = emptyList())
    val links by remember(enabled) { CuidadorCloud.observeLinks() }.collectAsState(initial = emptyList())

    LaunchedEffect(enabled) { if (enabled && signedIn) plan = CuidadorCloud.loadCarePlan() }
    LaunchedEffect(pairing) {
        if (pairing != null) {
            secondsLeft = 10 * 60
            while (secondsLeft > 0) { delay(1000); secondsLeft-- }
            pairing = null
        }
    }

    ScrollScreen {
        BackTitle("Cuidador online", { nav.popBackStack() })
        Text(
            "Deixe uma pessoa de confiança acompanhar sua glicemia no app Gluco Cris Cuidador, em tempo quase real. " +
                "Você escolhe quem e o que cada pessoa pode ver, e pode retirar o acesso quando quiser.",
            color = g.muted, fontSize = 13.sp,
        )

        if (!signedIn) {
            GCard(Modifier.padding(top = 8.dp)) {
                Text("Entre na sua conta primeiro", color = g.ink, fontWeight = FontWeight.Bold)
                Text(
                    "O compartilhamento usa a mesma conta do backup (Google ou e-mail e senha). Entre nela e volte aqui.",
                    color = g.muted, fontSize = 13.sp,
                )
            }
        }

        GCard(Modifier.padding(top = 8.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Compartilhar com o app Cuidador", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Desligado, nada é enviado para o servidor do Cuidador.", color = g.muted, fontSize = 12.sp)
                }
                Switch(checked = enabled, onCheckedChange = {
                    if (it) askEnable = true
                    else { enabled = false; CuidadorPrefs.setEnabled(ctx, false); pairing = null }
                }, enabled = signedIn)
            }
        }

        if (enabled && signedIn) {
            GCard(Modifier.padding(top = 8.dp)) {
                Text("Estado", color = g.ink, fontWeight = FontWeight.Bold)
                val last = CuidadorPrefs.lastOk(ctx)
                Text(
                    if (last > 0) "Última sincronização: ${formatDateTime(last)}" else "Ainda não sincronizou.",
                    color = g.muted, fontSize = 13.sp,
                )
                val err = CuidadorPrefs.lastMsg(ctx)
                if (err.isNotBlank()) Text(err, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                PrimaryButton("Sincronizar agora", g.violet, {
                    vm.syncNow(); info = "Sincronização pedida. Se estiver sem internet, o app tenta de novo sozinho."
                }, Modifier.padding(top = 8.dp))
                PrimaryButton("Estou bem ✔", g.green, {
                    scope.launch {
                        info = CuidadorCloud.estouBem().fold({ "Seu cuidador foi avisado de que você está bem." }, { CuidadorCloud.friendly(it) })
                    }
                }, Modifier.padding(top = 8.dp))
                if (info.isNotBlank()) Text(info, color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }

            SectionTitle("Convidar um cuidador")
            GCard {
                Text(
                    "Gere um código e passe para o cuidador. Ele digita no app Gluco Cris Cuidador; depois você aprova aqui e escolhe o que ele vê.",
                    color = g.muted, fontSize = 13.sp,
                )
                val code = pairing
                if (code != null) {
                    Text(code.chunked(4).joinToString(" "), color = g.violet, fontSize = 32.sp, fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(top = 8.dp))
                    Text("Vale por ${secondsLeft / 60}:${(secondsLeft % 60).toString().padStart(2, '0')} e só pode ser usado uma vez.", color = g.muted, fontSize = 12.sp)
                }
                PrimaryButton(if (code == null) "Gerar código" else "Gerar outro código", g.violet, {
                    if (!busy) scope.launch {
                        busy = true
                        CuidadorCloud.newPairingCode().fold({ pairing = it.code; info = "" }, { info = CuidadorCloud.friendly(it) })
                        busy = false
                    }
                }, Modifier.padding(top = 8.dp))
            }

            if (requests.isNotEmpty()) {
                SectionTitle("Pedidos de acesso")
                requests.forEach { r ->
                    GCard(Modifier.padding(bottom = 8.dp)) {
                        Text(r.name.ifBlank { "Cuidador" }, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        if (r.email.isNotBlank()) Text(r.email, color = g.muted, fontSize = 12.sp)
                        if (r.relation.isNotBlank()) Text("Relação: ${r.relation}", color = g.muted, fontSize = 12.sp)
                        Text("Só aprove se você reconhece esta pessoa.", color = g.orange, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PrimaryButton("Escolher o que ver", g.green, { approveFor = r }, Modifier.weight(1f))
                            PrimaryButton("Recusar", g.red, {
                                scope.launch { info = CuidadorCloud.respond(r.uid, false, emptySet()).fold({ "Pedido recusado." }, { CuidadorCloud.friendly(it) }) }
                            }, Modifier.weight(1f))
                        }
                    }
                }
            }

            SectionTitle("Cuidadores com acesso")
            if (links.isEmpty()) Text("Ninguém ainda.", color = g.muted, fontSize = 13.sp)
            links.forEach { l ->
                GCard(Modifier.padding(bottom = 8.dp)) {
                    Text(l.name.ifBlank { l.email.ifBlank { "Cuidador" } }, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    val shown = CuidadorOnline.PERMISSIONS.filter { l.permissions[it.first] == true }.joinToString(", ") { it.second }
                    Text(if (shown.isBlank()) "Sem nenhuma permissão." else "Pode ver: $shown", color = g.muted, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { editPerms = l }) { Text("Permissões") }
                        TextButton(onClick = { askRevoke = l }) { Text("Retirar acesso", color = g.red) }
                    }
                }
            }

            SectionTitle("Plano de ação (o cuidador vê, se você permitir)")
            GCard {
                GField("Se a glicemia estiver baixa", plan.lowGlucose, { plan = plan.copy(lowGlucose = it.take(1000)) }, "Ex.: 15 g de açúcar e medir de novo em 15 min")
                GField("Se estiver alta", plan.highGlucose, { plan = plan.copy(highGlucose = it.take(1000)) }, "Ex.: beber água e seguir o plano da equipe de saúde")
                GField("Quando chamar emergência", plan.emergencyWhen, { plan = plan.copy(emergencyWhen = it.take(1000)) }, "Ex.: desmaio ou confusão — ligar 192")
                GField("Combinado com a equipe de saúde", plan.agreed, { plan = plan.copy(agreed = it.take(1000)) }, "")
                Text("O app não calcula nem indica dose de insulina ou remédio. Use o que sua equipe de saúde orientou.", color = g.muted, fontSize = 11.sp)
                PrimaryButton("Salvar plano", g.violet, {
                    scope.launch { info = CuidadorCloud.saveCarePlan(plan).fold({ "Plano salvo." }, { CuidadorCloud.friendly(it) }) }
                }, Modifier.padding(top = 6.dp))
                if (Caregiver.phoneValid(ctx)) {
                    Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Mostrar meu contato de confiança", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${Caregiver.name(ctx).ifBlank { "Contato" }} aparece como contato de emergência.", color = g.muted, fontSize = 12.sp)
                        }
                        Switch(checked = shareContact, onCheckedChange = { on ->
                            shareContact = on; CuidadorPrefs.setShareContact(ctx, on)
                            scope.launch {
                                CuidadorCloud.setEmergencyContact(Caregiver.name(ctx), Caregiver.phone(ctx), on)
                                    .onFailure { info = CuidadorCloud.friendly(it) }
                            }
                        })
                    }
                }
            }

            SectionTitle("Privacidade")
            GCard {
                Text(
                    "Ao ligar, suas glicemias (valor, hora, se veio do sensor ou foi digitada), seus limites, o nome de exibição e os exames de HbA1c " +
                        "ficam num servidor do Firebase para o cuidador ver. Insulina, refeições, sintomas, CPF e conversas com a Cris NÃO são enviados.",
                    color = g.muted, fontSize = 12.sp,
                )
                Text(
                    "Leituras já enviadas não são apagadas quando você edita ou exclui a glicemia no app; para apagar tudo do servidor use o botão abaixo.",
                    color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
                )
                PrimaryButton("Apagar tudo que compartilhei", g.red, { askDeleteAll = true }, Modifier.padding(top = 8.dp))
            }
            Text(
                "Não substitui os alarmes do seu sensor nem o socorro: em emergência, ligue 192 (SAMU). O aviso ao cuidador depende de internet e de o celular enviar os dados.",
                color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 10.dp),
            )
        }
    }

    if (askEnable) {
        ConfirmDialog(
            "Compartilhar com o app Cuidador?",
            "Suas glicemias e seus limites passarão a ser enviados ao servidor do Firebase, e só quem você aprovar poderá ver. " +
                "Você pode desligar e apagar tudo quando quiser.",
            "Ativar",
            {
                askEnable = false; enabled = true; CuidadorPrefs.setEnabled(ctx, true); vm.syncNow()
            },
            { askEnable = false },
        )
    }
    if (askDeleteAll) {
        ConfirmDialog(
            "Apagar tudo que foi compartilhado?",
            "Remove do servidor suas glicemias compartilhadas, plano, contatos e todos os vínculos. Seu backup pessoal e os dados do app não são tocados. Não dá para desfazer.",
            "Apagar",
            {
                askDeleteAll = false
                scope.launch {
                    CuidadorCloud.deleteSharedData(ctx).fold(
                        { enabled = false; CuidadorPrefs.setEnabled(ctx, false); info = "Tudo foi apagado do servidor e o compartilhamento foi desligado." },
                        { info = CuidadorCloud.friendly(it) },
                    )
                }
            },
            { askDeleteAll = false },
        )
    }
    approveFor?.let { r ->
        PermissionsDialog("O que ${r.name.ifBlank { "o cuidador" }} pode ver?", CuidadorOnline.PRESET_BASIC, "Aprovar", {
            approveFor = null
        }) { perms ->
            approveFor = null
            scope.launch { info = CuidadorCloud.respond(r.uid, true, perms).fold({ "Acesso aprovado." }, { CuidadorCloud.friendly(it) }) }
        }
    }
    editPerms?.let { l ->
        PermissionsDialog("Permissões de ${l.name.ifBlank { "cuidador" }}", l.permissions.filterValues { it }.keys, "Salvar", {
            editPerms = null
        }) { perms ->
            editPerms = null
            scope.launch { info = CuidadorCloud.setPermissions(l.uid, perms).fold({ "Permissões atualizadas." }, { CuidadorCloud.friendly(it) }) }
        }
    }
    askRevoke?.let { l ->
        ConfirmDialog(
            "Retirar o acesso de ${l.name.ifBlank { "este cuidador" }}?",
            "Ele deixa de ver seus dados na hora. Para voltar, será preciso um novo código e uma nova aprovação.",
            "Retirar",
            {
                askRevoke = null
                scope.launch { info = CuidadorCloud.revoke(l.uid).fold({ "Acesso retirado." }, { CuidadorCloud.friendly(it) }) }
            },
            { askRevoke = null },
        )
    }
}

@Composable
private fun PermissionsDialog(
    title: String,
    initial: Set<String>,
    confirmText: String,
    onDismiss: () -> Unit,
    onConfirm: (Set<String>) -> Unit,
) {
    val g = glucoColors()
    var sel by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) {
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton(onClick = { sel = CuidadorOnline.PRESET_BASIC }) { Text("Básico") }
                    TextButton(onClick = { sel = CuidadorOnline.PRESET_FULL }) { Text("Tudo") }
                    TextButton(onClick = { sel = emptySet() }) { Text("Nada") }
                }
                Text("Básico: glicemia atual, tendência e alertas.", color = g.muted, fontSize = 11.sp)
                CuidadorOnline.PERMISSIONS.forEach { (key, label) ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = key in sel, onCheckedChange = { on -> sel = if (on) sel + key else sel - key })
                        Text(label, color = g.ink, fontSize = 14.sp)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(sel) }) { Text(confirmText) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}
