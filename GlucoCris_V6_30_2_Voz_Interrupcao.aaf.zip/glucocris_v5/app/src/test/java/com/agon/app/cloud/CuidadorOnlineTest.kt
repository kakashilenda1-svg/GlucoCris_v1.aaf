package com.agon.app.cloud

import com.agon.app.data.GlucoseEntry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CuidadorOnlineTest {
    private val now = 1_800_000_000_000L
    private fun e(id: String, v: Double, at: Long, unit: String = "mg/dL") = GlucoseEntry(id, v, unit, at, "outro")

    @Test fun origemDaLeitura() {
        assertEquals("cgm", CuidadorOnline.sourceOf("sensor-libre-123"))
        assertEquals("cgm", CuidadorOnline.sourceOf("sensor-dexcom-9"))
        assertEquals("manual", CuidadorOnline.sourceOf("ble-AA-1-2"))
        assertEquals("manual", CuidadorOnline.sourceOf("3f2c9a1e-0000-4000-8000-000000000000"))
        assertEquals("libre", CuidadorOnline.deviceOf("sensor-libre-123"))
        assertEquals("bluetooth", CuidadorOnline.deviceOf("ble-AA-1-2"))
        assertNull(CuidadorOnline.deviceOf("abc"))
    }

    @Test fun valorEmMgDlInteiroDentroDaFaixaDasRegras() {
        assertEquals(120, CuidadorOnline.readingMg(e("a", 120.4, now)))
        assertEquals(99, CuidadorOnline.readingMg(e("a", 5.5, now, "mmol/L")))
        assertNull(CuidadorOnline.readingMg(e("a", 19.0, now)))
        assertNull(CuidadorOnline.readingMg(e("a", 601.0, now)))
        assertEquals(20, CuidadorOnline.readingMg(e("a", 20.0, now)))
        assertEquals(600, CuidadorOnline.readingMg(e("a", 600.0, now)))
    }

    @Test fun pendentesIgnoramDemoEnviadasInvalidasFuturasEAntigas() {
        val list = listOf(
            e("demo-1", 100.0, now - 60_000),
            e("ok-novo", 110.0, now - 60_000),
            e("ok-velho", 90.0, now - 3_600_000),
            e("ja-enviada", 95.0, now - 120_000),
            e("fora-da-faixa", 10.0, now - 120_000),
            e("muito-antiga", 100.0, now - 10 * 3_600_000L),
            e("futura", 100.0, now + 3_600_000L),
        )
        val r = CuidadorOnline.pending(list, setOf("ja-enviada"), now, CuidadorOnline.MAX_PENDING_MS)
        assertEquals(listOf("ok-velho", "ok-novo"), r.map { it.id }) // mais antiga primeiro
    }

    @Test fun primeiraAtivacaoUsaJanelaCurta() {
        val list = listOf(e("a", 100.0, now - 2 * 3_600_000L), e("b", 100.0, now - 4 * 3_600_000L))
        assertEquals(listOf("a"), CuidadorOnline.pending(list, emptySet(), now, CuidadorOnline.FIRST_BACKFILL_MS).map { it.id })
    }

    @Test fun limitesSempreCoerentes() {
        val ok = CuidadorOnline.thresholds(70, 180, 54, 300)
        assertEquals(54, ok["urgentLow"]); assertEquals(70, ok["low"]); assertEquals(70, ok["targetLow"])
        assertEquals(180, ok["high"]); assertEquals(180, ok["targetHigh"]); assertEquals(300, ok["urgentHigh"])
        // limite "grave baixo" configurado acima da meta: força urgentLow < low
        val bad = CuidadorOnline.thresholds(70, 180, 80, 150)
        assertTrue(bad["urgentLow"]!! < bad["low"]!!)
        assertTrue(bad["urgentHigh"]!! > bad["high"]!!)
    }

    @Test fun estadoDoCgm() {
        assertEquals("disconnected", CuidadorOnline.cgmState(false, 0, now, 15))
        assertEquals("no_readings", CuidadorOnline.cgmState(true, 0, now, 15))
        assertEquals("ok", CuidadorOnline.cgmState(true, now - 20 * 60_000, now, 15))
        assertEquals("no_readings", CuidadorOnline.cgmState(true, now - 60 * 60_000, now, 15))
    }

    @Test fun permissoesIguaisAsDoBackend() {
        val backend = setOf("currentGlucose","history","charts","cgm","trends","gmi","cgmCoverage","hba1cCurrent",
            "hba1cHistory","reports","alerts","diary","carePlan","emergencyContacts","extraInfo")
        assertEquals(backend, CuidadorOnline.PERMISSIONS.map { it.first }.toSet())
        assertTrue(CuidadorOnline.PRESET_BASIC.all { it in backend })
    }
}
