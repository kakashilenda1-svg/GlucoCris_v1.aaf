// Testes das regras: 2 pacientes (p1,p2) e 3 cuidadores (c1,c2,c3) com permissões diferentes.
// Executar: cd firebase && firebase emulators:exec --only firestore "npx mocha tests/rules.test.js --timeout 20000"
const fs = require("fs");
const { initializeTestEnvironment, assertFails, assertSucceeds } = require("@firebase/rules-unit-testing");
const { doc, getDoc, setDoc, updateDoc, deleteDoc, serverTimestamp, Timestamp } = require("firebase/firestore");
let env;
const P = (o) => Object.assign({ currentGlucose:false,history:false,charts:false,cgm:false,trends:false,gmi:false,cgmCoverage:false,
  hba1cCurrent:false,hba1cHistory:false,reports:false,alerts:false,diary:false,carePlan:false,emergencyContacts:false,extraInfo:false }, o);

before(async () => {
  env = await initializeTestEnvironment({ projectId: "glucocris-test", firestore: { rules: fs.readFileSync(__dirname + "/../firestore.rules", "utf8"), host: "127.0.0.1", port: 8080 } });
});
after(() => env.cleanup());
beforeEach(async () => {
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async (ctx) => {
    const f = ctx.firestore();
    for (const p of ["p1", "p2"]) {
      await setDoc(doc(f, `patients/${p}`), { displayName: p });
      await setDoc(doc(f, `patients/${p}/current/latest`), { value: 100 });
      await setDoc(doc(f, `patients/${p}/current/trend`), { arrow: "→" });
      await setDoc(doc(f, `patients/${p}/readings/r1`), { value: 100 });
      await setDoc(doc(f, `patients/${p}/hba1c/h1`), { value: 7 });
      await setDoc(doc(f, `patients/${p}/hba1cLatest/main`), { value: 7 });
      await setDoc(doc(f, `patients/${p}/stats/gmi`), { gmi: 7 });
      await setDoc(doc(f, `patients/${p}/alerts/a1`), { type: "hypo" });
      await setDoc(doc(f, `patients/${p}/carePlan/main`), { t: "x" });
    }
    const L = (p, c, perms, status = "active") => setDoc(doc(f, `patients/${p}/links/${c}`), { status, permissions: P(perms) });
    await L("p1", "c1", { currentGlucose: true, cgm: true, gmi: true, alerts: true });
    await L("p1", "c2", { currentGlucose: true, history: true, hba1cCurrent: true, hba1cHistory: true });
    await L("p1", "c3", { currentGlucose: true, alerts: true });
    await L("p2", "c1", { currentGlucose: true, history: true }); // c1 acompanha 2 pacientes com perms diferentes
  });
});
const as = (u) => env.authenticatedContext(u).firestore();
const g = (u, path) => getDoc(doc(as(u), path));

describe("multicuidador / permissões", () => {
  it("c1 lê glicemia atual e GMI de p1, mas não histórico nem HbA1c", async () => {
    await assertSucceeds(g("c1", "patients/p1/current/latest"));
    await assertSucceeds(g("c1", "patients/p1/stats/gmi"));
    await assertFails(g("c1", "patients/p1/readings/r1"));
    await assertFails(g("c1", "patients/p1/hba1cLatest/main"));
  });
  it("c2 lê histórico e HbA1c, mas não alertas nem GMI", async () => {
    await assertSucceeds(g("c2", "patients/p1/readings/r1"));
    await assertSucceeds(g("c2", "patients/p1/hba1c/h1"));
    await assertFails(g("c2", "patients/p1/alerts/a1"));
    await assertFails(g("c2", "patients/p1/stats/gmi"));
  });
  it("c3 só vê glicemia atual e alertas (sem tendência)", async () => {
    await assertSucceeds(g("c3", "patients/p1/current/latest"));
    await assertSucceeds(g("c3", "patients/p1/alerts/a1"));
    await assertFails(g("c3", "patients/p1/current/trend"));
    await assertFails(g("c3", "patients/p1/readings/r1"));
  });
  it("uma conta acompanha vários pacientes sem misturar permissões", async () => {
    await assertSucceeds(g("c1", "patients/p2/readings/r1"));   // permitido em p2
    await assertFails(g("c1", "patients/p1/readings/r1"));      // negado em p1
    await assertFails(g("c1", "patients/p2/alerts/a1"));        // negado em p2
  });
  it("cuidador sem vínculo não acessa nada; paciente não acessa outro paciente", async () => {
    await assertFails(g("c3", "patients/p2/current/latest"));
    await assertFails(g("p2", "patients/p1/current/latest"));
    await assertFails(g("outsider", "patients/p1"));
  });
  it("dono lê tudo dele", async () => { await assertSucceeds(g("p1", "patients/p1/readings/r1")); await assertSucceeds(g("p1", "patients/p1/hba1c/h1")); });
});

describe("revogação e alteração de permissões", () => {
  it("revogar impede novas consultas", async () => {
    await assertSucceeds(g("c1", "patients/p1/current/latest"));
    await env.withSecurityRulesDisabled((c) => updateDoc(doc(c.firestore(), "patients/p1/links/c1"), { status: "revoked" }));
    await assertFails(g("c1", "patients/p1/current/latest"));
    await assertFails(g("c1", "patients/p1"));
  });
  it("alterar permissões muda o acesso imediatamente", async () => {
    await assertFails(g("c3", "patients/p1/readings/r1"));
    await env.withSecurityRulesDisabled((c) => updateDoc(doc(c.firestore(), "patients/p1/links/c3"), { "permissions.history": true }));
    await assertSucceeds(g("c3", "patients/p1/readings/r1"));
  });
  it("cuidador não consegue se auto-conceder permissões nem criar vínculos", async () => {
    await assertFails(updateDoc(doc(as("c3"), "patients/p1/links/c3"), { "permissions.history": true }));
    await assertFails(setDoc(doc(as("evil"), "patients/p1/links/evil"), { status: "active", permissions: P({ history: true }) }));
  });
});

describe("escrita", () => {
  const rd = (o = {}) => ({ value: 120, unit: "mg/dL", source: "cgm", originTs: Timestamp.now(), serverTs: serverTimestamp(), ...o });
  it("paciente cria medição válida; valor absurdo e cuidador são negados", async () => {
    await assertSucceeds(setDoc(doc(as("p1"), "patients/p1/readings/new1"), rd()));
    await assertFails(setDoc(doc(as("p1"), "patients/p1/readings/bad"), rd({ value: 5 })));
    await assertFails(setDoc(doc(as("c1"), "patients/p1/readings/x"), rd()));
    await assertFails(setDoc(doc(as("p2"), "patients/p1/readings/x"), rd()));
  });
  it("medição é imutável (sem update/delete)", async () => {
    await assertFails(updateDoc(doc(as("p1"), "patients/p1/readings/r1"), { value: 300 }));
    await assertFails(deleteDoc(doc(as("p1"), "patients/p1/readings/r1")));
  });
  it("ack de alerta: só com permissão alerts e no próprio uid", async () => {
    const ack = (uid) => ({ uid, status: "following", ts: serverTimestamp() });
    await assertSucceeds(setDoc(doc(as("c3"), "patients/p1/alerts/a1/acks/c3"), ack("c3")));
    await assertFails(setDoc(doc(as("c3"), "patients/p1/alerts/a1/acks/c1"), ack("c1")));
    await assertFails(setDoc(doc(as("c2"), "patients/p1/alerts/a1/acks/c2"), ack("c2")));
  });
  it("diário é imutável e identifica o autor", async () => {
    await env.withSecurityRulesDisabled((c) => updateDoc(doc(c.firestore(), "patients/p1/links/c3"), { "permissions.diary": true }));
    const d = (a) => ({ authorUid: a, text: "tontura", ts: serverTimestamp() });
    await assertSucceeds(setDoc(doc(as("c3"), "patients/p1/diary/d1"), d("c3")));
    await assertFails(setDoc(doc(as("c3"), "patients/p1/diary/d2"), d("c1")));
    await assertFails(updateDoc(doc(as("c3"), "patients/p1/diary/d1"), { text: "outro" }));
  });
  it("cuidador não altera plano de ação nem limites do paciente", async () => {
    await assertFails(setDoc(doc(as("c1"), "patients/p1/carePlan/main"), { t: "y" }));
    await assertFails(updateDoc(doc(as("c1"), "patients/p1"), { thresholds: { low: 10 } }));
  });
  it("códigos de pareamento e auditoria inacessíveis ao cliente", async () => {
    await assertFails(g("p1", "pairingCodes/abc"));
    await assertFails(g("c1", "patients/p1/audit/x"));
  });
});
