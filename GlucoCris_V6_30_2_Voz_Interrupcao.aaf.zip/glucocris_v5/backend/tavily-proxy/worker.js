// Proxy do Gluco Cris para Tavily Search API + Google Gemini API (Cloudflare Workers).
// Chaves ficam SOMENTE aqui como segredos. O app nunca as recebe.
//
// Rotas:
//   POST /          ou POST /tavily  → Tavily Search (contrato original, inalterado)
//   POST /gemini                     → proxy Gemini generateContent
//
// Tavily contrato (app -> proxy):
//   { query, depth: "basic"|"advanced", maxResults, topic: "general"|"news",
//     timeRange?: "day"|"week"|"month", health?: boolean }
//   Resposta: { results: [{title,url,content,score,published_date}], usage: { credits } }
//
// Gemini contrato (app -> proxy):
//   Body = exatamente o JSON que iria para generativelanguage.googleapis.com
//   (.../models/{model}:generateContent), SEM a chave.
//   Header opcional: x-gemini-model (padrão: gemini-3.8-flash)
//   Header: x-app-token (se APP_TOKEN configurado)
//   Resposta: o JSON bruto do Google (candidates, etc.) ou { error, status }
//
// Segredos/vars:
//   TAVILY_API_KEY (obrigatório para /tavily) · GEMINI_API_KEY (obrigatório para /gemini)
//   APP_TOKEN (opcional) · MONTHLY_LIMIT · MONTHLY_RESERVE · USAGE (KV)
//   GEMINI_DAILY_LIMIT (padrão 2000 requisições/dia no worker, global)

const HEALTH_DOMAINS = [
  "*.gov.br", "who.int", "paho.org", "nih.gov", "pubmed.ncbi.nlm.nih.gov", "diabetes.org.br",
  "fiocruz.br", "cdc.gov", "diabetes.org", "idf.org", "scielo.br",
];
const COST = { basic: 1, advanced: 2 };

/** Modelos oficialmente permitidos (evitar abuso / modelos inexistentes). */
const ALLOWED_GEMINI_MODELS = new Set([
  "gemini-3.8-flash",
  "gemini-3.6-flash",
  "gemini-3.5-flash-lite",
  "gemini-3.1-flash-lite",
  "gemini-2.5-flash",
  "gemini-2.0-flash",
  "gemini-1.5-flash",
  "gemini-1.5-flash-8b",
]);

const MAX_GEMINI_BODY_BYTES = 8 * 1024 * 1024; // 8 MB (imagens/PDF base64)
const DEFAULT_GEMINI_MODEL = "gemini-3.8-flash";

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
    },
  });

const monthKey = () => "credits:" + new Date().toISOString().slice(0, 7);
const dayKey = () => "gemini:" + new Date().toISOString().slice(0, 10);

function pathOf(request) {
  try {
    const u = new URL(request.url);
    return (u.pathname || "/").replace(/\/+$/, "") || "/";
  } catch {
    return "/";
  }
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: {
          "access-control-allow-origin": "*",
          "access-control-allow-methods": "POST, OPTIONS",
          "access-control-allow-headers": "content-type, x-app-token, x-gemini-model",
          "access-control-max-age": "86400",
        },
      });
    }
    if (request.method !== "POST") return json({ error: "method" }, 405);

    if (env.APP_TOKEN && request.headers.get("x-app-token") !== env.APP_TOKEN) {
      return json({ error: "unauthorized" }, 401);
    }

    const path = pathOf(request);

    if (path === "/gemini") {
      return handleGemini(request, env);
    }
    // Tavily: raiz ou /tavily (compatível com o app atual que posta na raiz)
    if (path === "/" || path === "/tavily") {
      return handleTavily(request, env);
    }
    // FatSecret: busca de alimentos (chave fica so no servidor)
    if (path === "/fatsecret") {
      return handleFatSecret(request, env);
    }
    return json({ error: "not_found", path }, 404);
  },
};

// ─── Tavily (comportamento original, sem alterações de contrato) ─────────────

async function handleTavily(request, env) {
  if (!env.TAVILY_API_KEY) return json({ error: "not_configured" }, 500);

  let b;
  try {
    b = await request.json();
  } catch {
    return json({ error: "bad_json" }, 400);
  }
  const query = typeof b.query === "string" ? b.query.trim().slice(0, 200) : "";
  if (query.length < 2) return json({ error: "bad_query" }, 400);

  const depth = b.depth === "advanced" ? "advanced" : "basic";
  const topic = b.topic === "news" ? "news" : "general";
  const maxResults = Math.min(Math.max(parseInt(b.maxResults, 10) || 5, 1), 6);
  const timeRange = ["day", "week", "month"].includes(b.timeRange) ? b.timeRange : null;
  const cost = COST[depth];

  const limit = parseInt(env.MONTHLY_LIMIT || "1000", 10) - parseInt(env.MONTHLY_RESERVE || "50", 10);
  let used = 0;
  if (env.USAGE) {
    used = parseInt((await env.USAGE.get(monthKey())) || "0", 10);
    if (used + cost > limit) return json({ error: "quota" }, 429);
  }

  const payload = {
    query,
    search_depth: depth,
    max_results: maxResults,
    topic,
    language: "pt",
    include_answer: false,
    include_raw_content: false,
    include_images: false,
    include_favicon: false,
    include_usage: true,
    chunks_per_source: 1,
  };
  if (topic === "general") payload.country = "brazil";
  if (timeRange) payload.time_range = timeRange;
  if (b.health === true) {
    payload.include_domains = HEALTH_DOMAINS;
    payload.include_domains_mode = "prefer";
  }

  let r;
  try {
    r = await fetch("https://api.tavily.com/search", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: "Bearer " + env.TAVILY_API_KEY,
      },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(20000),
    });
  } catch {
    return json({ error: "upstream_unreachable" }, 504);
  }

  if (!r.ok) {
    return json(
      { error: "upstream", status: r.status },
      r.status === 401 ? 401 : r.status === 429 || r.status === 432 || r.status === 433 ? 429 : 502,
    );
  }

  const data = await r.json().catch(() => ({}));
  const credits = Number.isInteger(data?.usage?.credits) ? data.usage.credits : cost;
  if (env.USAGE) {
    await env.USAGE.put(monthKey(), String(used + credits), { expirationTtl: 60 * 60 * 24 * 62 });
  }

  const results = (Array.isArray(data.results) ? data.results : []).slice(0, maxResults).map((x) => ({
    title: x.title,
    url: x.url,
    content: x.content,
    score: x.score,
    published_date: x.published_date ?? null,
  }));
  return json({ results, usage: { credits } });
}

// ─── Gemini ──────────────────────────────────────────────────────────────────

async function handleGemini(request, env) {
  if (!env.GEMINI_API_KEY) return json({ error: "gemini_not_configured" }, 500);

  // Limite de tamanho do corpo (proteção contra abuso / OOM)
  const cl = request.headers.get("content-length");
  if (cl && parseInt(cl, 10) > MAX_GEMINI_BODY_BYTES) {
    return json({ error: "body_too_large", max: MAX_GEMINI_BODY_BYTES }, 413);
  }

  let bodyText;
  try {
    bodyText = await request.text();
  } catch {
    return json({ error: "bad_body" }, 400);
  }
  if (!bodyText || bodyText.length < 2) return json({ error: "empty_body" }, 400);
  if (bodyText.length > MAX_GEMINI_BODY_BYTES) {
    return json({ error: "body_too_large", max: MAX_GEMINI_BODY_BYTES }, 413);
  }

  let parsed;
  try {
    parsed = JSON.parse(bodyText);
  } catch {
    return json({ error: "bad_json" }, 400);
  }
  if (!parsed || typeof parsed !== "object" || !Array.isArray(parsed.contents)) {
    return json({ error: "invalid_gemini_payload" }, 400);
  }

  // Modelo: header x-gemini-model ou padrão; só lista branca
  let model = (request.headers.get("x-gemini-model") || DEFAULT_GEMINI_MODEL).trim();
  if (!ALLOWED_GEMINI_MODELS.has(model)) {
    model = DEFAULT_GEMINI_MODEL;
  }

  // Cota diária global opcional (KV)
  const dailyLimit = parseInt(env.GEMINI_DAILY_LIMIT || "2000", 10);
  if (env.USAGE && dailyLimit > 0) {
    const used = parseInt((await env.USAGE.get(dayKey())) || "0", 10);
    if (used >= dailyLimit) return json({ error: "gemini_quota" }, 429);
  }

  const url =
    "https://generativelanguage.googleapis.com/v1beta/models/" +
    encodeURIComponent(model) +
    ":generateContent";

  // Autenticação: chave como query (compatível com chaves AIza... e formatos novos AQ...)
  const target = url + "?key=" + encodeURIComponent(env.GEMINI_API_KEY);

  let r;
  try {
    r = await fetch(target, {
      method: "POST",
      headers: {
        "content-type": "application/json; charset=utf-8",
      },
      body: bodyText,
      signal: AbortSignal.timeout(90000),
    });
  } catch {
    return json({ error: "upstream_unreachable" }, 504);
  }

  // Contabiliza só respostas bem-sucedidas ou 429 (já consumiu cota do Google)
  if (env.USAGE && (r.ok || r.status === 429)) {
    const used = parseInt((await env.USAGE.get(dayKey())) || "0", 10);
    await env.USAGE.put(dayKey(), String(used + 1), { expirationTtl: 60 * 60 * 48 });
  }

  const raw = await r.text();
  // Repassa status e corpo do Google (app faz o parse). Não loga conteúdo.
  return new Response(raw, {
    status: r.status,
    headers: {
      "content-type": r.headers.get("content-type") || "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-gemini-model-used": model,
    },
  });
}


// ─── FatSecret (busca de alimentos) ──────────────────────────────────────────
// Segredos no Cloudflare: FATSECRET_CLIENT_ID e FATSECRET_CLIENT_SECRET.
// Corpo esperado: { "query": "arroz" }  ->  { "items": [ ... ] }

let fsToken = null; // cache em memoria do isolate
let fsTokenExp = 0;

async function fatSecretToken(env) {
  const now = Date.now();
  if (fsToken && now < fsTokenExp - 60000) return fsToken;
  const basic = btoa(env.FATSECRET_CLIENT_ID + ":" + env.FATSECRET_CLIENT_SECRET);
  const r = await fetch("https://oauth.fatsecret.com/connect/token", {
    method: "POST",
    headers: {
      authorization: "Basic " + basic,
      "content-type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials&scope=basic",
  });
  if (!r.ok) throw new Error("token_" + r.status);
  const j = await r.json();
  fsToken = j.access_token;
  fsTokenExp = now + (j.expires_in || 3600) * 1000;
  return fsToken;
}

// "Per 100g - Calories: 52kcal | Fat: 0.17g | Carbs: 13.81g | Protein: 0.26g"
function parseFatSecretDescription(d) {
  const num = (re) => {
    const m = re.exec(d || "");
    return m ? parseFloat(m[1].replace(",", ".")) : 0;
  };
  const per = /^\s*(?:Per|Por)\s+([^-]+?)\s*-/i.exec(d || "");
  const serving = per ? per[1].trim() : "100g";
  const g = /(\d+(?:[.,]\d+)?)\s*g\b/i.exec(serving);
  return {
    serving,
    grams: g ? parseFloat(g[1].replace(",", ".")) : 100,
    kcal: num(/Calories:\s*([\d.,]+)/i) || num(/Calorias:\s*([\d.,]+)/i),
    fat: num(/Fat:\s*([\d.,]+)/i) || num(/Gord[^:]*:\s*([\d.,]+)/i),
    carbs: num(/Carbs:\s*([\d.,]+)/i) || num(/Carb[^:]*:\s*([\d.,]+)/i),
    protein: num(/Protein:\s*([\d.,]+)/i) || num(/Prote[^:]*:\s*([\d.,]+)/i),
  };
}

// OAuth 1.0 (sem restricao de IP): usado quando FATSECRET_CONSUMER_KEY/SECRET existem.
const rfc3986 = (v) =>
  encodeURIComponent(String(v)).replace(/[!'()*]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase());

async function fatSecretOAuth1Search(env, query) {
  const url = "https://platform.fatsecret.com/rest/server.api";
  const params = {
    method: "foods.search",
    search_expression: query,
    format: "json",
    max_results: "20",
    oauth_consumer_key: env.FATSECRET_CONSUMER_KEY,
    oauth_nonce: crypto.randomUUID().replace(/-/g, ""),
    oauth_signature_method: "HMAC-SHA1",
    oauth_timestamp: String(Math.floor(Date.now() / 1000)),
    oauth_version: "1.0",
  };
  const norm = Object.keys(params)
    .sort()
    .map((k) => rfc3986(k) + "=" + rfc3986(params[k]))
    .join("&");
  const base = "GET&" + rfc3986(url) + "&" + rfc3986(norm);
  const keyData = new TextEncoder().encode(rfc3986(env.FATSECRET_CONSUMER_SECRET) + "&");
  const key = await crypto.subtle.importKey("raw", keyData, { name: "HMAC", hash: "SHA-1" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(base));
  const sigB64 = btoa(String.fromCharCode(...new Uint8Array(sig)));
  return fetch(url + "?" + norm + "&oauth_signature=" + rfc3986(sigB64));
}

async function handleFatSecret(request, env) {
  const useOAuth1 = !!(env.FATSECRET_CONSUMER_KEY && env.FATSECRET_CONSUMER_SECRET);
  if (!useOAuth1 && !(env.FATSECRET_CLIENT_ID && env.FATSECRET_CLIENT_SECRET)) {
    return json({ error: "fatsecret_not_configured" }, 500);
  }
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "bad_json" }, 400);
  }
  const query = String((body && body.query) || "").trim().slice(0, 100);
  if (!query) return json({ items: [] });

  try {
    let r;
    if (useOAuth1) {
      r = await fatSecretOAuth1Search(env, query);
    } else {
      const token = await fatSecretToken(env);
      const params = new URLSearchParams({
        search_expression: query,
        format: "json",
        max_results: "20",
      });
      r = await fetch("https://platform.fatsecret.com/rest/foods/search/v1?" + params, {
        headers: { authorization: "Bearer " + token },
      });
    }
    const text = await r.text();
    if (!r.ok) return json({ error: "fatsecret_http_" + r.status, detail: text.slice(0, 300) }, 502);
    const j = JSON.parse(text);
    if (j.error) return json({ error: "fatsecret_api", detail: j.error }, 502);
    let foods = (j.foods && j.foods.food) || [];
    if (!Array.isArray(foods)) foods = [foods]; // 1 resultado vem como objeto
    const items = foods.map((f) => {
      const n = parseFatSecretDescription(f.food_description);
      return {
        id: String(f.food_id),
        name: f.food_name || "",
        brand: f.brand_name || "",
        generic: f.food_type === "Generic",
        ...n,
      };
    }).filter((x) => x.name && (x.kcal > 0 || x.carbs > 0));
    return json({ items });
  } catch (e) {
    return json({ error: "fatsecret_failed", detail: String(e && e.message || e).slice(0, 200) }, 502);
  }
}
