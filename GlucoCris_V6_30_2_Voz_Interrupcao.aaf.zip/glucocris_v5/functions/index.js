/* GlucoCris — Cloud Functions (Node 20, firebase-functions v6).
 * Toda escrita de vínculo/permissão/auditoria passa por aqui (Admin SDK). */
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { onDocumentCreated, onDocumentWritten } = require("firebase-functions/v2/firestore");
const { onSchedule } = require("firebase-functions/v2/scheduler");
const admin = require("firebase-admin");
const crypto = require("crypto");

admin.initializeApp();
const db = admin.firestore();
const FV = admin.firestore.FieldValue;
const TS = admin.firestore.Timestamp;
const REGION = "southamerica-east1";
const opts = { region: REGION };

const PERMS = ["currentGlucose","history","charts","cgm","trends","gmi","cgmCoverage","hba1cCurrent",
  "hba1cHistory","reports","alerts","diary","carePlan","emergencyContacts","extraInfo"];
const DEFAULT_TH = { urgentLow: 54, low: 70, targetLow: 70, targetHigh: 180, high: 180, urgentHigh: 250 };
const CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // sem 0/O/1/I
const CODE_TTL_MIN = 10;

const sha = (s) => crypto.createHash("sha256").update(s).digest("hex");
const need = (c, m) => { if (!c) throw new HttpsError("invalid-argument", m); };
const authed = (req) => { if (!req.auth) throw new HttpsError("unauthenticated", "Login necessário"); return req.auth.uid; };

function cleanPerms(p) {
  const out = {};
  for (const k of PERMS) out[k] = !!(p && p[k] === true);
  return out;
}
const audit = (pid, entry) => db.collection(`patients/${pid}/audit`).add({ ...entry, ts: FV.serverTimestamp() });

async function mirror(cuid, pid, data) {
  await db.doc(`users/${cuid}/patients/${pid}`).set({ patientId: pid, ...data, updatedAt: FV.serverTimestamp() }, { merge: true });
}

/* ---------- PAREAMENTO ---------- */
exports.createPairingCode = onCall(opts, async (req) => {
  const pid = authed(req);
  const active = await db.collection("pairingCodes").where("pid", "==", pid)
    .where("expiresAt", ">", TS.now()).get();
  if (active.size >= 5) throw new HttpsError("resource-exhausted", "Muitos códigos ativos");
  let code = "";
  const bytes = crypto.randomBytes(8);
  for (let i = 0; i < 8; i++) code += CODE_ALPHABET[bytes[i] % CODE_ALPHABET.length];
  await db.doc(`pairingCodes/${sha(code)}`).set({
    pid, usesLeft: 1, createdAt: FV.serverTimestamp(),
    expiresAt: TS.fromMillis(Date.now() + CODE_TTL_MIN * 60000),
  });
  await audit(pid, { type: "pairing_code_created", by: pid });
  return { code, qrPayload: `glucocris://pair?c=${code}`, expiresInMin: CODE_TTL_MIN };
});

exports.revokePairingCodes = onCall(opts, async (req) => {
  const pid = authed(req);
  const s = await db.collection("pairingCodes").where("pid", "==", pid).get();
  const b = db.batch(); s.forEach((d) => b.delete(d.ref)); await b.commit();
  return { revoked: s.size };
});

exports.requestAccess = onCall(opts, async (req) => {
  const uid = authed(req);
  const code = String(req.data.code || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
  need(code.length === 8, "Código inválido");
  // anti força-bruta: 10 tentativas/hora por conta
  const att = db.doc(`users/${uid}/meta/attempts`);
  await db.runTransaction(async (t) => {
    const a = await t.get(att);
    const d = a.exists ? a.data() : { n: 0, windowStart: Date.now() };
    if (Date.now() - d.windowStart > 3600000) { d.n = 0; d.windowStart = Date.now(); }
    if (d.n >= 10) throw new HttpsError("resource-exhausted", "Muitas tentativas. Tente mais tarde.");
    t.set(att, { n: d.n + 1, windowStart: d.windowStart });
  });
  const ref = db.doc(`pairingCodes/${sha(code)}`);
  const pid = await db.runTransaction(async (t) => {
    const s = await t.get(ref);
    if (!s.exists) throw new HttpsError("not-found", "Código inválido ou expirado");
    const c = s.data();
    if (c.expiresAt.toMillis() < Date.now() || c.usesLeft < 1) throw new HttpsError("not-found", "Código inválido ou expirado");
    t.update(ref, { usesLeft: c.usesLeft - 1 });
    return c.pid;
  });
  if (pid === uid) throw new HttpsError("failed-precondition", "Não é possível seguir a si mesmo");
  const user = await admin.auth().getUser(uid);
  const name = String(req.data.displayName || user.displayName || user.email || "Cuidador").slice(0, 80);
  await db.doc(`patients/${pid}/requests/${uid}`).set({
    uid, name, email: user.email || null, status: "pending", relation: String(req.data.relation || "").slice(0, 40),
    createdAt: FV.serverTimestamp(),
  });
  const p = await db.doc(`patients/${pid}`).get();
  await mirror(uid, pid, { status: "pending", patientName: p.exists ? p.data().displayName || "Paciente" : "Paciente", permissions: {} });
  await audit(pid, { type: "access_requested", by: uid, name });
  await pushToUser(pid, { title: "Nova solicitação de acesso", body: `${name} pediu para acompanhar você.`, data: { kind: "access_request" } });
  return { status: "pending" };
});

exports.respondRequest = onCall(opts, async (req) => {
  const pid = authed(req);
  const { caregiverUid, approve } = req.data;
  need(caregiverUid, "caregiverUid obrigatório");
  const rq = db.doc(`patients/${pid}/requests/${caregiverUid}`);
  const r = await rq.get();
  if (!r.exists || r.data().status !== "pending") throw new HttpsError("failed-precondition", "Solicitação inexistente");
  const p = (await db.doc(`patients/${pid}`).get()).data() || {};
  if (!approve) {
    await rq.update({ status: "denied", decidedAt: FV.serverTimestamp() });
    await mirror(caregiverUid, pid, { status: "denied", permissions: {}, patientName: p.displayName || "Paciente" });
    await audit(pid, { type: "access_denied", by: pid, target: caregiverUid });
    return { status: "denied" };
  }
  const perms = cleanPerms(req.data.permissions);
  await db.doc(`patients/${pid}/links/${caregiverUid}`).set({
    uid: caregiverUid, name: r.data().name, email: r.data().email, relation: r.data().relation || "",
    status: "active", permissions: perms, grantedAt: FV.serverTimestamp(),
  });
  await rq.update({ status: "approved", decidedAt: FV.serverTimestamp() });
  await mirror(caregiverUid, pid, { status: "active", permissions: perms, patientName: p.displayName || "Paciente" });
  await audit(pid, { type: "access_granted", by: pid, target: caregiverUid, permissions: perms });
  await pushToUser(caregiverUid, { title: "Acesso aprovado", body: `${p.displayName || "Paciente"} autorizou seu acompanhamento.`, data: { kind: "access_approved", patientId: pid } });
  return { status: "active" };
});

exports.updatePermissions = onCall(opts, async (req) => {
  const pid = authed(req);
  const { caregiverUid } = req.data;
  const lnk = db.doc(`patients/${pid}/links/${caregiverUid}`);
  const s = await lnk.get();
  if (!s.exists || s.data().status !== "active") throw new HttpsError("failed-precondition", "Vínculo inativo");
  const perms = cleanPerms(req.data.permissions);
  await lnk.update({ permissions: perms, updatedAt: FV.serverTimestamp() });
  await mirror(caregiverUid, pid, { permissions: perms });
  await audit(pid, { type: "permissions_changed", by: pid, target: caregiverUid, before: s.data().permissions, after: perms });
  return { permissions: perms };
});

exports.revokeCaregiver = onCall(opts, async (req) => {
  const pid = authed(req);
  const { caregiverUid } = req.data;
  const lnk = db.doc(`patients/${pid}/links/${caregiverUid}`);
  const s = await lnk.get();
  if (!s.exists) throw new HttpsError("not-found", "Vínculo inexistente");
  // Mantém o documento (auditoria) mas com status revoked: as regras exigem status == 'active'.
  await lnk.update({ status: "revoked", permissions: cleanPerms({}), revokedAt: FV.serverTimestamp() });
  await mirror(caregiverUid, pid, { status: "revoked", permissions: {} });
  await audit(pid, { type: "access_revoked", by: pid, target: caregiverUid });
  return { status: "revoked" };
});

/** LGPD: exclusão completa dos dados do paciente (dono). */
exports.deletePatientData = onCall(opts, async (req) => {
  const pid = authed(req);
  if (req.data.confirm !== "EXCLUIR") throw new HttpsError("failed-precondition", "Confirmação ausente");
  const links = await db.collection(`patients/${pid}/links`).get();
  for (const l of links.docs) await db.doc(`users/${l.id}/patients/${pid}`).delete();
  await db.recursiveDelete(db.doc(`patients/${pid}`));
  return { deleted: true };
});

/* ---------- NOTIFICAÇÕES ---------- */
async function pushToUser(uid, { title, body, data }) {
  const toks = await db.collection(`users/${uid}/devices`).get();
  if (toks.empty) return;
  const tokens = toks.docs.map((d) => d.id);
  const res = await admin.messaging().sendEachForMulticast({
    tokens, data: { title, body, ...Object.fromEntries(Object.entries(data || {}).map(([k, v]) => [k, String(v)])) },
    android: { priority: "high" },
  });
  const dead = [];
  res.responses.forEach((r, i) => { if (!r.success && /registration-token-not-registered|invalid-argument/.test(r.error?.code || "")) dead.push(tokens[i]); });
  await Promise.all(dead.map((t) => db.doc(`users/${uid}/devices/${t}`).delete()));
}

async function notifyCaregivers(pid, alert, patient) {
  const links = await db.collection(`patients/${pid}/links`).where("status", "==", "active").get();
  for (const l of links.docs) {
    const perms = l.data().permissions || {};
    if (!perms.alerts) continue;
    const showValue = perms.currentGlucose && alert.value != null; // sem permissão de glicemia, não vaza o valor
    const hhmm = alert.originTs.toDate().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone: "America/Sao_Paulo" });
    await pushToUser(l.id, {
      title: `${alert.severityLabel}: ${patient.displayName || "Paciente"}`,
      body: `${alert.label}${showValue ? ` — ${alert.value} mg/dL` : ""} às ${hhmm}`,
      data: { kind: "alert", patientId: pid, alertId: alert.id, severity: alert.severity, type: alert.type },
    });
  }
}

const SEV = { critical: "Crítico", high: "Alto", attention: "Atenção", info: "Informativo" };

function classify(v, th) {
  if (v <= th.urgentLow) return { type: "hypo_severe", severity: "critical", label: "Hipoglicemia grave" };
  if (v < th.low) return { type: "hypo", severity: "high", label: "Hipoglicemia" };
  if (v >= th.urgentHigh) return { type: "hyper_severe", severity: "high", label: "Hiperglicemia importante" };
  if (v > th.high) return { type: "hyper", severity: "attention", label: "Glicemia acima da faixa" };
  return null;
}
const stateOf = (v, th) => (v < th.low ? "low" : v > th.high ? "high" : "range");

/** Cria alerta com ID determinístico (janela de 30 min) => sem duplicidade. */
async function createAlert(pid, patient, a) {
  const bucket = Math.floor(a.originTs.toMillis() / (30 * 60000));
  const id = `${a.type}_${bucket}`;
  const ref = db.doc(`patients/${pid}/alerts/${id}`);
  try {
    await ref.create({ ...a, id, severityLabel: SEV[a.severity], unit: "mg/dL", createdAt: FV.serverTimestamp() });
  } catch (e) { if (e.code === 6) return null; throw e; } // ALREADY_EXISTS
  await notifyCaregivers(pid, { ...a, id, severityLabel: SEV[a.severity] }, patient);
  return id;
}

/* ---------- PROCESSAMENTO DE MEDIÇÕES ---------- */
const dayKey = (ms, tz) => new Date(ms + tz * 60000).toISOString().slice(0, 10);
const hourOf = (ms, tz) => new Date(ms + tz * 60000).getUTCHours();

exports.onReadingCreated = onDocumentCreated({ ...opts, document: "patients/{pid}/readings/{rid}" }, async (event) => {
  const { pid, rid } = event.params;
  const rRef = event.data.ref;
  const pRef = db.doc(`patients/${pid}`);
  const pSnap = await pRef.get();
  const patient = pSnap.exists ? pSnap.data() : {};
  const th = { ...DEFAULT_TH, ...(patient.thresholds || {}) };
  const tz = patient.tzOffsetMin ?? -180;
  let result = null;

  await db.runTransaction(async (t) => {
    const [rs, latest] = await Promise.all([t.get(rRef), t.get(db.doc(`patients/${pid}/current/latest`))]);
    const r = rs.data();
    if (!r || r.processed) return; // idempotência de gatilho (at-least-once)
    const ms = r.originTs.toMillis();
    const dRef = db.doc(`patients/${pid}/dailySummary/${dayKey(ms, tz)}`);
    const dSnap = await t.get(dRef);
    const d = dSnap.exists ? dSnap.data() : { date: dayKey(ms, tz), n: 0, nCgm: 0, sumAll: 0, sumCgm: 0, below: 0, inRange: 0, above: 0, lowEpisodes: 0, highEpisodes: 0, hours: {} };
    const st = stateOf(r.value, th);
    d.n++; d.sumAll += r.value;
    if (r.source === "cgm") {
      d.nCgm++; d.sumCgm += r.value;
      if (r.value < th.targetLow) d.below++; else if (r.value > th.targetHigh) d.above++; else d.inRange++;
      const h = String(hourOf(ms, tz)); const hh = d.hours[h] || { n: 0, sum: 0 };
      hh.n++; hh.sum += r.value; d.hours[h] = hh;
    }
    const prev = latest.exists ? latest.data() : null;
    const isNewest = !prev || ms > prev.originTs.toMillis();
    if (isNewest && prev && prev.state !== st) { if (st === "low") d.lowEpisodes++; if (st === "high") d.highEpisodes++; }
    t.set(dRef, d);
    if (isNewest) {
      t.set(latest.ref, { value: r.value, unit: "mg/dL", source: r.source, originTs: r.originTs, serverTs: r.serverTs,
        processedAt: FV.serverTimestamp(), readingId: rid, state: st });
      t.set(pRef, { lastReadingAt: r.originTs }, { merge: true });
    }
    t.update(rRef, { processed: true });
    result = { r, isNewest, st };
  });
  if (!result) return;

  if (result.isNewest) {
    // tendência a partir das últimas leituras CGM
    const last = await db.collection(`patients/${pid}/readings`).orderBy("originTs", "desc").limit(4).get();
    const pts = last.docs.map((x) => x.data()).filter((x) => x.source === "cgm").reverse();
    let arrow = null, rate = null;
    if (pts.length >= 3) {
      const dt = (pts[pts.length - 1].originTs.toMillis() - pts[0].originTs.toMillis()) / 60000;
      if (dt > 0 && dt <= 30) {
        rate = (pts[pts.length - 1].value - pts[0].value) / dt; // mg/dL/min
        arrow = rate >= 2 ? "↑↑" : rate >= 1 ? "↑" : rate <= -2 ? "↓↓" : rate <= -1 ? "↓" : "→";
      }
    }
    await db.doc(`patients/${pid}/current/trend`).set({ arrow, ratePerMin: rate, computedAt: FV.serverTimestamp() });
    const c = classify(result.r.value, th);
    if (c) await createAlert(pid, patient, { ...c, value: result.r.value, originTs: result.r.originTs, source: result.r.source });
  }
});

/* ---------- HbA1c ---------- */
exports.onHba1cWrite = onDocumentWritten({ ...opts, document: "patients/{pid}/hba1c/{id}" }, async (event) => {
  const { pid } = event.params;
  const s = await db.collection(`patients/${pid}/hba1c`).orderBy("examDate", "desc").limit(1).get();
  const ref = db.doc(`patients/${pid}/hba1cLatest/main`);
  if (s.empty) return ref.delete();
  return ref.set({ ...s.docs[0].data(), id: s.docs[0].id });
});

/* ---------- ESTATÍSTICAS (GMI = 3.31 + 0.02392 × média mg/dL; consenso internacional) ---------- */
async function computeStats(pid, patient) {
  const tz = patient.tzOffsetMin ?? -180;
  const interval = patient.cgmIntervalMin || 15;
  const DAYS = 14;
  const keys = [...Array(DAYS)].map((_, i) => dayKey(Date.now() - i * 86400000, tz));
  const snaps = await Promise.all(keys.map((k) => db.doc(`patients/${pid}/dailySummary/${k}`).get()));
  const ds = snaps.filter((s) => s.exists).map((s) => s.data());
  const nCgm = ds.reduce((a, d) => a + d.nCgm, 0), sum = ds.reduce((a, d) => a + d.sumCgm, 0);
  const expected = DAYS * (1440 / interval);
  const coverage = Math.min(100, (nCgm / expected) * 100);
  const daysWithData = ds.filter((d) => d.nCgm > 0).length;
  const reliable = coverage >= 70 && daysWithData >= 10; // critério mínimo de confiabilidade
  const mean = nCgm ? sum / nCgm : null;
  const base = { computedAt: FV.serverTimestamp(), periodDays: DAYS, source: "cgm", n: nCgm };
  const b = db.batch();
  b.set(db.doc(`patients/${pid}/stats/gmi`), { ...base, meanGlucose: mean && Math.round(mean),
    gmi: reliable ? Math.round((3.31 + 0.02392 * mean) * 10) / 10 : null,
    reliable, reason: reliable ? null : "dados_insuficientes" });
  b.set(db.doc(`patients/${pid}/stats/coverage`), { ...base, coveragePct: Math.round(coverage * 10) / 10, daysWithData, reliable });
  const pct = (x) => (nCgm ? Math.round((x / nCgm) * 1000) / 10 : null);
  b.set(db.doc(`patients/${pid}/stats/tir`), { ...base,
    timeInRangePct: pct(ds.reduce((a, d) => a + d.inRange, 0)),
    timeBelowPct: pct(ds.reduce((a, d) => a + d.below, 0)),
    timeAbovePct: pct(ds.reduce((a, d) => a + d.above, 0)),
    lowEpisodes: ds.reduce((a, d) => a + d.lowEpisodes, 0), highEpisodes: ds.reduce((a, d) => a + d.highEpisodes, 0), reliable });
  const hours = {};
  ds.forEach((d) => Object.entries(d.hours || {}).forEach(([h, v]) => { const x = hours[h] || { n: 0, sum: 0 }; x.n += v.n; x.sum += v.sum; hours[h] = x; }));
  b.set(db.doc(`patients/${pid}/chartData/hourlyProfile`), { computedAt: FV.serverTimestamp(),
    points: Object.keys(hours).sort((a, b) => a - b).map((h) => ({ hour: +h, avg: Math.round(hours[h].sum / hours[h].n) })) });
  await b.commit();
}
exports.scheduledStats = onSchedule({ ...opts, schedule: "every 15 minutes" }, async () => {
  const since = TS.fromMillis(Date.now() - 36 * 3600000);
  const ps = await db.collection("patients").where("lastReadingAt", ">", since).get();
  for (const p of ps.docs) await computeStats(p.id, p.data());
});

/* ---------- FALTA DE ATUALIZAÇÃO ---------- */
exports.scheduledStale = onSchedule({ ...opts, schedule: "every 5 minutes" }, async () => {
  const ps = await db.collection("patients").where("cgmExpected", "==", true).get();
  for (const p of ps.docs) {
    const d = p.data(); const last = d.lastReadingAt?.toMillis();
    const limit = (d.staleAfterMin || 20) * 60000;
    if (!last || Date.now() - last < limit) continue;
    if (Date.now() - last > 24 * 3600000) continue; // não alertar indefinidamente
    await createAlert(p.id, d, { type: "no_readings", severity: "attention", label: "Sem novas leituras do CGM",
      value: null, originTs: TS.now(), source: "system" });
  }
});

/* ---------- SOLICITAÇÃO DE CONTATO ---------- */
exports.onContactRequest = onDocumentCreated({ ...opts, document: "patients/{pid}/contactRequests/{id}" }, async (event) => {
  const { pid } = event.params;
  await pushToUser(pid, { title: "Um cuidador pediu contato", body: "Toque para responder.", data: { kind: "contact_request" } });
});
