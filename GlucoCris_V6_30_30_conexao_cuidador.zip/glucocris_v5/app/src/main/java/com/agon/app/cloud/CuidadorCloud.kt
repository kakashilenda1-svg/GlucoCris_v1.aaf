package com.agon.app.cloud

import android.content.Context
import com.agon.app.data.AppData
import com.google.android.gms.tasks.Task
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.SetOptions
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.FirebaseFunctionsException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

data class CuidadorRequest(val uid: String, val name: String, val email: String, val relation: String)
data class CuidadorLink(val uid: String, val name: String, val email: String, val relation: String, val status: String, val permissions: Map<String, Boolean>)
data class CuidadorCarePlan(val lowGlucose: String = "", val highGlucose: String = "", val emergencyWhen: String = "", val agreed: String = "")
data class CuidadorContactRequest(val id: String, val fromName: String, val message: String, val atMs: Long)
data class CuidadorPairing(val code: String, val expiresInMin: Int)
data class CuidadorResult(val ok: Boolean, val sent: Int, val message: String)

/**
 * Ponte online Paciente -> app "Gluco Cris Cuidador" (Firestore + Cloud Functions do projeto do Cuidador).
 * Nunca lança para o chamador no fluxo de sincronização: qualquer falha vira [CuidadorResult] e o que não foi
 * enviado é tentado de novo na próxima sincronização. Não altera nada do backup existente (users/{uid}/records).
 */
object CuidadorCloud {
    private const val REGION = "southamerica-east1"
    private const val NET_TIMEOUT_MS = 25_000L
    private val mutex = Mutex()

    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()
    private val fn get() = FirebaseFunctions.getInstance(REGION)

    /** Mesma regra do backup: conta real (Google ou e-mail/senha), nunca anônima. */
    fun uid(): String? = auth.currentUser?.takeIf { !it.isAnonymous }?.uid

    private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { c ->
        addOnSuccessListener { if (c.isActive) c.resumeWith(Result.success(it)) }
        addOnFailureListener { if (c.isActive) c.resumeWith(Result.failure(it)) }
        addOnCanceledListener { c.cancel() }
    }

    private suspend fun <T> net(block: suspend () -> T): T = withTimeout(NET_TIMEOUT_MS) { block() }

    private fun ts(ms: Long) = Timestamp(ms / 1000, ((ms % 1000) * 1_000_000).toInt())

    fun friendly(e: Throwable): String = when (e) {
        is kotlinx.coroutines.TimeoutCancellationException -> "Sem resposta da internet. Tentarei de novo."
        is FirebaseFirestoreException -> when (e.code) {
            FirebaseFirestoreException.Code.PERMISSION_DENIED ->
                "O servidor recusou (regras do Firestore). Publique o firestore.rules unificado desta versão."
            FirebaseFirestoreException.Code.UNAVAILABLE -> "Sem internet no momento. Tentarei de novo."
            FirebaseFirestoreException.Code.RESOURCE_EXHAUSTED -> "Limite diário do Firebase atingido. Tentarei mais tarde."
            FirebaseFirestoreException.Code.UNAUTHENTICATED -> "Entre na sua conta para compartilhar."
            else -> "Falha ao falar com o servidor (${e.code})."
        }
        is FirebaseFunctionsException -> when (e.code) {
            FirebaseFunctionsException.Code.NOT_FOUND ->
                "As funções do Cuidador ainda não foram publicadas no Firebase (veja INTEGRACAO_CUIDADOR.md)."
            FirebaseFunctionsException.Code.UNAUTHENTICATED -> "Entre na sua conta para compartilhar."
            FirebaseFunctionsException.Code.RESOURCE_EXHAUSTED -> e.message ?: "Muitos códigos ativos. Tente mais tarde."
            FirebaseFunctionsException.Code.UNAVAILABLE -> "Sem internet no momento."
            else -> e.message ?: "Falha ao falar com o servidor."
        }
        else -> "Falha inesperada ao compartilhar."
    }

    // ------------------------------------------------------------------ sincronização automática

    /**
     * Chamada após cada sincronização (app aberto, trabalho em segundo plano e importação de sensor).
     * Sem o "Cuidador online" ligado ou sem conta, não faz nada e não usa rede.
     */
    suspend fun syncIfEnabled(ctx: Context, data: AppData): CuidadorResult {
        val app = ctx.applicationContext
        if (!CuidadorPrefs.enabled(app)) return CuidadorResult(true, 0, "Desligado")
        val me = uid() ?: return CuidadorResult(false, 0, "Entre na sua conta para compartilhar.")
        return mutex.withLock {
            withContext(Dispatchers.IO) {
                try {
                    if (CuidadorPrefs.ownerUid(app) != me) {
                        CuidadorPrefs.resetSyncState(app)
                        CuidadorPrefs.setOwnerUid(app, me)
                    }
                    val snap = CuidadorSnapshot.of(app, data)
                    val now = System.currentTimeMillis()

                    pushProfile(app, me, snap, now)
                    val sent = pushReadings(app, me, snap, now)
                    pushHba1c(app, me, snap)
                    heartbeat(app, me, snap, now)
                    // Push de "pedido de acesso" / "pedido de contato": falha aqui nunca derruba a sincronização.
                    runCatching { ensurePushToken(app, me) }

                    CuidadorPrefs.setLastOk(app, now)
                    CuidadorPrefs.setLastMsg(app, "")
                    CuidadorResult(true, sent, if (sent > 0) "$sent leitura(s) enviada(s)." else "Tudo em dia.")
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    val msg = friendly(e)
                    CuidadorPrefs.setLastMsg(app, msg)
                    CuidadorResult(false, 0, msg)
                }
            }
        }
    }

    /** Perfil/limites: só reenvia quando algo mudou (o backend aceita apenas estas chaves no update). */
    private suspend fun pushProfile(app: Context, pid: String, s: CuidadorSnapshot, now: Long) {
        val th = CuidadorOnline.thresholds(s.targetLow, s.targetHigh, s.severeLow, s.severeHigh)
        val tz = CuidadorOnline.tzOffsetMin(now)
        val interval = 15 // o importador de sensor grava 1 leitura a cada 15 min
        val stale = CuidadorOnline.STALE_AFTER_MIN
        val hash = listOf(s.displayName, th, tz, s.cgmConfigured, interval, stale).hashCode()
        if (hash == CuidadorPrefs.lastProfileHash(app)) return
        net {
            db.document("patients/$pid").set(
                mapOf(
                    "displayName" to s.displayName,
                    "thresholds" to th,
                    "cgmExpected" to s.cgmConfigured,
                    "cgmIntervalMin" to interval,
                    "staleAfterMin" to stale,
                    "tzOffsetMin" to tz,
                ),
                SetOptions.merge(),
            ).await()
        }
        CuidadorPrefs.setLastProfileHash(app, hash)
    }

    private fun readingMap(e: com.agon.app.data.GlucoseEntry, mg: Int): Map<String, Any> {
        val m = mutableMapOf<String, Any>(
            "value" to mg,
            "unit" to "mg/dL",
            "source" to CuidadorOnline.sourceOf(e.id),
            "originTs" to ts(e.at),
            "serverTs" to FieldValue.serverTimestamp(),
        )
        CuidadorOnline.deviceOf(e.id)?.let { m["deviceId"] = it }
        return m
    }

    /** Envia as leituras pendentes (mais antigas primeiro). Retorna quantas foram confirmadas pelo servidor. */
    private suspend fun pushReadings(app: Context, pid: String, s: CuidadorSnapshot, now: Long): Int {
        val sentMap = CuidadorPrefs.sent(app).toMutableMap()
        val first = sentMap.isEmpty()
        val window = if (first) CuidadorOnline.FIRST_BACKFILL_MS else CuidadorOnline.MAX_PENDING_MS
        val todo = CuidadorOnline.pending(s.readings, sentMap.keys, now, window)
        if (todo.isEmpty()) {
            // Marca as leituras antigas como "já tratadas" para a janela da primeira vez não repetir
            if (first) s.readings.filter { !CuidadorOnline.isDemo(it) }.forEach { sentMap[it.id] = it.at }
            CuidadorPrefs.saveSent(app, sentMap, now)
            return 0
        }
        var confirmed = 0
        var firstError: Exception? = null
        for (chunk in todo.chunked(CuidadorOnline.BATCH)) {
            try {
                net {
                    val b = db.batch()
                    for (e in chunk) b.set(db.document("patients/$pid/readings/${e.id}"), readingMap(e, CuidadorOnline.readingMg(e)!!))
                    b.commit().await()
                }
                chunk.forEach { sentMap[it.id] = it.at }
                confirmed += chunk.size
            } catch (e: FirebaseFirestoreException) {
                if (e.code != FirebaseFirestoreException.Code.PERMISSION_DENIED) { firstError = firstError ?: e; break }
                // Provável: alguma já existe (regras não permitem update). Resolve uma a uma.
                for (x in chunk) {
                    try {
                        val exists: DocumentSnapshot = net { db.document("patients/$pid/readings/${x.id}").get().await() }
                        if (!exists.exists()) {
                            net { db.document("patients/$pid/readings/${x.id}").set(readingMap(x, CuidadorOnline.readingMg(x)!!)).await() }
                            confirmed++
                        }
                        sentMap[x.id] = x.at
                    } catch (e2: Exception) {
                        firstError = firstError ?: e2
                        break
                    }
                }
            } catch (e: Exception) {
                firstError = firstError ?: e
                break
            }
        }
        // Mesmo com erro, o que foi confirmado fica registrado (não reenvia); o resto tenta de novo depois.
        if (first) s.readings.filter { !CuidadorOnline.isDemo(it) && now - it.at > window }.forEach { sentMap[it.id] = it.at }
        CuidadorPrefs.saveSent(app, sentMap, now)
        firstError?.let { throw it }
        return confirmed
    }

    /** HbA1c de exame: poucos registros, então espelha tudo (inclui edições) e apaga o que foi excluído. */
    private suspend fun pushHba1c(app: Context, pid: String, s: CuidadorSnapshot) {
        val before = CuidadorPrefs.hba1cSent(app)
        val currentIds = s.hba1c.map { it.first }.toSet()
        val key = s.hba1c.joinToString("|") { "${it.first}:${it.second}:${it.third}:${s.hba1cLab[it.first]}" }.hashCode().toString()
        val sig = "sig:$key"
        if (before == currentIds + sig) return
        for ((id, pct, at) in s.hba1c) {
            net {
                db.document("patients/$pid/hba1c/$id").set(
                    mapOf("value" to pct, "examDate" to ts(at), "lab" to (s.hba1cLab[id]?.ifBlank { null })),
                ).await()
            }
        }
        for (gone in before.filter { !it.startsWith("sig:") && it !in currentIds }) {
            net { db.document("patients/$pid/hba1c/$gone").delete().await() }
        }
        CuidadorPrefs.setHba1cSent(app, currentIds + sig)
    }

    private suspend fun heartbeat(app: Context, pid: String, s: CuidadorSnapshot, now: Long) {
        val sentIds = CuidadorPrefs.sent(app).keys
        val pend = CuidadorOnline.pending(s.readings, sentIds, now, CuidadorOnline.MAX_PENDING_MS).size
        net {
            db.document("patients/$pid/syncStatus/status").set(
                mapOf(
                    "lastSyncAt" to FieldValue.serverTimestamp(),
                    "pendingCount" to pend,
                    "cgmState" to CuidadorOnline.cgmState(s.cgmConfigured, s.lastCgmMs, now, 15),
                    "lastCgmReadingAt" to (if (s.lastCgmMs > 0) ts(s.lastCgmMs) else null),
                ),
            ).await()
        }
    }

    // ------------------------------------------------------------------ ações da tela

    /** Botão "Estou bem". A ausência dele NÃO gera alerta. */
    suspend fun estouBem(): Result<Unit> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        net { db.collection("patients/$pid/okConfirmations").add(mapOf("ts" to FieldValue.serverTimestamp())).await() }
        Unit
    }

    suspend fun newPairingCode(): Result<CuidadorPairing> = runCatching {
        net {
            val r = fn.getHttpsCallable("createPairingCode").call().await().data as Map<*, *>
            CuidadorPairing(r["code"] as String, (r["expiresInMin"] as? Number)?.toInt() ?: 10)
        }
    }

    suspend fun respond(caregiverUid: String, approve: Boolean, perms: Set<String>): Result<Unit> = runCatching {
        net {
            fn.getHttpsCallable("respondRequest").call(
                mapOf("caregiverUid" to caregiverUid, "approve" to approve, "permissions" to perms.associateWith { true }),
            ).await()
        }
        Unit
    }

    suspend fun setPermissions(caregiverUid: String, perms: Set<String>): Result<Unit> = runCatching {
        net {
            fn.getHttpsCallable("updatePermissions").call(
                mapOf("caregiverUid" to caregiverUid, "permissions" to perms.associateWith { true }),
            ).await()
        }
        Unit
    }

    suspend fun revoke(caregiverUid: String): Result<Unit> = runCatching {
        net { fn.getHttpsCallable("revokeCaregiver").call(mapOf("caregiverUid" to caregiverUid)).await() }
        Unit
    }

    /** LGPD: apaga do servidor tudo o que foi compartilhado e desfaz os vínculos. Não toca no backup pessoal. */
    suspend fun deleteSharedData(ctx: Context): Result<Unit> = runCatching {
        net { fn.getHttpsCallable("deletePatientData").call(mapOf("confirm" to "EXCLUIR")).await() }
        CuidadorPrefs.resetSyncState(ctx.applicationContext)
        Unit
    }

    suspend fun loadCarePlan(): CuidadorCarePlan = runCatching {
        val pid = uid() ?: return@runCatching CuidadorCarePlan()
        val d = net { db.document("patients/$pid/carePlan/main").get().await() }
        CuidadorCarePlan(
            d.getString("lowGlucose").orEmpty(), d.getString("highGlucose").orEmpty(),
            d.getString("emergencyWhen").orEmpty(), d.getString("agreed").orEmpty(),
        )
    }.getOrDefault(CuidadorCarePlan())

    suspend fun saveCarePlan(p: CuidadorCarePlan): Result<Unit> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        net {
            db.document("patients/$pid/carePlan/main").set(
                mapOf(
                    "lowGlucose" to p.lowGlucose.take(1000), "highGlucose" to p.highGlucose.take(1000),
                    "emergencyWhen" to p.emergencyWhen.take(1000), "agreed" to p.agreed.take(1000),
                    "updatedAt" to FieldValue.serverTimestamp(),
                ),
            ).await()
        }
        Unit
    }

    /** Publica (ou remove) o contato de confiança do modo cuidador como contato de emergência visível ao cuidador. */
    suspend fun setEmergencyContact(name: String, phoneDigits: String, share: Boolean): Result<Unit> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        val ref = db.document("patients/$pid/emergencyContacts/confianca")
        net {
            if (share && name.isNotBlank() && phoneDigits.isNotBlank()) {
                ref.set(mapOf("name" to name.take(80), "phone" to "+$phoneDigits".replace("++", "+"), "relation" to "Contato de confiança")).await()
            } else ref.delete().await()
        }
        Unit
    }

    // ------------------------------------------------------------------ push (pedido de acesso / de contato)

    /** Registra o token do FCM em users/{uid}/devices/{token} (o servidor envia o push para esses tokens). */
    suspend fun registerPushToken(app: Context, token: String) {
        if (!CuidadorPrefs.enabled(app)) return
        val me = uid() ?: return
        net { db.document("users/$me/devices/$token").set(mapOf("createdAt" to FieldValue.serverTimestamp(), "platform" to "android")).await() }
        CuidadorPrefs.setPushRegistered(app, "$me|$token")
    }

    private suspend fun ensurePushToken(app: Context, me: String) {
        val token = net { com.google.firebase.messaging.FirebaseMessaging.getInstance().token.await() }
        if (CuidadorPrefs.pushRegistered(app) == "$me|$token") return
        registerPushToken(app, token)
    }

    /** Ao desligar o compartilhamento: o aparelho deixa de receber push do Cuidador. */
    suspend fun unregisterPushToken(app: Context): Result<Unit> = runCatching {
        val me = uid() ?: return@runCatching
        val token = net { com.google.firebase.messaging.FirebaseMessaging.getInstance().token.await() }
        net { db.document("users/$me/devices/$token").delete().await() }
        CuidadorPrefs.setPushRegistered(app, "")
    }

    // ------------------------------------------------------------------ telefone do paciente (contact/main)

    /** Publica (ou remove) o telefone do próprio paciente para o cuidador com permissão de contatos de emergência. */
    suspend fun setPatientPhone(phoneE164: String?, share: Boolean): Result<Unit> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        val ref = db.document("patients/$pid/contact/main")
        net {
            if (share && !phoneE164.isNullOrBlank()) ref.set(mapOf("phone" to phoneE164)).await()
            else ref.delete().await()
        }
        Unit
    }

    // ------------------------------------------------------------------ observação (tela)

    private fun parsePerms(raw: Any?): Map<String, Boolean> =
        (raw as? Map<*, *>)?.entries?.mapNotNull { (k, v) -> (k as? String)?.let { it to (v == true) } }?.toMap() ?: emptyMap()

    fun observeRequests(): Flow<List<CuidadorRequest>> = callbackFlow {
        val pid = uid()
        if (pid == null) { trySend(emptyList()); awaitClose { }; return@callbackFlow }
        val reg = db.collection("patients/$pid/requests").whereEqualTo("status", "pending")
            .addSnapshotListener { s, e ->
                if (e != null) { trySend(emptyList()); return@addSnapshotListener }
                trySend(s?.documents?.map {
                    CuidadorRequest(it.id, it.getString("name").orEmpty(), it.getString("email").orEmpty(), it.getString("relation").orEmpty())
                } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun observeLinks(): Flow<List<CuidadorLink>> = callbackFlow {
        val pid = uid()
        if (pid == null) { trySend(emptyList()); awaitClose { }; return@callbackFlow }
        val reg = db.collection("patients/$pid/links").addSnapshotListener { s, e ->
            if (e != null) { trySend(emptyList()); return@addSnapshotListener }
            trySend(s?.documents?.map {
                CuidadorLink(it.id, it.getString("name").orEmpty(), it.getString("email").orEmpty(), it.getString("relation").orEmpty(),
                    it.getString("status").orEmpty(), parsePerms(it.get("permissions")))
            }?.filter { it.status == "active" } ?: emptyList())
        }
        awaitClose { reg.remove() }
    }

    /** Últimos pedidos de contato feitos por cuidadores ("Solicitar que o paciente entre em contato"). */
    fun observeContactRequests(): Flow<List<CuidadorContactRequest>> = callbackFlow {
        val pid = uid()
        if (pid == null) { trySend(emptyList()); awaitClose { }; return@callbackFlow }
        val reg = db.collection("patients/$pid/contactRequests")
            .orderBy("ts", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(5)
            .addSnapshotListener { s, e ->
                if (e != null) { trySend(emptyList()); return@addSnapshotListener }
                trySend(s?.documents?.map {
                    CuidadorContactRequest(
                        it.id, it.getString("fromName").orEmpty().ifBlank { "Seu cuidador" },
                        it.getString("message").orEmpty(), it.getTimestamp("ts")?.toDate()?.time ?: System.currentTimeMillis(),
                    )
                } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }
}
