package com.agon.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.R
import com.agon.app.love.MAIN_LOVE_MESSAGE

/** Cores do cartão "Uma mensagem para você" (as mesmas dos layouts roxo e azul). */
internal class LoveCardColors(
    val fill: List<Color>, val border: List<Color>, val glow: Color,
    val title: Color, val text: Color, val phrase: Color, val label: Color,
)

internal val LoveCardPurple = LoveCardColors(
    fill = listOf(Color(0xFFF4CCFF), Color(0xFFE6B6FF), Color(0xFFDDA7FF)), border = listOf(Color(0xFFFFFFFF), Color(0xFFE79BFF)), glow = Color(0xFFFF8BFF),
    title = Color(0xFF481078), text = Color(0xFF2B1055), phrase = Color(0xFF5A1E9E), label = Color(0xFF7A4FA8),
)

internal val LoveCardBlue = LoveCardColors(
    fill = listOf(Color(0xFFD6E8FF), Color(0xFFC2DCFF), Color(0xFFB0D0FF)), border = listOf(Color(0xFFFFFFFF), Color(0xFF9CC8FF)), glow = Color(0xFF8CC8FF),
    title = Color(0xFF0F2F66), text = Color(0xFF12243F), phrase = Color(0xFF1F4F9C), label = Color(0xFF3F6FB0),
)

/** Mensagem fixa e, abaixo dela, a frase carinhosa do dia (uma das 100 frases, trocando a cada dia). */
@Composable
internal fun LoveMessageCard(phrase: String, c: LoveCardColors, modifier: Modifier = Modifier) {
    val shape = RoundedCornerShape(18.dp)
    Column(
        modifier
            .fillMaxWidth()
            .heightIn(min = 120.dp)
            .shadow(5.dp, shape, clip = false, ambientColor = c.glow, spotColor = c.glow)
            .clip(shape)
            .background(Brush.linearGradient(c.fill))
            .border(1.5.dp, Brush.linearGradient(c.border), shape)
            .padding(top = 10.dp, bottom = 8.dp, end = 12.dp),
    ) {
        Row(Modifier.fillMaxWidth().heightIn(min = 22.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Text("❤️", fontSize = 15.sp)
            Spacer(Modifier.width(8.dp))
            Text("Uma mensagem para você", color = c.title, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
            Spacer(Modifier.width(8.dp))
            Text("❤️", fontSize = 15.sp)
        }
        Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.Top) {
            Image(
                painterResource(R.drawable.neon_love_hearts),
                contentDescription = "Corações",
                modifier = Modifier.size(72.dp).offset(x = 4.dp, y = 2.dp),
                contentScale = ContentScale.Crop,
            )
            Text(
                MAIN_LOVE_MESSAGE,
                color = c.text,
                fontSize = 13.sp,
                lineHeight = 17.sp,
                modifier = Modifier.weight(1f).padding(start = 6.dp, top = 4.dp),
            )
        }
        if (phrase.isNotEmpty()) {
            Text(
                phrase,
                color = c.phrase,
                fontSize = 13.sp,
                fontStyle = FontStyle.Italic,
                lineHeight = 18.sp,
                modifier = Modifier.fillMaxWidth().padding(start = 14.dp, top = 8.dp),
            )
            Text(
                "Frase carinhosa de hoje",
                color = c.label,
                fontSize = 11.sp,
                modifier = Modifier.padding(start = 14.dp, top = 2.dp),
            )
        }
    }
}
