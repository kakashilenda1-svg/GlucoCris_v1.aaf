# v6.25 — mais letras e letra valendo no app todo (versionName 1.29.6-v6.25-letras-no-app-todo)

## 1) 8 letras novas em Acessibilidade → Tipo de letra
Helvetica, Arial, Times New Roman, Futura, Garamond, Courier, Bodoni e Roboto (equivalentes livres; ver FONTES_LICENCAS.md). Arquivos em app/src/main/res/font. Calibri e Verdana já existiam (Carlito e DejaVu Sans).

## 2) A letra escolhida agora vale em TUDO que é texto do app
Antes, o tema já trocava títulos e textos, mas estes pontos ficavam na letra do sistema:
- 11 campos de escrita (BasicTextField): busca de insulina (2), chat da Cris, nome/perfil (2), conta Google (2), insights, registro rápido, PIN/bloqueio e campo padrão em Components.kt.
- Medição do texto que se ajusta sozinho na Home (HomeScreen.kt): agora mede com a mesma letra, para não cortar.
- Números do gráfico da HbA1c (Hba1cScreen.kt), desenhados à mão.
- Janelinha de registro rápido (QuickGlucose.kt): agora carrega a letra salva mesmo com o app fechado.
Novas funções em ui/theme/AppFonts.kt: appFontFamily() e appTypeface().

## Não muda (limite do Android / de propósito)
Notificações, avisos rápidos (Toast) e menus do sistema usam a letra do sistema. Os PDFs de relatório continuam na letra padrão (documento para o médico).

## Status
Código escrito; NÃO compilado aqui (sem Android SDK). O build do GitHub Actions é quem confirma.
