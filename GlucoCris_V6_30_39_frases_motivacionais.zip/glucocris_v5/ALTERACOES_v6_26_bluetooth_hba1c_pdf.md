# v6.26 — glicosímetro Bluetooth, estimativa de HbA1c e relatório PDF (versionName 1.30.0-v6.26-bluetooth-hba1c-pdf)

Nada foi removido nem trocado: applicationId, dados antigos, Cris IA, backup, login e biometria seguem como estavam.

## 1. Glicosímetro Bluetooth (Sensores → "Glicosímetro Bluetooth")
- Busca, pareamento e download das medições guardadas no aparelho pelo **perfil padrão de glicose do Bluetooth LE** (serviço 0x1808, medidas 0x2A18, contexto 0x2A34, acesso a registros 0x2A52).
- Funciona só com glicosímetros que seguem esse padrão. Aparelhos que só falam com o app do fabricante (protocolo próprio) não aparecem na busca.
- Pede "todos os registros" e remove duplicados no app (id `ble-<aparelho>-<sequência>-<minuto>`), então sincronizar várias vezes não repete leituras e o que a pessoa apagou não volta.
- Ignora leituras com erro de tira/amostra insuficiente e leituras com relógio do aparelho errado.
- Conversão de unidade (kg/L e mol/L → mg/dL), deslocamento de hora e SFLOAT conforme a especificação.
- As leituras entram como **glicosímetro** (não como sensor/CGM): valem para painel, relatório, alertas do cuidador (se recentes) e estimativa de HbA1c.
- Opção "Tentar ao abrir o app" (desligada por padrão): busca em segundo plano com limite de 20 s, sem travar a tela.
- Permissões novas no manifest: BLUETOOTH_SCAN (neverForLocation), BLUETOOTH_CONNECT e, até o Android 11, BLUETOOTH/BLUETOOTH_ADMIN. Em Android 6–11 a busca BLE também exige a localização do celular ligada (exigência do sistema).
- Limite conhecido: o glicosímetro só aceita conexão enquanto está ligado em modo Bluetooth; por isso não há sincronização 100% automática em segundo plano.

## 2. Estimativa de HbA1c (tela HbA1c → "Estimativa a partir da sua glicose")
- **GMI** (3,31 + 0,02392 × média) e **eA1c** pela equação ADAG ((média + 46,7) ÷ 28,7), lado a lado.
- **Ajuste pelo histórico**: com 2+ exames seus que tenham glicose registrada nos 90 dias anteriores, soma a diferença mediana (exame − GMI), limitada a ±1,5 p.p.
- **Faixa aproximada** e **confiança** (alta/média/baixa) conforme volume, período e, no CGM, cobertura. A largura da faixa (±0,4/0,6/0,8) é uma regra prática do app, não um intervalo estatístico.
- Só aparece quando os dados passam nos critérios já existentes (mín. 14 medições, 7 dias, 5 dias distintos). Nunca entra na série de exames laboratoriais.

## 3. Relatório PDF (Relatórios → PDF do médico)
- Cartões de resumo no topo (média, na meta, HbA1c estimada, abaixo da meta).
- Perfil de glicose por horário no estilo AGP (mediana, 25–75%, 10–90%).
- Evolução da média diária com a faixa-alvo.
- Dias com hipoglicemia/hiperglicemia (leve e grave) e origem das medições (Bluetooth, sensor, manual).
- Seção própria da estimativa de HbA1c (GMI, eA1c, ajuste, faixa, confiança, fórmulas), sempre separada do exame laboratorial.
- Mantidos: exames de HbA1c, comparação exame × GMI, insulinas, medicamentos, refeições, alimentos e resumo por dia.

## Testes novos (JVM)
`BleGlucoseParserTest`, `Hba1cEstimatorTest`, `ReportStatsTest`.

## Não verificado neste ambiente
O código foi escrito e revisado sem compilar (sem Android SDK/Gradle aqui) e o Bluetooth nunca foi testado com um glicosímetro real. Rode `./gradlew testDebugUnitTest assembleDebug` (ou o GitHub Actions) e teste com o seu aparelho.
