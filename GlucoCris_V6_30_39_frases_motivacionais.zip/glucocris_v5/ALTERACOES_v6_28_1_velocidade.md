# Gluco Cris v1.32.1 / v6.28.1 — Velocidade de identificação

Objetivo: reduzir o tempo de identificação de alimentos, rótulos e anexos sem abrir mão demais da qualidade da v6.28.

## O que ficou mais rápido

### 1. Scanner de pratos (maior ganho)
- **Uma única chamada Gemini** na maioria dos casos. A 2ª passagem (que dobrava o tempo) só roda se a primeira não encontrar nenhum item.
- Imagem enviada: **1400 px / qualidade 85** (antes 1600/88 na v6.28).
- `maxOutputTokens`: 4096 → **1536**.
- Timeout de leitura: ~22 s (antes 30 s).
- Caminho `fast=true` no proxy: prioriza modelos **flash-lite** e tenta no máximo **2 modelos**.

### 2. Leitor de rótulos
- Imagem: **1600 px / q=88**.
- `maxOutputTokens`: 3072 → **2048**.
- Mesmo caminho `fast` + timeouts mais curtos.

### 3. Código de barras (quando cai no Gemini)
- Também usa caminho rápido e timeouts menores.

### 4. Câmera
- Volta a `CAPTURE_MODE_MINIMIZE_LATENCY` (shutter mais rápido). A nitidez da leitura continua vindo do pré-processamento.

### 5. Anexos da Cris (laudos/receitas)
- Online: **1600 px / q=86** (antes 1920/88) — upload e encode menores, ainda legível para textos e carimbos.
- OCR local de PDF/foto permanece em alta resolução (não afeta a via online).

### 6. Proxy / fallback
- `postWithFallback(..., fast = true)`: ordem prioriza lite, no máximo 2 modelos, sleep de retry 400 ms (antes 700 ms).

## O que NÃO mudou
- Prompts de leitura médica, cruzamento com rotina e sugestões de dieta/água (v6.28).
- Segurança (não inventa dose, não altera receita).
- Fallback local (ML Kit / OCR) quando a nuvem falha.

## Arquivos alterados
- `data/FoodVisionAi.kt`
- `data/CrisGemini.kt` (`postWithFallback` com parâmetro `fast`)
- `localai/CrisAttachments.kt`
- `ui/screens/FoodSmartScannerScreen.kt`
- `app/build.gradle.kts` → 1.32.1-v6.28.1

## Expectativa de tempo
- Prato “simples”: costuma cair de ~8–15 s para algo mais próximo de **4–8 s** (rede dependente).
- Rótulo: redução parecida.
- Se a rede estiver ruim, o fallback local continua sendo o caminho mais rápido possível.
