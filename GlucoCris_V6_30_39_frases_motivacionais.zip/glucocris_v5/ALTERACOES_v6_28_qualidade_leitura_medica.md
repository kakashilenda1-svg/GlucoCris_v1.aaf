# Gluco Cris v1.32.0 / v6.28 — Qualidade ampliada + Leitura médica aprimorada

## 1. Qualidade de câmeras e scanners ampliada

### FoodSmartScannerScreen (câmera de pratos / rótulos)
- `ImageCapture` agora usa `CAPTURE_MODE_MAXIMIZE_QUALITY` (antes MINIMIZE_LATENCY).
- Fotos saem com mais detalhe para a IA ler melhor textos pequenos e alimentos.

### FoodVisionAi (leitor de alimentos e rótulos)
- Decode de foto: 1600 → **2048 px**.
- Envio para Gemini (prato): 1280 px / q=78 → **1600 px / q=88**.
- Envio para Gemini (rótulo/tabela nutricional): 1400 px / q=82 → **1800 px / q=90**.
- Resultado: melhor identificação de itens, leitura de tabelas nutricionais e ingredientes.

### CrisAttachments (anexos da Cris IA)
- Imagens enviadas online: 1280 px / q=80 → **1920 px / q=88** (melhor legibilidade de laudos, receitas manuscritas, carimbos).
- Páginas de PDF no OCR local: 1600 → **1920 px**, até 12 páginas.
- Frames de vídeo: aumentados em resolução e quantidade.
- Visão local de imagens: 1280 → **1600 px**.

## 2. Cris IA — leitura de documentos médicos aprimorada

O prompt de anexos (`ATTACH_SYSTEM` em CrisGemini) foi expandido:

- **Atestados**: identifica período, CID (explicado em linguagem simples), médico e recomendações.
- **Laudos / exames gerais**: lista cada valor + referência + se está dentro/acima/abaixo, explica siglas.
- **Receitas e pedidos de exame**: mantém a precisão extrema (não inventa, não altera dose).

### Cruzamento com os registros do usuário
Quando o contexto do app está disponível (glicemias, média 7 dias, refeições, insulinas, medicamentos, metas):

- Compara valores do laudo (glicemia, HbA1c etc.) com a rotina atual do usuário.
- Comenta de forma clara e gentil **como a pessoa está indo**.
- Monta **sugestão de rotina prática** personalizada:
  - horários aproximados de refeições/lanches;
  - dicas de alimentação (priorizar/moderar, sem proibir);
  - hidratação (intervalos para beber água);
  - alinhamento com lembretes e medicamentos já cadastrados (sem alterar doses);
  - observação sobre atividade leve se a glicemia estiver estável.
- Sempre deixa explícito: "sugestões baseadas nos seus registros do app — não substituem o médico".

O prompt de chat principal também ganhou orientação para, quando for o caso, comentar controle e sugerir rotina prática.

## 3. Segurança mantida
- Continua proibido calcular ou alterar dose de insulina.
- Continua pedindo confirmação com médico/farmácia em trechos duvidosos.
- Continua priorizando segurança em valores extremos.

## Arquivos alterados
- `app/build.gradle.kts` (versão 1.32.0-v6.28)
- `ui/screens/FoodSmartScannerScreen.kt`
- `data/FoodVisionAi.kt`
- `localai/CrisAttachments.kt`
- `data/CrisGemini.kt`

Nada foi removido. Só ampliação de qualidade e capacidade de leitura + cruzamento.
