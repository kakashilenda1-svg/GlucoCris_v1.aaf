# Gluco Cris v1.33.2 / v6.29.2 — Alerta vermelho de alergia em receitas

## O que faz
Quando a Cris IA lê uma **receita médica** (ou bula / lista de remédios) e o **perfil** tem alergias cadastradas, ela **cruza** cada medicamento (nome, classe e componentes usuais da composição) com essas alergias.

Se houver risco ou dúvida razoável, a resposta começa com:

```
🔴 ALERTA DE ALERGIA — [remédio]: possível conflito com [alergia do perfil]. Motivo: [...]. Não use sem falar com o médico ou farmacêutico.
```

No chat, essa linha é **pintada de vermelho e em negrito**.

## Detalhes
- Alergias vêm do **Perfil** (campo Alergias + observações), já enviadas no contexto da Cris.
- O cruzamento vale para anexos (foto/PDF da receita) e para conversa de texto sobre remédios.
- Se não houver alergia no perfil, a Cris informa que não há o que cruzar.
- Se houver alergias mas nenhum cruzamento aparente, avisa que não viu conflito óbvio.
- **Não inventa** alergia que não está no perfil.
- **Não substitui** médico nem farmacêutico.

## Arquivos
- `data/CrisGemini.kt` — prompt de anexos e chat
- `ui/screens/CrisShared.kt` — contexto com alergias em destaque
- `ui/screens/CrisMessageText.kt` — destaque visual vermelho no chat
- `app/build.gradle.kts` → 1.33.2-v6.29.2
