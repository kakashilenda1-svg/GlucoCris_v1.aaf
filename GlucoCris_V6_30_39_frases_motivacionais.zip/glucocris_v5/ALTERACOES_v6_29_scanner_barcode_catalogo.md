# Gluco Cris v1.33.0 / v6.29 — Scanner em 2 botões + catálogo de código de barras ampliado

## 1. Dois caminhos claros no Scanner

Na abertura do **Scanner Cris** agora aparecem dois botões grandes:

1. **📷 Foto, prato e rótulo (IA)** — reconhecimento por imagem (auto / prato / rótulo / comparar / histórico).
2. **▮▯▮ Código de barras** — tela dedicada de EAN/UPC (câmera ML Kit + digitação).

Também há atalho **📚 Meu catálogo Cris** para adicionar e editar alimentos.

O botão fechar volta ao hub (ou sai do scanner se já estiver no hub).

## 2. Catálogo de código de barras ampliado

Ordem de busca ao ler um código:

1. **Catálogo Cris** (alimentos que você cadastrou/editou com EAN)
2. **Cache no aparelho** (até **4000** produtos já consultados; instantâneo offline)
3. **Open Food Facts** em paralelo:
   - `br.openfoodfacts.org`
   - `world.openfoodfacts.org`
   - **API v2** (`/api/v2/product/...`)
   - variantes de zeros à esquerda / EAN-13
   - busca por código
4. **Gemini** (se configurado e nada encontrado)

Timeout da corrida de fontes: ~3,5 s (antes ~2,2 s) para cobrir mais hosts.

## 3. Adicionar e editar no catálogo Cris

### Tela **Catálogo Cris** (`Meus alimentos`)
- Campos novos: **marca**, **código de barras**, gramas da porção, fibras, açúcares, sódio.
- **Editar** tocando no item (ou no botão Editar).
- **Excluir**.
- Ao salvar com EAN, o produto entra no **BarcodeCache** → próxima leitura é instantânea.

### Tela **Código de barras**
- Se o produto não existir nas bases, formulário de cadastro manual grava no catálogo Cris **já com o EAN lido**.
- Link direto para o catálogo Cris.
- Texto de ajuda atualizado com a ordem de busca.

## Arquivos alterados
- `ui/screens/FoodSmartScannerScreen.kt` — hub com 2 botões
- `ui/screens/FoodExtrasScreens.kt` — CustomFood expandido, load/save, edição, `findCustomByBarcode`
- `ui/screens/FoodNutritionScreens.kt` — lookup ampliado, cache 4000, barcode screen
- `app/build.gradle.kts` → 1.33.0-v6.29

Nada removido das melhorias de qualidade (v6.28) nem de velocidade (v6.28.1).
