# v6.30.13 — Visual do Localizador de Insulinas

Só a tela `InsulinLocatorScreen.kt` mudou (mais o versionName). Busca, GPS, filtros, dados e demais telas não foram tocados.

- **Aviso de localização**: os textos laranja soltos viraram um card âmbar ("Localização desligada" / "Sem permissão de localização" / "Não consegui obter sua posição") com os botões **Ativar** e **Buscar cidade**. "Ativar" abre as configurações de localização (ou do app, se a permissão foi negada) e, ao voltar, o app tenta de novo sozinho. Se a posição falhou, o botão vira "Tentar de novo". O card some quando a pessoa já escolheu cidade, estado, bairro ou CEP.
- **Resumo em chips**: locais, cidades, insulinas e "Offline: N municípios".
- **Lista**: o status de cada local (Gratuito, Preço regulado…) virou pílula colorida.
- **Rodapé**: "Mostrando 120 de N locais" (cinza) com botão **Carregar mais** (+120 por toque), no fim da lista.
- **Dica laranja** de "Perto de mim" removida (a informação está no card de aviso).
- versionName 1.34.11-v6.30.13-localizador-visual.

Status: código escrito; não compilado neste ambiente (sem Android SDK/rede). Validar no build do GitHub Actions.
