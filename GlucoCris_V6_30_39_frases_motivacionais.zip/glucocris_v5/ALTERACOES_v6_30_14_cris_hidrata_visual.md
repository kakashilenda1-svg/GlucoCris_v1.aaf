# v6.30.14 — Visual novo do Cris Hidrata

Só a tela `WaterTrackerScreen.kt` mudou (mais o texto da Ajuda e o versionName). Toda a lógica de água foi mantida:
registros, metas, favoritos, desfazer em 5 s, modo calor, alerta de glicose alta, relógio inteligente e sons.

- **Gotinha** (`CrisDrop`): a animação de toque (dança, risada com som, vermelho que vai e volta, bracinhos levantados,
  brilhos) **não foi alterada**. Ganhou só o parâmetro `limbs`: na tela cheia ela agora tem bracinhos e perninhas fixos
  (o braço esquerdo aponta para o balão). Ao tocar, os bracinhos animados de sempre assumem.
- **Balão de fala**: o lembrete que ficava num card ("Lembrete suave: ainda falta água para a meta") agora é falado pela
  gotinha, junto com a sugestão do próximo horário ("Que tal 150 ml às 09:00?").
- **Contador circular**: arco de progresso de 270°, círculo de vidro com água que sobe e ondula, personagem bebendo água
  no centro e botão "＋ N ml" (repete o último copo; 200 ml se ainda não houver registro). Chips: % da meta, quanto falta,
  próximo lembrete, conquista do dia e modo calor.
- **Copos**: grade de 2 colunas com copos 3D neon (tamanho proporcional ao volume), estrela de favorito e uma gotinha
  fixa e sorridente, com bracinhos e perninhas, ao lado de cada copo. Mostra 4 por vez (favoritos primeiro);
  "Mais copos" abre todos. O card inteiro soma o copo.
- **Quantidade personalizada**: pílula tracejada que abre o campo de ml.
- **Desfazer**: barra escura em pílula com "Desfazer" em ciano (mesmo comportamento de antes).
- **Registros de hoje**: horário primeiro, o próximo lembrete no topo da lista e botão de excluir mantido.
- **Lembretes**: card recolhido (estado, janela e intervalo + interruptor). Ao abrir, aparecem o relógio, os horários e a
  geração automática de 1 a 4 h, como antes.
- **Alerta de glicose alta**: mostra o limite atual (sua meta máxima em mg/dL).
- Ordem nova da tela: contador, copos, registros, lembretes, alerta de glicose, ajustes.
- versionName 1.34.12-v6.30.14-cris-hidrata-visual.

Status: código escrito; não compilado neste ambiente (sem Android SDK/rede). Validar no build do GitHub Actions.
