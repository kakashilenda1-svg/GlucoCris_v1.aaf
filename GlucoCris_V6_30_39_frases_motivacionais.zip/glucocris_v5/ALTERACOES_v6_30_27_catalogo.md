# v6.30.27 — FoodBase + busca inteligente + Catálogo Gluco

A chave da FoodBase fica SÓ no Cloudflare Worker (segredo `FOODBASE_API_KEY`). O APK não a contém e o Gradle não a lê.

## O que foi ligado
- **Pesquisa de alimentos**: `searchFoodBase` entra em `fetchOnlineFoodsParallel` junto das outras fontes online (resultado aparece com "FoodBase · online").
- **Scanner inteligente**: usa `searchFoodsComplete` (via `matchToCatalog`), então os alimentos detectados na foto também são casados com a FoodBase.
- **Código de barras**: `lookupFoodBaseBarcodeBlocking` corre em paralelo com o Open Food Facts em `lookupBarcode`; vence a primeira resposta válida.
- **Cris IA**: ferramenta `CrisFoodBaseTool` responde "quantos carboidratos/calorias/proteínas… tem o X?" com os valores por 100 g da FoodBase. Só informa; não calcula dose. Sem internet, sem dado ou com dado pessoal na pergunta, a Cris segue o fluxo de sempre.

## Segurança dos dados
- Item da FoodBase sem nutrientes é descartado (nunca vira carboidrato zero). Sem carboidrato informado, fica marcado "confira".
- Qualquer falha (sem worker, sem cota, sem rede) devolve vazio e o app continua com TACO/Open Food Facts/USDA/FatSecret.

## Arquivos
- `app/.../ui/screens/FoodBaseSearch.kt` (novo); `FoodNutritionScreens.kt` (4 linhas); `CrisShared.kt` (1 linha); `backend/tavily-proxy/worker.js` (rota `/foodbase`), `wrangler.toml`, `README.md`, `test-foodbase.mjs`.
- Nada de telas, cálculos, banco, Firebase, workflow ou Gradle foi alterado.

## Busca que acompanha a escrita (v6.30.25)
- `FoodFastSearch.kt`: índice local pré-normalizado; a lista aparece na hora a cada letra (prefixo, palavra, trecho), sem travar o teclado.
- A busca local completa (sinônimos e erros de digitação) roda em segundo plano (`Dispatchers.Default`) e substitui a rápida quando termina; se você já digitou mais, o resultado velho é descartado.
- `searchLocal` ficou mais leve (normalização memorizada, sem recalcular por alimento) com o mesmo critério de pontuação.
- Online (FoodBase, Open Food Facts, USDA, FatSecret) só dispara quando a digitação pausa (120 ms) e as consultas antigas são canceladas de verdade. A FoodBase só é consultada com 3+ letras, para poupar a cota.
- Meus alimentos são carregados uma vez fora da thread principal.

## Busca inteligente (v6.30.26): o resultado se mantém no que você escreve
- Ordem fixa de relevância: 1) o nome começa com o digitado ("abobo" → Abóbora), 2) uma palavra começa com ele, 3) contém, 4) só parecido (sinônimo/erro de digitação). Erro de digitação só aparece se nada começar com o digitado.
- Dentro do mesmo grupo: favoritos e usados recentemente, depois alimentos genéricos (TACO/Meus alimentos) antes de produtos de marca, depois nome mais curto.
- Resultados que chegam depois (busca completa, internet) entram nessa mesma ordem (`mergeStable`), então a ordem em que as fontes respondem não troca o alimento no topo.
- Interface: a parte digitada fica em negrito/verde no nome (sugestões e lista) e o cabeçalho mostra "Melhor resultado: …".
- Arquivo: `FoodFastSearch.kt`. A lógica foi simulada com exemplos em Python; o app não foi compilado nem testado em celular.

## Catálogo Gluco na nuvem (v6.30.27)
- Todo produto que você ABRE para ver (tela do alimento) entra no catálogo (Cloudflare D1), com assinatura única `GLC-…` calculada no servidor. Mesmo código de barras = mesma assinatura em qualquer fonte.
- Mudar a porção (nome da porção + peso dela) e usar ADD NO DIARIO / Adicionar ao prato / Salvar no catálogo Cris atualiza o catálogo: nova versão, histórico guardado. Ao reabrir o produto, a última porção editada volta preenchida.
- Só dados do produto sobem (nunca Meus alimentos, estimativas de IA nem o histórico de busca). Edição leva só um id anônimo do aparelho.
- Base da API Gluco: rotas `/api/v1/foods…` com chaves `gk_…` (hash no banco, limite diário por chave). Só sai o que estiver verificado E com a fonte liberada em `source_policy`; padrão: só USDA liberado.
- Arquivos: `CatalogSync.kt` (novo), `worker.js` (rotas /catalog, /catalog/admin, /api/v1), `README.md` (passo a passo), `test-catalog.mjs`.
- Sem o banco D1 ligado ou sem internet, o app simplesmente não registra (nada quebra). Não há fila de reenvio: produto aberto offline não entra.

## FoodBase confirmado no diagnóstico real
- Chave aceita; nutrientes lidos certo (Nutella: 539 kcal, 57,5 g de carboidratos). Código de barras: `GET /v1/foods/barcode/{código}`.

## Não verificado
- O app não foi compilado (sem Android SDK neste ambiente) nem testado em celular. O tempo exato da busca em milissegundos não foi medido.
- O formato da resposta do código de barras da FoodBase (`/foods/barcode/...`) só foi visto pelo status 200; o `/foodbase/diag` mostra as chaves.
