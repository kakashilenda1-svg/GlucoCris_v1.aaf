# v6.30.29 – Frase do dia + revisão do Tempo no alvo

- Card "Controle sua diabetes com confiança!" da Início (layout claro) agora mostra a **Frase do dia**: 50 frases motivadoras em `data/DailyQuotes.kt`, uma por dia (troca à meia-noite do aparelho, segue a ordem e recomeça após a 50ª). O toque continua abrindo o Resumo semanal.
- Tempo no alvo: cálculo (`Insights.timeInRangePct`) revisado, está correto. Sem medições nos últimos 7 dias ele mostra "—"; agora o rodapé diz "Sem medições em 7 dias".
- Teste novo: `DailyQuotesTest`.
