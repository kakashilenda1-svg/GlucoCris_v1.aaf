# v6.30.30 – Conexão Gluco Cris ⇄ Cris Cuidador (fechando as pontas)

Não compilado nem testado aqui (sem Android SDK/Gradle/Firebase). Rode `./gradlew testDebugUnitTest assembleDebug` e o teste de regras antes de usar com dados reais.

## O que mudou
1. **Push no Gluco Cris** (novo `cloud/CuidadorFcmService.kt`, `firebase-messaging`, serviço no manifesto): o paciente agora recebe aviso de "Nova solicitação de acesso" e "Seu cuidador pediu contato". O token vai para `users/{uid}/devices/{token}` na primeira sincronização com o Cuidador online ligado e é removido ao desligar. Alertas de glicemia continuam só no app Cuidador.
2. **Pedidos de contato na tela "Cuidador online"**: lista os 5 últimos (`patients/{pid}/contactRequests`).
3. **Telefone do paciente** (`patients/{pid}/contact/main`): interruptor "Mostrar meu telefone", usa DDD+número do Perfil, desligado por padrão; publicado em formato +55…
4. **Limite de atualização**: o app envia `staleAfterMin = 40` (2 leituras de 15 min + folga). O Cuidador usa o mesmo valor (antes: 10 min fixos, causando "Desatualizado" falso).
5. **"Estou bem"** agora aparece no app Cuidador (ver CHANGELOG no projeto do Cuidador).

## Fora do escopo (continua como antes)
`extraInfo`; editar/excluir leitura já enviada; estatísticas do Cuidador só com dados de sensor.

## Antes de testar
Registrar `br.com.glucocris.cuidador` no Firebase e colocar o `google-services.json` no Cuidador; plano Blaze; `firebase deploy --only firestore:rules,firestore:indexes,functions` (veja INTEGRACAO_CUIDADOR.md). No Android 13+, permitir notificações no Gluco Cris.

Testes novos: `CuidadorOnlineTest` (telefone e limite de atualização).
