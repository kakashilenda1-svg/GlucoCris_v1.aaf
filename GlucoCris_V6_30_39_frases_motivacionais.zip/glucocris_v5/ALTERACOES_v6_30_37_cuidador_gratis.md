# v6.30.37 — Cuidador online sem Cloud Functions (plano Spark, grátis)

**Não compilado nem testado em aparelho** (sem Android SDK/Gradle/Firebase aqui). Testes do Worker (`node --test`) foram executados; os testes Kotlin e o de regras estão escritos mas **não rodaram**.

## O que mudou
1. **Sem Cloud Functions**: removidos `functions/` e a dependência `firebase-functions`. Não precisa mais do plano Blaze.
2. **Pareamento direto no Firestore** (`CuidadorCloud`): código de 8 caracteres gerado no app, só o SHA-256 vai ao servidor (`pairingCodes/{hash}`); aprovar, mudar permissões e revogar gravam `links` e o espelho do cuidador em lote. Auditoria em `patients/{pid}/audit`.
3. **Cálculos no Gluco Cris** (`CuidadorCompute`): glicemia atual, tendência (setas), alertas (id `tipo_janela30min`, só para leitura de até 2 h), GMI, cobertura, tempo no alvo, perfil por hora (a cada ~1 h) e último HbA1c. Isso também **resolve a espera do GMI** que dependia de dias de histórico no servidor.
4. **Push pelo Worker do Cloudflare** (`backend/cuidador-push`, novo): `/v1/notify` (alerta, pedido de acesso, acesso aprovado, pedido de contato) e gatilho de 10 min para "sem novas leituras". Novo `BuildConfig.CUIDADOR_PUSH_URL` (`cuidador.push.url` no local.properties ou variável `CUIDADOR_PUSH_URL`).
5. **`firestore.rules` novas** (iguais nos dois projetos) e `backend-tests` com testes para o pareamento, aprovação, revogação, cálculos gravados pelo paciente e exclusão LGPD.
6. `versionName` 1.35.6-v6.30.37-cuidador-gratis (versionCode 98).

## Mudanças de comportamento
- O paciente agora pode apagar leituras do próprio `patients/{pid}` (necessário para "Apagar tudo que compartilhei"); cuidadores continuam sem nenhuma escrita além de ack, diário e pedido de contato.
- Sem servidor, não há limite de 10 tentativas/h por cuidador no código de pareamento; a aprovação manual do paciente continua obrigatória.
- Se o Worker não estiver no ar, tudo funciona, só o push não sai (o dado aparece quando o outro app é aberto).

Passo a passo completo em `INTEGRACAO_CUIDADOR.md`.

## Telefone do cuidador (Modo cuidador por SMS/WhatsApp)
O campo agora aceita só **DDD + número** (ex.: `11932089685` ou `(11) 93208-9685`); o `55` entra sozinho. Número de outro país: começar com `+` ou `00` (ex.: `+351912345678`). Já começando com 55 (12–13 dígitos) não duplica. O código de pareamento do Cuidador online continua como estava: aparece na tela para copiar e enviar manualmente.
