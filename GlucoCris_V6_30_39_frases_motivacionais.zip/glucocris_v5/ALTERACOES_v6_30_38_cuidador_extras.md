# v6.30.38 — Mais dados para o Cuidador (6 novas permissões)

**Não compilado nem testado em aparelho.** Escritos mas não executados: testes Kotlin (`CuidadorExtrasTest`) e de regras (`backend-tests`).

- Novas permissões e coleções: `insulin`, `meals`, `symptoms`, `medications`, `water`, `reminders` (regras do Firestore atualizadas: leitura por permissão, escrita só do paciente).
- `cloud/CuidadorExtras.kt` (lógica pura) + `publishExtras` em `CuidadorCloud.kt`: envia só o que mudou (assinatura por item), só categorias liberadas a algum cuidador ativo, e apaga do servidor quando a permissão é retirada.
- `CuidadorSnapshot` agora carrega insulina, refeições, sintomas, remédios, lembretes e o resumo da água (Cris Hidrata).
- "Apagar tudo que compartilhei" também apaga as novas coleções.
- `versionName` 1.35.7-v6.30.38-cuidador-extras (versionCode 99).
- Limitação: o lembrete não tem registro de "cumprido" no app; só o horário programado é enviado.
- Publique de novo o `firestore.rules` (mesmo arquivo nos dois projetos).
