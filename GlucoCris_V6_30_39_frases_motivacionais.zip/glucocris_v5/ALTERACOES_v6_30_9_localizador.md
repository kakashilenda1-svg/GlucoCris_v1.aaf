# Localizador de Insulinas — busca inteligente e "Perto de mim"

## 1. Busca (a `LocatorSearch` agora está ligada)
Antes, a `LocatorSearch` existia mas nenhuma tela chamava. O texto digitado ia direto para
`InsulinCatalog.search`, que só fazia `contains` com acento: "glargína" ou "lantus curitiba" não achavam nada.

- **Acento e maiúsculas** não importam ("GLARGÍNA", "rápida").
- **Apelidos**: cristalina/transparente → regular; turva/leitosa → NPH; lenta/basal/longa → basais; rápida/bolus → prandiais.
- **Marca estreita a marca**: "Lantus" mostra Lantus e Lantus SoloStar (não mostra Basaglar). Princípio ativo ("glargina") mostra o grupo.
- **Todas as marcas do catálogo** (Admelog, Wosulin, Insuman…), fabricante e apresentação; "70/30" funciona.
- **"Você quis dizer…"**: erro de digitação vira *sugestão* (toque para aplicar). Nunca troca a busca sozinho.
- **Município no texto** ("lantus curitiba"): aparece o botão "Buscar em Curitiba — PR".
- **Segundo plano**: a interpretação do texto e a montagem dos pontos rodam em `Dispatchers.Default`, com espera de 150 ms
  após a última tecla; cada tecla cancela a conta anterior e a lista anterior fica na tela até a nova ficar pronta.
- Digitar limpa os chips de tipo/marca; tocar num chip limpa o texto (vale a última ação).
- Não afirma equivalência terapêutica entre insulinas (mesma regra de antes).

## 2. Onde buscar
- **"Perto de mim" (GPS) abre como padrão**: pede a permissão ao entrar na tela (uma vez) e, com a posição, descobre o município
  (reverse geocode) e lista farmácias/UBS/hospitais reais ao redor. Sem internet para descobrir o município, a busca fica pelo
  ponto e o app **não chuta** o município mais próximo.
- Mensagens claras para permissão negada (com atalho para as configurações do app), GPS desligado e falha de posição.
- **Qualquer cidade, bairro, rua ou CEP**: campo "Cidade, bairro ou CEP…".
  - Nome de município: resolve offline, na hora (sugestões enquanto digita).
  - Bairro/rua: Nominatim (OpenStreetMap), só ao confirmar (a política do serviço proíbe busca a cada letra).
  - CEP: ViaCEP → endereço → Nominatim; se a rua não está no mapa, cai para bairro e depois cidade (avisa que é aproximado).
  - Vários resultados (ex.: "Santa Rita"): a pessoa escolhe. Erro de grafia: "Você quis dizer…".
- **Lista de municípios do IBGE (opcional, offline)**: rode `python3 tools/gerar_ibge_municipios.py` uma vez. Ele grava
  `app/src/main/assets/ibge_municipios.txt` e o app passa a conhecer os 5.570 municípios. **Sem o arquivo nada quebra**
  (continua com os 194 curados). A lista do IBGE só amplia busca/escolha de município; os cartões de "canais de acesso" por UF
  continuam usando a lista curada.

## Privacidade
A posição (ou o CEP/endereço digitado) é enviada a serviços públicos: OpenStreetMap (Overpass/Nominatim) e, para CEP, ViaCEP.
A tela avisa isso quando usa o GPS. Nada é enviado antes da permissão.

## Arquivos
- `data/LocatorSearch.kt` (reescrito), `data/insulin/CityIndex.kt` (novo), `data/insulin/SupplyNetwork.kt`, `data/insulin/Models.kt`
- `data/PlaceFinder.kt` (`geocodeDetailed`, `cepOrNull`, `reverseInfo`; o `geocode` antigo foi mantido)
- `viewmodel/LocatorViewModel.kt` (origem, estado do GPS, busca por lugar)
- `ui/screens/InsulinLocatorScreen.kt`
- Testes: `test/.../data/LocatorSearchTest.kt`, `CityIndexTest.kt`
- `tools/gerar_ibge_municipios.py`
