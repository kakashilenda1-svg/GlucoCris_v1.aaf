# Gluco Cris v1.34.0 / v6.30 — App mais completo offline

## Objetivo
Com **sem internet**, o app continua identificando fotos, lendo rótulos/receitas e usando a **IA local** (se baixada) + catálogos no aparelho, em vez de depender da nuvem.

## O que roda offline

| Função | Offline |
|--------|---------|
| Scanner de prato | ML Kit + **IA local** (se instalada) + catálogo TACO/local |
| Leitura de rótulo | OCR ML Kit no aparelho |
| Código de barras | Cache (até 4000) + catálogo Cris + catalogo_extra; OFF online só com rede |
| Anexos da Cris (foto/PDF receita/laudo) | OCR + **IA local** + glossário; alerta de alergia com dados do perfil |
| Chat da Cris | Modelo local baixado no aparelho |
| Diário, bolus, lembretes, gráficos | Já eram locais |
| Pesquisa web / Gemini / Open Food Facts ao vivo | Precisam de internet |

## Mudanças técnicas
- `FoodVisionAi.analyzePlate(bitmap, context)`: se offline (ou Gemini falhar), usa `analyzePlateOnDevice` (ML Kit + LocalVisionManager).
- `analyzeLabel`: não tenta Gemini sem rede; OCR local direto.
- `CrisLocalAi` prompt offline: lista o que **pode** e **não pode** fazer sem internet; proíbe “não tenho acesso a imagens” quando há OCR.
- `CrisAttachments.answerWithLocalAi`: recebe contexto do app (alergias etc.) e regras de alerta de alergia offline.
- Scanner: mensagens de progresso diferenciam online / IA local / só ML Kit.

## Requisito importante
Para a Cris **conversar e interpretar** anexos/fotos com qualidade offline, a pessoa precisa **baixar a IA local uma vez** (Wi‑Fi) em Cris → status → Baixar IA local. Sem o modelo, restam OCR + ML Kit + catálogos (ainda funcionam, com menos “conversa”).

## Arquivos
- `data/FoodVisionAi.kt`
- `ui/screens/FoodSmartScannerScreen.kt`
- `localai/CrisLocalAi.kt`
- `localai/CrisAttachments.kt`
- `app/build.gradle.kts` → 1.34.0-v6.30
