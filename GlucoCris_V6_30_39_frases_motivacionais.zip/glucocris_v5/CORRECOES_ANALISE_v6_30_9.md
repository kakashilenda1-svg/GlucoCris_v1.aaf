# Análise estática v6.30.9 — correções

Feita sem compilador (sem Android SDK/rede): não substitui o build.

## Corrigido
- `InsulinLocatorScreen.kt`: o `catch (e: Exception)` da busca de locais engolia o `CancellationException`
  (troca de origem ou saída da tela). Agora a exceção é relançada.
- `app/build.gradle.kts`: `versionName` estava em `v6.30.6`; passou para `1.34.7-v6.30.9-localizador`.
  Comentário do `abiFilters` corrigido (só arm64-v8a, não "+ x86_64").
- `.github/workflows/build.yml`: nota do Release dizia "arm64-v8a + x86_64".

## Verificado sem problemas
JSON/XML/YAML/Python/JS válidos; delimitadores balanceados em todos os `.kt`; imports `com.agon.app.*` resolvem;
recursos `R.*` e `@...` do manifest existem; sem classes duplicadas; rotas existem; campos de cor existem;
símbolos usados pela tela do localizador existem; expectativas dos testes batem com a lógica lida.

## Observações (não alteradas)
- `BrazilGeo.cities` gera ids sem remover acentos (`sp-s-o-paulo`), enquanto `CityIndex.parseLine` remove (`sp-sao-paulo`).
  Funciona porque o índice mantém o id da lista curada, mas mudar quebraria ids já salvos.
- `ibge_municipios.txt` não está nos assets (opcional): rode `python3 tools/gerar_ibge_municipios.py`.

# v6.30.10 — "Onde pegar", WhatsApp e tela fluida

- **IBGE offline**: o app já lê `assets/ibge_municipios.txt` se existir. Sem rede aqui, o arquivo não foi gerado; o workflow
  agora roda `tools/gerar_ibge_municipios.py` antes do build (opcional, `continue-on-error`). Local: `python3 tools/gerar_ibge_municipios.py`.
- **Cartão "Onde pegar"** (`data/insulin/InsulinGuide.kt`): no topo da lista quando há busca/tipo/marca. NPH e regular -> UBS ou Farmácia Popular;
  análogos do CEAF -> CEAF do estado; privadas -> rede de farmácias. Um cartão por grupo de canais.
- **Ligar e WhatsApp** em cada local real (OpenStreetMap), com mensagem pronta ("Olá! Vocês têm Lantus?").
  WhatsApp só aparece quando o telefone é celular com DDD (fixo não tem WhatsApp). Telefones múltiplos: usa o primeiro.
- **Tela**: topo fixo (voltar, local, botão Filtros com contador) + busca fixa + uma única lista rolável.
  O painel Filtros (folha inferior) reúne tipo, marca, canal, gratuito, ordem e local (Perto de mim, Brasil, UF, município, cidade/bairro/CEP).
  Escolher um local fecha o painel.
- Testes novos: `InsulinGuideTest`.
- Não compilado neste ambiente.
