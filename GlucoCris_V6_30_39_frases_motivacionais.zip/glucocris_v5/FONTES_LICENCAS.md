# Fontes embutidas (Acessibilidade → Tipo de letra)
Arquivos em app/src/main/res/font (subconjunto Latino: português e símbolos comuns; o resto cai na fonte do sistema).
- Inter, Work Sans, Outfit, Instrument Sans, Lora, Crimson Pro, IBM Plex Serif, Carlito, Caladea: SIL Open Font License 1.1 (uso livre, inclusive em apps).
- DejaVu Sans: licença Bitstream Vera/DejaVu (uso e redistribuição livres).

## v6.25 — letras da lista famosa (Helvetica, Arial, Times New Roman, Futura, Garamond, Courier, Bodoni, Roboto)
Helvetica, Arial, Times New Roman, Futura, Garamond, Courier e Bodoni são fontes comerciais; o app usa equivalentes LIVRES de desenho muito parecido, embutidos no app (funcionam sem internet):
- Arimo (Arial), Tinos (Times New Roman), Jost (Futura), EB Garamond (Garamond), Courier Prime (Courier), Bodoni Moda (Bodoni), Roboto: SIL Open Font License 1.1 (uso livre, inclusive em apps). Recortadas para o alfabeto latino (português e símbolos comuns).
- TeX Gyre Heros (Helvetica): GUST Font License (uso e redistribuição livres). Arquivo original, sem alteração.
- Calibri e Verdana já existiam na lista como Carlito e DejaVu Sans (equivalentes livres), por isso não foram repetidas.
Textos completos das licenças: pasta LICENCAS_FONTES/.
