# Cuidador online 100% grátis (plano Spark, sem Cloud Functions, sem cartão)

Nada aqui exige o plano Blaze. O que antes eram Cloud Functions agora é feito assim:

| Antes (Functions, pago) | Agora (grátis) |
|---|---|
| Gerar código, pedir acesso, aprovar, mudar permissões, revogar | Os apps gravam direto no Firestore e as **regras** (`firestore.rules`) validam tudo |
| Calcular glicemia atual, tendência, alertas, GMI, cobertura, tempo no alvo | O **Gluco Cris** calcula (já tem o histórico) e grava pronto para o Cuidador ler |
| Enviar push (FCM) | Um **Worker do Cloudflare** (`backend/cuidador-push`), como o do Tavily/FoodBase |
| "Sem novas leituras do CGM" | O mesmo Worker, por gatilho agendado (a cada 10 min, gratuito) |

## Passo a passo (uma vez só)

**1. Firebase (projeto `gluco-cris`, continua no plano Spark)**
1. Configurações do projeto ▸ Seus apps ▸ **Adicionar app Android** ▸ pacote `br.com.glucocris.cuidador` ▸ baixe o `google-services.json`.
   - No GitHub: Settings ▸ Secrets and variables ▸ Actions ▸ **New repository secret** `GOOGLE_SERVICES_JSON` e cole o conteúdo inteiro do arquivo (o workflow do Cuidador cria o arquivo sozinho). Ou coloque o arquivo em `app/` do Cuidador.
2. Authentication ▸ Método de login ▸ ative **E-mail/senha** (o paciente já usa Google/e-mail).
3. Firestore Database ▸ **Regras** ▸ apague tudo, cole o conteúdo de `firestore.rules` ▸ **Publicar**. (Os dois projetos trazem o mesmo arquivo.)
4. Não precisa criar índices.
5. Cloud Messaging já vem ativo (API V1).

**2. Chave da conta de serviço (para o Worker enviar push)**
Configurações do projeto ▸ **Contas de serviço** ▸ *Gerar nova chave privada*. Guarde o JSON baixado. **Nunca** coloque esse arquivo no GitHub nem no app.

**3. Worker do Cloudflare**
```
cd backend/cuidador-push
npx wrangler login
npx wrangler deploy
npx wrangler secret put FIREBASE_SERVICE_ACCOUNT     # cole o JSON INTEIRO da chave e Enter
```
- Abra o endereço que o `deploy` mostrar: deve responder `{"service":"gluco-cris-cuidador-push","ok":true}`.
- Os apps já vêm apontando para `https://gluco-cris-cuidador-push.alanholivier.workers.dev`. Se o seu endereço for **diferente**, crie nos dois repositórios do GitHub a variável `CUIDADOR_PUSH_URL` (Settings ▸ Secrets and variables ▸ Actions ▸ **Variables**) com o endereço certo e rode o build de novo.
- Teste local do Worker (opcional): `node --test worker.test.mjs`.

**4. Usar**
No Gluco Cris: Mais ▸ Modo cuidador / família ▸ **Cuidador online** ▸ ligar ▸ *Gerar código*. No Cuidador: criar conta ▸ Adicionar paciente ▸ digitar o código. De volta ao Gluco Cris, aprove e escolha as permissões. No Android 13+, permita notificações nos dois apps.

## Dados extras que o paciente pode liberar (v6.30.38 / Cuidador 1.2.0)
Cada item é uma **permissão própria**, ligada por cuidador na hora de aprovar (ou depois, em "Alterar permissões"):

| Permissão | O que o cuidador vê | Coleção no Firestore |
|---|---|---|
| Insulina aplicada | dose, unidade, tipo e horário (últimos 14 dias) | `patients/{pid}/insulin` |
| Refeições e carboidratos | tipo, descrição, g de carboidratos e horário | `meals` |
| Sintomas | sintoma, intensidade, observação e horário | `symptoms` |
| Medicamentos em uso | nome, dose e horários informados pelo paciente | `medications` |
| Água | total do dia, meta e horário do último registro | `water` |
| Lembretes programados | horário, dias e título dos lembretes ativos | `reminders` |

- **Minimização:** o Gluco Cris só envia uma categoria se **algum cuidador ativo** tiver a permissão. Se a permissão sai de todos, o que já foi enviado dessa categoria é **apagado** do servidor.
- Só entram os últimos 14 dias (remédios, lembretes e a água do dia não têm janela). Editar ou apagar no Gluco Cris atualiza ou remove no servidor na próxima sincronização.
- **Lembrete "cumprido" não existe** hoje: o Gluco Cris não registra se você tocou no lembrete. O cuidador vê o que está programado, não se foi feito.
- Cota gratuita: as categorias extras só gastam escritas quando algo muda (a água muda a cada copo).

## Segurança sem servidor (o que as regras garantem)
- Só o **paciente** cria, altera e revoga vínculos e permissões. O cuidador não consegue se conceder nada.
- O código tem 8 caracteres (≈ 40 bits), vale 10 minutos, é gravado só como **hash** e é **consumido** no pedido. Mesmo com um código correto, o pedido fica **pendente** até o paciente aprovar. Não há limite de tentativas (não existe servidor para contar); a chance de acertar um código ativo por tentativa é de ~1 em 200 bilhões.
- O Worker só envia push depois de conferir o **ID token** do Firebase e de achar o documento correspondente no Firestore, e só uma vez por documento. A chave de serviço fica nos segredos do Worker.
- O paciente apaga tudo o que compartilhou em *Apagar tudo que compartilhei*.

## Limites honestos
- Os cálculos dependem do **Gluco Cris sincronizar** (app aberto ou trabalho em segundo plano, a cada 15–30 min). Se o celular do paciente estiver desligado ou sem internet, nada novo chega; nesse caso o Cuidador mostra "Desatualizado" e o Worker avisa "Sem novas leituras" (quando há sensor configurado).
- O **relógio do celular precisa estar em horário automático**: o código expira por data/hora.
- O alerta só é criado para leitura de até 2 h atrás (valor antigo não vira push).
- Editar ou excluir uma glicemia já enviada não muda o que o cuidador vê.
- Cota gratuita do Firestore (20 mil escritas/dia): cada paciente usa ~600 escritas/dia, então cabem ~30 pacientes. Para um uso familiar sobra muito.
- Cloudflare Workers grátis: 100 mil requisições/dia e 50 subrequisições por execução (o Worker já respeita isso).
- **Nada disso foi compilado nem testado em aparelho** (sem Android SDK/Firebase aqui). Foram executados: os testes do Worker (`node --test`). Faça antes: build no GitHub Actions, testes de regras (`backend-tests`, emulador local) e um teste de ponta a ponta com 2 celulares.

## Como os dois apps conversam (resumo técnico)
```
Gluco Cris (paciente)                       Firestore (projeto gluco-cris)                  Gluco Cris Cuidador
 salva/importa glicemia ──► patients/{uid}/readings/{id}
 CuidadorCompute (no app) ─► current/latest, current/trend, alerts/{tipo_janela},  ───────►  listeners (permissão por documento)
                              stats/{gmi,coverage,tir}, chartData/hourlyProfile, hba1cLatest
 código ─► pairingCodes/{sha256}  ◄── cuidador digita ── pedido em patients/{uid}/requests/{cuid} (+ aviso users/{cuid}/patients/{uid})
 aprova ─► patients/{uid}/links/{cuid} (+ espelho)                         push: app ─► Worker ─► FCM ─► outro aparelho
```
- `pid` = UID do Firebase Auth do paciente (mesma conta do backup). O cuidador é outra conta (e-mail/senha).
- Leituras `sensor-*` viram `cgm`; digitadas e Bluetooth (`ble-*`) viram `manual`. GMI/cobertura/tempo no alvo usam só `cgm` (14 dias; GMI só aparece com ≥ 70 % de cobertura e ≥ 10 dias).
- A primeira ativação envia só as últimas 3 h; depois de offline, no máximo 6 h. O importador de sensor grava 1 leitura a cada 15 min.
- Arquivos: `cloud/CuidadorCloud.kt` (Firestore + aviso ao Worker), `cloud/CuidadorCompute.kt` (cálculos puros, com `CuidadorComputeTest`), `cloud/CuidadorOnline.kt` (lógica pura, código de pareamento), `backend/cuidador-push/` (Worker), `backend-tests/` (regras).
