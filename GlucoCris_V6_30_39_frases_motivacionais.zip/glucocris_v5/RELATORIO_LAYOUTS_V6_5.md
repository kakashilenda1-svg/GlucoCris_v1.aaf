# Relatório — layouts roxo e azul da tela inicial (V6.5)

Alterado: HomeScreen.kt (tela inicial roxa e azul), WaterTrackerScreen.kt (só o visual da barra Cris Hidrata),
MainActivity.kt (barra de navegação), HistoryMoreScreens.kt (linhas extras no menu Mais), novo GlucoNavBars.kt e
duas imagens novas (blue_hero_robot.png, blue_cris_head.png, recortadas da imagem azul de referência).

Layout roxo: igual à imagem 1, mais compacto; sem a faixa do humor (o humor se escolhe no cartão "Seu humor"). Mensagem fixa sem a linha "Frase carinhosa de hoje", cabendo sem rolar.
Barra com 5 abas. O atalho "Conversar com a Cris IA" saiu da primeira tela e ficou logo abaixo (ao rolar).
Layout azul: igual à imagem 2 (sem a etiqueta "3. Layout 2x2 Inteligente", que é só legenda da imagem). Barra com 7 abas.
A barra Cris Hidrata fica abaixo da dobra (ao rolar).
Lembretes e Alimentação (roxo) e Perfil (azul) continuam acessíveis pelo menu Mais.

Compilação: NÃO verificada (sem Gradle/internet no ambiente). Rodar ./gradlew assembleDebug.
Layout azul: sem a faixa do humor; tocar na saudação abre a escolha de humor.
