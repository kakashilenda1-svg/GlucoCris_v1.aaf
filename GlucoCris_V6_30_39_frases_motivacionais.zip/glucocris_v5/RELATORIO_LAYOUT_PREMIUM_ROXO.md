# Relatório — cabeçalho e layout GlucoCris

Base utilizada: GlucoCris_V6_4_Layout2x2_ProfessionalPink.aaf (1).zip.

A tela inicial já contém a apresentação roxa/azul e os três controles no cabeçalho:
- Perfil: abre a tela existente Routes.PROFILE.
- Troca de layout: alterna a configuração blueTheme existente.
- Ajuda: abre a central existente Routes.HELP_CENTER.

A tela inicial mantém a última medição, humor, contagens de glicemia e insulina, Cris IA, mensagem fixa e o conteúdo subsequente (incluindo o restante da tela rolável). O menu Mais não contém uma entrada de Perfil nesta versão; por isso nenhuma função foi removida dali. O guia de introdução foi ajustado para orientar o usuário ao novo acesso pelo cabeçalho.

Não foram alterados banco de dados, modelos, autenticação, biometria, cálculos ou telas não relacionadas.

Compilação: não verificada. O Gradle Wrapper tentou baixar Gradle 8.11.1, mas o ambiente estava sem acesso DNS a services.gradle.org (UnknownHostException). É necessário executar ./gradlew assembleDebug em ambiente com acesso à internet/Gradle disponível.
