package com.agon.app.cloud

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.agon.app.MainActivity
import com.agon.app.R
import com.agon.app.data.AppData
import com.agon.app.data.GlucoStorage
import com.agon.app.data.GlucoViewModel
import com.agon.app.notifications.NotificationCenter
import com.agon.app.reminders.ReminderScheduler
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.security.KeyStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Backup automático: a cada ~24 h grava um arquivo criptografado (o mesmo formato do backup manual, AES-256-GCM)
 * numa PASTA que a pessoa escolhe uma vez (Google Drive, cartão, Downloads...). Mantém só os 7 mais recentes.
 *
 * A senha é escolhida uma vez e guardada cifrada pelo Android Keystore (só este app a lê). Para restaurar em outro
 * celular a pessoa usa a MESMA senha na tela "Backup e recuperação". Sem a senha, o arquivo não abre: não há como recuperar.
 */
object AutoBackup {
    private const val PREFS = "gluco_auto_backup"
    private const val KS_ALIAS = "gluco_autobackup_key"
    private const val FILE_PREFIX = "GlucoCris_backup_"
    private const val KEEP = 7
    private const val EVERY_MS = 20L * 3_600_000L
    private const val WARN_AFTER_DAYS = 7
    private const val NOTIF_ID = 7752

    private fun p(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun enabled(c: Context) = p(c).getBoolean("enabled", false) && !p(c).getString("tree", "").isNullOrBlank()
    fun lastOkAt(c: Context) = p(c).getLong("last_ok", 0L)
    fun lastMessage(c: Context) = p(c).getString("last_msg", "") ?: ""
    fun folderLabel(c: Context): String = try {
        Uri.parse(p(c).getString("tree", "") ?: "").lastPathSegment?.substringAfter(':')?.ifBlank { null } ?: "pasta escolhida"
    } catch (_: Exception) { "pasta escolhida" }

    /** Dias desde o último backup bom (null se nunca houve). */
    fun daysSinceOk(c: Context, now: Long = System.currentTimeMillis()): Int? =
        lastOkAt(c).takeIf { it > 0 }?.let { ((now - it) / 86_400_000L).toInt() }

    // ---- senha protegida pelo Keystore ----
    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(KS_ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(KS_ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build(),
        )
        return gen.generateKey()
    }

    private fun storePassword(c: Context, pw: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        val ct = cipher.doFinal(pw.toByteArray(Charsets.UTF_8))
        p(c).edit().putString("pw", Base64.encodeToString(cipher.iv + ct, Base64.NO_WRAP)).apply()
    }

    private fun loadPassword(c: Context): CharArray? = try {
        val raw = Base64.decode(p(c).getString("pw", "") ?: return null, Base64.NO_WRAP)
        val iv = raw.copyOfRange(0, 12)
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, iv)) }
        String(cipher.doFinal(raw.copyOfRange(12, raw.size)), Charsets.UTF_8).toCharArray()
    } catch (_: Exception) { null }

    /** Liga o backup automático. [tree] = pasta escolhida com permissão persistida. */
    fun enable(c: Context, tree: Uri, password: String) {
        try {
            c.contentResolver.takePersistableUriPermission(tree, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        } catch (_: Exception) {}
        storePassword(c, password)
        p(c).edit().putString("tree", tree.toString()).putBoolean("enabled", true).putLong("armed_at", System.currentTimeMillis()).putLong("last_ok", 0L).putString("last_msg", "").apply()
        AutoBackupScheduler.ensure(c)
    }

    fun disable(c: Context) {
        p(c).edit().putBoolean("enabled", false).remove("pw").remove("tree").apply()
        try { WorkManager.getInstance(c.applicationContext).cancelUniqueWork(AutoBackupScheduler.NAME) } catch (_: Exception) {}
    }

    data class Outcome(val ok: Boolean, val message: String)

    /** Gera e grava um backup agora. */
    suspend fun runNow(c: Context, data: AppData): Outcome = withContext(Dispatchers.IO) {
        val app = c.applicationContext
        val tree = try { Uri.parse(p(app).getString("tree", "") ?: "") } catch (_: Exception) { null }
        val pw = loadPassword(app)
        if (tree == null || tree.toString().isBlank() || pw == null) return@withContext record(app, false, "Escolha de novo a pasta e a senha do backup automático.")
        if (data.glucose.isEmpty() && data.insulin.isEmpty() && data.meals.isEmpty()) return@withContext Outcome(true, "Sem dados para guardar ainda.")
        val res = LocalEncryptedBackup.export(data, pw)
        val bytes = res.bytes
        if (!res.ok || bytes == null) return@withContext record(app, false, res.message)
        try {
            val resolver = app.contentResolver
            val docId = DocumentsContract.getTreeDocumentId(tree)
            val parent = DocumentsContract.buildDocumentUriUsingTree(tree, docId)
            val name = FILE_PREFIX + SimpleDateFormat("yyyy-MM-dd_HHmm", Locale.US).format(Date()) + ".gcbackup"
            val doc = DocumentsContract.createDocument(resolver, parent, "application/octet-stream", name)
                ?: return@withContext record(app, false, "Não consegui criar o arquivo na pasta. Escolha a pasta de novo.")
            resolver.openOutputStream(doc)?.use { it.write(bytes) } ?: return@withContext record(app, false, "Não consegui gravar o backup.")
            prune(app, tree, docId)
            record(app, true, "Backup salvo em ${folderLabel(app)}.")
        } catch (e: Exception) {
            record(app, false, "Falha ao salvar: ${(e.message ?: "erro").take(80)}")
        }
    }

    private fun record(c: Context, ok: Boolean, msg: String): Outcome {
        val e = p(c).edit().putString("last_msg", msg)
        if (ok) e.putLong("last_ok", System.currentTimeMillis())
        e.apply()
        return Outcome(ok, msg)
    }

    private fun prune(c: Context, tree: Uri, docId: String) {
        try {
            val resolver = c.contentResolver
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, docId)
            val files = mutableListOf<Pair<String, String>>()
            resolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID, DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use { cur ->
                while (cur.moveToNext()) {
                    val name = cur.getString(1) ?: continue
                    if (name.startsWith(FILE_PREFIX)) files += cur.getString(0) to name
                }
            }
            files.sortedByDescending { it.second }.drop(KEEP).forEach { (id, _) ->
                try { DocumentsContract.deleteDocument(resolver, DocumentsContract.buildDocumentUriUsingTree(tree, id)) } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
    }

    /** Roda só se passou tempo suficiente desde o último backup bom (ou se nunca rodou). */
    suspend fun runIfDue(c: Context, data: AppData): Outcome? {
        if (!enabled(c)) return null
        if (System.currentTimeMillis() - lastOkAt(c) < EVERY_MS) return null
        return runNow(c, data)
    }

    /** Se o backup está ligado mas falha há dias, avisa uma vez (respeita a Central de notificações). */
    fun warnIfStale(c: Context) {
        if (!enabled(c)) return
        val ref = lastOkAt(c).takeIf { it > 0 } ?: p(c).getLong("armed_at", 0L)
        if (ref == 0L || System.currentTimeMillis() - ref < WARN_AFTER_DAYS * 86_400_000L) return
        val d = ((System.currentTimeMillis() - ref) / 86_400_000L).toInt()
        if (!NotificationCenter.allow(c, NotificationCenter.Cat.BACKUP)) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(c, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) return
        try {
            ReminderScheduler.ensureChannels(c)
            val open = Intent(c, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP }
            val text = "O backup automático não conseguiu salvar há ${if (d > 0) "$d dias" else "alguns dias"}. Toque para ver e corrigir."
            val b = NotificationCompat.Builder(c, ReminderScheduler.CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_drop)
                .setContentTitle("Backup precisa de atenção")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(c, NOTIF_ID, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            NotificationManagerCompat.from(c).notify(NOTIF_ID, b.build())
        } catch (_: Exception) {}
    }
}

class AutoBackupWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        return try {
            if (!AutoBackup.enabled(ctx)) return Result.success()
            val live = GlucoViewModel.liveInstance()
            val data = if (live != null && !live.practice.value) live.data.value else GlucoStorage.read(ctx)
            if (data != null) AutoBackup.runIfDue(ctx, data)
            AutoBackup.warnIfStale(ctx)
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            Result.success()
        }
    }
}

object AutoBackupScheduler {
    const val NAME = "gluco_auto_backup"
    fun ensure(ctx: Context) {
        try {
            val req = PeriodicWorkRequestBuilder<AutoBackupWorker>(6, TimeUnit.HOURS).build()
            WorkManager.getInstance(ctx.applicationContext).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
        } catch (_: Exception) {}
    }
}
