package com.agon.app.cloud

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.agon.app.data.AppData
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.tasks.Task
import com.google.firebase.Timestamp
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseAuthInvalidUserException
import com.google.firebase.auth.FirebaseAuthUserCollisionException
import com.google.firebase.auth.FirebaseAuthWeakPasswordException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MemoryCacheSettings
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class CloudState { SIGNED_OUT, IDLE, SYNCING, OK, OFFLINE, QUOTA, ACCOUNT_MISMATCH, EMAIL_UNVERIFIED, ERROR }

data class CloudStatus(
    val state: CloudState,
    val message: String = "",
    val lastSyncAt: Long = 0L,
)

/** Textos claros para os erros do Firebase Auth. [google] ajusta a mensagem de e-mail já existente. */
fun authErrorMessage(e: Throwable, google: Boolean = false): String = when (e) {
    is FirebaseNetworkException, is IOException ->
        "Sem conexão com a internet. Conecte-se e tente de novo."
    is FirebaseTooManyRequestsException ->
        "Muitas tentativas. Aguarde alguns minutos e tente de novo."
    is FirebaseAuthUserCollisionException ->
        if (google) "Já existe uma conta com este e-mail. Entre com e-mail e senha e use \"Vincular Google\" no Perfil."
        else "Este e-mail já está cadastrado. Entre com seu e-mail e senha, toque em \"Esqueci minha senha\" ou continue com o Google."
    is FirebaseAuthWeakPasswordException ->
        "Senha fraca. Use pelo menos 8 caracteres, misturando letras e números."
    is FirebaseAuthInvalidUserException ->
        "E-mail ou senha incorretos."
    is FirebaseAuthInvalidCredentialsException ->
        if (e.errorCode == "ERROR_INVALID_EMAIL") "E-mail inválido. Confira como ele foi digitado." else "E-mail ou senha incorretos."
    is FirebaseAuthException -> when (e.errorCode) {
        "ERROR_USER_DISABLED" -> "Esta conta foi desativada."
        "ERROR_OPERATION_NOT_ALLOWED" -> "Login por e-mail e senha ainda não está ativado no Firebase."
        "ERROR_REQUIRES_RECENT_LOGIN" -> "Por segurança, entre de novo e repita a operação."
        "ERROR_CREDENTIAL_ALREADY_IN_USE" -> "Este método de acesso já pertence a outra conta."
        else -> "Não foi possível concluir (${e.errorCode}). Tente de novo."
    }
    else -> "Não foi possível concluir. Tente de novo."
}

private class LocalQuotaException(message: String) : Exception(message)

/**
 * Backup/sincronização no Firestore (plano Spark).
 *
 * Caminho: users/{uid}/records/{tipo}__{id}  e  users/{uid}.
 * A fonte da verdade é SEMPRE o armazenamento local (DataStore). A nuvem é cópia:
 * qualquer falha (offline, cota, permissão) só muda o status; nada local é apagado ou alterado.
 */
class CloudBackup(context: Context) {
    private val ctx = context.applicationContext
    private val prefs = ctx.getSharedPreferences("cloud_sync", Context.MODE_PRIVATE)

    private val auth: FirebaseAuth
        get() = FirebaseAuth.getInstance().also {
            try { it.setLanguageCode("pt-BR") } catch (_: Exception) {}
        }

    // Cache só em memória: não cria segunda cópia persistente dos dados de saúde no aparelho
    // e não deixa o SDK enfileirar escritas "para sempre". Quem controla o reenvio é este código.
    private val db: FirebaseFirestore by lazy {
        val fs = FirebaseFirestore.getInstance()
        try {
            fs.firestoreSettings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(MemoryCacheSettings.newBuilder().build())
                .build()
        } catch (_: IllegalStateException) {
            // já inicializado nesta execução; segue com as configurações atuais
        }
        fs
    }

    // ---------- Login (sempre Google; nunca anônimo) ----------

    /** UID do Firebase da pessoa logada com Google; null se ninguém ou se (por engano) for anônimo. */
    fun currentUid(): String? = auth.currentUser?.takeIf { !it.isAnonymous }?.uid

    suspend fun signInWithGoogleIdToken(idToken: String): String {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        val result = net { auth.signInWithCredential(credential).awaitValue() }
        val user = result.user ?: throw IllegalStateException("Login sem usuário")
        if (user.isAnonymous) {
            auth.signOut()
            throw IllegalStateException("Login anônimo não é permitido")
        }
        return user.uid
    }

    fun signOut() {
        try { auth.signOut() } catch (_: Exception) {}
        // Desconecta também o Google Sign-In Client para a próxima entrada pedir a conta
        // (sem isso o Google reutiliza a última conta sem mostrar o seletor).
        try {
            val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .requestProfile()
                .apply {
                    val id = ctx.resources.getIdentifier("default_web_client_id", "string", ctx.packageName)
                    if (id != 0) requestIdToken(ctx.getString(id))
                }
                .build()
            GoogleSignIn.getClient(ctx, gso).signOut()
        } catch (_: Exception) {
            // Firebase já saiu; o seletor ainda pode ser forçado na UI.
        }
    }

    // ---------- E-mail e senha ----------

    private fun user(): FirebaseUser? = auth.currentUser?.takeIf { !it.isAnonymous }

    /** "google.com" e/ou "password" ligados à conta atual. */
    fun providers(): Set<String> =
        user()?.providerData?.map { it.providerId }?.filter { it == "google.com" || it == "password" }?.toSet().orEmpty()

    fun currentEmail(): String = user()?.email.orEmpty()
    fun currentDisplayName(): String = user()?.displayName.orEmpty()
    // Sem verificação de e-mail: qualquer conta logada (Google ou e-mail/senha) já libera o backup.
    fun isEmailVerified(): Boolean = user() != null

    /** E-mail de quem criou conta com senha mas ainda não verificou (sessão guardada pelo Firebase). */
    fun pendingVerificationEmail(): String? =
        null

    suspend fun createEmailAccount(name: String, email: String, password: String) {
        val result = net { auth.createUserWithEmailAndPassword(email.trim(), password).awaitValue() }
        val u = result.user ?: throw IllegalStateException("Cadastro sem usuário")
        try {
            val req = UserProfileChangeRequest.Builder().setDisplayName(name.trim()).build()
            net { u.updateProfile(req).awaitDone() }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            // o nome é só de exibição; a conta já foi criada
        }
    }

    /** Sem verificação de e-mail: entrar com e-mail e senha corretos já libera o acesso. */
    suspend fun signInWithEmail(email: String, password: String): Boolean {
        val result = net { auth.signInWithEmailAndPassword(email.trim(), password).awaitValue() }
        val u = result.user ?: throw IllegalStateException("Login sem usuário")
        return true
    }

    suspend fun sendVerification() {
        val u = user() ?: throw IllegalStateException("Sem sessão")
        net { u.sendEmailVerification().awaitDone() }
    }

    /** Recarrega a conta e renova o token (as regras do Firestore leem email_verified do token). */
    suspend fun refreshVerified(): Boolean {
        val u = user() ?: return false
        net { u.reload().awaitDone() }
        val fresh = user() ?: return false
        if (fresh.isEmailVerified) net { fresh.getIdToken(true).awaitValue() }
        return fresh.isEmailVerified
    }

    suspend fun sendPasswordReset(email: String) {
        net { auth.sendPasswordResetEmail(email.trim()).awaitDone() }
    }

    /** Adiciona e-mail/senha à conta atual (mesmo UID). */
    suspend fun linkPassword(password: String) {
        val u = user() ?: throw IllegalStateException("Sem sessão")
        val email = u.email ?: throw IllegalStateException("Conta sem e-mail")
        net { u.linkWithCredential(EmailAuthProvider.getCredential(email, password)).awaitValue() }
        net { u.reload().awaitDone() }
    }

    /** Liga uma conta Google à conta atual (mesmo UID). */
    suspend fun linkGoogleCredential(idToken: String) {
        val u = user() ?: throw IllegalStateException("Sem sessão")
        net { u.linkWithCredential(GoogleAuthProvider.getCredential(idToken, null)).awaitValue() }
        net { u.reload().awaitDone() }
    }

    // ---------- Estado local do sync (SharedPreferences, por UID) ----------

    fun initialStatus(): CloudStatus {
        val uid = currentUid() ?: return CloudStatus(CloudState.SIGNED_OUT, "Entre na sua conta para ativar o backup.")
        if (!isEmailVerified()) return CloudStatus(CloudState.EMAIL_UNVERIFIED, "Verifique seu e-mail para ativar o backup.")
        return CloudStatus(CloudState.IDLE, "", prefs.getLong("lastsync_$uid", 0L))
    }

    /** Dados deste aparelho passam a pertencer à conta atual (decisão explícita da pessoa). */
    fun adoptCurrentAccount(resetCursors: Boolean) {
        val uid = currentUid() ?: return
        val ed = prefs.edit()
        ed.putString("owner_uid", uid)
        if (resetCursors) {
            ed.remove("cursor_$uid")
            ed.remove("lastpush_$uid")
        }
        ed.apply()
    }

    /** UID da conta dona dos dados que estão neste aparelho (null = ainda ninguém). */
    fun ownerUid(): String? = prefs.getString("owner_uid", null)

    /** Último envio concluído para a conta que era dona dos dados deste aparelho (-1 = nunca enviou). */
    fun previousOwnerLastPush(): Long {
        val owner = prefs.getString("owner_uid", null) ?: return -1L
        return prefs.getLong("lastpush_$owner", -1L)
    }

    /** A conta que era dona dos dados deste aparelho tem registros que o Firebase recusou (ainda só estão aqui)? */
    fun previousOwnerHasSkipped(): Boolean {
        val owner = prefs.getString("owner_uid", null) ?: return false
        return !prefs.getString("skipped_$owner", "").isNullOrBlank()
    }

    private fun readCursor(uid: String): Timestamp {
        val raw = prefs.getString("cursor_$uid", null) ?: return Timestamp(0, 0)
        val p = raw.split(":")
        val s = p.getOrNull(0)?.toLongOrNull() ?: return Timestamp(0, 0)
        val n = p.getOrNull(1)?.toIntOrNull() ?: 0
        return Timestamp(s, n)
    }

    private fun saveCursor(uid: String, ts: Timestamp) {
        prefs.edit().putString("cursor_$uid", "${ts.seconds}:${ts.nanoseconds}").apply()
    }

    // ---------- Cota do Spark (limites diários: 50 mil leituras, 20 mil gravações) ----------

    private fun dayKey(): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    private fun counter(prefix: String): Int = prefs.getInt("${prefix}_${dayKey()}", 0)

    private fun addCount(prefix: String, n: Int) {
        val day = dayKey()
        val ed = prefs.edit()
        prefs.all.keys.filter { (it.startsWith("r_") || it.startsWith("w_")) && !it.endsWith(day) }.forEach { ed.remove(it) }
        ed.putInt("${prefix}_$day", counter(prefix) + n).apply()
    }

    private fun nextMorning(): Long = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, 1)
        set(Calendar.HOUR_OF_DAY, 6); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun checkBudget(reads: Int, writes: Int) {
        if (counter("r") + reads > READ_BUDGET || counter("w") + writes > WRITE_BUDGET) {
            prefs.edit().putLong("blocked_until", nextMorning()).apply()
            throw LocalQuotaException("Limite diário gratuito quase no fim; o backup volta amanhã.")
        }
    }

    // ---------- Rede ----------

    fun isOnline(): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private suspend fun <T : Any> net(block: suspend () -> T): T =
        withTimeoutOrNull(NET_TIMEOUT_MS) { block() } ?: throw IOException("tempo esgotado")

    private suspend fun <T : Any> Task<T>.awaitValue(): T = suspendCancellableCoroutine { c ->
        addOnSuccessListener { v -> if (v != null) c.resume(v) else c.resumeWithException(IllegalStateException("vazio")) }
        addOnFailureListener { e -> c.resumeWithException(e) }
        addOnCanceledListener { c.cancel() }
    }

    private suspend fun Task<*>.awaitDone(): Boolean = suspendCancellableCoroutine { c ->
        addOnSuccessListener { c.resume(true) }
        addOnFailureListener { e -> c.resumeWithException(e) }
        addOnCanceledListener { c.cancel() }
    }

    // ---------- Firestore ----------

    private fun records(uid: String) = db.collection("users").document(uid).collection("records")

    private class Pulled(val docs: List<RemoteDoc>, val cursor: Timestamp)

    private suspend fun pull(uid: String, restore: Boolean): Pulled {
        val start = if (restore) Timestamp(0, 0) else readCursor(uid)
        var maxTs = start
        var last: DocumentSnapshot? = null
        val out = ArrayList<RemoteDoc>()
        while (true) {
            checkBudget(reads = PAGE, writes = 0)
            var q: Query = records(uid).whereGreaterThan("syncedAt", start).orderBy("syncedAt").limit(PAGE.toLong())
            if (last != null) q = q.startAfter(last)
            val snap = net { q.get(Source.SERVER).awaitValue() }
            addCount("r", maxOf(1, snap.size()))
            for (d in snap.documents) {
                val type = d.getString("type") ?: continue
                val id = d.getString("id") ?: continue
                if (type !in SyncMerge.TYPES) continue
                val upd = d.getLong("updatedAt") ?: continue
                out += RemoteDoc(type, id, upd, d.getBoolean("deleted") ?: false, d.getString("payload").orEmpty())
                d.getTimestamp("syncedAt")?.let { if (it > maxTs) maxTs = it }
            }
            if (snap.size() < PAGE) break
            last = snap.documents.last()
        }
        return Pulled(out, maxTs)
    }

    // ---------- Registros que o Firebase recusa (isolados para não travar o resto) ----------

    private class Skipped(val updatedAt: Long, val failedAt: Long)

    private fun loadSkipped(uid: String): MutableMap<String, Skipped> {
        val out = LinkedHashMap<String, Skipped>()
        val raw = prefs.getString("skipped_$uid", "") ?: ""
        raw.lines().forEach { line ->
            val p = line.split("|")
            if (p.size == 3) {
                val u = p[1].toLongOrNull() ?: return@forEach
                val f = p[2].toLongOrNull() ?: return@forEach
                out[p[0]] = Skipped(u, f)
            }
        }
        return out
    }

    private fun saveSkipped(uid: String, map: Map<String, Skipped>) {
        val ed = prefs.edit()
        if (map.isEmpty()) ed.remove("skipped_$uid")
        else ed.putString("skipped_$uid", map.entries.joinToString("\n") { "${it.key}|${it.value.updatedAt}|${it.value.failedAt}" })
        ed.apply()
    }

    private class Pending(val docs: List<RemoteDoc>, val knownIds: Set<String>?)

    /**
     * O que enviar agora. Registros que o Firebase já recusou (grandes demais ou barrados pelas regras) não são
     * reenviados até mudarem ou até passarem 6 horas (assim voltam sozinhos quando as regras forem atualizadas).
     */
    private suspend fun collectPending(uid: String, local: AppData, seen: Map<String, Long>, lastPush: Long, cloudWins: Boolean = false): Pending {
        val base = SyncMerge.pending(local, seen, lastPush) + ExtraSync.pending(ctx, seen, lastPush, cloudWins)
        val sk = loadSkipped(uid)
        if (sk.isEmpty()) return Pending(base, null)
        val now = System.currentTimeMillis()
        val full = SyncMerge.pending(local, seen, -1L) + ExtraSync.pending(ctx, seen, -1L)
        val fullById = full.associateBy { it.docId }
        val out = LinkedHashMap<String, RemoteDoc>()
        for (d in base) {
            val s = sk[d.docId]
            if (s != null && s.updatedAt == d.updatedAt && now - s.failedAt < RETRY_SKIPPED_MS) continue
            out[d.docId] = d
        }
        for ((id, s) in sk) {
            if (id in out || now - s.failedAt < RETRY_SKIPPED_MS) continue
            fullById[id]?.let { out[id] = it }
        }
        return Pending(out.values.toList(), fullById.keys)
    }

    private fun tooBig(d: RemoteDoc): Boolean {
        if (d.id.isEmpty() || d.id.length > 64) return true
        return if (d.type in ExtraSync.TYPES) d.payload.toByteArray(Charsets.UTF_8).size > ExtraSync.MAX_PAYLOAD_BYTES
        else d.payload.length > CORE_PAYLOAD_MAX_CHARS
    }

    /** Só estes erros indicam "este registro não serve"; os demais (rede, cota, sessão) continuam tratados como antes. */
    private fun isRejection(e: FirebaseFirestoreException) = e.code == FirebaseFirestoreException.Code.PERMISSION_DENIED ||
        e.code == FirebaseFirestoreException.Code.INVALID_ARGUMENT ||
        e.code == FirebaseFirestoreException.Code.FAILED_PRECONDITION ||
        e.code == FirebaseFirestoreException.Code.OUT_OF_RANGE

    private suspend fun commit(uid: String, chunk: List<RemoteDoc>, withControl: Boolean) {
        val batch = db.batch()
        for (d in chunk) {
            batch.set(
                records(uid).document(d.docId),
                mapOf(
                    "type" to d.type,
                    "id" to d.id,
                    "updatedAt" to d.updatedAt,
                    "deleted" to d.deleted,
                    "payload" to d.payload,
                    "schema" to 1L,
                    "syncedAt" to FieldValue.serverTimestamp(),
                ),
            )
        }
        if (withControl) {
            batch.set(
                db.collection("users").document(uid),
                mapOf("lastBackupAt" to FieldValue.serverTimestamp(), "schema" to 1L),
            )
        }
        net { batch.commit().awaitDone() }
        addCount("w", chunk.size + if (withControl) 1 else 0)
    }

    /**
     * Envia em lotes. Se um lote inteiro é recusado (um registro ruim derruba o lote todo), reenvia um por um:
     * os bons são salvos e só o registro ruim fica de fora. Devolve os que não puderam ser enviados.
     */
    private suspend fun push(uid: String, docs: List<RemoteDoc>): List<RemoteDoc> {
        if (docs.isEmpty()) return emptyList()
        val failed = ArrayList<RemoteDoc>()
        val sendable = docs.filter { d -> if (tooBig(d)) { failed += d; false } else true }
        val chunks = sendable.chunked(400)
        chunks.forEachIndexed { index, chunk ->
            val last = index == chunks.lastIndex
            checkBudget(reads = 0, writes = chunk.size + 1)
            try {
                commit(uid, chunk, last)
            } catch (e: FirebaseFirestoreException) {
                if (!isRejection(e)) throw e
                var ok = 0
                val bad = ArrayList<RemoteDoc>()
                for (d in chunk) {
                    checkBudget(reads = 0, writes = 1)
                    try {
                        commit(uid, listOf(d), false)
                        ok++
                    } catch (e2: FirebaseFirestoreException) {
                        if (!isRejection(e2)) throw e2
                        bad += d
                    }
                }
                // Nada passou: é problema de permissão/regras de verdade, não de um registro só. Mantém o aviso antigo.
                if (ok == 0 && failed.isEmpty() && bad.size == chunk.size && chunks.size == 1) throw e
                failed += bad
                if (last && ok > 0) {
                    try {
                        net {
                            db.collection("users").document(uid)
                                .set(mapOf("lastBackupAt" to FieldValue.serverTimestamp(), "schema" to 1L)).awaitDone()
                        }
                    } catch (e3: CancellationException) {
                        throw e3
                    } catch (_: Exception) {
                    }
                }
            }
        }
        return failed
    }

    private fun finishPush(uid: String, p: Pending, failed: List<RemoteDoc>): Int {
        val sk = loadSkipped(uid)
        val failedIds = failed.map { it.docId }.toSet()
        p.docs.forEach { if (it.docId !in failedIds) sk.remove(it.docId) }
        val now = System.currentTimeMillis()
        failed.forEach { sk[it.docId] = Skipped(it.updatedAt, now) }
        p.knownIds?.let { known -> sk.keys.retainAll(known + failedIds) }
        saveSkipped(uid, sk)
        return sk.size
    }

    private fun doneMessage(skipped: Int): String =
        if (skipped <= 0) "Backup em dia."
        else "Backup em dia, exceto $skipped registro${if (skipped > 1) "s" else ""} que o Firebase recusou (grande demais ou regras antigas). O restante foi salvo."

    /**
     * Um ciclo completo: baixar o que mudou na nuvem, enviar o que mudou aqui, aplicar o baixado.
     * [applyRemote] devolve false se não pôde aplicar agora (ex.: modo simulação); aí nada é marcado como feito.
     * Nunca lança: devolve o status.
     */
    suspend fun sync(
        getLocal: () -> AppData,
        applyRemote: (docs: List<RemoteDoc>, pruneBefore: Long) -> Boolean,
        restore: Boolean = false,
    ): CloudStatus = mutex.withLock {
        val uid = currentUid()
            ?: return@withLock CloudStatus(CloudState.SIGNED_OUT, "Entre na sua conta para ativar o backup.")
        if (!isEmailVerified()) {
            return@withLock CloudStatus(CloudState.EMAIL_UNVERIFIED, "Verifique seu e-mail para ativar o backup. Seus dados continuam no aparelho.")
        }
        if (!isOnline()) {
            return@withLock CloudStatus(CloudState.OFFLINE, "Sem internet. Seus dados continuam salvos no aparelho.", prefs.getLong("lastsync_$uid", 0L))
        }
        val now = System.currentTimeMillis()
        val blocked = prefs.getLong("blocked_until", 0L)
        if (blocked > now) {
            return@withLock CloudStatus(CloudState.QUOTA, "Limite diário gratuito do Firebase atingido. O backup tenta de novo mais tarde; nada foi perdido.", prefs.getLong("lastsync_$uid", 0L))
        }
        val owner = prefs.getString("owner_uid", null)
        if (owner != null && owner != uid) {
            return@withLock CloudStatus(CloudState.ACCOUNT_MISMATCH, "Os dados deste aparelho pertencem a outra conta Google.")
        }
        try {
            if (owner == null) prefs.edit().putString("owner_uid", uid).apply()
            val t0 = System.currentTimeMillis()
            val prevPush = prefs.getLong("lastpush_$uid", -1L)
            val lastPush = if (restore) -1L else prevPush
            val pulled = pull(uid, restore)
            val seen = HashMap<String, Long>()
            pulled.docs.forEach { seen[it.docId] = it.updatedAt }
            val pend = collectPending(uid, getLocal(), seen, lastPush, restore || owner == null)
            val failed = push(uid, pend.docs)
            val skipped = finishPush(uid, pend, failed)
            val pruneBefore = if (prevPush > 0) minOf(prevPush, t0 - PRUNE_MS) else -1L
            if (!applyRemote(pulled.docs, pruneBefore)) {
                return@withLock CloudStatus(CloudState.IDLE, "Backup adiado.", prefs.getLong("lastsync_$uid", 0L))
            }
            ExtraSync.applyRemote(ctx, pulled.docs, restore || owner == null)
            saveCursor(uid, pulled.cursor)
            val done = System.currentTimeMillis()
            prefs.edit().putLong("lastpush_$uid", t0 - 1).putLong("lastsync_$uid", done).apply()
            CloudStatus(CloudState.OK, doneMessage(skipped), done)
        } catch (e: CancellationException) {
            throw e
        } catch (e: LocalQuotaException) {
            CloudStatus(CloudState.QUOTA, e.message.orEmpty(), prefs.getLong("lastsync_$uid", 0L))
        } catch (e: FirebaseFirestoreException) {
            val last = prefs.getLong("lastsync_$uid", 0L)
            when (e.code) {
                FirebaseFirestoreException.Code.RESOURCE_EXHAUSTED -> {
                    prefs.edit().putLong("blocked_until", System.currentTimeMillis() + 3 * 3_600_000L).apply()
                    CloudStatus(CloudState.QUOTA, "Cota gratuita do Firebase esgotada hoje. Seus dados seguem no aparelho; o backup retoma sozinho.", last)
                }
                FirebaseFirestoreException.Code.UNAVAILABLE,
                FirebaseFirestoreException.Code.DEADLINE_EXCEEDED ->
                    CloudStatus(CloudState.OFFLINE, "Sem conexão com o servidor. Seus dados continuam no aparelho.", last)
                FirebaseFirestoreException.Code.PERMISSION_DENIED ->
                    CloudStatus(CloudState.ERROR, "Permissão negada pelo Firebase. Confira se as regras foram publicadas e se o login é Google.", last)
                FirebaseFirestoreException.Code.UNAUTHENTICATED ->
                    CloudStatus(CloudState.SIGNED_OUT, "Sessão expirada. Entre na sua conta de novo.", last)
                else -> CloudStatus(CloudState.ERROR, "Falha no backup (${e.code}). Seus dados continuam no aparelho.", last)
            }
        } catch (e: IOException) {
            CloudStatus(CloudState.OFFLINE, "Conexão instável. Seus dados continuam no aparelho.", prefs.getLong("lastsync_$uid", 0L))
        } catch (e: Exception) {
            CloudStatus(CloudState.ERROR, "Falha no backup. Seus dados continuam no aparelho.", prefs.getLong("lastsync_$uid", 0L))
        }
    }

    /**
     * Envio em segundo plano (sem o app aberto): só ENVIA o que está pendente. Não aplica nada da nuvem no aparelho
     * e não mexe no cursor de leitura; quem baixa e aplica é o ciclo normal, com o app aberto.
     * Sem pendências não faz nenhuma chamada de rede.
     */
    suspend fun backgroundPush(getLocal: () -> AppData): CloudStatus = mutex.withLock {
        val uid = currentUid()
            ?: return@withLock CloudStatus(CloudState.SIGNED_OUT, "Entre na sua conta para ativar o backup.")
        val last = prefs.getLong("lastsync_$uid", 0L)
        val owner = prefs.getString("owner_uid", null)
        if (owner != null && owner != uid) return@withLock CloudStatus(CloudState.ACCOUNT_MISMATCH, "Os dados deste aparelho pertencem a outra conta Google.", last)
        if (prefs.getLong("blocked_until", 0L) > System.currentTimeMillis()) return@withLock CloudStatus(CloudState.QUOTA, "Limite diário gratuito do Firebase atingido.", last)
        val t0 = System.currentTimeMillis()
        val lastPush = prefs.getLong("lastpush_$uid", -1L)
        val local = getLocal()
        try {
            if (collectPending(uid, local, emptyMap(), lastPush).docs.isEmpty()) return@withLock CloudStatus(CloudState.OK, "Nada pendente.", last)
            if (!isOnline()) return@withLock CloudStatus(CloudState.OFFLINE, "Sem internet. Seus dados continuam salvos no aparelho.", last)
            // Lê o que mudou na nuvem só para não sobrescrever algo mais novo vindo de outro aparelho (não aplica, não move o cursor)
            val pulled = pull(uid, false)
            val seen = HashMap<String, Long>()
            pulled.docs.forEach { seen[it.docId] = it.updatedAt }
            val pend = collectPending(uid, local, seen, lastPush)
            val failed = push(uid, pend.docs)
            val skipped = finishPush(uid, pend, failed)
            val done = System.currentTimeMillis()
            prefs.edit().putLong("lastpush_$uid", t0 - 1).putLong("lastsync_$uid", done).apply()
            CloudStatus(CloudState.OK, doneMessage(skipped), done)
        } catch (e: CancellationException) {
            throw e
        } catch (e: LocalQuotaException) {
            CloudStatus(CloudState.QUOTA, e.message.orEmpty(), last)
        } catch (e: FirebaseFirestoreException) {
            if (e.code == FirebaseFirestoreException.Code.RESOURCE_EXHAUSTED) prefs.edit().putLong("blocked_until", System.currentTimeMillis() + 3 * 3_600_000L).apply()
            CloudStatus(CloudState.ERROR, "Falha no backup (${e.code}).", last)
        } catch (e: Exception) {
            CloudStatus(CloudState.OFFLINE, "Conexão instável. Seus dados continuam no aparelho.", last)
        }
    }

    companion object {
        // Compartilhado entre instâncias: o app aberto e o envio em segundo plano nunca rodam ao mesmo tempo
        private val mutex = Mutex()

        // Limite das regras do Firestore para os registros de sempre (payload.size() <= 20000)
        private const val CORE_PAYLOAD_MAX_CHARS = 20_000
        private const val RETRY_SKIPPED_MS = 6L * 3_600_000L

        private const val PAGE = 500
        private const val NET_TIMEOUT_MS = 25_000L
        private const val PRUNE_MS = 90L * 24 * 3_600_000L

        // Margem de segurança sobre os limites do Spark (50.000 leituras e 20.000 gravações por dia)
        private const val READ_BUDGET = 40_000
        private const val WRITE_BUDGET = 16_000
    }
}
