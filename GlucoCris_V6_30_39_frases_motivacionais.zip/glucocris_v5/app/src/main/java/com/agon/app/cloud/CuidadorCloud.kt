package com.agon.app.cloud

import android.content.Context
import com.agon.app.data.AppData
import com.google.android.gms.tasks.Task
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout

data class CuidadorRequest(val uid: String, val name: String, val email: String, val relation: String)
data class CuidadorLink(val uid: String, val name: String, val email: String, val relation: String, val status: String, val permissions: Map<String, Boolean>)
data class CuidadorCarePlan(val lowGlucose: String = "", val highGlucose: String = "", val emergencyWhen: String = "", val agreed: String = "")
data class CuidadorContactRequest(val id: String, val fromName: String, val message: String, val atMs: Long)
data class CuidadorPairing(val code: String, val expiresInMin: Int)
data class CuidadorResult(val ok: Boolean, val sent: Int, val message: String)

/**
 * Ponte online Paciente -> app "Gluco Cris Cuidador" (só Firestore + Worker de push; SEM Cloud Functions, plano gratuito Spark).
 * Pareamento, vínculos e permissões são gravados aqui e validados pelas regras do Firestore (firestore.rules).
 * Os cálculos (glicemia atual, tendência, alertas, GMI, cobertura, tempo no alvo) vêm de [CuidadorCompute].
 * O único serviço externo é o Worker do Cloudflare (backend/cuidador-push), usado só para enviar push a OUTRO aparelho.
 * Nunca lança para o chamador no fluxo de sincronização: qualquer falha vira [CuidadorResult] e o que não foi
 * enviado é tentado de novo na próxima sincronização. Não altera nada do backup existente (users/{uid}/records).
 */
object CuidadorCloud {
    private const val NET_TIMEOUT_MS = 25_000L
    private val mutex = Mutex()

    private val auth get() = FirebaseAuth.getInstance()
    private val db get() = FirebaseFirestore.getInstance()

    /** Mesma regra do backup: conta real (Google ou e-mail/senha), nunca anônima. */
    fun uid(): String? = auth.currentUser?.takeIf { !it.isAnonymous }?.uid

    private suspend fun <T> Task<T>.await(): T = suspendCancellableCoroutine { c ->
        addOnSuccessListener { if (c.isActive) c.resumeWith(Result.success(it)) }
        addOnFailureListener { if (c.isActive) c.resumeWith(Result.failure(it)) }
        addOnCanceledListener { c.cancel() }
    }

    private suspend fun <T> net(block: suspend () -> T): T = withTimeout(NET_TIMEOUT_MS) { block() }

    private fun ts(ms: Long) = Timestamp(ms / 1000, ((ms % 1000) * 1_000_000).toInt())

    fun friendly(e: Throwable): String = when (e) {
        is kotlinx.coroutines.TimeoutCancellationException -> "Sem resposta da internet. Tentarei de novo."
        is FirebaseFirestoreException -> when (e.code) {
            FirebaseFirestoreException.Code.PERMISSION_DENIED ->
                "O servidor recusou (regras do Firestore). Publique o firestore.rules desta versão no console do Firebase."
            FirebaseFirestoreException.Code.UNAVAILABLE -> "Sem internet no momento. Tentarei de novo."
            FirebaseFirestoreException.Code.RESOURCE_EXHAUSTED -> "Limite diário do Firebase atingido. Tentarei mais tarde."
            FirebaseFirestoreException.Code.UNAUTHENTICATED -> "Entre na sua conta para compartilhar."
            else -> "Falha ao falar com o servidor (${e.code})."
        }
        else -> "Falha inesperada ao compartilhar."
    }

    // ------------------------------------------------------------------ sincronização automática

    /**
     * Chamada após cada sincronização (app aberto, trabalho em segundo plano e importação de sensor).
     * Sem o "Cuidador online" ligado ou sem conta, não faz nada e não usa rede.
     */
    suspend fun syncIfEnabled(ctx: Context, data: AppData): CuidadorResult {
        val app = ctx.applicationContext
        if (!CuidadorPrefs.enabled(app)) return CuidadorResult(true, 0, "Desligado")
        val me = uid() ?: return CuidadorResult(false, 0, "Entre na sua conta para compartilhar.")
        return mutex.withLock {
            withContext(Dispatchers.IO) {
                try {
                    if (CuidadorPrefs.ownerUid(app) != me) {
                        CuidadorPrefs.resetSyncState(app)
                        CuidadorPrefs.setOwnerUid(app, me)
                    }
                    val snap = CuidadorSnapshot.of(app, data)
                    val now = System.currentTimeMillis()

                    pushProfile(app, me, snap, now)
                    val sent = pushReadings(app, me, snap, now)
                    publishDerived(app, me, snap, now)
                    publishExtras(app, me, snap, now)
                    pushHba1c(app, me, snap)
                    heartbeat(app, me, snap, now)
                    // Push de "pedido de acesso" / "pedido de contato": falha aqui nunca derruba a sincronização.
                    runCatching { ensurePushToken(app, me) }

                    CuidadorPrefs.setLastOk(app, now)
                    CuidadorPrefs.setLastMsg(app, "")
                    CuidadorResult(true, sent, if (sent > 0) "$sent leitura(s) enviada(s)." else "Tudo em dia.")
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (e: Exception) {
                    val msg = friendly(e)
                    CuidadorPrefs.setLastMsg(app, msg)
                    CuidadorResult(false, 0, msg)
                }
            }
        }
    }

    /** Perfil/limites: só reenvia quando algo mudou (o backend aceita apenas estas chaves no update). */
    private suspend fun pushProfile(app: Context, pid: String, s: CuidadorSnapshot, now: Long) {
        val th = CuidadorOnline.thresholds(s.targetLow, s.targetHigh, s.severeLow, s.severeHigh)
        val tz = CuidadorOnline.tzOffsetMin(now)
        val interval = 15 // o importador de sensor grava 1 leitura a cada 15 min
        val stale = CuidadorOnline.STALE_AFTER_MIN
        val hash = listOf(s.displayName, th, tz, s.cgmConfigured, interval, stale).hashCode()
        if (hash == CuidadorPrefs.lastProfileHash(app)) return
        net {
            db.document("patients/$pid").set(
                mapOf(
                    "displayName" to s.displayName,
                    "thresholds" to th,
                    "cgmExpected" to s.cgmConfigured,
                    "cgmIntervalMin" to interval,
                    "staleAfterMin" to stale,
                    "tzOffsetMin" to tz,
                ),
                SetOptions.merge(),
            ).await()
        }
        CuidadorPrefs.setLastProfileHash(app, hash)
    }

    private fun readingMap(e: com.agon.app.data.GlucoseEntry, mg: Int): Map<String, Any> {
        val m = mutableMapOf<String, Any>(
            "value" to mg,
            "unit" to "mg/dL",
            "source" to CuidadorOnline.sourceOf(e.id),
            "originTs" to ts(e.at),
            "serverTs" to FieldValue.serverTimestamp(),
        )
        CuidadorOnline.deviceOf(e.id)?.let { m["deviceId"] = it }
        return m
    }

    /** Envia as leituras pendentes (mais antigas primeiro). Retorna quantas foram confirmadas pelo servidor. */
    private suspend fun pushReadings(app: Context, pid: String, s: CuidadorSnapshot, now: Long): Int {
        val sentMap = CuidadorPrefs.sent(app).toMutableMap()
        val first = sentMap.isEmpty()
        val window = if (first) CuidadorOnline.FIRST_BACKFILL_MS else CuidadorOnline.MAX_PENDING_MS
        val todo = CuidadorOnline.pending(s.readings, sentMap.keys, now, window)
        if (todo.isEmpty()) {
            // Marca as leituras antigas como "já tratadas" para a janela da primeira vez não repetir
            if (first) s.readings.filter { !CuidadorOnline.isDemo(it) }.forEach { sentMap[it.id] = it.at }
            CuidadorPrefs.saveSent(app, sentMap, now)
            return 0
        }
        var confirmed = 0
        var firstError: Exception? = null
        for (chunk in todo.chunked(CuidadorOnline.BATCH)) {
            try {
                net {
                    val b = db.batch()
                    for (e in chunk) b.set(db.document("patients/$pid/readings/${e.id}"), readingMap(e, CuidadorOnline.readingMg(e)!!))
                    b.commit().await()
                }
                chunk.forEach { sentMap[it.id] = it.at }
                confirmed += chunk.size
            } catch (e: FirebaseFirestoreException) {
                if (e.code != FirebaseFirestoreException.Code.PERMISSION_DENIED) { firstError = firstError ?: e; break }
                // Provável: alguma já existe (regras não permitem update). Resolve uma a uma.
                for (x in chunk) {
                    try {
                        val exists: DocumentSnapshot = net { db.document("patients/$pid/readings/${x.id}").get().await() }
                        if (!exists.exists()) {
                            net { db.document("patients/$pid/readings/${x.id}").set(readingMap(x, CuidadorOnline.readingMg(x)!!)).await() }
                            confirmed++
                        }
                        sentMap[x.id] = x.at
                    } catch (e2: Exception) {
                        firstError = firstError ?: e2
                        break
                    }
                }
            } catch (e: Exception) {
                firstError = firstError ?: e
                break
            }
        }
        // Mesmo com erro, o que foi confirmado fica registrado (não reenvia); o resto tenta de novo depois.
        if (first) s.readings.filter { !CuidadorOnline.isDemo(it) && now - it.at > window }.forEach { sentMap[it.id] = it.at }
        CuidadorPrefs.saveSent(app, sentMap, now)
        firstError?.let { throw it }
        return confirmed
    }

    // ------------------------------------------------------------------ cálculos que antes eram do servidor

    /**
     * Publica o que o Cuidador lê pronto: glicemia atual, tendência, alerta, e (a cada ~1 h) GMI, cobertura,
     * tempo no alvo e perfil por hora. Só mexe quando há leitura nova enviada; é seguro repetir (idempotente).
     */
    private suspend fun publishDerived(app: Context, pid: String, s: CuidadorSnapshot, now: Long) {
        val th = CuidadorCompute.Th.from(CuidadorOnline.thresholds(s.targetLow, s.targetHigh, s.severeLow, s.severeHigh))
        val sentIds = CuidadorPrefs.sent(app).keys
        val valid = s.readings.asSequence()
            .filter { !CuidadorOnline.isDemo(it) }
            .mapNotNull { e -> CuidadorOnline.readingMg(e)?.let { mg -> CuidadorCompute.Pt(e.id, e.at, mg, CuidadorOnline.sourceOf(e.id)) } }
            .sortedBy { it.ms }
            .toList()
        // "Atual" = a leitura mais nova entre as JÁ ENVIADAS (a mesma regra de antes: o servidor só via o que chegou).
        val newest = valid.lastOrNull { it.id in sentIds }
        if (newest != null && newest.id != CuidadorPrefs.lastLatestId(app)) {
            val tr = CuidadorCompute.trend(valid.filter { it.id in sentIds }.takeLast(4))
            net {
                db.document("patients/$pid/current/latest").set(
                    mapOf(
                        "value" to newest.mg, "unit" to "mg/dL", "source" to newest.source,
                        "originTs" to ts(newest.ms), "serverTs" to FieldValue.serverTimestamp(),
                        "processedAt" to FieldValue.serverTimestamp(), "readingId" to newest.id,
                        "state" to CuidadorCompute.stateOf(newest.mg, th),
                    ),
                ).await()
            }
            net {
                db.document("patients/$pid/current/trend").set(
                    mapOf("arrow" to tr.arrow, "ratePerMin" to tr.ratePerMin, "computedAt" to FieldValue.serverTimestamp()),
                ).await()
            }
            net { db.document("patients/$pid").set(mapOf("lastReadingAt" to ts(newest.ms)), SetOptions.merge()).await() }
            if (now - newest.ms <= CuidadorCompute.ALERT_MAX_AGE_MS) {
                CuidadorCompute.classify(newest.mg, th)?.let { createAlert(pid, newest, it) }
            }
            CuidadorPrefs.setLastLatestId(app, newest.id)
        }
        if (valid.isNotEmpty() && now - CuidadorPrefs.lastStatsAt(app) >= CuidadorCompute.STATS_EVERY_MS) {
            publishStats(pid, CuidadorCompute.stats(valid, th, 15, now, CuidadorOnline.tzOffsetMin(now)))
            CuidadorPrefs.setLastStatsAt(app, now)
        }
    }

    /** Cria o alerta (id determinístico: o mesmo episódio nunca duplica) e pede o push ao Worker. */
    private suspend fun createAlert(pid: String, pt: CuidadorCompute.Pt, a: CuidadorCompute.AlertSpec) {
        val id = CuidadorCompute.alertId(a.type, pt.ms)
        val ref = db.document("patients/$pid/alerts/$id")
        if (net { ref.get().await() }.exists()) return
        net {
            ref.set(
                mapOf(
                    "id" to id, "type" to a.type, "severity" to a.severity, "severityLabel" to a.severityLabel,
                    "label" to a.label, "value" to pt.mg, "unit" to "mg/dL", "originTs" to ts(pt.ms),
                    "source" to pt.source, "createdAt" to FieldValue.serverTimestamp(),
                ),
            ).await()
        }
        notifyServer("alert", mapOf("alertId" to id))
    }

    private suspend fun publishStats(pid: String, st: CuidadorCompute.Stats) {
        val computed = FieldValue.serverTimestamp()
        net {
            val b = db.batch()
            val base = mapOf("periodDays" to CuidadorCompute.STATS_DAYS, "source" to "cgm", "n" to st.n)
            b.set(
                db.document("patients/$pid/stats/gmi"),
                base + mapOf("computedAt" to computed, "meanGlucose" to st.meanGlucose, "gmi" to st.gmi, "reliable" to st.reliable, "reason" to st.reason),
            )
            b.set(
                db.document("patients/$pid/stats/coverage"),
                base + mapOf("computedAt" to computed, "coveragePct" to st.coveragePct, "daysWithData" to st.daysWithData, "reliable" to st.reliable),
            )
            b.set(
                db.document("patients/$pid/stats/tir"),
                base + mapOf(
                    "computedAt" to computed, "timeInRangePct" to st.timeInRangePct, "timeBelowPct" to st.timeBelowPct,
                    "timeAbovePct" to st.timeAbovePct, "lowEpisodes" to st.lowEpisodes, "highEpisodes" to st.highEpisodes, "reliable" to st.reliable,
                ),
            )
            b.set(
                db.document("patients/$pid/chartData/hourlyProfile"),
                mapOf("computedAt" to computed, "points" to st.hourly.map { mapOf("hour" to it.first, "avg" to it.second) }),
            )
            b.commit().await()
        }
    }

    // ------------------------------------------------------------------ aviso ao Worker (push para OUTRO aparelho)

    /**
     * Pede ao Worker do Cloudflare que envie o push. O Worker confere o ID token e só envia o que existe no Firestore,
     * uma única vez. Falha aqui NUNCA derruba nada: o dado já está no Firestore e o app do outro lado o mostra ao abrir.
     */
    private suspend fun notifyServer(kind: String, params: Map<String, String>) {
        val base = com.agon.app.BuildConfig.CUIDADOR_PUSH_URL.trim().trimEnd('/')
        if (base.isBlank()) return
        runCatching {
            val user = auth.currentUser ?: return
            val idToken = net { user.getIdToken(false).await() }.token ?: return
            withContext(Dispatchers.IO) {
                val body = org.json.JSONObject().put("kind", kind).also { j -> params.forEach { (k, v) -> j.put(k, v) } }.toString()
                val c = java.net.URL("$base/v1/notify").openConnection() as java.net.HttpURLConnection
                try {
                    c.requestMethod = "POST"
                    c.connectTimeout = 10_000
                    c.readTimeout = 10_000
                    c.doOutput = true
                    c.setRequestProperty("Content-Type", "application/json")
                    c.setRequestProperty("Authorization", "Bearer $idToken")
                    c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    c.responseCode // consome a resposta; o resultado não muda o fluxo
                } finally {
                    c.disconnect()
                }
            }
        }
    }

    // ------------------------------------------------------------------ extras por permissão (insulina, refeições, ...)

    /** Permissões somadas dos cuidadores ATIVOS (só estas categorias saem do aparelho). */
    private suspend fun wantedCategories(pid: String): Set<String> {
        val links = net { db.collection("patients/$pid/links").get().await() }
        return CuidadorExtras.wanted(
            links.documents.filter { it.getString("status") == "active" }.map { parsePerms(it.get("permissions")) },
        )
    }

    private fun extraItems(cat: String, s: CuidadorSnapshot, now: Long): List<CuidadorExtras.Item> = when (cat) {
        "insulin" -> CuidadorExtras.insulin(s.insulin, now)
        "meals" -> CuidadorExtras.meals(s.meals, now)
        "symptoms" -> CuidadorExtras.symptoms(s.symptoms, now)
        "medications" -> CuidadorExtras.medications(s.medications)
        "reminders" -> CuidadorExtras.reminders(s.reminders)
        "water" -> CuidadorExtras.water(s.waterDayKey, s.waterDayStartMs, s.waterTotalMl, s.waterGoalMl, s.waterLastAtMs, s.waterCups)
        else -> emptyList()
    }

    /** Envia/atualiza/apaga as categorias extras. Idempotente: só grava o que mudou desde o último envio. */
    private suspend fun publishExtras(app: Context, pid: String, s: CuidadorSnapshot, now: Long) {
        val sentAny = CuidadorExtras.CATEGORIES.any { CuidadorPrefs.extraSent(app, it).isNotEmpty() }
        val wanted = wantedCategories(pid)
        if (wanted.isEmpty() && !sentAny) return
        for (cat in CuidadorExtras.CATEGORIES) {
            val sent = CuidadorPrefs.extraSent(app, cat).toMutableMap()
            val items = if (cat in wanted) extraItems(cat, s, now) else emptyList()
            val plan = CuidadorExtras.plan(sent, items)
            if (plan.write.isEmpty() && plan.delete.isEmpty()) continue
            // Cada operação: (id, item) = gravar; (id, null) = apagar. Lotes de 200.
            val ops: List<Pair<String, CuidadorExtras.Item?>> = plan.write.map { it.id to it } + plan.delete.map { it to null }
            for (chunk in ops.chunked(200)) {
                net {
                    val b = db.batch()
                    for ((id, item) in chunk) {
                        val ref = db.document("patients/$pid/$cat/$id")
                        if (item == null) {
                            b.delete(ref)
                        } else {
                            val data = item.data.toMutableMap()
                            item.atMs?.let { data["at"] = ts(it) }
                            if (cat == "water") data["updatedAt"] = FieldValue.serverTimestamp()
                            b.set(ref, data)
                        }
                    }
                    b.commit().await()
                }
                // confirmado pelo servidor: registra o que foi gravado/apagado
                for ((id, item) in chunk) { if (item == null) sent.remove(id) else sent[id] = item.sig }
                CuidadorPrefs.setExtraSent(app, cat, sent)
            }
        }
    }

    /** HbA1c de exame: poucos registros, então espelha tudo (inclui edições) e apaga o que foi excluído. */
    private suspend fun pushHba1c(app: Context, pid: String, s: CuidadorSnapshot) {
        val before = CuidadorPrefs.hba1cSent(app)
        val currentIds = s.hba1c.map { it.first }.toSet()
        val key = s.hba1c.joinToString("|") { "${it.first}:${it.second}:${it.third}:${s.hba1cLab[it.first]}" }.hashCode().toString()
        val sig = "sig:$key"
        if (before == currentIds + sig) return
        for ((id, pct, at) in s.hba1c) {
            net {
                db.document("patients/$pid/hba1c/$id").set(
                    mapOf("value" to pct, "examDate" to ts(at), "lab" to (s.hba1cLab[id]?.ifBlank { null })),
                ).await()
            }
        }
        for (gone in before.filter { !it.startsWith("sig:") && it !in currentIds }) {
            net { db.document("patients/$pid/hba1c/$gone").delete().await() }
        }
        // O "último HbA1c" que o Cuidador lê (antes feito pelo servidor): o exame mais recente, ou nada se não houver.
        val latest = s.hba1c.maxByOrNull { it.third }
        if (latest == null) {
            net { db.document("patients/$pid/hba1cLatest/main").delete().await() }
        } else {
            net {
                db.document("patients/$pid/hba1cLatest/main").set(
                    mapOf("id" to latest.first, "value" to latest.second, "examDate" to ts(latest.third), "lab" to (s.hba1cLab[latest.first]?.ifBlank { null })),
                ).await()
            }
        }
        CuidadorPrefs.setHba1cSent(app, currentIds + sig)
    }

    private suspend fun heartbeat(app: Context, pid: String, s: CuidadorSnapshot, now: Long) {
        val sentIds = CuidadorPrefs.sent(app).keys
        val pend = CuidadorOnline.pending(s.readings, sentIds, now, CuidadorOnline.MAX_PENDING_MS).size
        net {
            db.document("patients/$pid/syncStatus/status").set(
                mapOf(
                    "lastSyncAt" to FieldValue.serverTimestamp(),
                    "pendingCount" to pend,
                    "cgmState" to CuidadorOnline.cgmState(s.cgmConfigured, s.lastCgmMs, now, 15),
                    "lastCgmReadingAt" to (if (s.lastCgmMs > 0) ts(s.lastCgmMs) else null),
                ),
            ).await()
        }
    }

    // ------------------------------------------------------------------ ações da tela

    /** Botão "Estou bem". A ausência dele NÃO gera alerta. */
    suspend fun estouBem(): Result<Unit> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        net { db.collection("patients/$pid/okConfirmations").add(mapOf("ts" to FieldValue.serverTimestamp())).await() }
        Unit
    }

    private suspend fun patientName(pid: String): String =
        runCatching { net { db.document("patients/$pid").get().await() }.getString("displayName") }.getOrNull()?.ifBlank { null } ?: "Paciente"

    private fun cleanPerms(perms: Set<String>): Map<String, Boolean> =
        CuidadorOnline.PERMISSIONS.associate { it.first to (it.first in perms) }

    private fun mirrorMap(pid: String, name: String, status: String, perms: Map<String, Boolean>): Map<String, Any> = mapOf(
        "patientId" to pid, "patientName" to name.take(80), "status" to status,
        "permissions" to perms, "updatedAt" to FieldValue.serverTimestamp(),
    )

    /** Trilha de auditoria do paciente (só ele lê). Nunca derruba a ação principal. */
    private suspend fun audit(pid: String, type: String, target: String? = null, extra: Map<String, Any> = emptyMap()) {
        runCatching {
            val m = mutableMapOf<String, Any>("type" to type, "by" to pid, "ts" to FieldValue.serverTimestamp())
            if (target != null) m["target"] = target
            m.putAll(extra)
            net { db.collection("patients/$pid/audit").add(m).await() }
        }
    }

    /**
     * Gera o código (8 caracteres, vale 10 min) e grava só o SHA-256 dele em pairingCodes/{hash}.
     * Não precisa de servidor: as regras só deixam o próprio paciente criar o documento e o cuidador consumi-lo.
     */
    suspend fun newPairingCode(): Result<CuidadorPairing> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        val nowMs = System.currentTimeMillis()
        val mine = net { db.collection("pairingCodes").whereEqualTo("pid", pid).get().await() }
        var active = 0
        for (d in mine.documents) {
            val exp = d.getTimestamp("expiresAt")?.toDate()?.time ?: 0L
            if (exp < nowMs) runCatching { net { d.reference.delete().await() } } else active++
        }
        if (active >= CuidadorOnline.MAX_ACTIVE_CODES) error("Muitos códigos ativos. Aguarde alguns minutos ou revogue os anteriores.")
        val code = CuidadorOnline.newCode()
        val name = patientName(pid)
        net {
            db.document("pairingCodes/${CuidadorOnline.codeHash(code)}").set(
                mapOf(
                    "pid" to pid, "patientName" to name.take(80),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "expiresAt" to Timestamp(java.util.Date(nowMs + CuidadorOnline.CODE_TTL_MIN * 60_000L)),
                ),
            ).await()
        }
        audit(pid, "pairing_code_created")
        CuidadorPairing(code, CuidadorOnline.CODE_TTL_MIN)
    }

    /** Aprova (com as permissões escolhidas) ou recusa o pedido de um cuidador. */
    suspend fun respond(caregiverUid: String, approve: Boolean, perms: Set<String>): Result<Unit> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        val rqRef = db.document("patients/$pid/requests/$caregiverUid")
        val rq = net { rqRef.get().await() }
        if (!rq.exists() || rq.getString("status") != "pending") error("Solicitação inexistente ou já respondida.")
        val name = patientName(pid)
        val mirror = db.document("users/$caregiverUid/patients/$pid")
        if (!approve) {
            net {
                val b = db.batch()
                b.update(rqRef, mapOf("status" to "denied", "decidedAt" to FieldValue.serverTimestamp()))
                b.set(mirror, mirrorMap(pid, name, "denied", emptyMap()))
                b.commit().await()
            }
            audit(pid, "access_denied", caregiverUid)
        } else {
            val permMap = cleanPerms(perms)
            val link = mutableMapOf<String, Any>(
                "uid" to caregiverUid, "name" to (rq.getString("name") ?: "Cuidador").take(80),
                "relation" to (rq.getString("relation") ?: "").take(40),
                "status" to "active", "permissions" to permMap, "grantedAt" to FieldValue.serverTimestamp(),
            )
            rq.getString("email")?.let { link["email"] = it }
            net {
                val b = db.batch()
                b.set(db.document("patients/$pid/links/$caregiverUid"), link)
                b.update(rqRef, mapOf("status" to "approved", "decidedAt" to FieldValue.serverTimestamp()))
                b.set(mirror, mirrorMap(pid, name, "active", permMap))
                b.commit().await()
            }
            audit(pid, "access_granted", caregiverUid, mapOf("permissions" to permMap))
            notifyServer("access_approved", mapOf("caregiverUid" to caregiverUid))
        }
        Unit
    }

    suspend fun setPermissions(caregiverUid: String, perms: Set<String>): Result<Unit> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        val linkRef = db.document("patients/$pid/links/$caregiverUid")
        val cur = net { linkRef.get().await() }
        if (!cur.exists() || cur.getString("status") != "active") error("Vínculo inativo.")
        val name = patientName(pid)
        val permMap = cleanPerms(perms)
        net {
            val b = db.batch()
            b.update(linkRef, mapOf("permissions" to permMap, "updatedAt" to FieldValue.serverTimestamp()))
            b.set(db.document("users/$caregiverUid/patients/$pid"), mirrorMap(pid, name, "active", permMap))
            b.commit().await()
        }
        audit(pid, "permissions_changed", caregiverUid, mapOf("before" to parsePerms(cur.get("permissions")), "after" to permMap))
        Unit
    }

    /** Retira o acesso: o documento do vínculo fica (auditoria) com status "revoked" e todas as permissões desligadas. */
    suspend fun revoke(caregiverUid: String): Result<Unit> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        val linkRef = db.document("patients/$pid/links/$caregiverUid")
        val cur = net { linkRef.get().await() }
        if (!cur.exists()) error("Vínculo inexistente.")
        val name = patientName(pid)
        net {
            val b = db.batch()
            b.update(linkRef, mapOf("status" to "revoked", "permissions" to cleanPerms(emptySet()), "revokedAt" to FieldValue.serverTimestamp()))
            b.set(db.document("users/$caregiverUid/patients/$pid"), mirrorMap(pid, name, "revoked", emptyMap()))
            b.commit().await()
        }
        audit(pid, "access_revoked", caregiverUid)
        Unit
    }

    /** Revoga todos os códigos de pareamento ainda ativos deste paciente. */
    suspend fun revokePairingCodes(): Result<Int> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        val mine = net { db.collection("pairingCodes").whereEqualTo("pid", pid).get().await() }
        mine.documents.forEach { d -> net { d.reference.delete().await() } }
        mine.size()
    }

    private suspend fun deleteCollection(path: String) {
        while (true) {
            val snap = withTimeout(60_000L) { db.collection(path).limit(400).get().await() }
            if (snap.isEmpty) return
            withTimeout(60_000L) {
                val b = db.batch()
                snap.documents.forEach { b.delete(it.reference) }
                b.commit().await()
            }
            if (snap.size() < 400) return
        }
    }

    /** LGPD: apaga do servidor tudo o que foi compartilhado e desfaz os vínculos. Não toca no backup pessoal. */
    suspend fun deleteSharedData(ctx: Context): Result<Unit> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        val links = withTimeout(60_000L) { db.collection("patients/$pid/links").get().await() }
        for (l in links.documents) runCatching { net { db.document("users/${l.id}/patients/$pid").delete().await() } }
        val alerts = withTimeout(60_000L) { db.collection("patients/$pid/alerts").get().await() }
        for (a in alerts.documents) deleteCollection("patients/$pid/alerts/${a.id}/acks")
        for (c in listOf(
            "readings", "alerts", "dailySummary", "chartData", "okConfirmations", "hba1c", "emergencyContacts",
            "contactRequests", "diary", "requests", "links", "audit",
            "insulin", "meals", "symptoms", "medications", "reminders", "water",
        )) deleteCollection("patients/$pid/$c")
        // Documentos únicos (as regras não permitem listar estas coleções; apaga pelo caminho).
        for (path in listOf(
            "current/latest", "current/trend", "stats/gmi", "stats/coverage", "stats/tir", "syncStatus/status",
            "hba1cLatest/main", "carePlan/main", "contact/main", "extraInfo/main",
        )) net { db.document("patients/$pid/$path").delete().await() }
        val codes = withTimeout(60_000L) { db.collection("pairingCodes").whereEqualTo("pid", pid).get().await() }
        for (d in codes.documents) runCatching { net { d.reference.delete().await() } }
        net { db.document("patients/$pid").delete().await() }
        CuidadorPrefs.resetSyncState(ctx.applicationContext)
        Unit
    }

    suspend fun loadCarePlan(): CuidadorCarePlan = runCatching {
        val pid = uid() ?: return@runCatching CuidadorCarePlan()
        val d = net { db.document("patients/$pid/carePlan/main").get().await() }
        CuidadorCarePlan(
            d.getString("lowGlucose").orEmpty(), d.getString("highGlucose").orEmpty(),
            d.getString("emergencyWhen").orEmpty(), d.getString("agreed").orEmpty(),
        )
    }.getOrDefault(CuidadorCarePlan())

    suspend fun saveCarePlan(p: CuidadorCarePlan): Result<Unit> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        net {
            db.document("patients/$pid/carePlan/main").set(
                mapOf(
                    "lowGlucose" to p.lowGlucose.take(1000), "highGlucose" to p.highGlucose.take(1000),
                    "emergencyWhen" to p.emergencyWhen.take(1000), "agreed" to p.agreed.take(1000),
                    "updatedAt" to FieldValue.serverTimestamp(),
                ),
            ).await()
        }
        Unit
    }

    /** Publica (ou remove) o contato de confiança do modo cuidador como contato de emergência visível ao cuidador. */
    suspend fun setEmergencyContact(name: String, phoneDigits: String, share: Boolean): Result<Unit> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        val ref = db.document("patients/$pid/emergencyContacts/confianca")
        net {
            if (share && name.isNotBlank() && phoneDigits.isNotBlank()) {
                ref.set(mapOf("name" to name.take(80), "phone" to "+$phoneDigits".replace("++", "+"), "relation" to "Contato de confiança")).await()
            } else ref.delete().await()
        }
        Unit
    }

    // ------------------------------------------------------------------ push (pedido de acesso / de contato)

    /** Registra o token do FCM em users/{uid}/devices/{token} (o servidor envia o push para esses tokens). */
    suspend fun registerPushToken(app: Context, token: String) {
        if (!CuidadorPrefs.enabled(app)) return
        val me = uid() ?: return
        net { db.document("users/$me/devices/$token").set(mapOf("createdAt" to FieldValue.serverTimestamp(), "platform" to "android")).await() }
        CuidadorPrefs.setPushRegistered(app, "$me|$token")
    }

    private suspend fun ensurePushToken(app: Context, me: String) {
        val token = net { com.google.firebase.messaging.FirebaseMessaging.getInstance().token.await() }
        if (CuidadorPrefs.pushRegistered(app) == "$me|$token") return
        registerPushToken(app, token)
    }

    /** Ao desligar o compartilhamento: o aparelho deixa de receber push do Cuidador. */
    suspend fun unregisterPushToken(app: Context): Result<Unit> = runCatching {
        val me = uid() ?: return@runCatching
        val token = net { com.google.firebase.messaging.FirebaseMessaging.getInstance().token.await() }
        net { db.document("users/$me/devices/$token").delete().await() }
        CuidadorPrefs.setPushRegistered(app, "")
    }

    // ------------------------------------------------------------------ telefone do paciente (contact/main)

    /** Publica (ou remove) o telefone do próprio paciente para o cuidador com permissão de contatos de emergência. */
    suspend fun setPatientPhone(phoneE164: String?, share: Boolean): Result<Unit> = runCatching {
        val pid = uid() ?: error("Entre na sua conta.")
        val ref = db.document("patients/$pid/contact/main")
        net {
            if (share && !phoneE164.isNullOrBlank()) ref.set(mapOf("phone" to phoneE164)).await()
            else ref.delete().await()
        }
        Unit
    }

    // ------------------------------------------------------------------ observação (tela)

    private fun parsePerms(raw: Any?): Map<String, Boolean> =
        (raw as? Map<*, *>)?.entries?.mapNotNull { (k, v) -> (k as? String)?.let { it to (v == true) } }?.toMap() ?: emptyMap()

    fun observeRequests(): Flow<List<CuidadorRequest>> = callbackFlow {
        val pid = uid()
        if (pid == null) { trySend(emptyList()); awaitClose { }; return@callbackFlow }
        val reg = db.collection("patients/$pid/requests").whereEqualTo("status", "pending")
            .addSnapshotListener { s, e ->
                if (e != null) { trySend(emptyList()); return@addSnapshotListener }
                trySend(s?.documents?.map {
                    CuidadorRequest(it.id, it.getString("name").orEmpty(), it.getString("email").orEmpty(), it.getString("relation").orEmpty())
                } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }

    fun observeLinks(): Flow<List<CuidadorLink>> = callbackFlow {
        val pid = uid()
        if (pid == null) { trySend(emptyList()); awaitClose { }; return@callbackFlow }
        val reg = db.collection("patients/$pid/links").addSnapshotListener { s, e ->
            if (e != null) { trySend(emptyList()); return@addSnapshotListener }
            trySend(s?.documents?.map {
                CuidadorLink(it.id, it.getString("name").orEmpty(), it.getString("email").orEmpty(), it.getString("relation").orEmpty(),
                    it.getString("status").orEmpty(), parsePerms(it.get("permissions")))
            }?.filter { it.status == "active" } ?: emptyList())
        }
        awaitClose { reg.remove() }
    }

    /** Últimos pedidos de contato feitos por cuidadores ("Solicitar que o paciente entre em contato"). */
    fun observeContactRequests(): Flow<List<CuidadorContactRequest>> = callbackFlow {
        val pid = uid()
        if (pid == null) { trySend(emptyList()); awaitClose { }; return@callbackFlow }
        val reg = db.collection("patients/$pid/contactRequests")
            .orderBy("ts", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(5)
            .addSnapshotListener { s, e ->
                if (e != null) { trySend(emptyList()); return@addSnapshotListener }
                trySend(s?.documents?.map {
                    CuidadorContactRequest(
                        it.id, it.getString("fromName").orEmpty().ifBlank { "Seu cuidador" },
                        it.getString("message").orEmpty(), it.getTimestamp("ts")?.toDate()?.time ?: System.currentTimeMillis(),
                    )
                } ?: emptyList())
            }
        awaitClose { reg.remove() }
    }
}
