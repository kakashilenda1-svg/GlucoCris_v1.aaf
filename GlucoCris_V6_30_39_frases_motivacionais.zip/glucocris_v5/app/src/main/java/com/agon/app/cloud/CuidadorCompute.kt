package com.agon.app.cloud

import kotlin.math.roundToInt

/**
 * Cálculos que antes eram feitos pelas Cloud Functions do Cuidador (plano pago) e agora são feitos AQUI, no Gluco Cris,
 * que já tem todo o histórico. Lógica PURA (sem Firebase) para testar na JVM (ver CuidadorComputeTest).
 * As fórmulas são as mesmas do antigo functions/index.js (removido): classificação, estado, tendência e GMI = 3,31 + 0,02392 × média.
 */
object CuidadorCompute {
    /** Leitura já validada (20..600 mg/dL) com a origem ("cgm" | "manual"). */
    data class Pt(val id: String, val ms: Long, val mg: Int, val source: String)

    data class Th(val urgentLow: Int, val low: Int, val targetLow: Int, val targetHigh: Int, val high: Int, val urgentHigh: Int) {
        companion object {
            fun from(m: Map<String, Int>) = Th(
                m.getValue("urgentLow"), m.getValue("low"), m.getValue("targetLow"),
                m.getValue("targetHigh"), m.getValue("high"), m.getValue("urgentHigh"),
            )
        }
    }

    data class AlertSpec(val type: String, val severity: String, val severityLabel: String, val label: String)

    private val SEV = mapOf("critical" to "Crítico", "high" to "Alto", "attention" to "Atenção", "info" to "Informativo")

    /** Alerta criado só para leitura recente: valor de horas atrás não deve virar push. */
    const val ALERT_MAX_AGE_MS = 2 * 3_600_000L

    /** Estatísticas (14 dias) só são regravadas a cada ~1 h: mudam devagar e isso poupa a cota gratuita de escritas do Firestore. */
    const val STATS_EVERY_MS = 55 * 60_000L

    const val STATS_DAYS = 14

    fun stateOf(v: Int, th: Th): String = when {
        v < th.low -> "low"
        v > th.high -> "high"
        else -> "range"
    }

    fun classify(v: Int, th: Th): AlertSpec? = when {
        v <= th.urgentLow -> AlertSpec("hypo_severe", "critical", SEV.getValue("critical"), "Hipoglicemia grave")
        v < th.low -> AlertSpec("hypo", "high", SEV.getValue("high"), "Hipoglicemia")
        v >= th.urgentHigh -> AlertSpec("hyper_severe", "high", SEV.getValue("high"), "Hiperglicemia importante")
        v > th.high -> AlertSpec("hyper", "attention", SEV.getValue("attention"), "Glicemia acima da faixa")
        else -> null
    }

    /** Id determinístico (tipo + janela de 30 min): o mesmo episódio nunca gera dois alertas. */
    fun alertId(type: String, originMs: Long): String = "${type}_${originMs / 1_800_000L}"

    data class Trend(val arrow: String?, val ratePerMin: Double?)

    /**
     * Tendência a partir das últimas 4 leituras (em ordem crescente de hora); só conta as de sensor.
     * Precisa de 3 ou mais pontos num intervalo de até 30 min (mesma regra do servidor).
     */
    fun trend(last4: List<Pt>): Trend {
        val pts = last4.filter { it.source == "cgm" }
        if (pts.size < 3) return Trend(null, null)
        val dt = (pts.last().ms - pts.first().ms) / 60_000.0
        if (dt <= 0 || dt > 30) return Trend(null, null)
        val rate = (pts.last().mg - pts.first().mg) / dt
        val arrow = when {
            rate >= 2 -> "↑↑"
            rate >= 1 -> "↑"
            rate <= -2 -> "↓↓"
            rate <= -1 -> "↓"
            else -> "→"
        }
        return Trend(arrow, rate)
    }

    data class Stats(
        val n: Int, val meanGlucose: Int?, val gmi: Double?, val reliable: Boolean, val reason: String?,
        val coveragePct: Double, val daysWithData: Int,
        val timeInRangePct: Double?, val timeBelowPct: Double?, val timeAbovePct: Double?,
        val lowEpisodes: Int, val highEpisodes: Int,
        val hourly: List<Pair<Int, Int>>, // hora -> média
    )

    private fun dayKey(ms: Long, tzMin: Int): Long = Math.floorDiv(ms + tzMin * 60_000L, 86_400_000L)
    private fun hourOf(ms: Long, tzMin: Int): Int = (Math.floorMod(ms + tzMin * 60_000L, 86_400_000L) / 3_600_000L).toInt()
    private fun round1(x: Double) = (x * 10).roundToInt() / 10.0

    /** Últimos [STATS_DAYS] dias (dia local do paciente, incluindo hoje); só leituras de sensor entram na média/GMI/tempo no alvo. */
    fun stats(all: List<Pt>, th: Th, intervalMin: Int, nowMs: Long, tzMin: Int): Stats {
        val today = dayKey(nowMs, tzMin)
        val inWindow = all.filter { dayKey(it.ms, tzMin) in (today - STATS_DAYS + 1)..today }.sortedBy { it.ms }
        val cgm = inWindow.filter { it.source == "cgm" }
        val nCgm = cgm.size
        val expected = STATS_DAYS * (1440.0 / intervalMin.coerceAtLeast(1))
        val coverage = minOf(100.0, nCgm / expected * 100.0)
        val daysWithData = cgm.map { dayKey(it.ms, tzMin) }.toSet().size
        val reliable = coverage >= 70.0 && daysWithData >= 10
        val mean = if (nCgm > 0) cgm.sumOf { it.mg }.toDouble() / nCgm else null
        val below = cgm.count { it.mg < th.targetLow }
        val above = cgm.count { it.mg > th.targetHigh }
        val inRange = nCgm - below - above
        fun pct(x: Int): Double? = if (nCgm > 0) (x.toDouble() / nCgm * 1000).roundToInt() / 10.0 else null
        // episódios: mudança de estado entre leituras consecutivas (qualquer origem, em ordem de hora)
        var lowEp = 0
        var highEp = 0
        var prev: String? = null
        for (p in inWindow) {
            val st = stateOf(p.mg, th)
            if (prev != null && prev != st) { if (st == "low") lowEp++; if (st == "high") highEp++ }
            prev = st
        }
        val hourly = cgm.groupBy { hourOf(it.ms, tzMin) }
            .map { (h, v) -> h to (v.sumOf { it.mg }.toDouble() / v.size).roundToInt() }
            .sortedBy { it.first }
        return Stats(
            n = nCgm, meanGlucose = mean?.roundToInt(),
            gmi = if (reliable && mean != null) round1(3.31 + 0.02392 * mean) else null,
            reliable = reliable, reason = if (reliable) null else "dados_insuficientes",
            coveragePct = round1(coverage), daysWithData = daysWithData,
            timeInRangePct = pct(inRange), timeBelowPct = pct(below), timeAbovePct = pct(above),
            lowEpisodes = lowEp, highEpisodes = highEp, hourly = hourly,
        )
    }
}
