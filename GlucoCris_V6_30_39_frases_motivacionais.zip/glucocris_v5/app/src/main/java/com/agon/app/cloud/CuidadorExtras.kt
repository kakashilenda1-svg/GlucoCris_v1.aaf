package com.agon.app.cloud

import com.agon.app.data.InsulinEntry
import com.agon.app.data.Meal
import com.agon.app.data.Medication
import com.agon.app.data.Reminder
import com.agon.app.data.Symptom

/**
 * Dados extras que o paciente pode liberar ao cuidador, UM POR PERMISSÃO (a chave da permissão = nome da coleção):
 *  insulin · meals · symptoms · medications · reminders · water  →  patients/{pid}/{chave}/{id}
 *
 * Privacidade: só é enviado o que ao menos um cuidador ativo tem permissão de ver. Se a permissão sai de todos,
 * o que já tinha sido enviado dessa categoria é apagado do servidor. Lógica PURA (sem Firebase), testada na JVM.
 */
object CuidadorExtras {
    val CATEGORIES = listOf("insulin", "meals", "symptoms", "medications", "reminders", "water")

    /** Eventos antigos não interessam ao acompanhamento e custam cota: só os últimos 14 dias. */
    const val WINDOW_MS = 14L * 86_400_000L

    /** [atMs] vira o campo "at" (Timestamp) na camada de nuvem; null = documento sem horário (remédio, lembrete, água). */
    data class Item(val id: String, val sig: String, val data: Map<String, Any?>, val atMs: Long? = null)

    /** Id de documento seguro (sem "/" e com tamanho limitado). */
    fun docId(raw: String): String = raw.replace('/', '_').trim().take(100).ifBlank { "x" }

    private fun inWindow(at: Long, now: Long) = at <= now + 3_600_000L && now - at <= WINDOW_MS
    private fun isDemo(id: String) = id.startsWith("demo-")
    private fun sig(vararg parts: Any?): String = parts.toList().hashCode().toString()

    fun insulin(list: List<InsulinEntry>, now: Long): List<Item> = list
        .filter { !isDemo(it.id) && inWindow(it.at, now) }
        .map { e ->
            Item(
                docId(e.id), sig(e.updatedAt, e.at, e.dose, e.name, e.kind, e.unit, e.notes),
                mapOf("kind" to e.kind.take(30), "name" to e.name.take(60), "dose" to e.dose, "unit" to e.unit.take(10), "notes" to e.notes.take(300)),
                e.at,
            )
        }

    fun meals(list: List<Meal>, now: Long): List<Item> = list
        .filter { !isDemo(it.id) && inWindow(it.at, now) }
        .map { m ->
            Item(
                docId(m.id), sig(m.updatedAt, m.at, m.type, m.description, m.carbs, m.notes),
                mapOf("type" to m.type.take(30), "description" to m.description.take(200), "carbs" to m.carbs, "notes" to m.notes.take(300)),
                m.at,
            )
        }

    fun symptoms(list: List<Symptom>, now: Long): List<Item> = list
        .filter { !isDemo(it.id) && inWindow(it.at, now) }
        .map { s ->
            Item(
                docId(s.id), sig(s.updatedAt, s.at, s.name, s.intensity, s.notes),
                mapOf("name" to s.name.take(80), "intensity" to s.intensity.take(30), "notes" to s.notes.take(300)),
                s.at,
            )
        }

    fun medications(list: List<Medication>): List<Item> = list
        .filter { !isDemo(it.id) }
        .map { m ->
            Item(
                docId(m.id), sig(m.updatedAt, m.name, m.dose, m.schedule, m.notes, m.active),
                mapOf("name" to m.name.take(80), "dose" to m.dose.take(60), "schedule" to m.schedule.take(120), "notes" to m.notes.take(300), "active" to m.active),
            )
        }

    fun reminders(list: List<Reminder>): List<Item> = list
        .filter { !isDemo(it.id) }
        .map { r ->
            Item(
                docId(r.id), sig(r.updatedAt, r.kind, r.title, r.hour, r.minute, r.days, r.enabled),
                mapOf(
                    "kind" to r.kind.take(30), "title" to r.title.take(80), "hour" to r.hour, "minute" to r.minute,
                    "days" to r.days, "enabled" to r.enabled,
                ),
            )
        }

    /** Resumo do dia da água (um documento por dia: id = AAAA-MM-DD do paciente). Sem registro nenhum, não envia. */
    fun water(dayKey: String, dayStartMs: Long, totalMl: Int, goalMl: Int, lastAtMs: Long, cups: Int): List<Item> {
        if (cups <= 0 && totalMl <= 0) return emptyList()
        return listOf(
            Item(
                docId(dayKey), sig(totalMl, goalMl, lastAtMs, cups),
                mapOf("date" to dayKey, "dayStartMs" to dayStartMs, "ml" to totalMl, "goal" to goalMl, "cups" to cups, "lastAtMs" to lastAtMs),
            ),
        )
    }

    /** Categorias que ao menos um cuidador ativo pode ver. */
    fun wanted(activePermissions: List<Map<String, Boolean>>): Set<String> =
        CATEGORIES.filter { c -> activePermissions.any { it[c] == true } }.toSet()

    data class Plan(val write: List<Item>, val delete: List<String>)

    /** Compara o que já foi enviado (id → assinatura) com o que deve existir agora. */
    fun plan(sent: Map<String, String>, now: List<Item>): Plan {
        val ids = now.map { it.id }.toSet()
        return Plan(
            write = now.filter { sent[it.id] != it.sig },
            delete = sent.keys.filter { it !in ids },
        )
    }

    fun encode(m: Map<String, String>): String = m.entries.joinToString("\n") { "${it.key}\t${it.value}" }
    fun decode(raw: String): Map<String, String> =
        raw.lineSequence().mapNotNull { l -> l.split('\t').takeIf { it.size == 2 && it[0].isNotBlank() }?.let { it[0] to it[1] } }.toMap()
}
