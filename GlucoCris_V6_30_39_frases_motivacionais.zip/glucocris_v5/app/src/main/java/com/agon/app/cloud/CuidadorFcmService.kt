package com.agon.app.cloud

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.agon.app.MainActivity
import com.agon.app.R
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Recebe os avisos do servidor do Cuidador destinados AO PACIENTE:
 *  - kind=access_request: um cuidador digitou seu código e espera aprovação;
 *  - kind=contact_request: um cuidador pediu que você entre em contato.
 * Qualquer outro tipo (alertas de glicemia etc.) é só do app Cuidador e é ignorado aqui.
 * Só mostra algo se o "Cuidador online" estiver ligado neste aparelho.
 */
class CuidadorFcmService : FirebaseMessagingService() {

    override fun onNewToken(token: String) {
        CoroutineScope(Dispatchers.IO).launch { runCatching { CuidadorCloud.registerPushToken(applicationContext, token) } }
    }

    override fun onMessageReceived(message: RemoteMessage) {
        val kind = message.data["kind"] ?: return
        if (!CuidadorPush.isPatientKind(kind)) return
        if (!CuidadorPrefs.enabled(applicationContext)) return
        CuidadorPush.show(applicationContext, kind, message.data["title"], message.data["body"])
    }
}

object CuidadorPush {
    const val CHANNEL = "gluco_cuidador_online_v1"

    fun isPatientKind(kind: String) = kind == "access_request" || kind == "contact_request"

    fun show(ctx: Context, kind: String, title: String?, body: String?) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) return
        try {
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                val ch = NotificationChannel(CHANNEL, "Cuidador online", NotificationManager.IMPORTANCE_HIGH)
                ch.description = "Pedidos de acesso e de contato feitos pelo seu cuidador."
                nm.createNotificationChannel(ch)
            }
            val t = title?.takeIf { it.isNotBlank() } ?: if (kind == "access_request") "Nova solicitação de acesso" else "Seu cuidador pediu contato"
            val b = body?.takeIf { it.isNotBlank() } ?: "Toque para abrir o Gluco Cris."
            val open = Intent(ctx, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP }
            val id = if (kind == "access_request") 7101 else 7102
            val n = NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_drop)
                .setContentTitle(t)
                .setContentText(b)
                .setStyle(NotificationCompat.BigTextStyle().bigText(b))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setColor(0xFF6D28D9.toInt())
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(ctx, id, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                .build()
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }
}
