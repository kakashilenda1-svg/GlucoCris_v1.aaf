package com.agon.app.cloud

import android.content.Context
import com.agon.app.data.AppData
import com.agon.app.data.GlucoseEntry
import com.agon.app.data.toMgDl
import com.agon.app.reminders.Caregiver
import com.agon.app.sensors.SensorConfig
import kotlin.math.roundToInt

/**
 * Lógica PURA (sem Firebase) da ponte Paciente -> app "Gluco Cris Cuidador".
 * Mantida separada para ser testada na JVM (ver CuidadorOnlineTest).
 *
 * Contrato com o Firestore do Cuidador (firestore.rules; v6.30.36: sem Cloud Functions, plano gratuito Spark):
 *  - patients/{pid}/readings/{uuid}: value Int 20..600, unit "mg/dL", source "cgm"|"manual", originTs, serverTs.
 *    Só CRIAÇÃO é aceita (update/delete = false), então cada leitura vai UMA vez.
 *  - patients/{pid}: só displayName, thresholds, cgmExpected, cgmIntervalMin, tzOffsetMin, staleAfterMin.
 */
object CuidadorOnline {
    const val SOURCE_CGM = "cgm"
    const val SOURCE_MANUAL = "manual"

    const val MIN_MG = 20
    const val MAX_MG = 600

    /** Primeira ativação: só as últimas horas (cada leitura antiga dispararia alerta/push no cuidador). */
    const val FIRST_BACKFILL_MS = 3 * 3_600_000L

    /** Depois de ficar offline: reenvia no máximo as últimas horas (evita alerta de valor muito antigo). */
    const val MAX_PENDING_MS = 6 * 3_600_000L

    /**
     * Minutos sem leitura até o Cuidador marcar "Desatualizado" / o servidor alertar "Sem novas leituras".
     * O importador de sensor grava 1 leitura a cada 15 min e o Android pode atrasar o trabalho em segundo plano,
     * então 40 min (= 2 intervalos + folga, a mesma conta de [cgmState]) evita alarme falso.
     */
    const val STALE_AFTER_MIN = 40

    /** Leituras por lote de gravação (limite do Firestore é 500). */
    const val BATCH = 100

    /** Leituras de sensor (Libre/Dexcom/Nightscout) têm id "sensor-..."; glicosímetro BT ("ble-...") e digitadas são "manual". */
    fun sourceOf(id: String): String = if (id.startsWith("sensor-")) SOURCE_CGM else SOURCE_MANUAL

    /** Detalhe opcional (campo deviceId das regras): de onde veio a leitura. */
    fun deviceOf(id: String): String? = when {
        id.startsWith("sensor-dexcom") -> "dexcom"
        id.startsWith("sensor-libre") -> "libre"
        id.startsWith("sensor-nightscout") -> "nightscout"
        id.startsWith("ble-") -> "bluetooth"
        else -> null
    }

    /** Valor em mg/dL inteiro aceito pelas regras, ou null se fora de 20..600. */
    fun readingMg(e: GlucoseEntry): Int? {
        val mg = toMgDl(e.value, e.unit).roundToInt()
        return if (mg in MIN_MG..MAX_MG) mg else null
    }

    fun isDemo(e: GlucoseEntry) = e.id.startsWith("demo-")

    /**
     * Leituras a enviar: não-demo, valor válido, dentro da janela, ainda não enviadas, da mais antiga para a mais nova
     * (o backend só atualiza "glicemia atual" quando a leitura é a mais recente).
     */
    fun pending(entries: List<GlucoseEntry>, sent: Set<String>, now: Long, windowMs: Long): List<GlucoseEntry> =
        entries.asSequence()
            .filter { !isDemo(it) && it.id !in sent && readingMg(it) != null }
            .filter { it.at <= now + 5 * 60_000L && now - it.at <= windowMs }
            .sortedBy { it.at }
            .toList()

    /** Limites do app Cuidador a partir dos ajustes do paciente (garante urgentLow < low e urgentHigh > high). */
    fun thresholds(targetLow: Int, targetHigh: Int, severeLow: Int, severeHigh: Int): Map<String, Int> {
        val low = targetLow.coerceIn(40, 130)
        val high = targetHigh.coerceIn(low + 10, 400)
        val urgentLow = minOf(severeLow, low - 1).coerceAtLeast(30)
        val urgentHigh = maxOf(severeHigh, high + 1).coerceAtMost(600)
        return mapOf(
            "urgentLow" to urgentLow, "low" to low, "targetLow" to low,
            "targetHigh" to high, "high" to high, "urgentHigh" to urgentHigh,
        )
    }

    /**
     * Telefone do paciente no formato internacional (+5511999998888) para o cuidador ligar, ou null se incompleto.
     * Exige DDD de 2 dígitos e número de 8 ou 9 dígitos (celular com 9 inicial).
     */
    fun patientPhone(country: String, ddd: String, number: String): String? {
        val c = country.filter { it.isDigit() }.ifBlank { "55" }
        val d = ddd.filter { it.isDigit() }
        val n = number.filter { it.isDigit() }
        if (c.isEmpty() || c.length > 3 || d.length != 2 || n.length !in 8..9) return null
        return "+$c$d$n"
    }

    /** Deslocamento do fuso em minutos (o backend usa para fechar o "dia" do resumo). Ex.: Brasília = -180. */
    fun tzOffsetMin(now: Long = System.currentTimeMillis()): Int =
        java.util.TimeZone.getDefault().getOffset(now) / 60_000

    /** Estado do CGM para o painel "Sincronização" do cuidador: ok | no_readings | disconnected. */
    fun cgmState(configured: Boolean, lastCgmMs: Long, now: Long, intervalMin: Int): String = when {
        !configured -> "disconnected"
        lastCgmMs <= 0L -> "no_readings"
        now - lastCgmMs > (intervalMin * 2 + 10) * 60_000L -> "no_readings"
        else -> "ok"
    }

    /** Permissões conhecidas pelas regras (validPerms em firestore.rules) com rótulo em português. */
    val PERMISSIONS: List<Pair<String, String>> = listOf(
        "currentGlucose" to "Glicemia atual",
        "history" to "Histórico de glicemia",
        "charts" to "Gráficos",
        "cgm" to "Dados do sensor (CGM)",
        "trends" to "Tendência (setas)",
        "gmi" to "GMI (estimativa de HbA1c)",
        "cgmCoverage" to "Cobertura do sensor",
        "hba1cCurrent" to "HbA1c de exame (último)",
        "hba1cHistory" to "Histórico de HbA1c",
        "reports" to "Relatórios",
        "alerts" to "Alertas de glicemia",
        "diary" to "Diário de ocorrências",
        "carePlan" to "Plano de ação",
        "emergencyContacts" to "Contatos de emergência",
        "extraInfo" to "Informações adicionais",
        "insulin" to "Insulina aplicada (doses e horários)",
        "meals" to "Refeições e carboidratos",
        "symptoms" to "Sintomas",
        "medications" to "Medicamentos em uso",
        "water" to "Água (Cris Hidrata)",
        "reminders" to "Lembretes programados",
    )


    // ------------------------------------------------------------------ código de pareamento (sem servidor)

    /** Validade do código. As regras aceitam até 20 min; o cuidador confere a hora também. */
    const val CODE_TTL_MIN = 10

    /** Máximo de códigos ativos ao mesmo tempo (o app confere; não há servidor para impor). */
    const val MAX_ACTIVE_CODES = 5

    private const val CODE_ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789" // sem 0/O/1/I

    /** 8 caracteres sorteados com SecureRandom (≈ 40 bits). */
    fun newCode(rnd: java.util.Random = java.security.SecureRandom()): String =
        buildString { repeat(8) { append(CODE_ALPHABET[rnd.nextInt(CODE_ALPHABET.length)]) } }

    fun normalizeCode(raw: String): String = raw.uppercase().filter { it in 'A'..'Z' || it in '0'..'9' }

    /** Id do documento pairingCodes/{hash}: SHA-256 (hex minúsculo) do código normalizado. Só o hash fica no servidor. */
    fun codeHash(code: String): String =
        java.security.MessageDigest.getInstance("SHA-256").digest(normalizeCode(code).toByteArray(Charsets.UTF_8))
            .joinToString("") { "%02x".format(it) }

    val PRESET_BASIC = setOf("currentGlucose", "trends", "alerts")
    val PRESET_FULL = PERMISSIONS.map { it.first }.toSet()
}

/** Preferências locais da ponte (não vão para backup: dizem respeito a este aparelho/conta). */
object CuidadorPrefs {
    private const val PREFS = "gluco_cuidador_online_v1"
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun enabled(ctx: Context) = sp(ctx).getBoolean("enabled", false)
    fun setEnabled(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("enabled", v).apply()

    fun ownerUid(ctx: Context): String = sp(ctx).getString("owner_uid", "") ?: ""
    fun setOwnerUid(ctx: Context, v: String) = sp(ctx).edit().putString("owner_uid", v).apply()

    /** ids já gravados no Firestore, com o instante da leitura ("id|at"), para não reenviar. */
    fun sent(ctx: Context): Map<String, Long> =
        (sp(ctx).getString("sent", "") ?: "").lineSequence().mapNotNull {
            val p = it.split('|'); if (p.size == 2) p[1].toLongOrNull()?.let { at -> p[0] to at } else null
        }.toMap()

    fun saveSent(ctx: Context, m: Map<String, Long>, now: Long) {
        val keep = m.filter { now - it.value <= CuidadorOnline.MAX_PENDING_MS * 4 }.entries.sortedByDescending { it.value }.take(3000)
        sp(ctx).edit().putString("sent", keep.joinToString("\n") { "${it.key}|${it.value}" }).apply()
    }

    fun hba1cSent(ctx: Context): Set<String> = sp(ctx).getStringSet("hba1c_sent", emptySet()) ?: emptySet()
    fun setHba1cSent(ctx: Context, s: Set<String>) = sp(ctx).edit().putStringSet("hba1c_sent", s).apply()

    fun lastProfileHash(ctx: Context) = sp(ctx).getInt("profile_hash", 0)
    fun setLastProfileHash(ctx: Context, h: Int) = sp(ctx).edit().putInt("profile_hash", h).apply()

    fun sharePhone(ctx: Context) = sp(ctx).getBoolean("share_phone", false)
    fun setSharePhone(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("share_phone", v).apply()

    /** Token do FCM já registrado para esta conta ("uid|token"): evita regravar a cada sincronização. */
    fun pushRegistered(ctx: Context) = sp(ctx).getString("push_registered", "") ?: ""
    fun setPushRegistered(ctx: Context, v: String) = sp(ctx).edit().putString("push_registered", v).apply()

    /** Id da última leitura publicada em current/latest (só publica quando aparece uma mais nova). */
    fun lastLatestId(ctx: Context) = sp(ctx).getString("latest_id", "") ?: ""
    fun setLastLatestId(ctx: Context, v: String) = sp(ctx).edit().putString("latest_id", v).apply()

    /** Quando as estatísticas (GMI, cobertura, tempo no alvo) foram gravadas pela última vez. */
    fun lastStatsAt(ctx: Context) = sp(ctx).getLong("stats_at", 0L)
    fun setLastStatsAt(ctx: Context, v: Long) = sp(ctx).edit().putLong("stats_at", v).apply()

    /** Extras já enviados por categoria (id → assinatura), para só regravar o que mudou e apagar o que saiu. */
    fun extraSent(ctx: Context, cat: String): Map<String, String> =
        CuidadorExtras.decode(sp(ctx).getString("extra_$cat", "") ?: "")
    fun setExtraSent(ctx: Context, cat: String, m: Map<String, String>) =
        sp(ctx).edit().putString("extra_$cat", CuidadorExtras.encode(m)).apply()

    fun shareContact(ctx: Context) = sp(ctx).getBoolean("share_contact", false)
    fun setShareContact(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("share_contact", v).apply()

    /** Apaga o controle de envio (troca de conta ou desligar): na próxima ativação recomeça do zero. */
    fun resetSyncState(ctx: Context) = sp(ctx).edit().remove("sent").remove("hba1c_sent").remove("profile_hash").remove("push_registered").remove("latest_id").remove("stats_at").also { e -> CuidadorExtras.CATEGORIES.forEach { e.remove("extra_$it") } }.apply()

    fun lastOk(ctx: Context) = sp(ctx).getLong("last_ok", 0L)
    fun setLastOk(ctx: Context, v: Long) = sp(ctx).edit().putLong("last_ok", v).apply()
    fun lastMsg(ctx: Context) = sp(ctx).getString("last_msg", "") ?: ""
    fun setLastMsg(ctx: Context, v: String) = sp(ctx).edit().putString("last_msg", v).apply()
}

/** Entrada de dados do paciente usada pelo envio (isola AppData/SensorConfig/Caregiver do código de rede). */
data class CuidadorSnapshot(
    val readings: List<GlucoseEntry>,
    val displayName: String,
    val targetLow: Int,
    val targetHigh: Int,
    val severeLow: Int,
    val severeHigh: Int,
    val cgmConfigured: Boolean,
    val lastCgmMs: Long,
    val hba1c: List<Triple<String, Double, Long>>, // id, %, data da coleta
    val hba1cLab: Map<String, String>,
    // Extras (cada um só é enviado se algum cuidador tiver a permissão correspondente). Padrões vazios: nada quebra.
    val insulin: List<com.agon.app.data.InsulinEntry> = emptyList(),
    val meals: List<com.agon.app.data.Meal> = emptyList(),
    val symptoms: List<com.agon.app.data.Symptom> = emptyList(),
    val medications: List<com.agon.app.data.Medication> = emptyList(),
    val reminders: List<com.agon.app.data.Reminder> = emptyList(),
    val waterDayKey: String = "",
    val waterDayStartMs: Long = 0L,
    val waterTotalMl: Int = 0,
    val waterGoalMl: Int = 0,
    val waterLastAtMs: Long = 0L,
    val waterCups: Int = 0,
) {
    companion object {
        fun of(ctx: Context, d: AppData): CuidadorSnapshot = CuidadorSnapshot(
            readings = d.glucose,
            displayName = d.settings.displayName.ifBlank { "Paciente" }.take(80),
            targetLow = d.settings.targetLow,
            targetHigh = d.settings.targetHigh,
            severeLow = Caregiver.severeLow(ctx),
            severeHigh = Caregiver.severeHigh(ctx),
            cgmConfigured = SensorConfig.isConfigured(ctx) && SensorConfig.provider(ctx) != SensorConfig.NONE,
            lastCgmMs = d.glucose.filter { it.id.startsWith("sensor-") }.maxOfOrNull { it.at } ?: 0L,
            hba1c = d.hba1c.map { Triple(it.id, it.percent, it.at) },
            hba1cLab = d.hba1c.associate { it.id to it.lab },
            insulin = d.insulin,
            meals = d.meals,
            symptoms = d.symptoms,
            medications = d.medications,
            reminders = d.reminders,
        ).withWater(ctx)

        /** Resumo da água de hoje (Cris Hidrata). Qualquer falha ao ler vira "sem registro". */
        private fun CuidadorSnapshot.withWater(ctx: Context): CuidadorSnapshot = runCatching {
            val entries = com.agon.app.ui.screens.loadWaterEntries(ctx)
            val cal = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
                set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
            }
            val key = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(cal.time)
            copy(
                waterDayKey = key, waterDayStartMs = cal.timeInMillis,
                waterTotalMl = entries.sumOf { it.ml }, waterGoalMl = com.agon.app.ui.screens.effectiveWaterGoal(ctx),
                waterLastAtMs = entries.maxOfOrNull { it.at } ?: 0L, waterCups = entries.size,
            )
        }.getOrDefault(this)
    }
}
