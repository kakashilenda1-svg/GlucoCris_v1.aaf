package com.agon.app.data

import java.util.TimeZone

/**
 * 50 frases motivadoras reservadas para o cartão da tela Início.
 * Uma frase por dia: a mesma o dia todo, trocando à meia-noite (horário do aparelho),
 * seguindo a ordem da lista e recomeçando depois da 50ª.
 * Cada frase tem no máximo ~85 caracteres para caber em 2 linhas no cartão.
 */
object DailyQuotes {
    val QUOTES: List<String> = listOf(
        "Cada registro é um passo a mais no cuidado com você.",
        "Pequenos hábitos de hoje constroem a saúde de amanhã.",
        "Você é mais forte do que imagina. Siga com calma e constância.",
        "Cuidar de si é um ato de amor. Parabéns por estar aqui!",
        "Um dia de cada vez, uma medição de cada vez.",
        "Seus esforços de hoje valem muito. Continue!",
        "Constância vence perfeição. Faça o seu melhor hoje.",
        "Beber água, se movimentar e registrar: pequenos gestos, grandes resultados.",
        "Você não está sozinho(a) nessa jornada. Estamos juntos!",
        "Celebre cada conquista, por menor que pareça.",
        "Hoje é um ótimo dia para cuidar de você.",
        "Disciplina é gostar de si mesmo(a) o bastante para se cuidar.",
        "Um número fora da meta é só informação, não um fracasso.",
        "Respire fundo. Você está fazendo o que pode, e isso conta.",
        "Sua saúde merece o seu carinho todos os dias.",
        "Persistir é o segredo. Você já começou, siga em frente!",
        "Cada escolha saudável é uma vitória silenciosa.",
        "Seja gentil consigo mesmo(a): o progresso não é uma linha reta.",
        "Quem se cuida hoje agradece amanhã.",
        "Foco no processo: os resultados vêm com o tempo.",
        "Você tem tudo para viver bem. Um passo de cada vez!",
        "Anotar é cuidar. Obrigado(a) por se importar com você.",
        "Hoje pode ser leve. Comece pelo próximo pequeno passo.",
        "A rotina de cuidado de hoje é o presente que você dá ao futuro.",
        "Dias difíceis passam. O seu compromisso fica.",
        "Acredite no seu processo. Você está evoluindo!",
        "Uma boa refeição, um copo d'água, um registro: você está no caminho.",
        "Você merece se sentir bem. Continue se cuidando!",
        "Coragem não é não ter dúvidas, é continuar mesmo assim.",
        "Cada dia de cuidado é um dia de vitória.",
        "Sua determinação inspira. Orgulhe-se de quem você é!",
        "Equilíbrio se constrói com paciência e carinho.",
        "Que hoje seja um dia de calma, energia e boas escolhas.",
        "Pequenas vitórias somadas viram grandes conquistas.",
        "Você cuida de muita coisa. Lembre-se de cuidar de você também.",
        "Não precisa ser perfeito(a), precisa ser constante.",
        "Cada manhã é uma nova chance de recomeçar com leveza.",
        "O cuidado que você tem hoje faz diferença na sua vida.",
        "Sorria: você está fazendo algo importante pela sua saúde.",
        "A força para seguir está em você. Confie!",
        "Mantenha o ritmo: seu futuro agradece cada atitude.",
        "Se hoje foi difícil, amanhã você tenta de novo. E está tudo bem.",
        "Você está construindo uma vida mais saudável, dia após dia.",
        "Cuidar da saúde é investir em mais momentos felizes.",
        "Sua jornada é só sua, e cada passo conta.",
        "Tenha orgulho de cada esforço, mesmo dos pequenos.",
        "Você é capaz! Siga com fé, foco e carinho por si.",
        "Hoje, escolha o que faz bem ao seu corpo e à sua mente.",
        "Quem persiste com carinho chega mais longe.",
        "Continue! Você está cuidando do que mais importa: a sua vida.",
    )

    private const val DAY_MS = 86_400_000L

    /** Índice (0–49) da frase de um dia, contando o dia no fuso do aparelho. */
    fun indexForDay(nowMs: Long = System.currentTimeMillis(), tz: TimeZone = TimeZone.getDefault()): Int {
        val localDay = Math.floorDiv(nowMs + tz.getOffset(nowMs), DAY_MS)
        return Math.floorMod(localDay, QUOTES.size.toLong()).toInt()
    }

    fun today(nowMs: Long = System.currentTimeMillis(), tz: TimeZone = TimeZone.getDefault()): String =
        QUOTES[indexForDay(nowMs, tz)]
}
