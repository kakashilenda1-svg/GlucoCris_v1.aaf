package com.agon.app.data

import com.agon.app.data.insulin.City
import com.agon.app.data.insulin.CityIndex
import com.agon.app.data.insulin.InsulinCatalog
import com.agon.app.data.insulin.InsulinProduct
import java.text.Normalizer

/**
 * Interpretação do texto digitado no Localizador de Insulina.
 *
 * - Ignora acento e maiúsculas ("Glargína", "RÁPIDA", "ação" funcionam).
 * - Entende nome comercial, princípio ativo, apelido popular ("cristalina", "turva", "lenta")
 *   e as marcas do catálogo ("Insuman", "Wosulin", "Admelog"…).
 * - Entende um município no meio do texto ("lantus curitiba") e só o SUGERE.
 * - Só reconhece nomes e grupos; NUNCA afirma equivalência terapêutica entre insulinas
 *   e NUNCA troca a pesquisa do usuário sozinho: erros de digitação viram apenas SUGESTÃO.
 */
object LocatorSearch {
    private val MARKS = Regex("\\p{Mn}+")
    private val SPACES = Regex("\\s+")
    private val NON_ALNUM = Regex("[^a-z0-9]+")

    fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(MARKS, "")

    /** id -> [princípio ativo, nomes comerciais e variações] (já sem acento). O 1º item é o próprio id. */
    val INSULIN_ALIASES: Map<String, List<String>> = linkedMapOf(
        "nph" to listOf("nph", "humana nph", "humulin n", "novolin n"),
        "regular" to listOf("regular", "humana regular", "humulin r", "novolin r"),
        "glargina" to listOf("glargina", "lantus", "basaglar", "toujeo"),
        "degludeca" to listOf("degludeca", "tresiba"),
        "detemir" to listOf("detemir", "levemir"),
        "lispro" to listOf("lispro", "humalog"),
        "asparte" to listOf("asparte", "novorapid", "fiasp"),
        "glulisina" to listOf("glulisina", "apidra"),
    )

    private val RAPIDAS = listOf("lispro", "asparte", "glulisina")
    private val LENTAS = listOf("glargina", "degludeca", "detemir")

    // Termos populares / tipos. Mostram os produtos do grupo, sem dizer que são equivalentes.
    private val GROUPS: Map<String, List<String>> = mapOf(
        "rapida" to RAPIDAS, "rapidas" to RAPIDAS, "rapido" to RAPIDAS,
        "ultrarrapida" to RAPIDAS, "ultrarapida" to RAPIDAS, "bolus" to RAPIDAS,
        "lenta" to LENTAS, "lentas" to LENTAS, "longa" to LENTAS, "basal" to LENTAS, "prolongada" to LENTAS,
        "intermediaria" to listOf("nph"),
        "turva" to listOf("nph"),
        "leitosa" to listOf("nph"),
        "curta" to listOf("regular"),
        "cristalina" to listOf("regular"),
        "transparente" to listOf("regular"),
        "humana" to listOf("nph", "regular"),
        "humanas" to listOf("nph", "regular"),
        "analogo" to LENTAS + RAPIDAS,
        "analogos" to LENTAS + RAPIDAS,
    )

    private val STOP = setOf(
        "insulina", "insulinas", "de", "da", "do", "das", "dos", "em", "no", "na", "nos", "nas",
        "perto", "proximo", "proxima", "onde", "tem", "ter", "comprar", "achar", "encontrar",
        "medicamento", "medicamentos", "remedio", "remedios", "para", "a", "o", "e", "um", "uma",
        "por", "favor", "quero", "preciso", "buscar", "procurar", "com", "acao", "mim", "mais",
    )

    /** Palavras sobre o tipo de local: não restringem a insulina (o tipo de local vem dos filtros). */
    private val PLACE_WORDS = setOf(
        "farmacia", "farmacias", "drogaria", "drogarias", "posto", "postos", "ubs", "upa",
        "hospital", "hospitais", "clinica", "clinicas", "sus", "popular",
    )

    // ---------------------------------------------------------------- catálogo normalizado

    private class PNorm(val brand: String, val active: String, val words: List<String>)

    private val PNORMS: Map<String, PNorm> by lazy {
        InsulinCatalog.products.associate { p ->
            p.id to PNorm(
                brand = " " + norm(p.brandName) + " ",
                active = norm(p.activeIngredient),
                words = norm(p.searchBlob).split(NON_ALNUM).filter { it.isNotEmpty() },
            )
        }
    }

    /** id do grupo -> (categorias principais, palavra do princípio ativo). Pré-mistura entra se contiver o princípio. */
    private val ID_RULES: Map<String, Pair<Set<String>, String>> = mapOf(
        "nph" to (setOf("nph") to "nph"),
        "regular" to (setOf("regular") to "regular"),
        "glargina" to (setOf("analogo_longo") to "glargina"),
        "degludeca" to (setOf("analogo_longo") to "degludeca"),
        "detemir" to (setOf("analogo_longo") to "detemir"),
        "lispro" to (setOf("analogo_rapido") to "lispro"),
        "asparte" to (setOf("analogo_rapido") to "asparte"),
        "glulisina" to (setOf("analogo_rapido") to "glulisina"),
    )

    private fun matchesId(id: String, p: InsulinProduct): Boolean {
        val (cats, kw) = ID_RULES[id] ?: return false
        val n = PNORMS[p.id] ?: return false
        return (p.categoryId in cats || p.categoryId == "pre_mistura") && n.active.contains(kw)
    }

    private fun isBrandAlias(id: String, alias: String) = alias != id && !alias.startsWith("humana ")

    /** Vocabulário usado só para sugerir correções. */
    private val VOCAB: List<String> by lazy {
        val brandWords = PNORMS.values.flatMap { it.words.take(3) }.filter { it.length >= 4 && it.all { c -> c.isLetter() } }
        (
            INSULIN_ALIASES.values.flatten().filter { !it.contains(' ') && it.length >= 4 } +
                GROUPS.keys + PLACE_WORDS.filter { it.length >= 4 } + brandWords +
                listOf("insulina", "nutricionista", "dietista", "saude", "unidade")
            ).distinct()
    }

    // ---------------------------------------------------------------- interpretação

    data class Parsed(
        /** Princípios ativos / grupos reconhecidos ("glargina", "nph"…). */
        val insulinIds: List<String>,
        /** Nomes comerciais reconhecidos ("lantus", "humulin n"…). */
        val brands: List<String>,
        /** Palavras restantes. */
        val tokens: List<String>,
        /** Pediu "farmácia popular": só prioriza, não filtra. */
        val popular: Boolean,
    )

    /** [qNorm] = texto já passado por [norm]. */
    fun parse(qNorm: String): Parsed {
        val clean = qNorm.trim().replace(SPACES, " ")
        if (clean.isEmpty()) return Parsed(emptyList(), emptyList(), emptyList(), false)

        val ids = LinkedHashSet<String>()
        val brands = LinkedHashSet<String>()
        var rest = " $clean "
        // 1) nomes com mais de uma palavra ("humulin n", "humana nph")
        for ((id, aliases) in INSULIN_ALIASES) {
            for (a in aliases) {
                if (a.contains(' ') && rest.contains(" $a ")) {
                    if (isBrandAlias(id, a)) brands += a else ids += id
                    rest = rest.replace(" $a ", " ")
                }
            }
        }
        val words = rest.trim().split(' ').filter { it.isNotEmpty() }

        val tokens = mutableListOf<String>()
        var popular = false
        for (w in words) {
            val group = GROUPS[w]
            if (group != null) { ids += group; continue }
            val hits = matchAlias(w)
            if (hits.isNotEmpty()) {
                for ((id, alias) in hits) if (isBrandAlias(id, alias)) brands += alias else ids += id
                continue
            }
            when {
                w in STOP -> {}
                w == "popular" -> popular = true
                w in PLACE_WORDS -> {}
                else -> tokens += w
            }
        }
        return Parsed(ids.toList(), brands.toList(), tokens, popular)
    }

    private fun matchAlias(w: String): List<Pair<String, String>> {
        val out = mutableListOf<Pair<String, String>>()
        for ((id, aliases) in INSULIN_ALIASES) {
            for (a in aliases) {
                if (a.contains(' ')) continue
                // prefixo só a partir de 4 letras, para "lant" achar "lantus" sem casar qualquer coisa
                if (a == w || (w.length >= 4 && a.startsWith(w))) { out += id to a; break }
            }
        }
        return out
    }

    // ---------------------------------------------------------------- resultado final

    data class Resolved(
        /**
         * Insulinas que o texto pede. `null` = o texto não restringe a insulina (vazio ou só cidade/tipo de local).
         * Lista vazia = o texto não bate com nenhuma insulina.
         */
        val textProducts: List<InsulinProduct>?,
        /** Pediu "farmácia popular": só prioriza. */
        val popular: Boolean,
        /** Palavras que não foram entendidas. */
        val unknown: List<String>,
        /** Texto inteiro já corrigido ("Você quis dizer…"). Nunca é aplicado sozinho. */
        val suggestion: String?,
        /** Município citado no texto. Só vira filtro se a pessoa tocar. */
        val cityHint: City?,
    )

    val EMPTY = Resolved(null, false, emptyList(), null, null)

    fun resolve(raw: String): Resolved {
        // "70/30", "campinas/sp" e "campinas - sp" viram palavras separadas
        val clean = norm(raw).replace(NON_ALNUM, " ").trim().replace(SPACES, " ")
        if (clean.isEmpty()) return EMPTY
        val parsed = parse(clean)
        val catalog = InsulinCatalog.products

        // União: princípio/grupo + marca citada
        val union = LinkedHashMap<String, InsulinProduct>()
        for (id in parsed.insulinIds) catalog.filter { matchesId(id, it) }.forEach { union[it.id] = it }
        for (b in parsed.brands) {
            catalog.filter { PNORMS[it.id]?.brand?.contains(" $b ") == true }.forEach { union[it.id] = it }
        }

        // Palavras que batem com marca / fabricante / apresentação do catálogo (todas precisam bater)
        var byCatalog: List<InsulinProduct>? = null
        val unknown = mutableListOf<String>()
        for (t in parsed.tokens) {
            val hit = if (t.length >= 3 || t.all { it.isDigit() }) catalog.filter { p -> PNORMS[p.id]?.words?.any { it.startsWith(t) } == true } else emptyList()
            if (hit.isNotEmpty()) {
                val ids = hit.map { it.id }.toSet()
                byCatalog = byCatalog?.filter { it.id in ids } ?: hit
            } else {
                unknown += t
            }
        }

        // Município no meio do texto (ex.: "lantus curitiba", "nph sao paulo sp")
        var city: City? = null
        var remaining: List<String> = unknown
        if (unknown.isNotEmpty()) {
            val found = findCityIn(unknown)
            if (found != null) { city = found.first; remaining = unknown - found.second.toSet() }
        }

        val cat: List<InsulinProduct>? = byCatalog
        val products: List<InsulinProduct>? = when {
            union.isNotEmpty() && cat != null -> union.values.filter { u -> cat.any { it.id == u.id } }
            union.isNotEmpty() -> union.values.toList()
            cat != null -> cat
            remaining.isNotEmpty() -> emptyList()
            else -> null
        }

        return Resolved(
            textProducts = products,
            popular = parsed.popular,
            unknown = remaining,
            suggestion = if (remaining.isNotEmpty()) suggestFor(clean, remaining) else null,
            cityHint = city,
        )
    }

    /** Procura um município em janelas de até 3 palavras seguidas (a maior primeiro). */
    private fun findCityIn(tokens: List<String>): Pair<City, List<String>>? {
        for (size in minOf(3, tokens.size) downTo 1) {
            for (start in 0..tokens.size - size) {
                val window = tokens.subList(start, start + size)
                if (size == 1 && window[0].length < 4) continue
                val hit = CityIndex.exactMatches(window.joinToString(" ")).firstOrNull()
                if (hit != null) return hit to window.toList()
            }
        }
        return null
    }

    private fun suggestFor(clean: String, unknown: List<String>): String? {
        val words = clean.split(' ')
        for (t in unknown) {
            // Palavra do vocabulário (insulinas) ou nome de município: vence o mais parecido; empate fica com a insulina
            val w = suggestWord(t)
            val c = CityIndex.suggest(t)?.let { it.name to levenshtein(t, norm(it.name)) }
            val fix = when {
                w != null && (c == null || w.second <= c.second) -> w.first
                c != null -> c.first
                else -> continue
            }
            return words.joinToString(" ") { if (it == t) fix else it }
        }
        return null
    }

    /** (palavra sugerida, distância) ou null. */
    private fun suggestWord(t: String): Pair<String, Int>? {
        if (t.length < 4) return null
        if (VOCAB.any { it == t || it.startsWith(t) }) return null // já é um termo (ou começo dele) válido
        val limit = if (t.length <= 5) 1 else 2
        var best: String? = null
        var bestD = Int.MAX_VALUE
        for (v in VOCAB) {
            if (kotlin.math.abs(v.length - t.length) > limit) continue
            val d = levenshtein(t, v)
            if (d in 1..limit && d < bestD) { best = v; bestD = d }
        }
        return best?.let { it to bestD }
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return prev[b.length]
    }
}
