package com.agon.app.data.insulin

import android.content.Context
import com.agon.app.data.LocatorSearch
import com.agon.app.data.PlaceFinder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Índice de municípios para busca offline (sem acento, sem diferenciar maiúsculas).
 *
 * Base: a lista curada de [BrazilGeo] (194 municípios, com classificação capital/metropolitana/interior).
 * Opcional: se existir `assets/ibge_municipios.txt` (gerado por `tools/gerar_ibge_municipios.py`),
 * os 5.570 municípios do IBGE são somados. Sem o arquivo, tudo continua funcionando só com a lista curada.
 *
 * Formato do arquivo, uma linha por município: `UF|Nome|latitude|longitude|C/M/I`.
 */
object CityIndex {
    const val IBGE_ASSET = "ibge_municipios.txt"

    private class Snapshot(
        val all: List<City>,
        val byId: Map<String, City>,
        /** (nome normalizado sem sufixo entre parênteses, cidade) */
        val norms: List<Pair<String, City>>,
        val ibgeCount: Int,
    )

    @Volatile private var snap: Snapshot = build(emptyList())

    /** true quando o arquivo do IBGE foi carregado. */
    val ibgeLoaded: Boolean get() = snap.ibgeCount > 0

    val all: List<City> get() = snap.all
    val size: Int get() = snap.all.size

    fun byId(id: String): City? = snap.byId[id]

    /** Capitais, depois região metropolitana, depois interior; em cada grupo, ordem alfabética. */
    fun citiesOf(uf: String): List<City> =
        snap.all.filter { it.uf == uf }
            .sortedWith(compareBy<City> { it.tier.ordinal }.thenBy { LocatorSearch.norm(it.name) })

    // ---------------------------------------------------------------- carga opcional do IBGE

    /** Lê o arquivo do IBGE em segundo plano. Sem o arquivo, não faz nada. Pode ser chamado várias vezes. */
    suspend fun loadIbge(context: Context) {
        if (snap.ibgeCount > 0) return
        val parsed = withContext(Dispatchers.IO) {
            try {
                context.applicationContext.assets.open(IBGE_ASSET).bufferedReader().use { r ->
                    r.lineSequence().mapNotNull { parseLine(it) }.toList()
                }
            } catch (_: Exception) {
                emptyList()
            }
        }
        if (parsed.isNotEmpty()) snap = withContext(Dispatchers.Default) { build(parsed) }
    }

    internal fun parseLine(line: String): City? {
        val p = line.split("|")
        if (p.size < 4) return null
        val uf = p[0].trim().uppercase()
        val name = p[1].trim()
        val lat = p[2].trim().toDoubleOrNull() ?: return null
        val lon = p[3].trim().toDoubleOrNull() ?: return null
        if (uf.length != 2 || name.isEmpty()) return null
        val tier = when (p.getOrNull(4)?.trim()) {
            "C" -> CityTier.CAPITAL
            "M" -> CityTier.METROPOLITANA
            else -> CityTier.INTERIOR
        }
        return City(idFor(uf, name), name, uf, lat, lon, tier)
    }

    private fun slug(name: String): String =
        LocatorSearch.norm(name).replace(Regex("[^a-z0-9]+"), "-").trim('-')

    private fun idFor(uf: String, name: String) = "${uf.lowercase()}-${slug(name)}"

    private fun searchName(c: City): String = LocatorSearch.norm(c.name.substringBefore('(')).trim()

    private fun build(extra: List<City>): Snapshot {
        val curated = BrazilGeo.cities
        val seen = curated.mapTo(HashSet()) { it.uf + "|" + searchName(it) }
        val added = extra.filter { seen.add(it.uf + "|" + searchName(it)) }
        val all = curated + added
        return Snapshot(
            all = all,
            byId = all.associateBy { it.id },
            norms = all.map { searchName(it) to it },
            ibgeCount = added.size.coerceAtLeast(if (extra.isNotEmpty()) 1 else 0),
        )
    }

    // ---------------------------------------------------------------- consulta

    /** Separa "Campinas, SP", "Campinas - SP" ou "Campinas/SP" em (nome normalizado, UF?). */
    internal fun splitUf(text: String): Pair<String, String?> {
        val n = LocatorSearch.norm(text).trim()
        val m = Regex("^(.*?)[\\s,/-]+([a-z]{2})$").matchEntire(n)
        if (m != null) {
            val uf = m.groupValues[2].uppercase()
            if (BrazilGeo.ufByCode(uf) != null && m.groupValues[1].isNotBlank()) {
                return m.groupValues[1].trim().trim(',', '-', '/').trim() to uf
            }
        }
        return n to null
    }

    /** Municípios cujo nome é exatamente o digitado (capitais primeiro). */
    fun exactMatches(text: String): List<City> {
        val (name, uf) = splitUf(text)
        if (name.isBlank()) return emptyList()
        return snap.norms
            .filter { (n, c) -> n == name && (uf == null || c.uf == uf) }
            .map { it.second }
            .sortedBy { it.tier.ordinal }
    }

    fun find(name: String, uf: String?): City? {
        val n = LocatorSearch.norm(name).trim()
        return snap.norms.firstOrNull { (k, c) -> k == n && (uf == null || c.uf == uf) }?.second
    }

    /** Sugestões enquanto digita: começa com o texto primeiro, depois contém. */
    fun search(text: String, limit: Int = 8): List<City> {
        val (name, uf) = splitUf(text)
        if (name.length < 2) return emptyList()
        val pool = snap.norms.filter { uf == null || it.second.uf == uf }
        val starts = pool.filter { it.first.startsWith(name) }
        val contains = if (starts.size >= limit) emptyList() else pool.filter { !it.first.startsWith(name) && it.first.contains(name) }
        return (starts.sortedWith(compareBy({ it.second.tier.ordinal }, { it.first })) +
            contains.sortedBy { it.first })
            .map { it.second }
            .take(limit)
    }

    /** Município do índice mais próximo do ponto (null se nenhum a menos de [maxKm]). */
    fun nearest(lat: Double, lon: Double, maxKm: Double = 60.0): City? {
        var best: City? = null
        var bestD = Double.MAX_VALUE
        for (c in snap.all) {
            val d = PlaceFinder.distanceKm(lat, lon, c.lat, c.lon)
            if (d < bestD) { best = c; bestD = d }
        }
        return if (bestD <= maxKm) best else null
    }

    /** Nome de município parecido com o digitado (erro de digitação). Nunca aplicado sozinho. */
    fun suggest(tokenNorm: String): City? {
        if (tokenNorm.length < 5) return null
        val limit = if (tokenNorm.length <= 6) 1 else 2
        var best: City? = null
        var bestD = Int.MAX_VALUE
        for ((n, c) in snap.norms) {
            if (kotlin.math.abs(n.length - tokenNorm.length) > limit) continue
            val d = LocatorSearch.levenshtein(tokenNorm, n)
            if (d in 1..limit && d < bestD) { best = c; bestD = d }
        }
        return best
    }
}
