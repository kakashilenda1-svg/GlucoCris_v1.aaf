package com.agon.app.data.insulin

import java.net.URLEncoder

/** Cartão "onde pegar" de um grupo de insulinas que compartilham os mesmos canais de acesso. */
data class GuideCard(
    /** Nomes das insulinas do grupo (até 3, depois "e mais N"). */
    val products: String,
    /** Onde pegar, em poucas palavras. */
    val headline: String,
    val detail: String,
    /** Gratuita (SUS / CEAF). */
    val free: Boolean,
    val channelIds: Set<String>,
)

/**
 * Orientação por insulina (NPH/regular -> UBS e Farmácia Popular; análogos -> CEAF; privadas -> rede de farmácias)
 * derivada dos canais do catálogo, e ajudantes de contato (Ligar / WhatsApp com mensagem pronta).
 * Só orienta onde costuma ser dispensada; nunca afirma estoque nem equivalência entre insulinas.
 */
object InsulinGuide {

    fun build(products: List<InsulinProduct>): List<GuideCard> =
        products.groupBy { it.channels }
            .map { (channels, group) -> card(channels, group) }
            .sortedWith(compareByDescending<GuideCard> { it.free }.thenBy { it.headline })

    private fun card(channels: Set<String>, group: List<InsulinProduct>): GuideCard {
        val names = group.map { it.brandName }.distinct()
        val shown = names.take(3).joinToString(", ") + if (names.size > 3) " e mais ${names.size - 3}" else ""
        val sus = channels == setOf(InsulinCatalog.CH_ATENCAO_BASICA, InsulinCatalog.CH_FARMACIA_POPULAR)
        return when {
            sus -> GuideCard(
                shown, "UBS ou Farmácia Popular",
                "Gratuita. Leve receita, documento com foto e Cartão do SUS ou CPF. Na UBS, siga o fluxo do seu município; " +
                    "na Farmácia Popular, procure drogarias com o selo “Aqui Tem Farmácia Popular”.",
                true, channels,
            )
            channels == setOf(InsulinCatalog.CH_CEAF) -> GuideCard(
                shown, "CEAF do seu estado",
                "Gratuita mediante processo: laudo (LME) preenchido pelo médico, receita, exames do PCDT e comprovante de residência. " +
                    "A Secretaria de Estado da Saúde define a unidade de referência.",
                true, channels,
            )
            channels == setOf(InsulinCatalog.CH_PRIVADA) -> GuideCard(
                shown, "Rede de farmácias",
                "Venda com receita e preço limitado ao teto PMC da CMED. Ligue antes para confirmar estoque e preço.",
                false, channels,
            )
            else -> {
                val chs = channels.mapNotNull { ChannelType.byId(it) }
                GuideCard(
                    shown, chs.joinToString(" ou ") { it.short }.ifBlank { "Consulte a rede de saúde" },
                    "A disponibilidade varia por canal. Confirme por telefone antes de se deslocar.",
                    chs.isNotEmpty() && chs.all { it.priceTier != PriceTier.PMC_CMED }, channels,
                )
            }
        }
    }

    /** Mensagem pronta para o estabelecimento ("Olá! Vocês têm Lantus?"). */
    fun message(products: List<InsulinProduct>): String {
        val names = products.map { it.brandName }.distinct()
        val shortest = names.minByOrNull { it.length }
        val what = when {
            names.isEmpty() -> "insulina"
            names.size == 1 -> names[0]
            shortest != null && names.all { it.startsWith(shortest, ignoreCase = true) } -> shortest
            names.size == 2 -> names.joinToString(" ou ")
            else -> {
                val cats = products.map { it.categoryId }.distinct()
                val short = if (cats.size == 1) InsulinCatalog.categoryById(cats[0])?.shortName else null
                if (short != null) "insulina $short" else "insulina"
            }
        }
        return "Olá! Vocês têm $what?"
    }

    // ---------------------------------------------------------------- contato

    /** Primeiro telefone de um texto que pode ter vários ("(11) 3333-4444; (11) 99999-8888"). */
    fun firstPhone(raw: String): String =
        raw.split(';', '/', ',').map { it.trim() }.firstOrNull { digits(it).length >= 8 }.orEmpty()

    private fun digits(s: String) = s.filter { it.isDigit() }

    /** DDD + número, sem 55 e sem zero de operadora. Vazio se não der para saber. */
    internal fun national(raw: String): String {
        var d = digits(firstPhone(raw))
        if (d.startsWith("55") && d.length >= 12) d = d.drop(2)
        d = d.trimStart('0')
        return d
    }

    /** Celular com DDD (11 dígitos, o 3º é 9): só esses costumam ter WhatsApp. */
    fun isMobile(raw: String): Boolean {
        val n = national(raw)
        return n.length == 11 && n[2] == '9'
    }

    /** Link do WhatsApp com a mensagem pronta, ou null se o telefone não for celular com DDD. */
    fun whatsappUrl(rawPhone: String, message: String): String? {
        if (!isMobile(rawPhone)) return null
        val text = URLEncoder.encode(message, "UTF-8").replace("+", "%20")
        return "https://wa.me/55${national(rawPhone)}?text=$text"
    }
}
