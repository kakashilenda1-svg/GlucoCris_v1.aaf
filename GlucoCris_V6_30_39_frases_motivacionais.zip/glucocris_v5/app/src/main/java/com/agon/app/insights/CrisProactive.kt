package com.agon.app.insights

import android.content.Context
import com.agon.app.data.AppData
import com.agon.app.data.toMgDl
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.roundToInt

/** Um aviso da Cris: pode abrir uma tela ou iniciar uma conversa. Só descreve; nunca indica dose. */
data class Nudge(
    val key: String,
    val emoji: String,
    val title: String,
    val text: String,
    val action: Action,
    val prompt: String = "",
    val urgent: Boolean = false,
) { enum class Action { GLUCOSE_FORM, FOOD, REMINDERS, ASK_CRIS, NONE } }

object CrisProactive {
    private const val MIN = 60_000L

    private fun hour(at: Long) = Calendar.getInstance().apply { timeInMillis = at }.get(Calendar.HOUR_OF_DAY)
    private fun dow(at: Long) = Calendar.getInstance().apply { timeInMillis = at }.get(Calendar.DAY_OF_WEEK)
    private fun hLabel(h: Int) = "%02dh".format(h)
    private val DOW = mapOf(
        Calendar.SUNDAY to "domingos", Calendar.MONDAY to "segundas", Calendar.TUESDAY to "terças", Calendar.WEDNESDAY to "quartas",
        Calendar.THURSDAY to "quintas", Calendar.FRIDAY to "sextas", Calendar.SATURDAY to "sábados",
    )

    /** O QUE FAZER AGORA: situações do momento (Home por contexto). Ordem = prioridade. */
    fun now(data: AppData, now: Long = System.currentTimeMillis()): List<Nudge> {
        val s = data.settings
        val out = mutableListOf<Nudge>()
        val reads = Insights.readings(data, 2, now)
        val last = reads.lastOrNull()
        val h = hour(now)

        if (last != null && now - last.at <= 120 * MIN) {
            val ago = ((now - last.at) / MIN).toInt()
            val agoTxt = if (ago < 60) "há $ago min" else "há ${ago / 60} h"
            if (last.mg < s.targetLow) out += Nudge(
                "low_now", "⚠️", "Glicemia baixa ${agoTxt}",
                "Última medição: ${last.mg.roundToInt()} mg/dL, abaixo da sua meta. Siga a orientação da sua equipe de saúde e meça de novo em seguida.",
                Nudge.Action.GLUCOSE_FORM, urgent = true,
            ) else if (last.mg > s.targetHigh) out += Nudge(
                "high_now", "📈", "Glicemia alta ${agoTxt}",
                "Última medição: ${last.mg.roundToInt()} mg/dL, acima da sua meta. Beba água e meça de novo mais tarde, conforme a orientação da sua equipe de saúde.",
                Nudge.Action.GLUCOSE_FORM,
            )
            // Subindo ou caindo rápido: 3 medições seguidas na mesma direção em 90 min
            val trend = reads.filter { now - it.at <= 90 * MIN }
            if (trend.size >= 3) {
                val d = trend.zipWithNext { a, b -> b.mg - a.mg }
                if (d.all { it >= 10 } && trend.last().mg - trend.first().mg >= 30) out += Nudge(
                    "rising", "↗️", "Glicose subindo",
                    "Suas últimas ${trend.size} medições vêm subindo (${trend.first().mg.roundToInt()} → ${trend.last().mg.roundToInt()} mg/dL).",
                    Nudge.Action.ASK_CRIS, "Minha glicose está subindo nas últimas medições (${trend.first().mg.roundToInt()} → ${trend.last().mg.roundToInt()} mg/dL). O que pode estar acontecendo e o que devo observar? Não calcule dose.",
                )
                if (d.all { it <= -10 } && trend.first().mg - trend.last().mg >= 40) out += Nudge(
                    "falling", "↘️", "Glicose caindo",
                    "Suas últimas ${trend.size} medições vêm caindo (${trend.first().mg.roundToInt()} → ${trend.last().mg.roundToInt()} mg/dL). Meça de novo em breve.",
                    Nudge.Action.GLUCOSE_FORM,
                )
            }
        }

        // 2 h depois da refeição, sem medir
        data.meals.filter { !it.id.startsWith("demo-") && now - it.at in 90 * MIN..150 * MIN }.maxByOrNull { it.at }?.let { m ->
            if (reads.none { it.at > m.at }) out += Nudge(
                "post_meal", "🍽️", "Medir 2 h depois da refeição",
                "Você registrou uma refeição há cerca de ${((now - m.at) / MIN / 60.0).let { "%.1f".format(it) }} h. Medir agora mostra o efeito dela na sua glicose.",
                Nudge.Action.GLUCOSE_FORM,
            )
        }

        // Faz muito tempo sem medir (só de dia)
        val lastAny = Insights.readings(data, 3, now).lastOrNull()
        if (h in 7..21 && lastAny != null && now - lastAny.at >= 5 * 60 * MIN) {
            out += Nudge(
                "gap", "🩸", "Faz ${(now - lastAny.at) / MIN / 60} h que você não mede",
                "Sua última medição foi às ${"%02d:%02d".format(hour(lastAny.at), Calendar.getInstance().apply { timeInMillis = lastAny.at }.get(Calendar.MINUTE))}.",
                Nudge.Action.GLUCOSE_FORM,
            )
        }

        // Refeição habitual chegando
        MealHabits.suggest(data, now, windowMin = 45, max = 1).firstOrNull()?.let { hm ->
            out += Nudge(
                "meal_soon", "🍴", "Hora de ${when (hm.type) { "cafe" -> "o café"; "almoco" -> "almoçar"; "jantar" -> "jantar"; else -> "lanchar" }}?",
                "Você costuma comer ${hm.description} por volta das ${"%02d:%02d".format(hm.typicalMin / 60, hm.typicalMin % 60)}. Abra a Alimentação para usar esse prato.",
                Nudge.Action.FOOD,
            )
        }

        // Próximo lembrete nos próximos 30 min
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        val today = cal.get(Calendar.DAY_OF_WEEK) - 1
        data.reminders.filter { it.enabled && today in it.days }
            .map { it to (it.hour * 60 + it.minute - nowMin) }.filter { it.second in 0..30 }.minByOrNull { it.second }?.let { (r, d) ->
                out += Nudge("rem_soon", "⏰", "${r.title} ${if (d == 0) "agora" else "em $d min"}", "Lembrete das ${"%02d:%02d".format(r.hour, r.minute)}.", Nudge.Action.REMINDERS)
            }
        return out
    }

    /** O QUE A CRIS NOTOU: padrões que se repetem (últimas semanas). Sem urgência. */
    fun patterns(data: AppData, now: Long = System.currentTimeMillis()): List<Nudge> {
        val s = data.settings
        val out = mutableListOf<Nudge>()
        val reads = Insights.readings(data, 28, now)
        if (reads.size < 12) return out

        // 1) Alta repetida no mesmo dia da semana e faixa de horário
        val highs = reads.filter { it.mg > s.targetHigh }.groupBy { dow(it.at) to hour(it.at) / 3 }
        highs.filter { (_, l) -> l.map { it.at / Insights.DAY_MS / 7 }.distinct().size >= 3 }
            .maxByOrNull { it.value.size }?.let { (k, l) ->
                val d = DOW[k.first] ?: "dias"
                out += Nudge(
                    "pat_high_${k.first}_${k.second}", "📈", "Altas nas $d entre ${hLabel(k.second * 3)} e ${hLabel(k.second * 3 + 3)}",
                    "Em ${l.map { it.at / Insights.DAY_MS / 7 }.distinct().size} das últimas 4 semanas sua glicose passou de ${s.targetHigh} nas $d entre ${hLabel(k.second * 3)} e ${hLabel(k.second * 3 + 3)}.",
                    Nudge.Action.ASK_CRIS,
                    "Notei glicemias acima de ${s.targetHigh} nas $d entre ${hLabel(k.second * 3)} e ${hLabel(k.second * 3 + 3)} em várias semanas. O que pode explicar esse padrão e o que perguntar à minha equipe de saúde? Não calcule dose.",
                )
            }

        // 2) Baixas repetidas na mesma faixa de horário
        val lows = reads.filter { it.mg < s.targetLow }.groupBy { hour(it.at) / 3 }
        lows.filter { (_, l) -> l.map { it.at / Insights.DAY_MS }.distinct().size >= 3 }.maxByOrNull { it.value.size }?.let { (b, l) ->
            out += Nudge(
                "pat_low_$b", "⚠️", "Baixas por volta das ${hLabel(b * 3)}",
                "Foram ${l.size} medições abaixo de ${s.targetLow} entre ${hLabel(b * 3)} e ${hLabel(b * 3 + 3)} nas últimas 4 semanas. Vale conversar com a equipe de saúde.",
                Nudge.Action.ASK_CRIS,
                "Tive ${l.size} glicemias abaixo de ${s.targetLow} entre ${hLabel(b * 3)} e ${hLabel(b * 3 + 3)} nas últimas 4 semanas. O que isso pode indicar e que perguntas levar ao médico? Não calcule dose.",
            )
        }

        // 3) Poucas medições por dia
        val perDay = reads.filter { now - it.at <= 7 * Insights.DAY_MS }.groupBy { it.at / Insights.DAY_MS }
        val daysWithFew = (0 until 7).count { i -> (perDay[now / Insights.DAY_MS - i]?.size ?: 0) < 2 }
        if (daysWithFew >= 4) out += Nudge(
            "pat_few", "🩸", "Poucas medições esta semana",
            "Em $daysWithFew dos últimos 7 dias você mediu menos de 2 vezes. Mais medições deixam as análises da Cris mais confiáveis.",
            Nudge.Action.REMINDERS,
        )

        // 4) Fim de semana diferente
        val (we, wd) = reads.partition { dow(it.at).let { d -> d == Calendar.SATURDAY || d == Calendar.SUNDAY } }
        if (we.size >= 6 && wd.size >= 12) {
            val tw = we.count { it.mg in s.targetLow.toDouble()..s.targetHigh.toDouble() } * 100.0 / we.size
            val td = wd.count { it.mg in s.targetLow.toDouble()..s.targetHigh.toDouble() } * 100.0 / wd.size
            if (abs(tw - td) >= 15) out += Nudge(
                "pat_weekend", "🗓️", if (tw < td) "Fins de semana mais difíceis" else "Fins de semana melhores",
                "Seu tempo na meta é ${tw.roundToInt()}% no fim de semana e ${td.roundToInt()}% nos dias úteis.",
                Nudge.Action.ASK_CRIS,
                "Meu tempo na meta é ${tw.roundToInt()}% nos fins de semana e ${td.roundToInt()}% nos dias úteis. O que pode explicar essa diferença? Não calcule dose.",
            )
        }
        return out
    }

    // ---- controle de "já mostrei / já avisei" ----
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("cris_proactive", Context.MODE_PRIVATE)
    fun dismiss(c: Context, key: String) { p(c).edit().putLong("d_$key", System.currentTimeMillis()).apply() }
    fun dismissedRecently(c: Context, key: String, days: Int = 7, now: Long = System.currentTimeMillis()) =
        now - p(c).getLong("d_$key", 0L) < days * Insights.DAY_MS
    fun markNotified(c: Context, key: String) { p(c).edit().putLong("n_$key", System.currentTimeMillis()).apply() }
    fun notifiedRecently(c: Context, key: String, days: Int = 14, now: Long = System.currentTimeMillis()) =
        now - p(c).getLong("n_$key", 0L) < days * Insights.DAY_MS
}
