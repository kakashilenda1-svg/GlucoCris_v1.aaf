package com.agon.app.insights

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.agon.app.MainActivity
import com.agon.app.R
import com.agon.app.Routes
import com.agon.app.data.GlucoStorage
import com.agon.app.data.GlucoViewModel
import com.agon.app.notifications.NotificationCenter
import java.util.concurrent.TimeUnit

/** A Cris avisa, sem ninguém pedir, quando percebe um padrão novo. No máximo 1 por dia, respeitando a Central de notificações. */
class CrisProactiveWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        return try {
            if (!NotificationCenter.enabled(ctx, NotificationCenter.Cat.CRIS)) return Result.success()
            val live = GlucoViewModel.liveInstance()
            val data = if (live != null && !live.practice.value) live.data.value else GlucoStorage.read(ctx)
            if (data == null) return Result.success()
            val pick = CrisProactive.patterns(data).firstOrNull {
                !CrisProactive.notifiedRecently(ctx, it.key) && !CrisProactive.dismissedRecently(ctx, it.key)
            } ?: return Result.success()
            if (!NotificationCenter.allow(ctx, NotificationCenter.Cat.CRIS)) return Result.success()
            if (Build.VERSION.SDK_INT >= 33 &&
                ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
            ) return Result.success()
            val channel = "gluco_cris_proativa_v1"
            if (Build.VERSION.SDK_INT >= 26) {
                (ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager)
                    .createNotificationChannel(NotificationChannel(channel, "Cris percebeu algo", NotificationManager.IMPORTANCE_DEFAULT))
            }
            val open = Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(OpenRoute.EXTRA, Routes.HOME)
            }
            val b = NotificationCompat.Builder(ctx, channel)
                .setSmallIcon(R.drawable.ic_stat_drop)
                .setContentTitle("${pick.emoji} ${pick.title}")
                .setContentText(pick.text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(pick.text))
                .setColor(0xFF6D28D9.toInt())
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(ctx, 7761, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            NotificationManagerCompat.from(ctx).notify(7761, b.build())
            CrisProactive.markNotified(ctx, pick.key)
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            Result.success()
        }
    }
}

object CrisProactiveScheduler {
    fun ensure(ctx: Context) {
        try {
            val req = PeriodicWorkRequestBuilder<CrisProactiveWorker>(8, TimeUnit.HOURS).build()
            WorkManager.getInstance(ctx.applicationContext).enqueueUniquePeriodicWork("gluco_cris_proactive", ExistingPeriodicWorkPolicy.KEEP, req)
        } catch (_: Exception) {}
    }
}
