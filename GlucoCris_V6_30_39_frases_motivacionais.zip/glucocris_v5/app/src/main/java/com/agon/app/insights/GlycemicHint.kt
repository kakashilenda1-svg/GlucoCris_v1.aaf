package com.agon.app.insights

import com.agon.app.data.AppData
import com.agon.app.data.toMgDl
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Dicas de glicose para um alimento/rótulo escaneado. Só orienta hábitos (combinar com proteína/fibra,
 * medir antes e depois) e mostra o que a PRÓPRIA pessoa registrou antes. Nunca calcula nem sugere dose de insulina.
 */
object GlycemicHint {
    private const val MIN = 60_000L

    /** Quanto a glicose subiu, em média, 2 h depois de refeições registradas com carboidrato parecido. Null se faltar dado. */
    fun personalRise(data: AppData, carbs: Double, now: Long = System.currentTimeMillis()): Pair<Int, Int>? {
        if (carbs <= 0) return null
        val since = now - 90L * Insights.DAY_MS
        val g = data.glucose.filter { !it.id.startsWith("demo-") && it.at >= since }
            .map { it.at to toMgDl(it.value, it.unit) }.sortedBy { it.first }
        val deltas = data.meals.filter { !it.id.startsWith("demo-") && it.at >= since && (it.carbs ?: 0.0) > 0 }
            .filter { abs(it.carbs!! - carbs) <= carbs * 0.3 }
            .mapNotNull { m ->
                val before = g.lastOrNull { it.first <= m.at && m.at - it.first <= 60 * MIN } ?: return@mapNotNull null
                val after = g.filter { it.first - m.at in 60 * MIN..180 * MIN }
                    .minByOrNull { abs(it.first - (m.at + 120 * MIN)) } ?: return@mapNotNull null
                after.second - before.second
            }
        if (deltas.size < 2) return null
        return deltas.average().roundToInt() to deltas.size
    }

    fun forNutrition(
        data: AppData,
        carbs: Double?, sugars: Double?, fiber: Double?, protein: Double?, fat: Double?,
        servingLabel: String,
    ): List<String> {
        val out = mutableListOf<String>()
        if (carbs == null) {
            return listOf("Não consegui ler os carboidratos. Confira a tabela e corrija os valores antes de usar.")
        }
        val net = (carbs - (fiber ?: 0.0)).coerceAtLeast(0.0)
        val perTxt = if (servingLabel.isNotBlank()) "por $servingLabel" else "por porção"
        out += when {
            carbs < 15 -> "Pouco carboidrato (${fmt(carbs)} g $perTxt): costuma mexer pouco na glicose."
            carbs <= 30 -> "Carboidrato moderado (${fmt(carbs)} g $perTxt): vale medir antes e 2 h depois."
            else -> "Muito carboidrato (${fmt(carbs)} g $perTxt): tende a subir bastante a glicose. Uma porção menor ajuda."
        }
        if ((fiber ?: 0.0) >= 3) out += "Tem ${fmt(fiber!!)} g de fibras (líquido ≈ ${fmt(net)} g de carboidrato): as fibras suavizam a subida."
        if (sugars != null && carbs > 0 && sugars / carbs >= 0.5 && sugars >= 8) {
            out += "Mais da metade do carboidrato é açúcar (${fmt(sugars)} g): costuma subir rápido."
        }
        if ((protein ?: 0.0) + (fat ?: 0.0) >= 15) {
            out += "Com bastante proteína e gordura, o pico pode vir mais tarde. Meça de novo 3 a 4 h depois."
        } else if (carbs >= 15) {
            out += "Combinar com proteína ou salada (ex.: ovo, queijo, legumes) deixa a subida mais lenta."
        }
        personalRise(data, carbs)?.let { (rise, n) ->
            out += "Nos seus registros, refeições com carboidrato parecido subiram em média ${if (rise >= 0) "+" else ""}$rise mg/dL depois de 2 h ($n registros)."
        }
        out += "Dose de insulina é com sua equipe de saúde: o app não calcula nem sugere."
        return out
    }

    private fun fmt(v: Double) = if (v == v.roundToInt().toDouble()) v.roundToInt().toString() else "%.1f".format(v)
}
