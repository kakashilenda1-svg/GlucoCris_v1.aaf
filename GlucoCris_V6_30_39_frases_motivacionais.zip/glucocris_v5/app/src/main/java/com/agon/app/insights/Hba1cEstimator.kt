package com.agon.app.insights

import com.agon.app.data.AppData
import kotlin.math.abs

enum class EstimateConfidence(val label: String) {
    HIGH("Alta"),
    MEDIUM("Média"),
    LOW("Baixa"),
}

/**
 * Estimativa de HbA1c a partir da glicose registrada. NUNCA é exame laboratorial e nunca entra na série laboratorial.
 *
 * - [gmi]: Indicador de Gerenciamento da Glicose (3,31 + 0,02392 × média mg/dL).
 * - [ea1c]: HbA1c estimada pela equação do estudo ADAG (média + 46,7) / 28,7.
 * - [adjusted]: GMI corrigido pela diferença média entre o SEU exame e o GMI da época do exame (só com ≥ 2 exames comparáveis).
 * - [rangeLow]..[rangeHigh]: faixa aproximada, mais larga quando há menos dados. A largura é uma regra prática do app, não um intervalo estatístico.
 */
data class Hba1cEstimate(
    val gmi: Double,
    val ea1c: Double,
    val adjusted: Double?,
    val personalOffset: Double?,
    val examsUsed: Int,
    val rangeLow: Double,
    val rangeHigh: Double,
    val confidence: EstimateConfidence,
    val meanMg: Double,
    val readings: Int,
    val spanDays: Int,
    val periodDays: Int,
    val origin: DataOrigin,
    val coveragePct: Double?,
) {
    /** Valor principal exibido: o ajustado ao histórico quando existe; senão o GMI. */
    val headline: Double get() = adjusted ?: gmi
}

object Hba1cEstimator {
    const val DEFAULT_PERIOD_DAYS = 90
    /** Quantos exames recentes entram no ajuste pessoal. */
    const val MAX_EXAMS_FOR_ADJUST = 4
    const val MIN_EXAMS_FOR_ADJUST = 2
    /** Limite do ajuste pessoal em pontos percentuais: evita que um exame atípico distorça tudo. */
    const val MAX_ABS_OFFSET = 1.5

    fun gmiOf(meanMg: Double): Double = 3.31 + 0.02392 * meanMg

    fun ea1cOf(meanMg: Double): Double = (meanMg + 46.7) / 28.7

    fun confidenceOf(origin: DataOrigin, coveragePct: Double?, count: Int, spanDays: Int): EstimateConfidence {
        val cgmOk = origin == DataOrigin.CGM && (coveragePct ?: 0.0) >= 70.0 && spanDays >= 14
        val volumeOk = count >= 120 && spanDays >= 60
        return when {
            cgmOk || volumeOk -> EstimateConfidence.HIGH
            spanDays >= 30 || count >= 60 -> EstimateConfidence.MEDIUM
            else -> EstimateConfidence.LOW
        }
    }

    /** Margem (± p.p.) usada na faixa aproximada. Regra prática do app. */
    fun marginOf(c: EstimateConfidence): Double = when (c) {
        EstimateConfidence.HIGH -> 0.4
        EstimateConfidence.MEDIUM -> 0.6
        EstimateConfidence.LOW -> 0.8
    }

    private fun median(v: List<Double>): Double {
        val s = v.sorted()
        val n = s.size
        return if (n % 2 == 1) s[n / 2] else (s[n / 2 - 1] + s[n / 2]) / 2.0
    }

    /**
     * Diferença (exame − GMI) em cada exame cujos 90 dias anteriores têm glicose suficiente para um GMI confiável.
     * Do mais recente para o mais antigo.
     */
    fun examGaps(data: AppData, periodDays: Int = DEFAULT_PERIOD_DAYS): List<Double> =
        data.hba1c
            .sortedByDescending { it.at }
            .mapNotNull { lab ->
                val from = lab.at - periodDays * Insights.DAY_MS
                val st = Insights.stats(
                    Insights.readingsBetween(data, from, lab.at),
                    data.settings.targetLow, data.settings.targetHigh,
                ) ?: return@mapNotNull null
                if (!st.gmiReliable) null else lab.percent - st.gmi
            }
            .take(MAX_EXAMS_FOR_ADJUST)

    /** Estimativa dos últimos [periodDays] dias, ou null quando os dados não bastam para um GMI confiável. */
    fun compute(data: AppData, now: Long = System.currentTimeMillis(), periodDays: Int = DEFAULT_PERIOD_DAYS): Hba1cEstimate? {
        val list = Insights.readings(data, periodDays, now)
        val st = Insights.stats(list, data.settings.targetLow, data.settings.targetHigh) ?: return null
        if (!st.gmiReliable) return null

        val gmi = gmiOf(st.mean)
        val ea1c = ea1cOf(st.mean)
        val cov = if (st.dataOrigin == DataOrigin.CGM && st.coveragePct > 0.0) st.coveragePct else null
        val conf = confidenceOf(st.dataOrigin, cov, st.count, st.spanDays)

        val gaps = examGaps(data, periodDays)
        val offset = if (gaps.size >= MIN_EXAMS_FOR_ADJUST) median(gaps).coerceIn(-MAX_ABS_OFFSET, MAX_ABS_OFFSET) else null
        val adjusted = offset?.let { (gmi + it).coerceIn(Hba1cRules.MIN_PERCENT, Hba1cRules.MAX_PERCENT) }

        val center = adjusted ?: gmi
        val m = marginOf(conf)
        // A faixa também cobre a equação ADAG quando ela discorda do GMI (acontece nos extremos de glicose).
        val low = minOf(center - m, ea1c).coerceAtLeast(Hba1cRules.MIN_PERCENT)
        val high = maxOf(center + m, ea1c).coerceAtMost(Hba1cRules.MAX_PERCENT)

        return Hba1cEstimate(
            gmi = gmi, ea1c = ea1c, adjusted = adjusted, personalOffset = offset,
            examsUsed = if (offset != null) gaps.size else 0,
            rangeLow = low, rangeHigh = high, confidence = conf,
            meanMg = st.mean, readings = st.count, spanDays = st.spanDays, periodDays = periodDays,
            origin = st.dataOrigin, coveragePct = cov,
        )
    }

    /** Diferença entre dois valores em p.p. com sinal e vírgula decimal; útil para textos. */
    fun signed(d: Double): String = (if (d >= 0) "+" else "−") + Hba1cRules.f1(abs(d))

    const val DISCLAIMER =
        "Estimativa calculada a partir das medições de glicose registradas no app. Não é exame de HbA1c e pode diferir dele, " +
            "muitas vezes em meio ponto percentual ou mais. O exame laboratorial continua sendo a referência."
}
