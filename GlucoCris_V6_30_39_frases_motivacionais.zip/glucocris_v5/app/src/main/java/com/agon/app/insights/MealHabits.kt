package com.agon.app.insights

import com.agon.app.data.AppData
import java.util.Calendar
import kotlin.math.abs

/** Refeição habitual da pessoa, aprendida do diário (últimos 60 dias). */
data class HabitMeal(
    val type: String,
    val description: String,
    val carbs: Double?,
    val kcal: Double?,
    val protein: Double?,
    val fat: Double?,
    val times: Int,
    val typicalMin: Int,
)

object MealHabits {
    private fun minOfDay(at: Long): Int = Calendar.getInstance().apply { timeInMillis = at }
        .let { it.get(Calendar.HOUR_OF_DAY) * 60 + it.get(Calendar.MINUTE) }

    /** Tipo de refeição mais provável para o horário de [now]. */
    fun typeFor(now: Long = System.currentTimeMillis()): String = when (minOfDay(now) / 60) {
        in 4..9 -> "cafe"
        in 10..14 -> "almoco"
        in 15..17 -> "lanche"
        in 18..22 -> "jantar"
        else -> "lanche"
    }

    private fun key(desc: String) = desc.substringBefore(" · ").lowercase().replace(Regex("\\s+"), " ").trim()

    private fun note(notes: String, k: String): Double? =
        Regex("(?:^|;)$k=([0-9.,]+)").find(notes)?.groupValues?.get(1)?.replace(",", ".")?.toDoubleOrNull()

    /**
     * O que a pessoa costuma comer por volta deste horário (±2 h), repetido pelo menos 2 vezes.
     * Só aprende o que ela já registrou: nenhuma sugestão de alimento "novo".
     */
    fun suggest(data: AppData, now: Long = System.currentTimeMillis(), windowMin: Int = 120, max: Int = 3): List<HabitMeal> {
        val since = now - 60L * Insights.DAY_MS
        val nowMin = minOfDay(now)
        val near = data.meals.filter { !it.id.startsWith("demo-") && it.at >= since && it.description.isNotBlank() }
            .filter { abs(minOfDay(it.at) - nowMin) <= windowMin }
        // Já comeu algo parecido hoje nesta janela? Então não sugere de novo.
        val dayStart = Calendar.getInstance().apply { timeInMillis = now; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        val ateNow = near.any { it.at >= dayStart }
        if (ateNow) return emptyList()
        return near.groupBy { key(it.description) }
            .filter { it.key.isNotBlank() && it.value.size >= 2 }
            .map { (_, list) ->
                val latest = list.maxByOrNull { it.at }!!
                HabitMeal(
                    type = list.groupingBy { it.type }.eachCount().maxByOrNull { it.value }!!.key,
                    description = latest.description.substringBefore(" · ").trim(),
                    carbs = list.mapNotNull { it.carbs }.takeIf { it.isNotEmpty() }?.average(),
                    kcal = list.mapNotNull { note(it.notes, "kcal") }.takeIf { it.isNotEmpty() }?.average(),
                    protein = list.mapNotNull { note(it.notes, "prot") }.takeIf { it.isNotEmpty() }?.average(),
                    fat = list.mapNotNull { note(it.notes, "fat") }.takeIf { it.isNotEmpty() }?.average(),
                    times = list.size,
                    typicalMin = list.map { minOfDay(it.at) }.sorted()[list.size / 2],
                )
            }
            .sortedWith(compareByDescending<HabitMeal> { it.times }.thenBy { abs(it.typicalMin - nowMin) })
            .take(max)
    }
}
