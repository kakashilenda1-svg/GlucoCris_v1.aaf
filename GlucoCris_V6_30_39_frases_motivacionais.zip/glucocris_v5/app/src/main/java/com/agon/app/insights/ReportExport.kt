package com.agon.app.insights

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import com.agon.app.data.AppData
import com.agon.app.data.toMgDl
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Arquivos do relatório para enviar ao médico ou baixar. Ignora registros de exemplo (demo). */
object ReportExport {
    enum class Kind(val label: String, val mime: String, val ext: String) {
        PDF("PDF do médico", "application/pdf", "pdf"),
        CSV("Planilha (CSV)", "text/csv", "csv"),
        TXT("Texto", "text/plain", "txt"),
    }

    fun fileName(kind: Kind, days: Int): String =
        "GlucoCris_relatorio_${days}d_" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + "." + kind.ext

    private fun q(v: String) = "\"" + v.replace("\"", "\"\"") + "\""

    /** CSV simples (separador ponto e vírgula, abre direto no Excel pt-BR): glicose, insulina e refeições. */
    fun csv(data: AppData, days: Int, now: Long = System.currentTimeMillis()): String {
        val from = now - days * Insights.DAY_MS
        val fmt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR"))
        val sb = StringBuilder("\uFEFF")
        sb.appendLine("tipo;data_hora;valor;unidade;detalhe")
        data.glucose.filter { !it.id.startsWith("demo-") && it.at >= from }.sortedBy { it.at }.forEach {
            sb.appendLine("glicose;${fmt.format(Date(it.at))};${toMgDl(it.value, it.unit).toInt()};mg/dL;${q(it.context)}")
        }
        data.insulin.filter { !it.id.startsWith("demo-") && it.at >= from }.sortedBy { it.at }.forEach {
            sb.appendLine("insulina;${fmt.format(Date(it.at))};${it.dose};${it.unit};${q(it.name + " " + it.kind)}")
        }
        data.meals.filter { !it.id.startsWith("demo-") && it.at >= from }.sortedBy { it.at }.forEach {
            sb.appendLine("refeicao;${fmt.format(Date(it.at))};${it.carbs ?: ""};g carb;${q(it.type + ": " + it.description)}")
        }
        return sb.toString()
    }

    /** Gera o arquivo no cache e devolve os bytes (usado tanto para compartilhar quanto para baixar). */
    fun bytes(ctx: Context, data: AppData, days: Int, kind: Kind, reportText: () -> String): ByteArray = when (kind) {
        Kind.PDF -> MedicalPdf.build(ctx, data, days).readBytes()
        Kind.CSV -> csv(data, days).toByteArray(Charsets.UTF_8)
        Kind.TXT -> reportText().toByteArray(Charsets.UTF_8)
    }

    fun share(ctx: Context, bytes: ByteArray, kind: Kind, days: Int, subject: String) {
        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val f = File(dir, fileName(kind, days)).apply { writeBytes(bytes) }
        val uri = try { FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f) } catch (_: Exception) { android.net.Uri.fromFile(f) }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = kind.mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, subject)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(send, "Enviar ao médico").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
