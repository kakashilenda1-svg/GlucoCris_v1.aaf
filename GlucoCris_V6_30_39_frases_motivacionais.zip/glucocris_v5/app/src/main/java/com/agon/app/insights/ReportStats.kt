package com.agon.app.insights

import java.util.Calendar
import java.util.TimeZone

/** Percentis de glicose em uma hora do dia (todas as medições feitas nessa hora, em todos os dias do período). */
data class HourPercentiles(
    val hour: Int,
    val count: Int,
    val p10: Double,
    val p25: Double,
    val p50: Double,
    val p75: Double,
    val p90: Double,
)

data class SourceMix(val bluetooth: Int, val sensor: Int, val manual: Int) {
    val total: Int get() = bluetooth + sensor + manual
}

/** Estatísticas puras (sem Android) usadas pelo relatório em PDF. */
object ReportStats {
    /** Percentil com interpolação linear. [sorted] precisa estar em ordem crescente e não vazio. */
    fun percentile(sorted: List<Double>, p: Double): Double {
        require(sorted.isNotEmpty())
        if (sorted.size == 1) return sorted[0]
        val rank = p.coerceIn(0.0, 100.0) / 100.0 * (sorted.size - 1)
        val lo = rank.toInt()
        val hi = minOf(lo + 1, sorted.size - 1)
        return sorted[lo] + (sorted[hi] - sorted[lo]) * (rank - lo)
    }

    /** Horas com menos de [minPerHour] medições ficam de fora: percentil com 1 ou 2 pontos engana. */
    fun hourly(list: List<Reading>, minPerHour: Int = 3, tz: TimeZone = TimeZone.getDefault()): List<HourPercentiles> {
        val cal = Calendar.getInstance(tz)
        val byHour = list.groupBy { cal.apply { timeInMillis = it.at }.get(Calendar.HOUR_OF_DAY) }
        return (0..23).mapNotNull { h ->
            val v = byHour[h]?.map { it.mg }?.sorted() ?: return@mapNotNull null
            if (v.size < minPerHour) return@mapNotNull null
            HourPercentiles(
                hour = h, count = v.size,
                p10 = percentile(v, 10.0), p25 = percentile(v, 25.0), p50 = percentile(v, 50.0),
                p75 = percentile(v, 75.0), p90 = percentile(v, 90.0),
            )
        }
    }

    private fun dayKey(ms: Long, tz: TimeZone): Long {
        val c = Calendar.getInstance(tz).apply { timeInMillis = ms }
        return c.get(Calendar.YEAR) * 1000L + c.get(Calendar.DAY_OF_YEAR)
    }

    /** Em quantos dias diferentes houve ao menos uma medição que atende [predicate]. */
    fun daysWith(list: List<Reading>, tz: TimeZone = TimeZone.getDefault(), predicate: (Double) -> Boolean): Int =
        list.filter { predicate(it.mg) }.map { dayKey(it.at, tz) }.toSet().size

    fun distinctDays(list: List<Reading>, tz: TimeZone = TimeZone.getDefault()): Int =
        list.map { dayKey(it.at, tz) }.toSet().size

    /** Média por dia (mais antigo primeiro). A chave é o início do dia local. */
    fun dailyMeans(list: List<Reading>, tz: TimeZone = TimeZone.getDefault()): List<Pair<Long, Double>> {
        val cal = Calendar.getInstance(tz)
        return list
            .groupBy {
                cal.apply {
                    timeInMillis = it.at
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
            }
            .map { (day, items) -> day to items.map { it.mg }.average() }
            .sortedBy { it.first }
    }

    /** Origem dos registros pelo prefixo do id: "ble-" glicosímetro Bluetooth, "sensor-" CGM; o resto foi digitado. */
    fun sourceMix(ids: List<String>): SourceMix = SourceMix(
        bluetooth = ids.count { it.startsWith("ble-") },
        sensor = ids.count { it.startsWith("sensor-") },
        manual = ids.count { !it.startsWith("ble-") && !it.startsWith("sensor-") },
    )
}
