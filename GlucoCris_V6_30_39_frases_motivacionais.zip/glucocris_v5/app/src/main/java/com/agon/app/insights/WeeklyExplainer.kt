package com.agon.app.insights

import com.agon.app.data.AppData
import com.agon.app.data.toMgDl
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Explica POR QUE a semana foi assim, cruzando glicose, refeições e insulina registradas.
 * Só observa o que está nos registros: nunca calcula, sugere ou ajusta dose de insulina.
 * Cada regra só aparece com dados suficientes; sem dados, fica em silêncio (nada de chute).
 */
object WeeklyExplainer {
    private const val MIN = 60_000L
    private data class G(val at: Long, val mg: Double, val context: String)

    fun explain(data: AppData, now: Long = System.currentTimeMillis()): List<String> {
        val s = data.settings
        val from = now - 7 * Insights.DAY_MS
        fun glucose(a: Long, b: Long) = data.glucose
            .filter { !it.id.startsWith("demo-") && it.at in a..b }
            .map { G(it.at, toMgDl(it.value, it.unit), it.context) }
            .sortedBy { it.at }
        val cur = glucose(from, now)
        if (cur.size < 6) return emptyList()
        val prev = glucose(from - 7 * Insights.DAY_MS, from)
        val meals = data.meals.filter { !it.id.startsWith("demo-") }
        val insulin = data.insulin.filter { !it.id.startsWith("demo-") && it.kind == "aplicacao" }
        val low = s.targetLow.toDouble()
        val high = s.targetHigh.toDouble()
        val out = mutableListOf<String>()

        // 1) O que mudou em relação à semana anterior, e em que parte do dia
        if (prev.size >= 6) {
            val tirC = cur.count { it.mg in low..high } * 100.0 / cur.size
            val tirP = prev.count { it.mg in low..high } * 100.0 / prev.size
            val dTir = tirC - tirP
            if (abs(dTir) >= 5) {
                val parts = listOf("madrugada" to 0..5, "manhã" to 6..11, "tarde" to 12..17, "noite" to 18..23)
                fun mean(list: List<G>, r: IntRange): Double? =
                    list.filter { hourOf(it.at) in r }.takeIf { it.size >= 3 }?.map { it.mg }?.average()
                val diffs = parts.mapNotNull { (n, r) ->
                    val c = mean(cur, r); val p = mean(prev, r)
                    if (c != null && p != null) Triple(n, p, c) else null
                }
                diffs.maxByOrNull { abs(it.third - it.second) }?.takeIf { abs(it.third - it.second) >= 15 }?.let { (n, p, c) ->
                    val verbo = if (dTir > 0) "melhora" else "piora"
                    out += "A $verbo no tempo na meta veio sobretudo da $n: a média foi de ${p.roundToInt()} para ${c.roundToInt()} mg/dL."
                }
            }
        }

        // 2) Pico depois das refeições: qual tipo de refeição mais subiu e se carboidrato explica
        data class Rise(val type: String, val carbs: Double?, val delta: Double)
        val rises = meals.filter { it.at in from..now }.mapNotNull { m ->
            val before = cur.lastOrNull { it.at <= m.at && m.at - it.at <= 60 * MIN } ?: return@mapNotNull null
            val after = cur.filter { it.at - m.at in 60 * MIN..180 * MIN }.minByOrNull { abs(it.at - (m.at + 120 * MIN)) } ?: return@mapNotNull null
            Rise(m.type.trim().lowercase(), m.carbs, after.mg - before.mg)
        }
        if (rises.size >= 3) {
            rises.groupBy { it.type }.filter { it.key.isNotBlank() && it.value.size >= 2 }
                .maxByOrNull { e -> e.value.map { it.delta }.average() }?.let { (type, list) ->
                    val avg = list.map { it.delta }.average()
                    if (avg >= 40) out += "Depois do $type a glicose subiu em média ${avg.roundToInt()} mg/dL em ${list.size} registros: é onde a semana mais oscilou após comer."
                }
            val withCarbs = rises.filter { it.carbs != null }
            if (withCarbs.size >= 6) {
                val med = withCarbs.map { it.carbs!! }.sorted()[withCarbs.size / 2]
                val hi = withCarbs.filter { it.carbs!! >= med }.map { it.delta }
                val lo = withCarbs.filter { it.carbs!! < med }.map { it.delta }
                if (hi.size >= 3 && lo.size >= 3 && hi.average() - lo.average() >= 25) {
                    out += "Refeições com mais carboidrato (a partir de ${med.roundToInt()} g) subiram em média ${hi.average().roundToInt()} mg/dL; as mais leves, ${lo.average().roundToInt()} mg/dL."
                }
            }
        }

        // 3) Glicemias altas: o que aparece nos registros antes delas
        val highs = cur.filter { it.mg > high }
        if (highs.size >= 3) {
            val afterMeal = highs.count { h -> meals.any { h.at - it.at in 0..180 * MIN } }
            val noInsulin = highs.count { h -> insulin.none { h.at - it.at in 0..240 * MIN } }
            val parts = mutableListOf<String>()
            if (afterMeal * 2 >= highs.size) parts += "$afterMeal de ${highs.size} vieram até 3 h depois de uma refeição registrada"
            if (noInsulin * 2 >= highs.size) parts += "$noInsulin de ${highs.size} não têm aplicação de insulina registrada nas 4 h anteriores (pode ser falta de registro)"
            if (parts.isNotEmpty()) out += "Sobre as glicemias acima de ${s.targetHigh}: " + parts.joinToString("; ") + "."
        }

        // 4) Glicemias baixas: o que aparece antes delas
        val lows = cur.filter { it.mg < low }
        if (lows.size >= 2) {
            val afterInsulin = lows.count { l -> insulin.any { l.at - it.at in 0..240 * MIN } }
            val noMeal = lows.count { l -> meals.none { l.at - it.at in 0..180 * MIN } }
            val parts = mutableListOf<String>()
            if (afterInsulin * 2 >= lows.size) parts += "$afterInsulin de ${lows.size} ocorreram até 4 h depois de uma aplicação de insulina"
            if (noMeal * 2 >= lows.size) parts += "$noMeal de ${lows.size} sem refeição registrada nas 3 h anteriores"
            if (parts.isNotEmpty()) out += "Sobre as glicemias abaixo de ${s.targetLow}: " + parts.joinToString("; ") + ". Vale conversar com a equipe de saúde sobre isso."
        }

        // 5) Fim de semana x dias úteis
        val (we, wd) = cur.partition { val d = dowOf(it.at); d == Calendar.SATURDAY || d == Calendar.SUNDAY }
        if (we.size >= 5 && wd.size >= 5) {
            val tw = we.count { it.mg in low..high } * 100.0 / we.size
            val td = wd.count { it.mg in low..high } * 100.0 / wd.size
            if (abs(tw - td) >= 15) {
                out += if (tw < td) "No fim de semana o tempo na meta foi menor (${tw.roundToInt()}% contra ${td.roundToInt()}% nos dias úteis)."
                else "No fim de semana o tempo na meta foi maior (${tw.roundToInt()}% contra ${td.roundToInt()}% nos dias úteis)."
            }
        }

        // 6) Jejum x semana anterior
        val fc = cur.filter { it.context == "jejum" }.map { it.mg }
        val fp = prev.filter { it.context == "jejum" }.map { it.mg }
        if (fc.size >= 3 && fp.size >= 3 && abs(fc.average() - fp.average()) >= 10) {
            out += "A glicemia em jejum ficou em média ${fc.average().roundToInt()} mg/dL (semana anterior: ${fp.average().roundToInt()})."
        }
        return out.take(4)
    }

    private fun cal(at: Long) = Calendar.getInstance().apply { timeInMillis = at }
    private fun hourOf(at: Long) = cal(at).get(Calendar.HOUR_OF_DAY)
    private fun dowOf(at: Long) = cal(at).get(Calendar.DAY_OF_WEEK)
}
