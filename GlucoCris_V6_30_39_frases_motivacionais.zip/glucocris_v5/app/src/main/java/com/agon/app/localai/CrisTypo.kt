package com.agon.app.localai

import java.text.Normalizer

/** Tolerância a erros de digitação: corrige só palavras-chave conhecidas (usado para decidir/pesquisar, nunca mostrado). */
object CrisTypo {
    /** Instrução comum à IA online e à local: entender o SENTIDO de mensagens com erros, sem depender de lista de palavras. */
    const val UNDERSTAND_RULES: String =
        "ENTENDER A PESSOA: ela escreve rápido, no celular ou por voz. Interprete o SENTIDO, não as letras: erros de digitação, " +
            "letras trocadas ou faltando, falta de acento, palavras coladas ou separadas, abreviações, gírias e erros de reconhecimento de voz " +
            "(ex.: \"abacjate\" = abacate, \"amanja\" = amanhã, \"vc tá bem\" = você está bem). Use o assunto da conversa e do app " +
            "(alimentos, glicemia, insulina, receitas, horários) para escolher a palavra mais provável. Responda ao que ela quis dizer, " +
            "sem corrigir nem comentar o erro. Se duas leituras mudarem a resposta, siga a mais provável e confirme em uma frase curta " +
            "(\"Entendi X; se for Y, me avise\"). Pergunte só se não der para chutar. " +
            "Se houver dúvida em NÚMERO, dose ou nome de remédio, nunca adivinhe: confirme antes de responder.\n"

    fun fold(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").lowercase()

    private val VOCAB = listOf(
        "presidente", "atualmente", "notícias", "notícia", "semana", "descobriu", "brasil", "governador", "prefeito",
        "ministro", "aconteceu", "acontecendo", "importante", "importantes", "principais", "recentes", "últimas",
        "resultado", "cotação", "dólar", "medicamento", "remédio", "vacina", "quanto", "capital", "frança",
        "estados", "unidos", "mundial", "campeão", "inteligência", "artificial", "funciona", "explique", "pesquise",
        "internet", "argentina", "portugal", "alemanha", "espanha", "itália", "inglaterra", "japão", "china", "rússia",
    )
    /** Palavras do dia a dia do app (alimentos, tempo, saúde) para reconhecer erros de digitação como "amanja" ou "abacjate". */
    private val COMMON = listOf(
        "amanhã", "depois", "ontem", "agora", "manhã", "tarde", "noite", "domingo", "segunda", "terça", "quarta", "quinta", "sexta", "sábado",
        "abacate", "abacaxi", "banana", "laranja", "maçã", "mamão", "melancia", "morango", "manga", "limão", "tomate", "cebola", "batata",
        "cenoura", "brócolis", "alface", "abóbora", "chuchu", "beterraba", "pepino", "couve", "espinafre", "mandioca", "tapioca", "cuscuz",
        "arroz", "feijão", "macarrão", "farinha", "aveia", "granola", "queijo", "presunto", "frango", "carne", "peixe", "salmão", "sardinha",
        "ovos", "leite", "iogurte", "manteiga", "azeite", "chocolate", "sorvete", "biscoito", "bolacha", "refrigerante", "cerveja", "pizza",
        "hambúrguer", "sanduíche", "salada", "sopa", "omelete", "pudim", "brigadeiro", "bolo", "torrada", "castanha", "amendoim", "mel",
        "glicemia", "glicose", "insulina", "diabetes", "hipoglicemia", "hiperglicemia", "carboidrato", "carboidratos", "açúcar", "refeição",
        "almoço", "jantar", "lanche", "café", "exercício", "caminhada", "pressão", "receita", "receitas", "sintoma", "cansaço", "tontura",
        "médico", "consulta", "exame", "hemoglobina", "sensor", "caneta", "agulha", "dosagem", "medição", "medições", "registro", "registrar",
        "preciso", "posso", "quantos", "quantas", "temperatura", "previsão", "chovendo", "tempo", "calorias", "proteína", "gordura", "fibra",
    )
    private val BASE_WORDS: List<String> = VOCAB + COMMON

    /** Índice por 1ª letra (sem acento): palavra sem acento → forma original. Cresce com [registerVocab] (receitas e ingredientes do app). */
    @Volatile private var index: Map<Char, Map<String, String>> = buildIndex(BASE_WORDS)
    @Volatile private var known: Set<String> = BASE_WORDS.map { fold(it) }.toSet()
    private val vocabLock = Any()
    @Volatile private var vocabLoaded = false

    private fun buildIndex(words: Collection<String>): Map<Char, Map<String, String>> {
        val out = HashMap<Char, MutableMap<String, String>>()
        for (w in words) {
            val f = fold(w)
            if (f.length < 4 || f.any { !it.isLetter() }) continue
            out.getOrPut(f[0]) { HashMap() }.putIfAbsent(f, w.lowercase())
        }
        return out
    }

    /** Acrescenta palavras (ex.: nomes de alimentos do catálogo). Só letras, 4+ caracteres; o resto é ignorado. */
    fun registerVocab(words: Collection<String>) = synchronized(vocabLock) {
        val extra = words.flatMap { it.split(Regex("""[^\p{L}]+""")) }.filter { it.length >= 4 }.map { it.lowercase() }.distinct()
        val merged = BASE_WORDS + extra
        index = buildIndex(merged)
        known = merged.map { fold(it) }.toSet()
    }

    /** Carrega o vocabulário extra uma única vez (a fonte só é lida na primeira chamada). */
    fun registerVocabOnce(provider: () -> Collection<String>) {
        if (vocabLoaded) return
        synchronized(vocabLock) { if (vocabLoaded) return; vocabLoaded = true }
        try { registerVocab(provider()) } catch (_: Exception) { }
    }
    /**
     * Abreviações e gírias de chat (pt-BR). Só entram palavras de sentido único: nada que possa ser outra coisa
     * em uma frase comum. O que a pessoa digita nunca é alterado na tela; isto só normaliza o texto que a Cris processa.
     */
    private val SLANG: Map<String, String> = mapOf(
        // tempo
        "agr" to "agora", "agra" to "agora", "hj" to "hoje", "oje" to "hoje", "ontm" to "ontem", "amh" to "amanhã", "amnh" to "amanhã",
        "dps" to "depois", "depos" to "depois", "hrs" to "horas", "qdo" to "quando", "qnd" to "quando", "qndo" to "quando",
        // pessoas
        "vc" to "você", "vcs" to "vocês", "voce" to "você", "ngm" to "ninguém", "gnt" to "gente", "qm" to "quem", "cmg" to "comigo", "ctg" to "contigo",
        // perguntas
        "pq" to "porque", "oq" to "o que", "qto" to "quanto", "qtos" to "quantos", "qtas" to "quantas", "kd" to "cadê", "ond" to "onde", "aq" to "aqui",
        // ligação e intensidade
        "q" to "que", "p" to "para", "n" to "não", "ñ" to "não", "naum" to "não", "nd" to "nada", "td" to "tudo", "tdo" to "tudo",
        "tb" to "também", "tbm" to "também", "tmb" to "também", "msm" to "mesmo", "mt" to "muito", "mto" to "muito", "mts" to "muitos", "mtos" to "muitos",
        "dnv" to "de novo", "eh" to "é", "sla" to "sei lá", "ctz" to "certeza", "vdd" to "verdade", "tdb" to "tudo bem", "tdbm" to "tudo bem",
        // verbos
        "ta" to "está", "tá" to "está", "to" to "estou", "tô" to "estou", "tao" to "estão", "tão" to "estão",
        // cortesia
        "pf" to "por favor", "pfv" to "por favor", "pfvr" to "por favor", "obg" to "obrigado", "obgd" to "obrigado", "vlw" to "valeu", "blz" to "beleza",
        // coisas
        "msg" to "mensagem", "cel" to "celular", "refri" to "refrigerante",
        // saúde (só formas curtas inequívocas)
        "glic" to "glicemia", "insu" to "insulina",
    )
    private val SHORT = SLANG

    /** "vcs", "agr", "hj"…: devolve o texto com as abreviações escritas por extenso (e letras esticadas, "agoraaa", reduzidas). */
    fun expandSlang(text: String): String {
        val squeezed = Regex("""(\p{L})\1{2,}""").replace(text) { it.groupValues[1] }
        return Regex("""\p{L}+""").replace(squeezed) { SLANG[it.value.lowercase()] ?: it.value }
    }

    /** Distância de edição com troca de letras vizinhas ("abcate" → "abacte") contando como 1 erro só. */
    private fun dist(a: String, b: String): Int {
        if (a == b) return 0
        val d = Array(a.length + 1) { IntArray(b.length + 1) }
        for (i in 0..a.length) d[i][0] = i
        for (j in 0..b.length) d[0][j] = j
        for (i in 1..a.length) {
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                var v = minOf(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + cost)
                if (i > 1 && j > 1 && a[i - 1] == b[j - 2] && a[i - 2] == b[j - 1]) v = minOf(v, d[i - 2][j - 2] + 1)
                d[i][j] = v
            }
        }
        return d[a.length][b.length]
    }

    private fun fixToken(tok: String): String {
        SHORT[tok.lowercase()]?.let { return it }
        val f = fold(tok)
        if (f.length < 5 || f.any { !it.isLetter() }) return tok
        if (f in known) return tok
        val max = if (f.length >= 9) 2 else 1
        val bucket = index[f[0]] ?: return tok
        var best: String? = null
        var bestD = max + 1
        var ambiguous = false
        for ((cand, original) in bucket) {
            if (kotlin.math.abs(cand.length - f.length) > max) continue
            val d = dist(f, cand)
            if (d < bestD) { bestD = d; best = original; ambiguous = false } else if (d == bestD && original != best) ambiguous = true
        }
        return if (best != null && bestD <= max && !ambiguous) best else tok
    }

    fun fix(text: String): String {
        val expanded = expandSlang(text)
        return Regex("""\p{L}+""").replace(expanded) { m ->
            val tok = m.value
            val atStart = expanded.substring(0, m.range.first).none { it.isLetter() }
            if (tok[0].isUpperCase() && !atStart) tok else fixToken(tok)   // "Amanda", "Recife"… são nomes: ficam como estão
        }
    }
}
