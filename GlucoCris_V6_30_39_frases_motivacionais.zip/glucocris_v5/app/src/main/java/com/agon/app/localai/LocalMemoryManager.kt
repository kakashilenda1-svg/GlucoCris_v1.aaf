package com.agon.app.localai

import android.content.Context
import com.agon.app.data.uid
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/** Fato guardado pela Cris (aprendido sozinha ou a pedido). Fica só neste aparelho. */
@Serializable
data class CrisFact(val id: String, val text: String, val createdAt: Long, val auto: Boolean = false)

/**
 * Memória de longo prazo da Cris, separada do histórico de conversa.
 * É AUTOMÁTICA: a Cris aprende sozinha com o que a pessoa conta no chat e com a rotina real dos registros do app
 * (horários de glicose, insulina e refeições). Comandos como "lembre que ..." / "esqueça ..." continuam funcionando.
 */
object LocalMemoryManager {
    private const val FILE = "cris_localai_memory"
    private const val KEY = "facts.v1"
    private const val MAX_FACTS = 60
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    private fun p(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    @Synchronized
    fun load(c: Context): List<CrisFact> {
        val raw = p(c).getString(KEY, null) ?: return emptyList()
        return try { json.decodeFromString<List<CrisFact>>(raw) } catch (_: Exception) { emptyList() }
    }

    @Synchronized
    private fun save(c: Context, list: List<CrisFact>) {
        p(c).edit().putString(KEY, json.encodeToString(list.takeLast(MAX_FACTS))).apply()
    }

    fun add(c: Context, text: String): CrisFact? {
        val t = text.trim().take(300)
        if (t.length < 3) return null
        val f = CrisFact(uid(), t, System.currentTimeMillis())
        save(c, load(c) + f)
        return f
    }

    fun update(c: Context, id: String, text: String) {
        val t = text.trim().take(300)
        if (t.isBlank()) return
        save(c, load(c).map { if (it.id == id) it.copy(text = t) else it })
    }

    fun remove(c: Context, id: String) = save(c, load(c).filterNot { it.id == id })

    fun clear(c: Context) = p(c).edit().remove(KEY).remove(KEY_ROUTINE_AT).apply()

    private const val KEY_ROUTINE_AT = "routine.at"
    private const val ROUTINE_ID = "auto_rotina"
    private const val ROUTINE_EVERY_MS = 6L * 3_600_000L

    private fun norm(t: String) = t.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), "").replace(Regex("\\s+"), " ").trim()

    @Synchronized
    private fun addAuto(c: Context, text: String, id: String? = null): Boolean {
        val t = text.trim().take(600)
        if (t.length < 8) return false
        val list = load(c)
        if (id == null && list.any { norm(it.text) == norm(t) }) return false
        val f = CrisFact(id ?: uid(), t, System.currentTimeMillis(), auto = true)
        save(c, if (id != null) list.filterNot { it.id == id } + f else list + f)
        return true
    }

    // Frases em primeira pessoa que revelam rotina, gostos ou condição de saúde (não perguntas nem valores pontuais).
    private val LEARN_RE = Regex(
        """\b(costumo|sempre|normalmente|geralmente|todo dia|todos os dias|toda (manhã|manha|noite|tarde)|acordo|durmo|almoço|almoco|janto|tomo café|tomo cafe|treino|academia|caminho|trabalho|estudo|plantão|plantao|turno|gosto|não gosto|nao gosto|prefiro|odeio|amo|não como|nao como|alérgic|alergic|tenho alergia|diabetes tipo|uso (insulina|bomba|sensor|libre|dexcom)|minha (filha|esposa|mãe|mae|irmã|irma)|meu (filho|marido|pai|irmão|irmao))""",
        RegexOption.IGNORE_CASE,
    )
    private val FIRST_PERSON_RE = Regex("""\b(eu|meu|minha|meus|minhas|costumo|sempre|tenho|sou|uso|tomo|acordo|durmo|gosto|prefiro|trabalho|estudo|treino|faço|faco|almoço|almoco|janto|não|nao|odeio|amo|todo|toda|todos|normalmente|geralmente)\b""", RegexOption.IGNORE_CASE)

    /** Aprende sozinha, sem a pessoa pedir. Ignora perguntas, mensagens longas e qualquer coisa com número longo (CPF, telefone...). */
    fun learnFromMessage(c: Context, text: String) {
        try {
            text.split(Regex("(?<=[.!\\n])\\s+")).forEach { raw ->
                val t = raw.trim().trimEnd('.', '!')
                if (t.length !in 12..180 || '?' in t) return@forEach
                if (Regex("\\d{7,}").containsMatchIn(t) || "@" in t || "http" in t.lowercase()) return@forEach
                if (!FIRST_PERSON_RE.containsMatchIn(t) || !LEARN_RE.containsMatchIn(t)) return@forEach
                addAuto(c, t)
            }
        } catch (_: Exception) {}
    }

    private fun medianMinutes(times: List<Long>): Int {
        val cal = java.util.Calendar.getInstance()
        val m = times.map { cal.timeInMillis = it; cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE) }.sorted()
        return m[m.size / 2]
    }

    private fun clock(min: Int) = "%02d:%02d".format(min / 60, min % 60)

    /** Aprende a rotina real a partir dos registros (últimos 45 dias). Atualiza um único item e no máximo a cada 6 horas. */
    fun learnRoutine(c: Context, data: com.agon.app.data.AppData) {
        try {
            val now = System.currentTimeMillis()
            if (now - p(c).getLong(KEY_ROUTINE_AT, 0L) < ROUTINE_EVERY_MS) return
            p(c).edit().putLong(KEY_ROUTINE_AT, now).apply()
            val since = now - 45L * 86_400_000L
            val lines = mutableListOf<String>()
            data.glucose.filter { it.at >= since }.groupBy { it.context }.forEach { (ctxKey, list) ->
                if (list.size >= 3) {
                    val label = (com.agon.app.data.GLUCOSE_CONTEXT_LABEL[ctxKey] ?: ctxKey).lowercase()
                    lines += "mede a glicose (${label}) por volta de ${clock(medianMinutes(list.map { it.at }))} (${list.size} registros)"
                }
            }
            data.insulin.filter { it.at >= since }.groupBy { it.name.trim().lowercase() }.forEach { (name, list) ->
                if (name.isNotBlank() && list.size >= 3) lines += "aplica $name por volta de ${clock(medianMinutes(list.map { it.at }))} (${list.size} registros)"
            }
            data.meals.filter { it.at >= since }.groupBy { it.type.trim().lowercase() }.forEach { (type, list) ->
                if (type.isNotBlank() && list.size >= 3) lines += "$type por volta de ${clock(medianMinutes(list.map { it.at }))}"
            }
            if (lines.isEmpty()) return
            addAuto(c, "Rotina observada nos registros: " + lines.take(8).joinToString("; ") + ".", ROUTINE_ID)
        } catch (_: Exception) {}
    }

    private val SAVE_RE = Regex("""^\s*(?:cris[,!]?\s*)?(?:por favor[,]?\s*)?(?:lembre|lembra|guarde|guarda|memorize|anote|anota)\s+(?:que\s+|isso:?\s*|aí:?\s*)?(.+)$""", RegexOption.IGNORE_CASE)
    private val FORGET_RE = Regex("""^\s*(?:cris[,!]?\s*)?(?:esque[cç]a|apague|apaga|remova|remove)\s+(?:que\s+|a memória sobre\s+|o que (?:eu )?(?:disse|falei) sobre\s+)(.+)$""", RegexOption.IGNORE_CASE)
    private val LIST_RE = Regex("""(o que (você|voce|vc) (sabe|lembra|guardou)( sobre mim)?|suas? mem[oó]rias|minhas mem[oó]rias|o que (você|voce|vc) anotou)""", RegexOption.IGNORE_CASE)
    private val CLEAR_RE = Regex("""(apague|apaga|limpe|limpa|esque[cç]a)\s+(tudo|todas as (minhas )?mem[oó]rias|todas as mem[oó]rias)""", RegexOption.IGNORE_CASE)

    /** Resposta direta para comandos de memória, ou null se a mensagem não for um comando. */
    fun handleCommand(c: Context, text: String): String? {
        if (CLEAR_RE.containsMatchIn(text)) {
            clear(c)
            return "Pronto, apaguei tudo o que eu tinha guardado sobre você neste aparelho."
        }
        FORGET_RE.find(text)?.let { m ->
            val term = m.groupValues[1].trim().lowercase()
            val facts = load(c)
            val hit = facts.filter { term.length >= 3 && it.text.lowercase().contains(term) }
            if (hit.isEmpty()) return "Não encontrei nada guardado sobre \"$term\"."
            hit.forEach { remove(c, it.id) }
            return "Esqueci ${hit.size} item(ns) sobre \"$term\"."
        }
        if (LIST_RE.containsMatchIn(text)) {
            val facts = load(c)
            return if (facts.isEmpty()) "Ainda estou aprendendo sobre você. Conforme a gente conversa e você usa o app, eu vou anotando sozinha a sua rotina."
            else "Isto é o que guardei (só neste aparelho):\n" + facts.joinToString("\n") { "• ${it.text}" } +
                "\n\nSe quiser que eu esqueça algo, diga \"esqueça que ...\"."
        }
        SAVE_RE.find(text)?.let { m ->
            val body = m.groupValues[1].trim().trimEnd('.', '!')
            // Não confunde com a nota de preferência já tratada pela Cris local antiga:
            // aqui guardamos qualquer fato pedido explicitamente.
            val f = add(c, body) ?: return null
            return "Guardei: \"${f.text}\". Fica só neste aparelho e você pode apagar quando quiser."
        }
        return null
    }

    /** Bloco de texto para o prompt da IA local. */
    fun promptBlock(c: Context): String {
        val f = load(c)
        if (f.isEmpty()) return ""
        return "O que você já aprendeu sobre a pessoa e a rotina dela (use com naturalidade, sem repetir tudo):\n" + f.joinToString("\n") { "- ${it.text}" } + "\n"
    }
}
