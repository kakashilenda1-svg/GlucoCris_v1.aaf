package com.agon.app.love

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import com.agon.app.data.PrefsJson
import org.json.JSONObject
import java.time.LocalDate

/**
 * Frases motivacionais de superação e força, guardadas no aplicativo. Funcionam sem internet.
 * A ordem é fixa: uma por dia, avançando sem repetir até o fim da coleção.
 */
val LOVE_PHRASES = listOf(
    "Você é mais forte do que imagina e já provou isso muitas vezes.",
    "Cada dia vencido é uma vitória que ninguém pode tirar de você.",
    "Cair faz parte. Levantar é o que te define.",
    "Um passo de cada vez ainda é caminhar.",
    "A sua força aparece justamente nos dias em que você pensa que não tem mais.",
    "Não desista: o que hoje pesa, amanhã vira história de superação.",
    "Coragem não é não sentir medo, é seguir mesmo com ele.",
    "Você já superou 100% dos seus dias difíceis até aqui.",
    "Persistir é a forma mais bonita de vencer.",
    "Seu esforço de hoje constrói a sua tranquilidade de amanhã.",
    "Respire fundo, ajuste o passo e continue.",
    "Os desafios não chegam para te parar, e sim para mostrar do que você é capaz.",
    "Pequenas vitórias diárias formam grandes conquistas.",
    "Acredite: você tem tudo o que precisa para seguir em frente.",
    "Seu cuidado com a saúde é um ato de coragem todos os dias.",
    "A disciplina de hoje é a liberdade de amanhã.",
    "Nenhuma tempestade dura para sempre, e você é mais firme que ela.",
    "Foco no progresso, não na perfeição.",
    "Você não precisa ser perfeito, precisa ser constante.",
    "Tropeçar não é fracassar. Desistir é que seria.",
    "Respeite o seu ritmo: o importante é não parar.",
    "Quem enfrenta a rotina com determinação já é um vencedor.",
    "A sua história de superação está sendo escrita agora.",
    "Força não é ausência de cansaço, é continuar apesar dele.",
    "Cada escolha saudável é um voto de confiança no seu futuro.",
    "Você é capaz de coisas incríveis, comece com o que está ao seu alcance.",
    "Hoje é um ótimo dia para ser a sua melhor versão.",
    "Dias difíceis ensinam, dias bons recompensam. Aproveite os dois.",
    "Não compare o seu capítulo 1 com o capítulo 20 de ninguém.",
    "A resiliência mora em quem se recusa a abandonar a si mesmo.",
    "Seja paciente consigo: grandes mudanças levam tempo.",
    "O que você faz por você hoje, o seu futuro agradece.",
    "Você não está começando do zero, está começando da experiência.",
    "Todo grande guerreiro já pensou em desistir e mesmo assim continuou.",
    "Transforme obstáculos em degraus.",
    "A vitória de hoje pode ser simplesmente não desistir.",
    "Sua determinação é maior do que qualquer dificuldade.",
    "Confie no processo, ele está te levando mais longe do que você vê.",
    "Quem cuida de si com carinho vai longe.",
    "Mantenha a cabeça erguida, o melhor ainda está por vir.",
    "Seu corpo ouve tudo o que você diz a ele. Fale com gentileza e força.",
    "Cada manhã é uma nova chance de recomeçar com mais sabedoria.",
    "Você já chegou longe demais para parar agora.",
    "Fé no caminho, firmeza nos passos.",
    "A coragem de hoje é a conquista de amanhã.",
    "Quando tudo parecer difícil, lembre-se do porquê você começou.",
    "O sucesso é a soma de pequenos esforços repetidos todos os dias.",
    "Faça o seu melhor hoje, e amanhã faça de novo.",
    "Sua constância vale mais que qualquer pressa.",
    "Ninguém é mais forte do que quem escolheu continuar.",
    "Você é a prova de que é possível superar.",
    "Dê o seu melhor sem se cobrar além do que é humano.",
    "Cada obstáculo vencido te deixa mais preparado para o próximo.",
    "O seu limite de ontem é o seu ponto de partida de hoje.",
    "Seja gentil com você: até as montanhas mais altas se sobem passo a passo.",
    "Seu esforço silencioso hoje fará barulho nos seus resultados.",
    "Continue. Você está mais perto do que imagina.",
    "Não existe vitória sem luta, e você é um lutador.",
    "A sua saúde é a sua maior conquista, proteja-a com orgulho.",
    "Mesmo nos dias nublados, você segue brilhando.",
    "Quem não desiste já está à frente de quem nunca tentou.",
    "Tenha orgulho de cada passo, mesmo os pequenos.",
    "O medo diminui quando a gente avança.",
    "A força que você procura já está dentro de você.",
    "Você escreve o seu futuro com as decisões de hoje.",
    "Supere a si mesmo todos os dias, só isso basta.",
    "Quando o caminho apertar, lembre-se de que você nasceu para atravessar.",
    "Nada é impossível para quem não para de tentar.",
    "A superação começa quando você decide que vale a pena.",
    "Seja a pessoa que você precisaria ter ao seu lado: forte, calma e firme.",
    "Os melhores resultados vêm de quem não abandona a rotina.",
    "Você está aprendendo, evoluindo e vencendo, mesmo sem perceber.",
    "Cada recomeço é uma prova de coragem.",
    "A paciência e a persistência vencem qualquer pressa.",
    "Acredite no seu potencial: ele é maior do que as suas dúvidas.",
    "Não deixe o dia de ontem ocupar o espaço do dia de hoje.",
    "Você é feito de força, esperança e determinação.",
    "A vida recompensa quem continua tentando.",
    "Gratidão pelo que já foi vencido, coragem para o que vem.",
    "Hoje, escolha ser o herói da sua própria história.",
    "Sua energia vai até onde a sua vontade te levar.",
    "A confiança em si mesmo é o primeiro passo de toda conquista.",
    "Quem tem um propósito encontra força em qualquer circunstância.",
    "Sorria para o desafio: ele só aparece para quem consegue vencê-lo.",
    "Seu progresso é só seu, e merece ser celebrado.",
    "Você tem direito de descansar, mas nunca de desistir.",
    "Deixe a determinação falar mais alto que o cansaço.",
    "Cada dia cuidado com carinho é uma vitória para a sua vida.",
    "O sucesso é uma estrada, e você está nela.",
    "Você é resistente, você é capaz, você é suficiente.",
    "Faça hoje o que o seu eu do futuro vai agradecer.",
    "Quem insiste, conquista. Quem conquista, inspira.",
    "Acreditar em você mesmo é metade do caminho.",
    "Que a sua fé seja maior que os seus medos.",
    "Coragem para começar, persistência para continuar, orgulho para chegar.",
    "A sua trajetória de superação inspira mais gente do que você imagina.",
    "Hoje o seu melhor já é suficiente.",
    "Não espere o dia perfeito: faça deste dia o seu melhor.",
    "Siga em frente, a sua força te acompanha em cada passo.",
    "Você venceu ontem, está vencendo hoje e vai vencer amanhã.",
)

const val MAIN_LOVE_MESSAGE =
    "Nem todos os dias são iguais: existem dias bons e dias difíceis, mas você já superou tantos obstáculos e continua de pé. Cada passo conta, a sua força é maior do que qualquer desafio e você não está sozinho nessa caminhada."

const val LOVE_PHONE_DISPLAY = "+55 11 93208-9685"
const val LOVE_PHONE_TEL = "+5511932089685"
const val LOVE_WHATSAPP = "https://wa.me/5511932089685"
const val SAMU_TEL = "192"

private val Context.loveStore by preferencesDataStore(name = "gluco_love")
private val DATE_KEY = stringPreferencesKey("phrase_date")
private val INDEX_KEY = intPreferencesKey("phrase_index")

// ---- Portabilidade de dados por conta (backup completo / troca de conta) ----

suspend fun loveDumpAll(context: Context): String = PrefsJson.fromPreferences(context.loveStore.data.first()).toString()

suspend fun loveRestoreAll(context: Context, text: String) {
    val o = try { JSONObject(text) } catch (_: Exception) { return }
    context.loveStore.edit { PrefsJson.applyPreferences(it, o) }
}

suspend fun loveWipeAll(context: Context) {
    context.loveStore.edit { it.clear() }
}

/** Mesma frase o dia inteiro; no dia seguinte, a próxima da coleção. Sem rede. */
suspend fun phraseForToday(context: Context): String {
    val today = LocalDate.now().toString()
    val prefs = context.loveStore.data.first()
    val savedDate = prefs[DATE_KEY]
    val savedIndex = prefs[INDEX_KEY] ?: -1
    if (savedDate == today && savedIndex in LOVE_PHRASES.indices) return LOVE_PHRASES[savedIndex]
    val next = if (savedIndex < 0) 0 else (savedIndex + 1) % LOVE_PHRASES.size
    context.loveStore.edit {
        it[DATE_KEY] = today
        it[INDEX_KEY] = next
    }
    return LOVE_PHRASES[next]
}

/**
 * Não liga sozinho. Abre o discador com o número preenchido para a pessoa confirmar.
 * Chamada direta não foi implementada: o Android exige confirmação no discador.
 */
fun openDialer(context: Context, tel: String) {
    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$tel")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "Não foi possível abrir o discador neste aparelho.", Toast.LENGTH_LONG).show()
    }
}

/** Abre a conversa no WhatsApp, ou a página do link, sem enviar nenhuma mensagem. */
fun openWhatsApp(context: Context) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(LOVE_WHATSAPP)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "Não foi possível abrir o WhatsApp neste aparelho.", Toast.LENGTH_LONG).show()
    }
}
