package com.agon.app.notifications

import android.content.Context
import java.util.Calendar

/**
 * Central de notificações: UM lugar com as regras de todos os avisos do app.
 *  • Cada categoria tem uma chave liga/desliga.
 *  • Avisos URGENTES (lembretes de medicação, alertas de glicemia, cuidador) nunca respeitam horário de silêncio
 *    nem limite diário: só a chave da própria categoria.
 *  • Avisos NÃO urgentes (água, HbA1c, resumo semanal, Cris, backup) respeitam o horário de silêncio e um limite por dia.
 */
object NotificationCenter {
    enum class Cat(val label: String, val desc: String, val urgent: Boolean) {
        REMINDERS("Lembretes de glicose e insulina", "Os horários da aba Lembretes. Urgente: toca mesmo no horário de silêncio.", true),
        GLUCOSE_ALERTS("Alertas de glicemia", "Aviso quando a glicemia medida fica baixa ou alta. Urgente.", true),
        CAREGIVER("Aviso ao cuidador", "Sugere avisar seu contato de confiança em glicemia fora do limite. Urgente.", true),
        WATER("Água e glicose alta", "Lembra de se hidratar quando a medição vem alta.", false),
        HBA1C("Exame de HbA1c", "Lembrete da data que você escolheu para o exame.", false),
        WEEKLY("Resumo semanal", "Aviso aos domingos quando o resumo da semana está pronto.", false),
        CRIS("Cris percebeu algo", "A Cris avisa quando nota um padrão na sua rotina (no máximo 1 por dia).", false),
        BACKUP("Backup", "Avisa se o backup automático não rodou há muitos dias.", false),
    }

    private const val PREFS = "gluco_notification_center"
    private fun p(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun enabled(c: Context, cat: Cat) = p(c).getBoolean("on_${cat.name}", true)
    fun setEnabled(c: Context, cat: Cat, v: Boolean) = p(c).edit().putBoolean("on_${cat.name}", v).apply()

    fun quietOn(c: Context) = p(c).getBoolean("quiet_on", false)
    fun setQuietOn(c: Context, v: Boolean) = p(c).edit().putBoolean("quiet_on", v).apply()
    fun quietStart(c: Context) = p(c).getInt("quiet_start", 22)
    fun quietEnd(c: Context) = p(c).getInt("quiet_end", 7)
    fun setQuiet(c: Context, start: Int, end: Int) = p(c).edit().putInt("quiet_start", start).putInt("quiet_end", end).apply()

    /** Máximo de avisos NÃO urgentes por dia (0 = sem limite). */
    fun dailyCap(c: Context) = p(c).getInt("daily_cap", 3)
    fun setDailyCap(c: Context, v: Int) = p(c).edit().putInt("daily_cap", v).apply()

    private fun dayKey(now: Long): String = Calendar.getInstance().apply { timeInMillis = now }
        .let { "${it.get(Calendar.YEAR)}-${it.get(Calendar.DAY_OF_YEAR)}" }

    fun sentToday(c: Context, now: Long = System.currentTimeMillis()): Int =
        if (p(c).getString("cap_day", "") == dayKey(now)) p(c).getInt("cap_count", 0) else 0

    fun inQuietHours(c: Context, now: Long = System.currentTimeMillis()): Boolean {
        if (!quietOn(c)) return false
        val h = Calendar.getInstance().apply { timeInMillis = now }.get(Calendar.HOUR_OF_DAY)
        val s = quietStart(c); val e = quietEnd(c)
        return if (s == e) false else if (s < e) h in s until e else (h >= s || h < e)
    }

    /**
     * Pergunte antes de mostrar qualquer aviso. Retorna true se pode mostrar.
     * Para avisos não urgentes, já CONTA o aviso no limite diário.
     */
    @Synchronized
    fun allow(c: Context, cat: Cat, now: Long = System.currentTimeMillis()): Boolean {
        if (!enabled(c, cat)) return false
        if (cat.urgent) return true
        if (inQuietHours(c, now)) return false
        val cap = dailyCap(c)
        val day = dayKey(now)
        val count = if (p(c).getString("cap_day", "") == day) p(c).getInt("cap_count", 0) else 0
        if (cap > 0 && count >= cap) return false
        p(c).edit().putString("cap_day", day).putInt("cap_count", count + 1).apply()
        return true
    }
}
