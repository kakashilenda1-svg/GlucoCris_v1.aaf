package com.agon.app.reminders

import android.content.Context
import com.agon.app.data.AppData
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.Reminder
import java.util.Calendar
import kotlin.math.abs

/** Sugestão da Cris para a aba Lembretes, baseada na rotina real dos registros. Nunca mexe em nada sem o toque da pessoa. */
data class ReminderSuggestion(
    val key: String,
    val type: Type,
    val text: String,
    val kind: String,
    val title: String,
    val hour: Int,
    val minute: Int,
    val days: List<Int>,
    val reminderId: String? = null,
) { enum class Type { CREATE, MOVE, PAUSE } }

object ReminderCoach {
    private const val PREFS = "cris_reminder_coach"
    private const val DISMISS_MS = 30L * 86_400_000L
    private const val DAY = 86_400_000L

    private data class Ev(val at: Long, val min: Int, val dow: Int, val label: String, val day: Long)

    private fun p(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun dismiss(c: Context, key: String) { p(c).edit().putLong(key, System.currentTimeMillis()).apply() }

    private fun dismissed(c: Context, key: String, now: Long) = now - p(c).getLong(key, 0L) < DISMISS_MS

    private fun events(list: List<Pair<Long, String>>): List<Ev> {
        val cal = Calendar.getInstance()
        return list.map { (at, label) ->
            cal.timeInMillis = at
            Ev(at, cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE), cal.get(Calendar.DAY_OF_WEEK) - 1, label, at / DAY)
        }
    }

    /** Agrupa eventos próximos (lacuna maior que 75 min separa grupos) e devolve só grupos com hábito de verdade. */
    private fun clusters(evs: List<Ev>): List<List<Ev>> {
        val sorted = evs.sortedBy { it.min }
        val groups = mutableListOf<MutableList<Ev>>()
        for (e in sorted) {
            if (groups.isNotEmpty() && e.min - groups.last().last().min <= 75) groups.last() += e else groups += mutableListOf(e)
        }
        return groups.filter { g -> g.map { it.day }.distinct().size >= 5 }
    }

    private fun median(v: List<Int>) = v.sorted()[v.size / 2]
    private fun fmt(min: Int) = "%02d:%02d".format(min / 60, min % 60)
    private fun diff(a: Int, b: Int) = abs(a - b)

    fun suggestions(c: Context, data: AppData, now: Long = System.currentTimeMillis()): List<ReminderSuggestion> {
        return try { build(c, data, now) } catch (_: Exception) { emptyList() }
    }

    private fun build(c: Context, data: AppData, now: Long): List<ReminderSuggestion> {
        val since = now - 45 * DAY
        val out = mutableListOf<ReminderSuggestion>()
        val usedReminders = mutableSetOf<String>()

        val glu = events(data.glucose.filter { !it.id.startsWith("demo-") && it.at >= since }
            .map { it.at to (GLUCOSE_CONTEXT_LABEL[it.context] ?: it.context) })
        val ins = events(data.insulin.filter { !it.id.startsWith("demo-") && it.kind == "aplicacao" && it.at >= since }
            .map { it.at to it.name.trim() })

        for ((kind, evs) in listOf("glicose" to glu, "insulina" to ins)) {
            val mine = data.reminders.filter { it.kind == kind && it.enabled }
            for (g in clusters(evs)) {
                val center = median(g.map { it.min })
                val label = g.groupingBy { it.label }.eachCount().maxByOrNull { it.value }?.key.orEmpty()
                val dayCount = g.groupingBy { it.dow }.eachCount()
                var days = dayCount.filter { it.value >= 2 }.keys.sorted()
                if (days.size >= 6) days = (0..6).toList()
                if (days.isEmpty()) continue
                val near = mine.filter { it.id !in usedReminders }.minByOrNull { diff(it.hour * 60 + it.minute, center) }
                val d = near?.let { diff(it.hour * 60 + it.minute, center) } ?: Int.MAX_VALUE
                val title = if (kind == "glicose") "Medir glicose" + (if (label.isNotBlank()) " (${label.lowercase()})" else "")
                else "Aplicar insulina" + (if (label.isNotBlank()) " ($label)" else "")
                when {
                    d <= 30 -> { near?.let { usedReminders += it.id } }
                    near != null && d <= 90 -> {
                        usedReminders += near.id
                        val key = "move|${near.id}|${center / 30}"
                        if (!dismissed(c, key, now)) out += ReminderSuggestion(
                            key, ReminderSuggestion.Type.MOVE,
                            "Você costuma registrar por volta de ${fmt(center)}, mas o lembrete \"${near.title}\" toca às ${fmt(near.hour * 60 + near.minute)}. Mover para ${fmt(center)}?",
                            kind, near.title, center / 60, center % 60, near.days, near.id,
                        )
                    }
                    else -> {
                        val key = "new|$kind|${center / 30}"
                        if (!dismissed(c, key, now)) out += ReminderSuggestion(
                            key, ReminderSuggestion.Type.CREATE,
                            "Notei que você ${if (kind == "glicose") "mede a glicose" else "aplica insulina"} quase todo dia por volta de ${fmt(center)} e não há lembrete nesse horário. Criar um?",
                            kind, title, center / 60, center % 60, days,
                        )
                    }
                }
            }
        }

        // Lembretes que ninguém acompanha: pessoa ativa nas últimas 3 semanas, mas nada registrado perto do horário
        val recent = now - 21 * DAY
        data.reminders.filter { it.enabled && (it.kind == "glicose" || it.kind == "insulina") && it.id !in usedReminders }.forEach { r ->
            val evs = (if (r.kind == "glicose") glu else ins).filter { it.at >= recent }
            if (evs.size < 10) return@forEach
            val rMin = r.hour * 60 + r.minute
            val hits = evs.count { diff(it.min, rMin) <= 90 }
            val key = "pause|${r.id}"
            if (hits == 0 && !dismissed(c, key, now)) out += ReminderSuggestion(
                key, ReminderSuggestion.Type.PAUSE,
                "Nas últimas 3 semanas você não registrou nada perto do lembrete \"${r.title}\" (${fmt(rMin)}). Pausar esse lembrete?",
                r.kind, r.title, r.hour, r.minute, r.days, r.id,
            )
        }
        return out.take(3)
    }
}
