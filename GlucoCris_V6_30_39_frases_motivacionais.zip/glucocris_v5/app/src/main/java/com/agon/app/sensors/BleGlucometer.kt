package com.agon.app.sensors

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.BluetoothStatusCodes
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import androidx.core.content.ContextCompat
import com.agon.app.cloud.SyncMerge
import com.agon.app.data.GlucoStorage
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.GlucoseEntry
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.withTimeoutOrNull
import java.util.UUID

class BleException(message: String) : Exception(message)

data class BleDevice(val address: String, val name: String, val rssi: Int)

/** Glicosímetro Bluetooth pareado (só neste aparelho). */
object BleConfig {
    private const val PREFS = "gluco_ble_v1"
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun address(ctx: Context): String = sp(ctx).getString("address", "") ?: ""
    fun name(ctx: Context): String = sp(ctx).getString("name", "") ?: ""
    fun isPaired(ctx: Context): Boolean = address(ctx).isNotBlank()

    fun setDevice(ctx: Context, address: String, name: String) =
        sp(ctx).edit().putString("address", address).putString("name", name).apply()

    fun forget(ctx: Context) = sp(ctx).edit().remove("address").remove("name").apply()

    /** Tentar buscar as leituras sozinho quando o app abre (o aparelho precisa estar ligado e perto). */
    fun autoOnOpen(ctx: Context): Boolean = sp(ctx).getBoolean("auto_open", false)
    fun setAutoOnOpen(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("auto_open", v).apply()

    fun lastSync(ctx: Context): Long = sp(ctx).getLong("last_sync", 0L)
    fun lastMsg(ctx: Context): String = sp(ctx).getString("last_msg", "") ?: ""
    fun saveResult(ctx: Context, msg: String) =
        sp(ctx).edit().putLong("last_sync", System.currentTimeMillis()).putString("last_msg", msg).apply()
}

/**
 * Comunicação com glicosímetros pelo perfil padrão de glicose do Bluetooth LE (serviço 0x1808).
 * Funciona com aparelhos que seguem esse padrão (muitos modelos Accu-Chek, Contour, OneTouch, G-Tech, entre outros);
 * aparelhos com protocolo próprio (só usam o app do fabricante) não aparecem na busca.
 */
object BleGlucometer {
    val SERVICE_GLUCOSE: UUID = UUID.fromString("00001808-0000-1000-8000-00805f9b34fb")
    val CHAR_MEASUREMENT: UUID = UUID.fromString("00002a18-0000-1000-8000-00805f9b34fb")
    val CHAR_CONTEXT: UUID = UUID.fromString("00002a34-0000-1000-8000-00805f9b34fb")
    val CHAR_RACP: UUID = UUID.fromString("00002a52-0000-1000-8000-00805f9b34fb")
    val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    fun requiredPermissions(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    fun hasPermissions(ctx: Context): Boolean =
        requiredPermissions().all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }

    fun isSupported(ctx: Context): Boolean = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)

    private fun adapter(ctx: Context): BluetoothAdapter? =
        (ctx.applicationContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

    fun isEnabled(ctx: Context): Boolean = try { adapter(ctx)?.isEnabled == true } catch (_: SecurityException) { false }

    /** Procura glicosímetros que anunciam o serviço 0x1808 por [timeoutMs]. [onFound] roda na thread principal. */
    @SuppressLint("MissingPermission")
    suspend fun scan(ctx: Context, timeoutMs: Long = 15_000L, onFound: (BleDevice) -> Unit) {
        if (!hasPermissions(ctx)) return
        val scanner = adapter(ctx)?.takeIf { it.isEnabled }?.bluetoothLeScanner ?: return
        val seen = HashSet<String>()
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val dev = result.device ?: return
                if (!seen.add(dev.address)) return
                val name = (try { dev.name } catch (_: SecurityException) { null })
                    ?: result.scanRecord?.deviceName
                    ?: "Glicosímetro"
                onFound(BleDevice(dev.address, name, result.rssi))
            }
        }
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE_GLUCOSE)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        try {
            scanner.startScan(listOf(filter), settings, cb)
            delay(timeoutMs)
        } finally {
            try { scanner.stopScan(cb) } catch (_: Exception) { }
        }
    }

    /** Pareia (bond) com o aparelho; o sistema mostra o pedido de confirmação ou PIN. Falhar aqui não impede de tentar conectar. */
    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    suspend fun ensureBonded(ctx: Context, dev: BluetoothDevice) {
        if (dev.bondState == BluetoothDevice.BOND_BONDED) return
        val result = CompletableDeferred<Int>()
        val rx = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) {
                val d: BluetoothDevice? = if (Build.VERSION.SDK_INT >= 33) {
                    i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                } else {
                    i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                }
                if (d?.address != dev.address) return
                val st = i.getIntExtra(BluetoothDevice.EXTRA_BOND_STATE, BluetoothDevice.ERROR)
                if (st == BluetoothDevice.BOND_BONDED || st == BluetoothDevice.BOND_NONE) result.complete(st)
            }
        }
        val app = ctx.applicationContext
        ContextCompat.registerReceiver(app, rx, IntentFilter(BluetoothDevice.ACTION_BOND_STATE_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        try {
            if (!dev.createBond()) return
            withTimeoutOrNull(45_000L) { result.await() }
        } finally {
            try { app.unregisterReceiver(rx) } catch (_: Exception) { }
        }
    }

    class Download(val readings: List<BleGlucoseReading>, val ignored: Int)

    /** Conecta, pede todos os registros guardados e devolve o que chegou. Lança [BleException] com mensagem clara em caso de falha. */
    suspend fun download(ctx: Context, address: String, timeoutMs: Long = 60_000L): Download {
        val app = ctx.applicationContext
        val ad = adapter(app) ?: throw BleException("Este aparelho não tem Bluetooth.")
        if (!hasPermissions(app)) throw BleException("Falta a permissão de Bluetooth. Permita e tente de novo.")
        if (!ad.isEnabled) throw BleException("O Bluetooth está desligado. Ligue-o e tente de novo.")
        val dev = try { ad.getRemoteDevice(address) } catch (_: IllegalArgumentException) { throw BleException("Endereço do glicosímetro inválido. Pareie de novo.") }
        ensureBonded(app, dev)
        val session = Session(app, dev)
        try {
            withContext(Dispatchers.Main) { session.start() }
            try {
                withTimeout(timeoutMs) { session.done.await() }
            } catch (_: TimeoutCancellationException) {
                if (session.readings.isEmpty()) {
                    throw BleException("O glicosímetro não respondeu. Ligue-o no modo Bluetooth (transferência de dados) e deixe-o perto do celular.")
                }
            }
        } finally {
            // NonCancellable: mesmo se a tela for fechada no meio, a conexão Bluetooth precisa ser encerrada.
            withContext(NonCancellable + Dispatchers.Main) { session.close() }
        }
        val err = session.error
        if (err != null && session.readings.isEmpty()) throw BleException(err)
        return Download(session.readings.toList(), session.ignored)
    }

    /** Uma sessão GATT: liga notificações (medidas e contexto), indicações do RACP e pede "todos os registros". */
    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private class Session(val ctx: Context, val device: BluetoothDevice) {
        val done = CompletableDeferred<Unit>()
        val readings: MutableList<BleGlucoseReading> = java.util.Collections.synchronizedList(ArrayList())

        @Volatile var ignored = 0
        @Volatile var error: String? = null
        @Volatile private var finished = false
        private var gatt: BluetoothGatt? = null
        private val steps = kotlin.collections.ArrayDeque<(BluetoothGatt) -> Boolean>()
        private val main = Handler(Looper.getMainLooper())

        fun start() {
            gatt = device.connectGatt(ctx, false, callback, BluetoothDevice.TRANSPORT_LE)
            if (gatt == null) fail("Não foi possível iniciar a conexão Bluetooth.")
        }

        fun close() {
            main.removeCallbacksAndMessages(null)
            try { gatt?.disconnect() } catch (_: Exception) { }
            try { gatt?.close() } catch (_: Exception) { }
            gatt = null
        }

        private fun fail(msg: String) {
            if (error == null) error = msg
            finished = true
            if (!done.isCompleted) done.complete(Unit)
        }

        private fun succeed() {
            finished = true
            if (!done.isCompleted) done.complete(Unit)
        }

        private fun runNext(g: BluetoothGatt) {
            val step = steps.removeFirstOrNull() ?: return
            if (!step(g)) fail("Falha ao falar com o glicosímetro. Tente de novo.")
        }

        private fun enable(g: BluetoothGatt, ch: BluetoothGattCharacteristic, indicate: Boolean): Boolean {
            if (!g.setCharacteristicNotification(ch, true)) return false
            val cccd = ch.getDescriptor(CCCD) ?: return false
            val v = if (indicate) BluetoothGattDescriptor.ENABLE_INDICATION_VALUE else BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            return if (Build.VERSION.SDK_INT >= 33) {
                g.writeDescriptor(cccd, v) == BluetoothStatusCodes.SUCCESS
            } else {
                cccd.value = v
                g.writeDescriptor(cccd)
            }
        }

        private fun writeRacp(g: BluetoothGatt, ch: BluetoothGattCharacteristic): Boolean =
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, BleRacp.REPORT_ALL, BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT) == BluetoothStatusCodes.SUCCESS
            } else {
                ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                ch.value = BleRacp.REPORT_ALL
                g.writeCharacteristic(ch)
            }

        private fun onValue(uuid: UUID, value: ByteArray?) {
            if (value == null) return
            when (uuid) {
                CHAR_MEASUREMENT -> {
                    val r = BleGlucoseParser.parse(value)
                    if (r != null) readings.add(r) else ignored++
                }
                CHAR_RACP -> {
                    val resp = BleRacp.parseResponse(value) ?: return
                    if (resp.requestOp != BleRacp.OP_REPORT_STORED) return
                    if (resp.success || resp.noRecords) succeed()
                    else fail("O glicosímetro recusou a transferência (${BleRacp.resultText(resp.result)}).")
                }
            }
        }

        private val callback = object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (status != BluetoothGatt.GATT_SUCCESS) {
                    if (!finished) fail("Não consegui conectar ao glicosímetro (código $status). Ligue-o no modo Bluetooth e tente de novo.")
                    return
                }
                when (newState) {
                    BluetoothProfile.STATE_CONNECTED ->
                        // Uma pequena pausa evita falha de descoberta logo depois do pareamento.
                        main.postDelayed({ if (!finished && !g.discoverServices()) fail("Não consegui ler os serviços do glicosímetro.") }, 600L)
                    BluetoothProfile.STATE_DISCONNECTED ->
                        if (!finished) {
                            if (readings.isNotEmpty()) succeed() else fail("O glicosímetro desconectou antes de enviar as leituras.")
                        }
                }
            }

            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                if (status != BluetoothGatt.GATT_SUCCESS) { fail("Falha ao descobrir os serviços do glicosímetro."); return }
                val svc = g.getService(SERVICE_GLUCOSE)
                    ?: run { fail("Este aparelho não usa o serviço padrão de glicosímetro Bluetooth."); return }
                val meas = svc.getCharacteristic(CHAR_MEASUREMENT)
                    ?: run { fail("O glicosímetro não expõe as medições pelo perfil padrão."); return }
                val ctxChar = svc.getCharacteristic(CHAR_CONTEXT)
                val racp = svc.getCharacteristic(CHAR_RACP)
                steps.clear()
                steps.addLast { enable(it, meas, indicate = false) }
                if (ctxChar != null) steps.addLast { enable(it, ctxChar, indicate = false) }
                if (racp != null) {
                    steps.addLast { enable(it, racp, indicate = true) }
                    steps.addLast { writeRacp(it, racp) }
                } else {
                    // Sem RACP o aparelho só envia o que acabou de medir: espera alguns segundos e encerra.
                    main.postDelayed({ succeed() }, 8_000L)
                }
                runNext(g)
            }

            override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
                if (status == BluetoothGatt.GATT_SUCCESS) { runNext(g); return }
                if (status == 5 || status == 15) {
                    fail("O glicosímetro pediu pareamento. Coloque-o em modo de pareamento, confirme o pedido do Android e tente de novo.")
                } else {
                    fail("O glicosímetro não aceitou a conexão (código $status).")
                }
            }

            override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
                if (status != BluetoothGatt.GATT_SUCCESS) fail("O glicosímetro não aceitou o pedido de leituras (código $status).")
            }

            // Android 13+
            override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, value: ByteArray) {
                onValue(characteristic.uuid, value)
            }

            // Android 12 e anteriores
            @Deprecated("Usado em versões antigas do Android")
            override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
                if (Build.VERSION.SDK_INT < 33) onValue(characteristic.uuid, characteristic.value)
            }
        }
    }
}

/** Importa as leituras do glicosímetro para o histórico do app. */
object BleImporter {
    private val lock = Mutex()

    fun toEntries(
        address: String,
        deviceName: String,
        readings: List<BleGlucoseReading>,
        known: Set<String>,
        deleted: Set<String>,
        now: Long = System.currentTimeMillis(),
    ): List<GlucoseEntry> {
        val label = "Glicosímetro Bluetooth" + if (deviceName.isNotBlank()) " · $deviceName" else ""
        return BleEntryMapper.fresh(address, readings, known, deleted, now).map { (id, r) ->
            GlucoseEntry(id, Math.round(r.mg).toDouble(), "mg/dL", r.at, "outro", label, now, now)
        }
    }

    suspend fun syncOnce(ctx: Context, timeoutMs: Long = 60_000L): Result<Int> {
        val app = ctx.applicationContext
        if (!BleConfig.isPaired(app)) return Result.failure(BleException("Nenhum glicosímetro pareado."))
        if (!lock.tryLock()) return Result.failure(BleException("Já existe uma sincronização em andamento."))
        return try {
            val address = BleConfig.address(app)
            val name = BleConfig.name(app)
            val dl = BleGlucometer.download(app, address, timeoutMs)
            val live = GlucoViewModel.liveInstance()
            val added: List<GlucoseEntry>
            if (live != null) {
                val d = live.data.value
                val known = d?.glucose?.map { it.id }?.toSet() ?: emptySet()
                val deleted = d?.tombstones?.filter { it.col == SyncMerge.GLUCOSE }?.map { it.id }?.toSet() ?: emptySet()
                added = toEntries(address, name, dl.readings, known, deleted)
                withContext(Dispatchers.Main) { live.importSensorEntries(added) }
            } else {
                val d = GlucoStorage.read(app)
                val known = d?.glucose?.map { it.id }?.toSet() ?: emptySet()
                val deleted = d?.tombstones?.filter { it.col == SyncMerge.GLUCOSE }?.map { it.id }?.toSet() ?: emptySet()
                added = toEntries(address, name, dl.readings, known, deleted)
                if (d != null && added.isNotEmpty()) GlucoStorage.write(app, d.copy(glucose = (added + d.glucose).sortedByDescending { it.at }))
            }
            added.maxByOrNull { it.at }?.let {
                com.agon.app.reminders.Caregiver.onNewGlucose(app, it.value, it.at, live?.data?.value?.settings?.displayName.orEmpty())
            }
            val skipped = dl.readings.count { it.deviceFault || it.timeFault } + dl.ignored
            val msg = buildString {
                append(if (added.isNotEmpty()) "${added.size} leitura(s) nova(s) do glicosímetro." else "Tudo em dia, sem leituras novas.")
                if (skipped > 0) append(" $skipped ignorada(s) por erro do aparelho ou da tira.")
            }
            BleConfig.saveResult(app, msg)
            Result.success(added.size)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: BleException) {
            BleConfig.saveResult(app, e.message ?: "Falha ao ler o glicosímetro.")
            Result.failure(e)
        } catch (e: Exception) {
            val msg = "Falha ao ler o glicosímetro."
            BleConfig.saveResult(app, msg)
            Result.failure(BleException(msg))
        } finally {
            lock.unlock()
        }
    }
}
