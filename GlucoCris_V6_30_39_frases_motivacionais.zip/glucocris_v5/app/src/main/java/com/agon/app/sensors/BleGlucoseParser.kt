package com.agon.app.sensors

import java.util.Calendar
import java.util.TimeZone
import kotlin.math.pow

/**
 * Uma leitura vinda de um glicosímetro Bluetooth (Bluetooth SIG "Glucose Profile", serviço 0x1808).
 * [mg] já está convertido para mg/dL.
 */
data class BleGlucoseReading(
    val seq: Int,
    val at: Long,
    val mg: Double,
    /** O aparelho marcou erro de tira, amostra insuficiente, mau funcionamento etc. Não deve entrar no histórico. */
    val deviceFault: Boolean = false,
    /** O aparelho avisou que o relógio dele está errado: o horário da leitura não é confiável. */
    val timeFault: Boolean = false,
)

/**
 * Decodifica o pacote "Glucose Measurement" (característica 0x2A18). Lógica pura, sem Android, testada em JVM.
 *
 * Formato: flags(1) · sequência(2) · hora-base(7) · [deslocamento de hora(2)] · [concentração SFLOAT(2) + tipo/local(1)] · [status(2)]
 */
object BleGlucoseParser {
    const val MIN_MG = 10.0
    const val MAX_MG = 1000.0

    /** mol/L → mg/dL (massa molar da glicose: 180,156 g/mol). */
    private const val MOL_L_TO_MG_DL = 18_015.6

    /** kg/L → mg/dL. */
    private const val KG_L_TO_MG_DL = 100_000.0

    private const val FLAG_TIME_OFFSET = 0x01
    private const val FLAG_CONCENTRATION = 0x02
    private const val FLAG_UNIT_MOL = 0x04
    private const val FLAG_STATUS = 0x08

    /** Bits do "status de anunciação": mau funcionamento, amostra insuficiente, erro/tipo de tira, leitura interrompida, falha geral. */
    private const val STATUS_FAULT_MASK = 0x0002 or 0x0004 or 0x0008 or 0x0010 or 0x0200 or 0x0400
    private const val STATUS_TIME_FAULT = 0x0800

    private fun u8(d: ByteArray, i: Int) = d[i].toInt() and 0xFF
    private fun u16(d: ByteArray, i: Int) = u8(d, i) or (u8(d, i + 1) shl 8)
    private fun s16(d: ByteArray, i: Int): Int = u16(d, i).let { if (it >= 0x8000) it - 0x10000 else it }

    /** IEEE-11073 SFLOAT (16 bits). Devolve null para NaN, "sem resultado" e infinitos. */
    fun sfloat(raw: Int): Double? {
        val r = raw and 0xFFFF
        if (r == 0x07FF || r == 0x0800 || r == 0x0801 || r == 0x07FE || r == 0x0802) return null
        var mantissa = r and 0x0FFF
        if (mantissa >= 0x0800) mantissa -= 0x1000
        var exponent = r shr 12
        if (exponent >= 0x08) exponent -= 0x10
        return mantissa * 10.0.pow(exponent)
    }

    /** Valor da característica → leitura, ou null se o pacote estiver incompleto, sem glicose ou fora de uma faixa plausível. */
    fun parse(d: ByteArray, tz: TimeZone = TimeZone.getDefault()): BleGlucoseReading? {
        if (d.size < 10) return null
        val flags = u8(d, 0)
        val seq = u16(d, 1)
        val year = u16(d, 3)
        val month = u8(d, 5)
        val day = u8(d, 6)
        val hour = u8(d, 7)
        val minute = u8(d, 8)
        val second = u8(d, 9)
        if (year !in 2000..2100 || month !in 1..12 || day !in 1..31 || hour > 23 || minute > 59 || second > 59) return null
        var i = 10

        var offsetMin = 0
        if (flags and FLAG_TIME_OFFSET != 0) {
            if (d.size < i + 2) return null
            offsetMin = s16(d, i)
            i += 2
        }

        if (flags and FLAG_CONCENTRATION == 0) return null
        if (d.size < i + 3) return null
        val value = sfloat(u16(d, i)) ?: return null
        i += 3 // concentração (2) + tipo/local da amostra (1)

        var status = 0
        if (flags and FLAG_STATUS != 0 && d.size >= i + 2) status = u16(d, i)

        val mg = value * if (flags and FLAG_UNIT_MOL != 0) MOL_L_TO_MG_DL else KG_L_TO_MG_DL
        if (mg.isNaN() || mg < MIN_MG || mg > MAX_MG) return null

        val base = Calendar.getInstance(tz).apply {
            clear()
            set(year, month - 1, day, hour, minute, second)
        }.timeInMillis
        val at = base + offsetMin * 60_000L

        return BleGlucoseReading(
            seq = seq,
            at = at,
            mg = mg,
            deviceFault = status and STATUS_FAULT_MASK != 0,
            timeFault = status and STATUS_TIME_FAULT != 0,
        )
    }
}

/** Resposta do "Record Access Control Point" (0x2A52). */
data class RacpResponse(val requestOp: Int, val result: Int) {
    val success: Boolean get() = result == BleRacp.RESULT_SUCCESS
    val noRecords: Boolean get() = result == BleRacp.RESULT_NO_RECORDS
}

object BleRacp {
    const val OP_REPORT_STORED = 0x01
    const val OP_RESPONSE = 0x06
    const val RESULT_SUCCESS = 0x01
    const val RESULT_NO_RECORDS = 0x06

    /** "Reportar todos os registros guardados". Pedir tudo e remover duplicados no app é mais seguro que filtrar por sequência (o aparelho pode ser reiniciado). */
    val REPORT_ALL: ByteArray = byteArrayOf(OP_REPORT_STORED.toByte(), 0x01)

    fun parseResponse(d: ByteArray): RacpResponse? {
        if (d.size < 4) return null
        if ((d[0].toInt() and 0xFF) != OP_RESPONSE) return null
        return RacpResponse(requestOp = d[2].toInt() and 0xFF, result = d[3].toInt() and 0xFF)
    }

    fun resultText(code: Int): String = when (code) {
        0x02 -> "comando não suportado"
        0x03 -> "operador inválido"
        0x04 -> "operador não suportado"
        0x05 -> "operando inválido"
        0x06 -> "sem registros"
        0x07 -> "procedimento não concluído"
        0x08 -> "operando não suportado"
        else -> "código $code"
    }
}

/** Converte leituras do aparelho em registros do app, sem duplicar e sem ressuscitar o que a pessoa apagou. */
object BleEntryMapper {
    fun id(address: String, r: BleGlucoseReading): String =
        "ble-" + address.replace(":", "").lowercase() + "-" + r.seq + "-" + (r.at / 60_000L)

    /** @return pares (id, leitura) ainda não importados e que não estão no futuro. */
    fun fresh(
        address: String,
        readings: List<BleGlucoseReading>,
        known: Set<String>,
        deleted: Set<String>,
        now: Long,
    ): List<Pair<String, BleGlucoseReading>> =
        readings
            .asSequence()
            .filter { !it.deviceFault && !it.timeFault }
            .filter { it.at <= now + 5 * 60_000L }
            .map { id(address, it) to it }
            .filter { (id, _) -> id !in known && id !in deleted }
            .distinctBy { it.first }
            .sortedBy { it.second.at }
            .toList()
}
