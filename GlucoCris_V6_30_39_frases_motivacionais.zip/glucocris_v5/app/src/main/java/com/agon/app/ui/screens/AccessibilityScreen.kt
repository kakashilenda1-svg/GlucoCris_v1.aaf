package com.agon.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.ui.components.BackTitle
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.theme.AccessibilityPrefs
import com.agon.app.ui.theme.AppFonts
import com.agon.app.ui.theme.glucoColors

/** Ajustes de acessibilidade, todos MANUAIS: nada muda sozinho. */
@Composable
fun AccessibilityScreen(nav: NavHostController) {
    val g = glucoColors()
    val ctx = LocalContext.current
    val level = AccessibilityPrefs.level.value
    val contrast = AccessibilityPrefs.highContrast.value
    val big = AccessibilityPrefs.bigTouch.value
    val fontId = AccessibilityPrefs.fontId.value

    ScrollScreen {
        BackTitle("Acessibilidade", { nav.popBackStack() })
        Text(
            "Você escolhe aqui. Nada muda sozinho e a escolha vale só neste aparelho.",
            color = g.muted, fontSize = 13.sp,
        )

        SectionTitle("Tamanho do texto")
        GCard {
            ChipRow(AccessibilityPrefs.LABELS.mapIndexed { i, l -> i.toString() to l }, level.toString()) {
                AccessibilityPrefs.setLevel(ctx, it.toInt())
            }
            Text(
                "Soma-se ao tamanho de fonte do Android. A tela inteira se ajusta ao novo tamanho. Veja o efeito agora, neste texto de exemplo.",
                color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
            )
            Text("Glicemia 112 mg/dL · dentro da meta", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.padding(top = 8.dp))
        }

        SectionTitle("Tipo de letra")
        GCard {
            Text(
                "Vale para o app inteiro: títulos, textos e também o que você escreve. Toque para trocar.",
                color = g.muted, fontSize = 12.sp,
            )
            AppFonts.options.forEach { opt ->
                val on = opt.id == fontId
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(
                            BorderStroke(if (on) 2.dp else 1.dp, if (on) g.violet else g.line),
                            RoundedCornerShape(14.dp),
                        )
                        .clickable { AccessibilityPrefs.setFont(ctx, opt.id) }
                        .padding(horizontal = 12.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(opt.label, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp, fontFamily = opt.family)
                        Text("Glicemia 112 mg/dL · dentro da meta", color = g.ink, fontSize = 14.sp, fontFamily = opt.family)
                        Text(opt.note, color = g.muted, fontSize = 12.sp)
                    }
                    if (on) Text("✓", color = g.violet, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                }
            }
        }

        SectionTitle("Contraste e toque")
        GCard {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("Contraste alto", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Textos de apoio e linhas ficam mais escuros e fáceis de ler.", color = g.muted, fontSize = 12.sp)
                }
                Switch(checked = contrast, onCheckedChange = { AccessibilityPrefs.setHighContrast(ctx, it) })
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
                Column(Modifier.weight(1f)) {
                    Text("Botões de baixo maiores", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("A barra de abas fica mais alta, com área de toque maior.", color = g.muted, fontSize = 12.sp)
                }
                Switch(checked = big, onCheckedChange = { AccessibilityPrefs.setBigTouch(ctx, it) })
            }
        }

        PrimaryButton("Voltar ao padrão", g.muted, { AccessibilityPrefs.reset(ctx) }, Modifier.padding(top = 16.dp))
    }
}
