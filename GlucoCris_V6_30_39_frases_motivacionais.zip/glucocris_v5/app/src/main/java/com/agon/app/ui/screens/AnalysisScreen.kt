package com.agon.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.data.GlucoViewModel
import com.agon.app.insights.ReportExport
import com.agon.app.ui.components.BackTitle
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.LocalEmbedded
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Análises: Resumo da semana, Estatísticas, Padrões e Relatório numa tela só, com um botão fixo
 * para enviar os arquivos ao médico (PDF, planilha, texto) ou baixar no aparelho.
 */
@Composable
fun AnalysisScreen(vm: GlucoViewModel, nav: NavHostController, startTab: String = "resumo") {
    val g = glucoColors()
    val ctx = LocalContext.current
    val data by vm.data.collectAsStateWithLifecycle()
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(startTab) }
    var showSend by remember { mutableStateOf(false) }
    var days by remember { mutableStateOf(30) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var pendingKind by remember { mutableStateOf(ReportExport.Kind.PDF) }

    fun make(kind: ReportExport.Kind): ByteArray =
        ReportExport.bytes(ctx, data, days, kind) { buildReport(vm, days, ctx) }

    fun sendIt(kind: ReportExport.Kind) {
        if (busy) return
        busy = true; msg = ""
        scope.launch {
            try {
                val bytes = withContext(Dispatchers.Default) { make(kind) }
                ReportExport.share(ctx, bytes, kind, days, "Gluco Cris — relatório de ${data.settings.displayName}")
                showSend = false
            } catch (e: Exception) {
                msg = "Não foi possível gerar o arquivo agora."
            }
            busy = false
        }
    }

    val saveLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri: Uri? ->
        if (uri == null) { msg = "Download cancelado."; return@rememberLauncherForActivityResult }
        val kind = pendingKind
        busy = true
        scope.launch {
            try {
                withContext(Dispatchers.IO) {
                    val bytes = make(kind)
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) } ?: error("sem acesso ao arquivo")
                }
                msg = "Arquivo salvo no aparelho."
                showSend = false
            } catch (e: Exception) {
                msg = "Não foi possível salvar o arquivo."
            }
            busy = false
        }
    }

    fun download(kind: ReportExport.Kind) {
        pendingKind = kind
        saveLauncher.launch(ReportExport.fileName(kind, days))
    }

    Column(Modifier.fillMaxSize()) {
        Box(Modifier.padding(start = 16.dp, end = 16.dp, top = 12.dp)) { BackTitle("Análises", { nav.popBackStack() }) }
        Box(Modifier.padding(horizontal = 16.dp)) {
            ChipRow(
                listOf("resumo" to "Semana", "stats" to "Estatísticas", "padroes" to "Padrões", "relatorio" to "Relatório"),
                tab,
            ) { tab = it }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            CompositionLocalProvider(LocalEmbedded provides true) {
                when (tab) {
                    "stats" -> StatsScreen(vm, nav)
                    "padroes" -> PatternsScreen(vm, nav)
                    "relatorio" -> MedicalReportScreen(vm, nav)
                    else -> WeeklySummaryScreen(vm, nav)
                }
            }
        }
        Box(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
            PrimaryButton("📤  Enviar ao médico / Baixar", g.violet, { showSend = true; msg = "" })
        }
    }

    if (showSend) {
        AlertDialog(
            onDismissRequest = { if (!busy) showSend = false },
            title = { Text("Enviar ao médico ou baixar") },
            text = {
                Column {
                    Text("Período do relatório", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    ChipRow(listOf("7" to "7 dias", "14" to "14 dias", "30" to "30 dias", "90" to "90 dias"), days.toString()) { days = it.toInt() }
                    Text("Enviar (WhatsApp, e-mail…)", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                    ReportExport.Kind.values().forEach { k ->
                        TextButton(onClick = { sendIt(k) }, enabled = !busy) { Text("📨 ${k.label}") }
                    }
                    Text("Baixar no aparelho", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                    ReportExport.Kind.values().forEach { k ->
                        TextButton(onClick = { download(k) }, enabled = !busy) { Text("⬇️ ${k.label}") }
                    }
                    if (busy) Text("Gerando…", color = g.violet, fontSize = 13.sp)
                    if (msg.isNotBlank()) Text(msg, color = g.red, fontSize = 13.sp)
                    Text(
                        "Registros de exemplo ficam de fora. O relatório não calcula nem indica dose de insulina.",
                        color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp),
                    )
                }
            },
            confirmButton = { TextButton(onClick = { showSend = false }, enabled = !busy) { Text("Fechar") } },
        )
    }
}
