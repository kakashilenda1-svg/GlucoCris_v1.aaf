package com.agon.app.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.agon.app.cloud.CloudBackup
import com.agon.app.cloud.LocalEncryptedBackup
import com.agon.app.data.AppData
import com.agon.app.data.GlucoViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.*

/**
 * Configurações → Backup e recuperação (V6.2).
 * Sem estado global: o AppData decodificado fica só no estado da composição.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BackupRecoveryScreen(vm: GlucoViewModel, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val data by vm.data.collectAsStateWithLifecycle()
    var password by remember { mutableStateOf("") }
    var password2 by remember { mutableStateOf("") }
    var showPassword by remember { mutableStateOf(false) }
    var statusMsg by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var plan by remember { mutableStateOf<LocalEncryptedBackup.RestorePlan?>(null) }
    var pendingBytes by remember { mutableStateOf<ByteArray?>(null) }
    var pendingRestore by remember { mutableStateOf<AppData?>(null) }
    var cloudNote by remember { mutableStateOf("Consultando…") }

    fun clearSensitive() {
        password = ""
        password2 = ""
        pendingBytes = null
        pendingRestore = null
        plan = null
    }

    LaunchedEffect(Unit) {
        cloudNote = try {
            val st = CloudBackup(ctx).initialStatus()
            val last = if (st.lastSyncAt > 0L) {
                SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date(st.lastSyncAt))
            } else "nunca"
            "${st.state}: ${st.message.ifBlank { "—" }} · última sincronização: $last"
        } catch (_: Exception) {
            "Não foi possível consultar o status da nuvem."
        }
    }

    val createDoc = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/octet-stream"),
    ) { uri: Uri? ->
        if (uri == null) {
            statusMsg = "Exportação cancelada."
            pendingBytes = null
            return@rememberLauncherForActivityResult
        }
        val bytes = pendingBytes
        if (bytes == null) {
            statusMsg = "Nenhum backup gerado."
            return@rememberLauncherForActivityResult
        }
        scope.launch {
            busy = true
            try {
                withContext(Dispatchers.IO) {
                    ctx.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        ?: error("Não foi possível gravar o arquivo")
                }
                statusMsg = "Backup exportado com sucesso."
            } catch (e: Exception) {
                statusMsg = "Falha ao salvar: ${(e.message ?: "erro").take(80)}"
            } finally {
                pendingBytes = null
                password = ""
                password2 = ""
                busy = false
            }
        }
    }

    val openDoc = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument(),
    ) { uri: Uri? ->
        if (uri == null) {
            statusMsg = "Seleção cancelada."
            return@rememberLauncherForActivityResult
        }
        scope.launch {
            busy = true
            statusMsg = null
            plan = null
            pendingRestore = null
            try {
                val bytes = withContext(Dispatchers.IO) {
                    ctx.contentResolver.openInputStream(uri)?.use { input ->
                        val limited = ByteArrayOutputStreamLimited(LocalEncryptedBackup.MAX_CIPHER_BYTES)
                        val buf = ByteArray(8192)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            if (!limited.write(buf, 0, n)) {
                                error("Arquivo de backup muito grande (máximo ${LocalEncryptedBackup.MAX_CIPHER_BYTES / (1024 * 1024)} MB).")
                            }
                        }
                        limited.toByteArray()
                    } ?: error("Não foi possível ler o arquivo")
                }
                val pwd = password.toCharArray()
                val (dataIn, msg) = LocalEncryptedBackup.decrypt(bytes, pwd)
                pwd.fill('\u0000')
                if (dataIn == null) {
                    statusMsg = msg
                    return@launch
                }
                plan = LocalEncryptedBackup.planRestore(data, dataIn)
                pendingRestore = dataIn
                statusMsg = "Arquivo válido. Revise a prévia e confirme a restauração."
            } catch (e: Exception) {
                statusMsg = "Falha ao ler backup: ${(e.message ?: "erro").take(100)}"
            } finally {
                busy = false
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Backup e recuperação") },
                navigationIcon = { TextButton(onClick = onBack) { Text("←") } },
            )
        },
    ) { padding ->
        Column(
            Modifier.padding(padding).padding(16.dp).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // ---- Backup automático (pasta + senha, uma vez só)
            var autoOn by remember { mutableStateOf(com.agon.app.cloud.AutoBackup.enabled(ctx)) }
            var autoMsg by remember { mutableStateOf(com.agon.app.cloud.AutoBackup.lastMessage(ctx)) }
            var autoPw by remember { mutableStateOf("") }
            var autoPw2 by remember { mutableStateOf("") }
            var pickedTree by remember { mutableStateOf<Uri?>(null) }
            val pickFolder = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
                if (uri != null) pickedTree = uri
            }
            Text("Backup automático", fontWeight = FontWeight.Bold)
            if (autoOn) {
                val days = com.agon.app.cloud.AutoBackup.daysSinceOk(ctx)
                Text(
                    "Ligado · pasta: ${com.agon.app.cloud.AutoBackup.folderLabel(ctx)} · último backup: " +
                        (when (days) { null -> "ainda não rodou"; 0 -> "hoje"; 1 -> "ontem"; else -> "há $days dias" }),
                    style = MaterialTheme.typography.bodySmall,
                )
                if (autoMsg.isNotBlank()) Text(autoMsg, style = MaterialTheme.typography.bodySmall)
                Button(
                    onClick = {
                        if (busy) return@Button
                        scope.launch {
                            busy = true
                            val r = com.agon.app.cloud.AutoBackup.runNow(ctx, data)
                            autoMsg = r.message
                            busy = false
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Fazer backup agora") }
                TextButton(onClick = { com.agon.app.cloud.AutoBackup.disable(ctx); autoOn = false; autoMsg = "" }) { Text("Desligar backup automático") }
            } else {
                Text(
                    "A cada dia o app salva sozinho um arquivo criptografado numa pasta que você escolher (Google Drive, Downloads, cartão). " +
                        "Guarda os 7 mais recentes. Anote a senha: sem ela o backup não abre e não há como recuperar.",
                    style = MaterialTheme.typography.bodySmall,
                )
                OutlinedButton(onClick = { pickFolder.launch(null) }, modifier = Modifier.fillMaxWidth()) {
                    Text(if (pickedTree == null) "1. Escolher a pasta" else "Pasta escolhida ✓ (toque para trocar)")
                }
                OutlinedTextField(
                    value = autoPw, onValueChange = { autoPw = it }, label = { Text("2. Senha do backup automático") },
                    singleLine = true, visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth(),
                )
                OutlinedTextField(
                    value = autoPw2, onValueChange = { autoPw2 = it }, label = { Text("Confirmar senha") },
                    singleLine = true, visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth(),
                )
                Button(
                    onClick = {
                        val t = pickedTree
                        when {
                            t == null -> autoMsg = "Escolha a pasta primeiro."
                            autoPw.length < 6 -> autoMsg = "Use uma senha de pelo menos 6 caracteres."
                            autoPw != autoPw2 -> autoMsg = "As senhas não coincidem."
                            else -> scope.launch {
                                busy = true
                                try {
                                    com.agon.app.cloud.AutoBackup.enable(ctx, t, autoPw)
                                    autoOn = true
                                    val r = com.agon.app.cloud.AutoBackup.runNow(ctx, data)
                                    autoMsg = r.message
                                    autoPw = ""; autoPw2 = ""
                                } catch (e: Exception) {
                                    autoMsg = "Não foi possível ligar: ${(e.message ?: "erro").take(80)}"
                                }
                                busy = false
                            }
                        }
                    },
                    enabled = !busy,
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("3. Ligar backup automático") }
                if (autoMsg.isNotBlank()) Text(autoMsg, style = MaterialTheme.typography.bodySmall)
            }
            HorizontalDivider()
            Text("Backup na nuvem (Firebase)", fontWeight = FontWeight.Bold)
            Text(cloudNote, style = MaterialTheme.typography.bodySmall)
            Text(
                "O backup na nuvem usa a conta já configurada. Nada é apagado localmente em caso de falha de sincronização.",
                style = MaterialTheme.typography.bodySmall,
            )
            HorizontalDivider()
            Text("Backup local protegido por senha", fontWeight = FontWeight.Bold)
            Text(
                "Exporte um arquivo criptografado (AES-256-GCM) para guardar fora do aparelho ou restaurar em outro celular. " +
                    "A senha não fica no arquivo. A biometria do aparelho não é transferida.",
                style = MaterialTheme.typography.bodySmall,
            )
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text("Senha do backup") },
                singleLine = true,
                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                trailingIcon = {
                    TextButton(onClick = { showPassword = !showPassword }) {
                        Text(if (showPassword) "Ocultar" else "Mostrar")
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = password2,
                onValueChange = { password2 = it },
                label = { Text("Confirmar senha (só na exportação)") },
                singleLine = true,
                visualTransformation = if (showPassword) VisualTransformation.None else PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                modifier = Modifier.fillMaxWidth(),
            )
            Button(
                onClick = {
                    if (busy) return@Button
                    if (password.isBlank()) { statusMsg = "Informe uma senha."; return@Button }
                    if (password != password2) { statusMsg = "As senhas não coincidem."; return@Button }
                    scope.launch {
                        busy = true
                        statusMsg = "Gerando backup…"
                        val pwd = password.toCharArray()
                        val res = LocalEncryptedBackup.export(data, pwd)
                        pwd.fill('\u0000')
                        if (!res.ok || res.bytes == null) {
                            statusMsg = res.message
                            busy = false
                            return@launch
                        }
                        pendingBytes = res.bytes
                        val name = "glucocris-backup-" + SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date()) + ".gcbackup"
                        createDoc.launch(name)
                        busy = false
                    }
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Exportar backup completo") }
            Button(
                onClick = {
                    if (busy) return@Button
                    if (password.isBlank()) { statusMsg = "Informe a senha do arquivo para restaurar."; return@Button }
                    openDoc.launch(arrayOf("application/octet-stream", "*/*"))
                },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("Selecionar arquivo para restaurar") }
            plan?.let { p ->
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Prévia do backup", fontWeight = FontWeight.SemiBold)
                        Text("Glicemia: ${p.preview.glucoseCount} · Insulina: ${p.preview.insulinCount}")
                        Text("Refeições: ${p.preview.mealsCount} · Medicamentos: ${p.preview.medsCount}")
                        Text("Lembretes: ${p.preview.remindersCount} · Sintomas: ${p.preview.symptomsCount} · Exames HbA1c: ${p.preview.hba1cCount}")
                        Text(p.summary)
                        Button(
                            onClick = {
                                val incoming = pendingRestore ?: return@Button
                                scope.launch {
                                    busy = true
                                    try {
                                        // Snapshot atual antes de aplicar (recuperação em falha)
                                        val before = data
                                        val merged = LocalEncryptedBackup.merge(before, incoming)
                                        vm.replaceAllData(merged)
                                        statusMsg = "Restauração concluída. Adicionados ${p.toAdd}, atualizados ${p.toUpdate}, ignorados ${p.toSkip}."
                                        clearSensitive()
                                    } catch (e: Exception) {
                                        statusMsg = "Falha na restauração: ${(e.message ?: "erro").take(80)}. Dados atuais preservados."
                                    } finally {
                                        busy = false
                                    }
                                }
                            },
                            enabled = !busy && pendingRestore != null,
                            modifier = Modifier.fillMaxWidth(),
                        ) { Text("Confirmar restauração") }
                        TextButton(onClick = {
                            clearSensitive()
                            statusMsg = "Restauração cancelada. Nenhum dado foi alterado."
                        }) { Text("Cancelar") }
                    }
                }
            }
            statusMsg?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        }
    }
}

/** Acumulador com teto de bytes (protege leitura de arquivos enormes). */
private class ByteArrayOutputStreamLimited(private val max: Int) {
    private val bos = java.io.ByteArrayOutputStream()
    private var total = 0
    fun write(buf: ByteArray, off: Int, len: Int): Boolean {
        if (total + len > max) return false
        bos.write(buf, off, len)
        total += len
        return true
    }
    fun toByteArray(): ByteArray = bos.toByteArray()
}
