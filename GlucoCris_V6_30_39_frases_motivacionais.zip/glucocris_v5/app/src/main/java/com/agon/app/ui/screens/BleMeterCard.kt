package com.agon.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.formatDateTime
import com.agon.app.sensors.BleConfig
import com.agon.app.sensors.BleDevice
import com.agon.app.sensors.BleGlucometer
import com.agon.app.sensors.BleImporter
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/** Cartão "Glicosímetro Bluetooth" da tela Sensores: procurar, parear e sincronizar as medições guardadas no aparelho. */
@Composable
fun BleMeterCard() {
    val g = glucoColors()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()

    var paired by remember { mutableStateOf(BleConfig.isPaired(ctx)) }
    var name by remember { mutableStateOf(BleConfig.name(ctx)) }
    var autoOpen by remember { mutableStateOf(BleConfig.autoOnOpen(ctx)) }
    var scanning by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf(BleConfig.lastMsg(ctx)) }
    var lastSync by remember { mutableStateOf(BleConfig.lastSync(ctx)) }
    var scanJob by remember { mutableStateOf<Job?>(null) }
    val found = remember { mutableStateListOf<BleDevice>() }

    DisposableEffect(Unit) { onDispose { scanJob?.cancel() } }

    fun startScan() {
        if (!BleGlucometer.isEnabled(ctx)) {
            msg = "Ligue o Bluetooth do celular e tente de novo."
            return
        }
        found.clear()
        scanning = true
        msg = ""
        scanJob = scope.launch {
            try {
                BleGlucometer.scan(ctx) { d -> if (found.none { it.address == d.address }) found.add(d) }
            } finally {
                scanning = false
            }
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.isNotEmpty() && res.values.all { it }) startScan()
        else msg = "Sem a permissão de Bluetooth não consigo procurar o glicosímetro."
    }

    fun requestAndScan() {
        if (!BleGlucometer.isSupported(ctx)) { msg = "Este celular não tem Bluetooth de baixa energia."; return }
        if (BleGlucometer.hasPermissions(ctx)) startScan() else permLauncher.launch(BleGlucometer.requiredPermissions())
    }

    fun syncNow() {
        if (busy) return
        if (!BleGlucometer.hasPermissions(ctx)) { permLauncher.launch(BleGlucometer.requiredPermissions()); return }
        busy = true
        msg = "Conectando ao glicosímetro…"
        scope.launch {
            BleImporter.syncOnce(ctx)
            msg = BleConfig.lastMsg(ctx)
            lastSync = BleConfig.lastSync(ctx)
            busy = false
        }
    }

    fun pair(d: BleDevice) {
        scanJob?.cancel()
        scanning = false
        BleConfig.setDevice(ctx, d.address, d.name)
        paired = true
        name = d.name
        found.clear()
        syncNow()
    }

    GCard(Modifier.padding(top = 8.dp)) {
        Text("Glicosímetro Bluetooth", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text(
            "Traz para o app as medições guardadas no seu glicosímetro, sem digitar. Funciona com aparelhos que usam o perfil padrão de glicose do Bluetooth.",
            color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp),
        )

        if (paired) {
            Text(name.ifBlank { "Glicosímetro pareado" }, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.padding(top = 10.dp))
            if (lastSync > 0L) Text("Última sincronização: ${formatDateTime(lastSync)}", color = g.muted, fontSize = 12.sp)
            PrimaryButton(if (busy) "Sincronizando…" else "Sincronizar agora", g.violet, { syncNow() }, Modifier.padding(top = 8.dp))
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Tentar ao abrir o app", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("Com o glicosímetro ligado no modo Bluetooth e por perto.", color = g.muted, fontSize = 12.sp)
                }
                Switch(checked = autoOpen, onCheckedChange = { autoOpen = it; BleConfig.setAutoOnOpen(ctx, it) })
            }
            Text(
                "Trocar de glicosímetro",
                color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.padding(top = 8.dp).clickable { requestAndScan() },
            )
            Text(
                "Esquecer este glicosímetro",
                color = g.red, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.padding(top = 6.dp).clickable {
                    BleConfig.forget(ctx); BleConfig.setAutoOnOpen(ctx, false)
                    paired = false; autoOpen = false; name = ""; msg = ""
                },
            )
        } else {
            PrimaryButton(if (scanning) "Procurando…" else "Procurar glicosímetro", g.violet, { if (!scanning) requestAndScan() }, Modifier.padding(top = 10.dp))
            if (!scanning && found.isEmpty()) {
                Text(
                    "Antes de procurar, ligue o glicosímetro no modo Bluetooth (veja no manual do aparelho; em geral é segurar um botão até piscar o símbolo do Bluetooth).",
                    color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
                )
            }
        }

        if (found.isNotEmpty()) {
            Text("Encontrados (toque para parear)", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
            found.forEach { d ->
                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(12.dp)).background(g.inputBg)
                        .clickable { pair(d) }.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(d.name, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(d.address, color = g.muted, fontSize = 11.sp)
                    }
                    Text("Parear", color = g.violet, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                }
            }
        }

        if (msg.isNotBlank()) Text(msg, color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        Text(
            "As leituras chegam marcadas como \"glicosímetro\" e valem para painel, relatório e estimativa de HbA1c. Medições com erro de tira ou relógio errado do aparelho são ignoradas.",
            color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp),
        )
    }
}
