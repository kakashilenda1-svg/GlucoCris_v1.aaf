package com.agon.app.ui.screens

import android.content.Context
import com.agon.app.BuildConfig
import java.net.HttpURLConnection
import java.net.URL
import java.util.UUID
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import org.json.JSONObject

/** Registro do produto no catálogo Gluco (nuvem). */
data class CatalogRecord(
    val sig: String,
    val serving: String,
    val servingG: Double,
    val edited: Boolean,
    val version: Int,
)

/**
 * Catálogo Gluco: todo produto que o usuário ABRE para ver entra no catálogo (Cloudflare D1, rota /catalog do proxy),
 * com assinatura única "GLC-…" calculada no servidor. Se a porção for alterada (nome da porção + peso dela), o catálogo
 * ganha uma nova versão (histórico guardado). Nada aqui lança exceção nem trava a tela: sem internet ou sem o banco
 * ligado no Cloudflare, simplesmente não registra.
 *
 * Privacidade: só dados do PRODUTO são enviados. "Meus alimentos", alimentos estimados por IA e o histórico de busca de
 * cada pessoa nunca saem do aparelho. A edição leva só um id anônimo do aparelho (para auditoria).
 */
object CatalogSync {
    private const val PREFS = "gluco_catalog"

    /** Fontes aceitas no catálogo (o servidor confere de novo). */
    private val SOURCES = setOf(
        "off", "usda", "taco", "foodbase", "fatsecret", "local", "restaurant_official", "restaurant_estimate",
    )

    // Escopo próprio: o registro termina mesmo que o usuário saia da tela logo depois de abrir o produto.
    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private fun call(body: JSONObject): JSONObject? {
        val base = BuildConfig.TAVILY_PROXY_URL.trim().trimEnd('/')
        if (base.isBlank()) return null
        return try {
            val c = (URL("$base/catalog").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                doOutput = true
                connectTimeout = 3000
                readTimeout = 6000
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept", "application/json")
                setRequestProperty("User-Agent", "GlucoCris (Android; catalog)")
                val tok = BuildConfig.TAVILY_APP_TOKEN.trim()
                if (tok.isNotBlank()) setRequestProperty("X-App-Token", tok)
            }
            c.outputStream.use { out -> out.write(body.toString().toByteArray(Charsets.UTF_8)) }
            if (c.responseCode != 200) null else JSONObject(c.inputStream.bufferedReader().readText())
        } catch (_: Exception) {
            null
        }
    }

    fun accepts(f: FoodItem): Boolean =
        f.sourceKey in SOURCES && f.reliability != "verificar" && f.name.isNotBlank()

    /** Código de barras do produto: "bc-789…" (leitura) ou "fb-<id>~789…" (FoodBase). Vazio se não houver. */
    private fun barcodeOf(f: FoodItem): String {
        val raw = when {
            f.id.startsWith("bc-") -> f.id.removePrefix("bc-")
            f.id.contains("~") -> f.id.substringAfter("~")
            else -> ""
        }
        val digits = raw.filter { ch -> ch.isDigit() }
        return if (digits.length in 8..14) digits else ""
    }

    private fun sourceIdOf(f: FoodItem): String = f.id.substringBefore("~")

    /** O app guarda valores por porção; o catálogo guarda sempre por 100 g. Zero de nutriente opcional = desconhecido. */
    private fun per100Json(f: FoodItem): JSONObject {
        val k = if (f.servingGrams > 0.0) 100.0 / f.servingGrams else 1.0
        val kcal = if (f.kcal > 0.0) f.kcal else f.kj / 4.184
        val o = JSONObject()
            .put("kcal", kcal * k)
            .put("carbs", f.carbs * k)
            .put("protein", f.protein * k)
            .put("fat", f.fat * k)
        if (f.fiber > 0.0) o.put("fiber", f.fiber * k)
        if (f.sugars > 0.0) o.put("sugars", f.sugars * k)
        if (f.satFat > 0.0) o.put("satFat", f.satFat * k)
        if (f.sodium > 0.0) o.put("sodiumMg", f.sodium * k)
        return o
    }

    private fun recordOf(j: JSONObject?): CatalogRecord? {
        val r = j?.optJSONObject("record") ?: return null
        val sig = r.optString("sig", "")
        if (sig.isBlank()) return null
        return CatalogRecord(
            sig = sig,
            serving = r.optString("serving", ""),
            servingG = r.optDouble("servingG", 0.0),
            edited = r.optBoolean("edited", false),
            version = r.optInt("version", 1),
        )
    }

    private fun upsertBlocking(ctx: Context, f: FoodItem): CatalogRecord? {
        if (!accepts(f)) return null
        return try {
            val food = JSONObject()
                .put("name", f.name)
                .put("brand", f.brand)
                .put("category", f.category)
                .put("serving", f.serving)
                .put("servingG", f.servingGrams)
                .put("barcode", barcodeOf(f))
                .put("sourceKey", f.sourceKey)
                .put("sourceId", sourceIdOf(f))
                .put("per100", per100Json(f))
            val rec = recordOf(call(JSONObject().put("op", "upsert").put("food", food)))
            if (rec != null) {
                ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("sig_" + f.id, rec.sig).apply()
            }
            rec
        } catch (_: Exception) {
            null
        }
    }

    private fun editBlocking(ctx: Context, f: FoodItem, label: String, grams: Double) {
        try {
            val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            var sig = sp.getString("sig_" + f.id, null)
            if (sig == null) sig = upsertBlocking(ctx, f)?.sig
            if (sig == null) return
            var dev = sp.getString("device", null)
            if (dev == null) {
                dev = UUID.randomUUID().toString()
                sp.edit().putString("device", dev).apply()
            }
            call(
                JSONObject().put("op", "edit").put("sig", sig).put("serving", label)
                    .put("servingG", grams).put("device", dev),
            )
        } catch (_: Exception) {
        }
    }

    /** Registra o produto aberto (ou só conta a visita) e devolve o registro do catálogo, com a última porção editada. */
    fun upsertAsync(ctx: Context, f: FoodItem): Deferred<CatalogRecord?> {
        val app = ctx.applicationContext
        return appScope.async { upsertBlocking(app, f) }
    }

    /** Atualiza a porção do produto no catálogo ("1 colher de sopa" = 18 g). Nova versão; a anterior fica no histórico. */
    fun editServingAsync(ctx: Context, f: FoodItem, label: String, grams: Double) {
        val app = ctx.applicationContext
        appScope.launch { editBlocking(app, f, label, grams) }
    }
}
