package com.agon.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.selection.selectable
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.CrisPrefs
import com.agon.app.localai.CrisConnectivityManager
import com.agon.app.localai.CrisFact
import com.agon.app.localai.CrisConversationStore
import com.agon.app.localai.CrisWebSearch
import com.agon.app.localai.EngineState
import com.agon.app.localai.LocalAiEngine
import com.agon.app.localai.LocalAiSettings
import com.agon.app.localai.LocalMemoryManager
import com.agon.app.localai.LocalModelManager
import com.agon.app.localai.LocalModels
import com.agon.app.localai.ModelAdvisor
import com.agon.app.ui.components.tourTarget
import java.io.File
import com.agon.app.localai.LocalSpeech
import com.agon.app.localai.ModelState
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.launch

/** Configurações da IA local: modelo (download/pausa/retomada/apagar), privacidade, memória e voz. */
@Composable
fun CrisLocalAiScreen(nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val mgr = remember { LocalModelManager.get(context) }
    val engine = remember { LocalAiEngine.get(context) }
    val state by mgr.state.collectAsState()
    val engineState by engine.state.collectAsState()
    val online by remember { CrisConnectivityManager.observe(context) }
        .collectAsState(initial = CrisConnectivityManager.isOnline(context))

    var enabled by remember { mutableStateOf(LocalAiSettings.enabled(context)) }
    var aiMode by remember { mutableStateOf(LocalAiSettings.mode(context)) }
    var cloudVoice by remember { mutableStateOf(LocalAiSettings.cloudVoiceAllowed(context)) }
    var onlineHealth by remember { mutableStateOf(LocalAiSettings.onlineHealthContextAllowed(context)) }
    var webSearch by remember { mutableStateOf(LocalAiSettings.webSearchEnabled(context)) }
    var webTesting by remember { mutableStateOf(false) }
    var webTestResult by remember { mutableStateOf<String?>(null) }
    var facts by remember { mutableStateOf(LocalMemoryManager.load(context)) }
    var confirmModelAction by remember { mutableStateOf<String?>(null) }   // "delete" | "reinstall"
    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<CrisFact?>(null) }
    var adding by remember { mutableStateOf(false) }
    var confirmClearAll by remember { mutableStateOf(false) }
    var historyCleared by remember { mutableStateOf(false) }
    var showAdvanced by remember { mutableStateOf(false) }
    var wasVerifying by remember { mutableStateOf(false) }

    fun runTest() {
        if (testing) return
        testing = true
        testResult = null
        scope.launch {
            testResult = try {
                "Funcionou. Resposta do modelo: " + engine.selfTest().trim().take(200)
            } catch (e: Exception) {
                "Falhou: ${e.message ?: "erro desconhecido"}"
            }
            testing = false
        }
    }

    LaunchedEffect(Unit) { mgr.refresh() }
    LaunchedEffect(state) {
        if (state is ModelState.Verifying) wasVerifying = true
        if (state is ModelState.Ready && wasVerifying) { wasVerifying = false; runTest() }
    }

    @Composable
    fun Card(content: @Composable () -> Unit) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(g.card).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) { content() }
    }

    Column(Modifier.fillMaxSize().background(g.bg)) {
        Row(Modifier.fillMaxWidth().background(g.card).padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = g.ink) }
            Text("IA da Cris", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // ---- Modelo
            item {
                Card {
                    Text("Modelo no aparelho", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.tourTarget("cris_model"))
                    val active = remember(state) { mgr.activeSpec }
                    if (active != null) {
                        Text(active.tierName + " · " + active.displayName.substringAfter("·").trim(), color = g.ink, fontSize = 14.sp)
                        Text(
                            "Tamanho: ${LocalModelManager.fmtBytes(active.sizeBytes)} · Licença: ${active.license} · Versão do modelo: ${mgr.installedVersion(active)}",
                            color = g.muted, fontSize = 12.sp,
                        )
                    } else {
                        Text("Nenhuma IA local instalada. A Cris usa as respostas básicas offline e, se houver internet, os serviços online.", color = g.ink, fontSize = 13.sp)
                    }
                    val advice = remember { ModelAdvisor.advise(context) }
                    Text(
                        "Recomendado para este aparelho: " + advice.recommended.tierName + ". " + advice.reason,
                        color = g.violet, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
                    )
                    advice.warnings.forEach { Text("⚠️ $it", color = g.red, fontSize = 12.sp) }
                    Text("Espaço livre: ${LocalModelManager.fmtBytes(mgr.freeBytes())}", color = g.muted, fontSize = 12.sp)
                    Text("Conexão: " + if (online) "online" else "offline", color = g.muted, fontSize = 12.sp)

                    // Andamento do download (WorkManager): progresso, pausar, continuar, tentar de novo, cancelar
                    ModelDownloadStatusBlock()

                    Button(onClick = { nav.navigate(Routes.CRIS_MODEL_CHOOSER) }) {
                        Text(if (active != null) "Trocar modelo" else "Escolher e instalar modelo")
                    }
                    Text(
                        "O modelo atual só é removido depois que o novo for baixado, conferido e instalado.",
                        color = g.muted, fontSize = 11.sp,
                    )

                    if (active != null && state is ModelState.Ready) {
                        Text(
                            when (val e = engineState) {
                                EngineState.Unloaded -> "Instalado e verificado. Carrega na memória só quando você conversa."
                                EngineState.Loading -> "Carregando na memória…"
                                is EngineState.Loaded -> "Carregado (${e.backend}${if (e.vision) ", com visão" else ", só texto"})."
                                is EngineState.Error -> "Instalado, mas não iniciou: ${e.message}"
                            },
                            color = g.ink, fontSize = 13.sp,
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { runTest() }, enabled = !testing) { Text(if (testing) "Testando…" else "Testar") }
                            OutlinedButton(onClick = { engine.unload() }) { Text("Liberar memória") }
                        }
                        testResult?.let { Text(it, color = g.ink, fontSize = 12.sp) }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(onClick = { confirmModelAction = "delete" }) { Text("Apagar modelo") }
                            OutlinedButton(onClick = { confirmModelAction = "reinstall" }) { Text("Reinstalar") }
                        }
                    }
                }
            }

            // ---- Preferências e privacidade
            item {
                Card {
                    Text("Privacidade", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Como a Cris usa a IA do aparelho", color = g.ink, fontSize = 14.sp)
                    if (!LocalModelManager.get(context).isInstalled()) {
                        Text("A IA local ainda não está instalada: instale para valer a escolha abaixo. Até lá, a Cris usa a internet.", color = g.muted, fontSize = 12.sp)
                    }
                    listOf(
                        Triple(LocalAiSettings.MODE_AUTO, "Automático (recomendado)", "A Cris decide sozinha: assuntos pessoais e de saúde ficam no aparelho; notícias e fatos de hoje vão à internet; sem internet ou sem cota online, o aparelho assume."),
                        Triple(LocalAiSettings.MODE_LOCAL, "Aparelho primeiro", "Responde no aparelho sempre que não precisar de informação de hoje. Mais privado e não gasta cota online; pode ser mais lento."),
                        Triple(LocalAiSettings.MODE_OFF, "Só online", "Não usa a IA do aparelho."),
                    ).forEach { (id, title, desc) ->
                        Row(
                            Modifier.fillMaxWidth().selectable(
                                selected = aiMode == id, role = Role.RadioButton,
                                onClick = { aiMode = id; enabled = id != LocalAiSettings.MODE_OFF; LocalAiSettings.setMode(context, id) },
                            ),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            RadioButton(selected = aiMode == id, onClick = null)
                            Column(Modifier.weight(1f).padding(start = 8.dp, top = 4.dp, bottom = 4.dp)) {
                                Text(title, color = g.ink, fontSize = 14.sp)
                                Text(desc, color = g.muted, fontSize = 12.sp)
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Enviar resumo de saúde a serviços online", color = g.ink, fontSize = 14.sp)
                            Text("Glicemias, insulina e refeições só vão a Gemini/servidor se você ligar isto. Desligado por padrão.", color = g.muted, fontSize = 12.sp)
                        }
                        Switch(checked = onlineHealth, onCheckedChange = { onlineHealth = it; LocalAiSettings.setOnlineHealthContextAllowed(context, it) })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Voz natural online", color = g.ink, fontSize = 14.sp)
                            Text("Envia o texto das respostas ao servidor de voz. Desligado: usa a voz do aparelho, que funciona offline.", color = g.muted, fontSize = 12.sp)
                        }
                        Switch(checked = cloudVoice, onCheckedChange = { cloudVoice = it; LocalAiSettings.setCloudVoiceAllowed(context, it) })
                    }
                }
            }

            // ---- Opções avançadas: tudo já funciona no automático; aqui só para quem quer mexer
            item {
                Card {
                    Row(
                        Modifier.fillMaxWidth().clickable { showAdvanced = !showAdvanced },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("Opções avançadas", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("Avisos, download, pesquisa online e voz. A Cris já escolhe tudo sozinha (modo automático).", color = g.muted, fontSize = 12.sp)
                        }
                        Text(if (showAdvanced) "Fechar" else "Abrir", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
            if (showAdvanced) {
            // ---- Avisos da Cris: agora ficam na Central de notificações
            item {
                Card {
                    Text("Avisos da Cris", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Os avisos (pesquisa pronta, som, padrões que a Cris nota) são ligados ou desligados na Central de notificações.", color = g.muted, fontSize = 12.sp)
                    OutlinedButton(onClick = { nav.navigate(Routes.NOTIFICATIONS) }) { Text("Abrir a Central de notificações") }
                }
            }

            // ---- Download em segundo plano
            item {
                Card {
                    Text("Download", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        "O download da IA roda em segundo plano (WorkManager) com notificação, e continua se você fechar o app ou apagar a tela. " +
                            "Por padrão só usa Wi-Fi; se faltar rede ele espera e retoma de onde parou. O Android pode limitar se a bateria estiver muito restrita.",
                        color = g.muted, fontSize = 12.sp,
                    )
                    var metered by remember { mutableStateOf(LocalAiSettings.allowMeteredDownload(context)) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Permitir dados móveis no download", color = g.ink, fontSize = 14.sp)
                            Text("Desligado: o download espera o Wi-Fi. Vale para os próximos downloads.", color = g.muted, fontSize = 12.sp)
                        }
                        Switch(checked = metered, onCheckedChange = { metered = it; LocalAiSettings.setAllowMeteredDownload(context, it) })
                    }
                }
            }

            // ---- Pesquisa online (ferramenta da Cris; a IA local continua respondendo)
            item {
                Card {
                    Text("Pesquisa online", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Pesquisar sozinha quando precisar", color = g.ink, fontSize = 14.sp)
                            Text(
                                "Com internet, a Cris pesquisa notícias e informações atuais e responde com as palavras dela, citando fontes e datas. Sem internet, segue 100% local. Seus registros de saúde e seu histórico nunca são enviados.",
                                color = g.muted, fontSize = 12.sp,
                            )
                        }
                        Switch(checked = webSearch, onCheckedChange = { webSearch = it; LocalAiSettings.setWebSearchEnabled(context, it) })
                    }
                    Text(
                        (if (LocalAiSettings.tavilyAvailable(context)) "Busca geral na web (Tavily): ativa quando necessário (créditos estimados restantes no mês: ${com.agon.app.localai.TavilyCredits.remaining(context)}). " else "Busca geral na web: indisponível neste aplicativo. ") +
                            "Também usa Google Notícias, Wikipédia, Wikidata e PubMed (saúde). Status: " + if (online) "online" else "sem internet",
                        color = g.ink, fontSize = 12.sp,
                    )
                    OutlinedButton(
                        enabled = !webTesting,
                        onClick = {
                            webTesting = true; webTestResult = null
                            scope.launch { webTestResult = CrisWebSearch.selfTest(context); webTesting = false }
                        },
                    ) { Text(if (webTesting) "Testando..." else "Testar pesquisa") }
                    webTestResult?.let { Text(it, color = g.ink, fontSize = 12.sp) }
                }
            }

            // ---- Voz
            item {
                Card {
                    Text("Voz", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        if (LocalSpeech.onDeviceRecognitionAvailable(context))
                            "Reconhecimento no aparelho: disponível neste Android. Se o pacote de português do Brasil não estiver instalado, instale em Configurações > Idioma > Voz."
                        else
                            "Reconhecimento no aparelho: não disponível neste Android (precisa do Android 13 ou mais). O reconhecimento padrão do sistema pode exigir internet.",
                        color = g.ink, fontSize = 13.sp,
                    )
                    Text("Fala: usa uma voz pt-BR instalada que não precise de internet. O Android não informa o gênero da voz; a escolha é aproximada.", color = g.muted, fontSize = 12.sp)
                }
            }
            }

            // ---- Aprendizado automático (sem cadastro manual)
            item {
                Card {
                    Text("Aprendizado da Cris", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        "A Cris aprende sozinha: guarda automaticamente o que você conta nas conversas e a sua rotina real " +
                            "(horários de glicose, insulina e refeições). Tudo fica só neste aparelho.",
                        color = g.muted, fontSize = 12.sp,
                    )
                    if (facts.isNotEmpty()) Text("Itens aprendidos até agora: ${facts.size}.", color = g.ink, fontSize = 13.sp)
                    else Text("Ainda aprendendo sobre você.", color = g.ink, fontSize = 13.sp)
                    if (facts.isNotEmpty()) OutlinedButton(onClick = { confirmClearAll = true }) { Text("Esquecer o que aprendi") }
                    OutlinedButton(onClick = {
                        scope.launch { CrisPrefs.clearChat(context); CrisConversationStore.clearAll(context); historyCleared = true }
                    }) { Text(if (historyCleared) "Histórico apagado" else "Apagar histórico de conversas") }
                }
            }
        }
    }

    confirmModelAction?.let { action ->
        val active = mgr.activeSpec
        AlertDialog(
            onDismissRequest = { confirmModelAction = null },
            title = { Text(if (action == "reinstall") "Reinstalar a IA local?" else "Apagar a IA local?") },
            text = {
                Text(
                    if (action == "reinstall")
                        "Isto apaga o modelo instalado e abre a escolha para baixar de novo. Até terminar, a Cris usa as respostas básicas. Suas conversas e memórias não mudam. " +
                            "Se só quer trocar de modelo, use \"Trocar modelo\": ele mantém o atual até o novo ficar pronto."
                    else
                        "O modelo será removido do aparelho (libera espaço). Suas conversas e memórias não mudam; você pode instalar de novo quando quiser.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    confirmModelAction = null
                    if (active != null) mgr.deleteModel(active)
                    testResult = null
                    if (action == "reinstall") nav.navigate(Routes.CRIS_MODEL_CHOOSER)
                }) { Text(if (action == "reinstall") "Apagar e escolher" else "Apagar") }
            },
            dismissButton = { TextButton(onClick = { confirmModelAction = null }) { Text("Cancelar") } },
        )
    }

    if (confirmClearAll) {
        AlertDialog(
            onDismissRequest = { confirmClearAll = false },
            title = { Text("Esquecer o que a Cris aprendeu?") },
            text = { Text("A Cris apaga a rotina e os detalhes que aprendeu sobre você neste aparelho e começa a aprender de novo.") },
            confirmButton = {
                TextButton(onClick = { LocalMemoryManager.clear(context); facts = emptyList(); confirmClearAll = false }) { Text("Esquecer") }
            },
            dismissButton = { TextButton(onClick = { confirmClearAll = false }) { Text("Cancelar") } },
        )
    }

    if (adding || editing != null) {
        var text by remember(editing, adding) { mutableStateOf(editing?.text ?: "") }
        AlertDialog(
            onDismissRequest = { adding = false; editing = null },
            title = { Text(if (editing != null) "Editar memória" else "Nova memória") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it.take(300) }, modifier = Modifier.fillMaxWidth()) },
            confirmButton = {
                TextButton(onClick = {
                    val e = editing
                    if (e != null) LocalMemoryManager.update(context, e.id, text) else LocalMemoryManager.add(context, text)
                    facts = LocalMemoryManager.load(context)
                    adding = false; editing = null
                }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { adding = false; editing = null }) { Text("Cancelar") } },
        )
    }
}