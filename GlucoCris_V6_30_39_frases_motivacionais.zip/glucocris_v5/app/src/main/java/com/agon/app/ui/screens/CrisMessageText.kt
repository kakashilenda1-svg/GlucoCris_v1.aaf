package com.agon.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit

private val URL_REGEX = Regex("""https?://[^\s<>"']+""")
/** Marcadores que a Cris usa para alerta de alergia em receitas — pintados de vermelho no chat. */
private val ALLERGY_ALERT_REGEX = Regex(
    """(?i)(🔴\s*ALERTA\s+DE\s+ALERGIA[^\n]*|ALERTA\s+DE\s+ALERGIA\s*[—\-:][^\n]*)""",
)
private val ALLERGY_RED = Color(0xFFDC2626)

/** Transforma links (https://...) do texto em trechos clicáveis e destaca alertas de alergia em vermelho. */
internal fun linkify(text: String, linkColor: Color, allergyColor: Color = ALLERGY_RED): AnnotatedString = buildAnnotatedString {
    // 1) Marca faixas de alerta de alergia
    data class Span(val start: Int, val end: Int, val kind: String, val value: String)
    val spans = mutableListOf<Span>()
    for (m in ALLERGY_ALERT_REGEX.findAll(text)) {
        spans.add(Span(m.range.first, m.range.last + 1, "allergy", m.value))
    }
    for (m in URL_REGEX.findAll(text)) {
        var url = m.value
        while (url.isNotEmpty() && url.last() in ")].,;:!?") url = url.dropLast(1)
        if (url.length < 8) continue
        spans.add(Span(m.range.first, m.range.first + url.length, "url", url))
    }
    spans.sortBy { it.start }

    var last = 0
    for (s in spans) {
        if (s.start < last) continue // overlap: ignora
        if (s.start > last) append(text.substring(last, s.start))
        when (s.kind) {
            "allergy" -> withStyle(
                SpanStyle(color = allergyColor, fontWeight = FontWeight.Bold),
            ) { append(s.value) }
            "url" -> withLink(
                LinkAnnotation.Url(
                    s.value,
                    TextLinkStyles(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline)),
                ),
            ) { append(s.value) }
            else -> append(s.value)
        }
        last = s.end
    }
    if (last < text.length) append(text.substring(last))
}

/**
 * Texto da mensagem: links clicáveis, alerta de alergia em vermelho e seleção
 * pressionando e segurando (copia só o trecho escolhido).
 */
@Composable
internal fun CrisMessageText(
    text: String,
    color: Color,
    linkColor: Color,
    fontSize: TextUnit,
    lineHeight: TextUnit,
    modifier: Modifier = Modifier,
) {
    val annotated = remember(text, linkColor) { linkify(text, linkColor) }
    SelectionContainer(modifier) {
        Column { Text(annotated, color = color, fontSize = fontSize, lineHeight = lineHeight) }
    }
}

/** Copia o texto inteiro da mensagem para a área de transferência. */
internal fun copyMessageText(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Mensagem da Cris", text))
    Toast.makeText(context, "Texto copiado", Toast.LENGTH_SHORT).show()
}
