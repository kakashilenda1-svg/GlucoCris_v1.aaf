package com.agon.app.ui.screens

import android.content.Context
import com.agon.app.BuildConfig
import java.net.HttpURLConnection
import java.net.URL
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * FoodBase (foodbase.dev) pelo proxy (Cloudflare Worker, rota /foodbase).
 * A chave da FoodBase fica SÓ no servidor (segredo FOODBASE_API_KEY); o app só conhece o endereço do proxy,
 * o mesmo já usado por Tavily/Gemini/FatSecret. Nenhuma função aqui lança exceção: em qualquer falha devolve vazio/null,
 * e o app segue com as outras fontes (TACO, Open Food Facts, USDA, FatSecret).
 *
 * Valores nutricionais vêm por 100 g. Item sem nutrientes NUNCA vira alimento com carboidrato zero (é descartado).
 */
private fun foodBaseCall(body: JSONObject, connectMs: Int, readMs: Int): JSONObject? {
    val base = BuildConfig.TAVILY_PROXY_URL.trim().trimEnd('/')
    if (base.isBlank()) return null
    return try {
        val c = (URL("$base/foodbase").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            doOutput = true
            connectTimeout = connectMs
            readTimeout = readMs
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "GlucoCris (Android; foodbase)")
            val tok = BuildConfig.TAVILY_APP_TOKEN.trim()
            if (tok.isNotBlank()) setRequestProperty("X-App-Token", tok)
        }
        c.outputStream.use { out -> out.write(body.toString().toByteArray(Charsets.UTF_8)) }
        if (c.responseCode != 200) null else JSONObject(c.inputStream.bufferedReader().readText())
    } catch (_: Exception) {
        null
    }
}

private fun foodBaseItemOf(o: JSONObject): FoodItem? {
    val name = o.optString("name", "").trim()
    if (name.isBlank()) return null
    val per = o.optJSONObject("per100") ?: return null
    val hasCarbs = per.optBoolean("hasCarbs", true)
    val kcal = per.optDouble("kcal", 0.0)
    val brand = o.optString("brand", "").trim()
    val id = o.optString("id", "").ifBlank { name }
    // O código de barras viaja no id ("fb-<id>~<código>") para o catálogo Gluco reconhecer o mesmo produto em qualquer fonte
    val bc = o.optString("barcode", "").filter { ch -> ch.isDigit() }
    return FoodItem(
        id = "fb-$id" + (if (bc.length in 8..14) "~$bc" else ""),
        name = name,
        brand = brand,
        serving = "100 g",
        servingGrams = 100.0,
        kcal = kcal,
        kj = kcal * 4.184,
        carbs = per.optDouble("carbs", 0.0),
        protein = per.optDouble("protein", 0.0),
        fat = per.optDouble("fat", 0.0),
        fiber = per.optDouble("fiber", 0.0),
        sodium = per.optDouble("sodiumMg", 0.0),
        sugars = per.optDouble("sugars", 0.0),
        satFat = per.optDouble("satFat", 0.0),
        source = if (hasCarbs) "FoodBase" else "FoodBase — carboidrato não informado, confira",
        sourceKey = "foodbase",
        isGeneric = brand.isBlank(),
        category = o.optString("category", ""),
        reliability = if (hasCarbs) "media" else "verificar",
    )
}

/** Busca por nome no catálogo FoodBase (6,1 milhões de produtos). Só devolve itens com nutrientes. */
suspend fun searchFoodBase(query: String): List<FoodItem> = withContext(Dispatchers.IO) {
    val q = query.trim()
    if (q.length < 3) return@withContext emptyList() // poupa a cota: não consulta a cada letra inicial
    val body = JSONObject().put("op", "search").put("q", q).put("limit", 12).put("hydrate", 3)
    val json = foodBaseCall(body, 2500, 4500) ?: return@withContext emptyList()
    val arr = json.optJSONArray("items") ?: return@withContext emptyList()
    val out = mutableListOf<FoodItem>()
    for (i in 0 until arr.length()) {
        val item = foodBaseItemOf(arr.getJSONObject(i))
        if (item != null) out.add(item)
    }
    out
}

/** Consulta por código de barras (bloqueante: roda dentro da corrida de fontes do lookupBarcode). */
fun lookupFoodBaseBarcodeBlocking(code: String): FoodItem? {
    val digits = code.filter { ch -> ch.isDigit() }
    if (digits.length < 8) return null
    val json = foodBaseCall(JSONObject().put("op", "barcode").put("code", digits), 2500, 3300) ?: return null
    val o = json.optJSONObject("item") ?: return null
    val base = foodBaseItemOf(o) ?: return null
    return base.copy(id = "bc-$digits")
}

/**
 * Ferramenta da Cris IA: pergunta sobre nutrientes de um alimento ("quantos carboidratos tem o arroz branco?")
 * é respondida com os dados da FoodBase, sem inventar números. Só informa; não calcula dose de insulina.
 * Devolve null (e a Cris segue o fluxo normal) se não for esse tipo de pergunta, se houver dado pessoal,
 * se estiver sem internet ou se a FoodBase não achar o alimento.
 */
object CrisFoodBaseTool {
    private val NUTRIENT = Regex(
        """(carboidratos?|carbos?|calorias?|kcal|prote[ií]nas?|gorduras?|s[oó]dio|a[cç][uú]cares?|fibras?|valor nutricional|informa[cç][aã]o nutricional|tabela nutricional)""",
        RegexOption.IGNORE_CASE,
    )
    private val FOOD_AFTER = Regex(
        """(?:carboidratos?|carbos?|calorias?|kcal|prote[ií]nas?|gorduras?|s[oó]dio|a[cç][uú]cares?|fibras?|valor nutricional|informa[cç][aã]o nutricional|tabela nutricional)\s+(?:tem|t[eê]m|possui|cont[eé]m|h[aá])?\s*(?:(?:de|do|da|dos|das|em|no|na|nos|nas|num|numa)\s+)?(?:(?:um|uma|uns|umas|o|a|os|as)\s+)?(.+?)\s*[?!.]*$""",
        RegexOption.IGNORE_CASE,
    )
    private val QUESTION = Regex("""(quanto|quantos|quantas|qual|quais|tem|t[eê]m|possui|cont[eé]m|valor|informa)""", RegexOption.IGNORE_CASE)
    private val PERSONAL = Regex("""(meu|minha|meus|minhas|hoje|ontem|registr|glicemia|insulina|dose|unidades)""", RegexOption.IGNORE_CASE)
    private val STOP = setOf("com", "sem", "para", "por", "uma", "uns", "umas", "dos", "das", "que")
    private val QTY = Regex("""^\d+([.,]\d+)?\s*(g|gr|gramas?|ml|kg)\s*(de\s+)?""", RegexOption.IGNORE_CASE)

    private fun fmt(v: Double): String {
        val s = String.format(java.util.Locale.forLanguageTag("pt-BR"), "%.1f", v)
        return if (s.endsWith(",0")) s.dropLast(2) else s
    }

    fun extractFood(text: String): String? {
        val t = text.trim()
        if (!NUTRIENT.containsMatchIn(t) || !QUESTION.containsMatchIn(t)) return null
        val raw = FOOD_AFTER.find(t)?.groupValues?.getOrNull(1)?.trim().orEmpty()
        val food = raw.replace(QTY, "").trim().trim(',', ';', ':')
        if (food.length < 3 || food.length > 60) return null
        if (PERSONAL.containsMatchIn(food)) return null
        return food
    }

    suspend fun tryAnswer(context: Context, text: String, userName: String): String? {
        val food = extractFood(text) ?: return null
        if (PERSONAL.containsMatchIn(text)) return null
        if (com.agon.app.localai.CrisSearchPolicy.hasPersonalData(text, userName)) return null
        if (!com.agon.app.localai.CrisConnectivityManager.isOnline(context)) return null
        // Só aceita resultado cujo nome (ou marca) tenha pelo menos uma palavra do alimento pedido: evita responder com
        // um produto sem relação quando a frase extraída não era um alimento.
        val tokens = normSearch(food).split(" ").filter { w -> w.length >= 3 && w !in STOP }
        if (tokens.isEmpty()) return null
        val scored = searchFoodBase(food)
            .filter { f -> f.reliability != "verificar" }
            .map { f ->
                val blob = normSearch(f.name + " " + f.brand)
                f to tokens.count { w -> blob.contains(w) }
            }
            .filter { pair -> pair.second > 0 }
        if (scored.isEmpty()) return null
        val ranked = scored.sortedByDescending { pair -> pair.second }.take(3).map { pair -> pair.first }
        val sb = StringBuilder()
        sb.append("Pela FoodBase, valores por 100 g:\n")
        for (f in ranked) {
            val label = if (f.brand.isNotBlank()) "${f.name} (${f.brand})" else f.name
            sb.append("• ").append(label).append(": ")
                .append(fmt(f.carbs)).append(" g de carboidratos, ")
                .append(fmt(f.kcal)).append(" kcal, ")
                .append(fmt(f.protein)).append(" g de proteínas, ")
                .append(fmt(f.fat)).append(" g de gorduras")
            if (f.fiber > 0.0) sb.append(", ").append(fmt(f.fiber)).append(" g de fibras")
            sb.append("\n")
        }
        sb.append("\nA conta muda conforme a porção que você come; a pesagem e a tabela do rótulo valem mais que a média.")
        return sb.toString()
    }
}
