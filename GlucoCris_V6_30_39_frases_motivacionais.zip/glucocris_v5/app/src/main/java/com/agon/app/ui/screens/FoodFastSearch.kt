package com.agon.app.ui.screens

import android.content.Context
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle

/**
 * Pesquisa inteligente de alimentos: o resultado ACOMPANHA o que o usuário escreve.
 *
 * Regras (sempre nesta ordem, para o alimento certo não "pular" para outro):
 *  1) Quem COMEÇA com o digitado vem primeiro ("abobo" → Abóbora), depois quem tem uma palavra começando com ele,
 *     depois quem apenas contém. Só o que é parecido (sinônimo / erro de digitação) fica por último.
 *  2) Dentro do mesmo grupo: favoritos e usados recentemente, depois alimentos genéricos (TACO/Meus alimentos)
 *     antes de produtos de marca, depois nome mais curto.
 *  3) Quando chegam resultados novos (busca completa, internet), eles se encaixam nessa mesma ordem; a escolha
 *     do grupo nunca depende da ordem em que as fontes responderam.
 * Erro de digitação só entra se nada começar com o digitado.
 */
private class FastEntry(val food: FoodItem, val name: String, val brand: String, val words: List<String>)

private class Hit(val food: FoodItem, val tier: Int, val len: Int, val order: Int)

private var fastIndex: List<FastEntry>? = null
private var fastIndexTaco: List<FoodItem>? = null

private fun fastIndexFor(taco: List<FoodItem>): List<FastEntry> {
    val cur = fastIndex
    if (cur != null && fastIndexTaco === taco) return cur
    val built = (EXTRA_FOODS + taco).map { f ->
        val n = normSearch(f.name)
        FastEntry(f, n, normSearch(f.brand), n.split(" ").filter { w -> w.isNotEmpty() })
    }
    fastIndex = built
    fastIndexTaco = taco
    return built
}

/** Meus alimentos (cadastrados pelo usuário) como FoodItem, no mesmo formato usado pela pesquisa. */
fun customFoodsAsItems(context: Context): List<FoodItem> =
    loadCustomFoods(context).map { c ->
        FoodItem(
            id = c.id, name = c.name, serving = c.serving, servingGrams = 100.0,
            kcal = c.kcal, carbs = c.carbs, protein = c.protein, fat = c.fat,
            source = "Meu alimento", sourceKey = "custom", isGeneric = true, reliability = "alta",
        )
    }

/** 0 = nome igual · 1 = nome começa com o digitado · 2 = uma palavra começa · 3 = contém · 4 = só parecido. */
private fun tierWithWords(n: String, words: List<String>, q: String): Int = when {
    n == q -> 0
    n.startsWith(q) -> 1
    words.any { w -> w.startsWith(q) } -> 2
    n.contains(q) -> 3
    q.contains(" ") && q.split(" ").filter { t -> t.isNotEmpty() }.all { t -> n.contains(t) } -> 3
    else -> 4
}

fun foodMatchTier(nameNorm: String, q: String): Int =
    tierWithWords(nameNorm, nameNorm.split(" ").filter { w -> w.isNotEmpty() }, q)

private fun sortHits(hits: List<Hit>, boost: Set<String>): List<Hit> =
    hits.sortedWith(
        compareBy<Hit>(
            { h -> h.tier },
            // "só parecido" (tier 4) mantém a ordem de relevância de quem encontrou; os demais seguem as regras abaixo
            { h -> if (h.tier >= 4) 0 else if (h.food.favoriteKey() in boost) 0 else 1 },
            { h -> if (h.tier >= 4) 0 else if (h.food.isGeneric) 0 else 1 },
            { h -> if (h.tier >= 4) 0 else h.len },
            { h -> h.order },
        ),
    )

/** Busca local instantânea (índice pré-normalizado): só o que começa/contém o digitado. */
fun searchLocalFast(query: String, taco: List<FoodItem>, custom: List<FoodItem>, boost: Set<String>): List<FoodItem> {
    val q = normSearch(query)
    if (q.isBlank()) return emptyList()
    val hits = ArrayList<Hit>()
    for (e in fastIndexFor(taco)) {
        var t = tierWithWords(e.name, e.words, q)
        if (t == 4 && e.brand.contains(q)) t = 3
        if (t <= 3) hits.add(Hit(e.food, t, e.name.length, hits.size))
    }
    for (f in custom) {
        val n = normSearch(f.name)
        val t = foodMatchTier(n, q)
        if (t <= 3) hits.add(Hit(f, t, n.length, hits.size))
    }
    return sortHits(hits, boost).take(60).map { h -> h.food }.distinctBy { f -> f.id }
}

/** Junta resultados novos aos que já estão na tela, sempre na mesma ordem inteligente (sem pular para outro alimento). */
fun mergeStable(prev: List<FoodItem>, incoming: List<FoodItem>, query: String, boost: Set<String>): List<FoodItem> {
    val seen = HashSet<String>()
    val all = ArrayList<FoodItem>()
    for (f in prev) if (seen.add(f.id)) all.add(f)
    for (f in incoming) if (seen.add(f.id)) all.add(f)
    val q = normSearch(query)
    if (q.isBlank()) return all
    val hits = all.mapIndexed { i, f ->
        val n = normSearch(f.name)
        var t = foodMatchTier(n, q)
        if (t == 4 && normSearch(f.brand).contains(q)) t = 3
        Hit(f, t, n.length, i)
    }
    return sortHits(hits, boost).map { h -> h.food }
}

private fun foldChar(c: Char): Char {
    val l = c.lowercaseChar()
    return when (l) {
        'á', 'à', 'â', 'ã', 'ä' -> 'a'
        'é', 'è', 'ê', 'ë' -> 'e'
        'í', 'ì', 'î', 'ï' -> 'i'
        'ó', 'ò', 'ô', 'õ', 'ö' -> 'o'
        'ú', 'ù', 'û', 'ü' -> 'u'
        'ç' -> 'c'
        '-' -> ' '
        else -> l
    }
}

/** Nome com a parte digitada em destaque (ignora acento e maiúscula): "abobo" → **Abóbo**ra. */
fun highlightMatch(name: String, query: String, color: Color): AnnotatedString {
    val q = query.trim().map { ch -> foldChar(ch) }.joinToString("")
    if (q.isEmpty()) return AnnotatedString(name)
    val folded = name.map { ch -> foldChar(ch) }.joinToString("")
    var idx = if (folded.startsWith(q)) 0 else -1
    if (idx < 0) {
        val w = folded.indexOf(" $q")
        if (w >= 0) idx = w + 1
    }
    if (idx < 0) idx = folded.indexOf(q)
    if (idx < 0 || idx + q.length > name.length) return AnnotatedString(name)
    return buildAnnotatedString {
        append(name.substring(0, idx))
        withStyle(SpanStyle(fontWeight = FontWeight.ExtraBold, color = color)) {
            append(name.substring(idx, idx + q.length))
        }
        append(name.substring(idx + q.length))
    }
}
