package com.agon.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PriorityHigh
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.R
import com.agon.app.ui.components.tourTarget

// Layout 3 ("claro/vidro"): reproduz o print de referência (841 px de largura).
// Todas as medidas abaixo estão em pixels do print; [s] converte para dp (largura da tela / 841).

internal val GlassNavy = Color(0xFF061442)
private val GlassGreen = Color(0xFF259C23)
private val GlassAmber = Color(0xFFE08A00)
private val GlassRed = Color(0xFFD32F2F)

private fun d(v: Float, s: Float): Dp = (v * s).dp

/** Cartão de vidro: degradê claro, borda azul-acinzentada e faixa azul viva no topo (como no print). */
internal fun Modifier.glassCard(s: Float, accent: Boolean = true): Modifier {
    val shape = RoundedCornerShape((40f * s).dp)
    return this
        .shadow(8.dp, shape, clip = false, ambientColor = Color(0x331E5BFF), spotColor = Color(0x661E5BFF))
        .clip(shape)
        .background(Brush.verticalGradient(listOf(Color(0xFFFEFEFF), Color(0xFFEDF3FD), Color(0xFFE2EAF9))))
        .border(
            1.5.dp,
            Brush.verticalGradient(
                if (accent) listOf(Color(0xFF3D78E0), Color(0xFFC3D3EC), Color(0xFF9DB8E0))
                else listOf(Color(0xFF8DBBF2), Color(0xFFCFE0F6), Color(0xFF9DB8E0)),
            ),
            shape,
        )
        .drawWithContent {
            drawContent()
            if (accent) {
                drawRect(
                    Brush.horizontalGradient(listOf(Color(0x000A47C8), Color(0xFF0A47C8), Color(0xFF1EA4FF), Color(0x001EA4FF))),
                    size = Size(size.width, 3.dp.toPx()),
                )
            }
        }
}

/** Deixa o conteúdo [extra] dp mais largo de cada lado (a tela inicial tem 16 dp de margem). */
private fun Modifier.bleedX(extra: Dp): Modifier = this.layout { measurable, constraints ->
    val e = extra.roundToPx()
    val w = constraints.maxWidth + 2 * e
    val p = measurable.measure(constraints.copy(minWidth = w, maxWidth = w))
    layout(constraints.maxWidth, p.height) { p.place(-e, 0) }
}

/** Texto de uma linha que encolhe até caber na largura disponível. */
@Composable
private fun FitLine(
    text: String,
    color: Color,
    maxSp: Float,
    minSp: Float,
    modifier: Modifier = Modifier,
    weight: FontWeight? = null,
) {
    val measurer = rememberTextMeasurer()
    val fam = com.agon.app.ui.theme.appFontFamily()
    BoxWithConstraints(modifier) {
        val maxW = constraints.maxWidth
        var sp = maxSp
        while (sp > minSp) {
            val w = measurer.measure(
                text = text,
                style = TextStyle(fontFamily = fam, fontSize = sp.sp, fontWeight = weight),
                softWrap = false,
                maxLines = 1,
            ).size.width
            if (w <= maxW) break
            sp -= 0.5f
        }
        Text(text, color = color, fontSize = sp.sp, fontWeight = weight, maxLines = 1, softWrap = false)
    }
}

/** Posiciona [content] com a margem esquerda em [x] e o centro vertical em [cy] (px do print, relativos ao cartão). */
@Composable
private fun AtBox(s: Float, x: Float, cy: Float, h: Float, w: Float? = null, content: @Composable () -> Unit) {
    val base = Modifier.offset(d(x, s), d(cy - h / 2f, s)).height(d(h, s))
    Box(if (w != null) base.width(d(w, s)) else base, contentAlignment = Alignment.CenterStart) { content() }
}

@Composable
private fun GlassChevron(s: Float, modifier: Modifier = Modifier) {
    Icon(
        Icons.AutoMirrored.Filled.KeyboardArrowRight,
        contentDescription = null,
        tint = GlassNavy,
        modifier = modifier.size(d(46f, s)),
    )
}

@Composable
private fun GlassTopButton(s: Float, cx: Float, label: String?, onClick: () -> Unit, modifier: Modifier = Modifier, icon: @Composable () -> Unit) {
    Column(
        Modifier.offset(d(cx - 50f, s), d(17f, s)).width(d(100f, s)),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            modifier
                .size(d(80f, s))
                .shadow(8.dp, CircleShape, clip = false, ambientColor = Color(0xFF1E6BFF), spotColor = Color(0xFF1E6BFF))
                .clip(CircleShape)
                .background(Brush.radialGradient(listOf(Color(0xFF1F6FE0), Color(0xFF0A3A9A), Color(0xFF031E5E))))
                .border(2.dp, Brush.verticalGradient(listOf(Color(0xFF7DB8FF), Color(0xFF0A3B8C))), CircleShape)
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) { icon() }
        if (label != null) {
            Text(label, color = GlassNavy, fontWeight = FontWeight.Bold, fontSize = (23f * s).sp, maxLines = 1, modifier = Modifier.padding(top = d(8f, s)))
        }
    }
}

@Composable
private fun StatusBadge(s: Float, status: String?, modifier: Modifier = Modifier) {
    val (c1, c2) = when (status) {
        "low" -> Color(0xFFFFB74D) to Color(0xFFE65100)
        "high" -> Color(0xFFEF5350) to Color(0xFFB71C1C)
        else -> Color(0xFF55D455) to Color(0xFF0E7F12)
    }
    Box(
        modifier
            .size(d(56f, s))
            .shadow(4.dp, CircleShape, clip = false, ambientColor = c2, spotColor = c2)
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(c1, c2)))
            .border(1.5.dp, Color.White.copy(alpha = 0.9f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (status == "low" || status == "high") Icons.Filled.PriorityHigh else Icons.Filled.Check,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(d(36f, s)),
        )
    }
}

@Composable
private fun RoundArrowButton(s: Float, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(d(58f, s))
            .shadow(5.dp, CircleShape, clip = false, ambientColor = Color(0xFF6C9CE8), spotColor = Color(0xFF6C9CE8))
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(Color.White, Color(0xFFD6E6FB))))
            .border(1.5.dp, Color(0xFFB4CCF0), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Color(0xFF1B5FD0), modifier = Modifier.size(d(38f, s)))
    }
}

@Composable
internal fun HomeTopGlass(
    s: Float,
    greetText: String,
    mg: Int?,
    status: String?,
    statusText: String,
    dateText: String,
    weekG: Int,
    weekI: Int,
    tirPct: Int?,
    onProfile: () -> Unit,
    onSwitch: () -> Unit,
    onHelp: () -> Unit,
    onMood: () -> Unit,
    onLast: () -> Unit,
    onGlucose: () -> Unit,
    onInsulin: () -> Unit,
    onCris: () -> Unit,
    onConfidence: () -> Unit,
    phrase: String = "",
) {
    val fs = LocalDensity.current.fontScale.coerceIn(1f, 1.3f)
    val statusColor = when (status) {
        "low" -> GlassAmber
        "high" -> GlassRed
        else -> GlassGreen
    }
    val sidePad = Modifier.padding(start = d(20f, s), end = d(19f, s))

    Column(Modifier.fillMaxWidth().bleedX(16.dp)) {
        // ───────────── Cabeçalho (do y=60 ao y=500 do print) ─────────────
        Box(Modifier.fillMaxWidth().height(d(440f, s))) {
            Image(
                painterResource(R.drawable.home3_logo),
                contentDescription = "GlucoCris",
                modifier = Modifier.offset(d(14f, s), d(4f, s)).size(d(422f, s), d(168f, s)),
                contentScale = ContentScale.Fit,
            )
            GlassTopButton(s, 563f, "Perfil", onProfile, Modifier.tourTarget("home_profile")) {
                Icon(Icons.Filled.Person, "Perfil", tint = Color.White, modifier = Modifier.size(d(44f, s)))
            }
            GlassTopButton(s, 670f, null, onSwitch, Modifier.tourTarget("home_theme")) {
                Icon(Icons.Filled.Repeat, "Trocar layout", tint = Color.White, modifier = Modifier.size(d(46f, s)))
            }
            GlassTopButton(s, 778f, "Ajuda", onHelp, Modifier.tourTarget("home_help")) {
                Text("?", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = (50f * s).sp)
            }
            // Saudação (toque abre a escolha de humor)
            Box(
                Modifier
                    .offset(d(28f, s), d(228f, s))
                    .width(d(412f, s))
                    .clickable(onClick = onMood),
            ) {
                Column {
                    FitLine(greetText, GlassNavy, 58f * s, 28f * s, Modifier.fillMaxWidth(), FontWeight.ExtraBold)
                    Text(
                        "Como está seu dia hoje?",
                        color = GlassNavy,
                        fontSize = (36f * s).sp,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.padding(top = d(8f, s)),
                    )
                }
            }
            // Curva azul sob a saudação
            Canvas(Modifier.offset(d(40f, s), d(350f, s)).size(d(330f, s), d(90f, s))) {
                val w = size.width
                val h = size.height
                val p = Path().apply {
                    moveTo(w * 0.03f, h * 0.92f)
                    cubicTo(w * 0.30f, h * 0.42f, w * 0.62f, h * 0.16f, w * 1.0f, h * 0.20f)
                }
                drawPath(
                    p,
                    Brush.horizontalGradient(listOf(Color(0x001E7BFF), Color(0xFF1E7BFF), Color(0xFF39A0FF))),
                    style = Stroke(width = (7f * s).dp.toPx(), cap = StrokeCap.Round),
                )
            }
            // Valor mostrado na tela do glicosímetro (a arte vem sem número)
            Column(
                Modifier
                    .offset(d(642f, s), d(198f, s))
                    .size(d(130f, s), d(112f, s))
                    .rotate(-6f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(
                    mg?.toString() ?: "--",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontStyle = FontStyle.Italic,
                    fontSize = (52f * s).sp,
                    maxLines = 1,
                    softWrap = false,
                )
                Text("mg/dL", color = Color.White, fontStyle = FontStyle.Italic, fontSize = (27f * s).sp, maxLines = 1, softWrap = false)
            }
        }

        // ───────────── Linha 1: Última medição | Tempo no alvo ─────────────
        Row(
            sidePad.fillMaxWidth().height(d(325f, s) * fs),
            horizontalArrangement = Arrangement.spacedBy(d(17f, s)),
        ) {
            // Última medição
            Box(Modifier.weight(1f).fillMaxHeight().glassCard(s).clickable(onClick = onLast)) {
                Image(painterResource(R.drawable.home3_ic_drop), null, Modifier.offset(d(30f, s), d(16f, s)).size(d(62f, s), d(68f, s)), contentScale = ContentScale.Fit)
                AtBox(s, 111f, 53f, 50f, 235f) { FitLine("Última medição", GlassNavy, 30f * s, 14f * s, Modifier.fillMaxWidth(), FontWeight.Medium) }
                Box(Modifier.align(Alignment.TopEnd).padding(end = d(14f, s), top = d(28f, s))) { GlassChevron(s) }
                AtBox(s, 48f, 137f, 130f) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(mg?.toString() ?: "--", color = GlassNavy, fontWeight = FontWeight.ExtraBold, fontSize = (112f * s).sp, maxLines = 1, softWrap = false)
                        Text("mg/dL", color = GlassNavy, fontSize = (30f * s).sp, maxLines = 1, softWrap = false, modifier = Modifier.padding(start = d(10f, s), bottom = d(22f, s)))
                    }
                }
                if (mg != null) {
                    StatusBadge(s, status, Modifier.offset(d(26f, s), d(197f, s)))
                    AtBox(s, 110f, 225f, 44f, 250f) { FitLine(statusText, statusColor, 30f * s, 14f * s, Modifier.fillMaxWidth(), FontWeight.Bold) }
                } else {
                    AtBox(s, 34f, 225f, 44f, 330f) { FitLine("Toque para registrar", GlassNavy, 30f * s, 14f * s, Modifier.fillMaxWidth(), FontWeight.Bold) }
                }
                Image(painterResource(R.drawable.home3_ic_clock), null, Modifier.offset(d(30f, s), d(262f, s)).size(d(50f, s), d(42f, s)), contentScale = ContentScale.Fit)
                AtBox(s, 110f, 286f, 40f, 262f) { FitLine(if (mg != null) dateText else "Sem medição ainda", GlassNavy, 26f * s, 11f * s, Modifier.fillMaxWidth()) }
            }
            // Tempo no alvo
            Box(Modifier.weight(1f).fillMaxHeight().glassCard(s).clickable(onClick = onGlucose)) {
                Image(painterResource(R.drawable.home3_ic_target), null, Modifier.offset(d(30f, s), d(24f, s)).size(d(64f, s), d(62f, s)), contentScale = ContentScale.Fit)
                AtBox(s, 114f, 53f, 50f, 215f) { FitLine("Tempo no alvo", GlassNavy, 30f * s, 14f * s, Modifier.fillMaxWidth(), FontWeight.Medium) }
                Box(Modifier.align(Alignment.TopEnd).padding(end = d(14f, s), top = d(28f, s))) { GlassChevron(s) }
                AtBox(s, 50f, 137f, 130f) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(tirPct?.toString() ?: "—", color = GlassNavy, fontWeight = FontWeight.ExtraBold, fontSize = (112f * s).sp, maxLines = 1, softWrap = false)
                        if (tirPct != null) {
                            Text("%", color = GlassNavy, fontWeight = FontWeight.ExtraBold, fontSize = (62f * s).sp, maxLines = 1, softWrap = false, modifier = Modifier.padding(start = d(4f, s), bottom = d(14f, s)))
                        }
                    }
                }
                Box(
                    Modifier
                        .padding(start = d(31f, s), top = d(210f, s), end = d(31f, s))
                        .fillMaxWidth()
                        .height(d(30f, s))
                        .clip(RoundedCornerShape(d(15f, s)))
                        .background(Color(0xFF9EC5EB)),
                ) {
                    val frac = ((tirPct ?: 0).coerceIn(0, 100)) / 100f
                    if (frac > 0f) {
                        Box(
                            Modifier
                                .fillMaxWidth(frac)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(d(15f, s)))
                                .background(Brush.horizontalGradient(listOf(Color(0xFF0A63F0), Color(0xFF1E9BFF)))),
                        )
                    }
                }
                Image(painterResource(R.drawable.home3_ic_calendar), null, Modifier.offset(d(32f, s), d(264f, s)).size(d(44f, s), d(46f, s)), contentScale = ContentScale.Fit)
                AtBox(s, 100f, 287f, 40f, 250f) { FitLine(if (tirPct != null) "Últimos 7 dias" else "Sem medições em 7 dias", GlassNavy, 26f * s, 11f * s, Modifier.fillMaxWidth()) }
            }
        }

        Spacer(Modifier.height(d(20f, s)))

        // ───────────── Linha 2: Glicemias | Insulinas ─────────────
        Row(
            sidePad.fillMaxWidth().height(d(260f, s) * fs),
            horizontalArrangement = Arrangement.spacedBy(d(17f, s)),
        ) {
            @Composable
            fun SmallGlassCard(
                title: String,
                value: Int,
                iconRes: Int,
                iconW: Float,
                iconH: Float,
                bottomIconRes: Int,
                bottomIconW: Float,
                bottomIconH: Float,
                modifier: Modifier,
                onClick: () -> Unit,
            ) {
                Box(
                    modifier
                        .fillMaxHeight()
                        .glassCard(s)
                        .drawBehind {
                            val w = size.width
                            val h = size.height
                            val wave = Path().apply {
                                moveTo(w * 0.28f, h * 0.84f)
                                cubicTo(w * 0.52f, h * 0.60f, w * 0.78f, h * 0.70f, w, h * 0.50f)
                                lineTo(w, h)
                                lineTo(w * 0.28f, h)
                                close()
                            }
                            drawPath(wave, Brush.verticalGradient(listOf(Color(0x55B7D2F7), Color(0x22DCE9FB))))
                            val crest = Path().apply {
                                moveTo(w * 0.28f, h * 0.84f)
                                cubicTo(w * 0.52f, h * 0.60f, w * 0.78f, h * 0.70f, w, h * 0.50f)
                            }
                            drawPath(crest, Color.White.copy(alpha = 0.8f), style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
                        }
                        .clickable(onClick = onClick),
                ) {
                    Image(painterResource(iconRes), null, Modifier.offset(d(30f, s), d(22f, s)).size(d(iconW, s), d(iconH, s)), contentScale = ContentScale.Fit)
                    AtBox(s, 111f, 50f, 50f, 225f) { FitLine(title, GlassNavy, 30f * s, 12f * s, Modifier.fillMaxWidth(), FontWeight.Medium) }
                    Box(Modifier.align(Alignment.TopEnd).padding(end = d(14f, s), top = d(25f, s))) { GlassChevron(s) }
                    AtBox(s, 50f, 132f, 120f) {
                        Text(value.toString(), color = GlassNavy, fontWeight = FontWeight.ExtraBold, fontSize = (104f * s).sp, maxLines = 1, softWrap = false)
                    }
                    Image(painterResource(bottomIconRes), null, Modifier.offset(d(30f, s), d(200f, s)).size(d(bottomIconW, s), d(bottomIconH, s)), contentScale = ContentScale.Fit)
                    AtBox(s, 110f, 223f, 40f, 190f) { FitLine("Registros recentes", GlassNavy, 26f * s, 11f * s, Modifier.fillMaxWidth()) }
                    RoundArrowButton(s, Modifier.align(Alignment.BottomEnd).padding(end = d(17f, s), bottom = d(8f, s)))
                }
            }
            SmallGlassCard("Glicemias (7 dias)", weekG, R.drawable.home3_ic_bars, 64f, 62f, R.drawable.home3_ic_chartup, 54f, 48f, Modifier.weight(1f), onGlucose)
            SmallGlassCard("Insulinas (7 dias)", weekI, R.drawable.home3_ic_syringe, 66f, 62f, R.drawable.home3_ic_jar, 40f, 48f, Modifier.weight(1f), onInsulin)
        }

        Spacer(Modifier.height(d(17f, s)))

        // ───────────── Cris IA ─────────────
        Box(
            sidePad.fillMaxWidth().height(d(183f, s)).glassCard(s, accent = false).clickable(onClick = onCris),
        ) {
            Image(painterResource(R.drawable.home3_robot), "Cris IA", Modifier.offset(d(14f, s), d(-4f, s)).size(d(196f, s), d(188f, s)), contentScale = ContentScale.Fit)
            Image(painterResource(R.drawable.home3_ic_spark_l), null, Modifier.offset(d(240f, s), d(26f, s)).size(d(60f, s), d(62f, s)), contentScale = ContentScale.Fit)
            AtBox(s, 312f, 55f, 60f, 140f) { Text("Cris IA", color = GlassNavy, fontWeight = FontWeight.ExtraBold, fontSize = (44f * s).sp, maxLines = 1, softWrap = false) }
            Image(painterResource(R.drawable.home3_ic_spark_r), null, Modifier.offset(d(444f, s), d(26f, s)).size(d(48f, s), d(62f, s)), contentScale = ContentScale.Fit)
            Text(
                "Sua assistente inteligente para acompanhar sua rotina de saúde.",
                color = GlassNavy,
                fontSize = (28f * s).sp,
                lineHeight = (33f * s).sp,
                modifier = Modifier.offset(d(248f, s), d(96f, s)).width(d(330f, s)),
            )
            Row(
                Modifier
                    .offset(d(598f, s), d(38f, s))
                    .size(d(187f, s), d(68f, s))
                    .shadow(6.dp, RoundedCornerShape(50), clip = false, ambientColor = Color(0xFF0A3A9A), spotColor = Color(0xFF0A3A9A))
                    .clip(RoundedCornerShape(50))
                    .background(Brush.verticalGradient(listOf(Color(0xFF0A4BA8), Color(0xFF06245C))))
                    .border(1.5.dp, Brush.verticalGradient(listOf(Color(0xFF6FA8FF), Color(0xFF0A3B8C))), RoundedCornerShape(50))
                    .clickable(onClick = onCris),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
            ) {
                Text("Saiba mais", color = Color.White, fontWeight = FontWeight.Bold, fontSize = (27f * s).sp, maxLines = 1, softWrap = false)
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Color.White, modifier = Modifier.size(d(34f, s)))
            }
        }

        Spacer(Modifier.height(d(22f, s)))

        // ───────────── Frase motivadora do dia (50 frases, uma por dia) ─────────────
        val quoteDay = com.agon.app.data.DailyQuotes.indexForDay()
        val dailyQuote = remember(quoteDay) { com.agon.app.data.DailyQuotes.QUOTES[quoteDay] }
        Box(
            sidePad.fillMaxWidth().height(d(125f, s)).glassCard(s, accent = false).clickable(onClick = onConfidence),
        ) {
            Image(painterResource(R.drawable.home3_ic_shield_blue), null, Modifier.offset(d(40f, s), d(8f, s)).size(d(86f, s), d(108f, s)), contentScale = ContentScale.Fit)
            AtBox(s, 165f, 30f, 40f, 560f) { FitLine("Frase do dia", GlassNavy, 30f * s, 12f * s, Modifier.fillMaxWidth(), FontWeight.ExtraBold) }
            Text(
                dailyQuote,
                color = GlassNavy,
                fontSize = (26f * s).sp,
                lineHeight = (30f * s).sp,
                maxLines = 2,
                modifier = Modifier.offset(d(165f, s), d(54f, s)).width(d(540f, s)),
            )
            Box(Modifier.align(Alignment.CenterEnd).padding(end = d(14f, s))) { GlassChevron(s) }
        }

        Spacer(Modifier.height(d(21f, s)))

        // O cartão Cris Hidrata fica fixo sobre a tela (HomeScreen), com o efeito de sumir ao rolar.
        Spacer(Modifier.height(d(24f, s)))
    }
}

