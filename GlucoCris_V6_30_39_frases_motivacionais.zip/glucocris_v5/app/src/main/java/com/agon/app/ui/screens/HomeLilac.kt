package com.agon.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PriorityHigh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.R
import com.agon.app.ui.components.tourTarget

// Layout 4 ("lilás vidro"): reproduz o print de referência lilás (842 px de largura).
// As medidas estão em pixels do print; [s] converte para dp (largura da tela / 841).

internal val LilacInk = Color(0xFF2A0A5C)
internal val LilacIndigo = Color(0xFF2B1590)
internal val LilacMagenta = Color(0xFFF514C4)
private val LilacGreen = Color(0xFF0F6E0F)
private val LilacAmber = Color(0xFFE08A00)
private val LilacRed = Color(0xFFD32F2F)

private fun ld(v: Float, s: Float): Dp = (v * s).dp

/** Cartão lilás: fundo quase branco-lilás, borda magenta e brilho rosa (como no print). */
internal fun Modifier.lilacCard(s: Float, tint: Boolean = false): Modifier {
    val shape = RoundedCornerShape((44f * s).dp)
    return this
        .shadow(10.dp, shape, clip = false, ambientColor = Color(0x66E81EC8), spotColor = Color(0x99E81EC8))
        .clip(shape)
        .background(
            Brush.verticalGradient(
                if (tint) listOf(Color(0xFFFDF2FE), Color(0xFFF7DDFB), Color(0xFFF3CCF8))
                else listOf(Color(0xFFFFFAFF), Color(0xFFFCEFFD), Color(0xFFF8E2FB)),
            ),
        )
        .border(
            2.dp,
            Brush.verticalGradient(listOf(Color(0xFFF514C4), Color(0xFFEC6BDD), Color(0xFFF28FE6), Color(0xFFEA3DCB))),
            shape,
        )
}

private fun Modifier.lBleedX(extra: Dp): Modifier = this.layout { measurable, constraints ->
    val e = extra.roundToPx()
    val w = constraints.maxWidth + 2 * e
    val p = measurable.measure(constraints.copy(minWidth = w, maxWidth = w))
    layout(constraints.maxWidth, p.height) { p.place(-e, 0) }
}

@Composable
private fun LFitLine(
    text: String,
    color: Color,
    maxSp: Float,
    minSp: Float,
    modifier: Modifier = Modifier,
    weight: FontWeight? = null,
) {
    val measurer = rememberTextMeasurer()
    val fam = com.agon.app.ui.theme.appFontFamily()
    BoxWithConstraints(modifier) {
        val maxW = constraints.maxWidth
        var sp = maxSp
        while (sp > minSp) {
            val w = measurer.measure(
                text = text,
                style = TextStyle(fontFamily = fam, fontSize = sp.sp, fontWeight = weight),
                softWrap = false,
                maxLines = 1,
            ).size.width
            if (w <= maxW) break
            sp -= 0.5f
        }
        Text(text, color = color, fontSize = sp.sp, fontWeight = weight, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun LAt(s: Float, x: Float, cy: Float, h: Float, w: Float? = null, content: @Composable () -> Unit) {
    val base = Modifier.offset(ld(x, s), ld(cy - h / 2f, s)).height(ld(h, s))
    Box(if (w != null) base.width(ld(w, s)) else base, contentAlignment = Alignment.CenterStart) { content() }
}

@Composable
private fun LChevron(s: Float, modifier: Modifier = Modifier) {
    Icon(
        Icons.AutoMirrored.Filled.KeyboardArrowRight,
        contentDescription = null,
        tint = LilacInk,
        modifier = modifier.size(ld(46f, s)),
    )
}

/** Imagem posicionada pelas medidas do print (x, y relativos ao cartão; w, h em px do print). */
@Composable
private fun LImg(res: Int, s: Float, x: Float, y: Float, w: Float, h: Float) {
    Image(painterResource(res), null, Modifier.offset(ld(x, s), ld(y, s)).size(ld(w, s), ld(h, s)), contentScale = ContentScale.Fit)
}

@Composable
private fun LilacTopButton(s: Float, cx: Float, onClick: () -> Unit, modifier: Modifier = Modifier, icon: @Composable () -> Unit) {
    Box(
        modifier
            .offset(ld(cx - 43f, s), ld(24f, s))
            .size(ld(86f, s))
            .shadow(8.dp, CircleShape, clip = false, ambientColor = Color(0xFF9B1FE0), spotColor = Color(0xFF9B1FE0))
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(Color(0xFF8A1FD0), Color(0xFF6A04B0), Color(0xFF3F0580))))
            .border(2.dp, Brush.verticalGradient(listOf(Color(0xFFE05BFF), Color(0xFF7A2BD0))), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { icon() }
}

@Composable
private fun LilacStatusBadge(s: Float, status: String?, modifier: Modifier = Modifier) {
    val (c1, c2) = when (status) {
        "low" -> Color(0xFFFFB74D) to Color(0xFFE65100)
        "high" -> Color(0xFFEF5350) to Color(0xFFB71C1C)
        else -> Color(0xFF55C21E) to Color(0xFF17780A)
    }
    Box(
        modifier
            .size(ld(56f, s))
            .shadow(4.dp, CircleShape, clip = false, ambientColor = c2, spotColor = c2)
            .clip(CircleShape)
            .background(Brush.radialGradient(listOf(c1, c2)))
            .border(1.5.dp, Color.White.copy(alpha = 0.9f), CircleShape),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            if (status == "low" || status == "high") Icons.Filled.PriorityHigh else Icons.Filled.Check,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(ld(36f, s)),
        )
    }
}

/** Topo do layout 4: cabeçalho, 4 cartões, Cris IA e mensagem motivadora (a Cris Hidrata flutua na HomeScreen). */
@Composable
internal fun HomeTopLilac(
    s: Float,
    greetText: String,
    mg: Int?,
    status: String?,
    statusText: String,
    dateText: String,
    weekG: Int,
    weekI: Int,
    tirPct: Int?,
    onProfile: () -> Unit,
    onSwitch: () -> Unit,
    onHelp: () -> Unit,
    onMood: () -> Unit,
    onLast: () -> Unit,
    onGlucose: () -> Unit,
    onInsulin: () -> Unit,
    onCris: () -> Unit,
    onConfidence: () -> Unit,
    phrase: String = "",
) {
    val fs = LocalDensity.current.fontScale.coerceIn(1f, 1.3f)
    val statusColor = when (status) {
        "low" -> LilacAmber
        "high" -> LilacRed
        else -> LilacGreen
    }
    val sidePad = Modifier.padding(start = ld(17f, s), end = ld(19f, s))

    Column(Modifier.fillMaxWidth().lBleedX(16.dp)) {
        // ───────────── Cabeçalho (y = 60 a 482 do print) ─────────────
        Box(Modifier.fillMaxWidth().height(ld(422f, s))) {
            Image(
                painterResource(R.drawable.lilac_logo),
                contentDescription = "GlucoCris",
                modifier = Modifier.offset(ld(22f, s), ld(0f, s)).size(ld(430f, s), ld(164f, s)),
                contentScale = ContentScale.Fit,
            )
            LilacTopButton(s, 558f, onProfile, Modifier.tourTarget("home_profile")) {
                Icon(Icons.Filled.Person, "Perfil", tint = Color.White, modifier = Modifier.size(ld(48f, s)))
            }
            LilacTopButton(s, 666f, onSwitch, Modifier.tourTarget("home_theme")) {
                Icon(Icons.Filled.Sync, "Trocar layout", tint = Color.White, modifier = Modifier.size(ld(50f, s)))
            }
            LilacTopButton(s, 773f, onHelp, Modifier.tourTarget("home_help")) {
                Text("?", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = (54f * s).sp)
            }
            // Saudação (toque abre a escolha de humor)
            Box(
                Modifier
                    .offset(ld(28f, s), ld(200f, s))
                    .width(ld(412f, s))
                    .clickable(onClick = onMood),
            ) {
                Column {
                    LFitLine(greetText, LilacInk, 58f * s, 28f * s, Modifier.fillMaxWidth(), FontWeight.ExtraBold)
                    Text(
                        "Como está seu dia hoje?",
                        color = LilacIndigo,
                        fontSize = (36f * s).sp,
                        maxLines = 1,
                        softWrap = false,
                        modifier = Modifier.padding(top = ld(8f, s)),
                    )
                }
            }
            // Curva sob a saudação (do índigo ao magenta, sumindo à direita)
            Canvas(Modifier.offset(ld(22f, s), ld(332f, s)).size(ld(360f, s), ld(86f, s))) {
                val w = size.width
                val h = size.height
                val p = Path().apply {
                    moveTo(w * 0.02f, h * 0.97f)
                    cubicTo(w * 0.25f, h * 0.45f, w * 0.55f, h * 0.12f, w * 1.0f, h * 0.14f)
                }
                drawPath(
                    p,
                    Brush.horizontalGradient(listOf(Color(0xFF3A1A9A), Color(0xFFB0189F), Color(0xFFF514C4), Color(0x00F514C4))),
                    style = Stroke(width = (6f * s).dp.toPx(), cap = StrokeCap.Round),
                )
            }
            // Valor mostrado na tela do glicosímetro (a arte vem sem número)
            Column(
                Modifier
                    .offset(ld(641f, s), ld(176f, s))
                    .size(ld(130f, s), ld(100f, s))
                    .rotate(-6f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Text(
                    mg?.toString() ?: "--",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontStyle = FontStyle.Italic,
                    fontSize = (54f * s).sp,
                    maxLines = 1,
                    softWrap = false,
                )
                Text("mg/dL", color = Color.White, fontStyle = FontStyle.Italic, fontSize = (28f * s).sp, maxLines = 1, softWrap = false)
            }
        }

        // ───────────── Linha 1: Última medição | Tempo no alvo ─────────────
        Row(
            sidePad.fillMaxWidth().height(ld(323f, s) * fs),
            horizontalArrangement = Arrangement.spacedBy(ld(17f, s)),
        ) {
            Box(Modifier.weight(1f).fillMaxHeight().lilacCard(s).clickable(onClick = onLast)) {
                LImg(R.drawable.lilac_ic_drop, s, 23f, 8f, 78f, 85f)
                LAt(s, 113f, 50f, 50f, 235f) { LFitLine("Última medição", LilacInk, 30f * s, 14f * s, Modifier.fillMaxWidth(), FontWeight.Medium) }
                Box(Modifier.align(Alignment.TopEnd).padding(end = ld(14f, s), top = ld(28f, s))) { LChevron(s) }
                LAt(s, 52f, 136f, 130f) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(mg?.toString() ?: "--", color = LilacInk, fontWeight = FontWeight.ExtraBold, fontSize = (112f * s).sp, maxLines = 1, softWrap = false)
                        Text("mg/dL", color = LilacIndigo, fontSize = (30f * s).sp, maxLines = 1, softWrap = false, modifier = Modifier.padding(start = ld(10f, s), bottom = ld(22f, s)))
                    }
                }
                if (mg != null) {
                    LilacStatusBadge(s, status, Modifier.offset(ld(35f, s), ld(196f, s)))
                    LAt(s, 113f, 225f, 44f, 250f) { LFitLine(statusText, statusColor, 30f * s, 14f * s, Modifier.fillMaxWidth(), FontWeight.Medium) }
                } else {
                    LAt(s, 40f, 225f, 44f, 330f) { LFitLine("Toque para registrar", LilacInk, 30f * s, 14f * s, Modifier.fillMaxWidth(), FontWeight.Bold) }
                }
                LImg(R.drawable.lilac_ic_clock, s, 28f, 253f, 67f, 62f)
                LAt(s, 111f, 284f, 40f, 262f) { LFitLine(if (mg != null) dateText else "Sem medição ainda", LilacIndigo, 26f * s, 11f * s, Modifier.fillMaxWidth()) }
            }
            Box(Modifier.weight(1f).fillMaxHeight().lilacCard(s).clickable(onClick = onGlucose)) {
                LImg(R.drawable.lilac_ic_target, s, 25f, 13f, 83f, 80f)
                LAt(s, 125f, 50f, 50f, 215f) { LFitLine("Tempo no alvo", LilacInk, 30f * s, 14f * s, Modifier.fillMaxWidth(), FontWeight.Medium) }
                Box(Modifier.align(Alignment.TopEnd).padding(end = ld(14f, s), top = ld(28f, s))) { LChevron(s) }
                LAt(s, 55f, 136f, 130f) {
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(tirPct?.toString() ?: "—", color = LilacInk, fontWeight = FontWeight.ExtraBold, fontSize = (112f * s).sp, maxLines = 1, softWrap = false)
                        if (tirPct != null) {
                            Text("%", color = LilacInk, fontWeight = FontWeight.ExtraBold, fontSize = (62f * s).sp, maxLines = 1, softWrap = false, modifier = Modifier.padding(start = ld(4f, s), bottom = ld(14f, s)))
                        }
                    }
                }
                Box(
                    Modifier
                        .padding(start = ld(30f, s), top = ld(208f, s), end = ld(26f, s))
                        .fillMaxWidth()
                        .height(ld(30f, s))
                        .clip(RoundedCornerShape(ld(15f, s)))
                        .background(Brush.horizontalGradient(listOf(Color(0xFFF9C4F5), Color(0xFFFBDDF8)))),
                ) {
                    val frac = ((tirPct ?: 0).coerceIn(0, 100)) / 100f
                    if (frac > 0f) {
                        Box(
                            Modifier
                                .fillMaxWidth(frac)
                                .fillMaxHeight()
                                .clip(RoundedCornerShape(ld(15f, s)))
                                .background(Brush.horizontalGradient(listOf(Color(0xFFE8039F), Color(0xFFF21CB8)))),
                        )
                    }
                }
                LImg(R.drawable.lilac_ic_calendar, s, 25f, 253f, 63f, 62f)
                LAt(s, 102f, 284f, 40f, 262f) { LFitLine(if (tirPct != null) "Últimos 7 dias" else "Sem medições em 7 dias", LilacIndigo, 26f * s, 11f * s, Modifier.fillMaxWidth()) }
            }
        }

        Spacer(Modifier.height(ld(25f, s)))

        // ───────────── Linha 2: Glicemias | Insulinas ─────────────
        Row(
            sidePad.fillMaxWidth().height(ld(258f, s) * fs),
            horizontalArrangement = Arrangement.spacedBy(ld(17f, s)),
        ) {
            @Composable
            fun SmallCard(
                title: String,
                value: Int,
                topIcon: Int,
                topBox: FloatArray,
                bottomIcon: Int,
                bottomBox: FloatArray,
                textX: Float,
                modifier: Modifier,
                onClick: () -> Unit,
            ) {
                Box(
                    modifier
                        .fillMaxHeight()
                        .lilacCard(s)
                        .drawBehind {
                            val w = size.width
                            val h = size.height
                            val wave = Path().apply {
                                moveTo(w * 0.22f, h * 0.88f)
                                cubicTo(w * 0.48f, h * 0.60f, w * 0.78f, h * 0.74f, w, h * 0.46f)
                                lineTo(w, h)
                                lineTo(w * 0.22f, h)
                                close()
                            }
                            drawPath(wave, Brush.verticalGradient(listOf(Color(0x66F5A8EE), Color(0x22F9D0F5))))
                            val crest = Path().apply {
                                moveTo(w * 0.22f, h * 0.88f)
                                cubicTo(w * 0.48f, h * 0.60f, w * 0.78f, h * 0.74f, w, h * 0.46f)
                            }
                            drawPath(crest, Color.White.copy(alpha = 0.85f), style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round))
                        }
                        .clickable(onClick = onClick),
                ) {
                    LImg(topIcon, s, topBox[0], topBox[1], topBox[2], topBox[3])
                    LAt(s, 114f, 50f, 50f, 225f) { LFitLine(title, LilacInk, 30f * s, 12f * s, Modifier.fillMaxWidth(), FontWeight.Medium) }
                    Box(Modifier.align(Alignment.TopEnd).padding(end = ld(14f, s), top = ld(28f, s))) { LChevron(s) }
                    LAt(s, 38f, 134f, 120f) {
                        Text(value.toString(), color = LilacInk, fontWeight = FontWeight.ExtraBold, fontSize = (104f * s).sp, maxLines = 1, softWrap = false)
                    }
                    LImg(bottomIcon, s, bottomBox[0], bottomBox[1], bottomBox[2], bottomBox[3])
                    LAt(s, textX, 221f, 40f, 190f) { LFitLine("Registros recentes", LilacIndigo, 26f * s, 11f * s, Modifier.fillMaxWidth()) }
                }
            }
            SmallCard("Glicemias (7 dias)", weekG, R.drawable.lilac_ic_bars, floatArrayOf(28f, 15f, 73f, 70f), R.drawable.lilac_ic_chartup, floatArrayOf(28f, 188f, 67f, 64f), 110f, Modifier.weight(1f), onGlucose)
            SmallCard("Insulinas (7 dias)", weekI, R.drawable.lilac_ic_syringe, floatArrayOf(25f, 15f, 80f, 70f), R.drawable.lilac_ic_jar, floatArrayOf(28f, 188f, 60f, 64f), 102f, Modifier.weight(1f), onInsulin)
        }

        Spacer(Modifier.height(ld(24f, s)))

        // ───────────── Cris IA ─────────────
        Box(
            sidePad.fillMaxWidth().height(ld(190f, s)).lilacCard(s, tint = true).clickable(onClick = onCris),
        ) {
            LImg(R.drawable.lilac_robot, s, 16f, 5f, 182f, 179f)
            LImg(R.drawable.lilac_spark_l, s, 242f, 34f, 46f, 47.5f)
            LAt(s, 299f, 60f, 60f, 140f) { Text("Cris IA", color = LilacIndigo, fontWeight = FontWeight.ExtraBold, fontSize = (44f * s).sp, maxLines = 1, softWrap = false) }
            LImg(R.drawable.lilac_spark_r, s, 425f, 36f, 50f, 49f)
            Text(
                "Sua assistente inteligente para acompanhar sua rotina de saúde.",
                color = LilacIndigo,
                fontSize = (28f * s).sp,
                lineHeight = (33f * s).sp,
                modifier = Modifier.offset(ld(240f, s), ld(96f, s)).width(ld(345f, s)),
            )
            Row(
                Modifier
                    .offset(ld(601f, s), ld(36f, s))
                    .size(ld(185f, s), ld(69f, s))
                    .shadow(6.dp, RoundedCornerShape(50), clip = false, ambientColor = Color(0xFFB0109A), spotColor = Color(0xFFB0109A))
                    .clip(RoundedCornerShape(50))
                    .background(Brush.verticalGradient(listOf(Color(0xFFC41FBE), Color(0xFF8E0AA0), Color(0xFF6A0A80))))
                    .border(1.5.dp, Brush.verticalGradient(listOf(Color(0xFFF08BE6), Color(0xFF7A1A9A))), RoundedCornerShape(50))
                    .clickable(onClick = onCris),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
            ) {
                Text("Saiba mais", color = Color.White, fontWeight = FontWeight.Bold, fontSize = (27f * s).sp, maxLines = 1, softWrap = false)
                Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Color.White, modifier = Modifier.size(ld(34f, s)))
            }
        }

        Spacer(Modifier.height(ld(25f, s)))

        // ───────────── Mensagem fixa + frase motivadora do dia (100 frases, uma por dia) ─────────────
        LoveMessageCard(phrase, LoveCardPurple, sidePad)

        Spacer(Modifier.height(ld(24f, s)))
    }
}
