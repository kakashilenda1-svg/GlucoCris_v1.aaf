package com.agon.app.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.core.content.ContextCompat
import com.agon.app.data.LocatorSearch
import com.agon.app.data.insulin.CityIndex
import com.agon.app.data.insulin.CityTier
import com.agon.app.viewmodel.LocState
import com.agon.app.viewmodel.Origin
import com.agon.app.viewmodel.OriginKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudOff
import androidx.compose.material.icons.filled.LocationOff
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.agon.app.data.insulin.BrazilGeo
import com.agon.app.data.insulin.ChannelType
import com.agon.app.data.insulin.City
import com.agon.app.data.insulin.GuideCard
import com.agon.app.data.insulin.InsulinGuide
import com.agon.app.data.insulin.InsulinCatalog
import com.agon.app.data.insulin.LocatorResult
import com.agon.app.data.insulin.LocatorScope
import com.agon.app.data.insulin.PriceTier
import com.agon.app.data.insulin.SortMode
import com.agon.app.data.insulin.SupplyNetwork
import com.agon.app.data.HealthPlace
import com.agon.app.data.PlaceFinder
import com.agon.app.data.PlaceKind
import com.agon.app.data.insulin.SupplyPoint
import com.agon.app.ui.theme.glucoColors
import com.agon.app.viewmodel.LocatorViewModel

private const val MAX_VISIBLE = 120

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun InsulinLocatorScreen(
    nav: NavHostController,
    lvm: LocatorViewModel = viewModel(),
) {
    val g = glucoColors()
    val focus = LocalFocusManager.current
    var selectedPoint by remember { mutableStateOf<SupplyPoint?>(null) }
    var history by remember { mutableStateOf(listOf<String>()) }
    var citySearch by remember { mutableStateOf("") }
    var realPlaces by remember { mutableStateOf<List<HealthPlace>>(emptyList()) }
    var realLoading by remember { mutableStateOf(false) }
    var realError by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val uiScope = rememberCoroutineScope()
    var placeJob by remember { mutableStateOf<Job?>(null) }
    var locateTick by remember { mutableIntStateOf(0) }
    var indexVersion by remember { mutableIntStateOf(0) }

    // Lista de municípios do IBGE (se estiver nos assets) carrega em segundo plano; sem o arquivo, nada muda.
    LaunchedEffect(Unit) {
        val before = CityIndex.size
        CityIndex.loadIbge(context)
        if (CityIndex.size != before) indexVersion++
    }

    val origin: Origin? = lvm.origin
    val reference: City? = origin?.refCity
        ?: lvm.cityId?.let { CityIndex.byId(it) }
        ?: lvm.uf?.let { BrazilGeo.capitalOf(it) }

    // Busca em segundo plano: interpreta o texto (acento, apelido, correção) e monta os pontos fora da thread
    // principal. Cada nova tecla cancela a conta anterior; a lista anterior fica na tela até a nova ficar pronta.
    var result by remember { mutableStateOf(LocatorResult(emptyList(), emptyList(), 0, 0)) }
    var resolved by remember { mutableStateOf(LocatorSearch.EMPTY) }
    var searching by remember { mutableStateOf(true) }
    val query = lvm.query
    LaunchedEffect(query, reference, indexVersion) {
        searching = true
        if (query.text.isNotBlank()) delay(150) // espera a pessoa parar de digitar
        val (res, rsl) = withContext(Dispatchers.Default) {
            val r = if (query.text.isBlank()) LocatorSearch.EMPTY else LocatorSearch.resolve(query.text)
            SupplyNetwork.search(query, reference, r) to r
        }
        result = res
        resolved = rsl
        searching = false
    }
    var visibleLimit by remember(result) { mutableIntStateOf(MAX_VISIBLE) }
    val visiblePoints = result.points.take(visibleLimit)

    // ---- "Perto de mim" (GPS) — é o padrão ao abrir a tela
    fun hasLocationPermission(): Boolean =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        if (grants.values.any { it }) {
            locateTick++
        } else {
            lvm.locState = LocState.DENIED
        }
    }

    fun nearMe() {
        if (hasLocationPermission()) {
            locateTick++
        } else {
            lvm.locState = LocState.ASKING
            permLauncher.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
        }
    }

    var awaitingSettings by remember { mutableStateOf(false) }
    val lifecycleOwner = context as? LifecycleOwner
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME && awaitingSettings) {
                awaitingSettings = false
                if (hasLocationPermission()) locateTick++
            }
        }
        lifecycleOwner?.lifecycle?.addObserver(observer)
        onDispose { lifecycleOwner?.lifecycle?.removeObserver(observer) }
    }

    fun fixLocation() {
        when (lvm.locState) {
            LocState.DISABLED -> {
                awaitingSettings = true
                runCatching {
                    context.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }
            }
            LocState.DENIED -> {
                awaitingSettings = true
                runCatching {
                    context.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                }
            }
            else -> nearMe()
        }
    }

    LaunchedEffect(Unit) {
        if (!lvm.autoLocateTried && lvm.origin == null && lvm.scope == LocatorScope.BRASIL) {
            lvm.autoLocateTried = true
            nearMe()
        }
    }

    LaunchedEffect(locateTick) {
        if (locateTick == 0) return@LaunchedEffect
        lvm.locState = LocState.LOCATING
        if (!PlaceFinder.locationEnabled(context)) {
            lvm.locState = LocState.DISABLED
            return@LaunchedEffect
        }
        val loc = PlaceFinder.currentLocation(context)
        if (loc == null) {
            lvm.locState = LocState.FAILED
            return@LaunchedEffect
        }
        val lat = loc.latitude
        val lon = loc.longitude
        val info = PlaceFinder.reverseInfo(lat, lon)
        // Sem internet para descobrir o município, não chutamos o mais próximo: a busca fica pelo ponto.
        val infoCity = info?.city
        val city = if (info != null && infoCity != null) {
            CityIndex.find(infoCity, info.uf) ?: cityFrom(infoCity, info.uf, lat, lon)
        } else {
            null
        }
        val label = listOfNotNull(
            info?.area,
            city?.let { c -> if (c.uf.isNotBlank()) "${c.name}/${c.uf}" else c.name },
        ).joinToString(", ").ifBlank { "Sua localização" }
        lvm.applyOrigin(Origin(lat, lon, label, OriginKind.GPS, city))
        lvm.locState = LocState.READY
        lvm.filtersExpanded = false
    }

    // ---- Buscar cidade, bairro, rua ou CEP
    fun applyHit(h: PlaceFinder.GeoHit) {
        val ufOrNull = h.uf.ifBlank { null }
        val city = if (h.city.isBlank()) null else (CityIndex.find(h.city, ufOrNull) ?: cityFrom(h.city, ufOrNull, h.lat, h.lon))
        lvm.applyOrigin(Origin(h.lat, h.lon, h.label, OriginKind.BUSCA, city, approximate = h.approximate))
        lvm.placeQuery = ""
        lvm.filtersExpanded = false
    }

    fun submitPlace() {
        val q = lvm.placeQuery.trim()
        if (q.length < 2) return
        focus.clearFocus()
        placeJob?.cancel()
        placeJob = uiScope.launch {
            lvm.placeBusy = true
            lvm.placeMsg = null
            lvm.placeChoices = emptyList()
            lvm.placeSuggestion = null
            try {
                val isCep = PlaceFinder.cepOrNull(q) != null
                val local = if (isCep) emptyList() else CityIndex.exactMatches(q)
                when {
                    local.size == 1 -> {
                        val c = local[0]
                        lvm.applyOrigin(Origin(c.lat, c.lon, c.label, OriginKind.MUNICIPIO, c))
                        lvm.placeQuery = ""
                        lvm.filtersExpanded = false
                        return@launch
                    }
                    local.size > 1 -> {
                        lvm.placeChoices = local.take(8).map { PlaceFinder.GeoHit(it.label, it.lat, it.lon, it.name, it.uf) }
                        lvm.placeMsg = "Mais de um município com esse nome. Escolha:"
                        return@launch
                    }
                }
                val hits = PlaceFinder.geocodeDetailed(q)
                when {
                    hits == null -> {
                        val offline = if (isCep) emptyList() else CityIndex.search(q, 6)
                        if (offline.isNotEmpty()) {
                            lvm.placeChoices = offline.map { PlaceFinder.GeoHit(it.label, it.lat, it.lon, it.name, it.uf) }
                            lvm.placeMsg = "Sem conexão para buscar “$q”. Estes municípios estão disponíveis offline:"
                        } else {
                            lvm.placeMsg = "Sem conexão para buscar “$q”. Bairros, ruas e CEP precisam de internet."
                        }
                    }
                    hits.isEmpty() -> {
                        lvm.placeMsg = if (isCep) "CEP não encontrado. Confira os números." else "Não encontrei “$q”. Confira a grafia ou tente o CEP."
                        lvm.placeSuggestion = if (isCep) null else CityIndex.suggest(LocatorSearch.norm(q))?.label
                    }
                    hits.size == 1 -> applyHit(hits[0])
                    else -> {
                        lvm.placeChoices = hits
                        lvm.placeMsg = "Encontrei mais de um lugar. Escolha:"
                    }
                }
            } finally {
                lvm.placeBusy = false
            }
        }
    }

    fun setText(t: String) {
        lvm.text = t
        // O que a pessoa digita vale mais do que os chips de tipo/marca escolhidos antes
        if (t.isNotBlank()) {
            lvm.productId = "all"
            lvm.categoryIds = emptySet()
        }
    }

    // Locais reais (OSM) — busca rápida: raio menor, farmácias primeiro, mostra assim que chegar
    LaunchedEffect(lvm.origin) {
        val city = lvm.origin // Origin tem lat/lon, igual a um município
        if (city == null) {
            realPlaces = emptyList()
            realError = null
            realLoading = false
            return@LaunchedEffect
        }
        realLoading = true
        realError = null
        realPlaces = emptyList()
        val prevTimeout = com.agon.app.data.LocatorConfig.mirrorTimeoutMs
        val prevHedge = com.agon.app.data.LocatorConfig.hedgeDelayMs
        val prevBudget = com.agon.app.data.LocatorConfig.sourceBudgetMs
        val prevAttempts = com.agon.app.data.LocatorConfig.maxAttempts
        com.agon.app.data.LocatorConfig.mirrorTimeoutMs = 4_000L
        com.agon.app.data.LocatorConfig.hedgeDelayMs = 200L
        com.agon.app.data.LocatorConfig.sourceBudgetMs = 8_000L
        com.agon.app.data.LocatorConfig.maxAttempts = 1
        try {
            // Fase 1: só farmácias, raio 3 km (bem mais rápido no Overpass)
            PlaceFinder.searchFlow(
                context = context,
                lat = city.lat,
                lon = city.lon,
                radiusKm = 3,
                only = setOf(com.agon.app.data.SRC_FARMACIAS),
            ).collect { state ->
                val filtered = state.places
                    .filter { it.kind == PlaceKind.FARMACIA || it.kind == PlaceKind.UBS }
                    .sortedBy { it.distanceKm }
                    .take(30)
                if (filtered.isNotEmpty()) {
                    realPlaces = filtered
                    realLoading = false
                }
                if (state.finished) realLoading = false
            }
            // Fase 2: se ainda vazio, amplia para 5 km com UBS/unidades
            if (realPlaces.isEmpty()) {
                realLoading = true
                PlaceFinder.searchFlow(
                    context = context,
                    lat = city.lat,
                    lon = city.lon,
                    radiusKm = 5,
                ).collect { state ->
                    val filtered = state.places
                        .filter {
                            it.kind == PlaceKind.FARMACIA || it.kind == PlaceKind.UBS || it.kind == PlaceKind.HOSPITAL
                        }
                        .sortedBy { it.distanceKm }
                        .take(40)
                    if (filtered.isNotEmpty()) {
                        realPlaces = filtered
                        realLoading = false
                    }
                    if (state.finished) {
                        realLoading = false
                        if (realPlaces.isEmpty()) {
                            realError = "Não encontramos estabelecimentos com endereço nesta área. Tente outro município."
                        }
                    }
                }
            }
        } catch (e: kotlinx.coroutines.CancellationException) {
            // Troca de origem/saída da tela cancela a busca: não é falha, e a exceção precisa seguir adiante.
            throw e
        } catch (e: Exception) {
            realLoading = false
            if (realPlaces.isEmpty()) {
                realError = "Falha ao buscar locais. Verifique a conexão e tente de novo."
            }
        } finally {
            com.agon.app.data.LocatorConfig.mirrorTimeoutMs = prevTimeout
            com.agon.app.data.LocatorConfig.hedgeDelayMs = prevHedge
            com.agon.app.data.LocatorConfig.sourceBudgetMs = prevBudget
            com.agon.app.data.LocatorConfig.maxAttempts = prevAttempts
        }
    }


    LaunchedEffect(lvm.text) {
        // Guarda no histórico só quando a pessoa para de digitar (não a cada letra)
        val t = lvm.text.trim()
        if (t.length < 3) return@LaunchedEffect
        delay(1_500)
        if (lvm.text.trim() != t) return@LaunchedEffect
        if (t !in history) history = (listOf(t) + history).take(12)
    }

    fun commitSearch() {
        val t = lvm.text.trim()
        if (t.isBlank()) {
            focus.clearFocus()
            return
        }
        if (t !in history) history = (listOf(t) + history).take(12)
        // O texto já filtra a lista (LocatorSearch); não precisa escolher produto sozinho
        focus.clearFocus()
        selectedPoint = null
    }

    val restricted = lvm.text.isNotBlank() || lvm.productId != "all" || lvm.categoryIds.isNotEmpty()
    val guideCards = remember(result.matchedProducts, restricted) {
        if (restricted && result.matchedProducts.isNotEmpty() && result.matchedProducts.size < InsulinCatalog.products.size) {
            InsulinGuide.build(result.matchedProducts)
        } else {
            emptyList()
        }
    }
    val waMessage = remember(result.matchedProducts, restricted) {
        InsulinGuide.message(if (restricted) result.matchedProducts else emptyList())
    }

    // Situação do "Perto de mim"
    val locStatus: String? = when (lvm.locState) {
        LocState.ASKING -> "Aguardando sua permissão de localização…"
        LocState.LOCATING -> "Obtendo sua localização…"
        LocState.DENIED -> "Sem permissão de localização. Busque uma cidade, bairro ou CEP em Filtros, ou libere nas configurações do aparelho."
        LocState.DISABLED -> "A localização do celular está desligada. Ligue-a ou busque uma cidade, bairro ou CEP em Filtros."
        LocState.FAILED -> "Não consegui obter sua posição agora. Tente “Perto de mim” de novo em Filtros ou busque uma cidade, bairro ou CEP."
        LocState.READY -> origin?.takeIf { it.kind == OriginKind.GPS }
            ?.let { "Usando sua localização (${it.label}). Ela é enviada ao OpenStreetMap só para achar os locais próximos." }
        LocState.IDLE -> null
    }

    Column(Modifier.fillMaxSize().background(g.bg)) {
        // ---- Topo fixo: voltar, título/local e um único botão Filtros
        Row(
            Modifier.fillMaxWidth().background(g.card).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = g.ink,
                modifier = Modifier.size(28.dp).clickable { nav.popBackStack() },
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f).clickable { lvm.filtersExpanded = true }) {
                Text("Localizador de Insulinas", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = g.ink)
                Text(
                    origin?.let { if (it.kind == OriginKind.GPS) "Perto de mim · ${it.label}" else it.label }
                        ?: when (lvm.scope) {
                            LocatorScope.BRASIL -> "Todo o Brasil"
                            LocatorScope.UF -> BrazilGeo.ufByCode(lvm.uf ?: "")?.name ?: lvm.uf ?: ""
                            LocatorScope.CIDADE -> CityIndex.byId(lvm.cityId ?: "")?.label ?: ""
                        },
                    fontSize = 12.sp, color = g.muted, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            val hasFilters = lvm.activeFilterCount > 0
            Row(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (hasFilters) g.violet else g.card)
                    .border(1.dp, if (hasFilters) g.violet else g.line, RoundedCornerShape(20.dp))
                    .clickable { lvm.filtersExpanded = true }
                    .padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Default.FilterList, null, tint = if (hasFilters) Color.White else g.violet, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    if (hasFilters) "Filtros · ${lvm.activeFilterCount}" else "Filtros",
                    fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    color = if (hasFilters) Color.White else g.violet,
                )
            }
        }

        // ---- Busca fixa
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(g.inputBg)
                .border(1.dp, g.line, RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Default.Search, null, tint = g.muted, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            BasicTextField(
                value = lvm.text,
                onValueChange = { setText(it) },
                singleLine = true,
                textStyle = TextStyle(fontFamily = com.agon.app.ui.theme.appFontFamily(), color = g.ink, fontSize = 15.sp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { commitSearch() }),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    if (lvm.text.isEmpty()) {
                        Text("Insulina: Lantus, NPH, rápida, cristalina…", color = g.muted, fontSize = 14.sp)
                    }
                    inner()
                },
            )
            if (lvm.text.isNotEmpty()) {
                Icon(
                    Icons.Default.Close, "Limpar", tint = g.muted,
                    modifier = Modifier.size(18.dp).clickable { lvm.text = "" },
                )
            }
        }

        // "Você quis dizer…" (nunca aplicado sozinho), município citado no texto e palavras ignoradas
        val sug = resolved.suggestion
        if (lvm.text.isNotBlank() && sug != null) {
            Text(
                "Você quis dizer “$sug”?",
                color = g.violet, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 2.dp)
                    .clickable { setText(sug); focus.clearFocus() },
            )
        }
        val cityHint = resolved.cityHint
        if (lvm.text.isNotBlank() && cityHint != null && lvm.cityId != cityHint.id) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 2.dp)) {
                MiniChip("Buscar em ${cityHint.label}", selected = false, g = g) {
                    lvm.selectCity(cityHint.id, cityHint.uf)
                    focus.clearFocus()
                }
            }
        }
        if (lvm.text.isNotBlank() && resolved.unknown.isNotEmpty() && resolved.textProducts?.isNotEmpty() == true) {
            Text(
                "Não reconheci: ${resolved.unknown.joinToString(", ")}",
                color = g.muted, fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 2.dp),
            )
        }

        // ---- Uma só lista rolável
        LazyColumn(
            state = rememberLazyListState(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f),
        ) {
            val isLocProblem = lvm.locState == LocState.DENIED || lvm.locState == LocState.DISABLED || lvm.locState == LocState.FAILED
            if (isLocProblem) {
                // O aviso some quando a pessoa já escolheu um local (cidade, estado, bairro ou CEP)
                if (origin == null && lvm.scope == LocatorScope.BRASIL) {
                    item(key = "loc-status") {
                        LocationAlertCard(
                            title = when (lvm.locState) {
                                LocState.DENIED -> "Sem permissão de localização"
                                LocState.FAILED -> "Não consegui obter sua posição"
                                else -> "Localização desligada"
                            },
                            message = when (lvm.locState) {
                                LocState.DENIED -> "Libere a localização nas configurações do app para ver farmácias e UBS perto de você."
                                LocState.FAILED -> "Tente de novo ou busque uma cidade, bairro ou CEP."
                                else -> "Ative para ver farmácias e UBS perto de você."
                            },
                            primaryLabel = if (lvm.locState == LocState.FAILED) "Tentar de novo" else "Ativar",
                            onPrimary = { fixLocation() },
                            onSearchCity = { lvm.filtersExpanded = true },
                            g = g,
                        )
                    }
                }
            } else if (locStatus != null) {
                item(key = "loc-status") {
                    Text(locStatus, fontSize = 12.sp, lineHeight = 16.sp, color = g.muted)
                }
            }

            if (lvm.text.isBlank() && history.isNotEmpty()) {
                item(key = "history") {
                    Column {
                        Text("Buscas recentes", fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = g.muted)
                        Spacer(Modifier.height(4.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(history) { h ->
                                MiniChip(h, selected = false, g = g) {
                                    setText(h)
                                    commitSearch()
                                }
                            }
                        }
                    }
                }
            }

            // Resumo
            item(key = "summary") {
                Row(verticalAlignment = Alignment.Top) {
                    FlowRow(
                        Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        InfoChip(countLabel(result.points.size, "local", "locais"), g)
                        InfoChip(countLabel(result.citiesCovered, "cidade", "cidades"), g)
                        InfoChip(countLabel(result.matchedProducts.size, "insulina", "insulinas"), g)
                        InfoChip("Offline: ${CityIndex.size} municípios", g, Icons.Default.CloudOff)
                    }
                    if (searching) {
                        Spacer(Modifier.width(8.dp))
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = g.violet)
                    }
                }
            }

            // Onde pegar cada insulina do resultado
            items(guideCards, key = { "guide-" + it.headline + it.products }) { card ->
                GuideCardView(card = card, g = g)
            }

            // Locais reais com endereço
            if (origin != null) {
                item(key = "real-title") {
                    Column {
                        Text(
                            if (origin.kind == OriginKind.GPS) "Locais reais perto de você" else "Locais reais próximos",
                            fontWeight = FontWeight.Bold, fontSize = 15.sp, color = g.ink,
                            modifier = Modifier.padding(top = 4.dp, bottom = 2.dp),
                        )
                        Text(
                            "Farmácias, UBS e hospitais com endereço do mapa (OpenStreetMap). Confirme no local se a insulina desejada está disponível." +
                                if (origin.approximate) " Não achamos o endereço exato: mostrando locais perto do bairro ou da cidade do CEP." else "",
                            fontSize = 12.sp, color = g.muted, lineHeight = 16.sp,
                        )
                    }
                }
                if (realLoading && realPlaces.isEmpty()) {
                    item(key = "real-loading") {
                        Row(
                            Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            horizontalArrangement = Arrangement.Center,
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.dp, color = g.violet)
                            Spacer(Modifier.width(10.dp))
                            Text("Buscando farmácias próximas…", color = g.muted, fontSize = 13.sp)
                        }
                    }
                }
                if (realError != null && realPlaces.isEmpty()) {
                    item(key = "real-error") {
                        Text(realError ?: "", color = g.orange, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp))
                    }
                }
                items(realPlaces, key = { "real-" + it.id }) { place ->
                    RealPlaceCard(place = place, waMessage = waMessage, g = g)
                }
                item(key = "channels-title") {
                    Column {
                        Spacer(Modifier.height(8.dp))
                        Text(
                            "Canais de acesso (orientação por tipo)",
                            fontWeight = FontWeight.Bold, fontSize = 15.sp, color = g.ink,
                            modifier = Modifier.padding(top = 8.dp, bottom = 2.dp),
                        )
                        Text(
                            "Indica onde esse tipo de insulina costuma ser dispensada (SUS, Farmácia Popular, CEAF ou rede privada).",
                            fontSize = 12.sp, color = g.muted, lineHeight = 16.sp,
                        )
                    }
                }
            }

            if (visiblePoints.isEmpty() && origin == null && !searching) {
                item(key = "empty") {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "Nenhum ponto encontrado.\nAmplie o escopo ou mude a insulina/filtros.",
                            color = g.muted, fontSize = 14.sp, lineHeight = 20.sp,
                        )
                    }
                }
            }
            items(visiblePoints, key = { it.id }) { point ->
                SupplyPointCard(
                    point = point,
                    products = result.matchedProducts.filter { it.id in point.productIds },
                    selected = selectedPoint?.id == point.id,
                    onClick = { selectedPoint = if (selectedPoint?.id == point.id) null else point },
                    g = g,
                )
            }
            if (result.points.size > MAX_VISIBLE) {
                item(key = "load-more") {
                    Column(
                        Modifier.fillMaxWidth().padding(top = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                    ) {
                        Text(
                            "Mostrando ${visiblePoints.size} de ${result.points.size} locais",
                            fontSize = 12.sp, color = g.muted,
                        )
                        if (result.points.size > visibleLimit) {
                            Spacer(Modifier.height(8.dp))
                            Text(
                                "Carregar mais",
                                fontSize = 13.sp, fontWeight = FontWeight.Medium, color = g.violet,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .border(1.dp, g.line, RoundedCornerShape(50))
                                    .clickable { visibleLimit += MAX_VISIBLE }
                                    .padding(horizontal = 18.dp, vertical = 8.dp),
                            )
                        }
                    }
                }
            }
            item(key = "bottom-space") { Spacer(Modifier.height(24.dp)) }
        }
    }

    // ---- Painel de filtros (um só): tipo, marca, canal, gratuito, ordem e local
    if (lvm.filtersExpanded) {
        ModalBottomSheet(
            onDismissRequest = { lvm.filtersExpanded = false },
            sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
            containerColor = g.bg,
        ) {
            val productsForChips = remember(lvm.categoryIds) {
                if (lvm.categoryIds.isEmpty()) InsulinCatalog.products
                else InsulinCatalog.products.filter { it.categoryId in lvm.categoryIds }
            }
            Column(
                Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .navigationBarsPadding()
                    .imePadding()
                    .padding(horizontal = 14.dp)
                    .padding(bottom = 24.dp),
            ) {
                SheetTitle("Tipo de insulina", g)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    MiniChip("Todas", selected = lvm.categoryIds.isEmpty() && lvm.productId == "all", g = g) {
                        lvm.text = ""
                        lvm.categoryIds = emptySet()
                        lvm.productId = "all"
                    }
                    listOf(
                        "nph" to "NPH",
                        "regular" to "Regular",
                        "analogo_rapido" to "Rápida / bolus",
                        "analogo_longo" to "Basal longa",
                        "pre_mistura" to "Pré-mistura",
                    ).forEach { (id, label) ->
                        MiniChip(label, selected = id in lvm.categoryIds, g = g) { lvm.text = ""; lvm.toggleCategory(id) }
                    }
                }

                SheetTitle("Marca / produto", g)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    MiniChip("Todas", selected = lvm.productId == "all", g = g) {
                        lvm.text = ""
                        lvm.productId = "all"
                    }
                    productsForChips.forEach { p ->
                        MiniChip(p.brandName, selected = lvm.productId == p.id, g = g) {
                            lvm.text = ""
                            lvm.productId = if (lvm.productId == p.id) "all" else p.id
                        }
                    }
                }

                SheetTitle("Canal de acesso", g)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ChannelType.entries.forEach { ch ->
                        MiniChip(ch.short, selected = ch.id in lvm.channelIds, g = g) { lvm.toggleChannel(ch.id) }
                    }
                }

                SheetTitle("Preço", g)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    MiniChip("Todos os preços", selected = !lvm.onlyFree, g = g) { lvm.onlyFree = false }
                    MiniChip("Só gratuito", selected = lvm.onlyFree, g = g) { lvm.onlyFree = true }
                }

                SheetTitle("Ordenar por", g)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SortMode.entries.forEach { m ->
                        MiniChip(m.label, selected = lvm.sort == m, g = g) { lvm.sort = m }
                    }
                }

                SheetTitle("Local", g)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    MiniChip(
                        if (lvm.locState == LocState.LOCATING || lvm.locState == LocState.ASKING) "Perto de mim…" else "Perto de mim",
                        selected = origin?.kind == OriginKind.GPS,
                        g = g,
                    ) { nearMe() }
                    MiniChip("Brasil", selected = lvm.scope == LocatorScope.BRASIL && origin == null, g = g) { lvm.selectBrazil() }
                }
                Spacer(Modifier.height(8.dp))
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    BrazilGeo.ufs.forEach { uf ->
                        MiniChip(uf.code, selected = lvm.uf == uf.code, g = g) {
                            if (lvm.uf == uf.code && lvm.scope == LocatorScope.UF) {
                                lvm.selectBrazil()
                            } else {
                                lvm.selectUf(uf.code)
                                citySearch = ""
                            }
                        }
                    }
                }
                if (locStatus != null) {
                    Text(
                        locStatus,
                        fontSize = 11.sp, lineHeight = 15.sp,
                        color = if (lvm.locState == LocState.DENIED || lvm.locState == LocState.DISABLED || lvm.locState == LocState.FAILED) g.orange else g.muted,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }

                // Qualquer cidade, bairro, rua ou CEP
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 10.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(g.inputBg)
                        .border(1.dp, g.line, RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Default.LocationOn, null, tint = g.muted, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    BasicTextField(
                        value = lvm.placeQuery,
                        onValueChange = { lvm.placeQuery = it; lvm.placeMsg = null; lvm.placeChoices = emptyList(); lvm.placeSuggestion = null },
                        singleLine = true,
                        textStyle = TextStyle(fontFamily = com.agon.app.ui.theme.appFontFamily(), color = g.ink, fontSize = 13.sp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { submitPlace() }),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            if (lvm.placeQuery.isEmpty()) Text("Cidade, bairro ou CEP…", color = g.muted, fontSize = 13.sp)
                            inner()
                        },
                    )
                    if (lvm.placeBusy) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = g.violet)
                    } else if (lvm.placeQuery.isNotEmpty()) {
                        Icon(
                            Icons.Default.Search, "Buscar", tint = g.violet,
                            modifier = Modifier.size(20.dp).clickable { submitPlace() },
                        )
                    }
                }
                val typedPlace = lvm.placeQuery
                val placeHints = remember(typedPlace, indexVersion) {
                    if (typedPlace.trim().length >= 2 && PlaceFinder.cepOrNull(typedPlace) == null) CityIndex.search(typedPlace, 6) else emptyList()
                }
                if (placeHints.isNotEmpty() && lvm.placeChoices.isEmpty()) {
                    FlowRow(
                        Modifier.padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        placeHints.forEach { c ->
                            MiniChip(c.label, selected = false, g = g) {
                                lvm.selectCity(c.id, c.uf)
                                lvm.placeQuery = ""
                                lvm.filtersExpanded = false
                            }
                        }
                    }
                }
                lvm.placeMsg?.let { msg ->
                    Text(msg, fontSize = 12.sp, color = g.orange, modifier = Modifier.padding(top = 6.dp))
                }
                lvm.placeSuggestion?.let { sugg ->
                    Text(
                        "Você quis dizer “$sugg”?",
                        color = g.violet, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(top = 4.dp).clickable { lvm.placeQuery = sugg; submitPlace() },
                    )
                }
                if (lvm.placeChoices.isNotEmpty()) {
                    FlowRow(
                        Modifier.padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        lvm.placeChoices.forEach { h ->
                            MiniChip(h.label, selected = false, g = g) {
                                val known = if (h.city.isBlank()) null else CityIndex.find(h.city, h.uf.ifBlank { null })
                                if (known != null && h.lat == known.lat && h.lon == known.lon) {
                                    lvm.applyOrigin(Origin(known.lat, known.lon, known.label, OriginKind.MUNICIPIO, known))
                                    lvm.placeQuery = ""
                                    lvm.filtersExpanded = false
                                } else {
                                    applyHit(h)
                                }
                            }
                        }
                    }
                }

                // Municípios do estado escolhido
                val ufCode = lvm.uf
                if (ufCode != null && (origin == null || origin.kind == OriginKind.MUNICIPIO)) {
                    val cities = remember(ufCode, citySearch, indexVersion) {
                        val base = CityIndex.citiesOf(ufCode)
                        val q = LocatorSearch.norm(citySearch).trim()
                        (if (q.isBlank()) base else base.filter { LocatorSearch.norm(it.name).contains(q) }).take(60)
                    }
                    BasicTextField(
                        value = citySearch,
                        onValueChange = { citySearch = it },
                        singleLine = true,
                        textStyle = TextStyle(fontFamily = com.agon.app.ui.theme.appFontFamily(), color = g.ink, fontSize = 13.sp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 10.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(g.inputBg)
                            .border(1.dp, g.line, RoundedCornerShape(10.dp))
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                        decorationBox = { inner ->
                            if (citySearch.isEmpty()) Text("Filtrar município de $ufCode…", color = g.muted, fontSize = 13.sp)
                            inner()
                        },
                    )
                    FlowRow(
                        Modifier.padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp),
                    ) {
                        MiniChip("Todo o estado", selected = lvm.scope == LocatorScope.UF && lvm.cityId == null, g = g) { lvm.selectUf(ufCode) }
                        cities.forEach { city ->
                            MiniChip(city.name, selected = lvm.cityId == city.id, g = g) {
                                lvm.selectCity(city.id, city.uf)
                                lvm.filtersExpanded = false
                            }
                        }
                    }
                }

                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    ActionBtn("Limpar filtros", filled = false, g = g, modifier = Modifier.weight(1f)) { lvm.clearFilters() }
                    ActionBtn("Ver resultados", filled = true, g = g, modifier = Modifier.weight(1f)) { lvm.filtersExpanded = false }
                }
            }
        }
    }
}

private fun countLabel(n: Int, one: String, many: String): String = "$n ${if (n == 1) one else many}"

/** Chip cinza discreto do resumo (locais, cidades, insulinas, base offline). */
@Composable
private fun InfoChip(
    label: String,
    g: com.agon.app.ui.theme.GlucoColors,
    icon: ImageVector? = null,
) {
    Row(
        Modifier
            .clip(RoundedCornerShape(50))
            .background(g.lilacSoft)
            .padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Icon(icon, null, tint = g.muted, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(4.dp))
        }
        Text(label, fontSize = 12.sp, color = g.muted, maxLines = 1)
    }
}

/** Aviso âmbar quando a localização não está disponível: uma ação direta e a busca por cidade. */
@Composable
private fun LocationAlertCard(
    title: String,
    message: String,
    primaryLabel: String,
    onPrimary: () -> Unit,
    onSearchCity: () -> Unit,
    g: com.agon.app.ui.theme.GlucoColors,
) {
    val shape = RoundedCornerShape(12.dp)
    val warnText = if (g.dark) g.orange else Color(0xFF9A3412)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(g.orangeSoft)
            .border(1.dp, g.orange.copy(alpha = 0.35f), shape)
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Icon(Icons.Default.LocationOff, null, tint = g.orange, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = warnText)
                Text(message, fontSize = 12.sp, lineHeight = 16.sp, color = warnText, modifier = Modifier.padding(top = 2.dp))
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(g.card)
                    .border(1.dp, g.orange.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .clickable(onClick = onPrimary)
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text(primaryLabel, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = warnText)
            }
            Box(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .border(1.dp, g.orange.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .clickable(onClick = onSearchCity)
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("Buscar cidade", fontSize = 13.sp, color = warnText)
            }
        }
    }
}

@Composable
private fun SheetTitle(text: String, g: com.agon.app.ui.theme.GlucoColors) {
    Text(
        text,
        fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = g.muted,
        modifier = Modifier.padding(top = 14.dp, bottom = 6.dp),
    )
}

/** Cartão no topo do resultado: onde pegar aquela(s) insulina(s). */
@Composable
private fun GuideCardView(card: GuideCard, g: com.agon.app.ui.theme.GlucoColors) {
    val accent = if (card.free) g.green else g.blue
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(g.card)
            .border(1.5.dp, accent, RoundedCornerShape(14.dp))
            .padding(12.dp),
    ) {
        Text(card.products, fontSize = 12.sp, color = g.muted, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(4.dp))
        Text("Onde pegar: ${card.headline}", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = accent)
        Spacer(Modifier.height(4.dp))
        Text(card.detail, fontSize = 12.sp, color = g.ink, lineHeight = 17.sp)
    }
}


@Composable
private fun RealPlaceCard(
    place: HealthPlace,
    waMessage: String,
    g: com.agon.app.ui.theme.GlucoColors,
) {
    val context = LocalContext.current
    val accent = when (place.kind) {
        PlaceKind.FARMACIA -> g.green
        PlaceKind.UBS -> g.blue
        PlaceKind.HOSPITAL -> g.red
        PlaceKind.CLINICA -> g.violet
    }
    fun openMaps() {
        val uri = if (place.lat != 0.0 && place.lon != 0.0) {
            Uri.parse("geo:${place.lat},${place.lon}?q=${place.lat},${place.lon}(${Uri.encode(place.name)})")
        } else {
            Uri.parse("https://www.google.com/maps/search/?api=1&query=" + Uri.encode("${place.name} ${place.address}"))
        }
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, uri)) }
    }
    val dialNumber = InsulinGuide.firstPhone(place.phone)
    val whatsUrl = InsulinGuide.whatsappUrl(place.phone, waMessage)
    fun dial() {
        if (dialNumber.isBlank()) return
        runCatching { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(dialNumber)))) }
    }
    fun whatsapp() {
        val url = whatsUrl ?: return
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }
    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(g.card)
            .border(1.dp, g.line, RoundedCornerShape(14.dp))
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    when (place.kind) {
                        PlaceKind.FARMACIA -> Icons.Default.LocalPharmacy
                        PlaceKind.UBS -> Icons.Default.LocalHospital
                        else -> Icons.Default.MedicalServices
                    },
                    null,
                    tint = accent,
                    modifier = Modifier.size(18.dp),
                )
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(place.name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = g.ink, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Text(place.kind.label, fontSize = 12.sp, color = accent, fontWeight = FontWeight.Medium)
            }
            if (place.distanceKm > 0) {
                Text(String.format("%.1f km", place.distanceKm), fontSize = 11.sp, color = g.muted)
            }
        }
        if (place.address.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            Text(place.address, fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
        }
        if (place.phone.isNotBlank() || place.hours.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            if (place.phone.isNotBlank()) {
                Text("Tel: ${place.phone}", fontSize = 12.sp, color = g.muted)
            }
            if (place.hours.isNotBlank()) {
                Text(place.hours, fontSize = 12.sp, color = g.muted)
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(
                "Abrir no mapa",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.White,
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .background(g.violet)
                    .clickable { openMaps() }
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            )
            if (dialNumber.isNotBlank()) {
                Text(
                    "Ligar",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = g.violet,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, g.violet, RoundedCornerShape(10.dp))
                        .clickable { dial() }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                )
            }
            if (whatsUrl != null) {
                Text(
                    "WhatsApp",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = g.green,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .border(1.dp, g.green, RoundedCornerShape(10.dp))
                        .clickable { whatsapp() }
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                )
            }
        }
    }
}

@Composable
private fun MiniChip(
    label: String,
    selected: Boolean,
    g: com.agon.app.ui.theme.GlucoColors,
    onClick: () -> Unit,
) {
    Text(
        label,
        fontSize = 12.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        color = if (selected) Color.White else g.ink,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) g.violet else g.card)
            .border(1.dp, if (selected) g.violet else g.line, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp),
    )
}

@Composable
private fun SupplyPointCard(
    point: SupplyPoint,
    products: List<com.agon.app.data.insulin.InsulinProduct>,
    selected: Boolean,
    onClick: () -> Unit,
    g: com.agon.app.ui.theme.GlucoColors,
) {
    val context = LocalContext.current
    val channel = point.channel
    val icon: ImageVector = when (channel) {
        ChannelType.FARMACIA_POPULAR -> Icons.Default.LocalPharmacy
        ChannelType.ATENCAO_BASICA -> Icons.Default.LocalHospital
        ChannelType.CEAF -> Icons.Default.MedicalServices
        ChannelType.PRIVADA -> Icons.Default.LocalPharmacy
    }
    val accent = when (channel.priceTier) {
        PriceTier.GRATUITO, PriceTier.GRATUITO_PROCESSO -> g.green
        PriceTier.PMC_CMED -> g.blue
    }
    val primaryProduct = products.firstOrNull()
    val category = primaryProduct?.let { InsulinCatalog.categoryById(it.categoryId) }

    fun openUrl(url: String) {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }
    fun dial(phone: String) {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
        }
    }

    // Busca do estabelecimento no Google Maps (cidade + tipo), centrado nas coordenadas
    fun mapsSearchUrl(): String {
        val place = when (channel) {
            ChannelType.FARMACIA_POPULAR ->
                "Farmácia Popular Aqui Tem ${point.city.name} ${point.city.uf}"
            ChannelType.ATENCAO_BASICA ->
                "UBS farmácia ${point.city.name} ${point.city.uf}"
            ChannelType.CEAF ->
                "Farmácia CEAF ${point.city.name} ${point.city.uf}"
            ChannelType.PRIVADA ->
                "farmácia drogaria ${point.city.name} ${point.city.uf}"
        }
        val q = Uri.encode(place)
        // Abre a busca do estabelecimento centrada nas coordenadas da cidade
        return "https://www.google.com/maps/search/$q/@${point.city.lat},${point.city.lon},14z"
    }

    // Site / diretório para achar o estabelecimento (não página genérica fora do ar)
    fun establishmentFindUrl(): String {
        val cityUf = Uri.encode("${point.city.name} ${point.city.uf}")
        return when (channel) {
            ChannelType.FARMACIA_POPULAR ->
                // Busca Google do credenciado no município (painel MS costuma falhar)
                "https://www.google.com/search?q=" + Uri.encode("Aqui Tem Farmácia Popular ${point.city.name} ${point.city.uf} endereço")
            ChannelType.ATENCAO_BASICA ->
                "https://www.google.com/search?q=" + Uri.encode("UBS ${point.city.name} ${point.city.uf} farmácia endereço telefone")
            ChannelType.CEAF ->
                "https://www.google.com/search?q=" + Uri.encode("Farmácia CEAF ${point.city.uf} ${point.city.name} endereço")
            ChannelType.PRIVADA ->
                "https://www.google.com/search?q=" + Uri.encode("farmácia ${point.city.name} ${point.city.uf} insulina endereço")
        }
    }

    fun establishmentLabel(): String = when (channel) {
        ChannelType.FARMACIA_POPULAR -> "Buscar Farmácia Popular"
        ChannelType.ATENCAO_BASICA -> "Buscar UBS / farmácia"
        ChannelType.CEAF -> "Buscar farmácia CEAF"
        ChannelType.PRIVADA -> "Buscar farmácia"
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(g.card)
            .border(1.dp, if (selected) g.violet else g.line, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, null, tint = accent, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(channel.short, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = g.ink)
                Text("${point.city.name} — ${point.city.uf}", fontSize = 12.sp, color = g.muted)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    channel.priceTier.label.substringBefore(" —").substringBefore(" pelo"),
                    fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = accent,
                    textAlign = TextAlign.Center, lineHeight = 14.sp, maxLines = 2,
                    modifier = Modifier
                        .widthIn(max = 112.dp)
                        .clip(RoundedCornerShape(50))
                        .background(if (channel.priceTier == PriceTier.PMC_CMED) g.blueSoft else g.greenSoft)
                        .padding(horizontal = 10.dp, vertical = 3.dp),
                )
                if (point.distanceKm > 0) {
                    Text(
                        String.format("%.0f km", point.distanceKm), fontSize = 11.sp, color = g.muted,
                        modifier = Modifier.padding(top = 3.dp),
                    )
                }
            }
        }

        AnimatedVisibility(selected) {
            Column(Modifier.padding(top = 12.dp)) {
                // Endereço em destaque
                Text("Endereço / como encontrar", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = g.ink)
                Spacer(Modifier.height(4.dp))
                Text(
                    point.addressHint,
                    fontSize = 14.sp,
                    color = g.ink,
                    lineHeight = 20.sp,
                    fontWeight = FontWeight.Medium,
                )
                Text(point.coverage, fontSize = 12.sp, color = g.muted, modifier = Modifier.padding(top = 4.dp))
                Spacer(Modifier.height(10.dp))

                // Bloco de produto
                if (primaryProduct != null) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(g.inputBg)
                            .padding(12.dp),
                    ) {
                        Text("Princípio ativo: ${primaryProduct.activeIngredient}", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        Text("Marca/fabricante: ${primaryProduct.manufacturer}", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        if (category != null) {
                            Text("Categoria oficial: ${category.name}", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        }
                        val apres = primaryProduct.presentations.joinToString(", ")
                        val conc = primaryProduct.concentrations.joinToString(", ")
                        Text("Apresentações: $apres ($conc)", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(primaryProduct.publicNote, fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        if (category != null) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Início ${category.onset} · pico ${category.peak} · duração ${category.duration}",
                                fontSize = 12.sp, fontWeight = FontWeight.Medium, color = g.green,
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }

                Text("Documentos e condições para retirada", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = g.ink)
                Spacer(Modifier.height(6.dp))
                point.conditions.forEach { c ->
                    Text("• $c", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                }

                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("✓  ", fontSize = 14.sp, color = g.green, fontWeight = FontWeight.Bold)
                    Text("Como achar o estabelecimento", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = g.ink)
                }
                Text(
                    "A base orienta o canal de acesso no município. Use os botões abaixo para buscar o estabelecimento em ${point.city.name}/${point.city.uf} ou ligar no Disque Saúde.",
                    fontSize = 12.sp, color = g.muted, lineHeight = 16.sp,
                )

                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionBtn(
                        label = establishmentLabel(),
                        filled = true,
                        g = g,
                        modifier = Modifier.weight(1f),
                    ) { openUrl(establishmentFindUrl()) }
                    ActionBtn(
                        label = "Disque Saúde 136",
                        filled = false,
                        g = g,
                        modifier = Modifier.weight(1f),
                    ) { dial("136") }
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    "Fechar",
                    fontSize = 14.sp, fontWeight = FontWeight.Medium, color = g.green,
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .clickable(onClick = onClick)
                        .padding(8.dp),
                )
            }
        }
    }
}

@Composable
private fun ActionBtn(
    label: String,
    filled: Boolean,
    g: com.agon.app.ui.theme.GlucoColors,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(24.dp))
            .background(if (filled) g.green else Color.Transparent)
            .border(1.dp, if (filled) g.green else g.line, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = if (filled) Color.White else g.ink,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

/** Município que não está na lista conhecida (vindo do GPS, de bairro ou de CEP). */
private fun cityFrom(name: String, uf: String?, lat: Double, lon: Double): City {
    val slug = LocatorSearch.norm(name).replace(Regex("[^a-z0-9]+"), "-").trim('-')
    return City("geo-${(uf ?: "br").lowercase()}-$slug", name, uf.orEmpty(), lat, lon, CityTier.INTERIOR)
}
