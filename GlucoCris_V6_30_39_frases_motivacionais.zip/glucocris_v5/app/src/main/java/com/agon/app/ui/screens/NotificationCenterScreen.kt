package com.agon.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.insights.WeeklyPrefs
import com.agon.app.localai.LocalAiSettings
import com.agon.app.notifications.NotificationCenter
import com.agon.app.reminders.Caregiver
import com.agon.app.reminders.GlucoseAlerts
import com.agon.app.reminders.QuickGlucoseNotifier
import com.agon.app.reminders.WaterAlert
import com.agon.app.notifications.NotificationCenter.Cat
import com.agon.app.ui.components.BackTitle
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.theme.glucoColors

/** Central de notificações: todas as categorias de aviso do app num só lugar. */
@Composable
fun NotificationCenterScreen(nav: NavHostController) {
    val g = glucoColors()
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    // tick força releitura das preferências depois de cada alteração
    @Suppress("UNUSED_VARIABLE") val t = tick

    ScrollScreen {
        BackTitle("Central de notificações", { nav.popBackStack() })
        Text(
            "Aqui você liga ou desliga cada aviso do app, um por um. Avisos urgentes (medicação, glicemia, cuidador) nunca ficam mudos no horário de silêncio.",
            color = g.muted, fontSize = 13.sp,
        )

        SectionTitle("Avisos urgentes")
        Cat.values().filter { it.urgent }.forEach { cat -> CatRow(cat, nav) { tick++ } }
        Text(
            "Se desligar um destes, a Cris não vai mais avisar nesse caso. Faça isso só se tiver outro jeito de lembrar.",
            color = g.orange, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
        )

        SectionTitle("Avisos comuns")
        Cat.values().filter { !it.urgent }.forEach { cat -> CatRow(cat, nav) { tick++ } }

        SectionTitle("Outros avisos")
        GCard {
            var taskNotify by remember { mutableStateOf(LocalAiSettings.taskNotify(ctx)) }
            var taskSound by remember { mutableStateOf(LocalAiSettings.taskSound(ctx)) }
            var quickOn by remember { mutableStateOf(QuickGlucoseNotifier.isOn(ctx)) }
            SubSwitch("Cris IA terminou sua pesquisa", "Notificação quando a Cris acaba uma resposta em segundo plano.", taskNotify) {
                taskNotify = it; LocalAiSettings.setTaskNotify(ctx, it)
            }
            if (taskNotify) SubSwitch("Som nesse aviso", "Respeita o volume e o modo silencioso do aparelho.", taskSound) {
                taskSound = it; LocalAiSettings.setTaskSound(ctx, it)
            }
            SubSwitch("Atalho de glicemia na barra", "Fica fixo na barra de notificações para registrar sem abrir o app.", quickOn) {
                quickOn = it; QuickGlucoseNotifier.setOn(ctx, it)
            }
        }

        SectionTitle("Horário de silêncio")
        GCard {
            var quiet by remember { mutableStateOf(NotificationCenter.quietOn(ctx)) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Silenciar avisos comuns", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text("Não vale para avisos urgentes.", color = g.muted, fontSize = 12.sp)
                }
                Switch(checked = quiet, onCheckedChange = { quiet = it; NotificationCenter.setQuietOn(ctx, it); tick++ })
            }
            if (quiet) {
                var start by remember { mutableStateOf(NotificationCenter.quietStart(ctx)) }
                var end by remember { mutableStateOf(NotificationCenter.quietEnd(ctx)) }
                val hours = listOf(20, 21, 22, 23, 0).map { it.toString() to "%02d:00".format(it) }
                Text("Começa às", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
                ChipRow(hours, start.toString()) { start = it.toInt(); NotificationCenter.setQuiet(ctx, start, end) }
                val ends = listOf(5, 6, 7, 8, 9).map { it.toString() to "%02d:00".format(it) }
                Text("Termina às", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                ChipRow(ends, end.toString()) { end = it.toInt(); NotificationCenter.setQuiet(ctx, start, end) }
            }
        }

        SectionTitle("Limite diário")
        GCard {
            var cap by remember { mutableStateOf(NotificationCenter.dailyCap(ctx)) }
            Text("Máximo de avisos comuns por dia", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            ChipRow(listOf("1" to "1", "3" to "3", "5" to "5", "0" to "Sem limite"), cap.toString()) {
                cap = it.toInt(); NotificationCenter.setDailyCap(ctx, cap); tick++
            }
            Text("Hoje a Cris já enviou ${NotificationCenter.sentToday(ctx)} aviso(s) comum(ns).", color = g.muted, fontSize = 12.sp)
        }

        SectionTitle("Mais opções")
        PrimaryButton("Abrir permissões do Android", g.violet, {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                        .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                )
            } catch (_: Exception) {
                try {
                    ctx.startActivity(
                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                } catch (_: Exception) {}
            }
        }, Modifier.padding(top = 4.dp))
    }
}

@Composable
private fun SubSwitch(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val g = glucoColors()
    Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(desc, color = g.muted, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun CatRow(cat: Cat, nav: NavHostController, onChange: () -> Unit) {
    val g = glucoColors()
    val ctx = LocalContext.current
    var on by remember(cat) { mutableStateOf(NotificationCenter.enabled(ctx, cat)) }
    GCard(Modifier.padding(top = 8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) {
                Text(cat.label, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(cat.desc, color = g.muted, fontSize = 12.sp)
            }
            Switch(checked = on, onCheckedChange = { on = it; NotificationCenter.setEnabled(ctx, cat, it); onChange() })
        }
        if (!on) return@GCard
        when (cat) {
            Cat.REMINDERS -> LinkText("Editar horários e sons dos lembretes ›", g.violet) { Routes.goTab(nav, Routes.REMINDERS) }
            Cat.GLUCOSE_ALERTS -> {
                var lowOn by remember { mutableStateOf(GlucoseAlerts.lowOn(ctx)) }
                var lowH by remember { mutableStateOf(GlucoseAlerts.lowHours(ctx)) }
                var highOn by remember { mutableStateOf(GlucoseAlerts.highOn(ctx)) }
                var highH by remember { mutableStateOf(GlucoseAlerts.highHours(ctx)) }
                var missOn by remember { mutableStateOf(GlucoseAlerts.missOn(ctx)) }
                var missH by remember { mutableStateOf(GlucoseAlerts.missHour(ctx)) }
                SubSwitch("Glicemia baixa", "Avisa se a última medição está abaixo da meta e passou o tempo escolhido sem nova medida.", lowOn) {
                    lowOn = it; GlucoseAlerts.setLowOn(ctx, it)
                }
                if (lowOn) ChipRow(listOf("1" to "1 hora", "2" to "2 horas", "3" to "3 horas"), lowH.toString()) {
                    lowH = it.toInt(); GlucoseAlerts.setLowHours(ctx, lowH)
                }
                SubSwitch("Glicemia alta", "Avisa se a última medição está acima da meta e passou o tempo escolhido sem nova medida.", highOn) {
                    highOn = it; GlucoseAlerts.setHighOn(ctx, it)
                }
                if (highOn) ChipRow(listOf("2" to "2 horas", "3" to "3 horas", "4" to "4 horas", "6" to "6 horas"), highH.toString()) {
                    highH = it.toInt(); GlucoseAlerts.setHighHours(ctx, highH)
                }
                SubSwitch("Sem medir hoje", "Avisa se ainda não houver nenhuma medição no dia a partir do horário escolhido.", missOn) {
                    missOn = it; GlucoseAlerts.setMissOn(ctx, it)
                }
                if (missOn) ChipRow(listOf("12" to "12h", "16" to "16h", "18" to "18h", "20" to "20h", "22" to "22h"), missH.toString()) {
                    missH = it.toInt(); GlucoseAlerts.setMissHour(ctx, missH)
                }
                Text("Os alertas são um apoio e não substituem a medição.", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            }
            Cat.CAREGIVER -> {
                var cg by remember { mutableStateOf(Caregiver.alertsOn(ctx)) }
                SubSwitch("Sugerir avisar o cuidador", "Só funciona depois de você cadastrar o contato e dar o consentimento.", cg) {
                    cg = it; Caregiver.setAlertsOn(ctx, it)
                }
                LinkText("Configurar contato do cuidador ›", g.violet) { nav.navigate(Routes.CAREGIVER) }
            }
            Cat.WATER -> {
                var w by remember { mutableStateOf(WaterAlert.isOn(ctx)) }
                SubSwitch("Beber água quando a glicemia vem alta", "Aparece depois de uma medição acima da meta.", w) {
                    w = it; WaterAlert.setOn(ctx, it)
                }
            }
            Cat.HBA1C -> LinkText("Escolher a data do exame ›", g.violet) { nav.navigate(Routes.HBA1C) }
            Cat.WEEKLY -> {
                var wk by remember { mutableStateOf(WeeklyPrefs.notifyOn(ctx)) }
                SubSwitch("Aviso todo domingo à noite", "Quando o resumo da semana estiver pronto.", wk) {
                    wk = it; WeeklyPrefs.setNotifyOn(ctx, it)
                }
            }
            else -> {}
        }
    }
}

@Composable
private fun LinkText(text: String, color: androidx.compose.ui.graphics.Color, onClick: () -> Unit) {
    Text(
        text, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp,
        modifier = Modifier.padding(top = 10.dp).clickable(onClick = onClick),
    )
}
