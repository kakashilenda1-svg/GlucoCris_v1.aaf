package com.agon.app.ui.screens

import androidx.compose.foundation.layout.heightIn
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GlucoViewModel
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.ui.graphics.graphicsLayer
import com.agon.app.data.PracticeMode
import com.agon.app.data.toMgDl
import com.agon.app.reminders.ReminderScheduler
import com.agon.app.reminders.WaterAlert
import com.agon.app.ui.components.tourTarget
import kotlinx.coroutines.Job
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.Image
import com.agon.app.R
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.sin
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Switch
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.StrokeCap
import com.agon.app.ui.components.GCard
import com.agon.app.ui.theme.GlucoColors
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Tune
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.text.style.TextAlign

private val WaterBlue = Color(0xFF0EA5E9)
private val WaterBlueDeep = Color(0xFF0284C7)
private val WaterBlueSoft = Color(0xFFBAE6FD)
private val WaterBlueBg = Color(0xFF0C4A6E)
private val WaterSurface = Color(0xFFE0F2FE)

// Visual neon do Cris Hidrata (contador e copos): fundo azul-marinho com brilho ciano.
private val NeonBg1 = Color(0xFF0B1E3A)
private val NeonBg2 = Color(0xFF0F4C81)
private val NeonCyan = Color(0xFF5CF0FF)
private val NeonCyan2 = Color(0xFF22D3EE)
private val NeonBlue = Color(0xFF2563EB)
private val NeonSoft = Color(0xFFBDF8FF)

data class WaterCupPreset(val ml: Int, val label: String, val kind: String)
data class WaterEntry(val id: String, val ml: Int, val at: Long, val kind: String)

private val CUP_PRESETS = listOf(
    WaterCupPreset(150, "150 ml", "tea"),
    WaterCupPreset(200, "200 ml", "glass"),
    WaterCupPreset(250, "250 ml", "glass"),
    WaterCupPreset(300, "300 ml", "glass"),
    WaterCupPreset(400, "400 ml", "cup"),
    WaterCupPreset(500, "500 ml", "bottle"),
    WaterCupPreset(600, "600 ml", "bottle"),
    WaterCupPreset(700, "700 ml", "bottle"),
    WaterCupPreset(800, "800 ml", "bottle"),
    WaterCupPreset(1000, "1 L", "bottle"),
)

private const val WATER_PREFS = "gluco_water_v1"
private const val KEY_GOAL = "goal_ml"
private const val KEY_ENTRIES = "entries_json"

private const val KEY_FAV_CUPS = "fav_cups"
private const val KEY_SOUNDS = "sounds_on"
private const val KEY_HEAT_DAY = "heat_day"
private const val KEY_HEAT_ON = "heat_on"
private const val KEY_LAST_REMIND = "last_remind_at"
private const val KEY_ASK_MEAL = "ask_after_meal"
private const val KEY_REMIND_HOURS = "remind_hours"
private const val HEAT_BONUS_ML = 400

fun waterSoundsOn(ctx: Context): Boolean =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SOUNDS, true)

fun setWaterSoundsOn(ctx: Context, on: Boolean) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_SOUNDS, on).apply()
}

fun loadFavCups(ctx: Context): List<Int> {
    val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE)
        .getString(KEY_FAV_CUPS, "250,300,500") ?: "250,300,500"
    return raw.split(",").mapNotNull { it.trim().toIntOrNull() }.filter { it in 50..2000 }.distinct().take(4)
}

fun saveFavCups(ctx: Context, list: List<Int>) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putString(KEY_FAV_CUPS, list.distinct().take(4).joinToString(",")).apply()
}

fun toggleFavCup(ctx: Context, ml: Int) {
    val cur = loadFavCups(ctx).toMutableList()
    if (ml in cur) cur.remove(ml) else {
        if (cur.size >= 4) cur.removeAt(0)
        cur.add(ml)
    }
    saveFavCups(ctx, cur)
}

fun isHeatModeToday(ctx: Context): Boolean {
    val p = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE)
    return p.getBoolean(KEY_HEAT_ON, false) && p.getString(KEY_HEAT_DAY, "") == dayKey()
}

fun setHeatModeToday(ctx: Context, on: Boolean) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putBoolean(KEY_HEAT_ON, on).putString(KEY_HEAT_DAY, dayKey()).apply()
}

fun effectiveWaterGoal(ctx: Context): Int {
    val base = loadWaterGoal(ctx)
    return if (isHeatModeToday(ctx)) base + HEAT_BONUS_ML else base
}

fun suggestedWaterGoalMl(weightKg: String?): Int? {
    val w = weightKg?.replace(",", ".")?.toDoubleOrNull() ?: return null
    if (w < 30 || w > 250) return null
    return (w * 35.0).toInt().coerceIn(1500, 4500)
}

fun waterMorningLow(ctx: Context): Boolean {
    val entries = loadWaterEntries(ctx)
    val morning = entries.filter {
        val c = Calendar.getInstance().apply { timeInMillis = it.at }
        c.get(Calendar.HOUR_OF_DAY) < 12
    }.sumOf { it.ml }
    val goal = effectiveWaterGoal(ctx)
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return hour >= 12 && morning < (goal * 0.25)
}

fun waterRemindHours(ctx: Context): Int =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getInt(KEY_REMIND_HOURS, 2).coerceIn(1, 6)

fun setWaterRemindHours(ctx: Context, h: Int) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_REMIND_HOURS, h.coerceIn(1, 6)).apply()
}

fun shouldSoftWaterRemind(ctx: Context): Boolean {
    val total = waterTodayTotal(ctx)
    val goal = effectiveWaterGoal(ctx)
    if (total >= goal) return false
    val last = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getLong(KEY_LAST_REMIND, 0L)
    val gap = waterRemindHours(ctx) * 60L * 60L * 1000L
    return System.currentTimeMillis() - last > gap
}

fun markWaterReminded(ctx: Context) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putLong(KEY_LAST_REMIND, System.currentTimeMillis()).apply()
}

fun askWaterAfterMeal(ctx: Context): Boolean =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ASK_MEAL, true)

fun setAskWaterAfterMeal(ctx: Context, on: Boolean) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ASK_MEAL, on).apply()
}

fun waterInsightLine(ctx: Context): String? {
    val total = waterTodayTotal(ctx)
    val goal = effectiveWaterGoal(ctx)
    if (total >= goal) return "Meta batida hoje — lembretes suaves em silêncio."
    if (waterMorningLow(ctx)) return "Pouco de manhã no histórico de hoje. Que tal um copo agora?"
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    if (hour in 14..17 && total < goal * 0.5) return "Tarde: ainda abaixo da metade da meta."
    if (shouldSoftWaterRemind(ctx)) return "Lembrete suave: ainda falta água para a meta."
    return null
}

fun waterMood(progress: Float): Int = when {
    progress >= 1f -> 2
    progress >= 0.5f -> 1
    else -> 0
}

fun waterWeekTotal(ctx: Context): Int {
    return try {
        val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getString(KEY_ENTRIES, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val cutoff = System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000
        (0 until arr.length()).sumOf { i ->
            val o = arr.getJSONObject(i)
            val at = o.optLong("at")
            if (at >= cutoff) o.optInt("ml") else 0
        }
    } catch (_: Exception) { 0 }
}


private fun dayKey(ts: Long = System.currentTimeMillis()): String {
    val c = Calendar.getInstance().apply { timeInMillis = ts }
    return "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
}

fun loadWaterGoal(ctx: Context): Int =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getInt(KEY_GOAL, 2000)

fun saveWaterGoal(ctx: Context, ml: Int) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putInt(KEY_GOAL, ml.coerceIn(500, 8000)).apply()
}

fun loadWaterEntries(ctx: Context): List<WaterEntry> {
    return try {
        val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getString(KEY_ENTRIES, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val today = dayKey()
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val at = o.optLong("at")
            if (dayKey(at) != today) return@mapNotNull null
            WaterEntry(o.optString("id"), o.optInt("ml"), at, o.optString("kind", "glass"))
        }.sortedByDescending { it.at }
    } catch (_: Exception) {
        emptyList()
    }
}

fun saveWaterEntries(ctx: Context, list: List<WaterEntry>) {
    // keep today + last 7 days
    val cutoff = System.currentTimeMillis() - 8L * 24 * 60 * 60 * 1000
    val allRaw = try {
        val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getString(KEY_ENTRIES, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val old = (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val at = o.optLong("at")
            if (at < cutoff) null else WaterEntry(o.optString("id"), o.optInt("ml"), at, o.optString("kind", "glass"))
        }
        val today = dayKey()
        old.filter { dayKey(it.at) != today } + list
    } catch (_: Exception) {
        list
    }
    val arr = JSONArray()
    allRaw.forEach { e ->
        arr.put(JSONObject().put("id", e.id).put("ml", e.ml).put("at", e.at).put("kind", e.kind))
    }
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ENTRIES, arr.toString()).apply()
}

fun waterTodayTotal(ctx: Context): Int = loadWaterEntries(ctx).sumOf { it.ml }


// ───────── Relógio inteligente da água (horários editáveis + lembretes) ─────────

private const val KEY_CLOCK_TIMES = "clock_times"
private const val KEY_CLOCK_ON = "clock_on"
private const val KEY_CLOCK_IDS = "clock_scheduled_ids"

fun waterGoalMet(ctx: Context): Boolean = waterTodayTotal(ctx) >= effectiveWaterGoal(ctx)

fun waterClockOn(ctx: Context): Boolean =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getBoolean(KEY_CLOCK_ON, false)

private fun parseClock(t: String): Pair<Int, Int>? {
    val p = t.split(":")
    if (p.size != 2) return null
    val h = p[0].toIntOrNull() ?: return null
    val m = p[1].toIntOrNull() ?: return null
    return if (h in 0..23 && m in 0..59) h to m else null
}

fun defaultWaterClockTimes(hours: Int): List<String> {
    val step = hours.coerceIn(1, 6)
    return generateSequence(8) { it + step }.takeWhile { it <= 20 }.map { "%02d:00".format(it) }.toList()
}

fun loadWaterClockTimes(ctx: Context): List<String> {
    val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getString(KEY_CLOCK_TIMES, null)
    return if (raw == null) defaultWaterClockTimes(waterRemindHours(ctx))
    else raw.split(",").filter { parseClock(it) != null }
}

fun saveWaterClockTimes(ctx: Context, list: List<String>) {
    val clean = list.filter { parseClock(it) != null }.distinct().sorted().take(24)
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putString(KEY_CLOCK_TIMES, clean.joinToString(",")).apply()
    syncWaterClock(ctx)
}

fun setWaterClockOn(ctx: Context, on: Boolean) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_CLOCK_ON, on).apply()
    syncWaterClock(ctx)
}

/** Agenda (ou cancela) os alarmes do relógio de água. Não faz nada durante a simulação do tour. */
fun syncWaterClock(ctx: Context) {
    if (PracticeMode.active) return
    val app = ctx.applicationContext
    val p = app.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE)
    p.getString(KEY_CLOCK_IDS, "")?.split(",")?.filter { it.isNotBlank() }?.forEach { ReminderScheduler.cancel(app, it) }
    val ids = mutableListOf<String>()
    if (p.getBoolean(KEY_CLOCK_ON, false)) {
        loadWaterClockTimes(app).forEach { t ->
            val hm = parseClock(t) ?: return@forEach
            val id = "agua_" + t.replace(":", "")
            ReminderScheduler.schedule(
                app, id, "agua", "Hora de beber água 💧", hm.first, hm.second,
                listOf(0, 1, 2, 3, 4, 5, 6), "claro", "Beba um copo de água.",
            )
            ids.add(id)
        }
    }
    p.edit().putString(KEY_CLOCK_IDS, ids.joinToString(",")).apply()
}

// ───────── Cris Hidrata · visual leve, moderno e que acompanha o tema ─────────

/** Risadinha sintetizada (sem arquivo de áudio): "hi-hi-hi" com variação a cada toque. */
private fun playDropGiggle(ctx: Context) {
    if (!waterSoundsOn(ctx)) return
    Thread {
        try {
            val sr = 22050
            val variant = (Math.abs(System.nanoTime()) % 3).toInt()
            val bursts = 4 + variant
            val base = doubleArrayOf(620.0, 700.0, 780.0)[variant]
            val burstN = sr * 85 / 1000
            val gapN = sr * 45 / 1000
            val samples = ShortArray(bursts * (burstN + gapN) + 1)
            var idx = 0
            var phase = 0.0
            for (b in 0 until bursts) {
                val f0 = base * (1.0 + 0.06 * b) * (if (b % 2 == 0) 1.0 else 0.92)
                for (i in 0 until burstN) {
                    val tt = i / burstN.toDouble()
                    val f = f0 * (1.0 + 0.35 * (1.0 - tt))
                    phase += 2.0 * Math.PI * f / sr
                    val env = Math.pow(Math.sin(Math.PI * tt), 0.6)
                    val v = (Math.sin(phase) + 0.35 * Math.sin(2.0 * phase)) * env * 0.5
                    samples[idx++] = (v * Short.MAX_VALUE).toInt().toShort()
                }
                idx += gapN
            }
            val track = android.media.AudioTrack.Builder()
                .setAudioAttributes(
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                )
                .setAudioFormat(
                    android.media.AudioFormat.Builder()
                        .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO)
                        .build(),
                )
                .setBufferSizeInBytes(samples.size * 2)
                .setTransferMode(android.media.AudioTrack.MODE_STATIC)
                .build()
            track.write(samples, 0, samples.size)
            track.play()
            Thread.sleep((samples.size * 1000L / sr) + 150L)
            track.release()
        } catch (_: Exception) {
        }
    }.start()
}

/** Gotinha: ao tocar, dança, ri e sorri (squash/stretch, pulinhos, giro e brilhos). mood: 0 triste, 1 normal, 2 festa. */
@Composable
private fun CrisDrop(mood: Int, modifier: Modifier = Modifier, limbs: Boolean = false) {
    val g = glucoColors()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val rot = remember { Animatable(0f) }
    val hop = remember { Animatable(0f) }
    val squash = remember { Animatable(1f) }
    val sparkle = remember { Animatable(1f) }
    val arms = remember { Animatable(0f) }      // 0 = bracinhos baixos/escondidos, 1 = levantados
    val redness = remember { Animatable(0f) }   // 0 = cor normal, 1 = bem vermelha
    var redTarget by remember { mutableFloatStateOf(0f) }
    var coolJob by remember { mutableStateOf<Job?>(null) }
    var happy by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }
    val body = g.blue
    Box(
        modifier
            .graphicsLayer {
                rotationZ = rot.value
                translationY = hop.value * size.height
                scaleY = squash.value
                scaleX = 2f - squash.value
            }
            .clip(if (limbs) RoundedCornerShape(16.dp) else CircleShape)
            .clickable {
                playDropGiggle(ctx)
                val target = (maxOf(redTarget, redness.value) + 0.1f).coerceAtMost(1f)
                redTarget = target
                coolJob?.cancel()
                job?.cancel()
                job = scope.launch {
                    happy = true
                    launch {
                        redness.animateTo(target, tween(1600, easing = LinearEasing))
                    }
                    launch { arms.animateTo(1f, tween(220, easing = FastOutSlowInEasing)) }
                    launch {
                        sparkle.snapTo(0f)
                        sparkle.animateTo(1f, tween(1400, easing = LinearEasing))
                    }
                    launch {
                        squash.animateTo(0.8f, tween(70))
                        squash.animateTo(1.15f, spring(dampingRatio = 0.3f, stiffness = Spring.StiffnessMedium))
                        squash.animateTo(1f, spring(dampingRatio = 0.5f))
                    }
                    launch {
                        repeat(4) {
                            hop.animateTo(-0.18f, tween(110, easing = FastOutSlowInEasing))
                            hop.animateTo(0f, tween(110, easing = FastOutLinearInEasing))
                        }
                    }
                    repeat(4) {
                        rot.animateTo(15f, tween(120))
                        rot.animateTo(-15f, tween(120))
                    }
                    rot.animateTo(0f, spring(dampingRatio = 0.5f))
                    delay(300)
                    happy = false
                    arms.animateTo(0f, tween(350))
                }
                // parou de clicar: depois de um instante, o vermelho some devagar até voltar ao azul
                coolJob = scope.launch {
                    delay(2500)
                    redTarget = 0f
                    redness.animateTo(
                        0f,
                        tween((6000 * redness.value).toInt().coerceAtLeast(800), easing = LinearEasing),
                    )
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val ink = Color(0xFF0F172A)
            val drop = Path().apply {
                moveTo(w * 0.5f, h * 0.04f)
                cubicTo(w * 0.5f, h * 0.04f, w * 0.92f, h * 0.46f, w * 0.92f, h * 0.64f)
                cubicTo(w * 0.92f, h * 0.84f, w * 0.74f, h * 0.96f, w * 0.5f, h * 0.96f)
                cubicTo(w * 0.26f, h * 0.96f, w * 0.08f, h * 0.84f, w * 0.08f, h * 0.64f)
                cubicTo(w * 0.08f, h * 0.46f, w * 0.5f, h * 0.04f, w * 0.5f, h * 0.04f)
                close()
            }
            val bodyNow = androidx.compose.ui.graphics.lerp(body, Color(0xFFD32F2F), redness.value)
            // braços e pernas fixos (só no modo limbs); ficam atrás do corpo e acompanham a cor/animação dele
            if (limbs) drawDropLimbs(bodyNow, arms.value)
            withTransform({ if (limbs) scale(0.8f, 0.8f, Offset(w * 0.5f, 0f)) }) {
            // bracinhos levantados (só aparecem durante o toque)
            if (arms.value > 0.01f) {
                val ang = Math.toRadians((160.0 * arms.value))
                val armLen = w * 0.22f
                for (side in floatArrayOf(-1f, 1f)) {
                    val sx = w * (0.5f + side * 0.36f)
                    val sy = h * 0.64f
                    val ex = sx + side * Math.sin(ang).toFloat() * armLen
                    val ey = sy + Math.cos(ang).toFloat() * armLen
                    drawLine(bodyNow, Offset(sx, sy), Offset(ex, ey), strokeWidth = w * 0.07f, cap = StrokeCap.Round)
                    drawCircle(bodyNow, w * 0.05f, Offset(ex, ey))
                }
            }
            drawPath(drop, Brush.verticalGradient(listOf(bodyNow.copy(alpha = 0.75f), bodyNow)))
            val eyeR = w * 0.055f
            if (happy) {
                // olhinhos felizes ^ ^
                for (ex in floatArrayOf(0.38f, 0.62f)) {
                    val eye = Path().apply {
                        moveTo(w * ex - eyeR * 1.3f, h * 0.62f)
                        quadraticTo(w * ex, h * 0.62f - eyeR * 2.6f, w * ex + eyeR * 1.3f, h * 0.62f)
                    }
                    drawPath(eye, Color.White, style = Stroke(width = w * 0.04f, cap = StrokeCap.Round))
                }
                drawCircle(Color(0xFFFF8FB1).copy(alpha = 0.55f), w * 0.05f, Offset(w * 0.27f, h * 0.7f))
                drawCircle(Color(0xFFFF8FB1).copy(alpha = 0.55f), w * 0.05f, Offset(w * 0.73f, h * 0.7f))
                val mouth = Path().apply {
                    moveTo(w * 0.36f, h * 0.72f)
                    quadraticTo(w * 0.5f, h * 1.0f, w * 0.64f, h * 0.72f)
                    close()
                }
                drawPath(mouth, ink)
                drawCircle(Color(0xFFFF8FB1), w * 0.045f, Offset(w * 0.5f, h * 0.83f))
                val t = sparkle.value
                if (t < 1f) {
                    for (i in 0 until 4) {
                        val ang = i * 1.5708f + 0.6f
                        val rad = w * (0.30f + 0.14f * t)
                        val cx = w * 0.5f + Math.cos(ang.toDouble()).toFloat() * rad
                        val cy = h * 0.45f + Math.sin(ang.toDouble()).toFloat() * rad - t * h * 0.12f
                        drawCircle(Color(0xFFFFD54F).copy(alpha = 1f - t), w * 0.05f, Offset(cx, cy))
                    }
                }
            } else {
                drawCircle(Color.White, eyeR, Offset(w * 0.38f, h * 0.6f))
                drawCircle(Color.White, eyeR, Offset(w * 0.62f, h * 0.6f))
                drawCircle(ink, eyeR * 0.5f, Offset(w * 0.38f, h * 0.61f))
                drawCircle(ink, eyeR * 0.5f, Offset(w * 0.62f, h * 0.61f))
                val d = when (mood) { 2 -> 0.11f; 1 -> 0.06f; else -> -0.05f }
                val mouth = Path().apply {
                    moveTo(w * 0.4f, h * 0.76f)
                    quadraticTo(w * 0.5f, h * (0.76f + d), w * 0.6f, h * 0.76f)
                }
                drawPath(mouth, ink, style = Stroke(width = w * 0.035f, cap = StrokeCap.Round))
            }
            }
        }
    }
}

/**
 * Braços e pernas fixos da gotinha (tela cheia do Cris Hidrata). O braço esquerdo aponta para o balão e o direito
 * descansa; quando ela é tocada, os bracinhos animados de sempre assumem e estes somem de leve (armsRaise 0 -> 1).
 */
private fun DrawScope.drawDropLimbs(color: Color, armsRaise: Float) {
    val w = size.width
    val h = size.height
    val foot = androidx.compose.ui.graphics.lerp(color, Color.Black, 0.22f)
    val hand = androidx.compose.ui.graphics.lerp(color, Color.White, 0.35f)
    val sw = w * 0.085f
    for (lx in floatArrayOf(0.42f, 0.58f)) {
        drawLine(color, Offset(w * lx, h * 0.68f), Offset(w * lx, h * 0.89f), strokeWidth = sw, cap = StrokeCap.Round)
    }
    drawOval(foot, Offset(w * 0.30f, h * 0.885f), Size(w * 0.19f, h * 0.075f))
    drawOval(foot, Offset(w * 0.51f, h * 0.885f), Size(w * 0.19f, h * 0.075f))
    val a = (1f - armsRaise).coerceIn(0f, 1f)
    if (a > 0.01f) {
        val len = w * 0.2f
        val sy = h * 0.5f
        val poses = listOf(Triple(-1f, 0.18f, 135.0), Triple(1f, 0.82f, 28.0))
        for ((side, sxFrac, deg) in poses) {
            val ang = Math.toRadians(deg)
            val sx = w * sxFrac
            val ex = sx + side * Math.sin(ang).toFloat() * len
            val ey = sy + Math.cos(ang).toFloat() * len
            drawLine(color.copy(alpha = a), Offset(sx, sy), Offset(ex, ey), strokeWidth = sw * 0.9f, cap = StrokeCap.Round)
            drawCircle(hand.copy(alpha = a), w * 0.05f, Offset(ex, ey))
        }
    }
}

/** "1,4 L" ou "350 ml". */
private fun fmtWaterMl(ml: Int): String =
    if (ml >= 1000) String.format(Locale.forLanguageTag("pt-BR"), "%.1f L", ml / 1000f) else "$ml ml"

/** Próximo horário do relógio inteligente e quanto beber (mesma conta do card de lembretes). */
private fun nextWaterReminder(ctx: Context, total: Int, goal: Int): Pair<String, Int>? {
    val remaining = (goal - total).coerceAtLeast(0)
    if (remaining <= 0) return null
    val cal = Calendar.getInstance()
    val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    val mins = loadWaterClockTimes(ctx).mapNotNull { t -> parseClock(t)?.let { it.first * 60 + it.second } }.sorted()
    val nextMin = mins.firstOrNull { it > nowMin } ?: mins.firstOrNull() ?: return null
    val left = mins.count { it > nowMin }
    val suggest = (((remaining / left.coerceAtLeast(1)) + 25) / 50 * 50).coerceIn(100, 500)
    return "%02d:%02d".format(nextMin / 60, nextMin % 60) to suggest
}

/** Personagem bebendo água (desenhado em 340 x 258, dentro do círculo do contador). */
private fun DrawScope.drawDrinker() {
    val skin = Color(0xFFFFD2AE)
    val skinShade = Color(0xFFF2B98F)
    val shirt = Brush.verticalGradient(listOf(NeonCyan2, NeonBlue), startY = 100f, endY = 130f)
    drawCircle(
        Brush.radialGradient(listOf(NeonCyan2.copy(alpha = 0.7f), Color.Transparent), center = Offset(170f, 92f), radius = 46f),
        radius = 46f, center = Offset(170f, 92f),
    )
    // braços
    val armL = Path().apply { moveTo(147f, 122f); quadraticTo(145f, 104f, 157f, 101f) }
    val armR = Path().apply { moveTo(193f, 122f); quadraticTo(195f, 104f, 183f, 101f) }
    drawPath(armL, shirt, style = Stroke(9f, cap = StrokeCap.Round))
    drawPath(armR, shirt, style = Stroke(9f, cap = StrokeCap.Round))
    // camiseta
    val body = Path().apply {
        moveTo(138f, 130f); quadraticTo(140f, 106f, 170f, 103f); quadraticTo(200f, 106f, 202f, 130f); close()
    }
    drawPath(body, shirt)
    val collar = Path().apply { moveTo(156f, 112f); quadraticTo(170f, 120f, 184f, 112f) }
    drawPath(collar, NeonSoft.copy(alpha = 0.7f), style = Stroke(2f, cap = StrokeCap.Round))
    // pescoço, orelhas e cabeça
    drawRoundRect(skinShade, Offset(164f, 94f), Size(12f, 12f), CornerRadius(4f, 4f))
    drawCircle(skinShade, 3.6f, Offset(153f, 84f))
    drawCircle(skinShade, 3.6f, Offset(187f, 84f))
    drawCircle(skin, 17f, Offset(170f, 82f))
    // cabelo
    val hair = Path().apply {
        moveTo(152.5f, 80f); quadraticTo(150f, 61f, 170f, 61f); quadraticTo(190f, 61f, 187.5f, 80f)
        quadraticTo(184f, 70f, 172f, 70f); quadraticTo(160f, 72f, 152.5f, 80f); close()
    }
    drawPath(hair, Color(0xFF6B3E26))
    // olhinhos fechados de prazer e bochechas
    val ink = Color(0xFF3B2A20)
    val eyeL = Path().apply { moveTo(160f, 81.5f); quadraticTo(163.5f, 77.9f, 167f, 81.5f) }
    val eyeR = Path().apply { moveTo(173f, 81.5f); quadraticTo(176.5f, 77.9f, 180f, 81.5f) }
    drawPath(eyeL, ink, style = Stroke(1.9f, cap = StrokeCap.Round))
    drawPath(eyeR, ink, style = Stroke(1.9f, cap = StrokeCap.Round))
    drawOval(Color(0xFFFF9DB0).copy(alpha = 0.65f), Offset(155.1f, 85.9f), Size(6.8f, 4.2f))
    drawOval(Color(0xFFFF9DB0).copy(alpha = 0.65f), Offset(178.1f, 85.9f), Size(6.8f, 4.2f))
    // copo inclinado na boca
    withTransform({ rotate(-10f, Offset(170f, 98f)) }) {
        val glass = Path().apply {
            moveTo(160f, 88f); lineTo(180f, 88f); lineTo(177.5f, 108f)
            quadraticTo(170f, 111.5f, 162.5f, 108f); close()
        }
        drawPath(glass, Color(0xFFC8F8FF).copy(alpha = 0.35f))
        drawPath(glass, Color(0xFFE0FDFF), style = Stroke(1.6f))
        val water = Path().apply {
            moveTo(161.6f, 96f); lineTo(178.4f, 96f); lineTo(177f, 107.2f)
            quadraticTo(170f, 110f, 163f, 107.2f); close()
        }
        drawPath(water, Color(0xFF4FE8FF))
        drawLine(Color.White.copy(alpha = 0.7f), Offset(163f, 91f), Offset(164.3f, 104f), strokeWidth = 1.6f, cap = StrokeCap.Round)
    }
    // mãos segurando o copo
    drawCircle(skin, 5f, Offset(157.5f, 101f))
    drawCircle(skin, 5f, Offset(182.5f, 101f))
    // brilhinhos
    drawCircle(NeonSoft.copy(alpha = 0.8f), 2.2f, Offset(136f, 94f))
    drawCircle(NeonSoft.copy(alpha = 0.8f), 1.8f, Offset(206f, 88f))
    drawCircle(Color.White.copy(alpha = 0.7f), 1.4f, Offset(143f, 76f))
    drawCircle(Color.White.copy(alpha = 0.7f), 1.4f, Offset(198f, 102f))
}

/** Arte do contador (anel de 270°, círculo de vidro, água ondulando e o personagem) em 340 x 258. */
private fun DrawScope.drawCounterArt(prog: Float, phase: Float) {
    val c = Offset(170f, 140f)
    val ringR = 118f
    val ringTL = Offset(c.x - ringR, c.y - ringR)
    val ringSize = Size(ringR * 2f, ringR * 2f)
    drawArc(
        color = Color.White.copy(alpha = 0.15f), startAngle = 135f, sweepAngle = 270f, useCenter = false,
        topLeft = ringTL, size = ringSize, style = Stroke(12f, cap = StrokeCap.Round),
    )
    if (prog > 0.001f) {
        drawArc(
            brush = Brush.linearGradient(listOf(NeonBlue, NeonCyan), start = Offset(60f, 230f), end = Offset(280f, 40f)),
            startAngle = 135f, sweepAngle = 270f * prog, useCenter = false,
            topLeft = ringTL, size = ringSize, style = Stroke(12f, cap = StrokeCap.Round),
        )
    }
    val a = Math.toRadians(135.0 + 270.0 * prog)
    val dot = Offset(c.x + ringR * Math.cos(a).toFloat(), c.y + ringR * Math.sin(a).toFloat())
    drawCircle(Color.White, 9f, dot)
    drawCircle(NeonCyan, 9f, dot, style = Stroke(3f))
    // círculo de vidro
    drawCircle(Color.White.copy(alpha = 0.06f), 92f, c)
    drawCircle(NeonCyan.copy(alpha = 0.45f), 92f, c, style = Stroke(2f))
    val inner = Path().apply { addOval(Rect(c.x - 90f, c.y - 90f, c.x + 90f, c.y + 90f)) }
    clipPath(inner) {
        // água: sobe com o progresso (nunca some nem cobre tudo) e ondula devagar
        val level = 0.05f + 0.57f * prog
        val top = c.y + 92f - 184f * level
        fun waveY(px: Float): Float = top + 4f * Math.sin(px / 28.0 + phase).toFloat()
        val wave = Path()
        val fill = Path()
        wave.moveTo(60f, waveY(60f))
        fill.moveTo(60f, waveY(60f))
        var x = 60f
        while (x < 280f) {
            x += 4f
            wave.lineTo(x, waveY(x))
            fill.lineTo(x, waveY(x))
        }
        fill.lineTo(280f, 250f)
        fill.lineTo(60f, 250f)
        fill.close()
        drawPath(
            fill,
            Brush.verticalGradient(listOf(NeonCyan.copy(alpha = 0.9f), Color(0xFF1B8FEA), NeonBlue), startY = top, endY = 232f),
        )
        drawPath(wave, Color(0xFFCFFBFF).copy(alpha = 0.75f), style = Stroke(2.5f, cap = StrokeCap.Round))
        drawDrinker()
    }
}

@Composable
private fun NeonChip(text: String) {
    Text(
        text, color = Color.White, fontSize = 12.sp,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.14f))
            .padding(horizontal = 11.dp, vertical = 5.dp),
    )
}

/** Contador circular: arco de progresso, água subindo, personagem bebendo e botão de adição rápida. */
@Composable
private fun WaterCounter(
    progress: Float,
    total: Int,
    goal: Int,
    done: Boolean,
    heat: Boolean,
    quickMl: Int,
    nextLine: String?,
    onQuickAdd: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val anim by animateFloatAsState(progress.coerceIn(0f, 1f), tween(700), label = "counter")
    val waveT = rememberInfiniteTransition(label = "wave")
    val phase by waveT.animateFloat(
        initialValue = 0f,
        targetValue = (2.0 * Math.PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(4200, easing = LinearEasing), RepeatMode.Restart),
        label = "phase",
    )
    val shape = RoundedCornerShape(22.dp)
    val remaining = (goal - total).coerceAtLeast(0)
    Column(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(NeonBg1, NeonBg2)))
            .border(1.dp, NeonCyan.copy(alpha = 0.35f), shape)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        BoxWithConstraints(Modifier.fillMaxWidth().aspectRatio(340f / 258f)) {
            val k = maxWidth.value / 340f
            Canvas(Modifier.fillMaxSize()) {
                val kk = size.width / 340f
                withTransform({ scale(kk, kk, Offset.Zero) }) { drawCounterArt(anim, phase) }
            }
            Column(
                Modifier.align(Alignment.TopCenter).offset(y = (120f * k).dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text("$total", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 38.sp, lineHeight = 40.sp)
                Text("de $goal ml", color = NeonSoft, fontSize = 13.sp)
            }
            Box(
                Modifier
                    .align(Alignment.TopCenter)
                    .offset(y = (196f * k).dp)
                    .size(width = (96f * k).dp, height = (28f * k).dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White.copy(alpha = 0.2f))
                    .border(1.5.dp, NeonCyan, RoundedCornerShape(50))
                    .clickable(onClick = onQuickAdd),
                contentAlignment = Alignment.Center,
            ) {
                Text("＋ $quickMl ml", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Text(
                "0", color = NeonSoft, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.TopStart).offset(x = (86f * k - 20f).dp, y = (238f * k).dp).width(40.dp),
            )
            Text(
                "$goal ml", color = NeonSoft, fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.align(Alignment.TopStart).offset(x = (254f * k - 30f).dp, y = (238f * k).dp).width(60.dp),
            )
        }
        Column(
            Modifier.padding(top = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                NeonChip("${(progress * 100).toInt().coerceAtMost(999)}% da meta")
                NeonChip(if (done) "Meta batida! 🎉" else "Faltam ${fmtWaterMl(remaining)}")
            }
            if (nextLine != null || heat || done) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (done) NeonChip("★ Conquista do dia")
                    else nextLine?.let { NeonChip("🔔 $it") }
                    if (heat) NeonChip("Calor +$HEAT_BONUS_ML ml")
                }
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val g = glucoColors()
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = g.ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

/** Balão de fala da gotinha (com a pontinha apontando para ela, à direita). */
@Composable
private fun SpeechBubble(text: String, modifier: Modifier = Modifier) {
    val g = glucoColors()
    val fill = g.blueSoft
    val edge = g.blue.copy(alpha = 0.45f)
    Text(
        text, color = g.ink, fontSize = 14.sp, lineHeight = 19.sp,
        modifier = modifier
            .drawBehind {
                val r = CornerRadius(16.dp.toPx(), 16.dp.toPx())
                val tail = 9.dp.toPx()
                drawRoundRect(fill, size = size, cornerRadius = r)
                val p = Path().apply {
                    moveTo(size.width - 1f, 10.dp.toPx())
                    lineTo(size.width + tail, 18.dp.toPx())
                    lineTo(size.width - 1f, 26.dp.toPx())
                    close()
                }
                drawPath(p, fill)
                drawRoundRect(edge, size = size, cornerRadius = r, style = Stroke(1.dp.toPx()))
            }
            .padding(horizontal = 12.dp, vertical = 10.dp),
    )
}

/** Copo 3D de vidro com água neon (desenhado em 80 x 110). */
@Composable
private fun NeonCup(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val kk = size.width / 80f
        withTransform({ scale(kk, kk, Offset.Zero) }) {
            val cyan = Color(0xFF8CF0FF)
            drawOval(
                Brush.radialGradient(listOf(NeonCyan2.copy(alpha = 0.75f), Color.Transparent), center = Offset(40f, 100f), radius = 36f),
                topLeft = Offset(4f, 91f), size = Size(72f, 18f),
            )
            val glass = Path().apply {
                moveTo(10f, 14f); lineTo(18f, 92f)
                arcTo(Rect(18f, 86f, 62f, 98f), 180f, -180f, false)
                lineTo(70f, 14f); close()
            }
            drawPath(
                glass,
                Brush.horizontalGradient(
                    0f to cyan.copy(alpha = 0.35f), 0.35f to cyan.copy(alpha = 0.06f),
                    0.7f to cyan.copy(alpha = 0.10f), 1f to cyan.copy(alpha = 0.38f),
                    startX = 10f, endX = 70f,
                ),
            )
            val water = Path().apply {
                moveTo(12.9f, 42f); lineTo(18f, 92f)
                arcTo(Rect(18f, 86f, 62f, 98f), 180f, -180f, false)
                lineTo(67.1f, 42f); close()
            }
            drawPath(water, Brush.verticalGradient(listOf(Color(0xFF4FE8FF), Color(0xFF1B8FEA), Color(0xFF1B3FC4)), startY = 42f, endY = 98f))
            drawOval(Color(0xFF7DF3FF).copy(alpha = 0.9f), Offset(12.9f, 35f), Size(54.2f, 14f))
            drawOval(Color(0xFFE0FDFF).copy(alpha = 0.6f), Offset(21f, 38f), Size(38f, 8f))
            val outline = Path().apply {
                moveTo(10f, 14f); lineTo(18f, 92f)
                arcTo(Rect(18f, 86f, 62f, 98f), 180f, -180f, false)
                lineTo(70f, 14f)
            }
            drawPath(outline, cyan, style = Stroke(1.8f))
            drawOval(cyan.copy(alpha = 0.12f), Offset(10f, 6f), Size(60f, 16f))
            drawOval(Color(0xFFBDF8FF), Offset(10f, 6f), Size(60f, 16f), style = Stroke(1.8f))
            drawLine(Color.White.copy(alpha = 0.6f), Offset(20f, 24f), Offset(25f, 82f), strokeWidth = 3f, cap = StrokeCap.Round)
            drawLine(Color.White.copy(alpha = 0.3f), Offset(62f, 26f), Offset(58f, 70f), strokeWidth = 1.5f, cap = StrokeCap.Round)
            drawCircle(Color.White.copy(alpha = 0.7f), 2.2f, Offset(32f, 70f))
            drawCircle(Color.White.copy(alpha = 0.7f), 1.6f, Offset(46f, 60f))
            drawCircle(Color.White.copy(alpha = 0.7f), 1.4f, Offset(42f, 80f))
        }
    }
}

/** Gotinha fixa e sorridente, com bracinhos e perninhas, que fica ao lado de cada copo (sem animação e sem toque). */
@Composable
private fun CupMiniDrop(modifier: Modifier = Modifier) {
    val body = glucoColors().blue
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val ink = Color(0xFF0F172A)
        val foot = androidx.compose.ui.graphics.lerp(body, Color.Black, 0.22f)
        val hand = androidx.compose.ui.graphics.lerp(body, Color.White, 0.35f)
        val sw = w * 0.085f
        // perninhas e pezinhos
        for (lx in floatArrayOf(0.42f, 0.58f)) {
            drawLine(body, Offset(w * lx, h * 0.68f), Offset(w * lx, h * 0.89f), strokeWidth = sw, cap = StrokeCap.Round)
        }
        drawOval(foot, Offset(w * 0.30f, h * 0.885f), Size(w * 0.19f, h * 0.075f))
        drawOval(foot, Offset(w * 0.51f, h * 0.885f), Size(w * 0.19f, h * 0.075f))
        // bracinhos acenando
        for (side in floatArrayOf(-1f, 1f)) {
            val sx = w * (0.5f + side * 0.32f)
            val sy = h * 0.5f
            val ex = w * (0.5f + side * 0.44f)
            val ey = h * 0.35f
            drawLine(body, Offset(sx, sy), Offset(ex, ey), strokeWidth = sw, cap = StrokeCap.Round)
            drawCircle(hand, w * 0.05f, Offset(ex, ey))
        }
        withTransform({ scale(0.8f, 0.8f, Offset(w * 0.5f, 0f)) }) {
            val drop = Path().apply {
                moveTo(w * 0.5f, h * 0.04f)
                cubicTo(w * 0.5f, h * 0.04f, w * 0.92f, h * 0.46f, w * 0.92f, h * 0.64f)
                cubicTo(w * 0.92f, h * 0.84f, w * 0.74f, h * 0.96f, w * 0.5f, h * 0.96f)
                cubicTo(w * 0.26f, h * 0.96f, w * 0.08f, h * 0.84f, w * 0.08f, h * 0.64f)
                cubicTo(w * 0.08f, h * 0.46f, w * 0.5f, h * 0.04f, w * 0.5f, h * 0.04f)
                close()
            }
            drawPath(drop, Brush.verticalGradient(listOf(body.copy(alpha = 0.75f), body)))
            val eyeR = w * 0.06f
            drawCircle(Color.White, eyeR, Offset(w * 0.38f, h * 0.6f))
            drawCircle(Color.White, eyeR, Offset(w * 0.62f, h * 0.6f))
            drawCircle(ink, eyeR * 0.5f, Offset(w * 0.38f, h * 0.61f))
            drawCircle(ink, eyeR * 0.5f, Offset(w * 0.62f, h * 0.61f))
            drawCircle(Color(0xFFFF8FB1).copy(alpha = 0.6f), w * 0.05f, Offset(w * 0.27f, h * 0.7f))
            drawCircle(Color(0xFFFF8FB1).copy(alpha = 0.6f), w * 0.05f, Offset(w * 0.73f, h * 0.7f))
            val smile = Path().apply {
                moveTo(w * 0.4f, h * 0.74f)
                quadraticTo(w * 0.5f, h * 0.85f, w * 0.6f, h * 0.74f)
            }
            drawPath(smile, ink, style = Stroke(width = w * 0.045f, cap = StrokeCap.Round))
        }
    }
}

@Composable
private fun NeonCupCard(
    preset: WaterCupPreset,
    fav: Boolean,
    onAdd: () -> Unit,
    onToggleFav: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val shape = RoundedCornerShape(22.dp)
    // o copo cresce com o volume (raiz para os grandes não ficarem enormes)
    val frac = Math.sqrt(((preset.ml - 150).coerceAtLeast(0) / 850f).toDouble()).toFloat().coerceIn(0f, 1f)
    val cupH = (56f + 48f * frac).dp
    Box(
        modifier
            .clip(shape)
            .background(Brush.linearGradient(listOf(NeonBg1, NeonBg2)))
            .border(if (fav) 2.dp else 1.dp, if (fav) NeonCyan else NeonCyan.copy(alpha = 0.35f), shape)
            .clickable(onClick = onAdd)
            .padding(horizontal = 10.dp, vertical = 10.dp),
    ) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.height(104.dp), verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.Center) {
                NeonCup(Modifier.size(width = cupH * 0.727f, height = cupH))
                CupMiniDrop(Modifier.padding(start = 2.dp).size(width = 38.dp, height = 47.dp))
            }
            Text(preset.label, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, modifier = Modifier.padding(top = 4.dp, bottom = 6.dp))
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(50))
                    .background(Brush.horizontalGradient(listOf(NeonCyan2, NeonBlue)))
                    .padding(vertical = 8.dp),
                contentAlignment = Alignment.Center,
            ) {
                Text("＋ adicionar", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
        }
        Icon(
            if (fav) Icons.Filled.Star else Icons.Outlined.StarBorder,
            contentDescription = if (fav) "Tirar dos favoritos" else "Favoritar",
            tint = if (fav) Color(0xFFFBBF24) else Color.White.copy(alpha = 0.55f),
            modifier = Modifier.align(Alignment.TopEnd).size(24.dp).clip(CircleShape).clickable(onClick = onToggleFav),
        )
    }
}

@Composable
fun WaterMiniBar(visible: Boolean, onOpenFull: () -> Unit, modifier: Modifier = Modifier, glassScale: Float? = null, lilac: Boolean = false) {
    val ctx = LocalContext.current
    val g = glucoColors()
    var goal by remember { mutableIntStateOf(effectiveWaterGoal(ctx)) }
    var entries by remember { mutableStateOf(loadWaterEntries(ctx)) }
    var flash by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val total = entries.sumOf { it.ml }
    val done = total >= goal
    val progress = (total.toFloat() / goal.coerceAtLeast(1)).coerceIn(0f, 1f)
    val accent = if (done) g.green else g.blue

    fun addQuick() {
        val e = WaterEntry(SystemClock.uptimeMillis().toString(), 250, System.currentTimeMillis(), "glass")
        entries = listOf(e) + entries
        saveWaterEntries(ctx, entries)
        goal = effectiveWaterGoal(ctx)
        if (entries.sumOf { it.ml } >= goal) markWaterReminded(ctx)
        flash = true
        scope.launch {
            delay(1200)
            flash = false
        }
    }

    if (glassScale != null && lilac) {
        val gs: Float = glassScale
        fun dd(v: Float) = (v * gs).dp
        AnimatedVisibility(
            visible = visible,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
        Box(modifier.fillMaxWidth().lilacCard(gs).clickable { onOpenFull() }) {
            Image(painterResource(R.drawable.lilac_hdrop), null, Modifier.offset(dd(19f), dd(9f)).size(dd(88f), dd(88f)), contentScale = ContentScale.Fit)
            Text("Cris Hidrata", color = LilacIndigo, fontWeight = FontWeight.ExtraBold, fontSize = (29f * gs).sp, maxLines = 1, softWrap = false, modifier = Modifier.offset(dd(123f), dd(20f)))
            Text(
                if (flash) "+250 ml" else if (done) "$total ml ✓" else "$total / $goal ml",
                color = LilacInk, fontSize = (28f * gs).sp, maxLines = 1, softWrap = false,
                modifier = Modifier.align(Alignment.TopEnd).padding(end = dd(141f), top = dd(20f)),
            )
            Box(Modifier.offset(dd(123f), dd(68f)).width(dd(560f)).height(dd(17f)).clip(RoundedCornerShape(dd(8.5f))).background(Color(0xFFD9B6F0))) {
                if (progress > 0f) {
                    Box(Modifier.fillMaxWidth(progress).fillMaxHeight().clip(RoundedCornerShape(dd(8.5f))).background(Brush.horizontalGradient(listOf(Color(0xFF5D01BB), Color(0xFF9A3FE0)))))
                }
            }
            Box(
                Modifier
                    .offset(dd(704f), dd(12f))
                    .size(dd(82f))
                    .shadow(6.dp, CircleShape, clip = false, ambientColor = Color(0xFF9B1FE0), spotColor = Color(0xFF9B1FE0))
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color(0xFFC864F5), Color(0xFF9600E1))))
                    .border(2.dp, Color.White.copy(alpha = 0.85f), CircleShape)
                    .clickable { addQuick() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Adicionar 250 ml", tint = Color.White, modifier = Modifier.size(dd(50f)))
            }
        }
        }
        return
    }

    if (glassScale != null) {
        val gs: Float = glassScale
        fun dd(v: Float) = (v * gs).dp
        AnimatedVisibility(
            visible = visible,
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
        Box(modifier.fillMaxWidth().glassCard(gs, accent = false).clickable { onOpenFull() }) {
            Image(painterResource(R.drawable.home3_ic_hdrop), null, Modifier.offset(dd(28f), dd(5f)).size(dd(78f), dd(90f)), contentScale = ContentScale.Fit)
            Text("Cris Hidrata", color = GlassNavy, fontWeight = FontWeight.ExtraBold, fontSize = (28f * gs).sp, maxLines = 1, softWrap = false, modifier = Modifier.offset(dd(125f), dd(20f)))
            Text(
                if (flash) "+250 ml" else if (done) "$total ml ✓" else "$total / $goal ml",
                color = GlassNavy, fontSize = (28f * gs).sp, maxLines = 1, softWrap = false,
                modifier = Modifier.align(Alignment.TopEnd).padding(end = dd(135f), top = dd(20f)),
            )
            Box(Modifier.offset(dd(125f), dd(75f)).width(dd(543f)).height(dd(14f)).clip(RoundedCornerShape(dd(7f))).background(Color(0xFF9EC5EB))) {
                if (progress > 0f) {
                    Box(Modifier.fillMaxWidth(progress).fillMaxHeight().clip(RoundedCornerShape(dd(7f))).background(Brush.horizontalGradient(listOf(Color(0xFF0190FD), Color(0xFF3EC1FF)))))
                }
            }
            Box(
                Modifier
                    .offset(dd(700f), dd(12f))
                    .size(dd(86f))
                    .shadow(6.dp, CircleShape, clip = false, ambientColor = Color(0xFF0A55E0), spotColor = Color(0xFF0A55E0))
                    .clip(CircleShape)
                    .background(Brush.linearGradient(listOf(Color(0xFF3AB0FF), Color(0xFF0A55E0))))
                    .border(2.dp, Color.White.copy(alpha = 0.85f), CircleShape)
                    .clickable { addQuick() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Adicionar 250 ml", tint = Color.White, modifier = Modifier.size(dd(52f)))
            }
        }
        }
        return
    }

    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically { it } + fadeIn(),
        exit = slideOutVertically { it } + fadeOut(),
    ) {
        val shape = RoundedCornerShape(22.dp)
        Row(
            modifier
                .fillMaxWidth()
                .heightIn(min = 46.dp)
                .clip(shape)
                .background(Brush.horizontalGradient(listOf(Color(0xFF14043F), Color(0xFF0E0636), Color(0xFF1F0852))))
                .border(1.5.dp, Brush.horizontalGradient(listOf(Color(0xFF7A2BFF), Color(0xFFB51BFF), Color(0xFF7A2BFF))), shape)
                .clickable { onOpenFull() }
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.WaterDrop, contentDescription = null, tint = Color(0xFF2AA8FF), modifier = Modifier.size(24.dp))
            Column(Modifier.weight(1f).padding(start = 12.dp, end = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Cris Hidrata", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Text(
                        if (flash) "+250 ml" else if (done) "$total ml ✓" else "$total / $goal ml",
                        color = Color.White.copy(alpha = 0.86f), fontSize = 11.sp,
                    )
                }
                Box(Modifier.padding(top = 4.dp).fillMaxWidth().height(6.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF2B2478))) {
                    Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(Brush.horizontalGradient(listOf(Color(0xFF168BFF), Color(0xFF2AB8FF)))))
                }
            }
            Box(
                Modifier.size(34.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF168BFF), Color(0xFF0054D8)))).clickable { addQuick() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Adicionar 250 ml", tint = Color.White, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun WaterClockCard(total: Int, goal: Int, modifier: Modifier = Modifier, onChanged: () -> Unit = {}) {
    val ctx = LocalContext.current
    val g = glucoColors()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var times by remember { mutableStateOf(loadWaterClockTimes(ctx)) }
    var on by remember { mutableStateOf(waterClockOn(ctx)) }
    var hours by remember { mutableIntStateOf(waterRemindHours(ctx)) }
    var expanded by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(15_000)
        }
    }
    val clockFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val cal = Calendar.getInstance().apply { timeInMillis = now }
    val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    val mins = times.mapNotNull { t -> parseClock(t)?.let { it.first * 60 + it.second } }
    val left = mins.count { it > nowMin }
    val nextMin = mins.firstOrNull { it > nowMin } ?: mins.firstOrNull()
    val remaining = (goal - total).coerceAtLeast(0)
    val suggest = if (remaining <= 0) 0 else (((remaining / left.coerceAtLeast(1)) + 25) / 50 * 50).coerceIn(100, 500)

    fun commitTimes(list: List<String>) {
        times = list.distinct().sorted()
        saveWaterClockTimes(ctx, times)
        onChanged()
    }

    fun pick(initial: String?, onPicked: (String) -> Unit) {
        val hm = initial?.let { parseClock(it) } ?: (cal.get(Calendar.HOUR_OF_DAY) to 0)
        android.app.TimePickerDialog(
            ctx,
            { _, h, m -> onPicked("%02d:%02d".format(h, m)) },
            hm.first, hm.second, true,
        ).show()
    }

    val summary = (if (on) "Ligados" else "Desligados") +
        (if (times.isNotEmpty()) " · ${times.first()} às ${times.last()} · a cada ${hours}h" else " · sem horários")

    GCard(modifier) {
        // Cabeçalho recolhido: ícone, estado, interruptor e seta para abrir os ajustes
        Row(Modifier.fillMaxWidth().clickable { expanded = !expanded }, verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(40.dp).clip(CircleShape).background(g.blueSoft), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.Notifications, null, tint = g.blue, modifier = Modifier.size(20.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text("Lembretes", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                Text(summary, color = g.muted, fontSize = 12.sp)
            }
            Switch(checked = on, onCheckedChange = {
                on = it
                setWaterClockOn(ctx, it)
            })
            Icon(
                if (expanded) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                if (expanded) "Recolher lembretes" else "Abrir lembretes",
                tint = g.muted, modifier = Modifier.padding(start = 4.dp).size(22.dp),
            )
        }
        if (expanded) {
            Text("Relógio inteligente", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp))
            Text(clockFmt.format(Date(now)), color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 34.sp)
            Text(
                when {
                    remaining <= 0 -> "Meta batida: o relógio fica em silêncio hoje. 🎉"
                    nextMin != null -> "Próximo: %02d:%02d · beba cerca de %d ml".format(nextMin / 60, nextMin % 60, suggest)
                    else -> "Adicione um horário para o relógio te avisar."
                },
                color = g.ink, fontSize = 13.sp,
                modifier = Modifier.padding(top = 8.dp).fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp)).background(g.blueSoft).padding(10.dp),
            )
            Text("Horários (toque para editar)", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(times, key = { it }) { t ->
                    Row(
                        Modifier.clip(RoundedCornerShape(14.dp)).background(g.blueSoft)
                            .clickable { pick(t) { n -> commitTimes(times.filter { it != t } + n) } }
                            .padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(t, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Icon(
                            Icons.Filled.Close, "Remover $t", tint = g.muted,
                            modifier = Modifier.padding(start = 4.dp).size(24.dp).clip(CircleShape)
                                .clickable { commitTimes(times.filter { it != t }) }.padding(4.dp),
                        )
                    }
                }
                item {
                    Text(
                        "＋ Horário", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                        modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(g.blue)
                            .clickable { pick(null) { n -> commitTimes(times + n) } }
                            .padding(horizontal = 14.dp, vertical = 9.dp),
                    )
                }
            }
            Text("Gerar horários automáticos a cada", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(1, 2, 3, 4).forEach { h ->
                    val sel = hours == h
                    Text(
                        "${h}h",
                        color = if (sel) Color.White else g.muted,
                        fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                        modifier = Modifier.clip(RoundedCornerShape(12.dp))
                            .background(if (sel) g.blue else g.blueSoft)
                            .clickable {
                                hours = h
                                setWaterRemindHours(ctx, h)
                                commitTimes(defaultWaterClockTimes(h))
                            }
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                    )
                }
            }
        }
    }
}

@Composable
fun WaterTrackerScreen(vm: GlucoViewModel, nav: NavHostController) {
    val ctx = LocalContext.current
    val g = glucoColors()
    val data by vm.data.collectAsStateWithLifecycle()
    var goal by remember { mutableIntStateOf(loadWaterGoal(ctx)) }
    var goalText by remember { mutableStateOf(goal.toString()) }
    var effective by remember { mutableIntStateOf(effectiveWaterGoal(ctx)) }
    var entries by remember { mutableStateOf(loadWaterEntries(ctx)) }
    var customMl by remember { mutableStateOf("") }
    var undoEntry by remember { mutableStateOf<WaterEntry?>(null) }
    var sounds by remember { mutableStateOf(waterSoundsOn(ctx)) }
    var heat by remember { mutableStateOf(isHeatModeToday(ctx)) }
    var askMeal by remember { mutableStateOf(askWaterAfterMeal(ctx)) }
    var favs by remember { mutableStateOf(loadFavCups(ctx)) }
    var remindH by remember { mutableIntStateOf(waterRemindHours(ctx)) }
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    var highAlert by remember { mutableStateOf(WaterAlert.isOn(ctx)) }
    val latestGlucose = remember(data.glucose) { data.glucose.maxByOrNull { it.at } }
    val latestMg = latestGlucose?.let { toMgDl(it.value, it.unit) }
    val glucoseHigh = highAlert && latestGlucose != null && latestMg != null &&
        latestMg > data.settings.targetHigh &&
        System.currentTimeMillis() - latestGlucose.at < 6L * 60L * 60L * 1000L
    val total = entries.sumOf { it.ml }
    val progress = total.toFloat() / effective.coerceAtLeast(1)
    val done = progress >= 1f
    val mood = waterMood(progress.coerceAtMost(1f))
    val insight = remember(entries.size, effective) { waterInsightLine(ctx) }
    val suggested = suggestedWaterGoalMl(data.settings.weightKg)
    val cups = remember(favs) {
        CUP_PRESETS.sortedWith(compareByDescending<WaterCupPreset> { it.ml in favs }.thenBy { it.ml })
    }

    var showAllCups by remember { mutableStateOf(false) }
    var showCustom by remember { mutableStateOf(false) }
    var clockTick by remember { mutableIntStateOf(0) }
    val next = remember(entries.size, effective, clockTick) { nextWaterReminder(ctx, total, effective) }
    // A gotinha fala o lembrete do dia (antes ele ficava num card de texto).
    val bubbleText = run {
        val tip = next?.let { "Que tal ${it.second} ml às ${it.first}?" }
        val base = insight?.removePrefix("Lembrete suave: ")?.replaceFirstChar { c -> c.uppercase() }
        when {
            done -> "Meta batida! Parabéns, você arrasou! 🎉"
            base != null && base.contains("Que tal") -> base
            base != null -> if (tip != null) "$base $tip" else base
            tip != null -> "Ainda falta água para a meta. $tip"
            else -> "Ainda falta água para a meta. Bora beber um copo?"
        }
    }

    fun refreshGoal() {
        goal = loadWaterGoal(ctx)
        effective = effectiveWaterGoal(ctx)
        goalText = goal.toString()
    }

    fun addEntry(ml: Int, kind: String) {
        val e = WaterEntry(SystemClock.uptimeMillis().toString(), ml, System.currentTimeMillis(), kind)
        entries = listOf(e) + entries
        saveWaterEntries(ctx, entries)
        undoEntry = e
        if (entries.sumOf { it.ml } >= effective) markWaterReminded(ctx)
    }

    fun removeEntry(id: String) {
        entries = entries.filter { it.id != id }
        saveWaterEntries(ctx, entries)
    }

    LaunchedEffect(undoEntry) {
        if (undoEntry != null) {
            delay(5000)
            undoEntry = null
        }
    }

    Box(Modifier.fillMaxSize().background(g.bg)) {
        Column(Modifier.fillMaxSize()) {
            // Topo: título, balão de fala e a gotinha (com bracinhos e perninhas)
            Box(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(start = 8.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { nav.popBackStack() }) {
                            Icon(Icons.Filled.Close, "Fechar", tint = g.ink)
                        }
                        Text("Cris Hidrata", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    }
                    SpeechBubble(bubbleText, Modifier.fillMaxWidth().padding(start = 16.dp, end = 92.dp, bottom = 10.dp))
                }
                CrisDrop(
                    mood,
                    Modifier.align(Alignment.TopEnd).padding(top = 14.dp, end = 14.dp)
                        .size(width = 62.dp, height = 78.dp).tourTarget("water_drop"),
                    limbs = true,
                )
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                // Contador circular
                WaterCounter(
                    progress = progress,
                    total = total,
                    goal = effective,
                    done = done,
                    heat = heat,
                    quickMl = entries.firstOrNull()?.ml ?: 200,
                    nextLine = next?.let { "${it.first} · ${it.second} ml" },
                    onQuickAdd = { addEntry(entries.firstOrNull()?.ml ?: 200, "glass") },
                    modifier = Modifier.tourTarget("water_ring"),
                )

                // Adicionar água
                Column(Modifier.tourTarget("water_cups")) {
                    Text("Adicionar água", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                    Text("Toque no copo para somar. A estrela fixa seus favoritos no começo.", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp))
                    val shown = if (showAllCups) cups else cups.take(4)
                    shown.chunked(2).forEach { pair ->
                        Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            pair.forEach { pr ->
                                NeonCupCard(
                                    preset = pr,
                                    fav = pr.ml in favs,
                                    onAdd = { addEntry(pr.ml, pr.kind) },
                                    onToggleFav = {
                                        toggleFavCup(ctx, pr.ml)
                                        favs = loadFavCups(ctx)
                                    },
                                    modifier = Modifier.weight(1f),
                                )
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                    if (cups.size > 4) {
                        TextButton(onClick = { showAllCups = !showAllCups }) {
                            Text(
                                if (showAllCups) "Mostrar menos copos" else "Mais copos (${cups.size - 4})",
                                color = g.blue, fontWeight = FontWeight.Bold,
                            )
                        }
                    }
                    // Quantidade personalizada (pílula tracejada que abre o campo)
                    val dash = NeonCyan2
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(50))
                            .clickable { showCustom = !showCustom }
                            .drawBehind {
                                drawRoundRect(
                                    color = dash,
                                    cornerRadius = CornerRadius(size.height / 2f, size.height / 2f),
                                    style = Stroke(1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f))),
                                )
                            }
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.Tune, null, tint = g.blue, modifier = Modifier.size(18.dp))
                        Text("Quantidade personalizada", color = g.blue, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(start = 8.dp))
                    }
                    if (showCustom) {
                        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(
                                value = customMl,
                                onValueChange = { customMl = it.filter { ch -> ch.isDigit() }.take(4) },
                                modifier = Modifier.weight(1f),
                                singleLine = true,
                                label = { Text("ml") },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            )
                            Box(
                                Modifier
                                    .padding(start = 10.dp)
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(g.blue)
                                    .clickable {
                                        val ml = customMl.toIntOrNull() ?: return@clickable
                                        if (ml in 1..2000) {
                                            addEntry(ml, "custom")
                                            customMl = ""
                                        }
                                    },
                                contentAlignment = Alignment.Center,
                            ) {
                                Icon(Icons.Filled.Add, "Adicionar", tint = Color.White)
                            }
                        }
                    }
                }

                // Registros de hoje (com o próximo lembrete no topo)
                GCard {
                    Text("Registros de hoje", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    next?.let { (time, ml) ->
                        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Schedule, null, tint = g.blue, modifier = Modifier.size(20.dp))
                            Text(time, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(start = 12.dp).width(56.dp))
                            Text("próximo lembrete", color = g.muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            Text("$ml ml", color = g.muted, fontSize = 14.sp)
                        }
                    }
                    if (entries.isEmpty()) {
                        Text("Nenhum copo ainda. Toque em um copo acima.", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                    } else {
                        entries.forEach { e ->
                            Box(Modifier.fillMaxWidth().padding(top = 6.dp).height(0.5.dp).background(g.line))
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.WaterDrop, null, tint = g.blue, modifier = Modifier.size(20.dp))
                                Text(timeFmt.format(Date(e.at)), color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(start = 12.dp).width(56.dp))
                                Spacer(Modifier.weight(1f))
                                Text("${e.ml} ml", color = g.muted, fontSize = 14.sp)
                                IconButton(onClick = { removeEntry(e.id) }) {
                                    Icon(Icons.Filled.Delete, "Excluir", tint = g.muted)
                                }
                            }
                        }
                    }
                }

                // Lembretes (recolhido; abre para editar os horários)
                WaterClockCard(total, effective, Modifier.tourTarget("water_clock"), onChanged = { clockTick++ })

                // Alerta: glicose alta -> beber água (liga/desliga)
                GCard(Modifier.tourTarget("water_alert")) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(40.dp).clip(CircleShape).background(g.redSoft), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Favorite, null, tint = g.red, modifier = Modifier.size(20.dp))
                        }
                        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                            Text("Alerta de glicose alta", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                            Text(
                                "Avisa para beber água quando a glicose passar de ${data.settings.targetHigh} mg/dL (sua meta máxima).",
                                color = g.muted, fontSize = 12.sp,
                            )
                        }
                        Switch(checked = highAlert, onCheckedChange = {
                            highAlert = it
                            WaterAlert.setOn(ctx, it)
                        })
                    }
                    if (glucoseHigh && latestGlucose != null && latestMg != null) {
                        Column(
                            Modifier.padding(top = 10.dp).fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp)).background(g.red.copy(alpha = 0.14f)).padding(12.dp),
                        ) {
                            Text(
                                "⚠ Glicose alta: ${latestMg.toInt()} mg/dL às ${timeFmt.format(Date(latestGlucose.at))}. Beba um copo de água agora e siga a orientação da sua equipe de saúde.",
                                color = g.ink, fontSize = 13.sp,
                            )
                            Text(
                                "Beber 250 ml", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                                modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(12.dp))
                                    .background(g.blue).clickable { addEntry(250, "glass") }
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                            )
                        }
                    }
                }

                // Ajustes do contador
                GCard {
                    Text("Ajustes do contador", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Text("Meta base (ml)", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = goalText,
                            onValueChange = { goalText = it.filter { ch -> ch.isDigit() }.take(4) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        )
                        TextButton(onClick = {
                            val v = goalText.toIntOrNull() ?: return@TextButton
                            saveWaterGoal(ctx, v)
                            refreshGoal()
                        }) { Text("Salvar", color = g.blue, fontWeight = FontWeight.Bold) }
                    }
                    if (suggested != null) {
                        TextButton(onClick = {
                            saveWaterGoal(ctx, suggested)
                            refreshGoal()
                        }) {
                            Text("Usar meta sugerida (~35 ml/kg): $suggested ml", color = g.blue)
                        }
                    } else {
                        Text("Preencha o peso no Perfil para sugerir meta automática.", color = g.muted, fontSize = 12.sp)
                    }
                    SwitchRow("Modo calor / exercício (+$HEAT_BONUS_ML ml hoje)", heat) {
                        heat = it
                        setHeatModeToday(ctx, it)
                        effective = effectiveWaterGoal(ctx)
                    }
                    SwitchRow("Sons (gota e cócegas)", sounds) {
                        sounds = it
                        setWaterSoundsOn(ctx, it)
                    }
                    SwitchRow("Perguntar água ao salvar refeição", askMeal) {
                        askMeal = it
                        setAskWaterAfterMeal(ctx, it)
                    }
                }

                Text(
                    "Hidratação de apoio. Não substitui orientação médica.",
                    color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp),
                )
            }
        }

        AnimatedVisibility(
            visible = undoEntry != null,
            modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            val last = undoEntry
            val pill = RoundedCornerShape(50)
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(pill)
                    .background(NeonBg1)
                    .border(1.dp, NeonCyan.copy(alpha = 0.35f), pill)
                    .padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("✓ +${last?.ml ?: 0} ml adicionados", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(
                    "Desfazer",
                    color = NeonCyan,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            last?.let { removeEntry(it.id) }
                            undoEntry = null
                        }
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                )
            }
        }
    }
}
