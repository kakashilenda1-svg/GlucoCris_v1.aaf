package com.agon.app.ui.theme

import android.content.Context
import androidx.compose.runtime.mutableStateOf

/**
 * Acessibilidade MANUAL: nada muda sozinho. A pessoa escolhe aqui (botão "Aa") e a escolha vale só neste aparelho.
 * O tamanho do texto se SOMA ao tamanho de fonte do Android (não o substitui).
 */
object AccessibilityPrefs {
    private const val PREFS = "gluco_accessibility"
    val SCALES = floatArrayOf(1.0f, 1.15f, 1.3f, 1.5f)
    val LABELS = listOf("Normal", "Grande", "Maior", "Máximo")

    /** 0..3 */
    val level = mutableStateOf(0)
    val highContrast = mutableStateOf(false)
    val bigTouch = mutableStateOf(false)

    /** Tipo de letra escolhido (id de AppFonts). Vale para o app inteiro. */
    val fontId = mutableStateOf(AppFonts.DEFAULT_ID)
    private var loaded = false

    fun load(c: Context) {
        if (loaded) return
        val p = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        level.value = p.getInt("level", 0).coerceIn(0, 3)
        highContrast.value = p.getBoolean("contrast", false)
        bigTouch.value = p.getBoolean("big_touch", false)
        fontId.value = p.getString("font_id", AppFonts.DEFAULT_ID) ?: AppFonts.DEFAULT_ID
        loaded = true
    }

    private fun p(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun setLevel(c: Context, v: Int) { level.value = v.coerceIn(0, 3); p(c).edit().putInt("level", level.value).apply() }
    fun setHighContrast(c: Context, v: Boolean) { highContrast.value = v; p(c).edit().putBoolean("contrast", v).apply() }
    fun setBigTouch(c: Context, v: Boolean) { bigTouch.value = v; p(c).edit().putBoolean("big_touch", v).apply() }
    fun setFont(c: Context, id: String) { fontId.value = id; p(c).edit().putString("font_id", id).apply() }
    fun reset(c: Context) { setLevel(c, 0); setHighContrast(c, false); setBigTouch(c, false); setFont(c, AppFonts.DEFAULT_ID) }

    fun scale(): Float = SCALES[level.value.coerceIn(0, 3)]
}
