package com.agon.app.ui.theme

import android.graphics.Typeface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalFontFamilyResolver
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import com.agon.app.R

/** Uma opção de tipo de letra da Acessibilidade. As fontes ficam DENTRO do app (funcionam sem internet). */
data class AppFontOption(val id: String, val label: String, val note: String, val family: FontFamily)

object AppFonts {
    const val DEFAULT_ID = "padrao"

    private fun fam(regular: Int, bold: Int) = FontFamily(
        Font(regular, FontWeight.Normal),
        Font(bold, FontWeight.Bold),
    )

    /** "Padrão" (fonte original) + 18 tipos de letra famosos e elegantes (as da lista famosa usam equivalentes livres, embutidos no app). */
    val options: List<AppFontOption> by lazy {
        listOf(
            AppFontOption(DEFAULT_ID, "Padrão do app", "A letra original do aparelho", FontFamily.Default),
            AppFontOption("inter", "Inter", "Moderna e muito nítida, ótima para números", fam(R.font.inter_regular, R.font.inter_bold)),
            AppFontOption("worksans", "Work Sans", "Limpa e confortável para textos longos", fam(R.font.worksans_regular, R.font.worksans_bold)),
            AppFontOption("outfit", "Outfit", "Geométrica, redonda e moderna", fam(R.font.outfit_regular, R.font.outfit_bold)),
            AppFontOption("instrumentsans", "Instrument Sans", "Elegante e discreta", fam(R.font.instrumentsans_regular, R.font.instrumentsans_bold)),
            AppFontOption("carlito", "Carlito (estilo Calibri)", "Suave e familiar, como no Word", fam(R.font.carlito_regular, R.font.carlito_bold)),
            AppFontOption("dejavusans", "DejaVu Sans (estilo Verdana)", "Letras largas, muito fáceis de ler", fam(R.font.dejavusans_regular, R.font.dejavusans_bold)),
            AppFontOption("lora", "Lora", "Serifada clássica e elegante", fam(R.font.lora_regular, R.font.lora_bold)),
            AppFontOption("crimsonpro", "Crimson Pro", "Serifada refinada, de livro", fam(R.font.crimsonpro_regular, R.font.crimsonpro_bold)),
            AppFontOption("ibmplexserif", "IBM Plex Serif", "Serifada firme e profissional", fam(R.font.ibmplexserif_regular, R.font.ibmplexserif_bold)),
            AppFontOption("caladea", "Caladea (estilo Cambria)", "Serifada formal e legível", fam(R.font.caladea_regular, R.font.caladea_bold)),
            AppFontOption("heros", "Helvetica (TeX Gyre Heros)", "Sem serifa, limpa e muito versátil", fam(R.font.heros_regular, R.font.heros_bold)),
            AppFontOption("arimo", "Arial (Arimo)", "Sem serifa, popular em documentos e na web", fam(R.font.arimo_regular, R.font.arimo_bold)),
            AppFontOption("tinos", "Times New Roman (Tinos)", "Serifada clássica, de jornais e trabalhos acadêmicos", fam(R.font.tinos_regular, R.font.tinos_bold)),
            AppFontOption("jost", "Futura (Jost)", "Sem serifa geométrica, moderna, de círculos e quadrados", fam(R.font.jost_regular, R.font.jost_bold)),
            AppFontOption("ebgaramond", "Garamond (EB Garamond)", "Serifada de estilo antigo, elegante e tradicional", fam(R.font.ebgaramond_regular, R.font.ebgaramond_bold)),
            AppFontOption("courierprime", "Courier (Courier Prime)", "Monoespaçada, lembra máquina de escrever", fam(R.font.courierprime_regular, R.font.courierprime_bold)),
            AppFontOption("bodonimoda", "Bodoni (Bodoni Moda)", "Serifada de alto contraste, elegante, de moda e luxo", fam(R.font.bodonimoda_regular, R.font.bodonimoda_bold)),
            AppFontOption("roboto", "Roboto", "Sem serifa geométrica e orgânica, padrão do Android", fam(R.font.roboto_regular, R.font.roboto_bold)),
        )
    }

    fun byId(id: String): AppFontOption = options.firstOrNull { it.id == id } ?: options.first()
}

/** Tipo de letra escolhido em Acessibilidade. Use onde o texto é montado "na mão" (campos BasicTextField, medições), que não herdam o tema sozinhos. */
@Composable
fun appFontFamily(): FontFamily = AppFonts.byId(AccessibilityPrefs.fontId.value).family

/** A mesma letra como Typeface nativo, para texto desenhado em Canvas/Paint (gráficos). */
@Composable
fun appTypeface(bold: Boolean = false): Typeface {
    val family = appFontFamily()
    val resolver = LocalFontFamilyResolver.current
    return remember(family, bold) {
        val v = resolver.resolve(family, if (bold) FontWeight.Bold else FontWeight.Normal).value
        (v as? Typeface) ?: (if (bold) Typeface.DEFAULT_BOLD else Typeface.DEFAULT)
    }
}
