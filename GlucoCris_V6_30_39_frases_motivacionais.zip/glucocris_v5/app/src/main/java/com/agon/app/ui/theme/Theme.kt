package com.agon.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.material3.ProvideTextStyle
import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density

val LocalGluco = staticCompositionLocalOf { LightGlucoColors }

@Composable
fun glucoColors(): GlucoColors = LocalGluco.current

@Composable
fun AgonAppTheme(
    darkTheme: Boolean = false,
    blueTheme: Boolean = false,
    content: @Composable () -> Unit,
) {
    val g = when {
        blueTheme && darkTheme -> BlueDarkGlucoColors
        blueTheme -> BlueLightGlucoColors
        darkTheme -> DarkGlucoColors
        else -> LightGlucoColors
    }
    val scheme = if (darkTheme) {
        darkColorScheme(
            primary = g.violet,
            onPrimary = g.bg,
            secondary = g.blue,
            tertiary = g.green,
            background = g.bg,
            onBackground = g.ink,
            surface = g.bg,
            onSurface = g.ink,
            surfaceVariant = g.card,
            onSurfaceVariant = g.ink,
            outline = g.line,
            error = g.red,
        )
    } else {
        lightColorScheme(
            primary = g.violet,
            onPrimary = g.card,
            secondary = g.blue,
            tertiary = g.green,
            background = g.bg,
            onBackground = g.ink,
            surface = g.bg,
            onSurface = g.ink,
            surfaceVariant = g.card,
            onSurfaceVariant = g.ink,
            outline = g.line,
            error = g.red,
        )
    }
    // Acessibilidade manual (botão "Aa"): contraste alto deixa textos de apoio e linhas bem visíveis.
    val gFinal = if (AccessibilityPrefs.highContrast.value) g.copy(muted = g.ink, line = g.ink.copy(alpha = 0.55f)) else g
    val base = LocalDensity.current
    // Tamanho final = fonte do Android x escolha do app, com teto de 2x para a tela sempre caber.
    val effective = (base.fontScale * AccessibilityPrefs.scale()).coerceAtMost(2.0f)
    val density = Density(base.density, effective)
    // Tipo de letra escolhido em Acessibilidade: vale para todo o app (títulos, textos, campos de escrita).
    val family: FontFamily = AppFonts.byId(AccessibilityPrefs.fontId.value).family
    val t = Typography()
    val typography = Typography(
        displayLarge = t.displayLarge.copy(fontFamily = family),
        displayMedium = t.displayMedium.copy(fontFamily = family),
        displaySmall = t.displaySmall.copy(fontFamily = family),
        headlineLarge = t.headlineLarge.copy(fontFamily = family),
        headlineMedium = t.headlineMedium.copy(fontFamily = family),
        headlineSmall = t.headlineSmall.copy(fontFamily = family),
        titleLarge = t.titleLarge.copy(fontFamily = family),
        titleMedium = t.titleMedium.copy(fontFamily = family),
        titleSmall = t.titleSmall.copy(fontFamily = family),
        bodyLarge = t.bodyLarge.copy(fontFamily = family),
        bodyMedium = t.bodyMedium.copy(fontFamily = family),
        bodySmall = t.bodySmall.copy(fontFamily = family),
        labelLarge = t.labelLarge.copy(fontFamily = family),
        labelMedium = t.labelMedium.copy(fontFamily = family),
        labelSmall = t.labelSmall.copy(fontFamily = family),
    )
    CompositionLocalProvider(
        LocalGluco provides gFinal,
        LocalDensity provides density,
    ) {
        MaterialTheme(colorScheme = scheme, typography = typography) {
            ProvideTextStyle(TextStyle(fontFamily = family)) { content() }
        }
    }
}

/** Limita o aumento da letra num pedaço fixo da tela (ex.: barra de abas), para os rótulos não estourarem. */
@Composable
fun CappedFontScale(max: Float, content: @Composable () -> Unit) {
    val d = LocalDensity.current
    if (d.fontScale <= max) {
        content()
    } else {
        CompositionLocalProvider(LocalDensity provides Density(d.density, max)) { content() }
    }
}
