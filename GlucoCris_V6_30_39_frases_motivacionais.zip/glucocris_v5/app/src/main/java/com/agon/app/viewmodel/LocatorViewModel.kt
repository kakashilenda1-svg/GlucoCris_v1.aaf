package com.agon.app.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.agon.app.data.PlaceFinder
import com.agon.app.data.insulin.City
import com.agon.app.data.insulin.CityIndex
import com.agon.app.data.insulin.CityTier
import com.agon.app.data.insulin.LocatorQuery
import com.agon.app.data.insulin.LocatorScope
import com.agon.app.data.insulin.SortMode

/** De onde veio o ponto de partida da busca. */
enum class OriginKind { GPS, BUSCA, MUNICIPIO }

/** Situação do "Perto de mim". */
enum class LocState { IDLE, ASKING, LOCATING, READY, DENIED, DISABLED, FAILED }

/**
 * Ponto de partida da busca de locais reais: onde a pessoa está (GPS), um lugar buscado
 * (cidade, bairro, rua ou CEP) ou um município escolhido na lista.
 */
data class Origin(
    val lat: Double,
    val lon: Double,
    val label: String,
    val kind: OriginKind,
    /** Município do ponto, quando se sabe qual é. */
    val city: City?,
    /** Só achamos a cidade/bairro, não o endereço exato. */
    val approximate: Boolean = false,
) {
    /** Município de referência para distâncias (sintético quando o município não é conhecido). */
    val refCity: City get() = city ?: City("origem", label, "", lat, lon, CityTier.INTERIOR)
}

/**
 * ViewModel do Localizador de Insulina.
 * Fica vivo enquanto a tela está na pilha de navegação: a posição e a busca não se perdem ao voltar.
 */
class LocatorViewModel : ViewModel() {
    var text by mutableStateOf("")
    var productId by mutableStateOf("all")
    var categoryIds by mutableStateOf<Set<String>>(emptySet())
    var channelIds by mutableStateOf<Set<String>>(emptySet())
    var scope by mutableStateOf(LocatorScope.BRASIL)
    var uf by mutableStateOf<String?>(null)
    var cityId by mutableStateOf<String?>(null)
    var onlyFree by mutableStateOf(false)
    var sort by mutableStateOf(SortMode.PROXIMIDADE)
    var showMap by mutableStateOf(true)
    var filtersExpanded by mutableStateOf(false)

    // ---- Onde buscar
    var origin by mutableStateOf<Origin?>(null)
    var locState by mutableStateOf(LocState.IDLE)
    /** O "Perto de mim" automático só é tentado uma vez por sessão da tela. */
    var autoLocateTried by mutableStateOf(false)
    var placeQuery by mutableStateOf("")
    var placeBusy by mutableStateOf(false)
    var placeMsg by mutableStateOf<String?>(null)
    var placeChoices by mutableStateOf<List<PlaceFinder.GeoHit>>(emptyList())
    var placeSuggestion by mutableStateOf<String?>(null)

    val query: LocatorQuery
        get() = LocatorQuery(
            text = text,
            productId = productId,
            categoryIds = categoryIds,
            channelIds = channelIds,
            scope = scope,
            uf = uf,
            cityId = cityId,
            onlyFree = onlyFree,
            sort = sort,
            originCity = if (scope == LocatorScope.CIDADE) origin?.city else null,
        )

    fun toggleCategory(id: String) {
        categoryIds = if (id in categoryIds) categoryIds - id else categoryIds + id
    }

    fun toggleChannel(id: String) {
        channelIds = if (id in channelIds) channelIds - id else channelIds + id
    }

    private fun clearPlaceFeedback() {
        placeChoices = emptyList()
        placeMsg = null
        placeSuggestion = null
    }

    /** Define o ponto de partida. Com município conhecido, filtra os canais de acesso por ele. */
    fun applyOrigin(o: Origin) {
        origin = o
        val c = o.city
        if (c != null) {
            scope = LocatorScope.CIDADE
            uf = c.uf.ifBlank { null }
            cityId = c.id
        } else {
            scope = LocatorScope.BRASIL
            uf = null
            cityId = null
        }
        clearPlaceFeedback()
    }

    fun selectBrazil() {
        origin = null
        scope = LocatorScope.BRASIL
        uf = null
        cityId = null
    }

    fun selectUf(code: String) {
        origin = null
        scope = LocatorScope.UF
        uf = code
        cityId = null
    }

    fun selectCity(id: String, ufCode: String) {
        val c = CityIndex.byId(id)
        if (c != null) {
            applyOrigin(Origin(c.lat, c.lon, c.label, OriginKind.MUNICIPIO, c))
        } else {
            origin = null
            scope = LocatorScope.CIDADE
            uf = ufCode
            cityId = id
        }
    }

    fun clearFilters() {
        text = ""
        productId = "all"
        categoryIds = emptySet()
        channelIds = emptySet()
        onlyFree = false
        sort = SortMode.PROXIMIDADE
        // "Limpar filtros" não tira a pessoa do lugar onde ela está buscando
        if (origin == null) selectBrazil()
    }

    val activeFilterCount: Int
        get() {
            var n = 0
            if (productId != "all") n++
            if (categoryIds.isNotEmpty()) n++
            if (channelIds.isNotEmpty()) n++
            if (onlyFree) n++
            if (origin == null && scope != LocatorScope.BRASIL) n++
            if (sort != SortMode.PROXIMIDADE) n++
            return n
        }
}
