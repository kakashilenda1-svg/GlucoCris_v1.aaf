package com.agon.app.cloud

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CuidadorComputeTest {
    private val th = CuidadorCompute.Th.from(CuidadorOnline.thresholds(70, 180, 54, 250))
    private val tz = -180
    private val min = 60_000L

    @Test fun classificaComoOServidor() {
        assertEquals("hypo_severe", CuidadorCompute.classify(54, th)!!.type)
        assertEquals("critical", CuidadorCompute.classify(40, th)!!.severity)
        assertEquals("hypo", CuidadorCompute.classify(65, th)!!.type)
        assertNull(CuidadorCompute.classify(70, th))
        assertNull(CuidadorCompute.classify(180, th))
        assertEquals("hyper", CuidadorCompute.classify(181, th)!!.type)
        assertEquals("attention", CuidadorCompute.classify(200, th)!!.severity)
        assertEquals("hyper_severe", CuidadorCompute.classify(250, th)!!.type)
        assertEquals("Hipoglicemia grave", CuidadorCompute.classify(50, th)!!.label)
    }

    @Test fun estadoDaFaixa() {
        assertEquals("low", CuidadorCompute.stateOf(69, th))
        assertEquals("range", CuidadorCompute.stateOf(70, th))
        assertEquals("range", CuidadorCompute.stateOf(180, th))
        assertEquals("high", CuidadorCompute.stateOf(181, th))
    }

    @Test fun alertaTemIdPorJanelaDe30Minutos() {
        val t = 1_800_000_000_000L
        assertEquals(CuidadorCompute.alertId("hypo", t), CuidadorCompute.alertId("hypo", t + 5 * min))
        assertTrue(CuidadorCompute.alertId("hypo", t) != CuidadorCompute.alertId("hypo", t + 31 * min))
        assertTrue(CuidadorCompute.alertId("hypo", t) != CuidadorCompute.alertId("hyper", t))
        assertTrue(Regex("^[a-z_]+_\\d{1,12}$").matches(CuidadorCompute.alertId("hypo_severe", t)))
    }

    private fun pt(i: Int, ms: Long, mg: Int, src: String = "cgm") = CuidadorCompute.Pt("p$i", ms, mg, src)

    @Test fun tendenciaPorSetasExigeTresPontosEmAte30Min() {
        val t = 1_800_000_000_000L
        assertEquals("↑↑", CuidadorCompute.trend(listOf(pt(1, t, 100), pt(2, t + 5 * min, 110), pt(3, t + 10 * min, 120))).arrow)
        assertEquals("→", CuidadorCompute.trend(listOf(pt(1, t, 100), pt(2, t + 5 * min, 101), pt(3, t + 10 * min, 102))).arrow)
        assertEquals("↓", CuidadorCompute.trend(listOf(pt(1, t, 120), pt(2, t + 10 * min, 115), pt(3, t + 20 * min, 95))).arrow)
        assertNull(CuidadorCompute.trend(listOf(pt(1, t, 100), pt(2, t + 5 * min, 110))).arrow)                       // 2 pontos
        assertNull(CuidadorCompute.trend(listOf(pt(1, t, 100), pt(2, t + 20 * min, 110), pt(3, t + 40 * min, 120))).arrow) // > 30 min
        assertNull(CuidadorCompute.trend(listOf(pt(1, t, 100, "manual"), pt(2, t + 5 * min, 110, "manual"), pt(3, t + 10 * min, 120, "manual"))).arrow)
    }

    @Test fun poucosDadosNaoGeramGmi() {
        val now = 1_800_000_000_000L
        val s = CuidadorCompute.stats(listOf(pt(1, now - 10 * min, 150), pt(2, now - 5 * min, 160)), th, 15, now, tz)
        assertEquals(2, s.n)
        assertFalse(s.reliable)
        assertNull(s.gmi)
        assertEquals("dados_insuficientes", s.reason)
        assertEquals(155, s.meanGlucose)
    }

    @Test fun catorzeDiasCompletosGeramGmiCorreto() {
        val now = 1_800_000_000_000L
        val list = ArrayList<CuidadorCompute.Pt>()
        var i = 0
        // 14 dias x 96 leituras de 15 min, todas em 154 mg/dL (média 154 => GMI = 3,31 + 0,02392 x 154 = 6,99 => 7,0)
        for (k in 0 until 14 * 96) list.add(pt(i++, now - k * 15 * min, 154))
        val s = CuidadorCompute.stats(list, th, 15, now, tz)
        assertTrue(s.reliable)
        assertEquals(7.0, s.gmi!!, 0.0001)
        assertEquals(154, s.meanGlucose)
        assertEquals(100.0, s.timeInRangePct!!, 0.0001)
        assertEquals(0.0, s.timeBelowPct!!, 0.0001)
        assertNotNull(s.hourly.firstOrNull())
        assertTrue(s.coveragePct >= 70.0)
    }

    @Test fun tempoNoAlvoEEpisodios() {
        val now = 1_800_000_000_000L
        val vals = listOf(100, 60, 60, 100, 200, 100) // 1 episódio de baixa, 1 de alta
        val list = vals.mapIndexed { idx, v -> pt(idx, now - (vals.size - idx) * 15 * min, v) }
        val s = CuidadorCompute.stats(list, th, 15, now, tz)
        assertEquals(1, s.lowEpisodes)
        assertEquals(1, s.highEpisodes)
        assertEquals(33.3, s.timeBelowPct!!, 0.05)
        assertEquals(16.7, s.timeAbovePct!!, 0.05)
        assertEquals(50.0, s.timeInRangePct!!, 0.05)
    }

    @Test fun leituraManualNaoEntraNaMediaDoSensor() {
        val now = 1_800_000_000_000L
        val s = CuidadorCompute.stats(listOf(pt(1, now - 5 * min, 100), pt(2, now - 4 * min, 300, "manual")), th, 15, now, tz)
        assertEquals(1, s.n)
        assertEquals(100, s.meanGlucose)
    }
}

class CuidadorPairingCodeTest {
    @Test fun hashConhecidoIgualAoDoAppCuidador() {
        // O app Cuidador usa o mesmo vetor de teste: os dois lados TÊM que produzir o mesmo id de documento.
        assertEquals("9ac2197d9258257b1ae8463e4214e4cd0a578bc1517f2415928b91be4283fc48", CuidadorOnline.codeHash("ABCDEFGH"))
        assertEquals(CuidadorOnline.codeHash("ABCDEFGH"), CuidadorOnline.codeHash("abcd-efgh"))
    }

    @Test fun codigoTem8CaracteresSemAmbiguos() {
        repeat(200) {
            val c = CuidadorOnline.newCode()
            assertEquals(8, c.length)
            assertTrue(c.none { it in "01OI" })
            assertEquals(c, CuidadorOnline.normalizeCode(c))
        }
    }
}
