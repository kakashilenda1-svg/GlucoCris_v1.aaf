package com.agon.app.cloud

import com.agon.app.data.InsulinEntry
import com.agon.app.data.Meal
import com.agon.app.data.Reminder
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CuidadorExtrasTest {
    private val now = 1_800_000_000_000L
    private val day = 86_400_000L

    private fun ins(id: String, at: Long, dose: Double = 4.0, upd: Long = 1L) =
        InsulinEntry(id = id, kind = "rapida", name = "Rápida", dose = dose, at = at, updatedAt = upd)

    @Test fun soEnviaOsUltimos14DiasEIgnoraDemo() {
        val items = CuidadorExtras.insulin(listOf(ins("a", now - 1 * day), ins("b", now - 20 * day), ins("demo-1", now - day)), now)
        assertEquals(listOf("a"), items.map { it.id })
        assertEquals(now - day, items.single().atMs)
        assertEquals(4.0, items.single().data["dose"])
    }

    @Test fun idDeDocumentoNuncaTemBarra() {
        assertEquals("a_b", CuidadorExtras.docId("a/b"))
        assertEquals(100, CuidadorExtras.docId("x".repeat(300)).length)
    }

    @Test fun planoGravaSoOQueMudouEApagaOQueSumiu() {
        val v1 = CuidadorExtras.insulin(listOf(ins("a", now - day), ins("b", now - day)), now)
        val sent = v1.associate { it.id to it.sig }
        // nada mudou
        assertTrue(CuidadorExtras.plan(sent, v1).write.isEmpty() && CuidadorExtras.plan(sent, v1).delete.isEmpty())
        // 'a' editada (dose), 'b' apagada, 'c' nova
        val v2 = CuidadorExtras.insulin(listOf(ins("a", now - day, dose = 6.0, upd = 2L), ins("c", now - day)), now)
        val p = CuidadorExtras.plan(sent, v2)
        assertEquals(setOf("a", "c"), p.write.map { it.id }.toSet())
        assertEquals(listOf("b"), p.delete)
    }

    @Test fun semPermissaoNadaSai_eRetiradaApagaTudo() {
        val perms = listOf(mapOf("insulin" to true, "meals" to false), mapOf("water" to true))
        assertEquals(setOf("insulin", "water"), CuidadorExtras.wanted(perms))
        assertEquals(emptySet<String>(), CuidadorExtras.wanted(emptyList()))
        val sent = mapOf("a" to "1", "b" to "2")
        val p = CuidadorExtras.plan(sent, emptyList())
        assertEquals(setOf("a", "b"), p.delete.toSet())
    }

    @Test fun refeicaoELembreteViramMapasSimples() {
        val m = CuidadorExtras.meals(listOf(Meal("m1", "almoço", "arroz e feijão", 45.0, now - 3_600_000L)), now).single()
        assertEquals(45.0, m.data["carbs"])
        val r = CuidadorExtras.reminders(listOf(Reminder("r1", "glicose", "Medir", 8, 30, listOf(1, 2, 3)))).single()
        assertEquals(8, r.data["hour"])
        assertEquals(null, r.atMs)
    }

    @Test fun aguaSemRegistroNaoEnvia() {
        assertTrue(CuidadorExtras.water("2026-11-25", 0L, 0, 2000, 0L, 0).isEmpty())
        val w = CuidadorExtras.water("2026-11-25", 1L, 750, 2000, 5L, 3).single()
        assertEquals("2026-11-25", w.id)
        assertEquals(750, w.data["ml"])
    }

    @Test fun codificacaoDasAssinaturasIdaEVolta() {
        val m = mapOf("a" to "1", "b" to "-2")
        assertEquals(m, CuidadorExtras.decode(CuidadorExtras.encode(m)))
        assertEquals(emptyMap<String, String>(), CuidadorExtras.decode(""))
    }
}
