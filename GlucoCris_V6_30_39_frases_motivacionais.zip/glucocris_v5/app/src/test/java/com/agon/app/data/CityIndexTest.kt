package com.agon.app.data

import com.agon.app.data.insulin.CityIndex
import org.junit.Assert.*
import org.junit.Test

class CityIndexTest {

    @Test fun exactMatch_ignoresAccentAndCase() {
        assertEquals("São Paulo", CityIndex.exactMatches("SAO PAULO").single().name)
    }

    @Test fun exactMatch_acceptsUfSuffix() {
        assertEquals("Campinas", CityIndex.exactMatches("Campinas, SP").single().name)
        assertEquals("Campinas", CityIndex.exactMatches("campinas sp").single().name)
        assertEquals("Campinas", CityIndex.exactMatches("Campinas/SP").single().name)
        assertTrue(CityIndex.exactMatches("Campinas - RJ").isEmpty())
    }

    @Test fun brasiliaMatchesDespiteSuffixInParentheses() {
        assertEquals("DF", CityIndex.exactMatches("brasilia").single().uf)
    }

    @Test fun search_startsWithComesFirst() {
        val r = CityIndex.search("sao", 5)
        assertTrue(r.isNotEmpty())
        assertTrue(r.first().name.startsWith("São"))
    }

    @Test fun suggest_fixesTypo() {
        assertEquals("Curitiba", CityIndex.suggest("curitba")?.name)
        assertNull(CityIndex.suggest("xyz"))
    }

    @Test fun parseLine_buildsStableIdWithoutAccents() {
        val c = CityIndex.parseLine("SP|Águas de Lindóia|-22.47|-46.63|I")!!
        assertEquals("sp-aguas-de-lindoia", c.id)
        assertEquals("SP", c.uf)
        assertNull(CityIndex.parseLine("lixo"))
        assertNull(CityIndex.parseLine("SP|Sem coordenada|x|y|I"))
    }

    @Test fun citiesOf_capitalFirst() {
        assertEquals("São Paulo", CityIndex.citiesOf("SP").first().name)
    }
}
