package com.agon.app.data

import java.util.TimeZone
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DailyQuotesTest {
    private val utc = TimeZone.getTimeZone("UTC")
    private val day = 86_400_000L

    @Test fun temExatamente50FrasesDiferentes() {
        assertEquals(50, DailyQuotes.QUOTES.size)
        assertEquals(50, DailyQuotes.QUOTES.toSet().size)
        assertTrue(DailyQuotes.QUOTES.all { it.isNotBlank() && it.length <= 90 })
    }

    @Test fun mesmaFraseNoDiaTodoETrocaNoDiaSeguinte() {
        val d0 = 20_000L * day
        assertEquals(DailyQuotes.today(d0 + 1_000, utc), DailyQuotes.today(d0 + day - 1_000, utc))
        assertNotEquals(DailyQuotes.today(d0, utc), DailyQuotes.today(d0 + day, utc))
    }

    @Test fun recomecaDepoisDe50Dias() {
        val d0 = 20_000L * day
        assertEquals(DailyQuotes.today(d0, utc), DailyQuotes.today(d0 + 50 * day, utc))
    }

    @Test fun trocaNaMeiaNoiteLocal() {
        val br = TimeZone.getTimeZone("America/Sao_Paulo") // UTC-3
        val d0 = 20_000L * day // 00:00 UTC = 21:00 do dia anterior em SP
        assertNotEquals(DailyQuotes.today(d0, br), DailyQuotes.today(d0 + 3 * 3_600_000L, br))
    }
}
