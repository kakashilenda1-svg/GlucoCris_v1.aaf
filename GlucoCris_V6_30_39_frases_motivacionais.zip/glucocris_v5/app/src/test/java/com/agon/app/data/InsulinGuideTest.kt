package com.agon.app.data

import com.agon.app.data.insulin.InsulinCatalog
import com.agon.app.data.insulin.InsulinGuide
import org.junit.Assert.*
import org.junit.Test

class InsulinGuideTest {
    private fun prods(vararg ids: String) = ids.map { InsulinCatalog.productById(it)!! }

    @Test fun nphAndRegular_goToUbsAndFarmaciaPopular() {
        val cards = InsulinGuide.build(prods("humulin_n", "humulin_r"))
        assertEquals(1, cards.size)
        assertEquals("UBS ou Farmácia Popular", cards[0].headline)
        assertTrue(cards[0].free)
    }

    @Test fun analogs_goToCeaf_andPrivateToPharmacies() {
        assertEquals("CEAF do seu estado", InsulinGuide.build(prods("lantus"))[0].headline)
        val priv = InsulinGuide.build(prods("tresiba"))[0]
        assertEquals("Rede de farmácias", priv.headline)
        assertFalse(priv.free)
    }

    @Test fun mixedResult_makesOneCardPerGroup_freeFirst() {
        val cards = InsulinGuide.build(prods("tresiba", "lantus", "humulin_n"))
        assertEquals(3, cards.size)
        assertFalse(cards.last().free)
    }

    @Test fun message_usesBrand() {
        assertEquals("Olá! Vocês têm Lantus?", InsulinGuide.message(prods("lantus", "lantus_solostar")))
        assertEquals("Olá! Vocês têm insulina?", InsulinGuide.message(emptyList()))
    }

    @Test fun whatsapp_onlyForMobileWithDdd() {
        val url = InsulinGuide.whatsappUrl("+55 (11) 99999-8888", "Olá! Vocês têm Lantus?")
        assertEquals("https://wa.me/5511999998888?text=Ol%C3%A1%21%20Voc%C3%AAs%20t%C3%AAm%20Lantus%3F", url)
        assertNull(InsulinGuide.whatsappUrl("(11) 3333-4444", "oi"))
        assertNull(InsulinGuide.whatsappUrl("99999-8888", "oi"))
        assertEquals("(11) 3333-4444", InsulinGuide.firstPhone("(11) 3333-4444; (11) 99999-8888"))
    }
}
