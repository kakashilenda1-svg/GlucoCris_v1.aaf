package com.agon.app.data

import com.agon.app.data.insulin.CityIndex
import com.agon.app.data.insulin.LocatorQuery
import com.agon.app.data.insulin.LocatorScope
import com.agon.app.data.insulin.SupplyNetwork
import org.junit.Assert.*
import org.junit.Test

class LocatorSearchTest {

    private fun ids(text: String): Set<String> =
        LocatorSearch.resolve(text).textProducts.orEmpty().map { it.id }.toSet()

    @Test fun norm_removesAccentsAndCase() {
        assertEquals("acao rapida", LocatorSearch.norm("Ação RÁPIDA"))
        assertEquals("glargina", LocatorSearch.norm("Glargína"))
    }

    @Test fun accent_andCase_doNotMatter() {
        assertEquals(ids("glargina"), ids("GLARGÍNA"))
        assertTrue("lantus" in ids("glargina"))
    }

    @Test fun brandName_narrowsToThatBrand_notToEveryGlargina() {
        val r = ids("Lantus")
        assertEquals(setOf("lantus", "lantus_solostar"), r)
        assertFalse("basaglar" in r)
    }

    @Test fun twoWordBrand_isRecognized() {
        assertEquals(setOf("humulin_n"), ids("humulin n"))
    }

    @Test fun nicknames_mapToGroups() {
        val cristalina = ids("insulina cristalina")
        assertTrue("humulin_r" in cristalina)
        assertFalse("nph_generica" in cristalina)
        assertTrue("novorapid" in ids("rápida"))
        assertTrue("lantus" in ids("basal"))
    }

    @Test fun prefix_fromFourLetters() {
        assertTrue("lantus" in ids("lant"))
    }

    @Test fun catalogBrandsOutsideTheAliasList_areFound() {
        assertTrue("admelog" in ids("admelog"))
        assertTrue("wosulin_n" in ids("wosulin"))
    }

    @Test fun slashInName_isSplit() {
        val r = ids("humulin 70/30")
        assertTrue("humulin_7030" in r)
        assertFalse("humulin_n" in r)
    }

    @Test fun fillerWords_doNotRestrictAnything() {
        assertNull(LocatorSearch.resolve("insulina perto de mim").textProducts)
        assertNull(LocatorSearch.resolve("").textProducts)
    }

    @Test fun farmaciaPopular_onlyPrioritizes() {
        val r = LocatorSearch.resolve("farmácia popular lantus")
        assertTrue(r.popular)
        assertTrue("lantus" in r.textProducts.orEmpty().map { it.id })
    }

    @Test fun typo_becomesSuggestion_neverApplied() {
        val r = LocatorSearch.resolve("lantuz")
        assertEquals(emptyList<String>(), r.textProducts.orEmpty().map { it.id })
        assertEquals("lantus", r.suggestion)
    }

    @Test fun cityInText_isHint_andDoesNotBlockInsulin() {
        val r = LocatorSearch.resolve("lantus curitiba")
        assertEquals("Curitiba", r.cityHint?.name)
        assertTrue(r.textProducts.orEmpty().isNotEmpty())
        assertTrue(r.unknown.isEmpty())
    }

    @Test fun onlyCity_doesNotRestrictInsulin() {
        val r = LocatorSearch.resolve("são paulo")
        assertNull(r.textProducts)
        assertEquals("SP", r.cityHint?.uf)
    }

    @Test fun cityTypo_isSuggested() {
        val r = LocatorSearch.resolve("nph curitba")
        assertEquals("nph Curitiba", r.suggestion)
    }

    @Test fun levenshtein_basics() {
        assertEquals(0, LocatorSearch.levenshtein("nph", "nph"))
        assertEquals(1, LocatorSearch.levenshtein("lantuz", "lantus"))
        assertEquals(3, LocatorSearch.levenshtein("", "abc"))
    }

    // ---- SupplyNetwork usando o texto

    @Test fun supplyNetwork_usesTextFilter() {
        val ok = SupplyNetwork.search(LocatorQuery(text = "Lantus"))
        assertTrue(ok.points.isNotEmpty())
        assertTrue(ok.matchedProducts.all { it.brandName.startsWith("Lantus") })

        val typo = SupplyNetwork.search(LocatorQuery(text = "lantuz"))
        assertTrue(typo.points.isEmpty())
    }

    @Test fun supplyNetwork_popularGoesFirst() {
        val r = SupplyNetwork.search(LocatorQuery(text = "farmacia popular nph"))
        assertEquals("farmacia_popular", r.points.first().channel.id)
    }

    @Test fun supplyNetwork_cityScope_usesOriginCityNotInTheList() {
        val geo = CityIndex.parseLine("SP|Cidade Fictícia|-22.0|-47.0|I")!!
        val r = SupplyNetwork.search(
            LocatorQuery(scope = LocatorScope.CIDADE, cityId = geo.id, uf = "SP", originCity = geo),
        )
        assertTrue(r.points.isNotEmpty())
        assertTrue(r.points.all { it.city.id == geo.id })
    }
}
