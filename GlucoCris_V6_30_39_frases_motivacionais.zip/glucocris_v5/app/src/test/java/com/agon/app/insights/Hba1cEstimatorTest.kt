package com.agon.app.insights

import com.agon.app.data.AppData
import com.agon.app.data.GlucoseEntry
import com.agon.app.data.Hba1cEntry
import org.junit.Assert.*
import org.junit.Test
import java.util.Calendar

class Hba1cEstimatorTest {
    private val DAY = Insights.DAY_MS
    private val now = Calendar.getInstance().apply { set(2026, Calendar.NOVEMBER, 16, 15, 0, 0) }.timeInMillis

    /** Uma medição por dia, [mg] constante, dos últimos [days] dias (começando em [startDaysAgo]). */
    private fun daily(days: Int, mg: Double, startDaysAgo: Int = 0, perDay: Int = 1): List<GlucoseEntry> =
        (0 until days).flatMap { d ->
            (0 until perDay).map { k ->
                val at = now - (startDaysAgo + d) * DAY - k * 3_600_000L - 1_000L
                GlucoseEntry("m-$d-$k", mg, "mg/dL", at, "jejum", "", now, now)
            }
        }

    @Test fun formulas() {
        assertEquals(3.31 + 0.02392 * 154.0, Hba1cEstimator.gmiOf(154.0), 1e-9)
        assertEquals((154.0 + 46.7) / 28.7, Hba1cEstimator.ea1cOf(154.0), 1e-9)
        assertEquals(6.99, Hba1cEstimator.gmiOf(154.0), 0.01)
    }

    @Test fun noData_returnsNull() {
        assertNull(Hba1cEstimator.compute(AppData(), now))
    }

    @Test fun tooFewReadings_returnsNull() {
        assertNull(Hba1cEstimator.compute(AppData(glucose = daily(3, 150.0)), now))
    }

    @Test fun demoReadings_areIgnored() {
        val demo = daily(30, 300.0).map { it.copy(id = "demo-" + it.id) }
        assertNull(Hba1cEstimator.compute(AppData(glucose = demo), now))
    }

    @Test fun basicEstimate_lowConfidenceWithFewData() {
        val e = Hba1cEstimator.compute(AppData(glucose = daily(20, 154.0)), now)!!
        assertEquals(6.994, e.gmi, 0.001)
        assertEquals(6.993, e.ea1c, 0.001)
        assertNull(e.adjusted)
        assertNull(e.personalOffset)
        assertEquals(0, e.examsUsed)
        assertEquals(EstimateConfidence.LOW, e.confidence)
        assertEquals(e.gmi, e.headline, 1e-9)
        assertTrue(e.rangeLow < e.gmi && e.rangeHigh > e.gmi)
        assertEquals(DataOrigin.METER, e.origin)
    }

    @Test fun confidence_growsWithData() {
        assertEquals(EstimateConfidence.MEDIUM, Hba1cEstimator.compute(AppData(glucose = daily(40, 154.0)), now)!!.confidence)
        assertEquals(EstimateConfidence.HIGH, Hba1cEstimator.compute(AppData(glucose = daily(70, 154.0, perDay = 2)), now)!!.confidence)
    }

    @Test fun confidence_rules() {
        assertEquals(EstimateConfidence.HIGH, Hba1cEstimator.confidenceOf(DataOrigin.CGM, 85.0, 4000, 14))
        // CGM com cobertura baixa não vira confiança alta; cai para média pelo volume de leituras.
        assertEquals(EstimateConfidence.MEDIUM, Hba1cEstimator.confidenceOf(DataOrigin.CGM, 40.0, 100, 14))
        assertEquals(EstimateConfidence.LOW, Hba1cEstimator.confidenceOf(DataOrigin.METER, null, 20, 10))
        assertEquals(EstimateConfidence.MEDIUM, Hba1cEstimator.confidenceOf(DataOrigin.METER, null, 60, 20))
    }

    @Test fun personalAdjustment_usesMedianOfExamGaps() {
        // Glicose constante em 154 mg/dL por 180 dias (GMI ≈ 6,994 em qualquer janela). Exames: 7,5 e 7,7.
        val labs = listOf(
            Hba1cEntry("a", 7.5, now - 100 * DAY, "", "", now, now),
            Hba1cEntry("b", 7.7, now - 10 * DAY, "", "", now, now),
        )
        val e = Hba1cEstimator.compute(AppData(glucose = daily(180, 154.0), hba1c = labs), now)!!
        assertEquals(2, e.examsUsed)
        assertEquals(0.606, e.personalOffset!!, 0.001)
        assertEquals(7.6, e.adjusted!!, 0.001)
        assertEquals(e.adjusted!!, e.headline, 1e-9)
        assertEquals(8.2, e.rangeHigh, 0.001) // 7,6 + margem 0,6 (confiança média)
        assertTrue(e.rangeLow <= e.ea1c + 1e-9)
        // O ajuste não mexe na série laboratorial.
        assertEquals(listOf(7.5, 7.7), labs.map { it.percent })
    }

    @Test fun oneExam_isNotEnoughForAdjustment() {
        val labs = listOf(Hba1cEntry("a", 8.0, now - 10 * DAY, "", "", now, now))
        val e = Hba1cEstimator.compute(AppData(glucose = daily(120, 154.0), hba1c = labs), now)!!
        assertNull(e.adjusted)
        assertEquals(0, e.examsUsed)
    }

    @Test fun examsWithoutGlucoseAroundThem_areSkipped() {
        // Exames de 2 anos atrás: não há glicose registrada na época, então não servem para ajustar.
        val labs = listOf(
            Hba1cEntry("a", 9.0, now - 700 * DAY, "", "", now, now),
            Hba1cEntry("b", 9.2, now - 600 * DAY, "", "", now, now),
        )
        val e = Hba1cEstimator.compute(AppData(glucose = daily(60, 154.0), hba1c = labs), now)!!
        assertNull(e.adjusted)
    }

    @Test fun adjustment_isCapped() {
        val labs = listOf(
            Hba1cEntry("a", 12.0, now - 100 * DAY, "", "", now, now),
            Hba1cEntry("b", 12.0, now - 10 * DAY, "", "", now, now),
        )
        val e = Hba1cEstimator.compute(AppData(glucose = daily(180, 154.0), hba1c = labs), now)!!
        assertEquals(Hba1cEstimator.MAX_ABS_OFFSET, e.personalOffset!!, 1e-9)
    }

    @Test fun signedText() {
        assertEquals("+0,6", Hba1cEstimator.signed(0.6))
        assertEquals("−0,4", Hba1cEstimator.signed(-0.4))
    }
}
