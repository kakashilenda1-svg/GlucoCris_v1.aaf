package com.agon.app.insights

import org.junit.Assert.*
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

class ReportStatsTest {
    private val utc: TimeZone = TimeZone.getTimeZone("UTC")
    private fun at(day: Int, hour: Int): Long =
        Calendar.getInstance(utc).apply { clear(); set(2026, Calendar.NOVEMBER, day, hour, 15, 0) }.timeInMillis

    @Test fun percentile_interpolates() {
        val v = listOf(1.0, 2.0, 3.0, 4.0, 5.0)
        assertEquals(1.4, ReportStats.percentile(v, 10.0), 1e-9)
        assertEquals(2.0, ReportStats.percentile(v, 25.0), 1e-9)
        assertEquals(3.0, ReportStats.percentile(v, 50.0), 1e-9)
        assertEquals(2.5, ReportStats.percentile(listOf(1.0, 2.0, 3.0, 4.0), 50.0), 1e-9)
        assertEquals(7.0, ReportStats.percentile(listOf(7.0), 90.0), 1e-9)
    }

    @Test fun hourly_needsMinimumReadingsPerHour() {
        val list = listOf(
            Reading(at(1, 8), 100.0, false), Reading(at(2, 8), 120.0, false), Reading(at(3, 8), 140.0, false),
            Reading(at(1, 9), 200.0, false), Reading(at(2, 9), 210.0, false),
        )
        val h = ReportStats.hourly(list, minPerHour = 3, tz = utc)
        assertEquals(1, h.size)
        assertEquals(8, h[0].hour)
        assertEquals(3, h[0].count)
        assertEquals(120.0, h[0].p50, 1e-9)
        assertEquals(110.0, h[0].p25, 1e-9)
        assertEquals(130.0, h[0].p75, 1e-9)
    }

    @Test fun daysWith_countsDistinctDays() {
        val list = listOf(
            Reading(at(1, 8), 60.0, false), Reading(at(1, 20), 55.0, false),
            Reading(at(2, 8), 100.0, false), Reading(at(3, 8), 65.0, false),
        )
        assertEquals(2, ReportStats.daysWith(list, utc) { it < 70.0 })
        assertEquals(1, ReportStats.daysWith(list, utc) { it < 56.0 })
        assertEquals(3, ReportStats.distinctDays(list, utc))
    }

    @Test fun dailyMeans_groupAndSort() {
        val list = listOf(
            Reading(at(3, 8), 150.0, false), Reading(at(1, 8), 100.0, false), Reading(at(1, 20), 140.0, false),
        )
        val m = ReportStats.dailyMeans(list, utc)
        assertEquals(2, m.size)
        assertEquals(120.0, m[0].second, 1e-9)
        assertEquals(150.0, m[1].second, 1e-9)
        assertTrue(m[0].first < m[1].first)
    }

    @Test fun sourceMix_byIdPrefix() {
        val mix = ReportStats.sourceMix(listOf("ble-aa-1-2", "ble-aa-2-3", "sensor-libre-9", "abc", "xyz", "q"))
        assertEquals(2, mix.bluetooth)
        assertEquals(1, mix.sensor)
        assertEquals(3, mix.manual)
        assertEquals(6, mix.total)
    }
}
