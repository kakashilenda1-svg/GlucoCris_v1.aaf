package com.agon.app.localai

import org.junit.Assert.assertEquals
import org.junit.Test

class CrisSlangTest {
    @Test fun expandeAbreviacoesComuns() {
        assertEquals("quando você vai agora", CrisTypo.expandSlang("qnd vc vai agr"))
        assertEquals("O que é hoje", CrisTypo.expandSlang("oq é hj").replaceFirst("o que", "O que"))
        assertEquals("estou com muito calor também", CrisTypo.expandSlang("tô com mt calor tbm"))
    }

    @Test fun reduzLetrasEsticadasEPreservaPalavrasNormais() {
        assertEquals("agora", CrisTypo.expandSlang("agoraaaa"))
        assertEquals("Quantos graus em São Paulo", CrisTypo.expandSlang("Quantos graus em São Paulo"))
    }

    @Test fun fixAplicaAbreviacoesAntesDaClassificacao() {
        assertEquals(SearchIntent.CURRENT, CrisSearchPolicy.classify(CrisTypo.fix("quantos graus tá fazendo em Recife agr")))
    }
}

class CrisTypoFixTest {
    @Test fun corrigeErrosDeDigitacao() {
        assertEquals("amanhã", CrisTypo.fix("amanja"))
        assertEquals("abacate", CrisTypo.fix("abacjate"))
        assertEquals("glicemia", CrisTypo.fix("glicmeia"))
        assertEquals("o abacate tem carboidrato", CrisTypo.fix("o abacjate tem carboidrato"))
    }

    @Test fun naoMexeEmPalavrasCertasNemEmNomes() {
        assertEquals("banana", CrisTypo.fix("banana"))
        assertEquals("fale com Amanda hoje", CrisTypo.fix("fale com Amanda hoje"))
    }
}
