package com.agon.app.localai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CrisWeatherTest {
    @Test fun perguntaDeGrausEClassificadaComoAtual() {
        assertEquals(SearchIntent.CURRENT, CrisSearchPolicy.classify("Quantos graus tá fazendo na cidade de São Paulo agora"))
        assertEquals(SearchIntent.CURRENT, CrisSearchPolicy.classify("vai chover em Campinas?"))
        assertEquals(SearchIntent.CURRENT, CrisSearchPolicy.classify("qual a temperatura em Curitiba"))
    }

    @Test fun temperaturaCorporalNaoViraPesquisaDeClima() {
        assertEquals(false, CrisSearchPolicy.isWeather("minha temperatura está 37 e meu filho tem febre"))
    }

    @Test fun extraiACidade() {
        assertEquals("São Paulo", CrisWebSearch.cityOf("Quantos graus tá fazendo na cidade de São Paulo agora"))
        assertEquals("Belo Horizonte", CrisWebSearch.cityOf("qual a temperatura em Belo Horizonte hoje?"))
        assertEquals("Recife", CrisWebSearch.cityOf("tá chovendo em Recife agora?"))
        assertNull(CrisWebSearch.cityOf("quantos graus agora"))
    }
}

class CrisAnswerPickTest {
    private fun hit(snip: String) = WebHit("t", snip, "https://x.com/a", "Site", "", false, 1)

    @Test fun trechoDeChuvaNaoRespondePerguntaDeGraus() {
        val h = hit("Até o dia 21, já choveu 167 mm em São Paulo em novembro, o que representa 106% da média normal para o mês.")
        assertNull(CrisWebSearch.bestAnswerSentence("Quantos graus tá fazendo na cidade de São Paulo agora", listOf(h)))
    }

    @Test fun trechoComTemperaturaResponde() {
        val h = hit("Em São Paulo a cidade registra 24 graus agora, com céu nublado.")
        assertEquals("Site", CrisWebSearch.bestAnswerSentence("Quantos graus tá fazendo na cidade de São Paulo agora", listOf(h))?.first?.source)
    }
}
