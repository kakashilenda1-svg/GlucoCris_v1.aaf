package com.agon.app.sensors

import org.junit.Assert.*
import org.junit.Test
import java.util.Calendar
import java.util.TimeZone

class BleGlucoseParserTest {
    private val utc: TimeZone = TimeZone.getTimeZone("UTC")

    private fun base(y: Int = 2026, mo: Int = 11, d: Int = 16, h: Int = 10, mi: Int = 30, s: Int = 0): Long =
        Calendar.getInstance(utc).apply { clear(); set(y, mo - 1, d, h, mi, s) }.timeInMillis

    /** Monta um pacote 0x2A18; as flags são informadas por quem chama, de acordo com os campos presentes. */
    private fun packet(
        flags: Int, seq: Int, year: Int = 2026, month: Int = 11, day: Int = 16, hour: Int = 10, minute: Int = 30, second: Int = 0,
        offset: Int? = null, sfloat: Int? = 0xB069, status: Int? = null,
    ): ByteArray {
        val out = ArrayList<Byte>()
        fun u8(v: Int) { out.add(v.toByte()) }
        fun u16(v: Int) { u8(v and 0xFF); u8((v shr 8) and 0xFF) }
        u8(flags); u16(seq); u16(year); u8(month); u8(day); u8(hour); u8(minute); u8(second)
        if (offset != null) u16(offset and 0xFFFF)
        if (sfloat != null) { u16(sfloat); u8(0x11) }
        if (status != null) u16(status)
        return out.toByteArray()
    }

    @Test fun sfloat_decodesValuesAndSpecials() {
        assertEquals(0.00105, BleGlucoseParser.sfloat(0xB069)!!, 1e-9)
        assertEquals(22.5, BleGlucoseParser.sfloat(0xF0E1)!!, 1e-9)
        assertEquals(-1.0, BleGlucoseParser.sfloat(0x0FFF)!!, 1e-9)
        assertNull(BleGlucoseParser.sfloat(0x07FF)) // NaN
        assertNull(BleGlucoseParser.sfloat(0x0800)) // sem resultado
        assertNull(BleGlucoseParser.sfloat(0x07FE)) // +infinito
        assertNull(BleGlucoseParser.sfloat(0x0802)) // -infinito
    }

    @Test fun kgPerLiter_convertsToMgDl() {
        val r = BleGlucoseParser.parse(packet(flags = 0x02, seq = 5), utc)!!
        assertEquals(105.0, r.mg, 0.01)
        assertEquals(5, r.seq)
        assertEquals(base(), r.at)
        assertFalse(r.deviceFault)
        assertFalse(r.timeFault)
    }

    @Test fun molPerLiter_convertsToMgDl() {
        // 5,8 mmol/L = 0,0058 mol/L ≈ 104,5 mg/dL
        val r = BleGlucoseParser.parse(packet(flags = 0x06, seq = 1, sfloat = 0xC03A), utc)!!
        assertEquals(104.49, r.mg, 0.05)
    }

    @Test fun timeOffset_isAppliedInMinutes() {
        val r = BleGlucoseParser.parse(packet(flags = 0x03, seq = 2, offset = -180), utc)!!
        assertEquals(base() - 180 * 60_000L, r.at)
        val r2 = BleGlucoseParser.parse(packet(flags = 0x03, seq = 3, offset = 90), utc)!!
        assertEquals(base() + 90 * 60_000L, r2.at)
    }

    @Test fun status_flagsDeviceAndTimeFaults() {
        val strip = BleGlucoseParser.parse(packet(flags = 0x0A, seq = 1, status = 0x0004), utc)!!
        assertTrue(strip.deviceFault)
        val clock = BleGlucoseParser.parse(packet(flags = 0x0A, seq = 2, status = 0x0800), utc)!!
        assertTrue(clock.timeFault)
        assertFalse(clock.deviceFault)
        val battery = BleGlucoseParser.parse(packet(flags = 0x0A, seq = 3, status = 0x0001), utc)!!
        assertFalse(battery.deviceFault)
        assertFalse(battery.timeFault)
    }

    @Test fun invalidPackets_areRejected() {
        assertNull(BleGlucoseParser.parse(byteArrayOf(0x02, 0x01, 0x00), utc))                 // curto demais
        assertNull(BleGlucoseParser.parse(packet(flags = 0x00, seq = 1, sfloat = null), utc))  // sem concentração
        assertNull(BleGlucoseParser.parse(packet(flags = 0x02, seq = 1, sfloat = 0x07FF), utc)) // NaN
        assertNull(BleGlucoseParser.parse(packet(flags = 0x02, seq = 1, sfloat = 0xB005), utc)) // 5 mg/dL: implausível
        assertNull(BleGlucoseParser.parse(packet(flags = 0x02, seq = 1, month = 13), utc))     // data inválida
        assertNull(BleGlucoseParser.parse(packet(flags = 0x03, seq = 1, offset = null).copyOf(10), utc)) // falta o deslocamento
    }

    @Test fun racp_responses() {
        val ok = BleRacp.parseResponse(byteArrayOf(6, 0, 1, 1))!!
        assertTrue(ok.success)
        assertEquals(BleRacp.OP_REPORT_STORED, ok.requestOp)
        assertTrue(BleRacp.parseResponse(byteArrayOf(6, 0, 1, 6))!!.noRecords)
        assertFalse(BleRacp.parseResponse(byteArrayOf(6, 0, 1, 7))!!.success)
        assertNull(BleRacp.parseResponse(byteArrayOf(5, 0, 1, 0)))
        assertNull(BleRacp.parseResponse(byteArrayOf(6, 0)))
        assertArrayEquals(byteArrayOf(1, 1), BleRacp.REPORT_ALL)
    }

    @Test fun mapper_dedupesFiltersFaultsFutureAndDeleted() {
        val now = base()
        val ok = BleGlucoseReading(1, now - 3_600_000L, 100.0)
        val dup = BleGlucoseReading(1, now - 3_600_000L, 100.0)
        val fault = BleGlucoseReading(2, now - 7_200_000L, 90.0, deviceFault = true)
        val clock = BleGlucoseReading(3, now - 7_200_000L, 91.0, timeFault = true)
        val future = BleGlucoseReading(4, now + 3_600_000L, 110.0)
        val deletedOne = BleGlucoseReading(5, now - 9_000_000L, 120.0)
        val known = BleGlucoseReading(6, now - 10_000_000L, 130.0)
        val addr = "AA:BB:CC:DD:EE:FF"
        val res = BleEntryMapper.fresh(
            addr, listOf(ok, dup, fault, clock, future, deletedOne, known),
            known = setOf(BleEntryMapper.id(addr, known)),
            deleted = setOf(BleEntryMapper.id(addr, deletedOne)),
            now = now,
        )
        assertEquals(1, res.size)
        assertEquals(1, res[0].second.seq)
        assertTrue(res[0].first.startsWith("ble-aabbccddeeff-1-"))
        // Leituras do glicosímetro NÃO são CGM: o id não pode começar com "sensor-".
        assertFalse(com.agon.app.insights.GmiQuality.isCgmEntry(res[0].first))
    }
}
