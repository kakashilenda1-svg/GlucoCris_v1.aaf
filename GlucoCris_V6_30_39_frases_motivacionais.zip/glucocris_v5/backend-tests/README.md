# Teste das regras do Firestore

Roda no seu computador (emulador local, sem custo e sem tocar no projeto real):

    cd backend-tests
    npm install
    npm test

Precisa de Node 20+ e Java 11+. Se algum teste falhar, NÃO publique as regras.
