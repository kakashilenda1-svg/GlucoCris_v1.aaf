// Testes das regras: 2 pacientes (p1,p2) e 3 cuidadores (c1,c2,c3) com permissões diferentes.
// Executar: veja backend-tests/README (npm install && npm test)
const fs = require("fs");
const { initializeTestEnvironment, assertFails, assertSucceeds } = require("@firebase/rules-unit-testing");
const { doc, getDoc, getDocs, collection, query, where, writeBatch, setDoc, updateDoc, deleteDoc, serverTimestamp, Timestamp } = require("firebase/firestore");
let env;
const P = (o) => Object.assign({ currentGlucose:false,history:false,charts:false,cgm:false,trends:false,gmi:false,cgmCoverage:false,
  hba1cCurrent:false,hba1cHistory:false,reports:false,alerts:false,diary:false,carePlan:false,emergencyContacts:false,extraInfo:false }, o);

before(async () => {
  env = await initializeTestEnvironment({ projectId: "glucocris-test", firestore: { rules: fs.readFileSync(__dirname + "/../firestore.rules", "utf8"), host: "127.0.0.1", port: 8080 } });
});
after(() => env.cleanup());
beforeEach(async () => {
  await env.clearFirestore();
  await env.withSecurityRulesDisabled(async (ctx) => {
    const f = ctx.firestore();
    for (const p of ["p1", "p2"]) {
      await setDoc(doc(f, `patients/${p}`), { displayName: p });
      await setDoc(doc(f, `patients/${p}/current/latest`), { value: 100 });
      await setDoc(doc(f, `patients/${p}/current/trend`), { arrow: "→" });
      await setDoc(doc(f, `patients/${p}/readings/r1`), { value: 100 });
      await setDoc(doc(f, `patients/${p}/hba1c/h1`), { value: 7 });
      await setDoc(doc(f, `patients/${p}/hba1cLatest/main`), { value: 7 });
      await setDoc(doc(f, `patients/${p}/stats/gmi`), { gmi: 7 });
      await setDoc(doc(f, `patients/${p}/alerts/a1`), { type: "hypo" });
      await setDoc(doc(f, `patients/${p}/carePlan/main`), { t: "x" });
    }
    const L = (p, c, perms, status = "active") => setDoc(doc(f, `patients/${p}/links/${c}`), { status, permissions: P(perms) });
    await L("p1", "c1", { currentGlucose: true, cgm: true, gmi: true, alerts: true });
    await L("p1", "c2", { currentGlucose: true, history: true, hba1cCurrent: true, hba1cHistory: true });
    await L("p1", "c3", { currentGlucose: true, alerts: true });
    await L("p2", "c1", { currentGlucose: true, history: true }); // c1 acompanha 2 pacientes com perms diferentes
  });
});
const as = (u) => env.authenticatedContext(u).firestore();
const g = (u, path) => getDoc(doc(as(u), path));

describe("multicuidador / permissões", () => {
  it("c1 lê glicemia atual e GMI de p1, mas não histórico nem HbA1c", async () => {
    await assertSucceeds(g("c1", "patients/p1/current/latest"));
    await assertSucceeds(g("c1", "patients/p1/stats/gmi"));
    await assertFails(g("c1", "patients/p1/readings/r1"));
    await assertFails(g("c1", "patients/p1/hba1cLatest/main"));
  });
  it("c2 lê histórico e HbA1c, mas não alertas nem GMI", async () => {
    await assertSucceeds(g("c2", "patients/p1/readings/r1"));
    await assertSucceeds(g("c2", "patients/p1/hba1c/h1"));
    await assertFails(g("c2", "patients/p1/alerts/a1"));
    await assertFails(g("c2", "patients/p1/stats/gmi"));
  });
  it("c3 só vê glicemia atual e alertas (sem tendência)", async () => {
    await assertSucceeds(g("c3", "patients/p1/current/latest"));
    await assertSucceeds(g("c3", "patients/p1/alerts/a1"));
    await assertFails(g("c3", "patients/p1/current/trend"));
    await assertFails(g("c3", "patients/p1/readings/r1"));
  });
  it("uma conta acompanha vários pacientes sem misturar permissões", async () => {
    await assertSucceeds(g("c1", "patients/p2/readings/r1"));   // permitido em p2
    await assertFails(g("c1", "patients/p1/readings/r1"));      // negado em p1
    await assertFails(g("c1", "patients/p2/alerts/a1"));        // negado em p2
  });
  it("cuidador sem vínculo não acessa nada; paciente não acessa outro paciente", async () => {
    await assertFails(g("c3", "patients/p2/current/latest"));
    await assertFails(g("p2", "patients/p1/current/latest"));
    await assertFails(g("outsider", "patients/p1"));
  });
  it("dono lê tudo dele", async () => { await assertSucceeds(g("p1", "patients/p1/readings/r1")); await assertSucceeds(g("p1", "patients/p1/hba1c/h1")); });
});

describe("revogação e alteração de permissões", () => {
  it("revogar impede novas consultas", async () => {
    await assertSucceeds(g("c1", "patients/p1/current/latest"));
    await env.withSecurityRulesDisabled((c) => updateDoc(doc(c.firestore(), "patients/p1/links/c1"), { status: "revoked" }));
    await assertFails(g("c1", "patients/p1/current/latest"));
    await assertFails(g("c1", "patients/p1"));
  });
  it("alterar permissões muda o acesso imediatamente", async () => {
    await assertFails(g("c3", "patients/p1/readings/r1"));
    await env.withSecurityRulesDisabled((c) => updateDoc(doc(c.firestore(), "patients/p1/links/c3"), { "permissions.history": true }));
    await assertSucceeds(g("c3", "patients/p1/readings/r1"));
  });
  it("cuidador não consegue se auto-conceder permissões nem criar vínculos", async () => {
    await assertFails(updateDoc(doc(as("c3"), "patients/p1/links/c3"), { "permissions.history": true }));
    await assertFails(setDoc(doc(as("evil"), "patients/p1/links/evil"), { status: "active", permissions: P({ history: true }) }));
  });
});

describe("escrita", () => {
  const rd = (o = {}) => ({ value: 120, unit: "mg/dL", source: "cgm", originTs: Timestamp.now(), serverTs: serverTimestamp(), ...o });
  it("paciente cria medição válida; valor absurdo e cuidador são negados", async () => {
    await assertSucceeds(setDoc(doc(as("p1"), "patients/p1/readings/new1"), rd()));
    await assertFails(setDoc(doc(as("p1"), "patients/p1/readings/bad"), rd({ value: 5 })));
    await assertFails(setDoc(doc(as("c1"), "patients/p1/readings/x"), rd()));
    await assertFails(setDoc(doc(as("p2"), "patients/p1/readings/x"), rd()));
  });
  it("medição não pode ser alterada; só o dono pode apagar (LGPD)", async () => {
    await assertFails(updateDoc(doc(as("p1"), "patients/p1/readings/r1"), { value: 300 }));
    await assertFails(deleteDoc(doc(as("c1"), "patients/p1/readings/r1")));
    await assertSucceeds(deleteDoc(doc(as("p1"), "patients/p1/readings/r1")));
  });
  it("ack de alerta: só com permissão alerts e no próprio uid", async () => {
    const ack = (uid) => ({ uid, status: "following", ts: serverTimestamp() });
    await assertSucceeds(setDoc(doc(as("c3"), "patients/p1/alerts/a1/acks/c3"), ack("c3")));
    await assertFails(setDoc(doc(as("c3"), "patients/p1/alerts/a1/acks/c1"), ack("c1")));
    await assertFails(setDoc(doc(as("c2"), "patients/p1/alerts/a1/acks/c2"), ack("c2")));
  });
  it("diário é imutável e identifica o autor", async () => {
    await env.withSecurityRulesDisabled((c) => updateDoc(doc(c.firestore(), "patients/p1/links/c3"), { "permissions.diary": true }));
    const d = (a) => ({ authorUid: a, text: "tontura", ts: serverTimestamp() });
    await assertSucceeds(setDoc(doc(as("c3"), "patients/p1/diary/d1"), d("c3")));
    await assertFails(setDoc(doc(as("c3"), "patients/p1/diary/d2"), d("c1")));
    await assertFails(updateDoc(doc(as("c3"), "patients/p1/diary/d1"), { text: "outro" }));
  });
  it("cuidador não altera plano de ação nem limites do paciente", async () => {
    await assertFails(setDoc(doc(as("c1"), "patients/p1/carePlan/main"), { t: "y" }));
    await assertFails(updateDoc(doc(as("c1"), "patients/p1"), { thresholds: { low: 10 } }));
  });
  it("auditoria: só o dono lê e cria; ninguém altera", async () => {
    await assertFails(g("c1", "patients/p1/audit/x"));
    await assertSucceeds(setDoc(doc(as("p1"), "patients/p1/audit/a1"), { type: "access_granted", by: "p1", ts: serverTimestamp() }));
    await assertFails(updateDoc(doc(as("p1"), "patients/p1/audit/a1"), { type: "x" }));
    await assertFails(setDoc(doc(as("c1"), "patients/p1/audit/a2"), { type: "x", by: "c1", ts: serverTimestamp() }));
  });
});

describe("conexão paciente ↔ cuidador (v1.0.1)", () => {
  it("\"Estou bem\": paciente cria; só quem tem glicemia atual lê; ninguém altera", async () => {
    await assertSucceeds(setDoc(doc(as("p1"), "patients/p1/okConfirmations/o1"), { ts: serverTimestamp() }));
    await env.withSecurityRulesDisabled((c) => setDoc(doc(c.firestore(), "patients/p1/okConfirmations/o2"), { ts: Timestamp.now() }));
    await assertSucceeds(g("c1", "patients/p1/okConfirmations/o2"));
    await assertFails(setDoc(doc(as("c1"), "patients/p1/okConfirmations/o3"), { ts: serverTimestamp() }));
    await assertFails(updateDoc(doc(as("p1"), "patients/p1/okConfirmations/o2"), { ts: Timestamp.now() }));
  });
  it("telefone do paciente (contact/main): dono grava; cuidador só lê com contatos de emergência", async () => {
    await assertSucceeds(setDoc(doc(as("p1"), "patients/p1/contact/main"), { phone: "+5511999998888" }));
    await assertFails(g("c1", "patients/p1/contact/main"));
    await env.withSecurityRulesDisabled((c) => updateDoc(doc(c.firestore(), "patients/p1/links/c1"), { "permissions.emergencyContacts": true }));
    await assertSucceeds(g("c1", "patients/p1/contact/main"));
    await assertFails(setDoc(doc(as("c1"), "patients/p1/contact/main"), { phone: "+55000" }));
  });
  it("pedido de contato: cuidador com alertas cria; só o paciente lê", async () => {
    const req = (u) => ({ fromUid: u, fromName: "x", message: "oi", ts: serverTimestamp() });
    await assertSucceeds(setDoc(doc(as("c1"), "patients/p1/contactRequests/q1"), req("c1")));
    await assertFails(setDoc(doc(as("c2"), "patients/p1/contactRequests/q2"), req("c2"))); // c2 não tem alertas
    await assertFails(setDoc(doc(as("c1"), "patients/p1/contactRequests/q3"), req("c3"))); // fromUid de outra pessoa
    await assertSucceeds(g("p1", "patients/p1/contactRequests/q1"));
    await assertFails(g("c1", "patients/p1/contactRequests/q1"));
  });
  it("paciente grava staleAfterMin em patients/{pid}; cuidador não", async () => {
    await assertSucceeds(updateDoc(doc(as("p1"), "patients/p1"), { staleAfterMin: 40 }));
    await assertFails(updateDoc(doc(as("c1"), "patients/p1"), { staleAfterMin: 1 }));
  });
  it("token de push do próprio usuário (users/{uid}/devices)", async () => {
    await assertSucceeds(setDoc(doc(as("p1"), "users/p1/devices/tok"), { platform: "android" }));
    await assertFails(setDoc(doc(as("c1"), "users/p1/devices/tok2"), { platform: "android" }));
  });
});

// ───────────────────────── v6.30.37: pareamento e cálculos SEM Cloud Functions ─────────────────────────
const H1 = "a".repeat(64), H2 = "b".repeat(64);
const asEmail = (u, email) => env.authenticatedContext(u, { email }).firestore();
const inMin = (m) => Timestamp.fromMillis(Date.now() + m * 60000);
const codeDoc = (pid, exp = inMin(10)) => ({ pid, patientName: "Paciente", createdAt: serverTimestamp(), expiresAt: exp });
const seedCode = (h, pid, exp = inMin(10)) => env.withSecurityRulesDisabled((c) => setDoc(doc(c.firestore(), `pairingCodes/${h}`), { pid, patientName: "P", createdAt: Timestamp.now(), expiresAt: exp }));
const pairBatch = (db, cuid, pid, h, over = {}) => {
  const b = writeBatch(db);
  b.set(doc(db, `patients/${pid}/requests/${cuid}`), { uid: cuid, name: "Ana", email: `${cuid}@x.com`, status: "pending", relation: "mãe", createdAt: serverTimestamp(), codeHash: h, ...over });
  b.set(doc(db, `users/${cuid}/patients/${pid}`), { patientId: pid, patientName: "P", status: "pending", permissions: {}, updatedAt: serverTimestamp() });
  b.delete(doc(db, `pairingCodes/${h}`));
  return b.commit();
};

describe("código de pareamento (sem servidor)", () => {
  it("paciente cria o próprio código; não cria para outro nem com validade absurda", async () => {
    await assertSucceeds(setDoc(doc(as("p1"), `pairingCodes/${H1}`), codeDoc("p1")));
    await assertFails(setDoc(doc(as("p1"), `pairingCodes/${H2}`), codeDoc("p2")));
    await assertFails(setDoc(doc(as("p1"), `pairingCodes/${H2}`), codeDoc("p1", inMin(120))));
    await assertFails(setDoc(doc(as("p1"), `pairingCodes/xyz`), codeDoc("p1")));
  });
  it("cuidador lê só pelo código; ninguém lista os códigos dos outros", async () => {
    await seedCode(H1, "p1");
    await assertSucceeds(getDoc(doc(as("c9"), `pairingCodes/${H1}`)));
    await assertFails(getDocs(collection(as("c9"), "pairingCodes")));
    await assertSucceeds(getDocs(query(collection(as("p1"), "pairingCodes"), where("pid", "==", "p1"))));
    await assertFails(getDocs(query(collection(as("c9"), "pairingCodes"), where("pid", "==", "p1"))));
  });
  it("sem login não lê código", async () => {
    await seedCode(H1, "p1");
    await assertFails(getDoc(doc(env.unauthenticatedContext().firestore(), `pairingCodes/${H1}`)));
  });
  it("cuidador não apaga código sem pedir acesso; o paciente apaga o próprio", async () => {
    await seedCode(H1, "p1");
    await assertFails(deleteDoc(doc(as("c9"), `pairingCodes/${H1}`)));
    await assertSucceeds(deleteDoc(doc(as("p1"), `pairingCodes/${H1}`)));
  });
});

describe("pedido de acesso (sem servidor)", () => {
  it("cuidador com código válido cria pedido + aviso pendente e consome o código", async () => {
    await seedCode(H1, "p1");
    await assertSucceeds(pairBatch(asEmail("c9", "c9@x.com"), "c9", "p1", H1));
    await assertSucceeds(getDoc(doc(as("p1"), "patients/p1/requests/c9")));
    const s = await env.withSecurityRulesDisabled((c) => getDoc(doc(c.firestore(), `pairingCodes/${H1}`)));
    if (s.exists()) throw new Error("o código deveria ter sido consumido");
  });
  it("código expirado, de outro paciente ou inexistente não vale", async () => {
    await seedCode(H1, "p1"); await seedCode(H2, "p1", Timestamp.fromMillis(Date.now() - 60000));
    await assertFails(pairBatch(asEmail("c9", "c9@x.com"), "c9", "p1", H2));
    await assertFails(pairBatch(asEmail("c9", "c9@x.com"), "c9", "p2", H1));
    await assertFails(pairBatch(asEmail("c9", "c9@x.com"), "c9", "p1", "c".repeat(64)));
    await assertSucceeds(pairBatch(asEmail("c9", "c9@x.com"), "c9", "p1", H1));
  });
  it("pedido não pode usar o uid, o e-mail ou o status de outra pessoa", async () => {
    await seedCode(H1, "p1");
    const c = asEmail("c9", "c9@x.com");
    await assertFails(setDoc(doc(c, "patients/p1/requests/c8"), { uid: "c8", name: "x", status: "pending", createdAt: serverTimestamp(), codeHash: H1 }));
    await assertFails(setDoc(doc(c, "patients/p1/requests/c9"), { uid: "c9", name: "x", email: "outro@x.com", status: "pending", createdAt: serverTimestamp(), codeHash: H1 }));
    await assertFails(setDoc(doc(c, "patients/p1/requests/c9"), { uid: "c9", name: "x", status: "approved", createdAt: serverTimestamp(), codeHash: H1 }));
  });
  it("cuidador não cria vínculo nem aviso ativo para si", async () => {
    await assertFails(setDoc(doc(as("c9"), "users/c9/patients/p1"), { patientId: "p1", status: "active", permissions: P({ history: true }) }));
    await assertSucceeds(setDoc(doc(as("c9"), "users/c9/patients/p1"), { patientId: "p1", status: "pending", permissions: {} }));
    await assertFails(setDoc(doc(as("c9"), "patients/p1/links/c9"), { uid: "c9", status: "active", permissions: P({ history: true }) }));
  });
});

describe("aprovação, permissões e revogação feitas pelo paciente", () => {
  const approve = (db, cuid, perms) => {
    const b = writeBatch(db);
    b.set(doc(db, `patients/p1/links/${cuid}`), { uid: cuid, name: "Ana", status: "active", permissions: P(perms), grantedAt: serverTimestamp() });
    b.update(doc(db, `patients/p1/requests/${cuid}`), { status: "approved", decidedAt: serverTimestamp() });
    b.set(doc(db, `users/${cuid}/patients/p1`), { patientId: "p1", patientName: "P", status: "active", permissions: P(perms), updatedAt: serverTimestamp() });
    return b.commit();
  };
  beforeEach(async () => {
    await seedCode(H1, "p1");
    await pairBatch(asEmail("c9", "c9@x.com"), "c9", "p1", H1);
  });
  it("paciente aprova: o cuidador passa a ler só o que foi permitido", async () => {
    await assertFails(g("c9", "patients/p1/current/latest"));
    await assertSucceeds(approve(as("p1"), "c9", { currentGlucose: true }));
    await assertSucceeds(g("c9", "patients/p1/current/latest"));
    await assertFails(g("c9", "patients/p1/readings/r1"));
    await assertSucceeds(g("c9", "users/c9/patients/p1"));
  });
  it("só o paciente aprova; permissão desconhecida é recusada", async () => {
    await assertFails(approve(as("c9"), "c9", { history: true }));
    await assertFails(setDoc(doc(as("p1"), "patients/p1/links/c9"), { uid: "c9", status: "active", permissions: { admin: true } }));
  });
  it("paciente muda permissões e revoga; o acesso cai na hora", async () => {
    await approve(as("p1"), "c9", { currentGlucose: true });
    await assertSucceeds(updateDoc(doc(as("p1"), "patients/p1/links/c9"), { permissions: P({ currentGlucose: true, history: true }) }));
    await assertSucceeds(g("c9", "patients/p1/readings/r1"));
    await assertSucceeds(updateDoc(doc(as("p1"), "patients/p1/links/c9"), { status: "revoked", permissions: P({}) }));
    await assertFails(g("c9", "patients/p1/current/latest"));
    await assertFails(updateDoc(doc(as("c9"), "patients/p1/links/c9"), { status: "active" }));
  });
  it("paciente recusa; o cuidador pode pedir de novo apagando o próprio pedido", async () => {
    await assertSucceeds(updateDoc(doc(as("p1"), "patients/p1/requests/c9"), { status: "denied", decidedAt: serverTimestamp() }));
    await assertFails(updateDoc(doc(as("c9"), "patients/p1/requests/c9"), { status: "approved" }));
    await assertSucceeds(deleteDoc(doc(as("c9"), "patients/p1/requests/c9")));
  });
});

describe("cálculos gravados pelo paciente (antes eram das Functions)", () => {
  const latest = (o = {}) => ({ value: 120, unit: "mg/dL", source: "cgm", originTs: Timestamp.now(), serverTs: serverTimestamp(), processedAt: serverTimestamp(), readingId: "r9", state: "range", ...o });
  const alert = (id, o = {}) => ({ id, type: "hypo", severity: "high", severityLabel: "Alto", label: "Hipoglicemia", value: 60, unit: "mg/dL", originTs: Timestamp.now(), source: "cgm", createdAt: serverTimestamp(), ...o });
  it("current/latest e trend: só o paciente grava; valor absurdo é recusado", async () => {
    await assertSucceeds(setDoc(doc(as("p1"), "patients/p1/current/latest"), latest()));
    await assertFails(setDoc(doc(as("p1"), "patients/p1/current/latest"), latest({ value: 5 })));
    await assertFails(setDoc(doc(as("p1"), "patients/p1/current/latest"), latest({ state: "x" })));
    await assertFails(setDoc(doc(as("c1"), "patients/p1/current/latest"), latest()));
    await assertSucceeds(setDoc(doc(as("p1"), "patients/p1/current/trend"), { arrow: "↑", ratePerMin: 1.2, computedAt: serverTimestamp() }));
    await assertFails(setDoc(doc(as("c1"), "patients/p1/current/trend"), { arrow: "↑" }));
  });
  it("estatísticas, HbA1c atual e lastReadingAt: só o paciente", async () => {
    await assertSucceeds(setDoc(doc(as("p1"), "patients/p1/stats/gmi"), { gmi: 7.0, reliable: true }));
    await assertSucceeds(setDoc(doc(as("p1"), "patients/p1/chartData/hourlyProfile"), { points: [] }));
    await assertSucceeds(setDoc(doc(as("p1"), "patients/p1/hba1cLatest/main"), { value: 6.8 }));
    await assertSucceeds(updateDoc(doc(as("p1"), "patients/p1"), { lastReadingAt: Timestamp.now() }));
    await assertFails(setDoc(doc(as("c1"), "patients/p1/stats/gmi"), { gmi: 5 }));
    await assertFails(updateDoc(doc(as("c1"), "patients/p1"), { lastReadingAt: Timestamp.now() }));
  });
  it("alerta: paciente cria com id coerente; não duplica e cuidador não cria", async () => {
    await assertSucceeds(setDoc(doc(as("p1"), "patients/p1/alerts/hypo_100"), alert("hypo_100")));
    await assertFails(setDoc(doc(as("p1"), "patients/p1/alerts/hypo_100"), alert("hypo_100", { value: 61 })));
    await assertFails(setDoc(doc(as("p1"), "patients/p1/alerts/hypo_101"), alert("outro_id")));
    await assertFails(setDoc(doc(as("p1"), "patients/p1/alerts/x_1"), alert("x_1", { type: "inventado" })));
    await assertFails(setDoc(doc(as("p1"), "patients/p1/alerts/hypo_102"), alert("hypo_102", { value: 3 })));
    await assertFails(setDoc(doc(as("c1"), "patients/p1/alerts/hypo_103"), alert("hypo_103")));
  });
  it("LGPD: o paciente apaga tudo debaixo do próprio documento; ninguém apaga o de outro", async () => {
    await assertSucceeds(deleteDoc(doc(as("p1"), "patients/p1/stats/gmi")));
    await assertSucceeds(deleteDoc(doc(as("p1"), "patients/p1/alerts/a1")));
    await assertSucceeds(deleteDoc(doc(as("p1"), "patients/p1")));
    await assertFails(deleteDoc(doc(as("p2"), "patients/p1/alerts/a1")));
    await assertFails(deleteDoc(doc(as("c1"), "patients/p1/alerts/a1")));
  });
});

describe("extras por permissão (insulina, refeições, sintomas, remédios, água, lembretes)", () => {
  const extras = [["insulin", { kind: "rapida", name: "Rápida", dose: 4, unit: "UI", at: Timestamp.now() }],
    ["meals", { type: "almoço", description: "arroz", carbs: 40, at: Timestamp.now() }],
    ["symptoms", { name: "tontura", intensity: "leve", at: Timestamp.now() }],
    ["medications", { name: "Metformina", dose: "500 mg", schedule: "2x", active: true }],
    ["reminders", { kind: "glicose", title: "Medir", hour: 8, minute: 0, days: [1, 2], enabled: true }],
    ["water", { date: "2026-11-25", ml: 500, goal: 2000 }]];
  it("só o paciente grava; o cuidador lê somente com a permissão da categoria", async () => {
    for (const [c, d] of extras) {
      await assertSucceeds(setDoc(doc(as("p1"), `patients/p1/${c}/x1`), d));
      await assertFails(setDoc(doc(as("c1"), `patients/p1/${c}/x2`), d));
      await assertFails(g("c1", `patients/p1/${c}/x1`));
      await env.withSecurityRulesDisabled((ctx) => setDoc(doc(ctx.firestore(), "patients/p1/links/c1"), { uid: "c1", status: "active", permissions: P({ [c]: true }) }));
      await assertSucceeds(g("c1", `patients/p1/${c}/x1`));
      await env.withSecurityRulesDisabled((ctx) => setDoc(doc(ctx.firestore(), "patients/p1/links/c1"), { uid: "c1", status: "active", permissions: P({}) }));
    }
  });
  it("permissão nova é aceita no vínculo; chave inventada continua recusada", async () => {
    await assertSucceeds(setDoc(doc(as("p1"), "patients/p1/links/c7"), { uid: "c7", status: "active", permissions: P({ insulin: true, water: true }) }));
    await assertFails(setDoc(doc(as("p1"), "patients/p1/links/c7"), { uid: "c7", status: "active", permissions: { senhaDoBanco: true } }));
  });
});
