/* Gluco Cris — Worker de notificações do Cuidador (plano gratuito: sem Cloud Functions).
 *
 * Faz só o que o app não consegue sozinho: enviar push (FCM) para OUTRO aparelho e vigiar "sem novas leituras".
 * Tudo é conferido no Firestore antes de enviar (só vira push o que existe de verdade e uma única vez).
 *
 *   POST /v1/notify   Authorization: Bearer <ID token do Firebase>   corpo JSON { kind, ... }
 *     kind = "alert"           { alertId }                    paciente avisa os cuidadores com permissão "alerts"
 *     kind = "access_request"  { patientId }                  cuidador avisa o paciente de um pedido de acesso
 *     kind = "access_approved" { caregiverUid }               paciente avisa o cuidador de que foi aprovado
 *     kind = "contact_request" { patientId, requestId }       cuidador pede que o paciente entre em contato
 *   GET /               saúde do serviço (não revela nada)
 *   cron (*\/10 * * * *)   alerta "Sem novas leituras do CGM" (quem tem cgmExpected=true e ficou sem enviar)
 *
 * Segredos (nunca no código/APK/GitHub):  wrangler secret put FIREBASE_SERVICE_ACCOUNT   (JSON da conta de serviço)
 * Variável:  FIREBASE_PROJECT_ID (wrangler.toml)
 */

const GOOGLE_JWKS = "https://www.googleapis.com/service_accounts/v1/jwk/securetoken@system.gserviceaccount.com";
const MAX_TOKENS_PER_USER = 8;
const MAX_STALE_ALERTS_PER_RUN = 6; // plano gratuito do Workers: 50 subrequisições por execução

// ───────────────────────── utilidades ─────────────────────────
const enc = new TextEncoder();
export const b64uFromBytes = (buf) => {
  const bytes = new Uint8Array(buf);
  let s = "";
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
};
export const b64uFromString = (str) => b64uFromBytes(enc.encode(str));
export const bytesFromB64u = (s) => {
  const p = s.replace(/-/g, "+").replace(/_/g, "/") + "===".slice((s.length + 3) % 4);
  return Uint8Array.from(atob(p), (c) => c.charCodeAt(0));
};
const jsonFromB64u = (s) => JSON.parse(new TextDecoder().decode(bytesFromB64u(s)));
const pemToBuf = (pem) => bytesFromB64u(pem.replace(/-----[A-Z ]+-----/g, "").replace(/\s+/g, "").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, ""));

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store" } });

// ───────────────────────── valores do Firestore (REST) ─────────────────────────
export function fsDecode(v) {
  if (v == null) return null;
  if ("stringValue" in v) return v.stringValue;
  if ("integerValue" in v) return Number(v.integerValue);
  if ("doubleValue" in v) return v.doubleValue;
  if ("booleanValue" in v) return v.booleanValue;
  if ("timestampValue" in v) return new Date(v.timestampValue);
  if ("nullValue" in v) return null;
  if ("mapValue" in v) return fsDecodeFields(v.mapValue.fields || {});
  if ("arrayValue" in v) return (v.arrayValue.values || []).map(fsDecode);
  return null;
}
export const fsDecodeFields = (f) => Object.fromEntries(Object.entries(f || {}).map(([k, v]) => [k, fsDecode(v)]));
export function fsEncode(x) {
  if (x === null || x === undefined) return { nullValue: null };
  if (x instanceof Date) return { timestampValue: x.toISOString() };
  if (typeof x === "string") return { stringValue: x };
  if (typeof x === "boolean") return { booleanValue: x };
  if (typeof x === "number") return Number.isInteger(x) ? { integerValue: String(x) } : { doubleValue: x };
  if (typeof x === "object") return { mapValue: { fields: Object.fromEntries(Object.entries(x).map(([k, v]) => [k, fsEncode(v)])) } };
  return { nullValue: null };
}
const fsFields = (obj) => Object.fromEntries(Object.entries(obj).map(([k, v]) => [k, fsEncode(v)]));
const lastSeg = (name) => name.split("/").pop();

// ───────────────────────── autenticação Google (conta de serviço) ─────────────────────────
let tokenCache = { token: "", exp: 0 };
async function accessToken(env) {
  if (tokenCache.token && tokenCache.exp > Date.now() + 60_000) return tokenCache.token;
  const sa = JSON.parse(env.FIREBASE_SERVICE_ACCOUNT);
  const now = Math.floor(Date.now() / 1000);
  const unsigned =
    b64uFromString(JSON.stringify({ alg: "RS256", typ: "JWT" })) + "." +
    b64uFromString(JSON.stringify({
      iss: sa.client_email, scope: "https://www.googleapis.com/auth/cloud-platform",
      aud: "https://oauth2.googleapis.com/token", iat: now, exp: now + 3600,
    }));
  const key = await crypto.subtle.importKey("pkcs8", pemToBuf(sa.private_key), { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, enc.encode(unsigned));
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "content-type": "application/x-www-form-urlencoded" },
    body: "grant_type=" + encodeURIComponent("urn:ietf:params:oauth:grant-type:jwt-bearer") + "&assertion=" + unsigned + "." + b64uFromBytes(sig),
  });
  if (!res.ok) throw new Error("oauth " + res.status);
  const j = await res.json();
  tokenCache = { token: j.access_token, exp: Date.now() + (j.expires_in || 3600) * 1000 };
  return tokenCache.token;
}

// ───────────────────────── verificação do ID token do app ─────────────────────────
let jwksCache = { keys: [], exp: 0 };
async function jwks() {
  if (jwksCache.keys.length && jwksCache.exp > Date.now()) return jwksCache.keys;
  const res = await fetch(GOOGLE_JWKS);
  if (!res.ok) throw new Error("jwks " + res.status);
  const j = await res.json();
  jwksCache = { keys: j.keys || [], exp: Date.now() + 3_600_000 };
  return jwksCache.keys;
}

/** Valida o ID token do Firebase e devolve { uid, provider }. Lança Error se inválido. */
export async function verifyIdToken(env, token, nowSec = Math.floor(Date.now() / 1000), keysOverride = null) {
  const parts = String(token || "").split(".");
  if (parts.length !== 3) throw new Error("token malformado");
  const header = jsonFromB64u(parts[0]);
  const p = jsonFromB64u(parts[1]);
  if (header.alg !== "RS256" || !header.kid) throw new Error("algoritmo inválido");
  const keys = keysOverride || (await jwks());
  const jwk = keys.find((k) => k.kid === header.kid);
  if (!jwk) throw new Error("chave desconhecida");
  const key = await crypto.subtle.importKey("jwk", jwk, { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["verify"]);
  const ok = await crypto.subtle.verify("RSASSA-PKCS1-v1_5", key, bytesFromB64u(parts[2]), enc.encode(parts[0] + "." + parts[1]));
  if (!ok) throw new Error("assinatura inválida");
  const proj = env.FIREBASE_PROJECT_ID;
  if (p.aud !== proj) throw new Error("aud inválido");
  if (p.iss !== "https://securetoken.google.com/" + proj) throw new Error("iss inválido");
  if (!p.sub || typeof p.sub !== "string") throw new Error("sub inválido");
  if (typeof p.exp !== "number" || p.exp < nowSec - 30) throw new Error("token expirado");
  if (typeof p.iat === "number" && p.iat > nowSec + 300) throw new Error("iat no futuro");
  const provider = p.firebase && p.firebase.sign_in_provider;
  if (!provider || provider === "anonymous") throw new Error("conta anônima não permitida");
  return { uid: p.sub, provider };
}

// ───────────────────────── Firestore REST ─────────────────────────
const fsBase = (env) => `https://firestore.googleapis.com/v1/projects/${env.FIREBASE_PROJECT_ID}/databases/(default)/documents`;
async function fs(env, method, path, { body, query } = {}) {
  const t = await accessToken(env);
  const url = fsBase(env) + path + (query ? "?" + query : "");
  return fetch(url, { method, headers: { authorization: "Bearer " + t, "content-type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
}
async function getDoc(env, path) {
  const r = await fs(env, "GET", "/" + path);
  if (r.status === 404) return null;
  if (!r.ok) throw new Error("firestore get " + r.status);
  const j = await r.json();
  return { id: lastSeg(j.name), data: fsDecodeFields(j.fields) };
}
async function listDocs(env, collectionPath) {
  const out = [];
  let pageToken = "";
  for (let i = 0; i < 3; i++) {
    const r = await fs(env, "GET", "/" + collectionPath, { query: "pageSize=100" + (pageToken ? "&pageToken=" + encodeURIComponent(pageToken) : "") });
    if (r.status === 404) break;
    if (!r.ok) throw new Error("firestore list " + r.status);
    const j = await r.json();
    for (const d of j.documents || []) out.push({ id: lastSeg(d.name), data: fsDecodeFields(d.fields) });
    if (!j.nextPageToken) break;
    pageToken = j.nextPageToken;
  }
  return out;
}
/** Atualiza só os campos citados; falha se o documento não existir. */
async function patchFields(env, path, obj) {
  const mask = Object.keys(obj).map((k) => "updateMask.fieldPaths=" + encodeURIComponent(k)).join("&");
  const r = await fs(env, "PATCH", "/" + path, { query: mask + "&currentDocument.exists=true", body: { fields: fsFields(obj) } });
  if (!r.ok) throw new Error("firestore patch " + r.status);
}
/** Cria só se não existir. Devolve false se já existia. */
async function createDoc(env, collectionPath, id, obj) {
  const r = await fs(env, "POST", "/" + collectionPath, { query: "documentId=" + encodeURIComponent(id), body: { fields: fsFields(obj) } });
  if (r.status === 409) return false;
  if (!r.ok) throw new Error("firestore create " + r.status);
  return true;
}
async function deleteDoc(env, path) { await fs(env, "DELETE", "/" + path); }
async function runQuery(env, structuredQuery) {
  const r = await fs(env, "POST", ":runQuery", { body: { structuredQuery } });
  if (!r.ok) throw new Error("firestore query " + r.status);
  const j = await r.json();
  return j.filter((x) => x.document).map((x) => ({ id: lastSeg(x.document.name), data: fsDecodeFields(x.document.fields) }));
}

// ───────────────────────── FCM ─────────────────────────
async function sendFcm(env, token, data) {
  const t = await accessToken(env);
  const r = await fetch(`https://fcm.googleapis.com/v1/projects/${env.FIREBASE_PROJECT_ID}/messages:send`, {
    method: "POST",
    headers: { authorization: "Bearer " + t, "content-type": "application/json" },
    body: JSON.stringify({ message: { token, data, android: { priority: "HIGH" } } }),
  });
  if (r.ok) return "ok";
  const txt = await r.text();
  if (r.status === 404 || /UNREGISTERED|registration-token-not-registered|INVALID_ARGUMENT/.test(txt)) return "dead";
  return "error";
}
const strData = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v != null).map(([k, v]) => [k, String(v)]));

async function pushToUser(env, uid, { title, body, data }) {
  const toks = (await listDocs(env, `users/${uid}/devices`)).slice(0, MAX_TOKENS_PER_USER);
  let sent = 0;
  for (const tk of toks) {
    const res = await sendFcm(env, tk.id, strData({ title, body, ...(data || {}) }));
    if (res === "ok") sent++;
    else if (res === "dead") await deleteDoc(env, `users/${uid}/devices/${tk.id}`);
  }
  return sent;
}

const hhmm = (d) => d.toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit", timeZone: "America/Sao_Paulo" });

export function alertPushText(alert, patientName, canSeeValue) {
  const showValue = canSeeValue && alert.value != null;
  return {
    title: `${alert.severityLabel || "Alerta"}: ${patientName || "Paciente"}`,
    body: `${alert.label}${showValue ? ` — ${alert.value} mg/dL` : ""} às ${hhmm(alert.originTs)}`,
  };
}

async function notifyCaregivers(env, pid, alert) {
  const patient = (await getDoc(env, `patients/${pid}`))?.data || {};
  const links = await listDocs(env, `patients/${pid}/links`);
  let sent = 0;
  for (const l of links) {
    const perms = l.data.permissions || {};
    if (l.data.status !== "active" || !perms.alerts) continue;
    const txt = alertPushText(alert, patient.displayName, !!perms.currentGlucose);
    sent += await pushToUser(env, l.id, {
      ...txt,
      data: { kind: "alert", patientId: pid, alertId: alert.id, severity: alert.severity, type: alert.type },
    });
  }
  return sent;
}

// ───────────────────────── /v1/notify ─────────────────────────
const ID_RE = /^[A-Za-z0-9_-]{1,128}$/;
const ALERT_ID_RE = /^[a-z_]+_\d{1,12}$/;

async function handleNotify(env, uid, body) {
  const kind = body && body.kind;

  if (kind === "alert") {
    const alertId = String(body.alertId || "");
    if (!ALERT_ID_RE.test(alertId)) return json({ error: "alertId inválido" }, 400);
    const path = `patients/${uid}/alerts/${alertId}`;
    const a = await getDoc(env, path);
    if (!a) return json({ error: "alerta inexistente" }, 404);
    if (a.data.pushedAt) return json({ ok: true, sent: 0, duplicate: true });
    if (!(a.data.originTs instanceof Date) || Date.now() - a.data.originTs.getTime() > 12 * 3_600_000) return json({ ok: true, sent: 0, stale: true });
    await patchFields(env, path, { pushedAt: new Date() });
    const sent = await notifyCaregivers(env, uid, { ...a.data, id: alertId });
    return json({ ok: true, sent });
  }

  if (kind === "access_request") {
    const pid = String(body.patientId || "");
    if (!ID_RE.test(pid)) return json({ error: "patientId inválido" }, 400);
    const path = `patients/${pid}/requests/${uid}`;
    const r = await getDoc(env, path);
    if (!r || r.data.status !== "pending") return json({ error: "pedido inexistente" }, 404);
    if (r.data.pushedAt) return json({ ok: true, sent: 0, duplicate: true });
    await patchFields(env, path, { pushedAt: new Date() });
    const name = String(r.data.name || "Um cuidador").slice(0, 80);
    const sent = await pushToUser(env, pid, { title: "Nova solicitação de acesso", body: `${name} pediu para acompanhar você.`, data: { kind: "access_request" } });
    return json({ ok: true, sent });
  }

  if (kind === "access_approved") {
    const cuid = String(body.caregiverUid || "");
    if (!ID_RE.test(cuid)) return json({ error: "caregiverUid inválido" }, 400);
    const reqPath = `patients/${uid}/requests/${cuid}`;
    const [r, link] = await Promise.all([getDoc(env, reqPath), getDoc(env, `patients/${uid}/links/${cuid}`)]);
    if (!r || r.data.status !== "approved" || !link || link.data.status !== "active") return json({ error: "aprovação inexistente" }, 404);
    if (r.data.approvedPushedAt) return json({ ok: true, sent: 0, duplicate: true });
    await patchFields(env, reqPath, { approvedPushedAt: new Date() });
    const patient = (await getDoc(env, `patients/${uid}`))?.data || {};
    const sent = await pushToUser(env, cuid, {
      title: "Acesso aprovado", body: `${patient.displayName || "Paciente"} autorizou seu acompanhamento.`,
      data: { kind: "access_approved", patientId: uid },
    });
    return json({ ok: true, sent });
  }

  if (kind === "contact_request") {
    const pid = String(body.patientId || "");
    const rid = String(body.requestId || "");
    if (!ID_RE.test(pid) || !ID_RE.test(rid)) return json({ error: "parâmetros inválidos" }, 400);
    const path = `patients/${pid}/contactRequests/${rid}`;
    const [c, link] = await Promise.all([getDoc(env, path), getDoc(env, `patients/${pid}/links/${uid}`)]);
    if (!c || c.data.fromUid !== uid) return json({ error: "pedido inexistente" }, 404);
    if (!link || link.data.status !== "active" || !(link.data.permissions || {}).alerts) return json({ error: "sem permissão" }, 403);
    if (c.data.pushedAt) return json({ ok: true, sent: 0, duplicate: true });
    await patchFields(env, path, { pushedAt: new Date() });
    const sent = await pushToUser(env, pid, { title: "Um cuidador pediu contato", body: "Toque para responder.", data: { kind: "contact_request" } });
    return json({ ok: true, sent });
  }

  return json({ error: "kind inválido" }, 400);
}

// ───────────────────────── cron: falta de leituras ─────────────────────────
export function staleDecision(p, nowMs) {
  const last = p.lastReadingAt instanceof Date ? p.lastReadingAt.getTime() : null;
  const limit = (Number(p.staleAfterMin) || 20) * 60_000;
  if (!last) return false;
  if (nowMs - last < limit) return false;
  if (nowMs - last > 24 * 3_600_000) return false; // não alertar indefinidamente
  return true;
}

async function runStale(env) {
  const ps = await runQuery(env, {
    from: [{ collectionId: "patients" }],
    where: { fieldFilter: { field: { fieldPath: "cgmExpected" }, op: "EQUAL", value: { booleanValue: true } } },
    limit: 200,
  });
  const now = Date.now();
  let made = 0;
  for (const p of ps) {
    if (made >= MAX_STALE_ALERTS_PER_RUN) break;
    if (!staleDecision(p.data, now)) continue;
    const id = `no_readings_${Math.floor(now / 1_800_000)}`;
    const alert = {
      id, type: "no_readings", severity: "attention", severityLabel: "Atenção", label: "Sem novas leituras do CGM",
      value: null, unit: "mg/dL", source: "system", originTs: new Date(now), createdAt: new Date(now), pushedAt: new Date(now),
    };
    if (!(await createDoc(env, `patients/${p.id}/alerts`, id, alert))) continue;
    made++;
    await notifyCaregivers(env, p.id, alert);
  }
  return made;
}

// ───────────────────────── entrada ─────────────────────────
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (request.method === "GET" && url.pathname === "/") return json({ service: "gluco-cris-cuidador-push", ok: true });
    if (request.method !== "POST" || url.pathname !== "/v1/notify") return json({ error: "não encontrado" }, 404);
    if (!env.FIREBASE_SERVICE_ACCOUNT || !env.FIREBASE_PROJECT_ID) return json({ error: "Worker sem configuração" }, 500);
    const auth = request.headers.get("authorization") || "";
    const m = /^Bearer\s+(.+)$/i.exec(auth);
    if (!m) return json({ error: "sem token" }, 401);
    let who;
    try { who = await verifyIdToken(env, m[1]); } catch (e) { return json({ error: "token inválido" }, 401); }
    let body;
    try { body = await request.json(); } catch { return json({ error: "JSON inválido" }, 400); }
    try { return await handleNotify(env, who.uid, body); } catch (e) { return json({ error: "falha ao notificar" }, 502); }
  },
  async scheduled(_event, env, ctx) {
    if (!env.FIREBASE_SERVICE_ACCOUNT || !env.FIREBASE_PROJECT_ID) return;
    ctx.waitUntil(runStale(env).catch(() => {}));
  },
};
