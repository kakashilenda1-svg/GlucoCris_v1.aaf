// node --test worker.test.mjs   (Node 20+; não usa rede)
import test from "node:test";
import assert from "node:assert/strict";
import { fsEncode, fsDecode, fsDecodeFields, verifyIdToken, staleDecision, alertPushText, b64uFromBytes, b64uFromString } from "./worker.js";

const ENV = { FIREBASE_PROJECT_ID: "gluco-cris" };

test("valores do Firestore: ida e volta", () => {
  const src = { a: "x", n: 5, f: 1.5, ok: true, nada: null, d: new Date("2026-01-02T03:04:05.000Z"), m: { z: 1 } };
  const enc = fsEncode(src);
  const back = fsDecode(enc);
  assert.equal(back.a, "x"); assert.equal(back.n, 5); assert.equal(back.f, 1.5); assert.equal(back.ok, true);
  assert.equal(back.nada, null); assert.equal(back.d.toISOString(), "2026-01-02T03:04:05.000Z"); assert.equal(back.m.z, 1);
  assert.deepEqual(fsDecodeFields({ q: { integerValue: "7" } }), { q: 7 });
});

async function makeToken(claims, { kid = "k1", tamper = false } = {}) {
  const kp = await crypto.subtle.generateKey({ name: "RSASSA-PKCS1-v1_5", modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: "SHA-256" }, true, ["sign", "verify"]);
  const jwk = { ...(await crypto.subtle.exportKey("jwk", kp.publicKey)), kid };
  const h = b64uFromString(JSON.stringify({ alg: "RS256", kid, typ: "JWT" }));
  const p = b64uFromString(JSON.stringify(claims));
  const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", kp.privateKey, new TextEncoder().encode(h + "." + p));
  let tok = h + "." + p + "." + b64uFromBytes(sig);
  if (tamper) tok = h + "." + b64uFromString(JSON.stringify({ ...claims, sub: "outro" })) + "." + b64uFromBytes(sig);
  return { tok, keys: [jwk] };
}
const now = 1_800_000_000;
const good = { aud: "gluco-cris", iss: "https://securetoken.google.com/gluco-cris", sub: "uid123", iat: now - 10, exp: now + 3000, firebase: { sign_in_provider: "password" } };

test("ID token válido é aceito", async () => {
  const { tok, keys } = await makeToken(good);
  const r = await verifyIdToken(ENV, tok, now, keys);
  assert.equal(r.uid, "uid123"); assert.equal(r.provider, "password");
});
test("ID token: adulterado, expirado, projeto errado e anônimo são recusados", async () => {
  { const { tok, keys } = await makeToken(good, { tamper: true }); await assert.rejects(verifyIdToken(ENV, tok, now, keys)); }
  { const { tok, keys } = await makeToken({ ...good, exp: now - 1000 }); await assert.rejects(verifyIdToken(ENV, tok, now, keys)); }
  { const { tok, keys } = await makeToken({ ...good, aud: "outro" }); await assert.rejects(verifyIdToken(ENV, tok, now, keys)); }
  { const { tok, keys } = await makeToken({ ...good, iss: "https://securetoken.google.com/outro" }); await assert.rejects(verifyIdToken(ENV, tok, now, keys)); }
  { const { tok, keys } = await makeToken({ ...good, firebase: { sign_in_provider: "anonymous" } }); await assert.rejects(verifyIdToken(ENV, tok, now, keys)); }
  await assert.rejects(verifyIdToken(ENV, "lixo", now, []));
});

test("falta de leituras: só entre o limite e 24 h", () => {
  const n = Date.parse("2026-11-25T12:00:00Z");
  const at = (min) => ({ lastReadingAt: new Date(n - min * 60000), staleAfterMin: 40 });
  assert.equal(staleDecision(at(10), n), false);
  assert.equal(staleDecision(at(41), n), true);
  assert.equal(staleDecision(at(60 * 25), n), false);
  assert.equal(staleDecision({ staleAfterMin: 40 }, n), false);
});

test("texto do push: sem permissão de glicemia não vaza o valor", () => {
  const a = { severityLabel: "Alto", label: "Hipoglicemia", value: 60, originTs: new Date("2026-11-25T15:30:00Z") };
  assert.match(alertPushText(a, "Maria", true).body, /60 mg\/dL/);
  assert.doesNotMatch(alertPushText(a, "Maria", false).body, /mg\/dL/);
  assert.equal(alertPushText(a, "Maria", true).title, "Alto: Maria");
});
