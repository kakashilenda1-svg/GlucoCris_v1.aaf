# Proxy Tavily + Gemini do Gluco Cris

Guarda as chaves da **Tavily** e do **Google Gemini** no servidor (Cloudflare Workers).
O app só conhece o endereço deste proxy. **Nenhuma chave vai no APK.**

## Rotas

| Método | Caminho   | Função                                      |
|--------|-----------|---------------------------------------------|
| POST   | `/` ou `/tavily` | Pesquisa Tavily (contrato original)    |
| POST   | `/gemini` | Proxy para `generateContent` do Gemini      |
| OPTIONS| qualquer  | CORS preflight                              |

## Publicar (Cloudflare Workers, plano gratuito)

```bash
cd backend/tavily-proxy
npx wrangler login
npx wrangler secret put TAVILY_API_KEY     # chave de https://www.tavily.com/
npx wrangler secret put GEMINI_API_KEY    # chave da Google AI Studio / Gemini API
# (opcional) token do app:
npx wrangler secret put APP_TOKEN
# (recomendado) contador global:
npx wrangler kv namespace create USAGE
# cole o id em wrangler.toml e descomente o bloco [[kv_namespaces]]
npx wrangler deploy
# imprime https://gluco-cris-tavily-proxy.<conta>.workers.dev
```

### Ação manual obrigatória na Cloudflare

1. Entre no diretório `backend/tavily-proxy`.
2. Execute `npx wrangler secret put GEMINI_API_KEY` e cole a chave da Google AI Studio
   (formato `AIza...` ou o novo formato suportado pela API).
3. Mantenha o segredo `TAVILY_API_KEY` já existente (não remova).
4. Faça o deploy: `npx wrangler deploy`.
5. Confirme que a URL pública continua a mesma usada em `tavily.proxy.url` no app
   (ou atualize `local.properties` / CI se o nome do worker mudar).

**Não** coloque `GEMINI_API_KEY` nem `TAVILY_API_KEY` em `local.properties`, BuildConfig,
código-fonte ou logs.

## No app

`local.properties` (não versionado):

```
tavily.proxy.url=https://gluco-cris-tavily-proxy.<conta>.workers.dev
tavily.app.token=SEU_TOKEN_OPCIONAL
# gemini.api.key NÃO É MAIS USADO — a chave fica só no Worker
gemini.model=gemini-3.8-flash
```

Depois gere o APK. Em Cris IA > configurações:

- **Testar pesquisa** valida o proxy Tavily (1 crédito).
- **Testar Gemini** (se existir na UI) valida a rota `/gemini`.

## Gemini — contrato

O app envia `POST {proxy}/gemini` com:

- Body: JSON idêntico ao de `models/{model}:generateContent` (contents, systemInstruction, etc.).
- Header opcional `x-gemini-model`: um dos modelos da lista branca (padrão `gemini-3.8-flash`).
- Header `x-app-token` se `APP_TOKEN` estiver definido no Worker.

O Worker:

- Valida tamanho do corpo (máx. 8 MB).
- Só permite modelos da lista branca.
- Anexa a chave e encaminha para a API Google.
- Aplica cota diária global opcional (`GEMINI_DAILY_LIMIT`, padrão 2000).
- Não registra o conteúdo das consultas em log.

## Cota e custos

- **Tavily:** Basic = 1 crédito, Advanced = 2. `MONTHLY_LIMIT` / `MONTHLY_RESERVE` no `wrangler.toml`.
- **Gemini:** limite diário global no Worker + limite diário por aparelho no app (40).
- Com KV `USAGE`, o proxy bloqueia (HTTP 429) ao atingir os tetos.

## Teste local

```bash
node test.mjs          # Tavily (simulado)
node test-gemini.mjs   # Gemini (requer GEMINI_API_KEY no ambiente se quiser live)
```

## FoodBase (busca de alimentos, código de barras, scanner e Cris IA)

Rota `POST /foodbase` (a chave **nunca** vai no app). Segredo: `FOODBASE_API_KEY` (a chave que começa com `food_`).

1. No Cloudflare: Workers → seu worker → Settings → Variables and Secrets → **Add secret** `FOODBASE_API_KEY`.
2. Cole o `worker.js` atualizado (Edit code → Deploy).
3. Opcional: crie `FOODBASE_DAILY_LIMIT` (padrão 90) e ligue o KV `USAGE` para o limite diário valer.
4. Diagnóstico (abra no navegador): `https://SEU-WORKER.workers.dev/foodbase/diag` (se tiver `APP_TOKEN`, acrescente `?token=SEU_TOKEN`).
   Mostra se a chave foi aceita, os campos que a FoodBase devolveu e quais caminhos de código de barras responderam. Nunca mostra a chave.
5. Teste local do worker (FoodBase simulada): `node test-foodbase.mjs`.

Plano grátis da FoodBase: 100 requisições/dia e 25 detalhamentos de nutrientes/dia. O worker guarda busca (24 h) e nutrientes (30 dias) em cache para gastar menos.

## Catálogo Gluco (D1) e API própria

Todo produto que o usuário abre no app entra no catálogo, com assinatura única `GLC-XXXXX-XXXXX-XXXXX-XXXXX` (calculada no servidor).
Mesmo código de barras = mesma assinatura em qualquer fonte. Mudança de porção vira nova versão (histórico em `food_revisions`).

**Ligar (uma vez, no painel do Cloudflare)**
1. *Storage & Databases → D1 SQL Database → Create* → nome `gluco-catalog`.
2. No Worker: *Settings → Bindings → Add → D1 database* → variável **`DB`** → escolha `gluco-catalog` → Deploy. (As tabelas o Worker cria sozinho no primeiro uso.)
3. *Variables and Secrets → Add secret* `CATALOG_ADMIN_TOKEN` com uma senha longa sua (só você sabe).
4. Cole o `worker.js` novo e implante.
5. Confira no navegador: `https://SEU-WORKER.workers.dev/catalog/admin?token=SUA_SENHA` → mostra `total`, `bySource`, `policy` e `apiKeys`.

**Administração (PowerShell)** — troque URL e senha:
```
$u = "https://SEU-WORKER.workers.dev/catalog/admin"; $h = @{"x-admin-token"="SUA_SENHA"}
# verificar um produto (aparece na API só se verificado E a fonte estiver liberada):
Invoke-RestMethod -Method Post -Uri $u -Headers $h -ContentType "application/json" -Body '{"op":"verify","sig":"GLC-XXXXX-XXXXX-XXXXX-XXXXX"}'
# liberar/bloquear uma fonte para divulgação (só depois de conferir a licença dela):
Invoke-RestMethod -Method Post -Uri $u -Headers $h -ContentType "application/json" -Body '{"op":"policy","source_key":"usda","can_publish":true}'
# criar chave da API Gluco (aparece UMA vez):
Invoke-RestMethod -Method Post -Uri $u -Headers $h -ContentType "application/json" -Body '{"op":"key_create","label":"parceiro","daily_limit":1000}'
# revogar chave:
Invoke-RestMethod -Method Post -Uri $u -Headers $h -ContentType "application/json" -Body '{"op":"key_revoke","id":1}'
```

**API pública (somente leitura)** — cabeçalho `X-Gluco-Key: gk_…`
- `GET /api/v1/foods?q=arroz&limit=20` · `GET /api/v1/foods/GLC-…` · `GET /api/v1/foods/barcode/7891000100103`
- Só devolve produtos `verified = 1` cuja fonte tenha `can_publish = 1`. Padrão de fábrica: só o USDA está liberado; Open Food Facts (ODbL), FoodBase, FatSecret, TACO e demais ficam **bloqueados** até você conferir a licença.

Teste local (SQLite no lugar do D1): `node --no-warnings test-catalog.mjs`.
