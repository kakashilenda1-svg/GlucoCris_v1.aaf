// Teste local do catálogo Gluco com um banco SQLite REAL (node:sqlite) no lugar do D1. Nada de rede.
import worker from "./worker.js";
import assert from "node:assert/strict";
import { DatabaseSync } from "node:sqlite";

function makeD1() {
  const db = new DatabaseSync(":memory:");
  const stmt = (sql) => {
    let args = [];
    const o = {
      bind(...a) { args = a; return o; },
      async run() { const r = db.prepare(sql).run(...args); return { meta: { changes: Number(r.changes) } }; },
      async first() { return db.prepare(sql).get(...args) ?? null; },
      async all() { return { results: db.prepare(sql).all(...args) }; },
    };
    return o;
  };
  return { prepare: stmt, async batch(list) { for (const s of list) await s.run(); return []; } };
}

const ADMIN = "adm-123";
const mk = () => ({ DB: makeD1(), CATALOG_ADMIN_TOKEN: ADMIN });
const post = (env, path, body, headers = {}) =>
  worker.fetch(new Request("https://p" + path, { method: "POST", headers, body: JSON.stringify(body) }), env);
const get = (env, path, headers = {}) => worker.fetch(new Request("https://p" + path, { headers }), env);
const cat = async (env, body) => { const r = await post(env, "/catalog", body); return [r.status, await r.json()]; };
const adm = async (env, body) => { const r = await post(env, "/catalog/admin", body, { "x-admin-token": ADMIN }); return [r.status, await r.json()]; };

const nutella = (sourceKey, barcode) => ({
  op: "upsert",
  food: { name: "Nutella", brand: "Ferrero", category: "Cremes", serving: "100 g", servingG: 100, barcode, sourceKey, sourceId: "x1",
    per100: { kcal: 539, carbs: 57.5, protein: 6.3, fat: 30.9, sugars: 56.3, satFat: 10.6, sodiumMg: 42.8 } },
});

// 1) sem banco ligado: erro claro, sem quebrar
{
  const [st, j] = await cat({}, { op: "upsert", food: {} });
  assert.equal(st, 503); assert.equal(j.error, "catalog_not_configured");
}

const env = mk();

// 2) primeira vez cria; assinatura GLC-xxxxx-xxxxx-xxxxx-xxxxx; mesmo produto por outra fonte/formato de código NÃO duplica
let [st, a] = await cat(env, nutella("foodbase", "3017620422003"));
assert.equal(st, 200); assert.equal(a.created, true);
assert.match(a.record.sig, /^GLC-[0-9A-F]{5}-[0-9A-F]{5}-[0-9A-F]{5}-[0-9A-F]{5}$/);
assert.equal(a.record.per100.carbs, 57.5); assert.equal(a.record.version, 1); assert.equal(a.record.views, 1);
let [, b] = await cat(env, nutella("off", "03017620422003"));   // outra fonte, código com zero na frente
assert.equal(b.created, false); assert.equal(b.record.sig, a.record.sig); assert.equal(b.record.views, 2);
assert.equal(b.record.sourceKey, "foodbase");                  // a origem do primeiro registro é mantida

// 3) sem código de barras: fonte + id da fonte; fonte diferente = assinatura diferente
let [, c1] = await cat(env, nutella("usda", ""));
let [, c2] = await cat(env, nutella("usda", ""));
let [, c3] = await cat(env, nutella("taco", ""));
assert.equal(c1.record.sig, c2.record.sig); assert.notEqual(c1.record.sig, c3.record.sig); assert.notEqual(c1.record.sig, a.record.sig);

// 4) recusas: fonte privada/IA, valores impossíveis, sem nutrientes
assert.equal((await cat(env, { op: "upsert", food: { ...nutella("custom", "").food, sourceKey: "custom" } }))[0], 422);
assert.equal((await cat(env, { op: "upsert", food: { ...nutella("gemini", "").food, sourceKey: "gemini" } }))[0], 422);
assert.equal((await cat(env, { op: "upsert", food: { ...nutella("off", "").food, per100: { kcal: 100, carbs: 150 } } }))[0], 422);
assert.equal((await cat(env, { op: "upsert", food: { ...nutella("off", "").food, per100: {} } }))[0], 422);
assert.equal((await cat(env, { op: "upsert", food: { name: "", sourceKey: "off" } }))[0], 422);

// 5) edição de porção: nova versão, histórico, não verificada; novas visitas NÃO desfazem a edição
let [, e] = await cat(env, { op: "edit", sig: a.record.sig, serving: "1 colher de sopa", servingG: 18, device: "dev-1" });
assert.equal(e.changed, true); assert.equal(e.record.version, 2); assert.equal(e.record.edited, true); assert.equal(e.record.verified, false);
assert.equal(e.record.serving, "1 colher de sopa"); assert.equal(e.record.servingG, 18); assert.equal(e.record.per100.carbs, 57.5);
let [, same] = await cat(env, { op: "edit", sig: a.record.sig, serving: "1 colher de sopa", servingG: 18 });
assert.equal(same.changed, false); assert.equal(same.record.version, 2);
let [, again] = await cat(env, nutella("foodbase", "3017620422003"));
assert.equal(again.record.serving, "1 colher de sopa"); assert.equal(again.record.version, 2);
let [, h] = await cat(env, { op: "history", sig: a.record.sig });
assert.equal(h.revisions.length, 1); assert.equal(h.revisions[0].changes.servingG, 18); assert.equal(h.revisions[0].prev.servingG, 100);
assert.equal((await cat(env, { op: "edit", sig: a.record.sig, servingG: -5 }))[0], 422);
assert.equal((await cat(env, { op: "edit", sig: "GLC-NAO-EXISTE" }))[0], 404);
// edição de nutriente com valor inválido é recusada; válida cria nova versão
assert.equal((await cat(env, { op: "edit", sig: a.record.sig, per100: { carbs: 999 } }))[0], 422);
let [, e2] = await cat(env, { op: "edit", sig: a.record.sig, per100: { carbs: 56 } });
assert.equal(e2.record.version, 3); assert.equal(e2.record.per100.carbs, 56);

// 6) /catalog respeita o APP_TOKEN
{
  const envT = { ...mk(), APP_TOKEN: "tok" };
  assert.equal((await post(envT, "/catalog", { op: "history", sig: "x" })).status, 401);
  assert.equal((await post(envT, "/catalog", { op: "history", sig: "x" }, { "x-app-token": "tok" })).status, 200);
}

// 7) admin: sem token configurado/errado, estatísticas, verificar, política de fonte, chaves
assert.equal((await post({ DB: env.DB }, "/catalog/admin", { op: "stats" })).status, 403);
assert.equal((await post(env, "/catalog/admin", { op: "stats" }, { "x-admin-token": "errado" })).status, 401);
let [, s] = await adm(env, { op: "stats" });
assert.equal(s.total, 3); assert.equal(s.edited, 1); assert.equal(s.verified, 0);
assert.ok(s.policy.find((p) => p.source_key === "usda").can_publish === 1);
assert.ok(s.policy.find((p) => p.source_key === "foodbase").can_publish === 0);
assert.equal((await get(env, "/catalog/admin?token=" + ADMIN)).status, 200);   // estatísticas no navegador

// 8) API pública: sem chave/chave inválida => 401; nada aparece antes de verificar E liberar a fonte
assert.equal((await get(env, "/api/v1/foods?q=nutella")).status, 401);
assert.equal((await get(env, "/api/v1/foods?q=nutella", { "x-gluco-key": "gk_invalida" })).status, 401);
let [, k] = await adm(env, { op: "key_create", label: "parceiro teste", daily_limit: 9 });
assert.match(k.key, /^gk_[0-9a-f]{48}$/);
const H = { "x-gluco-key": k.key };
const q = async (path) => { const r = await get(env, path, H); return [r.status, await r.json()]; };
assert.equal((await q("/api/v1/foods?q=nutella"))[1].data.length, 0);          // não verificado
await adm(env, { op: "verify", sig: a.record.sig });
assert.equal((await q("/api/v1/foods?q=nutella"))[1].data.length, 0);          // verificado, mas fonte foodbase NÃO liberada
await adm(env, { op: "policy", source_key: "foodbase", can_publish: true, license: "Licença FoodBase (teste)" });
let [st2, r2] = await q("/api/v1/foods?q=nutel");
assert.equal(st2, 200); assert.equal(r2.data.length, 1);
assert.equal(r2.data[0].id, a.record.sig); assert.equal(r2.data[0].per_100g.carbohydrates_g, 56);
assert.equal(r2.data[0].serving.grams, 18); assert.equal(r2.data[0].source.license, "Licença FoodBase (teste)");
assert.ok(!("views" in r2.data[0]) && !("device" in r2.data[0]));               // nada interno vaza
let [st3, r3] = await q("/api/v1/foods/" + a.record.sig); assert.equal(st3, 200); assert.equal(r3.data.name, "Nutella");
[st3, r3] = await q("/api/v1/foods/barcode/3017620422003"); assert.equal(st3, 200); assert.equal(r3.data.id, a.record.sig);
assert.equal((await q("/api/v1/foods/barcode/9999999999999"))[0], 404);
assert.equal((await q("/api/v1/foods?q=n"))[0], 400);
// busca com caracteres especiais não quebra o SQL
assert.equal((await q("/api/v1/foods?q=" + encodeURIComponent("100%_\\")))[0], 200);

// 9) limite diário por chave (9): a 10ª chamada é barrada
let last; for (let i = 0; i < 3; i++) last = (await q("/api/v1/foods?q=nutella"))[0];
assert.equal(last, 429);

// 10) revogar chave
let [, k2] = await adm(env, { op: "key_create", label: "outro" });
await adm(env, { op: "key_revoke", id: 2 });
assert.equal((await get(env, "/api/v1/foods?q=nutella", { "x-gluco-key": k2.key })).status, 401);

console.log("catálogo: todos os testes passaram (SQLite real no lugar do D1)");
