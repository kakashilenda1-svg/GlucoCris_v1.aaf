// Teste local da rota /foodbase com FoodBase SIMULADA (não chama foodbase.dev de verdade).
// Os formatos simulados seguem o quickstart; nomes de campos além dos mostrados lá são hipóteses cobertas pelo normalizador.
import worker from "./worker.js";
import assert from "node:assert/strict";

const realFetch = globalThis.fetch;
let calls = [];
let mode = "ok";
const HITS = [
  { id: "id-nutella-0001", name_default: "Nutella", brand: "Ferrero", barcode: "3017620422003", category: "Sweet spreads" },
  { id: "id-pao-0002", name_default: "Pão de forma", brand: "Wickbold", barcode: "7891234567895", category: "Breads" },
  { id: "id-sem-nutr-0003", name_default: "Produto sem dados", brand: "", barcode: "123456789012", category: "x" },
];
globalThis.fetch = async (url, init = {}) => {
  const u = new URL(url);
  calls.push({ path: u.pathname + u.search, key: init.headers?.["X-API-Key"] });
  if (mode === "401") return new Response("{}", { status: 401 });
  if (mode === "500") return new Response("{}", { status: 500 });
  if (u.pathname === "/v1/foods/search") {
    const q = u.searchParams.get("q");
    if (q === "7891234567895") return new Response(JSON.stringify({ data: [HITS[1]], total: 1 }));
    if (q === "zzzz") return new Response(JSON.stringify({ data: [], total: 0 }));
    return new Response(JSON.stringify({ data: HITS, total: 611 }));
  }
  if (u.pathname.startsWith("/v1/foods/barcode/")) {
    const c = u.pathname.split("/").pop();
    if (c === "7891234567895") return new Response(JSON.stringify({ data: HITS[1] }));
    if (c === "3017620422003") return new Response(JSON.stringify(HITS[0]));
    return new Response("{}", { status: 404 });
  }
  if (u.pathname.endsWith("/nutrients")) {
    if (u.pathname.includes("id-nutella")) return new Response(JSON.stringify({ macros: { energy_kcal: 539, fat_g: 30.9, carbs_g: 57.5, sugars_g: 56.3, proteins_g: 6.3, saturated_fat_g: 10.6 }, minerals: { sodium_mg: 41 } }));
    if (u.pathname.includes("id-pao")) return new Response(JSON.stringify({ macros: { energy_kcal: 250, fat_g: 3, carbohydrates_g: 48, proteins_g: 8, fiber_g: 3.5 }, minerals: { sodium_mg: 480 } }));
    return new Response(JSON.stringify({ macros: {} }));
  }
  return new Response("{}", { status: 404 });
};

const kv = { m: new Map(), get: async (k) => kv.m.get(k) ?? null, put: async (k, v) => void kv.m.set(k, v) };
const env0 = { FOODBASE_API_KEY: "food_TESTE_123" };
const call = (body, env = env0, headers = {}) =>
  worker.fetch(new Request("https://p/foodbase", { method: "POST", headers, body: JSON.stringify(body) }), env);

// 1) busca: normaliza nutrientes dos que foram hidratados; sem dados => per100 null (nunca zero inventado)
let r = await call({ op: "search", q: "nutella", limit: 12, hydrate: 3 });
let j = await r.json();
assert.equal(r.status, 200);
assert.equal(j.total, 611);
assert.equal(j.items.length, 3);
assert.equal(j.items[0].name, "Nutella"); assert.equal(j.items[0].brand, "Ferrero");
assert.equal(j.items[0].per100.kcal, 539); assert.equal(j.items[0].per100.carbs, 57.5); assert.equal(j.items[0].per100.protein, 6.3);
assert.equal(j.items[0].per100.sodiumMg, 41); assert.equal(j.items[0].per100.sugars, 56.3);
assert.equal(j.items[1].per100.carbs, 48); assert.equal(j.items[1].per100.fiber, 3.5);
assert.equal(j.items[2].per100, null);
assert.ok(calls.every((c) => c.key === "food_TESTE_123"), "a chave vai no cabeçalho X-API-Key");

// 2) hydrate=0 => só 1 chamada (a busca); a chave nunca aparece na resposta
calls = [];
r = await call({ op: "search", q: "pao de forma", hydrate: 0 });
const txt = await r.text();
assert.equal(calls.length, 1); assert.ok(!txt.includes("food_TESTE_123"));

// 3) validações
assert.deepEqual(await (await call({ op: "search", q: "a" })).json(), { items: [], total: 0 });
assert.equal((await call({ op: "xyz" })).status, 400);
assert.equal((await call({ op: "search", q: "nutella" }, {})).status, 500);
assert.equal((await call({ op: "nutrients", id: "../../etc" })).status, 200); // id inválido: nem chama a FoodBase
assert.equal((await worker.fetch(new Request("https://p/foodbase"), env0)).status, 405);
assert.equal((await call({ op: "search", q: "nutella" }, { ...env0, APP_TOKEN: "t" })).status, 401);
assert.equal((await call({ op: "search", q: "nutella" }, { ...env0, APP_TOKEN: "t" }, { "x-app-token": "t" })).status, 200);

// 4) código de barras: usa GET /v1/foods/barcode/{código}; aceita resposta {data:{...}} ou o objeto direto
calls = [];
r = await call({ op: "barcode", code: "7891234567895" }); j = await r.json();
assert.equal(r.status, 200); assert.equal(j.item.name, "Pão de forma"); assert.equal(j.item.per100.carbs, 48);
assert.ok(calls[0].path.startsWith("/v1/foods/barcode/"));
j = await (await call({ op: "barcode", code: "3017620422003" })).json();
assert.equal(j.item.name, "Nutella"); assert.equal(j.item.per100.carbs, 57.5);
calls = [];
j = await (await call({ op: "barcode", code: "0000000000017" })).json();
assert.equal(j.item, null); assert.equal(calls.length, 2);   // 13 dígitos com 0 na frente: tenta sem o 0, sem gastar busca
assert.deepEqual(await (await call({ op: "barcode", code: "12" })).json(), { item: null });

// 5) erros da FoodBase
mode = "401"; assert.equal((await call({ op: "search", q: "arroz integral" })).status, 401);
mode = "500"; assert.equal((await call({ op: "search", q: "feijao preto" })).status, 502);
mode = "ok";

// 6) cota diária (KV): limite 2 => a 3ª chamada à FoodBase é bloqueada
calls = []; kv.m.clear();
const envQ = { ...env0, USAGE: kv, FOODBASE_DAILY_LIMIT: "2" };
r = await call({ op: "search", q: "granola mel", hydrate: 3 }, envQ); j = await r.json();
assert.equal(r.status, 200); assert.equal(calls.length, 2);           // busca + 1 nutriente; o resto foi bloqueado
assert.equal(j.items.filter((i) => i.per100).length, 1);
r = await call({ op: "search", q: "iogurte natural", hydrate: 3 }, envQ);
assert.equal(r.status, 429);

// 7) diagnóstico
calls = [];
r = await worker.fetch(new Request("https://p/foodbase/diag"), env0); j = await r.json();
assert.equal(r.status, 200); assert.equal(j.configured, true); assert.equal(j.nutrients.normalized.carbs, 57.5); assert.equal(j.barcode.status, 200);
assert.ok(!JSON.stringify(j).includes("food_TESTE_123"));
assert.equal((await worker.fetch(new Request("https://p/foodbase/diag"), { ...env0, APP_TOKEN: "t" })).status, 401);

// 8) rotas antigas continuam (Tavily/Gemini/FatSecret não afetadas pelo roteamento)
assert.equal((await worker.fetch(new Request("https://p/tavily", { method: "POST", body: "{}" }), {})).status, 500);
assert.equal((await worker.fetch(new Request("https://p/gemini", { method: "POST", body: "{}" }), {})).status, 500);
assert.equal((await worker.fetch(new Request("https://p/fatsecret", { method: "POST", body: "{}" }), {})).status, 500);
assert.equal((await worker.fetch(new Request("https://p/outra", { method: "POST", body: "{}" }), {})).status, 404);

console.log("foodbase: todos os testes passaram (com FoodBase simulada)");
globalThis.fetch = realFetch;
