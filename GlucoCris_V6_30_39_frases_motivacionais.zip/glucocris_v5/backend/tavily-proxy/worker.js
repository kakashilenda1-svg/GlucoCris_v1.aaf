// Proxy do Gluco Cris para Tavily Search API + Google Gemini API (Cloudflare Workers).
// Chaves ficam SOMENTE aqui como segredos. O app nunca as recebe.
//
// Rotas:
//   POST /          ou POST /tavily  → Tavily Search (contrato original, inalterado)
//   POST /gemini                     → proxy Gemini generateContent
//
// Tavily contrato (app -> proxy):
//   { query, depth: "basic"|"advanced", maxResults, topic: "general"|"news",
//     timeRange?: "day"|"week"|"month", health?: boolean }
//   Resposta: { results: [{title,url,content,score,published_date}], usage: { credits } }
//
// Gemini contrato (app -> proxy):
//   Body = exatamente o JSON que iria para generativelanguage.googleapis.com
//   (.../models/{model}:generateContent), SEM a chave.
//   Header opcional: x-gemini-model (padrão: gemini-3.8-flash)
//   Header: x-app-token (se APP_TOKEN configurado)
//   Resposta: o JSON bruto do Google (candidates, etc.) ou { error, status }
//
//   POST /foodbase                   → FoodBase (busca, código de barras, nutrientes). A chave FOODBASE_API_KEY fica só aqui.
//   POST /catalog                    → catálogo Gluco (op: upsert | edit | history), banco D1 binding "DB"
//   GET  /catalog/admin?token=...    → estatísticas do catálogo (CATALOG_ADMIN_TOKEN); POST = verify | policy | key_create | key_revoke
//   GET  /api/v1/foods...            → API pública (somente leitura, chave Gluco "gk_…" no cabeçalho X-Gluco-Key)
//   GET  /foodbase/diag?token=...    → diagnóstico (diz quais endpoints da FoodBase responderam; nunca mostra a chave)
//
// Segredos/vars:
//   FOODBASE_API_KEY (obrigatório para /foodbase) · FOODBASE_DAILY_LIMIT (padrão 90 chamadas/dia à FoodBase, precisa do KV USAGE)
//   TAVILY_API_KEY (obrigatório para /tavily) · GEMINI_API_KEY (obrigatório para /gemini)
//   APP_TOKEN (opcional) · MONTHLY_LIMIT · MONTHLY_RESERVE · USAGE (KV)
//   GEMINI_DAILY_LIMIT (padrão 2000 requisições/dia no worker, global)

const HEALTH_DOMAINS = [
  "*.gov.br", "who.int", "paho.org", "nih.gov", "pubmed.ncbi.nlm.nih.gov", "diabetes.org.br",
  "fiocruz.br", "cdc.gov", "diabetes.org", "idf.org", "scielo.br",
];
const COST = { basic: 1, advanced: 2 };

/** Modelos oficialmente permitidos (evitar abuso / modelos inexistentes). */
const ALLOWED_GEMINI_MODELS = new Set([
  "gemini-3.8-flash",
  "gemini-3.6-flash",
  "gemini-3.5-flash-lite",
  "gemini-3.1-flash-lite",
  "gemini-2.5-flash",
  "gemini-2.0-flash",
  "gemini-1.5-flash",
  "gemini-1.5-flash-8b",
]);

const MAX_GEMINI_BODY_BYTES = 8 * 1024 * 1024; // 8 MB (imagens/PDF base64)
const DEFAULT_GEMINI_MODEL = "gemini-3.8-flash";

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
    },
  });

const monthKey = () => "credits:" + new Date().toISOString().slice(0, 7);
const dayKey = () => "gemini:" + new Date().toISOString().slice(0, 10);

function pathOf(request) {
  try {
    const u = new URL(request.url);
    return (u.pathname || "/").replace(/\/+$/, "") || "/";
  } catch {
    return "/";
  }
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: {
          "access-control-allow-origin": "*",
          "access-control-allow-methods": "GET, POST, OPTIONS",
          "access-control-allow-headers": "content-type, x-app-token, x-gemini-model, x-gluco-key, authorization",
          "access-control-max-age": "86400",
        },
      });
    }
    if (request.method === "GET" && pathOf(request) === "/foodbase/diag") {
      return handleFoodBaseDiag(request, env);
    }
    // API pública do catálogo Gluco (somente leitura, exige chave Gluco): GET /api/v1/...
    if (request.method === "GET" && pathOf(request).startsWith("/api/v1")) {
      return handlePublicApi(request, env);
    }
    // Administração do catálogo (token próprio CATALOG_ADMIN_TOKEN, independente do APP_TOKEN)
    if (pathOf(request) === "/catalog/admin" && (request.method === "POST" || request.method === "GET")) {
      return handleCatalogAdmin(request, env);
    }
    if (request.method !== "POST") return json({ error: "method" }, 405);

    if (env.APP_TOKEN && request.headers.get("x-app-token") !== env.APP_TOKEN) {
      return json({ error: "unauthorized" }, 401);
    }

    const path = pathOf(request);

    if (path === "/gemini") {
      return handleGemini(request, env);
    }
    // Tavily: raiz ou /tavily (compatível com o app atual que posta na raiz)
    if (path === "/" || path === "/tavily") {
      return handleTavily(request, env);
    }
    // FoodBase: busca, código de barras e nutrientes (chave fica só no servidor)
    if (path === "/foodbase") {
      return handleFoodBase(request, env);
    }
    // Catálogo Gluco: o app registra/atualiza os produtos que o usuário abre (D1, binding "DB")
    if (path === "/catalog") {
      return handleCatalog(request, env);
    }
    // FatSecret: busca de alimentos (chave fica so no servidor)
    if (path === "/fatsecret") {
      return handleFatSecret(request, env);
    }
    return json({ error: "not_found", path }, 404);
  },
};

// ─── Tavily (comportamento original, sem alterações de contrato) ─────────────

async function handleTavily(request, env) {
  if (!env.TAVILY_API_KEY) return json({ error: "not_configured" }, 500);

  let b;
  try {
    b = await request.json();
  } catch {
    return json({ error: "bad_json" }, 400);
  }
  const query = typeof b.query === "string" ? b.query.trim().slice(0, 200) : "";
  if (query.length < 2) return json({ error: "bad_query" }, 400);

  const depth = b.depth === "advanced" ? "advanced" : "basic";
  const topic = b.topic === "news" ? "news" : "general";
  const maxResults = Math.min(Math.max(parseInt(b.maxResults, 10) || 5, 1), 6);
  const timeRange = ["day", "week", "month"].includes(b.timeRange) ? b.timeRange : null;
  const cost = COST[depth];

  const limit = parseInt(env.MONTHLY_LIMIT || "1000", 10) - parseInt(env.MONTHLY_RESERVE || "50", 10);
  let used = 0;
  if (env.USAGE) {
    used = parseInt((await env.USAGE.get(monthKey())) || "0", 10);
    if (used + cost > limit) return json({ error: "quota" }, 429);
  }

  const payload = {
    query,
    search_depth: depth,
    max_results: maxResults,
    topic,
    language: "pt",
    include_answer: false,
    include_raw_content: false,
    include_images: false,
    include_favicon: false,
    include_usage: true,
    chunks_per_source: 1,
  };
  if (topic === "general") payload.country = "brazil";
  if (timeRange) payload.time_range = timeRange;
  if (b.health === true) {
    payload.include_domains = HEALTH_DOMAINS;
    payload.include_domains_mode = "prefer";
  }

  let r;
  try {
    r = await fetch("https://api.tavily.com/search", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: "Bearer " + env.TAVILY_API_KEY,
      },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(20000),
    });
  } catch {
    return json({ error: "upstream_unreachable" }, 504);
  }

  if (!r.ok) {
    return json(
      { error: "upstream", status: r.status },
      r.status === 401 ? 401 : r.status === 429 || r.status === 432 || r.status === 433 ? 429 : 502,
    );
  }

  const data = await r.json().catch(() => ({}));
  const credits = Number.isInteger(data?.usage?.credits) ? data.usage.credits : cost;
  if (env.USAGE) {
    await env.USAGE.put(monthKey(), String(used + credits), { expirationTtl: 60 * 60 * 24 * 62 });
  }

  const results = (Array.isArray(data.results) ? data.results : []).slice(0, maxResults).map((x) => ({
    title: x.title,
    url: x.url,
    content: x.content,
    score: x.score,
    published_date: x.published_date ?? null,
  }));
  return json({ results, usage: { credits } });
}

// ─── Gemini ──────────────────────────────────────────────────────────────────

async function handleGemini(request, env) {
  if (!env.GEMINI_API_KEY) return json({ error: "gemini_not_configured" }, 500);

  // Limite de tamanho do corpo (proteção contra abuso / OOM)
  const cl = request.headers.get("content-length");
  if (cl && parseInt(cl, 10) > MAX_GEMINI_BODY_BYTES) {
    return json({ error: "body_too_large", max: MAX_GEMINI_BODY_BYTES }, 413);
  }

  let bodyText;
  try {
    bodyText = await request.text();
  } catch {
    return json({ error: "bad_body" }, 400);
  }
  if (!bodyText || bodyText.length < 2) return json({ error: "empty_body" }, 400);
  if (bodyText.length > MAX_GEMINI_BODY_BYTES) {
    return json({ error: "body_too_large", max: MAX_GEMINI_BODY_BYTES }, 413);
  }

  let parsed;
  try {
    parsed = JSON.parse(bodyText);
  } catch {
    return json({ error: "bad_json" }, 400);
  }
  if (!parsed || typeof parsed !== "object" || !Array.isArray(parsed.contents)) {
    return json({ error: "invalid_gemini_payload" }, 400);
  }

  // Modelo: header x-gemini-model ou padrão; só lista branca
  let model = (request.headers.get("x-gemini-model") || DEFAULT_GEMINI_MODEL).trim();
  if (!ALLOWED_GEMINI_MODELS.has(model)) {
    model = DEFAULT_GEMINI_MODEL;
  }

  // Cota diária global opcional (KV)
  const dailyLimit = parseInt(env.GEMINI_DAILY_LIMIT || "2000", 10);
  if (env.USAGE && dailyLimit > 0) {
    const used = parseInt((await env.USAGE.get(dayKey())) || "0", 10);
    if (used >= dailyLimit) return json({ error: "gemini_quota" }, 429);
  }

  const url =
    "https://generativelanguage.googleapis.com/v1beta/models/" +
    encodeURIComponent(model) +
    ":generateContent";

  // Autenticação: chave como query (compatível com chaves AIza... e formatos novos AQ...)
  const target = url + "?key=" + encodeURIComponent(env.GEMINI_API_KEY);

  let r;
  try {
    r = await fetch(target, {
      method: "POST",
      headers: {
        "content-type": "application/json; charset=utf-8",
      },
      body: bodyText,
      signal: AbortSignal.timeout(90000),
    });
  } catch {
    return json({ error: "upstream_unreachable" }, 504);
  }

  // Contabiliza só respostas bem-sucedidas ou 429 (já consumiu cota do Google)
  if (env.USAGE && (r.ok || r.status === 429)) {
    const used = parseInt((await env.USAGE.get(dayKey())) || "0", 10);
    await env.USAGE.put(dayKey(), String(used + 1), { expirationTtl: 60 * 60 * 48 });
  }

  const raw = await r.text();
  // Repassa status e corpo do Google (app faz o parse). Não loga conteúdo.
  return new Response(raw, {
    status: r.status,
    headers: {
      "content-type": r.headers.get("content-type") || "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-gemini-model-used": model,
    },
  });
}


// ─── FatSecret (busca de alimentos) ──────────────────────────────────────────
// Segredos no Cloudflare: FATSECRET_CLIENT_ID e FATSECRET_CLIENT_SECRET.
// Corpo esperado: { "query": "arroz" }  ->  { "items": [ ... ] }

let fsToken = null; // cache em memoria do isolate
let fsTokenExp = 0;

async function fatSecretToken(env) {
  const now = Date.now();
  if (fsToken && now < fsTokenExp - 60000) return fsToken;
  const basic = btoa(env.FATSECRET_CLIENT_ID + ":" + env.FATSECRET_CLIENT_SECRET);
  const r = await fetch("https://oauth.fatsecret.com/connect/token", {
    method: "POST",
    headers: {
      authorization: "Basic " + basic,
      "content-type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials&scope=basic",
  });
  if (!r.ok) throw new Error("token_" + r.status);
  const j = await r.json();
  fsToken = j.access_token;
  fsTokenExp = now + (j.expires_in || 3600) * 1000;
  return fsToken;
}

// "Per 100g - Calories: 52kcal | Fat: 0.17g | Carbs: 13.81g | Protein: 0.26g"
function parseFatSecretDescription(d) {
  const num = (re) => {
    const m = re.exec(d || "");
    return m ? parseFloat(m[1].replace(",", ".")) : 0;
  };
  const per = /^\s*(?:Per|Por)\s+([^-]+?)\s*-/i.exec(d || "");
  const serving = per ? per[1].trim() : "100g";
  const g = /(\d+(?:[.,]\d+)?)\s*g\b/i.exec(serving);
  return {
    serving,
    grams: g ? parseFloat(g[1].replace(",", ".")) : 100,
    kcal: num(/Calories:\s*([\d.,]+)/i) || num(/Calorias:\s*([\d.,]+)/i),
    fat: num(/Fat:\s*([\d.,]+)/i) || num(/Gord[^:]*:\s*([\d.,]+)/i),
    carbs: num(/Carbs:\s*([\d.,]+)/i) || num(/Carb[^:]*:\s*([\d.,]+)/i),
    protein: num(/Protein:\s*([\d.,]+)/i) || num(/Prote[^:]*:\s*([\d.,]+)/i),
  };
}

// OAuth 1.0 (sem restricao de IP): usado quando FATSECRET_CONSUMER_KEY/SECRET existem.
const rfc3986 = (v) =>
  encodeURIComponent(String(v)).replace(/[!'()*]/g, (c) => "%" + c.charCodeAt(0).toString(16).toUpperCase());

async function fatSecretOAuth1Search(env, query) {
  const url = "https://platform.fatsecret.com/rest/server.api";
  const params = {
    method: "foods.search",
    search_expression: query,
    format: "json",
    max_results: "20",
    oauth_consumer_key: env.FATSECRET_CONSUMER_KEY,
    oauth_nonce: crypto.randomUUID().replace(/-/g, ""),
    oauth_signature_method: "HMAC-SHA1",
    oauth_timestamp: String(Math.floor(Date.now() / 1000)),
    oauth_version: "1.0",
  };
  const norm = Object.keys(params)
    .sort()
    .map((k) => rfc3986(k) + "=" + rfc3986(params[k]))
    .join("&");
  const base = "GET&" + rfc3986(url) + "&" + rfc3986(norm);
  const keyData = new TextEncoder().encode(rfc3986(env.FATSECRET_CONSUMER_SECRET) + "&");
  const key = await crypto.subtle.importKey("raw", keyData, { name: "HMAC", hash: "SHA-1" }, false, ["sign"]);
  const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(base));
  const sigB64 = btoa(String.fromCharCode(...new Uint8Array(sig)));
  return fetch(url + "?" + norm + "&oauth_signature=" + rfc3986(sigB64));
}

async function handleFatSecret(request, env) {
  const useOAuth1 = !!(env.FATSECRET_CONSUMER_KEY && env.FATSECRET_CONSUMER_SECRET);
  if (!useOAuth1 && !(env.FATSECRET_CLIENT_ID && env.FATSECRET_CLIENT_SECRET)) {
    return json({ error: "fatsecret_not_configured" }, 500);
  }
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "bad_json" }, 400);
  }
  const query = String((body && body.query) || "").trim().slice(0, 100);
  if (!query) return json({ items: [] });

  try {
    let r;
    if (useOAuth1) {
      r = await fatSecretOAuth1Search(env, query);
    } else {
      const token = await fatSecretToken(env);
      const params = new URLSearchParams({
        search_expression: query,
        format: "json",
        max_results: "20",
      });
      r = await fetch("https://platform.fatsecret.com/rest/foods/search/v1?" + params, {
        headers: { authorization: "Bearer " + token },
      });
    }
    const text = await r.text();
    if (!r.ok) return json({ error: "fatsecret_http_" + r.status, detail: text.slice(0, 300) }, 502);
    const j = JSON.parse(text);
    if (j.error) return json({ error: "fatsecret_api", detail: j.error }, 502);
    let foods = (j.foods && j.foods.food) || [];
    if (!Array.isArray(foods)) foods = [foods]; // 1 resultado vem como objeto
    const items = foods.map((f) => {
      const n = parseFatSecretDescription(f.food_description);
      return {
        id: String(f.food_id),
        name: f.food_name || "",
        brand: f.brand_name || "",
        generic: f.food_type === "Generic",
        ...n,
      };
    }).filter((x) => x.name && (x.kcal > 0 || x.carbs > 0));
    return json({ items });
  } catch (e) {
    return json({ error: "fatsecret_failed", detail: String(e && e.message || e).slice(0, 200) }, 502);
  }
}


// ─── FoodBase (https://foodbase.dev, API REST /v1, chave no cabeçalho X-API-Key) ─────────────────────────────────
// Segredo no Cloudflare: FOODBASE_API_KEY.
// Contrato app -> proxy (POST /foodbase, JSON):
//   { op: "search",    q: "arroz", limit?: 12, hydrate?: 3 }  -> { items: [Item], total }
//   { op: "barcode",   code: "7891000100103" }                 -> { item: Item | null }
//   { op: "nutrients", id: "<uuid>" }                          -> { per100: Per100 | null }
//   Item   = { id, name, brand, barcode, category, per100: Per100 | null }
//   Per100 = { kcal, carbs, protein, fat, fiber, sugars, satFat, sodiumMg }  (por 100 g, só campos que a FoodBase trouxe)
// Regras de segurança do app: item sem nutrientes (per100 = null) NUNCA vira alimento com carboidrato zero.
// Para poupar a cota (plano grátis: 100 req/dia; 25 detalhamentos de nutrientes/dia): resultados ficam em cache
// no Cloudflare (busca 24 h, nutrientes 30 dias) e só os primeiros "hydrate" resultados recebem nutrientes.

const FB_BASE = "https://foodbase.dev/v1";
const FB_SEARCH_TTL = 60 * 60 * 24;
const FB_NUTR_TTL = 60 * 60 * 24 * 30;
const fbDayKey = () => "foodbase:" + new Date().toISOString().slice(0, 10);

/** Cache de respostas da FoodBase (Cache API do Cloudflare; sem binding). Silencioso se indisponível. */
async function fbCacheGet(key) {
  try {
    if (typeof caches === "undefined" || !caches.default) return null;
    const hit = await caches.default.match(new Request("https://fb-cache.invalid/" + key));
    return hit ? await hit.json() : null;
  } catch {
    return null;
  }
}
async function fbCachePut(key, value, ttl) {
  try {
    if (typeof caches === "undefined" || !caches.default) return;
    await caches.default.put(
      new Request("https://fb-cache.invalid/" + key),
      new Response(JSON.stringify(value), {
        headers: { "content-type": "application/json", "cache-control": "public, max-age=" + ttl },
      }),
    );
  } catch {
    /* sem cache: segue sem */
  }
}

/** Quantas chamadas ainda cabem hoje (Infinity se não houver KV/limite). Evita estourar a cota na hidratação em paralelo. */
async function fbRemaining(env) {
  const limit = parseInt(env.FOODBASE_DAILY_LIMIT || "90", 10);
  if (!env.USAGE || !(limit > 0)) return Infinity;
  const used = parseInt((await env.USAGE.get(fbDayKey())) || "0", 10);
  return Math.max(0, limit - used);
}

/** Uma chamada à FoodBase. Conta na cota diária (se houver KV). Devolve { status, data }. */
async function fbCall(env, path, init = {}) {
  const limit = parseInt(env.FOODBASE_DAILY_LIMIT || "90", 10);
  if (env.USAGE && limit > 0) {
    const used = parseInt((await env.USAGE.get(fbDayKey())) || "0", 10);
    if (used >= limit) return { status: 429, data: null, quota: true };
    await env.USAGE.put(fbDayKey(), String(used + 1), { expirationTtl: 60 * 60 * 48 });
  }
  let r;
  try {
    r = await fetch(FB_BASE + path, {
      method: init.method || "GET",
      headers: { "X-API-Key": env.FOODBASE_API_KEY, accept: "application/json", ...(init.headers || {}) },
      body: init.body,
      signal: AbortSignal.timeout(init.timeoutMs || 6000),
    });
  } catch {
    return { status: 504, data: null };
  }
  let data = null;
  try {
    data = await r.json();
  } catch {
    data = null;
  }
  return { status: r.status, data };
}

const fbNum = (v) => {
  const n = typeof v === "string" ? parseFloat(v.replace(",", ".")) : v;
  return typeof n === "number" && isFinite(n) && n >= 0 ? n : null;
};

/** Procura um campo numérico por vários nomes possíveis, em qualquer nível do JSON (a documentação mostra só um trecho). */
function fbPick(obj, names, depth = 0) {
  if (!obj || typeof obj !== "object" || depth > 4) return null;
  for (const n of names) {
    if (Object.prototype.hasOwnProperty.call(obj, n)) {
      const v = fbNum(obj[n]);
      if (v !== null) return v;
      if (obj[n] && typeof obj[n] === "object") {
        const inner = fbNum(obj[n].value ?? obj[n].amount ?? obj[n].per_100g);
        if (inner !== null) return inner;
      }
    }
  }
  for (const k of Object.keys(obj)) {
    if (obj[k] && typeof obj[k] === "object") {
      const v = fbPick(obj[k], names, depth + 1);
      if (v !== null) return v;
    }
  }
  return null;
}

/** Normaliza o JSON de nutrientes da FoodBase para por-100 g. Devolve null se não houver energia nem carboidrato. */
function fbNormalizeNutrients(data) {
  if (!data || typeof data !== "object") return null;
  const kcal = fbPick(data, ["energy_kcal", "kcal", "calories_kcal", "calories", "energy-kcal"]);
  const carbs = fbPick(data, ["carbs_g", "carbohydrates_g", "carbohydrate_g", "carbs", "carbohydrates", "total_carbohydrate_g"]);
  const protein = fbPick(data, ["proteins_g", "protein_g", "proteins", "protein"]);
  const fat = fbPick(data, ["fat_g", "total_fat_g", "fat"]);
  if (kcal === null && carbs === null) return null;
  const sodiumMg = fbPick(data, ["sodium_mg"]);
  const sodiumG = fbPick(data, ["sodium_g"]);
  const saltG = fbPick(data, ["salt_g"]);
  const out = {
    kcal: kcal ?? 0,
    carbs: carbs ?? 0,
    protein: protein ?? 0,
    fat: fat ?? 0,
  };
  const fiber = fbPick(data, ["fiber_g", "fibre_g", "dietary_fiber_g", "fiber"]);
  const sugars = fbPick(data, ["sugars_g", "sugar_g", "sugars"]);
  const sat = fbPick(data, ["saturated_fat_g", "sat_fat_g", "saturated_fat", "saturates_g"]);
  if (fiber !== null) out.fiber = fiber;
  if (sugars !== null) out.sugars = sugars;
  if (sat !== null) out.satFat = sat;
  if (sodiumMg !== null) out.sodiumMg = sodiumMg;
  else if (sodiumG !== null) out.sodiumMg = sodiumG * 1000;
  else if (saltG !== null) out.sodiumMg = (saltG / 2.5) * 1000;
  out.hasCarbs = carbs !== null;
  return out;
}

function fbItem(raw, per100) {
  const name = String(raw?.name_default || raw?.name || raw?.product_name || "").trim();
  return {
    id: String(raw?.id ?? ""),
    name,
    brand: String(raw?.brand || raw?.brands || "").trim(),
    barcode: String(raw?.barcode || raw?.code || "").trim(),
    category: String(raw?.category || "").trim(),
    per100: per100 || null,
  };
}

/** Nutrientes de um id (com cache de 30 dias). */
async function fbNutrients(env, id) {
  if (!/^[A-Za-z0-9_-]{6,64}$/.test(id)) return { per100: null, status: 400 };
  const ck = "n-" + id;
  const cached = await fbCacheGet(ck);
  if (cached && typeof cached === "object" && "per100" in cached) return { per100: cached.per100, status: 200, cached: true };
  const r = await fbCall(env, "/foods/" + encodeURIComponent(id) + "/nutrients");
  if (r.status !== 200) return { per100: null, status: r.status, quota: !!r.quota };
  const per100 = fbNormalizeNutrients(r.data);
  await fbCachePut(ck, { per100 }, FB_NUTR_TTL);
  return { per100, status: 200 };
}

async function handleFoodBase(request, env) {
  if (!env.FOODBASE_API_KEY) return json({ error: "foodbase_not_configured" }, 500);
  let b;
  try {
    b = await request.json();
  } catch {
    return json({ error: "bad_json" }, 400);
  }
  const op = b && typeof b.op === "string" ? b.op : "";

  if (op === "search") {
    const q = typeof b.q === "string" ? b.q.trim().slice(0, 100) : "";
    if (q.length < 2) return json({ items: [], total: 0 });
    const limit = Math.min(Math.max(parseInt(b.limit, 10) || 12, 1), 20);
    const hy = parseInt(b.hydrate, 10);
    const hydrate = Math.min(Math.max(Number.isNaN(hy) ? 3 : hy, 0), 6);
    const sk = "s-" + q.toLowerCase() + "|" + limit + "|" + hydrate;
    const hit = await fbCacheGet(sk);
    if (hit && Array.isArray(hit.items)) return json(hit);

    const r = await fbCall(env, "/foods/search?q=" + encodeURIComponent(q) + "&limit=" + limit);
    if (r.status === 429) return json({ error: "quota" }, 429);
    if (r.status === 401 || r.status === 403) return json({ error: "invalid_key" }, 401);
    if (r.status !== 200) return json({ error: "upstream", status: r.status }, 502);
    const rows = Array.isArray(r.data?.data) ? r.data.data : [];
    const items = rows.slice(0, limit).map((x) => {
      // se a busca já trouxer nutrientes, aproveita (zero chamadas extras)
      const inline = fbNormalizeNutrients(x?.nutrients || x?.nutrition || x);
      return fbItem(x, inline);
    });
    // Nutrientes só dos primeiros "hydrate" que ainda não têm (em paralelo)
    const room = await fbRemaining(env);
    const todo = items.filter((it) => it.id && !it.per100).slice(0, Math.min(hydrate, room));
    await Promise.all(
      todo.map(async (it) => {
        const n = await fbNutrients(env, it.id);
        if (n.per100) it.per100 = n.per100;
      }),
    );
    const out = { items: items.filter((it) => it.id && it.name), total: Number(r.data?.total) || items.length };
    // só guarda em cache se houve pelo menos um resultado com nutrientes (evita cachear falha de cota)
    if (out.items.some((it) => it.per100)) await fbCachePut(sk, out, FB_SEARCH_TTL);
    return json(out);
  }

  if (op === "barcode") {
    const code = typeof b.code === "string" ? b.code.replace(/\D/g, "") : "";
    if (code.length < 8 || code.length > 14) return json({ item: null });
    const bk = "b-" + code;
    const hit = await fbCacheGet(bk);
    if (hit && "item" in hit) return json(hit);

    // Caminho confirmado no diagnóstico real: GET /v1/foods/barcode/{código} (200 quando existe).
    const variants = [code];
    if (code.length === 12) variants.push("0" + code);
    if (code.length === 13 && code.startsWith("0")) variants.push(code.slice(1));
    let raw = null;
    let quota = false;
    for (const v of variants) {
      const r = await fbCall(env, "/foods/barcode/" + v);
      if (r.status === 429) { quota = true; break; }
      if (r.status === 200 && r.data && typeof r.data === "object") {
        const d = r.data;
        const cand = [d.data, d.food, d.product, d.item, d].find((x) => x && typeof x === "object" && !Array.isArray(x) && x.id);
        if (cand) { raw = cand; break; }
      }
    }
    if (quota) return json({ error: "quota" }, 429);
    if (!raw) {
      await fbCachePut(bk, { item: null }, 60 * 60 * 6);
      return json({ item: null });
    }
    let item = fbItem(raw, fbNormalizeNutrients(raw?.nutrients || raw?.nutrition || null));
    if (!item.per100 && item.id) {
      const n = await fbNutrients(env, item.id);
      if (n.per100) item.per100 = n.per100;
    }
    if (!item.barcode) item.barcode = code;
    const out = { item: item.name ? item : null };
    if (out.item && out.item.per100) await fbCachePut(bk, out, FB_NUTR_TTL);
    return json(out);
  }

  if (op === "nutrients") {
    const id = typeof b.id === "string" ? b.id.trim() : "";
    const n = await fbNutrients(env, id);
    if (n.quota) return json({ error: "quota" }, 429);
    return json({ per100: n.per100 });
  }

  return json({ error: "bad_op" }, 400);
}

/** Diagnóstico: GET /foodbase/diag?token=APP_TOKEN (token só se APP_TOKEN estiver configurado). Não mostra a chave. */
async function handleFoodBaseDiag(request, env) {
  const u = new URL(request.url);
  if (env.APP_TOKEN && u.searchParams.get("token") !== env.APP_TOKEN) return json({ error: "unauthorized" }, 401);
  if (!env.FOODBASE_API_KEY) return json({ configured: false, hint: "Cadastre o segredo FOODBASE_API_KEY no Cloudflare." });
  const out = { configured: true, keyPrefix: String(env.FOODBASE_API_KEY).slice(0, 5) + "…" };
  const s = await fbCall(env, "/foods/search?q=nutella&limit=1");
  out.search = { status: s.status, sampleKeys: s.data?.data?.[0] ? Object.keys(s.data.data[0]) : [], total: s.data?.total ?? null };
  const id = s.data?.data?.[0]?.id;
  if (id) {
    const n = await fbCall(env, "/foods/" + encodeURIComponent(id) + "/nutrients");
    out.nutrients = {
      status: n.status,
      topKeys: n.data && typeof n.data === "object" ? Object.keys(n.data) : [],
      macroKeys: n.data?.macros ? Object.keys(n.data.macros) : [],
      normalized: fbNormalizeNutrients(n.data),
    };
  }
  const bc = s.data?.data?.[0]?.barcode;
  if (bc) {
    const r = await fbCall(env, "/foods/barcode/" + bc);
    out.barcode = {
      status: r.status,
      topKeys: r.data && typeof r.data === "object" ? Object.keys(r.data) : [],
      itemKeys: r.data?.data && typeof r.data.data === "object" ? Object.keys(r.data.data) : [],
    };
  }
  return json(out);
}


// ─── Catálogo Gluco (Cloudflare D1, binding "DB") ────────────────────────────────────────────────────────────────
// Cada produto tem uma assinatura única "GLC-…" calculada AQUI (servidor):
//   com código de barras → mesma assinatura em qualquer fonte (o mesmo produto nunca duplica);
//   sem código de barras  → fonte + id da fonte; sem id → nome + marca normalizados.
// Valores sempre por 100 g. Edições do usuário criam uma nova versão (histórico em food_revisions, nada se perde).
// Só aparece na API pública o que estiver "verified = 1" E cuja FONTE esteja liberada em source_policy (can_publish = 1).
// Dados pessoais NUNCA entram: o app não envia "Meus alimentos", nem o que cada pessoa pesquisa; só dados do produto.

const CAT_SCHEMA = [
  `CREATE TABLE IF NOT EXISTS foods (
    sig TEXT PRIMARY KEY, barcode TEXT, name TEXT NOT NULL, name_norm TEXT NOT NULL,
    brand TEXT NOT NULL DEFAULT '', category TEXT NOT NULL DEFAULT '',
    serving TEXT NOT NULL DEFAULT '100 g', serving_g REAL NOT NULL DEFAULT 100,
    kcal REAL, carbs REAL, protein REAL, fat REAL, fiber REAL, sugars REAL, sat_fat REAL, sodium_mg REAL,
    source_key TEXT NOT NULL, source_id TEXT NOT NULL DEFAULT '',
    verified INTEGER NOT NULL DEFAULT 0, edited INTEGER NOT NULL DEFAULT 0,
    version INTEGER NOT NULL DEFAULT 1, views INTEGER NOT NULL DEFAULT 1,
    created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS idx_foods_barcode ON foods(barcode)`,
  `CREATE INDEX IF NOT EXISTS idx_foods_name ON foods(name_norm)`,
  `CREATE TABLE IF NOT EXISTS food_revisions (
    id INTEGER PRIMARY KEY AUTOINCREMENT, sig TEXT NOT NULL, version INTEGER NOT NULL,
    changes TEXT NOT NULL, prev TEXT NOT NULL, device TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL)`,
  `CREATE INDEX IF NOT EXISTS idx_rev_sig ON food_revisions(sig)`,
  `CREATE TABLE IF NOT EXISTS source_policy (
    source_key TEXT PRIMARY KEY, license TEXT NOT NULL, can_publish INTEGER NOT NULL DEFAULT 0)`,
  `CREATE TABLE IF NOT EXISTS api_keys (
    id INTEGER PRIMARY KEY AUTOINCREMENT, key_hash TEXT NOT NULL UNIQUE, label TEXT NOT NULL,
    daily_limit INTEGER NOT NULL DEFAULT 1000, revoked INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL)`,
  `CREATE TABLE IF NOT EXISTS api_usage (
    key_id INTEGER NOT NULL, day TEXT NOT NULL, count INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (key_id, day))`,
  `INSERT OR IGNORE INTO source_policy (source_key, license, can_publish) VALUES
    ('usda', 'USDA FoodData Central — domínio público (citar o USDA)', 1),
    ('off', 'Open Food Facts — ODbL (atribuir e manter a mesma licença na base derivada)', 0),
    ('foodbase', 'FoodBase — termos de redistribuição não verificados', 0),
    ('fatsecret', 'FatSecret — termos de redistribuição não verificados', 0),
    ('taco', 'TACO (NEPA/UNICAMP) — termos de redistribuição não verificados', 0),
    ('local', 'Tabelas internas do Gluco — origem a confirmar', 0),
    ('restaurant_official', 'Tabelas oficiais de restaurantes — origem a confirmar', 0),
    ('restaurant_estimate', 'Estimativas — origem a confirmar', 0)`,
];
const CAT_SOURCES = ["off", "usda", "taco", "foodbase", "fatsecret", "local", "restaurant_official", "restaurant_estimate"];
const catReady = new WeakMap();

async function catDb(env) {
  if (!env.DB) return null;
  let p = catReady.get(env.DB);
  if (!p) {
    p = env.DB.batch(CAT_SCHEMA.map((q) => env.DB.prepare(q))).catch((e) => {
      catReady.delete(env.DB);
      throw e;
    });
    catReady.set(env.DB, p);
  }
  await p;
  return env.DB;
}

const catNorm = (t) =>
  String(t || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, " ")
    .trim();

async function sha256Hex(text) {
  const buf = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text));
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, "0")).join("");
}

/** GTIN-14: EAN-13 e UPC-A do mesmo produto viram o mesmo número. */
const catGtin = (code) => {
  const d = String(code || "").replace(/\D/g, "");
  return d.length >= 8 && d.length <= 14 ? d.padStart(14, "0") : "";
};

async function catSignature({ barcode, sourceKey, sourceId, name, brand }) {
  const g = catGtin(barcode);
  let basis;
  if (g) basis = "b:" + g;
  else if (sourceId) basis = "s:" + sourceKey + ":" + sourceId;
  else basis = "n:" + catNorm(name) + "|" + catNorm(brand);
  const h = (await sha256Hex(basis)).slice(0, 20).toUpperCase();
  return "GLC-" + h.slice(0, 5) + "-" + h.slice(5, 10) + "-" + h.slice(10, 15) + "-" + h.slice(15, 20);
}

const catNum = (v, max) => {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "string" ? parseFloat(v.replace(",", ".")) : v;
  if (typeof n !== "number" || !isFinite(n) || n < 0 || n > max) return undefined; // undefined = inválido
  return Math.round(n * 1000) / 1000;
};
const CAT_LIMITS = { kcal: 1000, carbs: 100, protein: 100, fat: 100, fiber: 100, sugars: 100, satFat: 100, sodiumMg: 40000 };
const CAT_COLS = { kcal: "kcal", carbs: "carbs", protein: "protein", fat: "fat", fiber: "fiber", sugars: "sugars", satFat: "sat_fat", sodiumMg: "sodium_mg" };

/** Valida os valores por 100 g; devolve { ok, values } ou { ok:false }. */
function catPer100(p) {
  const out = {};
  for (const k of Object.keys(CAT_LIMITS)) {
    if (p && Object.prototype.hasOwnProperty.call(p, k)) {
      const n = catNum(p[k], CAT_LIMITS[k]);
      if (n === undefined) return { ok: false };
      out[k] = n;
    }
  }
  return { ok: true, values: out };
}

function catRecord(r) {
  return {
    sig: r.sig,
    barcode: r.barcode || "",
    name: r.name,
    brand: r.brand,
    category: r.category,
    serving: r.serving,
    servingG: r.serving_g,
    per100: {
      kcal: r.kcal, carbs: r.carbs, protein: r.protein, fat: r.fat,
      fiber: r.fiber, sugars: r.sugars, satFat: r.sat_fat, sodiumMg: r.sodium_mg,
    },
    sourceKey: r.source_key,
    verified: !!r.verified,
    edited: !!r.edited,
    version: r.version,
    views: r.views,
  };
}

async function handleCatalog(request, env) {
  let db;
  try {
    db = await catDb(env);
  } catch {
    return json({ error: "catalog_init_failed" }, 503);
  }
  if (!db) return json({ error: "catalog_not_configured" }, 503);
  let b;
  try {
    b = await request.json();
  } catch {
    return json({ error: "bad_json" }, 400);
  }
  const op = b && typeof b.op === "string" ? b.op : "";
  const now = Date.now();

  if (op === "upsert") {
    const f = b.food || {};
    const name = typeof f.name === "string" ? f.name.trim().slice(0, 160) : "";
    const sourceKey = typeof f.sourceKey === "string" ? f.sourceKey : "";
    if (!name || !CAT_SOURCES.includes(sourceKey)) return json({ error: "not_accepted" }, 422);
    const brand = typeof f.brand === "string" ? f.brand.trim().slice(0, 100) : "";
    const sourceId = typeof f.sourceId === "string" ? f.sourceId.trim().slice(0, 120) : "";
    const barcode = catGtin(f.barcode) ? String(f.barcode).replace(/\D/g, "") : "";
    const per = catPer100(f.per100);
    if (!per.ok) return json({ error: "bad_values" }, 422);
    const v = per.values;
    if (v.carbs === undefined && v.kcal === undefined) return json({ error: "no_nutrients" }, 422);
    const sig = await catSignature({ barcode, sourceKey, sourceId, name, brand });

    const cur = await db.prepare("SELECT * FROM foods WHERE sig = ?").bind(sig).first();
    if (cur) {
      // já existe: conta a visita e só preenche o que estava vazio (nunca sobrescreve valores nem edições)
      const fills = [];
      const vals = [];
      for (const [k, col] of Object.entries(CAT_COLS)) {
        if (cur[col] === null && v[k] !== undefined) { fills.push(col + " = ?"); vals.push(v[k]); }
      }
      if (!cur.barcode && barcode) { fills.push("barcode = ?"); vals.push(barcode); }
      const sql = "UPDATE foods SET views = views + 1, updated_at = ?" + (fills.length ? ", " + fills.join(", ") : "") + " WHERE sig = ?";
      await db.prepare(sql).bind(now, ...vals, sig).run();
      const row = await db.prepare("SELECT * FROM foods WHERE sig = ?").bind(sig).first();
      return json({ created: false, record: catRecord(row) });
    }
    const servingG = catNum(f.servingG, 5000);
    await db
      .prepare(
        `INSERT INTO foods (sig, barcode, name, name_norm, brand, category, serving, serving_g,
           kcal, carbs, protein, fat, fiber, sugars, sat_fat, sodium_mg, source_key, source_id, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        sig, barcode || null, name, catNorm(name), brand,
        typeof f.category === "string" ? f.category.trim().slice(0, 80) : "",
        typeof f.serving === "string" && f.serving.trim() ? f.serving.trim().slice(0, 60) : "100 g",
        servingG && servingG > 0 ? servingG : 100,
        v.kcal ?? null, v.carbs ?? null, v.protein ?? null, v.fat ?? null,
        v.fiber ?? null, v.sugars ?? null, v.satFat ?? null, v.sodiumMg ?? null,
        sourceKey, sourceId, now, now,
      )
      .run();
    const row = await db.prepare("SELECT * FROM foods WHERE sig = ?").bind(sig).first();
    return json({ created: true, record: catRecord(row) });
  }

  if (op === "edit") {
    const sig = typeof b.sig === "string" ? b.sig : "";
    const cur = sig ? await db.prepare("SELECT * FROM foods WHERE sig = ?").bind(sig).first() : null;
    if (!cur) return json({ error: "not_found" }, 404);
    const sets = [];
    const vals = [];
    const prev = {};
    const changes = {};
    if (typeof b.serving === "string" && b.serving.trim()) {
      const sv = b.serving.trim().slice(0, 60);
      if (sv !== cur.serving) { sets.push("serving = ?"); vals.push(sv); prev.serving = cur.serving; changes.serving = sv; }
    }
    if (b.servingG !== undefined) {
      const g = catNum(b.servingG, 5000);
      if (g === undefined || g === null || g <= 0) return json({ error: "bad_values" }, 422);
      if (g !== cur.serving_g) { sets.push("serving_g = ?"); vals.push(g); prev.servingG = cur.serving_g; changes.servingG = g; }
    }
    if (b.per100) {
      const per = catPer100(b.per100);
      if (!per.ok) return json({ error: "bad_values" }, 422);
      for (const [k, n] of Object.entries(per.values)) {
        const col = CAT_COLS[k];
        if (n !== cur[col]) { sets.push(col + " = ?"); vals.push(n); prev[k] = cur[col]; changes[k] = n; }
      }
    }
    if (!sets.length) return json({ changed: false, record: catRecord(cur) });
    const version = cur.version + 1;
    const device = typeof b.device === "string" ? b.device.slice(0, 64) : "";
    await db.batch([
      db.prepare("UPDATE foods SET " + sets.join(", ") + ", edited = 1, verified = 0, version = ?, updated_at = ? WHERE sig = ?").bind(...vals, version, now, sig),
      db.prepare("INSERT INTO food_revisions (sig, version, changes, prev, device, created_at) VALUES (?, ?, ?, ?, ?, ?)").bind(sig, version, JSON.stringify(changes), JSON.stringify(prev), device, now),
    ]);
    const row = await db.prepare("SELECT * FROM foods WHERE sig = ?").bind(sig).first();
    return json({ changed: true, record: catRecord(row) });
  }

  if (op === "history") {
    const sig = typeof b.sig === "string" ? b.sig : "";
    const rs = await db.prepare("SELECT version, changes, prev, created_at FROM food_revisions WHERE sig = ? ORDER BY id DESC LIMIT 20").bind(sig).all();
    return json({ revisions: (rs.results || []).map((r) => ({ version: r.version, changes: JSON.parse(r.changes), prev: JSON.parse(r.prev), at: r.created_at })) });
  }

  return json({ error: "bad_op" }, 400);
}

// ─── Administração (CATALOG_ADMIN_TOKEN) ─────────────────────────────────────────────────────────────────────────
async function handleCatalogAdmin(request, env) {
  const u = new URL(request.url);
  const given = request.headers.get("x-admin-token") || u.searchParams.get("token") || "";
  if (!env.CATALOG_ADMIN_TOKEN) return json({ error: "admin_not_configured", hint: "Cadastre o segredo CATALOG_ADMIN_TOKEN no Cloudflare." }, 403);
  if (given !== env.CATALOG_ADMIN_TOKEN) return json({ error: "unauthorized" }, 401);
  let db;
  try {
    db = await catDb(env);
  } catch {
    return json({ error: "catalog_init_failed" }, 503);
  }
  if (!db) return json({ error: "catalog_not_configured" }, 503);

  let b = { op: "stats" };
  if (request.method === "POST") {
    try {
      b = await request.json();
    } catch {
      return json({ error: "bad_json" }, 400);
    }
  }
  const op = b && typeof b.op === "string" ? b.op : "";

  if (op === "stats") {
    const t = await db.prepare("SELECT COUNT(*) AS total, COALESCE(SUM(edited),0) AS edited, COALESCE(SUM(verified),0) AS verified FROM foods").first();
    const by = await db.prepare("SELECT source_key, COUNT(*) AS n FROM foods GROUP BY source_key ORDER BY n DESC").all();
    const pol = await db.prepare("SELECT source_key, license, can_publish FROM source_policy ORDER BY source_key").all();
    const keys = await db.prepare("SELECT id, label, daily_limit, revoked FROM api_keys ORDER BY id").all();
    return json({ total: t.total, edited: t.edited, verified: t.verified, bySource: by.results, policy: pol.results, apiKeys: keys.results });
  }
  if (op === "verify") {
    const r = await db.prepare("UPDATE foods SET verified = ?, updated_at = ? WHERE sig = ?").bind(b.verified === false ? 0 : 1, Date.now(), String(b.sig || "")).run();
    return json({ ok: true, changes: r.meta?.changes ?? null });
  }
  if (op === "policy") {
    const sk = String(b.source_key || "");
    if (!sk) return json({ error: "bad_values" }, 422);
    await db
      .prepare("INSERT INTO source_policy (source_key, license, can_publish) VALUES (?, ?, ?) ON CONFLICT(source_key) DO UPDATE SET can_publish = excluded.can_publish, license = CASE WHEN ? != '' THEN ? ELSE license END")
      .bind(sk, String(b.license || "definido pelo administrador"), b.can_publish ? 1 : 0, String(b.license || ""), String(b.license || ""))
      .run();
    return json({ ok: true });
  }
  if (op === "key_create") {
    const raw = "gk_" + Array.from(crypto.getRandomValues(new Uint8Array(24))).map((x) => x.toString(16).padStart(2, "0")).join("");
    const limit = Math.min(Math.max(parseInt(b.daily_limit, 10) || 1000, 1), 1000000);
    await db.prepare("INSERT INTO api_keys (key_hash, label, daily_limit, created_at) VALUES (?, ?, ?, ?)").bind(await sha256Hex(raw), String(b.label || "sem nome").slice(0, 80), limit, Date.now()).run();
    return json({ key: raw, note: "Guarde agora: a chave não pode ser vista de novo (só o hash fica guardado)." });
  }
  if (op === "key_revoke") {
    await db.prepare("UPDATE api_keys SET revoked = 1 WHERE id = ?").bind(parseInt(b.id, 10) || 0).run();
    return json({ ok: true });
  }
  return json({ error: "bad_op" }, 400);
}

// ─── API pública (somente leitura) ───────────────────────────────────────────────────────────────────────────────
const pubJson = (obj, status = 200) => {
  const r = json(obj, status);
  r.headers.set("access-control-allow-origin", "*");
  return r;
};

function pubRecord(r) {
  return {
    id: r.sig,
    barcode: r.barcode || null,
    name: r.name,
    brand: r.brand || null,
    category: r.category || null,
    serving: { label: r.serving, grams: r.serving_g },
    per_100g: {
      energy_kcal: r.kcal, carbohydrates_g: r.carbs, proteins_g: r.protein, fat_g: r.fat,
      fiber_g: r.fiber, sugars_g: r.sugars, saturated_fat_g: r.sat_fat, sodium_mg: r.sodium_mg,
    },
    source: { key: r.source_key, license: r.license },
    version: r.version,
  };
}

async function handlePublicApi(request, env) {
  let db;
  try {
    db = await catDb(env);
  } catch {
    return pubJson({ error: "unavailable" }, 503);
  }
  if (!db) return pubJson({ error: "unavailable" }, 503);
  const auth = request.headers.get("x-gluco-key") || (request.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
  if (!auth.startsWith("gk_")) return pubJson({ error: "missing_key" }, 401);
  const key = await db.prepare("SELECT id, daily_limit FROM api_keys WHERE key_hash = ? AND revoked = 0").bind(await sha256Hex(auth)).first();
  if (!key) return pubJson({ error: "invalid_key" }, 401);
  const day = new Date().toISOString().slice(0, 10);
  await db.prepare("INSERT INTO api_usage (key_id, day, count) VALUES (?, ?, 1) ON CONFLICT(key_id, day) DO UPDATE SET count = count + 1").bind(key.id, day).run();
  const used = await db.prepare("SELECT count FROM api_usage WHERE key_id = ? AND day = ?").bind(key.id, day).first();
  if (used && used.count > key.daily_limit) return pubJson({ error: "daily_limit_reached" }, 429);

  const u = new URL(request.url);
  const path = pathOf(request);
  const BASE =
    "SELECT f.*, p.license AS license FROM foods f JOIN source_policy p ON p.source_key = f.source_key WHERE f.verified = 1 AND p.can_publish = 1";

  let m = path.match(/^\/api\/v1\/foods\/barcode\/(\d{8,14})$/);
  if (m) {
    const g = catGtin(m[1]);
    const rows = await db.prepare(BASE + " AND f.barcode IS NOT NULL ORDER BY f.version DESC LIMIT 50").all();
    const hit = (rows.results || []).find((r) => catGtin(r.barcode) === g);
    return hit ? pubJson({ data: pubRecord(hit) }) : pubJson({ error: "not_found" }, 404);
  }
  m = path.match(/^\/api\/v1\/foods\/(GLC-[0-9A-F]{5}-[0-9A-F]{5}-[0-9A-F]{5}-[0-9A-F]{5})$/);
  if (m) {
    const r = await db.prepare(BASE + " AND f.sig = ?").bind(m[1]).first();
    return r ? pubJson({ data: pubRecord(r) }) : pubJson({ error: "not_found" }, 404);
  }
  if (path === "/api/v1/foods") {
    const q = catNorm(u.searchParams.get("q") || "");
    const limit = Math.min(Math.max(parseInt(u.searchParams.get("limit") || "20", 10) || 20, 1), 50);
    if (q.length < 2) return pubJson({ error: "bad_query" }, 400);
    const rows = await db.prepare(BASE + " AND f.name_norm LIKE ? ESCAPE '\\' ORDER BY (f.name_norm LIKE ? ESCAPE '\\') DESC, LENGTH(f.name_norm) LIMIT ?")
      .bind("%" + q.replace(/[%_\\]/g, "\\$&") + "%", q.replace(/[%_\\]/g, "\\$&") + "%", limit).all();
    return pubJson({ data: (rows.results || []).map(pubRecord) });
  }
  return pubJson({ error: "not_found" }, 404);
}
