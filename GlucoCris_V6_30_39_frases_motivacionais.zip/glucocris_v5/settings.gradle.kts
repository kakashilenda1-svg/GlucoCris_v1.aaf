pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        // Reserva: espelho oficial do Maven Central mantido pelo Google. So e consultado se os
        // repositorios acima nao tiverem o arquivo (ou se um 404 temporario ficou guardado no cache).
        maven {
            name = "CentralMirrorGoogle"
            url = uri("https://maven-central.storage-download.googleapis.com/maven2/")
        }
    }
}

@Suppress("UnstableApiUsage")
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        maven {
            name = "CentralMirrorGoogle"
            url = uri("https://maven-central.storage-download.googleapis.com/maven2/")
        }
    }
}

rootProject.name = "AgonApp"
include(":app")
