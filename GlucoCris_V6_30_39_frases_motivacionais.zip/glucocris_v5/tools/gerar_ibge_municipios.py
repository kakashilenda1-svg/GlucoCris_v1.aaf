#!/usr/bin/env python3
"""
Gera app/src/main/assets/ibge_municipios.txt (5.570 municípios) para o Localizador de Insulina.

Formato de cada linha:  UF|Nome|latitude|longitude|C/I      (C = capital, I = demais)
O app soma esse arquivo à lista curada de 194 municípios. Sem o arquivo, o app funciona igual,
só com a lista curada.

Fontes (públicas):
  - Nomes e UF: IBGE, API de Localidades
      https://servicodados.ibge.gov.br/api/v1/localidades/municipios
  - Coordenadas (a API do IBGE não traz): repositório kelvins/municipios-brasileiros (municipios.csv)
      https://github.com/kelvins/municipios-brasileiros

Uso (precisa de internet, uma vez):
    python3 tools/gerar_ibge_municipios.py
Uso offline, com arquivos já baixados:
    python3 tools/gerar_ibge_municipios.py --ibge-json municipios.json --coords-csv municipios.csv
"""
import argparse
import csv
import io
import json
import sys
import urllib.request
from pathlib import Path

IBGE_URL = "https://servicodados.ibge.gov.br/api/v1/localidades/municipios"
COORDS_URL = "https://raw.githubusercontent.com/kelvins/municipios-brasileiros/main/csv/municipios.csv"
OUT = Path(__file__).resolve().parent.parent / "app/src/main/assets/ibge_municipios.txt"


def fetch(url: str) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "GlucoCris-tools/1.0"})
    with urllib.request.urlopen(req, timeout=60) as r:
        return r.read()


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ibge-json", help="municipios.json do IBGE já baixado")
    ap.add_argument("--coords-csv", help="municipios.csv (kelvins) já baixado")
    ap.add_argument("--out", default=str(OUT))
    a = ap.parse_args()

    ibge = json.loads(Path(a.ibge_json).read_bytes() if a.ibge_json else fetch(IBGE_URL))
    raw = Path(a.coords_csv).read_bytes() if a.coords_csv else fetch(COORDS_URL)
    coords = {}
    for row in csv.DictReader(io.StringIO(raw.decode("utf-8-sig"))):
        coords[str(row["codigo_ibge"]).strip()] = (
            row["latitude"].strip(), row["longitude"].strip(), row.get("capital", "0").strip() == "1",
        )

    lines, sem_coord = [], []
    for m in ibge:
        code = str(m["id"])
        nome = m["nome"].strip()
        try:
            uf = m["microrregiao"]["mesorregiao"]["UF"]["sigla"]
        except (KeyError, TypeError):
            uf = m["regiao-imediata"]["regiao-intermediaria"]["UF"]["sigla"]
        c = coords.get(code)
        if not c:
            sem_coord.append(f"{nome}/{uf}")
            continue
        lines.append(f"{uf}|{nome}|{float(c[0]):.4f}|{float(c[1]):.4f}|{'C' if c[2] else 'I'}")

    lines.sort()
    if len(lines) < 5000:
        print(f"ERRO: só {len(lines)} municípios com coordenadas (esperado ~5.570). Arquivo NÃO gravado.", file=sys.stderr)
        return 1
    out = Path(a.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"{len(lines)} municípios gravados em {out}")
    if sem_coord:
        print(f"{len(sem_coord)} sem coordenadas (ignorados): {', '.join(sem_coord[:10])}…")
    return 0


if __name__ == "__main__":
    sys.exit(main())
