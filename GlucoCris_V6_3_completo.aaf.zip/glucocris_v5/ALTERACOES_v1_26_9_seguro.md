# GlucoCris v1.26.9 (seguro) — o que mudou em relação ao "COMPLETO_pesquisa_restaurantes"

1. **Logout** (`GlucoViewModel.kt`): voltou ao comportamento original. Sair da conta NÃO apaga mais os dados do aparelho.
   A troca de conta continua segura pelo fluxo que já existia (ACCOUNT_MISMATCH / prepareAccountSwitch), que só troca
   os dados se tudo já estiver salvo na nuvem e, se não, junta os dados.
2. **Subway** (`FoodNutritionScreens.kt`): a fonte de cada item agora avisa que açúcares (e sódio, no Italiano) não
   foram informados e aparecem como 0. Nenhum valor numérico foi alterado.
3. Mantido do COMPLETO: catálogo de restaurantes, seletor de conta do Google (signIn(true)) e signOut do Google no CloudBackup.

Nada mais foi alterado. Os zips originais não foram modificados.

## Código de barras: velocidade, segurança e base offline (nesta revisão)
- **Correção importante:** o Open Food Facts traz valores por 100 g, mas o app os mostrava como se fossem da porção
  (ex.: porção de 30 g exibia os carboidratos de 100 g, ~3x maior). Agora os valores são convertidos para a porção.
- **Velocidade:** todas as consultas (BR + mundial + busca por código) rodam ao mesmo tempo; vence a primeira resposta
  válida, com limite de ~2,2 s para a internet. Cache do aparelho torna o segundo scan do mesmo produto instantâneo e offline.
- **Segurança dos dados:** produto sem dados ou com números incoerentes (calorias x macros) aparece como "verificar".
  Um produto vazio nunca vence uma fonte melhor. Resultado do Gemini aparece como estimado, pedindo conferência no rótulo,
  e agora traz também fibras, açúcares e sódio.
- **Base offline maior:** se existir `app/src/main/assets/catalogo_extra.json`, ele entra na busca de alimentos e no leitor
  de código de barras sem internet. Gere com `tools/build_catalogo_extra.py` (dump do Open Food Facts, só produtos do Brasil
  com dados coerentes). O arquivo ainda NÃO está incluído.

## Catálogo e scanner (revisão seguinte)
- O scanner com Gemini já usa a mesma busca do app (`searchFoodsComplete`: TACO + restaurantes + Meus alimentos + catálogo extra
  + Open Food Facts + USDA). Agora a visão offline do aparelho também enxerga os restaurantes e o catálogo extra.
- `assets/catalogo_extra.json` agora tem 2 itens, marcados como ESTIMATIVA (reliability "estimada"): Pizza de mussarela
  (média de 6 rótulos) e Brigadeiro (média de 2 tabelas). Coxinha, pastel, empada, quibe e croquete já vêm da TACO.
- Para ampliar: acrescente itens a `catalogo_extra.json` (valores POR PORÇÃO, com `servingGrams`) ou gere uma base grande
  com `tools/build_catalogo_extra.py`.
