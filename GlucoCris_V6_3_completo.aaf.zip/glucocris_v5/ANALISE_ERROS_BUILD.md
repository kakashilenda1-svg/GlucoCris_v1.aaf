# Análise do erro de build (GitHub Actions) — Gluco Cris v1.27.0

## Causa principal (corrigida)
`androidx.compose:compose-bom:2026.09.00` traz o Compose 1.12, que exige **compileSdk 37 + AGP 9.1.1+**.
O projeto usa AGP 8.10.1 e compileSdk 36, então o `checkDebugAarMetadata` falha (stack trace de workers do Gradle,
`BUILD FAILED in 2m 51s`, `23 actionable tasks: 23 executed`).

**Correção:** BOM `2026.04.01` (Compose 1.11, último compatível com compileSdk 36 / AGP 8.x).

## Outros ajustes
| Item | Problema | Correção |
|---|---|---|
| `kotlinOptions { jvmTarget }` | Depreciado; vira erro no Kotlin 2.2+ | `kotlin { compilerOptions { jvmTarget.set(JVM_17) } }` |
| `gradle.properties` | `android.suppressUnsupportedCompileSdk=36` desnecessário; sem limite de memória do Kotlin daemon | removido; `kotlin.daemon.jvmargs=-Xmx3g`, `kotlin.incremental=false` (CI) |
| `res/drawable/gluco_icon_source.png` | PNG de 1,4 MB (1024x1024) não usado, entrava no APK e no AAPT2 | movido para `tools/` |
| Workflow | Instalava NDK sem necessidade; log completo se perdia | NDK removido; `build.log` enviado como artifact em caso de falha |

## Verificado sem problemas
- Classes do AndroidManifest (7 receivers/services/activities) existem no código.
- Recursos `R.raw`, `R.drawable`, `R.layout`, `R.id`, `@xml`, `@string`, `@mipmap` existem.
- `google-services.json` com pacote `com.agon.app`.
- XMLs e JSONs (assets) válidos; chaves/parênteses balanceados em todos os `.kt`; pacotes batem com pastas.
- Nenhuma redeclaração de classe/objeto; imports internos resolvem; `BuildConfig` usado está definido.
- Dependências `llamacpp-kotlin:0.4.0` e demais existem no Maven.

## Riscos restantes (não verificáveis sem compilar)
- `llamacpp-kotlin:0.4.0` depende de kotlin-stdlib 2.3.20 e o projeto usa Kotlin 2.2.21 (compatível, 1 versão à frente). Se aparecer erro de metadata, suba Kotlin e os 3 plugins para 2.3.20.
- Se algum erro `e: ...` de Kotlin aparecer, o artifact `build-log` traz o log completo.
