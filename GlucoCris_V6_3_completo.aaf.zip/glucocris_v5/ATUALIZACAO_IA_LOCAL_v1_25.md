# Gluco Cris 1.25.0 — Escolha e instalação da IA local também para quem atualiza

> **Estado de verificação: NADA foi compilado nem executado.** O ambiente onde isto foi feito não tem Android SDK/Gradle nem
> internet. O código foi escrito e revisado por leitura (conferência de chaves/parênteses e de referências), não por compilação.
> Rode `./gradlew assembleDebug` e o checklist abaixo antes de publicar.

## Causa do problema
`MainActivity` só mostrava `CrisModelGateScreen` quando **não havia conta Google** (antes do login). Quem já tinha conta
(todo usuário antigo) nunca passava por ela. O diálogo pós-tour (`CrisLocalAiOfferDialog`) só aparecia uma vez e baixava sempre o
modelo padrão, sem escolha. Além disso, tocar em "Rápida/Precisa" nas configurações trocava o modelo "em foco" na hora,
fazendo o app tratar o modelo já instalado como ausente.

## O que mudou
| Área | Arquivo | Mudança |
|---|---|---|
| Decisão na abertura | `localai/ModelGate.kt` (novo) | Classifica a abertura (nova / atualização / normal) e decide: nada, escolher modelo (sem modelo, arquivo incompleto/corrompido ou modelo pesado demais para o aparelho) ou "manter ou trocar" (uma vez, só se há outra opção que o aparelho aguenta). |
| Modelos | `localai/LocalModelManager.kt` (reescrito) | Separa **modelo ativo** (em uso) de **modelo alvo** (baixando). Valida tamanho + cabeçalho `GGUF` (+ SHA-256 se preenchido). O ativo só é substituído/apagado depois que o novo foi baixado, validado e instalado. Migra instalações antigas sem apagar nada (adota o modelo que já estava no disco). |
| Download | `localai/ModelDownloadWorker.kt` (novo) | `CoroutineWorker` (WorkManager, trabalho único, expedited com fallback), notificação persistente com Pausar/Cancelar, retomada por `Range`, nova tentativa com espera crescente (até 8), exige Wi-Fi salvo se a pessoa autorizou dados móveis. Substitui `ModelDownloadService` (removido). |
| Telas | `ui/screens/CrisModelGateScreen.kt` (reescrito) | Tela de escolha (leve × potente) com tamanho, RAM mínima/recomendada, vantagens, "em uso/instalada/recomendada", avisos; progresso (baixado, %, velocidade); Pausar/Continuar/Tentar de novo/Cancelar. Mesma tela no gate e em *Configurações da Cris IA → Trocar modelo* (rota `cris_ia_modelo`). |
| Configurações | `ui/screens/CrisLocalAiScreen.kt` | Cartão do modelo mostra o ativo, versão e progresso; botão **Trocar modelo**; apagar/reinstalar com confirmação; opção de permitir dados móveis. |
| App | `MainActivity.kt`, `Routes.kt`, `AndroidManifest.xml`, `app/build.gradle.kts` | Fluxo do gate pré-login e pós-login; rota nova; `SystemForegroundService` dataSync + receiver dos botões; `work-runtime-ktx:2.10.0`; versão 1.25.0 (versionCode 68). `applicationId` continua `com.agon.app`. |
| Removido | `ModelDownloadService.kt`, `CrisLocalAiOffer.kt` | Substituídos pelo WorkManager e pela tela de escolha. |

**Não tocados:** glicemias, insulinas, perfil, gráficos, cálculos, lembretes, backup Firebase, histórico/memórias/personalidade
da Cris (nenhum código desses módulos foi alterado). Os modelos ficam em `noBackupFilesDir/localai/models` com os mesmos nomes de
arquivo/ids de antes; as preferências antigas (`selected_model`, `consent_model`) continuam sendo lidas.

## Regras de comportamento
- **Instalação nova** (sem versão gravada e sem conta): escolha antes do login. Em aparelho com ≥ 5 GB de RAM é obrigatória
  (como antes); aparece "Continuar sem a IA por enquanto" se falhar ou estiver sem internet. Abaixo de 5 GB é opcional.
- **Atualização sem modelo / modelo incompleto / corrompido / incompatível:** mesma tela, opcional ("Agora não"), mostrada
  depois do desbloqueio. "Agora não" não volta a aparecer até a próxima versão do app (continua acessível nas Configurações).
- **Atualização com modelo compatível:** nada é baixado. Um aviso único oferece "Manter a atual" ou "Ver opções".
- **Troca:** se o outro modelo já está instalado, vira ativo na hora; senão baixa em segundo plano, valida e só então ativa
  e remove o anterior (para liberar espaço).
- **Falta de espaço:** checado antes de começar (tamanho restante + 400 MB) e tratado se o disco encher durante o download
  (ENOSPC); o modelo em uso e o parcial são mantidos.
- **Offline:** o download entra na fila e começa sozinho ao conectar; modelo já instalado funciona sem internet.

## Pendências / decisões suas
1. **SHA-256 vazio** nos dois modelos (já era assim). Hoje a integridade = tamanho exato + cabeçalho GGUF. Para verificação
   forte, preencha `sha256` em `LocalModels` com o hash LFS mostrado na página de cada arquivo no Hugging Face.
2. **Números de RAM** (mín. 3/6 GB, recomendado 4/8 GB) e o limiar de 5 GB para "obrigatório" são minha estimativa a partir das regras
   que já existiam em `ModelAdvisor`; ajuste em `LocalModels`/`ModelGate` se quiser.
3. **Versão do WorkManager (2.10.0)** escolhida de memória; confirme que resolve no seu Gradle.
4. A notificação de progresso depende da permissão de notificações (Android 13+): é pedida uma vez ao iniciar o download; se negada o
   download funciona, só sem a notificação visível.
5. Android 15 limita serviços `dataSync` (~6 h/dia): o download é pausado pelo sistema e retomado pelo WorkManager.

## Checklist de testes (todos PENDENTES — não executados)
- [ ] Instalação nova, aparelho ≥ 5 GB: gate aparece antes do login; escolher leve; baixa; entra no login.
- [ ] Instalação nova, aparelho < 5 GB: gate opcional; "Agora não" leva ao login.
- [ ] Atualização de 1.24.0 sem modelo: após desbloquear, gate de escolha; escolher; histórico/memórias da Cris intactos.
- [ ] Atualização com modelo leve instalado: sem novo download; aviso "manter ou trocar" uma vez; "Manter" não repete.
- [ ] Atualização com modelo potente instalado: idem; em aparelho que não aguenta o potente, gate de escolha (incompatível).
- [ ] Troca leve → potente: o leve continua funcionando durante o download; só é removido após validar o potente.
- [ ] Troca para modelo já instalado (ambos presentes): ativa na hora.
- [ ] Matar o app / apagar a tela / reiniciar o aparelho durante o download: continua e retoma de onde parou.
- [ ] Pausar e continuar (tela e notificação); cancelar apaga só o parcial.
- [ ] Falha de download (modo avião no meio, servidor 5xx): fila/retentativa; "Tentar de novo" após esgotar.
- [ ] Falta de espaço antes e durante o download: mensagem clara, modelo em uso preservado.
- [ ] Arquivo corrompido (truncar o `.gguf` no disco): detectado como danificado, gate de reinstalação.
- [ ] Offline: modelo instalado responde; sem modelo, download espera conexão.
- [ ] Backup/restauração em outro aparelho (prefs voltam, modelo não): gate de escolha.
