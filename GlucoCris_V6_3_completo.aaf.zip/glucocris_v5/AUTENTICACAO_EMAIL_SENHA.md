# Gluco Cris v1.24.0 — Login por e-mail e senha + Google

Não compilado e não testado (ambiente sem Android SDK e sem internet). Gere o APK com `./gradlew assembleDebug` e rode o roteiro de testes abaixo.

## O que mudou no código (só o necessário)
- `cloud/CloudBackup.kt`: cadastro, login, verificação, redefinição de senha, vínculo Google/senha, mensagens de erro; backup só roda com e-mail verificado.
- `data/GlucoViewModel.kt`: fluxos de autenticação (não alteram dados de saúde).
- `ui/screens/GoogleAccount.kt`: tela de login (Google + e-mail/senha + criar conta + verificação) e "Métodos de acesso" no Perfil.
- `firestore.rules`: aceita `google.com` ou `password`, sempre com e-mail verificado; anônimo negado.
- `app/build.gradle.kts`: apenas versão (1.24.0 / código 67). `applicationId` e assinatura inalterados.
Nada em glicemias, insulinas, gráficos, cálculos, lembretes, Cris IA ou perfil foi tocado.

## O que ativar no Firebase (projeto gluco-cris, plano Spark)
1. Authentication > Método de login > Adicionar novo provedor > **E-mail/senha** > Ativar (deixe "Link por e-mail (sem senha)" desligado) > Salvar.
2. Mantenha **Google** ativado e **Anônimo** desativado.
3. Authentication > Configurações > Vinculação de contas: **"Vincular contas que usam o mesmo e-mail"** (padrão).
4. Authentication > Configurações > Ações do usuário: mantenha a **proteção contra enumeração de e-mails** ligada.
5. Authentication > Modelos: em "Verificação de endereço de e-mail" e "Redefinição de senha", escolha o idioma Português (Brasil) e, se quiser, ajuste nome do remetente e assunto.
6. Firestore > Regras: cole o novo `firestore.rules` e **Publicar**. Elas aceitam também as contas Google já usadas, então podem ser publicadas antes de instalar o app novo.
7. Não faça upgrade para Blaze nem para o Identity Platform quando o console oferecer.

## Regras de comportamento
- Senha: mínimo 8 caracteres, com confirmação.
- Cadastro: o app só libera o acesso depois da verificação do e-mail. A sessão fica guardada; ao reabrir, volta para a tela "Verifique seu e-mail".
- Erros: "E-mail ou senha incorretos" (e-mail inexistente e senha errada têm a mesma mensagem, por segurança), "Este e-mail já está cadastrado...", "Sem conexão com a internet...", entre outros.
- Mesmo UID: "Adicionar senha" (conta Google) e "Vincular Google" (conta com senha) usam `linkWithCredential`; só liga se o e-mail for igual.
- Contas diferentes no mesmo aparelho: o backup para e o app pergunta se usa os dados da conta nova ou junta (já existia na v1.23).
- Uso offline: tudo que já existia segue local; só cadastro, verificação, redefinição e backup precisam de internet.

## Roteiro de testes (NÃO EXECUTADOS — preencha ao testar)
| # | Teste | Resultado esperado | Resultado |
|---|---|---|---|
| 1 | Criar conta (nome, e-mail, senha, confirmação diferente) | "As senhas não são iguais." | |
| 2 | Criar conta válida | Tela "Verifique seu e-mail"; e-mail chega (ver spam) | |
| 3 | "Já verifiquei" antes de clicar no link | "Ainda não verificado..." | |
| 4 | Clicar no link e "Já verifiquei" | Entra no app; Perfil mostra backup "Em dia" | |
| 5 | Fechar e abrir o app | Continua logado | |
| 6 | Cadastro de e-mail já existente | Mensagem de e-mail já cadastrado | |
| 7 | Login com senha errada | "E-mail ou senha incorretos." | |
| 8 | Login em modo avião | "Sem conexão com a internet..." | |
| 9 | "Esqueci minha senha" | Mensagem neutra; e-mail de redefinição chega | |
| 10 | Continuar com Google | Entra; backup "Em dia" | |
| 11 | Perfil > Adicionar senha (conta Google) | Mesmo UID no console; login por senha funciona | |
| 12 | Perfil > Vincular Google (conta com senha), mesmo e-mail | Mesmo UID | |
| 13 | Vincular Google com e-mail diferente | Recusado, nada alterado | |
| 14 | Criar glicemia e conferir `users/{uid}/records` | Documento aparece | |
| 15 | Limpar dados do app, entrar, "Restaurar da nuvem" | Registros voltam | |
| 16 | Entrar com outra conta no mesmo aparelho | Backup bloqueado; escolha "Usar dados desta conta"/"Juntar" | |
| 17 | Sair da conta | Volta ao login; dados locais intactos | |
| 18 | Regras: leitura de `users/{outro uid}` e sem login | Negado (Rules Playground) | |
