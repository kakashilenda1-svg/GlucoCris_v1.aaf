# Backup e sincronização — Firebase Spark (v1.23.0)

Não compilado nem testado (ambiente sem Android SDK e sem internet). Compile, teste e rode o Emulador de regras antes de distribuir.

## Estrutura no Firestore
- `users/{uid}` — controle: `lastBackupAt` (serverTimestamp), `schema` (1)
- `users/{uid}/records/{tipo}__{id}` — um documento por registro
  - tipos: `glucose`, `insulin`, `reminders`, `meals`, `symptoms`, `medications`, `profile` (id fixo `main`)
  - campos: `type`, `id`, `updatedAt` (ms, do aparelho), `deleted` (bool, exclusão), `payload` (JSON do registro), `schema` (1), `syncedAt` (serverTimestamp, usado como cursor)
- `{uid}` é o `uid` do Firebase Auth (login Google). Nunca e-mail, CPF ou outro dado como chave.

## O que vai ao backup
Glicemias, insulinas, lembretes, refeições, sintomas, medicamentos e perfil/ajustes e, a partir desta versão:
água (registros, meta e copos favoritos), favoritos (refeições, alimentos e receitas), bolus (fatores, histórico e passo de arredondamento)
e conversas da Cris IA (um documento por conversa).
NÃO vão: PIN (e se está ativo), conta Google vinculada, tour visto, registros de exemplo ("demo-").
CPF vai junto com o perfil; para nunca enviar, ponha `SYNC_CPF = false` em `cloud/SyncMerge.kt`.
Ficam só no aparelho (sem backup): alimentos personalizados, memória da Cris IA e demais ajustes de som/lembrete da água.

## Registro grande ou recusado
Um registro que o Firebase recusa não trava mais os outros: se um lote é recusado, o app reenvia um por um, salva os bons e deixa só o ruim
de fora (a tela de backup mostra "exceto N registro(s)..."). O recusado é tentado de novo quando muda ou após 6 horas.
Limites das regras: 20.000 caracteres por registro nos tipos de sempre; 800.000 em água/favoritos/bolus/conversas
(se uma conversa passar disso, só a cópia da nuvem perde as mensagens mais antigas).
**Republique o `firestore.rules`** (passo 2 abaixo): ele agora aceita os tipos `water`, `favorites`, `bolus` e `conversations`.

## Envio em segundo plano
A cada ~30 min, com internet, o app envia o que estiver pendente mesmo fechado (WorkManager). Sem pendências, não faz nenhuma chamada.

## Console do Firebase (projeto gluco-cris, plano Spark — não faça upgrade para Blaze)
1. Firestore Database > Criar banco de dados > banco `(default)`, modo produção (a cota gratuita vale para o `(default)`). Região: southamerica-east1 (não dá para mudar depois).
2. Firestore > Regras: cole `firestore.rules` e Publicar.
3. Authentication > Método de login: ativar só "Google". Deixar "Anônimo" desativado.
4. Configurações do projeto > seu app Android: adicionar o SHA-1 do debug (4D:DB:07:75:25:B3:C4:84:A1:ED:F1:2C:07:8F:55:BA:2F:93:CE:AC) e o SHA-1 da chave de release.
5. Baixar o `google-services.json` de novo e substituir `app/google-services.json` (precisa trazer o cliente OAuth tipo 3, que gera `default_web_client_id`).
6. No Google Cloud > APIs e serviços > Credenciais: restringir a chave de API ao pacote `com.agon.app` + SHA-1.

## Cota Spark (por dia): 50.000 leituras, 20.000 gravações, 20.000 exclusões; 1 GiB
O app para sozinho em 40.000 leituras / 16.000 gravações do dia e reabre às 6h. Se o Firebase responder cota esgotada, espera 3 h. Nada local é tocado.
