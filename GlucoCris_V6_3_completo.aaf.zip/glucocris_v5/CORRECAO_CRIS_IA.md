# Cris IA com llama.cpp — v1.16.0

## O que mudou

| Antes | Agora |
|-------|--------|
| LiteRT-LM + Gemma 4 E2B (~2,5 GB) | **llama.cpp** via `llamacpp-kotlin` 0.4.0 |
| Formato `.litertlm` | Formato **GGUF** |
| Modelo pesado, risco de OOM | **Qwen2.5 1.5B Instruct Q4_K_M** (~1,04 GB) |

## Arquivos principais

- `localai/LocalAiEngine.kt` — motor reescrito em cima de `LlamaHelper` (llama.cpp)
- `localai/LocalModelManager.kt` — download do GGUF Qwen2.5
- `localai/LocalVisionManager.kt` — visão com mmproj se houver; senão OCR + texto
- `localai/CrisLocalAi.kt` — orquestração (mesma API)
- `ui/screens/CrisChatScreen.kt` — proteção contra crash (`Throwable` + handler)
- `app/build.gradle.kts` — dependência `io.github.ljcamargo:llamacpp-kotlin:0.4.0`

## Comportamento

- Offline: responde com o modelo local (llama.cpp)
- Online: pesquisa quando necessário + interpreta com o modelo local
- Personalidade da Cris preservada
- Scanner, glicemia, insulina, gráficos, alimentação, localizador **intactos**

## Build

```bash
cd agon_source
./gradlew assembleDebug
```

Requer NDK no CI/SDK (a lib AAR já traz `.so` nativos para arm64-v8a e x86_64).

## Testes no aparelho

1. Baixar a IA local (Wi-Fi)
2. Quem descobriu o Brasil?
3. Quanto é 25 × 8?
4. Quem é o presidente do Brasil atualmente?
5. Quais são as notícias de hoje?
6. Explique como funciona a glicose no organismo.

Com e sem internet. O app **não deve fechar**.
