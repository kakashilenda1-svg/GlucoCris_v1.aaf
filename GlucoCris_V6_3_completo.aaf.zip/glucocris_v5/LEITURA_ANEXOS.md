# Cris IA — leitura precisa de anexos (v1.20.0)

## Problema
Ao anexar foto/arquivo, a Cris respondia "não tenho acesso a imagens". Causa: sem chave Gemini no APK
(e sem IA local instalada) o anexo caía no chat de texto, que nunca recebe a imagem.

## O que mudou
- `localai/CrisAttachments.kt` (novo): recebe foto, PDF, Word (.docx), TXT/CSV, áudio e vídeo (até 4 por mensagem).
  - Foto: corrige rotação (EXIF), fundo branco em PNG transparente, envia até 2048 px / JPEG 90 (antes 768 px).
  - PDF: enviado inteiro e nativo à IA (lê texto, tabelas, carimbos). PDF muito pesado: páginas viram imagens.
  - Áudio/vídeo: enviados à IA (até ~14 MB). Vídeo maior: 10 imagens ao longo do vídeo.
  - Sem internet / sem chave / sem cota: OCR no aparelho (fotos e PDFs) + glossário de exames e abreviações de receita.
    Nunca mais diz "não tenho acesso a imagens".
- `data/CrisGemini.kt`: `analyzeParts` com instruções específicas para receita, pedido de exame e laudo
  (explica cada item e sigla, não adivinha trecho ilegível, não altera dose), vários anexos, histórico da conversa,
  modelo de reserva (gemini-2.5-flash / 2.0-flash) e nova tentativa em erro de servidor.
- `ui/screens/CrisChatScreen.kt`: seletor múltiplo, "toque para remover", anexo SEMPRE passa pela leitura de anexos.
- `app/build.gradle.kts`: versão 1.20.0 (62). A chave Gemini **não** vai mais no APK.

## IMPORTANTE: configurar o proxy (chave só no Cloudflare)
Leitura precisa online usa a rota `/gemini` do mesmo Worker do Tavily:
1. No Worker: `npx wrangler secret put GEMINI_API_KEY`
2. No app: `tavily.proxy.url=https://SEU-PROXY.workers.dev` em `local.properties`
3. Modelo opcional: `gemini.model=gemini-3.8-flash`

Sem proxy / sem internet: OCR no aparelho + glossário (já implementado).

## Testar
1. Foto de pedido de exame → lista cada exame e para que serve.
2. PDF de laudo → valores, referência, acima/abaixo.
3. Receita manuscrita → remédios como escritos; trecho ilegível é apontado, não inventado.
4. Áudio e vídeo curtos.
5. Modo avião + foto de documento → texto lido no aparelho + glossário.
