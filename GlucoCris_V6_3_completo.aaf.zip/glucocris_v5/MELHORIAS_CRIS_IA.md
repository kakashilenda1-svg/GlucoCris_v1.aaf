# Melhorias da IA Cris (sobre a v1.17.0)

Arquivos novos: `localai/CrisConversations.kt`
Arquivos alterados: `localai/LocalAiEngine.kt`, `localai/CrisLocalAi.kt`, `localai/CrisWebSearch.kt`,
`ui/screens/CrisShared.kt`, `ui/screens/CrisChatScreen.kt`, `MainActivity.kt`
Sem novas dependências. applicationId, assinatura e versão não foram alterados.

- Motor: modelo continua carregado (30 min ocioso; só descarrega sob pressão real de memória), contexto 1536→3072,
  prompt de sistema não é mais cortado em 1800 caracteres, janela de histórico 4→6 mensagens, pré-carregamento em
  segundo plano (4 s após abrir o app e ao abrir a Cris; ignora economia de bateria/aquecimento).
- Resposta aparece enquanto é gerada (streaming), passando pelo filtro de dose antes de ser exibida.
- Prompt reescrito: direto, concreto, profundidade proporcional à pergunta; dados do app só entram no prompt em assunto de saúde/registros.
- Fontes/links só aparecem se a pessoa pedir (fonte, link, referência, "de onde tirou"...). Rótulos "IA no aparelho/pesquisa online" ocultos;
  mantidos os de cálculo, dados do app, resposta básica e segurança.
- Histórico: um arquivo JSON por conversa (id único) + índice, em filesDir; menu ⋮ → Histórico / Nova conversa / Excluir esta conversa.
  O chat antigo é importado como primeira conversa (o original não é apagado).
- Memória: cada conversa carrega só o próprio contexto; mensagens antigas viram resumo compacto (assunto, dados pessoais, últimas trocas).
  Memória de longo prazo ("lembre que…") continua separada e só por pedido explícito.
- O ícone de lixeira do cabeçalho passou para o menu ⋮ ("Excluir esta conversa", com confirmação).

## Correção de build (v1.18.1)
- `CrisLocalAiScreen.kt`: faltava `import com.agon.app.localai.CrisFact` (causava os 5 erros do log: "Cannot infer type T", "Unresolved reference CrisFact/text/id").
- `CrisConversations.kt`: referência de função trocada por lambda (mais segura); novo `clearAll`.
- "Apagar histórico de conversas" (configurações da Cris) agora também apaga as conversas salvas pelo histórico novo.

## Correção: resposta errada ao perguntar "quem é o presidente atual do Brasil" (v1.17.1)
**Não compilado e não testado em aparelho.** Causa encontrada por leitura do código (sem Logcat):
- Para fatos atuais, a Cris tem um atalho que responde direto das fontes, sem passar pelo modelo (`composeDirectFact`). Ele escolhia o trecho de maior pontuação, **mesmo que fosse da Wikipédia e de outro assunto**. A busca na Wikipédia usava a frase inteira ("quero saber quem é o presidente atual do Brasil"), e o primeiro resultado foi "Povos indígenas do Brasil", que foi mostrado como resposta.
- Isso só acontece quando o dado estruturado do cargo (Wikidata, `officeFact`) falha. Hipótese provável: a consulta `wbgetentities&props=claims` do Brasil devolve um JSON maior que o limite de leitura (600 KB), chega cortado e não é lido. Não confirmado sem rede.

Correções (`localai/CrisWebSearch.kt`):
- `officeFact` agora pede só a propriedade do cargo (`wbgetclaims`, P35/P6), resposta pequena.
- `composeDirectFact` só responde direto quando há fato estruturado do Wikidata. Sem ele, quem responde é o modelo local, com os trechos como apoio (o prompt já manda dizer "não encontrei confirmação" se não responderem).
- A busca na Wikipédia usa só o assunto (`topicOf`): "presidente do Brasil", sem "quero saber quem é…".
- Se nenhuma fonte confiável responder, a mensagem continua honesta (não inventa).

`ui/screens/CrisChatScreen.kt` (cosmético): botões do cabeçalho de 40 dp e status em 11 sp, para "digitando…" não quebrar em duas linhas curtas.

Versão 57 / 1.17.1. applicationId e assinatura inalterados.

### v1.17.2 — Segunda trava contra resposta sem relação com a pergunta
- `CrisWebSearch.kt`: resultados da Wikipédia só entram (como resposta ou como apoio para o modelo) se o título ou o início do texto tratar do assunto perguntado (`relevant`: pelo menos 60% das palavras-chave). Exemplo: "Povos indígenas do Brasil" é descartado para "presidente do Brasil". A lógica foi testada isoladamente em Java; o app em si não foi compilado nem testado.
- Se nada relevante sobrar, a Cris avisa que não conseguiu confirmar na internet em vez de mostrar texto de outro assunto.
- Versão 58 / 1.17.2.

### v1.18.0 — Resposta com foto, contexto e fontes clicáveis (estilo do print do ChatGPT)
**Não compilado e não testado em aparelho.**
- Perguntas de cargo ("quem é o presidente…"): além da frase do Wikidata, a resposta traz uma frase de contexto da Wikipédia sobre a pessoa (só se o verbete for mesmo dela), a **foto oficial** (Wikidata P18 → Wikimedia Commons) e botões de **fonte** clicáveis.
- Respostas que usaram a pesquisa (inclusive as redigidas pelo modelo local) mostram os botões de fonte (até 3); tocar abre o site no navegador (só HTTPS).
- Novos: `localai/CrisImageLoader.kt` (baixa só de commons.wikimedia.org e upload.wikimedia.org, HTTPS, máx. 4 MB, imagem reduzida), `ui/screens/CrisMediaBlock.kt` (foto + fontes na bolha).
- Alterados: `CrisWebSearch.kt` (`WebHit.image`, `mediaOf`, foto e contexto no `officeFact`, até 2 frases na resposta direta), `CrisShared.kt` (`CrisTurnResult.media`), `CrisIaScreen.kt` (`CrisMsg.media`), `CrisConversations.kt` (`CrisConvMsg.media`, salvo no histórico), `CrisChatScreen.kt`.
- Observação: as fontes agora aparecem sempre como botões pequenos nas respostas pesquisadas (antes só quando a pessoa pedia). A fala (voz) lê só o texto, não as fontes.
- Limite: a Cris continua usando o modelo pequeno do aparelho (Qwen2.5 1,5B); respostas sem pesquisa são mais simples e podem errar mais que as de uma IA grande na nuvem.
- Versão 59 / 1.18.0.

### v1.19.2 — Perguntas fora de saúde usam prompt neutro
**Não compilado e não testado em aparelho.**
- Problema: numa pergunta comum ("como encher o pneu"), o prompt de diabetes/insulina/"não sou médica" fazia o modelo pequeno desviar para conselhos de saúde.
- `CrisLocalAi.buildSystemPrompt`: sem assunto de saúde/registros, usa um prompt enxuto (responder qualquer assunto, continuar o tema da pergunta anterior, passos numerados, não inventar, não falar de saúde sem ser perguntado). Com assunto de saúde, o prompt completo e as regras de segurança continuam iguais.
- As travas por código (`CrisSafetyGuard.precheck`/`postcheck`: dose de insulina, emergência, autolesão) não dependem do prompt e continuam em todas as conversas.
- `HEALTH_RE` ampliada (medicamento, remédio, bula, Anvisa, vacina, sintoma, exame, pressão, saúde, tratamento) para essas perguntas continuarem no modo saúde.
- Limite do modelo: o Qwen2.5 1,5B erra fatos e "como fazer". O modelo "Precisa · Qwen2.5 3B" (já existe em Cris IA > configurações) é bem melhor; é troca de modelo, não mudei o padrão.

### v1.19.1 — Cris não recusa mais pedidos comuns (ex.: receita de bolo)
**Não compilado e não testado em aparelho.**
- Causa: o modelo local pequeno respondia "não posso fornecer… é muito pessoal / não é minha área". Não vinha de regra do app.
- `CrisLocalAi.buildSystemPrompt`: instruções explícitas para atender receitas, contas, textos e conversa livre; as únicas recusas são dose de insulina/mudança de tratamento e algo perigoso/ilegal. As regras de segurança médica não mudaram.
- `CrisLocalAi.chat`: se o modelo soltar uma recusa genérica num assunto comum, a Cris tenta mais uma vez com diretriz reforçada (e não mostra a recusa na tela). Assuntos de insulina, dose, medicamento, tratamento, autolesão, armas, drogas etc. nunca passam por essa nova tentativa.
- `CrisChatScreen`: corrigida a mensagem duplicada com "digitando…" (a bolha ao vivo ficava na tela durante a fala da resposta).
- Limite: o modelo é pequeno (1,5B); receitas longas podem sair simples ou imprecisas. Versão 61 / 1.19.0 (sem mudar o código da versão).

### v1.19.0 — Busca geral na web via Tavily (substitui a busca geral anterior)
**Não compilado e não testado em aparelho nem contra a API real — ver "Testes pendentes" abaixo.**
- Novo `localai/TavilySearch.kt`: cliente do Tavily (Basic por padrão, 1 crédito; Advanced, 2 créditos, só para perguntas de estudo/diretriz/"detalhado"), timeout, uma chamada por vez, cache (15 min notícias, 6 h demais), tratamento de vazio/erro/timeout/offline/chave inválida/cota.
- Novo `TavilyCredits`: contador local estimado por mês, limite configurável (padrão 1.000) e reserva de segurança (padrão 50). Reserva o crédito antes da chamada e acerta com o valor real devolvido pelo servidor. Bloqueia automaticamente ao atingir o limite.
- **A chave da Tavily não fica no app.** O APK só recebe o endereço de um proxy (`backend/tavily-proxy`, Cloudflare Worker) via `tavily.proxy.url` no `local.properties` ou variável `TAVILY_PROXY_URL`. A chave é segredo do servidor (`TAVILY_API_KEY`).
- O proxy fixa as opções do pedido (sem resposta gerada, sem conteúdo bruto, sem imagens, máx. 5 resultados) e, opcionalmente, mantém um contador global mensal (KV) para proteger a cota da conta.
- Saúde: domínios confiáveis (gov.br, OMS, NIH/PubMed, SBD etc.) são preferidos (`include_domains_mode: prefer`), sem excluir o resto da web.
- Privacidade: só a consulta já neutralizada (sem glicemia, dose, nome, e-mail etc.) sai do aparelho; o fluxo de consentimento existente foi mantido.
- Resposta com cargo estruturado (Wikidata) não gasta crédito do Tavily.
- Removida toda a integração anterior de busca geral (função, cabeçalho, BuildConfig e documentação).
- Alterados: `localai/CrisWebSearch.kt`, `localai/LocalAiSettings.kt`, `ui/screens/CrisLocalAiScreen.kt` (só o texto do card "Pesquisa online"), `app/build.gradle.kts`. Versão 61 / 1.19.0.

