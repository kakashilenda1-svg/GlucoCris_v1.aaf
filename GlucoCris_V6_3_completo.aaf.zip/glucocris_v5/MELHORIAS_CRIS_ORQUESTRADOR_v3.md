# Cris: orquestrador v3 (rodada final)

STATUS DE VALIDAÇÃO: NADA aqui foi compilado nem executado. O ambiente de entrega não tem Gradle, Kotlin, Android SDK nem
internet. Os testes foram escritos mas NÃO rodados; o APK NÃO foi gerado. Rode `./gradlew testDebugUnitTest assembleDebug`.

## O que mudou
1. Latência: Gemini e pesquisa disputam. Pesquisa útil primeiro => o Gemini tem 8 s (3 s se houve dado estruturado da Wikidata)
   e, passado isso, a resposta sai com os resultados prontos (nota "IA online estava demorando"). Nenhuma 2ª chamada Gemini.
   Cada pergunta roda num Job próprio e, ao responder, o que sobrou é cancelado SEM esperar o HTTP bloqueante.
2. Tavily: janela após Gemini+Google: 4 s (com fontes do Google) ou 6 s (sem fontes), antes 2,5 s. A chamada já enviada agora
   termina em NonCancellable: grava no cache e acerta créditos, em vez de perder o resultado.
3. IA local (CrisLocalReview): plano sem custo decide TRADUZIR / RESUMIR / CONTRADIÇÕES / CLAREZA numa ÚNICA chamada;
   clareza nunca dispara chamada sozinha; trechos curtos não disparam nada.
4. CrisAnswerCheck: veredito CONSISTENT / INCONCLUSIVE / WEAK / CONFLICT / NO_ANSWER (assunto por raízes de palavras, valores já
   normalizados, "não sei"). Aviso sempre como suspeita ("possível divergência", "não consegui confirmar"); fontes mantidas.
   Resposta de memória que as fontes confirmam não gasta mais uma chamada Gemini.
5. CrisFactGuard: aceita 5,42=5.42=R$ 5,42, 1.000=1000, 1,5 milhão=1.500.000, 12 de novembro de 2026=12/11/2026;
   rejeita número, data e dose (valor+unidade, só das fontes) inventados. Arredondar conta como inventar (conservador).
6. Concorrência: erro do Gemini por chamada (GeminiReply), não mais CrisGemini.lastError; cota diária atômica; ritmo da busca atômico.
7. Privacidade: (a) contexto de saúde nunca viaja junto com a ferramenta de pesquisa do Google (se a pergunta precisa do contexto,
   o Google fica desligado; senão o contexto fica de fora); (b) histórico com dados pessoais vira marcador quando o Google está ligado;
   (c) texto da consulta Wikidata redigido e limitado a 4 palavras (antes podia levar o resto da frase no fluxo autorizado).
8. Cotas e limites: inalterados; sem novas chaves, contas, provedores ou configurações.

## Arquivos
Novos: CrisAnswerCheck.kt, CrisFactGuard.kt, CrisLocalReview.kt, CrisFactGuardTest.kt, este .md
Alterados: CrisCloudOrchestrator.kt, TavilySearch.kt, CrisWebSearch.kt, data/CrisGemini.kt, ui/screens/CrisShared.kt, CrisCloudOrchestratorTest.kt

## Limitações conhecidas
- A tela do chat já bloqueia 2ª pergunta enquanto "pensando"; a resposta de tarefa em segundo plano ainda é gravada na lista da tela atual (não alterado).
- pendingConsent (autorização de pesquisa pessoal) continua um único espaço global: vale para a pergunta pessoal mais recente.
- Com contexto de saúde autorizado e pergunta pessoal, o Gemini responde sem Google e pode haver síntese (2ª chamada) se as fontes não confirmarem.
