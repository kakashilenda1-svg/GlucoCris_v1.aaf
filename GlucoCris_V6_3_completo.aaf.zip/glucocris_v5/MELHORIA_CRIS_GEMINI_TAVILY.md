# Cris: Gemini + Tavily + IA local (v2, paralelismo real)

## Diagnóstico da v1
A v1 iniciava a pesquisa, mas o Gemini esperava até 3,5 s por ela antes de começar: não era paralelismo real.

## Implementação (CrisCloudOrchestrator.kt, lógica pura e testável)
- Gemini (1ª geração) e pesquisa independente são lançados em sequência imediata, sem await entre eles (supervisorScope + async).
- Timeouts próprios: Gemini 60 s, pesquisa 15 s, síntese 40 s. Falha/timeout de um não cancela o outro.
- A 1ª geração NÃO recebe os resultados do Tavily (requisição já enviada não recebe nada depois).
- 2ª chamada ao Gemini (síntese com os resultados) só se: há resultados úteis E (a resposta não veio fundamentada no Google OU diverge das fontes) E a cota permite (>= 10 restantes no aparelho). Histórico enviado na síntese: só 4 mensagens.
- Sem cota/falha na síntese: IA local resume (se instalada; números inventados são descartados) ou os resultados reais são mostrados, rotulados como pesquisa.
- Gemini fora: a pesquisa que já estava rodando vira a resposta (IA local organiza, se instalada; senão resultados diretos com aviso e fontes).
- Pesquisa fora: Gemini responde; se a pergunta pedia dado atual e nada foi confirmado, a resposta avisa que não foi verificada.
- Tudo fora: mensagem honesta + botão "Tentar novamente".
- Cancela a pesquisa só quando o Gemini já respondeu com Google e a pesquisa passou de 2,5 s.

## Fontes (CrisSourceQuality)
Só https, sem duplicatas (URL normalizada sem utm/fbclid e título), oficiais/confiáveis primeiro, descarta resultados vazios, em outro idioma ou de outro assunto (filtros já existentes).

## Status (CrisServiceHealth)
Sem internet · Gemini sem cota/indisponível · busca sem cota/indisponível/não configurada · servidor da Cris indisponível · IA local não instalada/com erro.
Atualização atômica; estados com mais de 30 min expiram (relógio de 1 min no cabeçalho).

## Testes (nenhum foi executado no ambiente de entrega: sem Gradle/Kotlin)
- CrisCloudOrchestratorTest (tempo virtual, serviços simulados) e CrisServiceHealthTest.
- Não cobertos por teste automatizado: HTTP 429/chave inválida reais do Tavily (mapeamento em TavilySearch), Worker real, IA local real, histórico/contexto da conversa, fila de duas perguntas na tela.
