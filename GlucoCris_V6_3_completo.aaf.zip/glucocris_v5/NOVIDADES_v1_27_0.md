# Gluco Cris v1.27.0 — novidades (só acréscimos; nada foi removido)

Novas telas (Mais): Painel de padrões, Relatório médico (PDF), Resposta glicêmica por alimento,
Resumo semanal da Cris, Sensores (Libre, Dexcom, Nightscout) e Modo cuidador / família.

Arquivos novos: insights/ (Insights, MedicalPdf, WeeklyNotifier), sensors/SensorSync.kt,
reminders/Caregiver.kt, ui/screens/InsightScreens.kt.

Pequenas alterações em arquivos existentes: Routes, MainActivity (rotas + leitura automática),
HistoryMoreScreens (6 linhas novas em "Mais"), GlucoViewModel (importSensorEntries + aviso ao cuidador),
QuickGlucose (aviso ao cuidador), FoodVisionAi (scanner: prompt mais completo, 2ª leitura quando acha poucos
itens, nome detectado preservado), FoodSmartScannerScreen (botão Renomear), build.gradle.kts (versão 79 / 1.27.0).

Limites conhecidos: Dexcom Share e LibreLinkUp são serviços não oficiais (podem mudar); o aviso ao cuidador
abre SMS/WhatsApp com a mensagem pronta (envio por toque), sem servidor. NÃO foi compilado neste ambiente (sem rede):
compile no GitHub Actions e me envie o log se aparecer algum erro.
