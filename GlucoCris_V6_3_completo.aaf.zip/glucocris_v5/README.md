# Gluco Cris ❤️

Aplicativo Android (Kotlin + Jetpack Compose) de apoio ao dia a dia com diabetes: glicose, insulina,
lembretes, alimentação, hidratação (Cris Hidrata), relatórios e a assistente Cris IA.

> Uso de apoio. Não substitui orientação médica nem calcula dose de insulina.

## Compilar

```bash
./gradlew assembleDebug
```

O APK sai em `app/build/outputs/apk/debug/`.

## Configuração

- **Cris IA (Gemini + Tavily):** as chaves **Gemini** e **Tavily** ficam **somente** no Cloudflare Worker
  (`backend/tavily-proxy`), como segredos `GEMINI_API_KEY` e `TAVILY_API_KEY`. O APK **nunca** recebe essas chaves.
  Informe só o endereço do proxy: `tavily.proxy.url=https://SEU-PROXY.workers.dev` no `local.properties`
  (ou `TAVILY_PROXY_URL` no CI). Modelo opcional: `gemini.model=gemini-3.8-flash`.
  Sem o proxy o app continua funcionando com a IA local (Qwen/llama.cpp) e as demais fontes abertas.
  Ver instruções de deploy em `backend/tavily-proxy/README.md`.
- **Login com Google:** crie um *ID do cliente OAuth* do tipo **Android** no Google Cloud Console com
  o pacote `com.agon.app` e o SHA-1 da chave que assina o APK (use `./gradlew signingReport`). Com a
  tela de consentimento em modo teste, adicione os e-mails de teste.
- **Assinatura:** o projeto usa `debug.keystore` para que as atualizações mantenham o mesmo SHA-1 e os dados
  do usuário. Para publicar na Play Store use uma chave de upload própria (não versionada).

## Recursos

- Tour inteligente com voz e simulação (nada é salvo)
- Cris Hidrata com relógio inteligente, alerta de glicose alta e gotinha animada
- Temas claro/escuro e azul com cinza
- Humor com emojis ou figurinhas de bruxinho (personagem original)
