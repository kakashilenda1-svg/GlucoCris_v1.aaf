# Relatório — correção definitiva da biometria (v5)

Base: GlucoCris_BUILD_cris_paralelo_v4_biometria.zip. Atualização corretiva; o app não foi recriado.

## Estado da validação (leia primeiro)
- Compilação: NÃO executada. APK: NÃO gerado. Testes Gradle: NÃO executados. Motivo: o ambiente não tem Gradle, Kotlin, Android SDK nem rede.
- Revisão feita: equilíbrio de chaves/parênteses dos arquivos alterados e conferência cruzada de assinaturas e chamadas. Isso NÃO equivale a compilar.
- Biometria em aparelho real: NÃO testada.
- Para validar: `./gradlew testDebugUnitTest assembleDebug` ou o workflow existente do GitHub Actions; depois o roteiro em SEGURANCA_BIOMETRICA.md.

## Arquivos criados
- security/EnrollmentWatch.kt — aviso de mudança nas biometrias do Android (chave sentinela do Keystore)
- security/LegacyBiometricMigration.kt — executa a migração da opção antiga (plano puro em BiometricPolicy.kt: LegacyMigration)
- test/.../LegacyMigrationTest.kt, SessionScenariosTest.kt

## Arquivos modificados
- security/SessionLock.kt — sem tolerância fixa; política ao voltar do 2º plano; marca de sessão (SessionStamp); RecoveryThrottle
- security/SecurityCodec.kt — formato v2 (chave geral, digital, rosto, política); lê o v1; RelockPolicy
- security/SecurityPrefs.kt — grava v2, marca de sessão fora da memória, aviso da migração
- security/BiometricPolicy.kt — limitação de modalidade, recuperação por PIN, mensagens, plano de migração
- security/BiometricAuth.kt — estado por modalidade (digital via FingerprintManager; rosto só sensor)
- security/SecurityViewModel.kt — sessão nova x tela recriada, recuperação por PIN, aviso
- ui/screens/SecurityLockScreen.kt — disponibilidade, cadastro, recuperação por PIN
- ui/screens/SecuritySettings.kt — seção única "Bloqueio biométrico"
- ui/screens/MedsReportSettingsScreens.kt — removida a opção antiga; texto do PIN esclarecido
- ui/screens/LockScreen.kt — tela do PIN sem biometria fraca
- MainActivity.kt — política de segundo plano, marca de sessão, migração, ligação da tela de bloqueio
- data/GlucoViewModel.kt — biometria aprovada cobre a camada do PIN; removido unlockWithBiometric
- data/Models.kt — só comentário (campo biometricEnabled mantido como legado)
- AndroidManifest.xml — permissões normais USE_BIOMETRIC e USE_FINGERPRINT
- testes: SecurityCodecTest, SessionLockTest, BiometricPolicyTest, GateWiringTest
- SEGURANCA_BIOMETRICA.md reescrito

## Removido
- ui/screens/BiometricHelper.kt (biometria FRACA da opção antiga, duplicada com a nova)

## Testes escritos (NÃO executados)
Cobrem os 17 itens do prompt como simulação na JVM e verificação estrutural do código-fonte:
1 a 4 combinações digital/rosto (SecurityCodecTest, BiometricPolicyTest) · 5 a 8 nova abertura, processo encerrado/recriado, reinício
(SessionLockTest, SessionScenariosTest) · 9 minimizar/restaurar por política · 10 e 11 cancelar/recusar · 12 sem cadastro e 13 modalidade
não suportada/limitação (BiometricPolicyTest) · 14 migração (LegacyMigrationTest, SecurityCodecTest v1→v2) · 15 conteúdo atrás do bloqueio e
16 notificações/navegação (GateWiringTest) · 17 sem pedidos duplicados (SessionLockTest, GateWiringTest). Simulações não provam o
comportamento em aparelhos reais.

## Limitações técnicas
1. O Android não permite aceitar só digital ou só rosto (sem API pública). A tela diz isso e avisa quando a escolha não é garantida.
2. Cadastro de rosto: o Android não informa se há rosto cadastrado nem se é forte; só o sensor. Digital: informa pelo FingerprintManager (API antiga, documentada).
3. Sem biometria e sem PIN, o app fica bloqueado até cadastrar biometria (ou limpar os dados).
4. Política padrão ao voltar do 2º plano: 1 minuto (configurável). "Imediatamente" também pede ao voltar da câmera/galeria.
5. A mudança de biometrias do Android gera apenas um aviso.
6. Widget, notificações e registro rápido de glicemia só gravam um valor; não foram alterados.

## Preservação (conferido por comparação com o ZIP original)
Idênticos byte a byte: CrisCloudOrchestrator, CrisGemini, TavilySearch, CrisLocalReview, CrisFactGuard, CrisAnswerCheck, backend/ (Cloudflare Worker),
.github/workflows/build.yml e debug.keystore. applicationId (com.agon.app), minSdk 24, assinatura e versão não foram alteradas.
Gemini, Tavily e IA local continuam preservados; nenhum provedor, conta, chave ou Secret foi adicionado e nenhuma dependência nova foi incluída.
