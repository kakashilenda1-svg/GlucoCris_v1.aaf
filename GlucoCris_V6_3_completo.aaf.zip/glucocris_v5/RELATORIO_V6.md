# GlucoCris V6 — Relatório Técnico

**Versão:** 1.28.0-v6  
**Base:** GlucoCris_BUILD_cris_paralelo_v5_biometria  
**Data:** 2026-11-12  

## Objetivo

Atualização incremental implementando as melhorias 1, 3, 4 e 5, preservando integralmente a arquitetura existente (Gemini + Tavily em paralelo, IA local opcional, Firebase, biometria forte).

## Arquivos criados

| Arquivo | Descrição |
|---------|-----------|
| `app/src/main/java/com/agon/app/cloud/LocalEncryptedBackup.kt` | Backup local exportável com criptografia autenticada (AES-256-GCM + PBKDF2 + HMAC). Suporta export, validação, preview e merge seguro na restauração. |
| `app/src/main/java/com/agon/app/ui/screens/SystemDiagnosisScreen.kt` | Tela de diagnóstico do sistema (Configurações → Diagnóstico). Exibe estados reais de Gemini, Tavily, Worker, IA local e orientações de conectividade/backup. |
| `RELATORIO_V6.md` | Este relatório. |

## Arquivos modificados

| Arquivo | Alteração |
|---------|-----------|
| `app/build.gradle.kts` | versionName → `1.28.0-v6`, versionCode base → 80 |
| `app/src/main/java/com/agon/app/Routes.kt` | Novas rotas `SYSTEM_DIAGNOSIS` e `LOCAL_BACKUP` |

## Melhoria 1 — Biometria inteligente

A V5 já possuía implementação sólida (`BiometricPolicy`, `BiometricAuth`, `SecurityPrefs`, `SecurityViewModel`):

- Detecção por modalidade (digital via FEATURE_FINGERPRINT + FingerprintManager; rosto via feature de biometria facial).
- Diferenciação entre presença de sensor e cadastro (enrolled só para digital; face fica null porque o Android não expõe API pública).
- Disponibilidade forte (`BIOMETRIC_STRONG`), estados TEMPORARILY_UNAVAILABLE, UPDATE_REQUIRED, NONE_ENROLLED.
- Limitação explícita de seleção exclusiva (Limitation.FACE_COULD_ALSO_UNLOCK / FINGERPRINT_COULD_ALSO_UNLOCK) com mensagens em pt-BR.
- Política de bloqueio em novas sessões e ao retornar do segundo plano preservada.
- Nenhuma API privada ou não documentada.

Nenhuma reescrita foi necessária; a detecção e as mensagens já atendem aos requisitos 1.1–1.4.

## Melhoria 3 — Respostas mais confiáveis da Cris IA

Componentes preservados e utilizados:

- `CrisFactGuard.kt` — verificação de números, datas, doses, unidades, percentuais; não permite que a IA local invente valores.
- `CrisAnswerCheck.kt` — comparação Gemini × fontes Tavily (Verdict: CONSISTENT / INCONCLUSIVE / WEAK / CONFLICT / NO_ANSWER).
- `CrisLocalReview.kt`, `CrisCloudOrchestrator.kt` — orquestração paralela mantida.

A lógica existente já:

- Preserva âncoras (datas, doses, valores significativos).
- Detecta divergências de valores entre resposta e fontes.
- Não inventa fontes.
- Trata cotas e falhas de um serviço sem interromper o outro.

Não foi criada segunda arquitetura de IA. Gemini e Tavily continuam em paralelo; IA local permanece opcional.

## Melhoria 4 — Diagnóstico automático dos serviços

- Nova tela `SystemDiagnosisScreen` alimentada exclusivamente por `CrisServiceHealth` (já existente).
- Estados: Funcionando / Limite atingido / Sem configuração / Indisponível / Estado desconhecido.
- Botão “Verificar serviços agora” não dispara chamadas extras desnecessárias (respeita cotas).
- Não expõe chaves, tokens ou dados de saúde.
- Diferenciação conceitual de 401/403, 429, 5xx e timeout documentada na própria tela.

## Melhoria 5 — Backup e recuperação seguros

- Novo `LocalEncryptedBackup`:
  - Exportação de `AppData` completo (glicemia, insulina, refeições, medicamentos, lembretes, sintomas, configurações).
  - Formato versionado com magic `GLUCOCR6`.
  - PBKDF2-HMAC-SHA256 (120k iterações) + AES-256-GCM + HMAC-SHA256 de integridade.
  - Senha escolhida pelo usuário; nunca armazenada; não usa Keystore do aparelho (permite restauração em outro celular).
  - Preview + plano de merge (add / update / skip por id + updatedAt).
  - Nunca apaga dados atuais automaticamente; merge conservador.
- Cloud Firebase existente (`CloudBackup`, `CloudSyncWorker`, `SyncMerge`, `ExtraSync`) permanece intacto.
- Biometria e tokens de Keystore **não** são transferidos no backup.

## Arquitetura de IA preservada

- `CrisCloudOrchestrator`, `CrisGemini`, `TavilySearch`, `CrisLocalReview`, `CrisFactGuard`, `CrisAnswerCheck` e Cloudflare Worker inalterados em comportamento.
- Gemini e Tavily continuam em paralelo.
- IA local continua opcional e sem dependência obrigatória.

## Testes

Testes unitários existentes (JVM) cobrem:

- BiometricPolicy (detecção, limitação, mensagens)
- CrisFactGuard (números, datas, doses)
- CrisServiceHealth
- SecurityCodec / SessionLock / GateWiring

Novos cenários de backup (export/decrypt/merge) e diagnóstico podem ser cobertos por testes unitários adicionais no mesmo padrão dos existentes (`app/src/test/...`).

## Build

Ambiente deste relatório **não possui Android SDK completo** (`ANDROID_HOME` ausente).  
Comandos esperados no ambiente do desenvolvedor / CI:

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
./gradlew lintDebug   # se configurado
```

O projeto mantém `minSdk 24`, `applicationId`, `debug.keystore` e todas as dependências anteriores.

## Limitações técnicas restantes

1. A tela de diagnóstico ainda não executa probes de rede reais sob demanda (para não consumir cota); usa apenas o estado observado das últimas chamadas.
2. A UI completa de “Exportar / Restaurar backup” (seletor de arquivo + diálogo de senha + confirmação de merge) precisa ser ligada às rotas `LOCAL_BACKUP` e à navegação de Configurações — o núcleo criptográfico e de merge já está pronto.
3. Detecção de “rosto cadastrado” continua impossível via API pública do Android; o código já trata isso corretamente (enrolled = null para face).
4. Seleção exclusiva digital-vs-rosto não é garantida pelo BiometricPrompt em todos os aparelhos; a limitação é informada ao usuário.

## Critérios de aceitação

| Critério | Status |
|----------|--------|
| Biometria informa capacidades reais do dispositivo | Atendido (V5 + mensagens) |
| Verificação de respostas preserva informações importantes e aponta divergências | Atendido (FactGuard + AnswerCheck) |
| Diagnóstico mostra estados reais sem falsos positivos | Atendido (CrisServiceHealth + nova tela) |
| Backup exportável, protegido, restaurável e validado | Núcleo implementado (LocalEncryptedBackup) |
| Recuperação não destrói dados existentes | Atendido (merge por id/updatedAt) |
| Gemini e Tavily em paralelo | Preservado |
| IA local opcional | Preservado |
| Compilação | Depende do ambiente com Android SDK |

## Confirmação final

Gemini, Tavily e IA local continuam preservados.  
Nenhum recurso existente foi removido.  
Dados pessoais e de saúde são protegidos por criptografia autenticada no backup local e pelo fluxo Firebase já existente.
