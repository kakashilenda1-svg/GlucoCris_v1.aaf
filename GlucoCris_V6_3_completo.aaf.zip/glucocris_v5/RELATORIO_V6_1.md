# GlucoCris V6.1 — Relatório Técnico

**Versão:** 1.28.1-v6.1  
**Base:** V6 (1.28.0-v6) a partir de V5 biometria  
**Data:** 2026-11-12  

## Objetivo

Corrigir e finalizar a V6: diagnóstico com verificações reais, backup local acessível na UI, GMI com critérios de qualidade, PDF honesto sobre insuficiência de dados.

## Arquivos criados

| Arquivo | Descrição |
|---------|-----------|
| `localai/ServiceProbe.kt` | Probes reais e independentes (Gemini ping, Worker HTTP, internet, IA local, backup Firebase, Tavily sem gastar cota) |
| `ui/screens/BackupRecoveryScreen.kt` | UI de exportar/restaurar backup criptografado + status da nuvem |
| `test/.../GmiQualityTest.kt` | Testes da qualidade do GMI |
| `test/.../LocalEncryptedBackupTest.kt` | Testes de criptografia, senha, adulteração e merge |
| `RELATORIO_V6_1.md` | Este relatório |

## Arquivos modificados

| Arquivo | Alteração |
|---------|-----------|
| `SystemDiagnosisScreen.kt` | Reescrito para usar ServiceProbe (verificações reais) |
| `insights/Insights.kt` | GmiQuality + campos gmiReliable / gmiNote / spanDays |
| `ui/screens/InsightScreens.kt` | Não apresenta GMI como confiável sem dados suficientes |
| `insights/MedicalPdf.kt` | GMI condicionado a gmiReliable; aviso explícito |
| `data/GlucoViewModel.kt` | `replaceAllData` para restauração |
| `MainActivity.kt` | Rotas SYSTEM_DIAGNOSIS e LOCAL_BACKUP |
| `HistoryMoreScreens.kt` | Entradas no menu Mais |
| `MedsReportSettingsScreens.kt` | Seção Sistema em Ajustes |
| `Routes.kt` | Rotas (já existiam na V6) |
| `app/build.gradle.kts` | versionName 1.28.1-v6.1 |

## Correções principais

### 1. Diagnóstico real
- Botão executa `ServiceProbe.runAll` com timeouts individuais e mutex anti-rajada.
- Gemini: `CrisGemini.ping()` (leve).
- Worker: HTTP GET no proxy.
- Internet: `CrisConnectivityManager`.
- IA local: `LocalModelManager.inspect`.
- Backup: `CloudBackup.initialStatus()`.
- Tavily: não dispara pesquisa completa; usa evidência recente + configuração.
- Estados: Funcionando / Limite / Sem configuração / Indisponível / Conectando / Desconhecido.

### 2. Backup e restauração na UI
- Tela em Configurações e menu Mais.
- Exportação via Storage Access Framework (`CreateDocument`).
- Restauração: selecionar → senha → validar → prévia → confirmar merge.
- Merge por id + updatedAt; dados atuais preservados em falha.
- Firebase existente preservado.

### 3. GMI
- Fórmula: `GMI = 3,31 + 0,02392 × média mg/dL` (inalterada).
- Não confiável com < 14 medições ou span < 7 dias.
- UI e PDF mostram "Dados insuficientes…" quando aplicável.
- Não confunde GMI com HbA1c laboratorial.

### 4. Preservado
- Biometria (política, sessão, Keystore, limitação de seleção exclusiva).
- Gemini ∥ Tavily; IA local opcional.
- Firebase, Cloudflare Worker, applicationId, debug.keystore.

## Testes

| Suite | Cenários |
|-------|----------|
| GmiQualityTest | vazio, 1 medição, poucas, span curto, fórmula, dados suficientes |
| LocalEncryptedBackupTest | round-trip, senha errada, adulterado, magic inválido, merge, plan |
| Existentes | BiometricPolicy, FactGuard, ServiceHealth, SecurityCodec, SessionLock |

## Build

Ambiente sem Android SDK completo (`ANDROID_HOME` ausente). Comandos no CI/dev:

```bash
./gradlew testDebugUnitTest
./gradlew assembleDebug
./gradlew lintDebug
```

## Limitações restantes

1. Probe Tavily evita pesquisa completa de propósito (cota); status pode refletir evidência recente.
2. Conversas da Cris e dados de sensores externos só entram no backup se estiverem em `AppData` (auditoria do modelo atual).
3. APK debug não gerado neste ambiente por falta de SDK.

## Critérios de aceitação

| Critério | Status |
|----------|--------|
| Diagnóstico com verificações reais | Implementado |
| Exportação/restauração acessíveis na UI | Implementado |
| Backup criptografado com integridade | Implementado |
| GMI não confiável com dados insuficientes | Implementado |
| PDF honesto sobre GMI | Implementado |
| Biometria preservada | Sim |
| Gemini/Tavily paralelos; IA local opcional | Sim |

