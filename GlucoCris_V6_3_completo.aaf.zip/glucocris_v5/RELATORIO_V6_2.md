# GlucoCris V6.2 — Relatório Técnico

**Versão:** 1.28.2-v6.2  
**Base:** V6.1 (1.28.1-v6.1)  
**Data:** 2026-11-12  

## Escopo

Correções pontuais somente nos itens 3 (backup), 4 (GMI glicosímetro/CGM), 5 (PDF), 6 (testes) e 7 (validação).  
Nenhuma funcionalidade da V6.1 foi removida ou reescrita fora desse escopo.

## Arquivos modificados

| Arquivo | Alteração |
|---------|-----------|
| `cloud/LocalEncryptedBackup.kt` | Limites de tamanho cifrado/descompactado, `safeGunzip`, limite de registros, mensagens sem vazar senha |
| `ui/screens/BackupRecoveryScreen.kt` | Removido `restoreHolder` global; estado só na composição; senha oculta com opção mostrar/ocultar; leitura com teto de bytes |
| `insights/Insights.kt` | `DataOrigin` (METER/CGM/MIXED), cobertura CGM, `timeInRangeMeaningful`, critérios distintos de GMI |
| `insights/MedicalPdf.kt` | "Distribuição das medições por faixa" vs "Tempo nas faixas"; nomenclatura GMI (não HbA1c) |
| `ui/screens/InsightScreens.kt` | Mesma nomenclatura e avisos da origem dos dados |
| `test/.../GmiQualityTest.kt` | Cenários meter/CGM/cobertura/fórmula |
| `test/.../LocalEncryptedBackupTest.kt` | Senha, adulteração, truncado, oversized, ZIP bomb via safeGunzip, merge |
| `app/build.gradle.kts` | versionName `1.28.2-v6.2` |

## 1. Segurança do backup

- **Sem estado global:** `pendingRestore` e `plan` vivem no `remember` da tela; limpos em cancelar/concluir/falha.
- **Limites:** arquivo ≤ 40 MB; JSON descompactado ≤ 32 MB; ≤ 200 000 registros/coleção.
- **ZIP bomb:** `safeGunzip` interrompe se a expansão ultrapassar o teto.
- **Integridade:** HMAC + GCM antes de qualquer merge.
- **Senha:** campos com `PasswordVisualTransformation`; não vai para logs/prefs/mensagens de erro; `CharArray.fill(0)` após uso.
- **Falha:** merge só após validação; cancelamento não altera dados; `replaceAllData` só após confirmação.

## 2. GMI — glicosímetro vs CGM

- Origem detectada por `id` `sensor-*` ou notes contendo "Sensor" (como já grava `SensorClient.toEntries`).
- **Glicosímetro:** GMI só com ≥14 medições, span ≥7 dias e ≥5 dias distintos; percentuais = distribuição das medições; **não** "tempo nas faixas".
- **CGM:** cobertura estimada (288 amostras/dia); "tempo nas faixas" só com cobertura ≥70% e span adequado.
- Nomenclatura explícita: **GMI (Indicador de Gerenciamento da Glicose)** — não é HbA1c laboratorial.
- Fórmula inalterada: `3,31 + 0,02392 × média mg/dL` (com conversão via `toMgDl`).

## 3. PDF e tela

- Mesma função `Insights.stats` alimenta tela e PDF (consistência).
- Seção de faixas: título condicionado a `timeInRangeMeaningful`.
- Seções sem dados suficientes não afirmam resultados inventados.

## 4. Testes

Incluídos no projeto:

- GMI: vazio, 1 ponto, poucos, span curto, meter suficiente, CGM baixa/alta cobertura, detecção sensor, fórmula.
- Backup: round-trip, senha errada, adulterado, magic inválido, truncado, oversized, safeGunzip, merge, plan, merge vazio.

## 5. Build / validação neste ambiente

| Comando | Resultado |
|---------|-----------|
| `./gradlew testDebugUnitTest` | **Não concluído** — daemon Gradle encerrou inesperadamente (ambiente sem Android SDK completo / possível OOM) |
| `./gradlew lintDebug` | **Não executado** (mesmo motivo) |
| `./gradlew assembleDebug` | **Não executado** — `ANDROID_HOME` ausente |

**Não foi possível gerar APK debug neste ambiente.**  
No ambiente do desenvolvedor/CI com SDK:

```bash
bash ./gradlew testDebugUnitTest --no-daemon
bash ./gradlew lintDebug --no-daemon
bash ./gradlew assembleDebug --no-daemon
```

## Preservação V6.1 → V6.2

Confirmado por inspeção de código (não por instalação em aparelho):

- Biometria, Gemini∥Tavily, IA local, Firebase, Worker, diagnósticos, gráficos, navegação e assinatura permanecem.
- Nenhuma dependência nova adicionada.
- Nenhuma tela ou rota existente removida.

## Limitações restantes

1. Classificação CGM depende do prefixo `sensor-` / notes "Sensor" já usados pelo app; registros manuais frequentes não são tratados como CGM.
2. Cobertura CGM é estimada (288 amostras/dia), não usa timestamps de lacunas explícitas do fabricante.
3. Build/APK e instalação física **não validados** neste ambiente.
4. Testes unitários escritos mas não executados com sucesso aqui (falha de infraestrutura Gradle/SDK).

