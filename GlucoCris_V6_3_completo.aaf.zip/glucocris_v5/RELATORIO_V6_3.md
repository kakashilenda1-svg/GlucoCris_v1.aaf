# GlucoCris V6.3 — Relatório Técnico

**Versão:** 1.28.3-v6.3  
**Base:** V6.2 (1.28.2-v6.2)  
**Data:** 2026-11-12  

## Escopo

Correção definitiva de três módulos apenas:

1. Backup e criptografia  
2. GMI e cobertura CGM  
3. Relatório médico PDF  

Nenhuma outra área (IA, biometria, Firebase, navegação, Worker) foi alterada.

## Arquivos modificados

| Arquivo | Alteração |
|---------|-----------|
| `cloud/LocalEncryptedBackup.kt` | `finally` zera senha e chaves derivadas em export/decrypt; limites e `safeGunzip` mantidos |
| `insights/Insights.kt` | CGM só por `id` `sensor-*` (não por notes); cobertura por intervalo mediano real e lacunas; GMI CGM exige 14 dias + ≥70% cobertura conhecida |
| `test/.../GmiQualityTest.kt` | Novos cenários: notes≠CGM, mmol/L, cobertura, concentração horária |
| `test/.../LocalEncryptedBackupTest.kt` | Verifica limpeza de senha; compatibilidade formato V6.2 |
| `app/build.gradle.kts` | versionName `1.28.3-v6.3` |

## Módulo 1 — Backup

- Senha (`CharArray`) e chaves derivadas limpas em **`finally`** (sucesso, falha, retorno antecipado).
- AES-256-GCM + PBKDF2-HMAC-SHA256 (120 000 it.) + salt/IV aleatórios + HMAC — formato `GLUCOCR6` v1 inalterado (backups V6.2 legíveis).
- Limites: cifrado ≤40 MB, plain ≤32 MB, ≤200 000 registros/coleção; descompressão com teto (ZIP bomb).
- Restauração: validar → prévia → confirmação → merge; falha não altera dados atuais.
- UI: senha oculta, mostrar/ocultar, sem estado global entre operações.

## Módulo 2 — GMI / CGM

| Regra | V6.3 |
|-------|------|
| Origem CGM | **Somente** `id.startsWith("sensor-")` (como grava o import de sensor). Notes com “Sensor” **não** classificam CGM. |
| Cobertura | Intervalo mediano entre amostras; lacunas >2× mediana não contam; se intervalo fora de 0,5–20 min → cobertura **desconhecida** (não inventa 288/dia). |
| GMI CGM | 14 dias de período + cobertura ≥70% **conhecida** + ≥10 dias distintos. |
| GMI glicosímetro | ≥14 medições, span ≥7 dias, ≥5 dias distintos; sem métricas de tempo. |
| Fórmula | `3,31 + 0,02392 × média mg/dL`; mmol/L via `× 18,0182` antes. |
| Nomenclatura | “O GMI é uma estimativa… Não equivale à HbA1c laboratorial.” |
| Média | Sempre exibida quando há medições; independente da confiabilidade do GMI. |

## Módulo 3 — PDF

- Mesma `Insights.stats` / `GmiQuality.assess` da tela.
- Título: “Distribuição das medições por faixa” (glicosímetro) vs “Tempo nas faixas (dados de sensor)” só se `timeInRangeMeaningful`.
- GMI omitido/insuficiente sem inventar valores; média permanece.

## Testes

Incluídos no ZIP (execução neste ambiente **não** concluída — ver abaixo):

- Backup: round-trip, senha, adulteração, truncado, oversized, safeGunzip, merge, limpeza de senha, formato V6.2.
- GMI: fórmula, mmol/L, meter, CGM baixa cobertura, concentração, intervalo inválido, notes≠CGM.

## Build / validação neste ambiente

| Comando | Resultado |
|---------|-----------|
| `testDebugUnitTest` | **Não validado** — ambiente sem Android SDK completo; daemon Gradle instável na tentativa anterior |
| `lintDebug` | **Não executado** |
| `assembleDebug` | **Não executado** (`ANDROID_HOME` ausente) |
| **APK** | **Não gerado** |

No ambiente com SDK:

```bash
bash ./gradlew testDebugUnitTest --no-daemon
bash ./gradlew lintDebug --no-daemon
bash ./gradlew assembleDebug --no-daemon
```

## Preservação V6.2 → V6.3

Inalterado por inspeção de código: biometria, Gemini∥Tavily, IA local, Firebase, Worker, diagnósticos, navegação, assinatura, identidade visual. Nenhuma dependência nova.

## Limitações restantes

1. Sem campo `source` explícito no `GlucoseEntry`; CGM depende do prefixo de id do import de sensor.  
2. Cobertura CGM usa mediana dos deltas (não metadados de fabricante).  
3. Build/APK e testes Gradle **não executados com sucesso** neste ambiente.  
4. A JVM não garante apagamento completo de senhas da memória (heap); o código zera os `CharArray`/`ByteArray` que controla.

