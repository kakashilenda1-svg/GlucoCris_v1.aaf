# Gluco Cris ❤️ — v1.22.0 (etapas 1 e 2)

applicationId `com.agon.app` mantido. Código NÃO compilado e NÃO testado em aparelho (o ambiente de build não tinha Android SDK nem internet). Compile com `./gradlew assembleDebug` e teste antes de distribuir.

## Etapa 1 — IA adaptativa e downloads
- `localai/ModelAdvisor.kt` (novo): lê RAM, processador (ABI) e espaço; recomenda Rápida (1,5B) ou Precisa (3B); avisos; escolha manual continua livre.
- Tela "IA da Cris": recomendação, explicação das opções, avisos, velocidade do download, botão Cancelar.
- Download: retentativas automáticas (6x) e retomada do parcial, velocidade, Cancelar na notificação.

## Etapa 2 — Perguntas da Cris em segundo plano
- `localai/CrisBackgroundTasks.kt` (novo): cada pergunta vira uma tarefa com id único, salva em disco (pergunta, conversa, horário, estado EM ANDAMENTO/CONCLUÍDA/ERRO). Roda fora da tela, mantida viva por um serviço em primeiro plano (`CrisTaskService`); não mantém tela/CPU ligadas.
- Ao terminar com o app fora da tela: notificação "💜 Cris IA terminou sua pesquisa! Toque para ver a resposta." (sem duplicar; som opcional). Toque abre a conversa correta.
- Chat: menu ⋮ > "Tarefas da Cris" (andamento, concluídas, erro, horário, "Tentar de novo", "Limpar"). Pede permissão de notificação (Android 13+) uma vez.
- Ajustes da IA: interruptores "Avisar quando terminar" e "Som no aviso".
- Tarefas online usam o fluxo atual (Tavily/Gemini via proxy); sem internet usa o modelo local, sem converter offline em online.

## Central de ajuda
- Tour já podia ser iniciado manualmente e repetido; mantido. Novos passos: conversa da Cris, menu/tarefas, modelos.
- Novos botões "Tutoriais por recurso" (água, glicose, insulina, lembretes, histórico, alimentação, perfil/conta, Cris IA/modelos, outros) que rodam só aquela seção, em simulação.
- Simulação protegida: no chat da Cris, enviar/apagar/trocar conversa ficam desativados durante o tour.

## Limitações (honestas)
- Não usei WorkManager: o fluxo da Cris depende do ViewModel do app, então usei serviço em primeiro plano + estado salvo. Se o Android encerrar o processo ou o app for forçado a parar, a tarefa fica "interrompida" e pode ser reenviada com um toque (não retoma sozinha após reiniciar o aparelho).
- Android 15+ limita serviços dataSync por dia.
- Se a pessoa sair e voltar à conversa enquanto a tarefa roda e enviar outra mensagem na mesma conversa, a gravação pode sobrescrever (caso raro, não tratado).
- Tutoriais cobrem as telas listadas; scanner de prato, código de barras, receitas e planos têm só o passo geral de Alimentação.

## Ainda não feito
- Backup Google com Firebase Spark (precisa criar o projeto e o `google-services.json`).
- Hash SHA-256 oficial dos modelos.
- Nenhum serviço pago foi habilitado ou adicionado.

## Firebase (configuração)
- `app/google-services.json` incluído (projeto `gluco-cris`, pacote `com.agon.app` conferido).
- Plugin `com.google.gms.google-services` 4.4.3 (raiz e app) e dependências via BoM 34.0.0: `firebase-auth` e `firebase-firestore`. Sem Analytics. Nenhum recurso pago; plano Spark mantido.
- Versões não puderam ser verificadas offline; se o Gradle reclamar, ajuste para a versão atual.
- PENDENTE no console: o JSON veio sem cliente OAuth (lista vazia) — cadastre o SHA-1 do `debug.keystore` (4D:DB:07:75:25:B3:C4:84:A1:ED:F1:2C:07:8F:55:BA:2F:93:CE:AC), ative o provedor Google em Authentication e baixe o JSON de novo.
- O código de sincronização/backup ainda não foi escrito.
