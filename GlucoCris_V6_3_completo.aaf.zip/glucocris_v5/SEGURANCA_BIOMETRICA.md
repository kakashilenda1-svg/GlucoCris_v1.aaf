# Bloqueio biométrico (Configurações → Segurança e privacidade → Bloqueio biométrico)

STATUS: NÃO compilado, testes NÃO executados, APK NÃO gerado (o ambiente onde esta atualização foi feita não tem Gradle,
Kotlin, Android SDK nem acesso à internet). Rode `./gradlew testDebugUnitTest assembleDebug` (ou o GitHub Actions) e teste
no aparelho com o roteiro abaixo. Nada aqui foi testado em aparelho físico.

## Comportamento
- **Toda nova abertura pede biometria** (app fechado e aberto de novo, processo encerrado, Android recriando o processo,
  forçar parada, celular reiniciado). Não existe tolerância de tempo para uma nova abertura: a sessão nasce bloqueada
  (`SessionLock.start`) e só uma autenticação aprovada libera.
- Além da variável em memória, há uma **marca de sessão** guardada fora da memória (`token do processo | contagem de
  inicializações do aparelho`). Ao voltar ao primeiro plano, marca de outro processo ou de antes de um reinício = bloqueia.
  A marca é apagada quando uma sessão nova começa.
- **Voltar do segundo plano** segue a política escolhida: Imediatamente / 30 s / 1 min (padrão) / 5 min. Girar a tela não conta.
- Cancelar, recusar, erro, botão voltar, recriar a tela, notificação ou atalho: continuam bloqueados.
- Uma única janela de biometria por vez (trava no `BiometricAuth` + `SessionLock`); sem laço de pedidos depois de cancelar.

## Configurações (uma única seção)
- **Bloqueio biométrico** (chave geral), **Impressão digital**, **Reconhecimento facial**: as duas modalidades podem ficar
  ligadas, só uma, ou nenhuma. Chave geral desligada ou nenhuma modalidade ligada = o app abre normalmente.
- Mostra a disponibilidade de cada modalidade (sensor presente; digital cadastrada quando o Android informa; rosto: só o sensor)
  e a disponibilidade geral da biometria forte; orientação e atalho para cadastrar biometria no Android.
- Ligar algo exige autenticar (prova que funciona e evita trancar). Com a proteção ativa, qualquer alteração exige autenticar.
  Exceção: se a biometria do aparelho foi removida e a pessoa entrou pelo PIN de recuperação, pode ajustar sem biometria.
- A antiga opção **"Entrar com digital ou rosto"** (biometria fraca, só trocava o teclado do PIN) foi **migrada uma vez** para cá e
  removida da tela de PIN. Se o aparelho não tem biometria forte, ela NÃO liga o bloqueio novo (não tranca ninguém), é desligada
  e a tela de segurança explica o motivo; o PIN continua valendo.

## PIN (camada à parte, mantido)
O PIN de 4 dígitos continua sendo uma proteção adicional e independente. Com o bloqueio biométrico ligado, a biometria aprovada ao
abrir também libera a camada do PIN (como a antiga opção fazia). O PIN também serve de **recuperação**, e só quando a biometria
do aparelho deixou de existir (removida, sem hardware, sem suporte); nunca por cancelar, recusar ou bloqueio temporário, e com
limite de 5 tentativas por minuto.

## Limitação técnica (Android)
Não existe API pública para aceitar SÓ a digital ou SÓ o rosto: o `BiometricPrompt` aceita qualquer biometria FORTE cadastrada.
Não foram usadas APIs privadas. As chaves expressam a escolha e conferem se o aparelho oferece a modalidade; a tela mostra um aviso
quando a escolha não pode ser garantida (aparelho com os dois sensores e só um ligado). Rosto classificado como fraco nunca é aceito.

## Segurança
- Só `BIOMETRIC_STRONG`; sem credencial do aparelho. Nenhuma imagem, impressão ou modelo biométrico é lido ou guardado.
- Preferências assinadas por HMAC do Android Keystore (arquivo `gluco_security_v1`, fora do backup). Assinatura inválida =
  proteção ligada com as duas modalidades e bloqueio imediato (falha fechando). Lê também o formato v1 da versão anterior.
- Aviso de mudança nas biometrias do Android: uma chave sentinela do Keystore (invalidada pelo sistema quando as biometrias mudam)
  mostra um aviso na tela de bloqueio. É só aviso; não libera nem bloqueia sozinha.
- Janela com FLAG_SECURE enquanto bloqueado; miniatura dos apps recentes desligada; nada do app é composto enquanto bloqueado.
- Nunca desativa a proteção em silêncio: se a biometria deixar de estar disponível, o app continua bloqueado com mensagem clara.

## Limites conhecidos (honestos)
- Exclusividade digital/rosto: ver acima.
- Sem biometria disponível e sem PIN: o app fica bloqueado até cadastrar biometria de novo (ou limpar os dados do app).
- Com a política "Imediatamente", trocar para a câmera/galeria e voltar também pede biometria (o app sai de primeiro plano).
- Fora do escopo: widget da tela inicial, notificações e a janelinha de registro rápido de glicemia (só gravam um valor, não leem dados).

## Roteiro no aparelho
digital · rosto forte · ambos · nenhum · sem cadastro · aparelho sem sensor · cancelar · recusar até bloquear · minimizar em cada
política · matar o app e abrir · forçar parada · reiniciar o celular · "não manter atividades" (recriação) · botão voltar na tela de
bloqueio · girar a tela · ligar/desligar com proteção ativa · remover a biometria do Android com a proteção ligada (com e sem PIN) ·
adicionar uma digital nova e abrir (aviso de mudança) · atualizar de uma versão com "Entrar com digital ou rosto" ligado.
