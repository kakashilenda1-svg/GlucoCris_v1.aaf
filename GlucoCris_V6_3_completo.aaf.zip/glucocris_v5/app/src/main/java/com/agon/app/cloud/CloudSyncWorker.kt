package com.agon.app.cloud

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.agon.app.data.GlucoStorage
import com.agon.app.data.GlucoViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

/**
 * Sincronização em segundo plano: de tempos em tempos, com internet, envia o que ainda estiver pendente
 * (mesmo com o app fechado). Sem pendências não faz nenhuma chamada de rede.
 */
class CloudSyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            // App aberto (ou ainda na memória): quem sincroniza é o ciclo normal do app, que também aplica o que vem da nuvem.
            val live = GlucoViewModel.liveInstance()
            if (live != null) {
                withContext(Dispatchers.Main) { live.syncNow() }
                return Result.success()
            }
            val data = GlucoStorage.read(applicationContext) ?: return Result.success()
            CloudBackup(applicationContext).backgroundPush { data }
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            Result.success() // tenta de novo no próximo ciclo; nada local foi alterado
        }
    }
}

object CloudSyncScheduler {
    private const val PERIODIC = "gluco_cloud_sync_periodic"
    private const val ONCE = "gluco_cloud_sync_once"
    private val NEEDS_NET = Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()

    /** Liga a sincronização periódica (a cada 30 min, só com internet). Pode ser chamada várias vezes. */
    fun ensurePeriodic(ctx: Context) {
        try {
            val req = PeriodicWorkRequestBuilder<CloudSyncWorker>(30, TimeUnit.MINUTES)
                .setConstraints(NEEDS_NET)
                .build()
            WorkManager.getInstance(ctx.applicationContext)
                .enqueueUniquePeriodicWork(PERIODIC, ExistingPeriodicWorkPolicy.KEEP, req)
        } catch (_: Exception) {
        }
    }

    /** Pede um envio logo que houver internet (usado depois de registros feitos fora do app, como o atalho rápido). */
    fun kickOnce(ctx: Context) {
        try {
            val req = OneTimeWorkRequestBuilder<CloudSyncWorker>().setConstraints(NEEDS_NET).build()
            WorkManager.getInstance(ctx.applicationContext).enqueueUniqueWork(ONCE, ExistingWorkPolicy.REPLACE, req)
        } catch (_: Exception) {
        }
    }
}
