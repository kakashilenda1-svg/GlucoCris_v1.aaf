package com.agon.app.cloud

import android.content.Context
import com.agon.app.localai.CrisConversation
import com.agon.app.localai.CrisConversationStore
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

/**
 * Backup do que antes ficava só no aparelho: água, favoritos, fatores/histórico de bolus e conversas da Cris IA.
 *
 * - água, favoritos e bolus: um documento "instantâneo" por tipo (id fixo "main"), com as chaves das
 *   SharedPreferences listadas em [SNAPSHOTS]. O carimbo (updatedAt) é o momento em que a mudança foi percebida;
 * - conversas: um documento POR conversa (tipo "conversations", id = id da conversa). Assim uma conversa muito
 *   grande não derruba as outras (cada registro é isolado).
 *
 * Mesma regra do resto do backup: o armazenamento local é a fonte da verdade; nada local é apagado por erro de rede.
 */
object ExtraSync {
    const val WATER = "water"
    const val FAVORITES = "favorites"
    const val BOLUS = "bolus"
    const val CONVERSATIONS = "conversations"
    const val SNAP_ID = "main"

    val TYPES = setOf(WATER, FAVORITES, BOLUS, CONVERSATIONS)

    /** Limite do payload (bytes UTF-8) dos tipos novos. O Firestore aceita 1 MiB por documento; as regras aceitam 800.000. */
    const val MAX_PAYLOAD_BYTES = 800_000

    private const val META = "cloud_extras"
    private const val TOMB_KEY = "conv_tombs"
    private const val TOMB_KEEP_MS = 90L * 24 * 3_600_000L

    private class Key(val file: String, val key: String, val kind: Char) // s=texto, S=conjunto de textos, f=float, i=int, b=boolean

    private val SNAPSHOTS: Map<String, List<Key>> = mapOf(
        WATER to listOf(
            Key("gluco_water_v1", "entries_json", 's'),
            Key("gluco_water_v1", "goal_ml", 'i'),
            Key("gluco_water_v1", "fav_cups", 's'),
        ),
        FAVORITES to listOf(
            Key("gluco_food_tools", "fav_meals_json", 's'),
            Key("gluco_food_prefs", "favorites", 'S'),
            Key("gluco_recipe_prefs", "fav_recipe_ids", 'S'),
        ),
        BOLUS to listOf(
            Key("gluco_food_tools", "bolus_factors_json", 's'),
            Key("gluco_food_tools", "bolus_hist_json", 's'),
            Key("gluco_food_tools", "bolus_round_step", 'f'),
        ),
    )

    private fun meta(ctx: Context) = ctx.applicationContext.getSharedPreferences(META, Context.MODE_PRIVATE)

    // ---------- Instantâneos (água, favoritos, bolus) ----------

    /** Lê as chaves que existem de fato. Devolve null se o aparelho ainda não tem nenhuma (nada a enviar). */
    private fun readSnapshot(ctx: Context, type: String): String? {
        val keys = SNAPSHOTS[type] ?: return null
        val arr = JSONArray()
        for (k in keys) {
            val sp = ctx.applicationContext.getSharedPreferences(k.file, Context.MODE_PRIVATE)
            if (!sp.contains(k.key)) continue
            val item = JSONObject().put("f", k.file).put("k", k.key).put("t", k.kind.toString())
            try {
                when (k.kind) {
                    's' -> item.put("v", sp.getString(k.key, "") ?: "")
                    'S' -> item.put("v", JSONArray((sp.getStringSet(k.key, emptySet()) ?: emptySet()).sorted()))
                    'f' -> item.put("v", sp.getFloat(k.key, 0f).toDouble())
                    'i' -> item.put("v", sp.getInt(k.key, 0))
                    'b' -> item.put("v", sp.getBoolean(k.key, false))
                }
            } catch (_: ClassCastException) {
                continue // tipo inesperado guardado nessa chave: ignora só ela
            }
            arr.put(item)
        }
        return if (arr.length() == 0) null else arr.toString()
    }

    private fun hash(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }.take(24)

    /** Carimbo do estado local: se o conteúdo mudou desde a última vez que olhamos, o carimbo vira "agora". */
    private fun localStamp(ctx: Context, type: String, payload: String): Long {
        val m = meta(ctx)
        val h = hash(payload)
        if (m.getString("hash_$type", "") != h) {
            m.edit().putString("hash_$type", h).putLong("upd_$type", System.currentTimeMillis()).apply()
        }
        return m.getLong("upd_$type", 0L)
    }

    /** Junta duas listas de água pelo id (a mesma regra do app: guarda só os últimos 8 dias). */
    private fun mergeWaterEntries(localRaw: String, remoteRaw: String): String {
        val cutoff = System.currentTimeMillis() - 8L * 24 * 3_600_000L
        val map = LinkedHashMap<String, JSONObject>()
        for (raw in listOf(localRaw, remoteRaw)) {
            try {
                val arr = JSONArray(raw)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    val id = o.optString("id")
                    if (id.isBlank() || o.optLong("at") < cutoff) continue
                    map[id] = o
                }
            } catch (_: Exception) {
            }
        }
        val out = JSONArray()
        map.values.sortedBy { it.optLong("at") }.forEach { out.put(it) }
        return out.toString()
    }

    private fun applySnapshot(ctx: Context, type: String, doc: RemoteDoc) {
        val allowed = SNAPSHOTS[type] ?: return
        val items = try { JSONArray(doc.payload) } catch (_: Exception) { return }
        val editors = HashMap<String, android.content.SharedPreferences.Editor>()
        for (i in 0 until items.length()) {
            val o = items.optJSONObject(i) ?: continue
            val file = o.optString("f")
            val key = o.optString("k")
            val kind = o.optString("t").firstOrNull() ?: continue
            // Só aplica chaves conhecidas (nada de gravar chave arbitrária vinda da nuvem)
            if (allowed.none { it.file == file && it.key == key && it.kind == kind }) continue
            val sp = ctx.applicationContext.getSharedPreferences(file, Context.MODE_PRIVATE)
            val ed = editors.getOrPut(file) { sp.edit() }
            try {
                when (kind) {
                    's' -> {
                        var v = o.optString("v", "")
                        if (type == WATER && key == "entries_json") v = mergeWaterEntries(sp.getString(key, "[]") ?: "[]", v)
                        ed.putString(key, v)
                    }
                    'S' -> {
                        val arr = o.optJSONArray("v") ?: continue
                        val set = HashSet<String>()
                        for (j in 0 until arr.length()) set.add(arr.optString(j))
                        ed.putStringSet(key, set)
                    }
                    'f' -> ed.putFloat(key, o.optDouble("v", 0.0).toFloat())
                    'i' -> ed.putInt(key, o.optInt("v", 0))
                    'b' -> ed.putBoolean(key, o.optBoolean("v", false))
                }
            } catch (_: Exception) {
            }
        }
        editors.values.forEach { it.apply() }
        // O que está no aparelho agora é o que veio da nuvem: não conta como alteração local.
        val now = readSnapshot(ctx, type)
        if (now != null) {
            meta(ctx).edit().putString("hash_$type", hash(now)).putLong("upd_$type", doc.updatedAt).apply()
        }
    }

    /** Remove do aparelho o que é deste backup (usado ao trocar para outra conta já toda salva). */
    fun clearLocal(ctx: Context) {
        for ((_, keys) in SNAPSHOTS) {
            val byFile = keys.groupBy { it.file }
            for ((file, ks) in byFile) {
                val ed = ctx.applicationContext.getSharedPreferences(file, Context.MODE_PRIVATE).edit()
                ks.forEach { ed.remove(it.key) }
                ed.apply()
            }
        }
        meta(ctx).edit().clear().apply()
    }

    // ---------- Conversas ----------

    private fun validId(id: String) = id.isNotBlank() && id.length <= 64 && id.all { it.isLetterOrDigit() || it == '-' || it == '_' }

    /** Registra que uma conversa foi apagada aqui (a exclusão precisa ir à nuvem). */
    fun noteConversationDeleted(ctx: Context, id: String) {
        if (!validId(id)) return
        val m = meta(ctx)
        val o = try { JSONObject(m.getString(TOMB_KEY, "{}") ?: "{}") } catch (_: Exception) { JSONObject() }
        o.put(id, System.currentTimeMillis())
        m.edit().putString(TOMB_KEY, o.toString()).apply()
    }

    private fun tombs(ctx: Context): Map<String, Long> {
        val o = try { JSONObject(meta(ctx).getString(TOMB_KEY, "{}") ?: "{}") } catch (_: Exception) { return emptyMap() }
        val out = HashMap<String, Long>()
        o.keys().forEach { out[it] = o.optLong(it) }
        return out
    }

    private fun pruneTombs(ctx: Context) {
        val cut = System.currentTimeMillis() - TOMB_KEEP_MS
        val cur = tombs(ctx)
        if (cur.values.none { it < cut }) return
        val o = JSONObject()
        cur.filter { it.value >= cut }.forEach { (k, v) -> o.put(k, v) }
        meta(ctx).edit().putString(TOMB_KEY, o.toString()).apply()
    }

    private val convJson get() = com.agon.app.data.GlucoStorage.json

    /** Texto da conversa para a nuvem. Se passar do limite, só a CÓPIA da nuvem perde as mensagens mais antigas. */
    private fun conversationPayload(conv: CrisConversation): String {
        var c = conv
        var text = convJson.encodeToString(CrisConversation.serializer(), c)
        while (text.toByteArray(Charsets.UTF_8).size > MAX_PAYLOAD_BYTES && c.messages.size > 1) {
            c = c.copy(messages = c.messages.drop(maxOf(1, c.messages.size / 10)))
            text = convJson.encodeToString(CrisConversation.serializer(), c)
        }
        return text
    }

    // ---------- Pendências e aplicação ----------

    /** O que enviar: instantâneos alterados, conversas novas/alteradas e conversas apagadas. */
    suspend fun pending(ctx: Context, seen: Map<String, Long>, lastPush: Long): List<RemoteDoc> {
        val out = ArrayList<RemoteDoc>()
        fun need(t: Long) = lastPush < 0 || t > lastPush

        for (type in SNAPSHOTS.keys) {
            val payload = readSnapshot(ctx, type) ?: continue
            val stamp = localStamp(ctx, type, payload)
            if (!need(stamp)) continue
            if ((seen["${type}__$SNAP_ID"] ?: -1L) >= stamp) continue
            out += RemoteDoc(type, SNAP_ID, stamp, false, payload)
        }

        val tombMap = tombs(ctx)
        for (cm in CrisConversationStore.list(ctx)) {
            if (!validId(cm.id)) continue
            if (!need(cm.updatedAt)) continue
            if ((seen["${CONVERSATIONS}__${cm.id}"] ?: -1L) >= cm.updatedAt) continue
            if ((tombMap[cm.id] ?: -1L) >= cm.updatedAt) continue
            val conv = CrisConversationStore.load(ctx, cm.id) ?: continue
            out += RemoteDoc(CONVERSATIONS, cm.id, cm.updatedAt, false, conversationPayload(conv))
        }
        for ((id, at) in tombMap) {
            if (!need(at)) continue
            if ((seen["${CONVERSATIONS}__$id"] ?: -1L) >= at) continue
            out += RemoteDoc(CONVERSATIONS, id, at, true, "")
        }
        pruneTombs(ctx)
        return out
    }

    /** Aplica o que veio da nuvem (só tipos deste backup). Nunca lança: erro em um item não afeta os outros. */
    suspend fun applyRemote(ctx: Context, docs: List<RemoteDoc>) {
        val mine = docs.filter { it.type in TYPES }
        if (mine.isEmpty()) return
        for (d in mine) {
            try {
                when (d.type) {
                    CONVERSATIONS -> applyConversation(ctx, d)
                    else -> if (!d.deleted && d.id == SNAP_ID) {
                        val payload = readSnapshot(ctx, d.type)
                        val stampNow = if (payload == null) 0L else localStamp(ctx, d.type, payload)
                        if (d.updatedAt > stampNow) applySnapshot(ctx, d.type, d)
                    }
                }
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
            }
        }
    }

    private suspend fun applyConversation(ctx: Context, d: RemoteDoc) {
        if (!validId(d.id)) return
        val local = CrisConversationStore.load(ctx, d.id)
        val tombAt = tombs(ctx)[d.id]
        if (d.deleted) {
            if (local != null && local.updatedAt <= d.updatedAt) CrisConversationStore.removeForSync(ctx, d.id)
            return
        }
        if (tombAt != null && tombAt >= d.updatedAt) return
        if (local != null && local.updatedAt >= d.updatedAt) return
        val conv = try {
            convJson.decodeFromString(CrisConversation.serializer(), d.payload)
        } catch (_: Exception) {
            return
        }
        if (conv.id != d.id) return
        CrisConversationStore.importForSync(ctx, conv.copy(updatedAt = d.updatedAt))
    }

    /** Há algo destes dados que ainda não foi enviado para a conta anterior? */
    suspend fun hasUnsaved(ctx: Context, lastPush: Long): Boolean = pending(ctx, emptyMap(), lastPush).isNotEmpty()
}
