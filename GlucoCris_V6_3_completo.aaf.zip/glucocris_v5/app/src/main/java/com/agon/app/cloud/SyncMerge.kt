package com.agon.app.cloud

import com.agon.app.data.AppData
import com.agon.app.data.GlucoStorage
import com.agon.app.data.GlucoseEntry
import com.agon.app.data.InsulinEntry
import com.agon.app.data.Meal
import com.agon.app.data.Medication
import com.agon.app.data.Reminder
import com.agon.app.data.Settings
import com.agon.app.data.Symptom
import com.agon.app.data.Tombstone
import kotlinx.serialization.encodeToString

/** Um documento de users/{uid}/records/{type}__{id}, já fora do formato Firestore. */
data class RemoteDoc(
    val type: String,
    val id: String,
    val updatedAt: Long,
    val deleted: Boolean,
    val payload: String,
) {
    val docId: String get() = "${type}__$id"
}

/**
 * Regras de sincronização (sem Firebase aqui, para ser testável):
 * - vence o registro com maior updatedAt (último a editar);
 * - exclusão vira "tombstone" (deleted=true) e só vale se for mais nova que o registro;
 * - nunca apaga nada local por causa de erro de rede: só aplica documentos que chegaram inteiros.
 */
object SyncMerge {
    const val GLUCOSE = "glucose"
    const val INSULIN = "insulin"
    const val REMINDERS = "reminders"
    const val MEALS = "meals"
    const val SYMPTOMS = "symptoms"
    const val MEDICATIONS = "medications"
    const val PROFILE = "profile"
    const val PROFILE_ID = "main"
    const val DEMO_PREFIX = "demo-"

    /** CPF vai ao backup? Troque para false para nunca enviá-lo à nuvem. */
    const val SYNC_CPF = true

    /** Tipos que vivem dentro de AppData (os demais — água, favoritos, bolus, conversas — são tratados em [ExtraSync]). */
    private val CORE_TYPES = setOf(GLUCOSE, INSULIN, REMINDERS, MEALS, SYMPTOMS, MEDICATIONS, PROFILE)

    val TYPES = CORE_TYPES + ExtraSync.TYPES

    private val json get() = GlucoStorage.json

    /** Ajustes sem o que é só deste aparelho (PIN, conta vinculada, tour). */
    fun sanitizeSettings(s: Settings): Settings = s.copy(
        pinEnabled = false,
        pin = "",
        biometricEnabled = false,
        googleEmail = "",
        googleName = "",
        tourSeen = false,
        cpf = if (SYNC_CPF) s.cpf else "",
    )

    private fun applyRemoteSettings(local: Settings, remote: Settings, stamp: Long): Settings = remote.copy(
        pinEnabled = local.pinEnabled,
        pin = local.pin,
        biometricEnabled = local.biometricEnabled,
        googleEmail = local.googleEmail,
        googleName = local.googleName,
        tourSeen = local.tourSeen,
        cpf = if (SYNC_CPF) remote.cpf else local.cpf,
        settingsUpdatedAt = stamp,
    )

    /** O que enviar: alterações locais mais novas que o último envio e que a nuvem ainda não tem. */
    fun pending(local: AppData, seen: Map<String, Long>, lastPush: Long): List<RemoteDoc> {
        val out = ArrayList<RemoteDoc>()
        fun need(t: Long) = lastPush < 0 || t > lastPush
        fun <T> add(type: String, items: List<T>, id: (T) -> String, upd: (T) -> Long, enc: (T) -> String) {
            for (item in items) {
                val i = id(item)
                if (i.startsWith(DEMO_PREFIX)) continue
                val u = upd(item)
                if (!need(u)) continue
                if ((seen["${type}__$i"] ?: -1L) >= u) continue
                out += RemoteDoc(type, i, u, false, enc(item))
            }
        }
        add(GLUCOSE, local.glucose, { it.id }, { it.updatedAt }, { json.encodeToString<GlucoseEntry>(it) })
        add(INSULIN, local.insulin, { it.id }, { it.updatedAt }, { json.encodeToString<InsulinEntry>(it) })
        add(REMINDERS, local.reminders, { it.id }, { it.updatedAt }, { json.encodeToString<Reminder>(it) })
        add(MEALS, local.meals, { it.id }, { it.updatedAt }, { json.encodeToString<Meal>(it) })
        add(SYMPTOMS, local.symptoms, { it.id }, { it.updatedAt }, { json.encodeToString<Symptom>(it) })
        add(MEDICATIONS, local.medications, { it.id }, { it.updatedAt }, { json.encodeToString<Medication>(it) })
        for (t in local.tombstones) {
            if (t.id.startsWith(DEMO_PREFIX) || t.col !in TYPES) continue
            if (!need(t.at)) continue
            if ((seen["${t.col}__${t.id}"] ?: -1L) >= t.at) continue
            out += RemoteDoc(t.col, t.id, t.at, true, "")
        }
        val su = local.settings.settingsUpdatedAt
        if (su > 0 && need(su) && (seen["${PROFILE}__$PROFILE_ID"] ?: -1L) < su) {
            out += RemoteDoc(PROFILE, PROFILE_ID, su, false, json.encodeToString(sanitizeSettings(local.settings)))
        }
        return out
    }

    /**
     * Aplica ao estado local os documentos vindos da nuvem.
     * [pruneBefore]: tombstones locais mais antigos que isso (e já enviados) são descartados; use -1 para não podar.
     */
    fun mergeRemote(local0: AppData, docs: List<RemoteDoc>, pruneBefore: Long): AppData {
        // Ao receber dados reais da nuvem (aparelho novo), os registros de exemplo da primeira abertura saem.
        val hasReal = docs.any { it.type in CORE_TYPES && it.type != PROFILE && !it.deleted }
        val local = if (!hasReal) local0 else local0.copy(
            glucose = local0.glucose.filterNot { it.id.startsWith(DEMO_PREFIX) },
            insulin = local0.insulin.filterNot { it.id.startsWith(DEMO_PREFIX) },
            reminders = local0.reminders.filterNot { it.id.startsWith(DEMO_PREFIX) },
            meals = local0.meals.filterNot { it.id.startsWith(DEMO_PREFIX) },
            symptoms = local0.symptoms.filterNot { it.id.startsWith(DEMO_PREFIX) },
            medications = local0.medications.filterNot { it.id.startsWith(DEMO_PREFIX) },
        )
        val byType = docs.groupBy { it.type }
        val tombs = local.tombstones.filter { pruneBefore < 0 || it.at >= pruneBefore }.toMutableList()

        fun <T> mergeList(type: String, items: List<T>, id: (T) -> String, upd: (T) -> Long, dec: (String) -> T?): List<T> {
            val ds = byType[type] ?: return items
            val map = LinkedHashMap<String, T>()
            items.forEach { map[id(it)] = it }
            for (d in ds) {
                val cur = map[d.id]
                if (d.deleted) {
                    if (cur != null && upd(cur) <= d.updatedAt) map.remove(d.id)
                } else {
                    val tomb = tombs.firstOrNull { it.col == type && it.id == d.id }
                    if (tomb != null && tomb.at >= d.updatedAt) continue
                    if (cur == null || upd(cur) < d.updatedAt) {
                        val v = dec(d.payload) ?: continue
                        map[d.id] = v
                        if (tomb != null) tombs.remove(tomb)
                    }
                }
            }
            return map.values.toList()
        }

        fun <T> decode(text: String, f: (String) -> T): T? = try { f(text) } catch (_: Exception) { null }

        val glucose = mergeList(GLUCOSE, local.glucose, { it.id }, { it.updatedAt }) { p ->
            decode(p) { json.decodeFromString<GlucoseEntry>(it) }
        }.sortedByDescending { it.at }
        val insulin = mergeList(INSULIN, local.insulin, { it.id }, { it.updatedAt }) { p ->
            decode(p) { json.decodeFromString<InsulinEntry>(it) }
        }.sortedByDescending { it.at }
        val reminders = mergeList(REMINDERS, local.reminders, { it.id }, { it.updatedAt }) { p ->
            decode(p) { json.decodeFromString<Reminder>(it) }
        }
        val meals = mergeList(MEALS, local.meals, { it.id }, { it.updatedAt }) { p ->
            decode(p) { json.decodeFromString<Meal>(it) }
        }.sortedByDescending { it.at }
        val symptoms = mergeList(SYMPTOMS, local.symptoms, { it.id }, { it.updatedAt }) { p ->
            decode(p) { json.decodeFromString<Symptom>(it) }
        }.sortedByDescending { it.at }
        val medications = mergeList(MEDICATIONS, local.medications, { it.id }, { it.updatedAt }) { p ->
            decode(p) { json.decodeFromString<Medication>(it) }
        }

        var settings = local.settings
        val p = byType[PROFILE]?.lastOrNull { !it.deleted && it.id == PROFILE_ID }
        if (p != null && p.updatedAt > settings.settingsUpdatedAt) {
            decode(p.payload) { json.decodeFromString<Settings>(it) }?.let {
                settings = applyRemoteSettings(settings, it, p.updatedAt)
            }
        }
        return local.copy(
            glucose = glucose,
            insulin = insulin,
            reminders = reminders,
            meals = meals,
            symptoms = symptoms,
            medications = medications,
            settings = settings,
            tombstones = tombs,
        )
    }
}
