package com.agon.app.data

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.agon.app.BuildConfig
import com.agon.app.ui.screens.FoodItem
import com.agon.app.ui.screens.loadTacoFoods
import com.agon.app.ui.screens.searchFoodsComplete
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/** Item identificado pela IA (ainda sem nutrientes do catálogo). */
data class VisionDetectedFood(
    val name: String,
    val quantityGrams: Double?,
    val householdMeasure: String?,
    val confidence: Double?,
    val notes: String? = null,
    /** Termo genérico curto (ex.: "biscoito recheado") usado se o nome completo não achar no catálogo. */
    val searchTerm: String? = null,
)

data class VisionAnalysisResult(
    val items: List<VisionDetectedFood>,
    val provider: String,
    val rawNotes: String? = null,
)

/** Item já casado com o banco nutricional do Gluco Cris. */
data class VisionMealLine(
    val id: String,
    val detectedName: String,
    var displayName: String,
    var grams: Double,
    var household: String,
    var confidence: Double?,
    var food: FoodItem?,
    val alternatives: List<FoodItem> = emptyList(),
) {
    fun factor(): Double {
        val base = food?.servingGrams?.takeIf { it > 0 } ?: 100.0
        return grams / base
    }

    fun carbs(): Double = food?.let { it.carbs * factor() } ?: 0.0
    fun kcal(): Double = food?.let { it.kcal * factor() } ?: 0.0
    fun protein(): Double = food?.let { it.protein * factor() } ?: 0.0
    fun fat(): Double = food?.let { it.fat * factor() } ?: 0.0
    fun fiber(): Double = food?.let { it.fiber * factor() } ?: 0.0
    fun sugars(): Double = food?.let { it.sugars * factor() } ?: 0.0
    fun sodium(): Double = food?.let { it.sodium * factor() } ?: 0.0
}


/** Valores nutricionais extraídos de um rótulo (tabela nutricional). */
data class LabelNutrition(
    val servingSize: String? = null,          // ex: "30 g (2 biscoitos)"
    val servingsPerPack: String? = null,      // ex: "10"
    val per100g: NutritionValues? = null,
    val perServing: NutritionValues? = null,
)

data class NutritionValues(
    val kcal: Double? = null,
    val carbs: Double? = null,
    val sugars: Double? = null,
    val addedSugars: Double? = null,
    val protein: Double? = null,
    val fat: Double? = null,
    val satFat: Double? = null,
    val transFat: Double? = null,
    val fiber: Double? = null,
    val sodium: Double? = null,               // em mg
)

/** Ingrediente com explicação simples para a pessoa com diabetes. */
data class LabelIngredient(
    val name: String,
    val simpleExplanation: String,
    val isSugarOrSweetener: Boolean = false,
    val mayRaiseGlucose: Boolean = false,
    val attention: Boolean = false,           // merece atenção
)

/** Resultado completo da leitura de um rótulo. */
data class LabelAnalysisResult(
    val productName: String?,
    val brand: String?,
    val netWeight: String?,                   // ex: "200 g" ou "350 ml"
    val nutrition: LabelNutrition?,
    val ingredients: List<LabelIngredient>,
    val allergens: List<String>,
    val warnings: List<String>,
    val notes: String?,
    val provider: String,
    val confidenceNotes: String? = null,      // quando a foto estava ruim
)

object FoodVisionAi {
    private const val TAG = "FoodVisionAi"

    fun hasGeminiKey(): Boolean = BuildConfig.TAVILY_PROXY_URL.isNotBlank()

    fun providerLabel(): String =
        if (hasGeminiKey()) "Gemini (${BuildConfig.GEMINI_MODEL.ifBlank { "gemini-3.8-flash" }}) via proxy + Open Food Facts"
        else "ML Kit + Open Food Facts (sem chave Gemini)"

    private fun sampleFor(w: Int, h: Int, maxSide: Int): Int {
        var sample = 1
        val max = maxOf(w, h)
        while (max / (sample * 2) >= maxSide) sample *= 2
        return sample
    }

    private fun applyExif(bmp: Bitmap, orientation: Int): Bitmap {
        val m = android.graphics.Matrix()
        when (orientation) {
            android.media.ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            android.media.ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            android.media.ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            android.media.ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            android.media.ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            android.media.ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            android.media.ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            else -> return bmp
        }
        return try {
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        } catch (_: Throwable) {
            bmp
        }
    }

    /** Foto da câmera (arquivo JPEG): decodifica reduzida e já na orientação correta. */
    fun decodeFileForAnalysis(path: String, maxSide: Int = 1600): Bitmap? {
        return try {
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(path, bounds)
            val opts = android.graphics.BitmapFactory.Options().apply {
                inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, maxSide)
            }
            val bmp = android.graphics.BitmapFactory.decodeFile(path, opts) ?: return null
            val orientation = android.media.ExifInterface(path).getAttributeInt(
                android.media.ExifInterface.TAG_ORIENTATION,
                android.media.ExifInterface.ORIENTATION_NORMAL,
            )
            applyExif(bmp, orientation)
        } catch (e: Throwable) {
            Log.w(TAG, "decodeFile", e)
            null
        }
    }

    /** Foto da galeria: decodifica reduzida e já na orientação correta. */
    fun decodeUriForAnalysis(context: Context, uri: android.net.Uri, maxSide: Int = 1600): Bitmap? {
        return try {
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                android.graphics.BitmapFactory.decodeStream(it, null, bounds)
            }
            val opts = android.graphics.BitmapFactory.Options().apply {
                inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, maxSide)
            }
            val bmp = context.contentResolver.openInputStream(uri)?.use {
                android.graphics.BitmapFactory.decodeStream(it, null, opts)
            } ?: return null
            val orientation = try {
                context.contentResolver.openInputStream(uri)?.use {
                    android.media.ExifInterface(it).getAttributeInt(
                        android.media.ExifInterface.TAG_ORIENTATION,
                        android.media.ExifInterface.ORIENTATION_NORMAL,
                    )
                } ?: android.media.ExifInterface.ORIENTATION_NORMAL
            } catch (_: Throwable) {
                android.media.ExifInterface.ORIENTATION_NORMAL
            }
            applyExif(bmp, orientation)
        } catch (e: Throwable) {
            Log.w(TAG, "decodeUri", e)
            null
        }
    }

    /**
     * Comprime e redimensiona a imagem antes do envio (economia de cota/custo).
     */
    fun prepareImageBase64(bitmap: Bitmap, maxSide: Int = 1280, quality: Int = 78): String {
        var bmp = bitmap
        val max = maxOf(bmp.width, bmp.height)
        if (max > maxSide) {
            val scale = maxSide.toFloat() / max
            bmp = Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * scale).toInt().coerceAtLeast(1),
                (bmp.height * scale).toInt().coerceAtLeast(1),
                true,
            )
        }
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, baos)
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun analyzeWithGemini(bitmap: Bitmap): VisionAnalysisResult = withContext(Dispatchers.IO) {
        if (BuildConfig.TAVILY_PROXY_URL.isBlank()) error("Proxy Gemini/Tavily não configurado (tavily.proxy.url).")

        val b64 = prepareImageBase64(bitmap)

        val prompt = """
Você é um assistente nutricional para o app brasileiro Gluco Cris (diabetes / contagem de carboidratos).
Identifique TODO alimento, bebida ou produto alimentício visível na foto, cada um separadamente. Pode ser prato
montado, comida solta, fruta, bebida, doce, lanche ou produto de mercado com embalagem (caixa, pacote, garrafa, lata, pote).

Responda APENAS com JSON válido, neste formato:
{
  "items": [
    {
      "name": "nome completo em português; para produto embalado inclua marca e sabor/variação lidos na embalagem",
      "search": "termo genérico curto para buscar no catálogo (ex.: biscoito recheado, refrigerante cola, iogurte natural)",
      "grams": 120,
      "household": "1 concha",
      "confidence": 0.0 a 1.0,
      "notes": "opcional"
    }
  ],
  "notes": "observação geral opcional"
}

Regras:
- LEIA os textos das embalagens (marca, sabor, peso/volume líquido) e use isso para nomear e estimar grams.
  Se a embalagem mostra o peso/volume (ex.: 350 ml, 200 g), use esse valor em grams (ml ≈ g para bebidas).
- Separe itens misturados (arroz, feijão, carne, salada etc.) e cada produto diferente em itens distintos.
- Se houver vários produtos iguais, um item só, com household indicando a quantidade (ex.: "3 unidades").
- grams é ESTIMATIVA; se incerto use null e explique em notes.
- Não invente o que não aparece; mas não deixe de listar o que está visível, mesmo parcialmente ou em segundo plano.
- Prefira nomes comuns no Brasil (arroz branco cozido, feijão carioca, frango grelhado...).
- Só use items: [] se não houver nenhum alimento, bebida ou produto alimentício na imagem.
- COMPLETUDE: percorra a imagem inteira (centro, bordas, fundo, sobre a mesa, em potes, copos e embalagens) e liste CADA alimento e bebida distinto, inclusive acompanhamentos pequenos (molho, farofa, azeite, pão, fruta de sobremesa, café, suco), itens parcialmente escondidos e alimentos fora do prato. Ignore talheres, pratos, guardanapos e objetos que não sejam comida.
- NOME: dê o nome ESPECÍFICO de cada alimento, como se diz no Brasil, com o preparo quando visível (ex.: "arroz branco cozido", "bife acebolado", "batata frita", "salada de alface e tomate", "banana prata"). Não use nomes genéricos como "comida", "prato", "refeição" ou "legumes" se der para separar; salada ou mistura com vários vegetais pode ser um item só, citando o que a compõe em notes.
- Precisão: copie marca, sabor e peso exatamente como estão impressos; não troque por nome parecido. Seja breve: sem texto fora do JSON, "notes" só se for necessário.
""".trimIndent()

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray()
                            .put(JSONObject().put("text", prompt))
                            .put(
                                JSONObject().put(
                                    "inline_data",
                                    JSONObject()
                                        .put("mime_type", "image/jpeg")
                                        .put("data", b64),
                                ),
                            ),
                    ),
                ),
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.1)
                    .put("responseMimeType", "application/json")
                    .put("maxOutputTokens", 4096)
                    // Ler a imagem não precisa de raciocínio longo: resposta mais rápida
                    .put("thinkingConfig", JSONObject().put("thinkingBudget", 0)),
            )

        var (code, resp) = CrisGemini.postWithFallback(body.toString(), 10_000, 30_000)
        if (code == 400 && body.has("generationConfig")) {
            // Modelo não aceitou "thinkingConfig": repete sem ele
            body.getJSONObject("generationConfig").remove("thinkingConfig")
            val again = CrisGemini.postWithFallback(body.toString(), 10_000, 30_000)
            code = again.first; resp = again.second
        }
        if (code !in 200..299) {
            Log.w(TAG, "Gemini proxy HTTP $code: ${resp.take(400)}")
            error(parseGeminiError(resp, code))
        }

        val text = extractGeminiText(resp)
        parseVisionJson(text, "Gemini")
    }

    private fun parseGeminiError(resp: String, code: Int): String {
        return try {
            val msg = JSONObject(resp).optJSONObject("error")?.optString("message")
            when {
                code == 429 -> "Limite de uso da API atingido. Tente mais tarde."
                code == 403 -> "Chave Gemini inválida ou sem permissão."
                !msg.isNullOrBlank() -> "Erro da IA: $msg"
                else -> "Erro HTTP $code na API Gemini."
            }
        } catch (_: Exception) {
            "Erro HTTP $code na API Gemini."
        }
    }

    private fun extractGeminiText(resp: String): String {
        val root = JSONObject(resp)
        val candidates = root.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            sb.append(parts.getJSONObject(i).optString("text"))
        }
        return sb.toString().trim()
    }

    private fun parseVisionJson(text: String, provider: String): VisionAnalysisResult {
        var cleaned = text.trim()
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.removePrefix("```json").removePrefix("```JSON").removePrefix("```").trim()
            if (cleaned.endsWith("```")) cleaned = cleaned.dropLast(3).trim()
        }
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        if (start < 0 || end <= start) return VisionAnalysisResult(emptyList(), provider, "Resposta sem JSON")
        val obj = JSONObject(cleaned.substring(start, end + 1))
        val arr = obj.optJSONArray("items") ?: JSONArray()
        val items = mutableListOf<VisionDetectedFood>()
        for (i in 0 until arr.length()) {
            val it = arr.getJSONObject(i)
            val name = it.optString("name", "").trim()
            if (name.isBlank()) continue
            val grams = if (it.has("grams") && !it.isNull("grams")) it.optDouble("grams") else null
            items.add(
                VisionDetectedFood(
                    name = name,
                    quantityGrams = grams?.takeIf { it > 0 },
                    householdMeasure = it.optString("household", "").ifBlank { null },
                    confidence = if (it.has("confidence")) it.optDouble("confidence") else null,
                    notes = it.optString("notes", "").ifBlank { null },
                    searchTerm = it.optString("search", "").trim().ifBlank { null },
                ),
            )
        }
        return VisionAnalysisResult(
            items = items,
            provider = provider,
            rawNotes = obj.optString("notes", "").ifBlank { null },
        )
    }


    /**
     * Fallback sem Gemini: rótulos ML Kit → nomes de alimentos → depois o catálogo OFF/local.
     */
    suspend fun analyzeWithMlKitLabels(bitmap: Bitmap): VisionAnalysisResult = withContext(Dispatchers.IO) {
        try {
            val labeler = com.google.mlkit.vision.label.ImageLabeling.getClient(
                com.google.mlkit.vision.label.defaults.ImageLabelerOptions.DEFAULT_OPTIONS,
            )
            val image = com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap, 0)
            val labels = com.google.android.gms.tasks.Tasks.await(labeler.process(image))
            labeler.close()
            val generic = setOf(
                "food", "cuisine", "dish", "ingredient", "tableware", "plate", "recipe", "meal", "produce",
                "cooking", "staple food", "comfort food", "fast food", "junk food", "finger food", "drink",
                "bowl", "table", "dishware", "serveware", "kitchen", "snack", "baked goods", "natural foods",
                "whole food", "local food", "superfood", "leaf vegetable", "vegetable", "fruit",
            )
            val pt = mapOf(
                "apple" to "maçã", "banana" to "banana", "orange" to "laranja", "bread" to "pão",
                "rice" to "arroz", "egg" to "ovo", "cheese" to "queijo", "pizza" to "pizza", "cake" to "bolo",
                "salad" to "salada", "tomato" to "tomate", "potato" to "batata", "milk" to "leite",
                "coffee" to "café", "juice" to "suco", "chicken" to "frango", "beef" to "carne bovina",
                "fish" to "peixe", "pasta" to "macarrão", "noodle" to "macarrão", "sandwich" to "sanduíche",
                "hamburger" to "hambúrguer", "cookie" to "biscoito", "biscuit" to "biscoito", "chocolate" to "chocolate",
                "strawberry" to "morango", "grape" to "uva", "lemon" to "limão", "carrot" to "cenoura",
                "beans" to "feijão", "bean" to "feijão", "soup" to "sopa", "yogurt" to "iogurte", "ice cream" to "sorvete",
                "soft drink" to "refrigerante", "soda" to "refrigerante", "water" to "água", "beer" to "cerveja",
                "wine" to "vinho", "cereal" to "cereal", "oat" to "aveia", "corn" to "milho", "mango" to "manga",
                "papaya" to "mamão", "watermelon" to "melancia", "pineapple" to "abacaxi", "avocado" to "abacate",
            )
            val foodish = labels
                .filter { it.confidence >= 0.45f }
                .filter { it.text.trim().lowercase() !in generic }
                .map { pt[it.text.trim().lowercase()] ?: it.text.trim() }
                .filter { it.length in 3..40 }
                .distinct()
                .take(8)
            if (foodish.isEmpty()) {
                return@withContext VisionAnalysisResult(
                    emptyList(),
                    "ML Kit + OFF",
                    "Não foi possível rotular alimentos na foto. Tente outra imagem ou configure Gemini.",
                )
            }
            val items = foodish.map { name ->
                VisionDetectedFood(
                    name = name,
                    quantityGrams = 100.0,
                    householdMeasure = "100 g (estimativa)",
                    confidence = 0.6,
                    notes = "Rótulo ML Kit; nutrientes vêm do catálogo OFF/local",
                )
            }
            VisionAnalysisResult(items, "ML Kit + Open Food Facts", null)
        } catch (e: Exception) {
            Log.w(TAG, "ML Kit labels", e)
            VisionAnalysisResult(
                emptyList(),
                "ML Kit + OFF",
                e.message ?: "Falha no reconhecimento local da imagem.",
            )
        }
    }

    private fun nameKey(s: String): String =
        java.text.Normalizer.normalize(s.lowercase(), java.text.Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").replace(Regex("[^a-z0-9 ]"), " ").replace(Regex("\\s+"), " ").trim()

    private val nameStop = setOf("com", "sem", "de", "da", "do", "das", "dos", "em", "ao", "na", "no", "e", "a", "o", "um", "uma")

    private fun nameTokens(s: String): Set<String> = nameKey(s).split(" ").filter { it.length >= 3 && it !in nameStop }.toSet()

    /** Mesmo alimento? (compara palavras do nome, ignorando acento e plural simples) */
    private fun sameFoodName(a: String, b: String): Boolean {
        val ta = nameTokens(a).map { it.removeSuffix("s") }
        val tb = nameTokens(b).map { it.removeSuffix("s") }
        return ta.any { x -> tb.any { y -> x == y || (x.length >= 5 && y.length >= 5 && (x.startsWith(y) || y.startsWith(x))) } }
    }

    private fun mergeDetected(base: List<VisionDetectedFood>, extra: List<VisionDetectedFood>): List<VisionDetectedFood> {
        val out = base.toMutableList()
        for (e in extra) if (out.none { sameFoodName(it.name, e.name) }) out.add(e)
        return out
    }

    /** Segunda leitura: pede só o que ainda NÃO foi listado (itens pequenos, ao fundo ou fora do prato). */
    private suspend fun findMissingWithGemini(bitmap: Bitmap, already: List<String>): List<VisionDetectedFood> = withContext(Dispatchers.IO) {
        if (BuildConfig.TAVILY_PROXY_URL.isBlank()) return@withContext emptyList()
        val b64 = prepareImageBase64(bitmap)
        val prompt = """
Foto de refeição/alimentos para o app Gluco Cris (contagem de carboidratos, Brasil).
Já foram identificados: ${if (already.isEmpty()) "(nenhum)" else already.joinToString("; ")}.
Procure na imagem inteira por OUTROS alimentos ou bebidas visíveis que NÃO estejam nessa lista (acompanhamentos pequenos, molhos, pães, frutas, bebidas, itens ao fundo, fora do prato ou parcialmente escondidos). Ignore talheres, pratos e objetos.
Responda APENAS com JSON: {"items":[{"name":"nome específico em português","search":"termo genérico curto","grams":100,"household":"1 unidade","confidence":0.0 a 1.0}]}
Se não houver nada além do já listado, responda {"items":[]}. Não repita itens já listados e não invente.
""".trimIndent()
        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray()
                            .put(JSONObject().put("text", prompt))
                            .put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", b64))),
                    ),
                ),
            )
            .put("generationConfig", JSONObject().put("temperature", 0.1).put("responseMimeType", "application/json").put("maxOutputTokens", 2048))
        val (code, resp) = CrisGemini.postWithFallback(body.toString(), 10_000, 25_000)
        if (code !in 200..299) return@withContext emptyList()
        parseVisionJson(extractGeminiText(resp), "Gemini").items
    }

    /**
     * Preferência: Gemini → se falhar ou sem chave, ML Kit + match no Open Food Facts/local.
     */
    suspend fun analyzePlate(bitmap: Bitmap): VisionAnalysisResult {
        if (hasGeminiKey()) {
            return try {
                val first = analyzeWithGemini(bitmap)
                // Poucos itens: confere se ficou algum alimento visível de fora (segunda leitura focada no que faltou).
                if (first.items.size in 0..2) {
                    val extra = try { findMissingWithGemini(bitmap, first.items.map { it.name }) } catch (_: Exception) { emptyList() }
                    if (extra.isNotEmpty()) first.copy(items = mergeDetected(first.items, extra)) else first
                } else first
            } catch (e: Exception) {
                Log.w(TAG, "Gemini falhou, fallback ML Kit/OFF", e)
                val fb = analyzeWithMlKitLabels(bitmap)
                if (fb.items.isEmpty()) {
                    VisionAnalysisResult(
                        emptyList(),
                        "Gemini falhou → OFF",
                        (e.message ?: "Gemini indisponível") + " · " + (fb.rawNotes ?: ""),
                    )
                } else fb.copy(provider = "Fallback: ML Kit + Open Food Facts", rawNotes = e.message)
            }
        }
        return analyzeWithMlKitLabels(bitmap)
    }

    /**
     * Quando o código de barras não está no Open Food Facts, tenta Gemini (texto) para sugerir o produto.
     * Nutrientes só se a IA devolver números; senão null.
     */
    suspend fun lookupBarcodeWithGemini(code: String): FoodItem? = withContext(Dispatchers.IO) {
        if (BuildConfig.TAVILY_PROXY_URL.isBlank()) return@withContext null
        try {
            val prompt = """
Código de barras (EAN/UPC): $code
Pesquise esse código no Google e identifique o produto alimentício (marca, nome, sabor, peso). Se não encontrar com segurança, não chute.
Responda APENAS JSON:
{"name":"...","brand":"...","kcal_100g":0,"carbs_100g":0,"protein_100g":0,"fat_100g":0,"fiber_100g":0,"sugars_100g":0,"sodium_mg_100g":0,"serving":"100 g"}
Se não souber com segurança, responda: {"name":""}
Não invente valores nutricionais se não tiver base.
""".trimIndent()
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("temperature", 0.1).put("maxOutputTokens", 600).put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))
                .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            var (codeHttp, resp) = CrisGemini.postWithFallback(body.toString(), 10_000, 25_000)
            if (codeHttp == 400) {
                // Pedido com pesquisa/raciocínio recusado: repete simples
                body.remove("tools")
                body.getJSONObject("generationConfig").remove("thinkingConfig")
                val again = CrisGemini.postWithFallback(body.toString(), 10_000, 20_000)
                codeHttp = again.first; resp = again.second
            }
            if (codeHttp !in 200..299) return@withContext null
            val text = extractGeminiText(resp)
            val jsonStr = text.substringAfter("{").substringBeforeLast("}").let { "{$it}" }
            val o = JSONObject(jsonStr)
            val name = o.optString("name", "").trim()
            if (name.isBlank()) return@withContext null
            val kcal = o.optDouble("kcal_100g", 0.0)
            val carbs = o.optDouble("carbs_100g", 0.0)
            val prot = o.optDouble("protein_100g", 0.0)
            val fatG = o.optDouble("fat_100g", 0.0)
            val warn = com.agon.app.ui.screens.nutritionWarning(kcal, carbs, prot, fatG)
            FoodItem(
                id = "bc-gemini-$code",
                name = name,
                brand = o.optString("brand", ""),
                serving = o.optString("serving", "100 g").ifBlank { "100 g" },
                servingGrams = 100.0,
                kcal = kcal,
                kj = kcal * 4.184,
                carbs = carbs,
                protein = prot,
                fat = fatG,
                fiber = o.optDouble("fiber_100g", 0.0),
                sugars = o.optDouble("sugars_100g", 0.0),
                sodium = o.optDouble("sodium_mg_100g", 0.0),
                source = if (warn != null) "Gemini (estimado) — confira: $warn" else "Gemini (código não achado no OFF) — confira no rótulo",
                sourceKey = "gemini",
                isGeneric = true,
                reliability = "estimada",
                category = "",
            )
        } catch (e: Exception) {
            Log.w(TAG, "barcode Gemini", e)
            null
        }
    }

    /**
     * Casa cada item detectado com o catálogo do app (searchFoodsComplete).
     * Não inventa nutrientes: se não achar, food fica null.
     */
    suspend fun matchToCatalog(
        context: Context,
        analysis: VisionAnalysisResult,
    ): List<VisionMealLine> = withContext(Dispatchers.IO) {
        val taco = loadTacoFoods(context)
        analysis.items.mapIndexed { index, det ->
            val queries = buildList {
                add(det.name)
                det.searchTerm?.let { add(it) }
                val words = det.name.split(" ").filter { it.isNotBlank() }
                if (words.size > 2) add(words.take(2).joinToString(" "))
            }.distinctBy { it.lowercase() }
            var results: List<FoodItem> = emptyList()
            for (q in queries) {
                results = try {
                    searchFoodsComplete(context, q, taco).take(8)
                } catch (_: Exception) {
                    emptyList()
                }
                if (results.isNotEmpty()) break
            }
            val best = results.firstOrNull()
            val grams = det.quantityGrams
                ?: best?.servingGrams?.takeIf { it > 0 }
                ?: 100.0
            VisionMealLine(
                id = "vision-$index-${det.name.hashCode()}",
                detectedName = det.name,
                displayName = if (best != null && (sameFoodName(det.name, best.name) || det.searchTerm?.let { sameFoodName(it, best.name) } == true)) best.name else det.name,
                grams = grams,
                household = det.householdMeasure
                    ?: best?.serving
                    ?: "${grams.roundToInt()} g",
                confidence = det.confidence,
                food = best,
                alternatives = results.drop(1).take(5),
            )
        }
    }

    // ──────────────────────────────────────────────────────────────
    // Leitura de RÓTULO (tabela nutricional + ingredientes)
    // ──────────────────────────────────────────────────────────────

    /**
     * Analisa uma foto de rótulo de produto (tabela nutricional e/ou lista de ingredientes).
     * Não inventa valores. Quando a foto estiver ilegível, retorna confidenceNotes pedindo nova foto.
     */
    suspend fun analyzeLabelWithGemini(bitmap: Bitmap): LabelAnalysisResult = withContext(Dispatchers.IO) {
        if (BuildConfig.TAVILY_PROXY_URL.isBlank()) {
            error("Proxy Gemini/Tavily não configurado (tavily.proxy.url).")
        }

        val b64 = prepareImageBase64(bitmap, maxSide = 1400, quality = 82)

        val prompt = """
Você é a Cris, assistente nutricional do app brasileiro Gluco Cris (focado em diabetes e contagem de carboidratos).
Analise a FOTO DO RÓTULO de um produto alimentício. Pode ser a tabela nutricional, a lista de ingredientes, a frente da embalagem ou várias partes juntas.

Responda APENAS com JSON válido neste formato exato:
{
  "productName": "nome do produto como aparece no rótulo",
  "brand": "marca",
  "netWeight": "peso ou volume líquido (ex: 200 g, 350 ml)",
  "servingSize": "porção indicada (ex: 30 g / 2 biscoitos)",
  "servingsPerPack": "número de porções por embalagem se houver",
  "per100g": {
    "kcal": null,
    "carbs": null,
    "sugars": null,
    "addedSugars": null,
    "protein": null,
    "fat": null,
    "satFat": null,
    "transFat": null,
    "fiber": null,
    "sodium": null
  },
  "perServing": {
    "kcal": null,
    "carbs": null,
    "sugars": null,
    "addedSugars": null,
    "protein": null,
    "fat": null,
    "satFat": null,
    "transFat": null,
    "fiber": null,
    "sodium": null
  },
  "ingredients": [
    {
      "name": "nome do ingrediente como escrito",
      "simpleExplanation": "explicação curta e simples em português, útil para quem tem diabetes",
      "isSugarOrSweetener": false,
      "mayRaiseGlucose": false,
      "attention": false
    }
  ],
  "allergens": ["contém glúten", "pode conter leite"],
  "warnings": ["aviso importante do rótulo se houver"],
  "notes": "observação geral se necessário",
  "confidenceNotes": "se a foto estiver desfocada, incompleta ou ilegível, diga aqui o que falta e peça nova foto. Caso contrário null"
}

REGRAS OBRIGATÓRIAS:
1. NUNCA invente valores nutricionais. Se não conseguir ler, deixe null.
2. Diferencie claramente valores POR 100g/100ml e POR PORÇÃO. Não misture.
3. Não confunda valor da embalagem inteira com valor da porção.
4. Para ingredientes: explique de forma simples. Marque isSugarOrSweetener=true para açúcares, xaropes, maltodextrina, dextrose, frutose, sacarose, etc. e também adoçantes (sucralose, aspartame, stevia...).
5. mayRaiseGlucose=true para ingredientes que tipicamente elevam a glicemia (carboidratos disponíveis, açúcares, maltodextrina...).
6. attention=true apenas quando realmente merece atenção (ex: alto teor de açúcar adicionado, gordura trans, sódio muito alto).
7. Se a foto estiver ruim (desfocada, cortada, sem tabela ou ingredientes legíveis), preencha confidenceNotes pedindo nova foto e deixe os campos numéricos como null.
8. Prefira português do Brasil. Seja objetivo. Sem texto fora do JSON.
""".trimIndent()

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray()
                            .put(JSONObject().put("text", prompt))
                            .put(
                                JSONObject().put(
                                    "inline_data",
                                    JSONObject()
                                        .put("mime_type", "image/jpeg")
                                        .put("data", b64),
                                ),
                            ),
                    ),
                ),
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.1)
                    .put("responseMimeType", "application/json")
                    .put("maxOutputTokens", 3072)
                    .put("thinkingConfig", JSONObject().put("thinkingBudget", 0)),
            )

        var (code, resp) = CrisGemini.postWithFallback(body.toString(), 12_000, 45_000)
        if (code == 400 && body.has("generationConfig")) {
            body.getJSONObject("generationConfig").remove("thinkingConfig")
            val again = CrisGemini.postWithFallback(body.toString(), 12_000, 45_000)
            code = again.first; resp = again.second
        }
        if (code !in 200..299) {
            Log.w(TAG, "Label Gemini HTTP $code: ${resp.take(400)}")
            error(parseGeminiError(resp, code))
        }

        val text = extractGeminiText(resp)
        parseLabelJson(text, "Gemini")
    }

    private fun parseLabelJson(text: String, provider: String): LabelAnalysisResult {
        var cleaned = text.trim()
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.removePrefix("```json").removePrefix("```JSON").removePrefix("```").trim()
            if (cleaned.endsWith("```")) cleaned = cleaned.dropLast(3).trim()
        }
        // Remove possível texto antes/depois do JSON
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        if (start >= 0 && end > start) cleaned = cleaned.substring(start, end + 1)

        val root = JSONObject(cleaned)

        fun optDouble(o: JSONObject?, key: String): Double? {
            if (o == null || !o.has(key) || o.isNull(key)) return null
            return try { o.getDouble(key) } catch (_: Exception) { null }
        }

        fun parseValues(obj: JSONObject?): NutritionValues? {
            if (obj == null) return null
            return NutritionValues(
                kcal = optDouble(obj, "kcal"),
                carbs = optDouble(obj, "carbs"),
                sugars = optDouble(obj, "sugars"),
                addedSugars = optDouble(obj, "addedSugars"),
                protein = optDouble(obj, "protein"),
                fat = optDouble(obj, "fat"),
                satFat = optDouble(obj, "satFat"),
                transFat = optDouble(obj, "transFat"),
                fiber = optDouble(obj, "fiber"),
                sodium = optDouble(obj, "sodium"),
            )
        }

        val nutrition = LabelNutrition(
            servingSize = root.optString("servingSize").takeIf { it.isNotBlank() },
            servingsPerPack = root.optString("servingsPerPack").takeIf { it.isNotBlank() },
            per100g = parseValues(root.optJSONObject("per100g")),
            perServing = parseValues(root.optJSONObject("perServing")),
        )

        val ingredients = mutableListOf<LabelIngredient>()
        val arr = root.optJSONArray("ingredients")
        if (arr != null) {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val name = o.optString("name").trim()
                if (name.isBlank()) continue
                ingredients.add(
                    LabelIngredient(
                        name = name,
                        simpleExplanation = o.optString("simpleExplanation").ifBlank {
                            "Ingrediente presente no produto."
                        },
                        isSugarOrSweetener = o.optBoolean("isSugarOrSweetener", false),
                        mayRaiseGlucose = o.optBoolean("mayRaiseGlucose", false),
                        attention = o.optBoolean("attention", false),
                    ),
                )
            }
        }

        fun stringList(key: String): List<String> {
            val a = root.optJSONArray(key) ?: return emptyList()
            return (0 until a.length()).mapNotNull {
                a.optString(it).trim().takeIf { s -> s.isNotBlank() }
            }
        }

        return LabelAnalysisResult(
            productName = root.optString("productName").takeIf { it.isNotBlank() },
            brand = root.optString("brand").takeIf { it.isNotBlank() },
            netWeight = root.optString("netWeight").takeIf { it.isNotBlank() },
            nutrition = nutrition,
            ingredients = ingredients,
            allergens = stringList("allergens"),
            warnings = stringList("warnings"),
            notes = root.optString("notes").takeIf { it.isNotBlank() },
            provider = provider,
            confidenceNotes = root.optString("confidenceNotes").takeIf { it.isNotBlank() && it.lowercase() != "null" },
        )
    }



    /**
     * Leitura de rótulo unificada: tenta Gemini online; se falhar ou sem chave, usa OCR local (ML Kit).
     */
    suspend fun analyzeLabel(bitmap: Bitmap): LabelAnalysisResult {
        if (hasGeminiKey()) {
            return try {
                analyzeLabelWithGemini(bitmap)
            } catch (e: Exception) {
                Log.w(TAG, "Label Gemini falhou, tentando OCR local", e)
                val offline = analyzeLabelWithOcr(bitmap)
                offline.copy(
                    notes = listOfNotNull(offline.notes, "Fallback OCR local: ${e.message?.take(80)}").joinToString(" · "),
                    provider = "OCR local (Gemini indisponível)",
                )
            }
        }
        return analyzeLabelWithOcr(bitmap)
    }

    /**
     * OCR 100% no aparelho (ML Kit Text Recognition) + parsing heurístico da tabela/ingredientes.
     * Não inventa números: só extrai o que conseguir ler no texto.
     */
    suspend fun analyzeLabelWithOcr(bitmap: Bitmap): LabelAnalysisResult = withContext(Dispatchers.IO) {
        val ocrText = try {
            com.agon.app.localai.LocalVisionManager.ocr(bitmap)
        } catch (e: Exception) {
            Log.w(TAG, "OCR local", e)
            ""
        }
        if (ocrText.isBlank()) {
            return@withContext LabelAnalysisResult(
                productName = null,
                brand = null,
                netWeight = null,
                nutrition = null,
                ingredients = emptyList(),
                allergens = emptyList(),
                warnings = emptyList(),
                notes = null,
                provider = "OCR local",
                confidenceNotes = "Não foi possível ler texto na imagem. Tente outra foto com boa luz, ou use internet (Gemini).",
            )
        }
        parseOcrLabelText(ocrText)
    }

    private fun parseOcrLabelText(ocr: String): LabelAnalysisResult {
        val lines = ocr.lines().map { it.trim() }.filter { it.isNotBlank() }
        val full = ocr.replace("\r", "\n")

        fun findNum(patterns: List<Regex>): Double? {
            for (p in patterns) {
                val m = p.find(full) ?: continue
                val raw = m.groupValues.last().replace(",", ".").replace(" ", "")
                raw.toDoubleOrNull()?.let { return it }
            }
            return null
        }

        // Heurísticas comuns em rótulos BR
        val carbs = findNum(listOf(
            Regex("""(?i)carboidrato[s]?\s*[:=]?\s*([\d]+(?:[.,]\d+)?)"""),
            Regex("""(?i)carb\.?\s*[:=]?\s*([\d]+(?:[.,]\d+)?)"""),
        ))
        val sugars = findNum(listOf(
            Regex("""(?i)a[cç][uú]care?s?\s*(?:totais?)?\s*[:=]?\s*([\d]+(?:[.,]\d+)?)"""),
            Regex("""(?i)of\s*which\s*sugars?\s*[:=]?\s*([\d]+(?:[.,]\d+)?)"""),
        ))
        val protein = findNum(listOf(
            Regex("""(?i)prote[ií]na[s]?\s*[:=]?\s*([\d]+(?:[.,]\d+)?)"""),
        ))
        val fat = findNum(listOf(
            Regex("""(?i)gordura[s]?\s*totais?\s*[:=]?\s*([\d]+(?:[.,]\d+)?)"""),
            Regex("""(?i)lip[ií]deos?\s*[:=]?\s*([\d]+(?:[.,]\d+)?)"""),
            Regex("""(?i)gordura[s]?\s*[:=]?\s*([\d]+(?:[.,]\d+)?)"""),
        ))
        val satFat = findNum(listOf(
            Regex("""(?i)gordura[s]?\s*saturada[s]?\s*[:=]?\s*([\d]+(?:[.,]\d+)?)"""),
        ))
        val fiber = findNum(listOf(
            Regex("""(?i)fibras?\s*(?:alimentares?)?\s*[:=]?\s*([\d]+(?:[.,]\d+)?)"""),
        ))
        val sodium = findNum(listOf(
            Regex("""(?i)s[oó]dio\s*[:=]?\s*([\d]+(?:[.,]\d+)?)"""),
        ))
        val kcal = findNum(listOf(
            Regex("""(?i)(?:valor\s+energ[eé]tico|energia|calorias?)\s*[:=]?\s*([\d]+(?:[.,]\d+)?)\s*kcal"""),
            Regex("""([\d]+(?:[.,]\d+)?)\s*kcal"""),
        ))

        val serving = Regex("""(?i)por[cç][aã]o\s*[:=]?\s*([^\n]{3,40})""").find(full)?.groupValues?.getOrNull(1)?.trim()
        val netWeight = Regex("""(?i)(?:conte[uú]do|peso\s*l[ií]quido|net\s*wt\.?)\s*[:=]?\s*([\d]+(?:[.,]\d+)?\s*(?:g|kg|ml|l)\b)""", RegexOption.IGNORE_CASE)
            .find(full)?.groupValues?.getOrNull(1)?.trim()
            ?: Regex("""\b([\d]+(?:[.,]\d+)?\s*(?:g|ml))\b""").find(lines.firstOrNull() ?: "")?.value

        // Ingredientes: bloco após "ingredientes"
        val ingBlock = Regex("""(?is)ingredientes?\s*[:：]?\s*(.+?)(?:informação|informacao|alerg|contém|contem|pode conter|tabela|valores|conservar|$$|$)""")
            .find(full)?.groupValues?.getOrNull(1)
            ?: Regex("""(?is)ingredientes?\s*[:：]?\s*(.+)""").find(full)?.groupValues?.getOrNull(1)

        val ingredients = mutableListOf<LabelIngredient>()
        if (!ingBlock.isNullOrBlank()) {
            val parts = ingBlock
                .replace("\n", " ")
                .split(Regex("""[,;•·]|(?<!\d)\.(?!\d)"""))
                .map { it.trim().trimStart('.', '-', '–') }
                .filter { it.length in 2..60 }
                .take(25)
            for (p in parts) {
                val low = p.lowercase()
                val isSugar = listOf(
                    "açúcar", "acucar", "sacarose", "glicose", "frutose", "maltodextrina",
                    "xarope", "dextrose", "mel ", "maltose", "lactose",
                ).any { low.contains(it) }
                val isSweet = listOf("sucralose", "aspartame", "esteviol", "stevia", "sacarina", "acesulfame").any { low.contains(it) }
                val raise = isSugar || low.contains("amido") || low.contains("farinha")
                ingredients.add(
                    LabelIngredient(
                        name = p.replaceFirstChar { if (it.isLowerCase()) it.titlecase() else it.toString() },
                        simpleExplanation = when {
                            isSugar -> "Fonte de açúcar/carboidrato que pode elevar a glicemia. A quantidade importa."
                            isSweet -> "Adoçante. Em geral não eleva a glicemia como o açúcar, mas a resposta individual varia."
                            raise -> "Pode contribuir com carboidratos dependendo da quantidade."
                            else -> "Ingrediente identificado no rótulo por OCR."
                        },
                        isSugarOrSweetener = isSugar || isSweet,
                        mayRaiseGlucose = raise && !isSweet,
                        attention = isSugar,
                    ),
                )
            }
        }

        val allergens = mutableListOf<String>()
        Regex("""(?i)(?:contém|contem|alerg[eé]nicos?)\s*[:：]?\s*([^\n]{3,120})""").find(full)?.groupValues?.getOrNull(1)?.let {
            allergens.add(it.trim())
        }
        Regex("""(?i)pode\s+conter\s+([^\n.]{3,80})""").findAll(full).forEach {
            allergens.add("Pode conter ${it.groupValues[1].trim()}")
        }

        // Nome: primeiras linhas sem parecer tabela
        val productName = lines.firstOrNull {
            val l = it.lowercase()
            !l.contains("ingrediente") && !l.contains("carboidrato") && !l.contains("porção")
                && !l.contains("calor") && it.length in 3..50
                && !it.all { ch -> ch.isDigit() || ch in ".,% " }
        }

        val hasAny = listOf(carbs, sugars, protein, fat, kcal).any { it != null } || ingredients.isNotEmpty()
        val values = NutritionValues(
            kcal = kcal, carbs = carbs, sugars = sugars, addedSugars = null,
            protein = protein, fat = fat, satFat = satFat, transFat = null,
            fiber = fiber, sodium = sodium,
        )
        val nutrition = if (listOf(carbs, sugars, protein, fat, kcal, fiber, sodium, satFat).any { it != null }) {
            LabelNutrition(servingSize = serving, servingsPerPack = null, per100g = null, perServing = values)
        } else null

        return LabelAnalysisResult(
            productName = productName,
            brand = null,
            netWeight = netWeight,
            nutrition = nutrition,
            ingredients = ingredients,
            allergens = allergens.distinct(),
            warnings = emptyList(),
            notes = "Texto OCR (${ocr.length} caracteres). Valores só se legíveis no texto.",
            provider = "OCR local (ML Kit)",
            confidenceNotes = if (!hasAny) {
                "OCR leu texto, mas não identificou tabela ou ingredientes com segurança. Tente foto mais nítida da tabela nutricional."
            } else null,
        )
    }

}
