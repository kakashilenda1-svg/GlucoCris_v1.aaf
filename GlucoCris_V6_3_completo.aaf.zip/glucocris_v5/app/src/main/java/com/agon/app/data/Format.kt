package com.agon.app.data

import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

private fun cal(ms: Long): Calendar = Calendar.getInstance().apply { timeInMillis = ms }

fun pad(n: Int): String = n.toString().padStart(2, '0')

fun formatDate(ms: Long): String {
    val c = cal(ms)
    return "${pad(c.get(Calendar.DAY_OF_MONTH))}/${pad(c.get(Calendar.MONTH) + 1)}/${c.get(Calendar.YEAR)}"
}

fun formatTime(ms: Long): String {
    val c = cal(ms)
    return "${pad(c.get(Calendar.HOUR_OF_DAY))}:${pad(c.get(Calendar.MINUTE))}"
}

fun formatDateTime(ms: Long): String = "${formatDate(ms)} às ${formatTime(ms)}"

fun formatClock(h: Int, m: Int): String = "${pad(h)}:${pad(m)}"

fun greeting(now: Long = System.currentTimeMillis()): String {
    val h = cal(now).get(Calendar.HOUR_OF_DAY)
    return if (h < 12) "Bom dia" else if (h < 18) "Boa tarde" else "Boa noite"
}

fun weekdayLong(ms: Long = System.currentTimeMillis()): String =
    listOf("domingo", "segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sábado")[cal(ms).get(Calendar.DAY_OF_WEEK) - 1]

fun formatLongDate(ms: Long = System.currentTimeMillis()): String {
    val months = listOf("janeiro", "fevereiro", "março", "abril", "maio", "junho", "julho", "agosto", "setembro", "outubro", "novembro", "dezembro")
    val c = cal(ms)
    return "${c.get(Calendar.DAY_OF_MONTH)} de ${months[c.get(Calendar.MONTH)]}"
}

fun toMgDl(value: Double, unit: String): Double = if (unit == "mmol/L") 18.0182 * value else value

fun rangeStatus(mg: Double, low: Int, high: Int): String = when {
    mg < low -> "low"
    mg > high -> "high"
    else -> "ok"
}

fun statusLabel(status: String): String = when (status) {
    "low" -> "Abaixo da meta"
    "high" -> "Acima da meta"
    else -> "Dentro da meta"
}

fun fmtNum(d: Double): String = if (d == kotlin.math.floor(d) && !d.isInfinite()) d.toLong().toString() else d.toString()

fun ptNumber(d: Double, maxFraction: Int = 3): String {
    val nf = NumberFormat.getNumberInstance(Locale("pt", "BR"))
    nf.maximumFractionDigits = maxFraction
    return nf.format(d)
}

fun parseDecimal(text: String): Double? {
    val v = text.trim().replace(',', '.').toDoubleOrNull() ?: return null
    return if (v.isNaN()) null else v
}

fun parseLocalDateTime(date: String, time: String): Long? {
    val d = Regex("""^(\d{1,2})/(\d{1,2})/(\d{4})$""").find(date.trim()) ?: return null
    val t = Regex("""^(\d{1,2}):(\d{2})$""").find(time.trim()) ?: return null
    val day = d.groupValues[1].toInt()
    val month = d.groupValues[2].toInt()
    val year = d.groupValues[3].toInt()
    val hour = t.groupValues[1].toInt()
    val minute = t.groupValues[2].toInt()
    if (month !in 1..12 || day !in 1..31 || hour > 23 || minute > 59) return null
    return try {
        val c = Calendar.getInstance()
        c.isLenient = false
        c.clear()
        c.set(year, month - 1, day, hour, minute, 0)
        c.timeInMillis
    } catch (e: Exception) {
        null
    }
}

fun daysLabel(days: List<Int>): String {
    if (days.size == 7) return "Todos os dias"
    if (days.size == 5 && (1..5).all { it in days }) return "Dias úteis"
    return days.sorted().joinToString(", ") { WEEKDAYS[it] }
}
