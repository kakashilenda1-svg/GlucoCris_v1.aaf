package com.agon.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Histórico persistente de análises de rótulo (SharedPreferences).
 * Não mistura com registros de glicemia.
 */
object LabelScanStore {
    private const val PREFS = "gluco_label_scan_history"
    private const val KEY = "entries_v1"
    private const val MAX = 80

    data class Entry(
        val id: String,
        val at: Long,
        val productName: String?,
        val brand: String?,
        val netWeight: String?,
        val servingSize: String?,
        val carbs: Double?,
        val sugars: Double?,
        val protein: Double?,
        val fat: Double?,
        val kcal: Double?,
        val fiber: Double?,
        val sodium: Double?,
        val ingredientsSummary: String?,
        val provider: String?,
        val notes: String?,
        /** JSON completo opcional para reabrir detalhes. */
        val rawJson: String? = null,
    )

    fun load(ctx: Context): List<Entry> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i ->
                val o = arr.optJSONObject(i) ?: return@mapNotNull null
                Entry(
                    id = o.optString("id").ifBlank { UUID.randomUUID().toString() },
                    at = o.optLong("at", 0L),
                    productName = o.optString("productName").takeIf { it.isNotBlank() },
                    brand = o.optString("brand").takeIf { it.isNotBlank() },
                    netWeight = o.optString("netWeight").takeIf { it.isNotBlank() },
                    servingSize = o.optString("servingSize").takeIf { it.isNotBlank() },
                    carbs = o.optDoubleOrNull("carbs"),
                    sugars = o.optDoubleOrNull("sugars"),
                    protein = o.optDoubleOrNull("protein"),
                    fat = o.optDoubleOrNull("fat"),
                    kcal = o.optDoubleOrNull("kcal"),
                    fiber = o.optDoubleOrNull("fiber"),
                    sodium = o.optDoubleOrNull("sodium"),
                    ingredientsSummary = o.optString("ingredientsSummary").takeIf { it.isNotBlank() },
                    provider = o.optString("provider").takeIf { it.isNotBlank() },
                    notes = o.optString("notes").takeIf { it.isNotBlank() },
                    rawJson = o.optString("rawJson").takeIf { it.isNotBlank() },
                )
            }.sortedByDescending { it.at }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun save(ctx: Context, list: List<Entry>) {
        val arr = JSONArray()
        list.take(MAX).forEach { e ->
            arr.put(
                JSONObject()
                    .put("id", e.id)
                    .put("at", e.at)
                    .put("productName", e.productName ?: "")
                    .put("brand", e.brand ?: "")
                    .put("netWeight", e.netWeight ?: "")
                    .put("servingSize", e.servingSize ?: "")
                    .put("carbs", e.carbs ?: JSONObject.NULL)
                    .put("sugars", e.sugars ?: JSONObject.NULL)
                    .put("protein", e.protein ?: JSONObject.NULL)
                    .put("fat", e.fat ?: JSONObject.NULL)
                    .put("kcal", e.kcal ?: JSONObject.NULL)
                    .put("fiber", e.fiber ?: JSONObject.NULL)
                    .put("sodium", e.sodium ?: JSONObject.NULL)
                    .put("ingredientsSummary", e.ingredientsSummary ?: "")
                    .put("provider", e.provider ?: "")
                    .put("notes", e.notes ?: "")
                    .put("rawJson", e.rawJson ?: ""),
            )
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun add(ctx: Context, result: LabelAnalysisResult): Entry {
        val base = result.nutrition?.perServing ?: result.nutrition?.per100g
        val entry = Entry(
            id = UUID.randomUUID().toString(),
            at = System.currentTimeMillis(),
            productName = result.productName,
            brand = result.brand,
            netWeight = result.netWeight,
            servingSize = result.nutrition?.servingSize,
            carbs = base?.carbs,
            sugars = base?.sugars,
            protein = base?.protein,
            fat = base?.fat,
            kcal = base?.kcal,
            fiber = base?.fiber,
            sodium = base?.sodium,
            ingredientsSummary = result.ingredients.take(12).joinToString(", ") { it.name }.ifBlank { null },
            provider = result.provider,
            notes = result.notes ?: result.confidenceNotes,
            rawJson = null,
        )
        val next = listOf(entry) + load(ctx)
        save(ctx, next)
        return entry
    }

    fun delete(ctx: Context, id: String) {
        save(ctx, load(ctx).filter { it.id != id })
    }

    fun clear(ctx: Context) {
        save(ctx, emptyList())
    }

    private fun JSONObject.optDoubleOrNull(key: String): Double? {
        if (!has(key) || isNull(key)) return null
        return try { getDouble(key) } catch (_: Exception) { null }
    }

    fun buildCrisContext(result: LabelAnalysisResult): String {
        return buildString {
            append("Contexto do rótulo analisado no Cris Scanner:\n")
            append("Produto: ${result.productName ?: "não identificado"}")
            if (!result.brand.isNullOrBlank()) append(" (${result.brand})")
            append("\n")
            result.netWeight?.let { append("Peso/volume: $it\n") }
            result.nutrition?.servingSize?.let { append("Porção: $it\n") }
            val n = result.nutrition?.perServing ?: result.nutrition?.per100g
            val basis = if (result.nutrition?.perServing != null) "por porção" else "por 100 g"
            if (n != null) {
                append("Valores nutricionais ($basis):\n")
                n.kcal?.let { append("• Calorias: ${it.toInt()} kcal\n") }
                n.carbs?.let { append("• Carboidratos: $it g\n") }
                n.sugars?.let { append("• Açúcares: $it g\n") }
                n.addedSugars?.let { append("• Açúcares adicionados: $it g\n") }
                n.protein?.let { append("• Proteínas: $it g\n") }
                n.fat?.let { append("• Gorduras: $it g\n") }
                n.fiber?.let { append("• Fibras: $it g\n") }
                n.sodium?.let { append("• Sódio: $it mg\n") }
            }
            if (result.ingredients.isNotEmpty()) {
                append("Ingredientes:\n")
                result.ingredients.take(20).forEach { ing ->
                    append("• ${ing.name}")
                    if (ing.isSugarOrSweetener) append(" [açúcar/adoçante]")
                    if (ing.mayRaiseGlucose) append(" [pode elevar glicemia]")
                    append(" — ${ing.simpleExplanation}\n")
                }
            }
            if (result.allergens.isNotEmpty()) {
                append("Alergênicos: ${result.allergens.joinToString(", ")}\n")
            }
            append("\nUse apenas esses dados. Se algo não estiver no rótulo, diga que não foi identificado. Não invente valores.")
        }
    }

    fun buildCrisContextFromEntry(e: Entry): String {
        return buildString {
            append("Contexto de análise anterior do Cris Scanner:\n")
            append("Produto: ${e.productName ?: "não identificado"}")
            if (!e.brand.isNullOrBlank()) append(" (${e.brand})")
            append("\n")
            e.servingSize?.let { append("Porção: $it\n") }
            e.carbs?.let { append("• Carboidratos: $it g\n") }
            e.sugars?.let { append("• Açúcares: $it g\n") }
            e.protein?.let { append("• Proteínas: $it g\n") }
            e.fat?.let { append("• Gorduras: $it g\n") }
            e.kcal?.let { append("• Calorias: ${it.toInt()} kcal\n") }
            e.ingredientsSummary?.let { append("Ingredientes: $it\n") }
            append("\nUse apenas esses dados. Não invente valores.")
        }
    }
}
