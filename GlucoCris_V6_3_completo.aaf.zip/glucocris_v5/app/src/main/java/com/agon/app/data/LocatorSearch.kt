package com.agon.app.data

import java.text.Normalizer

/**
 * Interpretação do texto digitado no Localizador de Insulina.
 * Só reconhece nomes e grupos; NUNCA afirma equivalência terapêutica entre insulinas
 * e NUNCA troca a pesquisa do usuário sozinho: erros de digitação viram apenas SUGESTÃO.
 */
object LocatorSearch {
    private val MARKS = Regex("\\p{Mn}+")
    private val SPACES = Regex("\\s+")

    fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(MARKS, "")

    /** id -> nomes comerciais, princípio ativo e variações (já sem acento). */
    val INSULIN_ALIASES: Map<String, List<String>> = linkedMapOf(
        "nph" to listOf("nph", "humana nph", "humulin n", "novolin n"),
        "regular" to listOf("regular", "humana regular", "humulin r", "novolin r"),
        "glargina" to listOf("glargina", "lantus", "basaglar", "toujeo"),
        "degludeca" to listOf("degludeca", "tresiba"),
        "detemir" to listOf("detemir", "levemir"),
        "lispro" to listOf("lispro", "humalog"),
        "asparte" to listOf("asparte", "novorapid", "fiasp"),
        "glulisina" to listOf("glulisina", "apidra"),
    )

    // Termos populares / tipos. Mostram os produtos do grupo, sem dizer que são equivalentes.
    private val GROUPS: Map<String, List<String>> = mapOf(
        "rapida" to listOf("lispro", "asparte", "glulisina"),
        "rapidas" to listOf("lispro", "asparte", "glulisina"),
        "rapido" to listOf("lispro", "asparte", "glulisina"),
        "ultrarrapida" to listOf("lispro", "asparte", "glulisina"),
        "lenta" to listOf("glargina", "degludeca", "detemir"),
        "lentas" to listOf("glargina", "degludeca", "detemir"),
        "longa" to listOf("glargina", "degludeca", "detemir"),
        "basal" to listOf("glargina", "degludeca", "detemir"),
        "prolongada" to listOf("glargina", "degludeca", "detemir"),
        "intermediaria" to listOf("nph"),
        "curta" to listOf("regular"),
        "humana" to listOf("nph", "regular"),
        "humanas" to listOf("nph", "regular"),
        "analogo" to listOf("glargina", "degludeca", "detemir", "lispro", "asparte", "glulisina"),
        "analogos" to listOf("glargina", "degludeca", "detemir", "lispro", "asparte", "glulisina"),
    )

    private val STOP = setOf(
        "insulina", "insulinas", "de", "da", "do", "das", "dos", "em", "no", "na", "nos", "nas",
        "perto", "proximo", "proxima", "onde", "tem", "ter", "comprar", "achar", "encontrar",
        "medicamento", "medicamentos", "remedio", "remedios", "para", "a", "o", "e", "um", "uma",
        "por", "favor", "quero", "preciso", "buscar", "procurar", "com", "acao",
    )

    /** Vocabulário usado só para sugerir correções. */
    private val VOCAB: List<String> = (
        INSULIN_ALIASES.values.flatten().filter { !it.contains(' ') && it.length >= 4 } +
            GROUPS.keys +
            listOf(
                "insulina", "farmacia", "posto", "hospital", "clinica",
                "nutricionista", "dietista", "popular", "saude", "unidade",
            )
        ).distinct()

    data class Parsed(
        /** Insulinas reconhecidas (por nome, princípio ativo ou grupo). */
        val insulinIds: List<String>,
        /** Palavras restantes, para filtrar nome / endereço / tipo do local. */
        val tokens: List<String>,
        /** Pediu "farmácia popular": só prioriza, não filtra. */
        val popular: Boolean,
        /** Possível correção de digitação (nunca aplicada automaticamente). */
        val suggestion: String?,
    )

    /** [qNorm] = texto já passado por [norm]. */
    fun parse(qNorm: String): Parsed {
        val clean = qNorm.trim().replace(SPACES, " ")
        if (clean.isEmpty()) return Parsed(emptyList(), emptyList(), false, null)

        val ids = LinkedHashSet<String>()
        var rest = " $clean "
        // 1) nomes com mais de uma palavra ("humulin n", "humana nph")
        for ((id, aliases) in INSULIN_ALIASES) {
            for (a in aliases) {
                if (a.contains(' ') && rest.contains(" $a ")) {
                    ids += id
                    rest = rest.replace(" $a ", " ")
                }
            }
        }
        val words = rest.trim().split(' ').filter { it.isNotEmpty() }
        val hasFarmacia = words.any { it.startsWith("farmaci") }

        val tokens = mutableListOf<String>()
        var popular = false
        for (w in words) {
            val hit = matchInsulinWord(w)
            when {
                hit.isNotEmpty() -> ids += hit
                w in STOP -> {}
                w == "popular" && hasFarmacia -> popular = true
                else -> tokens += w
            }
        }

        var suggestion: String? = null
        for (t in tokens) {
            val s = suggestWord(t) ?: continue
            suggestion = clean.split(' ').joinToString(" ") { if (it == t) s else it }
            break
        }
        return Parsed(ids.toList(), tokens, popular, suggestion)
    }

    private fun matchInsulinWord(w: String): List<String> {
        GROUPS[w]?.let { return it }
        val out = mutableListOf<String>()
        for ((id, aliases) in INSULIN_ALIASES) {
            for (a in aliases) {
                if (a.contains(' ')) continue
                // prefixo só a partir de 4 letras, para "lant" achar "lantus" sem casar qualquer coisa
                if (a == w || (w.length >= 4 && a.startsWith(w))) { out += id; break }
            }
        }
        return out
    }

    private fun suggestWord(t: String): String? {
        if (t.length < 4) return null
        if (VOCAB.any { it == t || it.startsWith(t) }) return null // já é um termo (ou começo dele) válido
        val limit = if (t.length <= 5) 1 else 2
        var best: String? = null
        var bestD = Int.MAX_VALUE
        for (v in VOCAB) {
            if (kotlin.math.abs(v.length - t.length) > limit) continue
            val d = levenshtein(t, v)
            if (d in 1..limit && d < bestD) { best = v; bestD = d }
        }
        return best
    }

    fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return prev[b.length]
    }
}
