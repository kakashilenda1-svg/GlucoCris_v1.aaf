package com.agon.app.data

import java.util.Calendar

data class OpenStatus(val open: Boolean, val label: String)

/**
 * Leitor do campo opening_hours do OpenStreetMap (formatos mais comuns no Brasil):
 * "24/7", "Mo-Fr 08:00-18:00; Sa 08:00-12:00", "Mo-Su 07:00-22:00",
 * "Mo,We 08:00-12:00,13:00-17:00", "Su off", "PH off", horários que viram a meia-noite.
 * Retorna null quando o horário não é informado ou não dá para interpretar com segurança.
 */
object OpeningHours {
    private val DAYS = listOf("mo", "tu", "we", "th", "fr", "sa", "su")
    private val TIME = Regex("^(\\d{1,2}):(\\d{2})\\s*-\\s*(\\d{1,2}):(\\d{2})\\+?$")
    private val DAYS_TOKEN = Regex("^[a-z]{2}(\\s*-\\s*[a-z]{2})?(\\s*,\\s*[a-z]{2}(\\s*-\\s*[a-z]{2})?)*$")

    /** [dia 0=segunda..6=domingo] -> lista de intervalos em minutos (fim pode passar de 1440). */
    fun parse(raw: String): List<List<IntRange>>? {
        val text = raw.trim().lowercase()
        if (text.isEmpty()) return null
        val week = MutableList(7) { emptyList<IntRange>() }
        if (text == "24/7" || text == "mo-su 00:00-24:00") return List(7) { listOf(0..1440) }
        var anyRule = false
        for (ruleRaw in text.split(";", "||")) {
            val rule = ruleRaw.trim()
            if (rule.isEmpty()) continue
            if (rule.startsWith("ph") || rule.startsWith("sh")) continue
            // separa dias e horários
            val firstDigit = rule.indexOfFirst { it.isDigit() }
            val offIdx = listOf(" off", " closed").map { rule.indexOf(it) }.filter { it >= 0 }.minOrNull()
            val daysPart: String
            val timesPart: String
            when {
                rule == "off" || rule == "closed" -> { daysPart = ""; timesPart = "off" }
                offIdx != null && (firstDigit < 0 || offIdx < firstDigit) -> {
                    daysPart = rule.substring(0, offIdx).trim(); timesPart = "off"
                }
                firstDigit < 0 -> return null
                else -> { daysPart = rule.substring(0, firstDigit).trim().trimEnd(':'); timesPart = rule.substring(firstDigit).trim() }
            }
            val days = parseDays(daysPart.replace(Regex(",?\\s*ph$"), "").trim()) ?: return null
            val intervals: List<IntRange> = if (timesPart == "off") emptyList() else {
                timesPart.split(",").map { it.trim() }.filter { it.isNotEmpty() }.map { t ->
                    val m = TIME.find(t) ?: return null
                    val (h1, m1, h2, m2) = m.destructured
                    val start = h1.toInt() * 60 + m1.toInt()
                    var end = h2.toInt() * 60 + m2.toInt()
                    if (start > 1440 || end > 1440) return null
                    if (end <= start) end += 1440
                    start..end
                }
            }
            days.forEach { week[it] = intervals }
            anyRule = true
        }
        return if (anyRule) week else null
    }

    private fun parseDays(part: String): List<Int>? {
        if (part.isEmpty()) return (0..6).toList()
        if (!DAYS_TOKEN.matches(part)) return null
        val out = mutableListOf<Int>()
        part.split(",").map { it.trim() }.forEach { token ->
            val bits = token.split("-").map { it.trim() }
            val a = DAYS.indexOf(bits[0]); if (a < 0) return null
            if (bits.size == 1) out.add(a) else {
                val b = DAYS.indexOf(bits[1]); if (b < 0) return null
                var d = a
                while (true) { out.add(d); if (d == b) break; d = (d + 1) % 7 }
            }
        }
        return out.distinct()
    }

    private fun fmt(min: Int): String {
        val m = ((min % 1440) + 1440) % 1440
        return "%02d:%02d".format(m / 60, m % 60)
    }

    fun status(raw: String, now: Calendar = Calendar.getInstance()): OpenStatus? {
        val week = parse(raw) ?: return null
        val today = (now.get(Calendar.DAY_OF_WEEK) + 5) % 7
        val yesterday = (today + 6) % 7
        val minute = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        if (week.all { d -> d.any { it.first == 0 && it.last >= 1440 } }) return OpenStatus(true, "Aberto 24 horas")
        week[today].firstOrNull { minute in it.first until it.last }?.let {
            return OpenStatus(true, if (it.last >= 1440 && it.first == 0) "Aberto agora" else "Aberto · fecha às ${fmt(it.last)}")
        }
        week[yesterday].firstOrNull { it.last > 1440 && minute + 1440 in it.first until it.last }?.let {
            return OpenStatus(true, "Aberto · fecha às ${fmt(it.last)}")
        }
        val next = week[today].filter { it.first > minute }.minByOrNull { it.first }
        return OpenStatus(false, if (next != null) "Fechado · abre às ${fmt(next.first)}" else "Fechado agora")
    }
}
