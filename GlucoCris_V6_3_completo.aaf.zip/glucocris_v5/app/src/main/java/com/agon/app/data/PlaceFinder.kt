package com.agon.app.data

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Looper
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.joinAll
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

enum class PlaceKind(val label: String) {
    FARMACIA("Farmácia"),
    UBS("Posto / UBS"),
    HOSPITAL("Hospital / UPA"),
    CLINICA("Clínica"),
}

@Serializable
data class HealthPlace(
    val id: String,
    val name: String,
    val kind: PlaceKind,
    val lat: Double,
    val lon: Double,
    val distanceKm: Double,
    val address: String,
    val phone: String,
    val hours: String,
    val is24h: Boolean,
    val website: String,
    val brand: String,
    /** Origem da informação (hoje só OpenStreetMap). */
    val source: String = "OpenStreetMap",
    /** Quando o dado foi obtido da fonte (epoch ms). 0 = desconhecido. */
    val fetchedAt: Long = 0L,
)

/** Limites ajustáveis do localizador (tempos em ms). */
object LocatorConfig {
    /** Tempo máximo de cada tentativa em cada servidor. */
    @Volatile var mirrorTimeoutMs = 9_000L
    /** Raio (km) da busca rápida inicial: resposta pequena, chega quase na hora. */
    @Volatile var fastRadiusKm = 2
    /** Intervalo até acionar o próximo servidor reserva se o anterior ainda não respondeu. */
    @Volatile var hedgeDelayMs = 600L
    /** Tentativas por fonte (cada tentativa consulta os servidores em corrida). Nunca infinito. */
    @Volatile var maxAttempts = 2
    /** Espera antes da 2ª tentativa; dobra a cada nova tentativa (backoff exponencial). */
    @Volatile var backoffBaseMs = 700L
    /** Teto de tempo total de uma fonte, somando todas as tentativas. */
    @Volatile var sourceBudgetMs = 20_000L
    /** Validade máxima do cache. Depois disso o dado é descartado. */
    @Volatile var cacheTtlMs = 3 * 24 * 60 * 60_000L
    /** Até esta idade o cache é usado sem consultar a rede. Acima, mostra e atualiza em segundo plano. */
    @Volatile var cacheFreshMs = 30 * 60_000L
    @Volatile var maxPlacesPerSource = 700
}

/** Fontes independentes, consultadas em paralelo. */
const val SRC_FARMACIAS = "farmacias"
const val SRC_UNIDADES = "unidades"

/** Foto da busca em andamento. Emitida várias vezes: a cada fonte que responde. */
data class SearchState(
    val places: List<HealthPlace>,
    val finished: Boolean,
    val okSources: Set<String>,
    val failedSources: Set<String>,
    /** Horário do dado mais antigo vindo do cache e ainda não atualizado (null = tudo veio da rede). */
    val cacheAt: Long?,
    val radiusKm: Int,
)

@Serializable
internal data class CacheRow(val key: String, val at: Long, val radiusKm: Int, val places: List<HealthPlace>)

@Serializable
internal data class CacheFile(val rows: List<CacheRow>)

/**
 * Dados públicos OSM (Overpass). Busca paralela por fonte, corrida entre servidores (hedged),
 * timeout por fonte, cancelamento real da conexão, retentativa com backoff, cache em memória + disco.
 */
object PlaceFinder {
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private const val UA = "GlucoCris/1.5 (localizador insulina; Android)"

    val SOURCES = listOf(SRC_FARMACIAS, SRC_UNIDADES)

    private val OVERPASS = listOf(
        "https://overpass.kumi.systems/api/interpreter",
        "https://overpass-api.de/api/interpreter",
        "https://overpass.private.coffee/api/interpreter",
        "https://overpass.openstreetmap.fr/api/interpreter",
        "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
    )

    @Volatile private var preferredMirror: String? = null

    private fun orderedMirrors(): List<String> {
        val p = preferredMirror
        return if (p != null && p in OVERPASS) listOf(p) + OVERPASS.filter { it != p } else OVERPASS
    }

    // ---------------------------------------------------------------- HTTP cancelável

    /** Requisição que de fato aborta a conexão quando a corrotina é cancelada. */
    private suspend fun http(url: String, body: String?, connectMs: Int, readMs: Int): String =
        suspendCancellableCoroutine { cont ->
            val holder = AtomicReference<HttpURLConnection?>(null)
            val worker = Thread {
                try {
                    if (!cont.isActive) return@Thread
                    val c = URL(url).openConnection() as HttpURLConnection
                    holder.set(c)
                    c.connectTimeout = connectMs
                    c.readTimeout = readMs
                    c.setRequestProperty("User-Agent", UA)
                    c.setRequestProperty("Accept-Language", "pt-BR")
                    if (body != null) {
                        c.requestMethod = "POST"
                        c.doOutput = true
                        c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8")
                        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                    }
                    val code = c.responseCode
                    if (code !in 200..299) throw IllegalStateException("HTTP $code")
                    val text = c.inputStream.bufferedReader().use { it.readText() }
                    if (cont.isActive) cont.resume(text)
                } catch (e: Throwable) {
                    if (cont.isActive) cont.resumeWithException(e)
                } finally {
                    runCatching { holder.get()?.disconnect() }
                }
            }
            worker.isDaemon = true
            cont.invokeOnCancellation { runCatching { holder.get()?.disconnect() } }
            worker.start()
        }

    // ---------------------------------------------------------------- localização

    private val locExec = Executors.newSingleThreadExecutor { r -> Thread(r).apply { isDaemon = true } }
    @Volatile private var lastFix: Location? = null
    @Volatile private var lastFixAt = 0L

    @SuppressLint("MissingPermission")
    suspend fun currentLocation(context: Context): Location? {
        // Evita pedir GPS de novo se acabou de obter (2 min)
        lastFix?.let { if (System.currentTimeMillis() - lastFixAt < 2 * 60_000L) return it }

        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
            .filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }

        val last = providers.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time < 15 * 60_000) {
            rememberFix(last); return last
        }

        for (p in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)) {
            if (p !in providers) continue
            val timeout = if (p == LocationManager.NETWORK_PROVIDER) 3_000L else 6_000L
            val fresh = withTimeoutOrNull(timeout) { single(lm, p) }
            if (fresh != null) { rememberFix(fresh); return fresh }
        }
        if (last != null) rememberFix(last)
        return last
    }

    private fun rememberFix(l: Location) { lastFix = l; lastFixAt = System.currentTimeMillis() }

    fun locationEnabled(context: Context): Boolean {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return runCatching {
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) ||
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
        }.getOrDefault(false)
    }

    @SuppressLint("MissingPermission")
    private suspend fun single(lm: LocationManager, provider: String): Location? =
        suspendCancellableCoroutine { cont ->
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    val signal = android.os.CancellationSignal()
                    cont.invokeOnCancellation { runCatching { signal.cancel() } }
                    lm.getCurrentLocation(provider, signal, locExec) { loc -> if (cont.isActive) cont.resume(loc) }
                } else {
                    val l = object : LocationListener {
                        override fun onLocationChanged(location: Location) {
                            if (cont.isActive) cont.resume(location)
                        }
                        @Deprecated("Deprecated in Java")
                        override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
                        override fun onProviderEnabled(provider: String) {}
                        override fun onProviderDisabled(provider: String) {
                            if (cont.isActive) cont.resume(null)
                        }
                    }
                    @Suppress("DEPRECATION")
                    lm.requestSingleUpdate(provider, l, Looper.getMainLooper())
                    cont.invokeOnCancellation { lm.removeUpdates(l) }
                }
            } catch (_: Exception) {
                if (cont.isActive) cont.resume(null)
            }
        }

    // ---------------------------------------------------------------- geocodificação (cache + 1 retentativa)

    private val geoCache = ConcurrentHashMap<String, Pair<Double, Double>>()
    private val reverseCache = ConcurrentHashMap<String, String>()

    suspend fun geocode(query: String): Pair<Double, Double>? = withContext(Dispatchers.IO) {
        val key = query.trim().lowercase()
        geoCache[key]?.let { return@withContext it }
        repeat(2) { attempt ->
            try {
                val q = URLEncoder.encode("$query, Brasil", "UTF-8")
                val body = withTimeoutOrNull(8_000) {
                    http("https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=br&q=$q", null, 5_000, 7_000)
                }
                if (body != null) {
                    val o = json.parseToJsonElement(body).jsonArray.firstOrNull()?.jsonObject
                        ?: return@withContext null // resposta válida, mas cidade não existe: sem retentar
                    val lat = o["lat"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull()
                    val lon = o["lon"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull()
                    if (lat != null && lon != null) {
                        geoCache[key] = lat to lon
                        return@withContext lat to lon
                    }
                    return@withContext null
                }
            } catch (e: CancellationException) {
                throw e
            } catch (_: Exception) {
            }
            if (attempt == 0) delay(500)
        }
        null
    }

    suspend fun reverse(lat: Double, lon: Double): String? = withContext(Dispatchers.IO) {
        val key = "%.3f|%.3f".format(Locale.US, lat, lon)
        reverseCache[key]?.let { return@withContext it }
        try {
            val body = withTimeoutOrNull(6_000) {
                http(
                    "https://nominatim.openstreetmap.org/reverse?format=json&zoom=14&lat=${"%.5f".format(Locale.US, lat)}&lon=${"%.5f".format(Locale.US, lon)}",
                    null, 4_000, 5_000,
                )
            } ?: return@withContext null
            val a = json.parseToJsonElement(body).jsonObject["address"]?.jsonObject ?: return@withContext null
            fun s(k: String) = a[k]?.jsonPrimitive?.contentOrNull
            val area = s("suburb") ?: s("neighbourhood") ?: s("city_district")
            val city = s("city") ?: s("town") ?: s("municipality") ?: s("village")
            listOfNotNull(area, city).joinToString(", ").ifBlank { null }?.also { reverseCache[key] = it }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            null
        }
    }

    // ---------------------------------------------------------------- cache (memória + disco)

    private val mem = ConcurrentHashMap<String, CacheRow>()
    private val diskLock = Any()
    private var diskLoaded = false
    private var cacheFile: File? = null
    private const val MAX_ROWS = 24

    /** Chave por grade de ~550 m (localização aproximada, não exata) + fonte. */
    private fun cacheKey(src: String, lat: Double, lon: Double): String =
        "$src|${Math.round(lat * 200)}|${Math.round(lon * 200)}"

    private fun ensureDisk(context: Context) {
        synchronized(diskLock) {
            if (diskLoaded) return
            diskLoaded = true
            val f = File(context.cacheDir, "locator_cache_v2.json")
            cacheFile = f
            try {
                if (f.exists()) {
                    val now = System.currentTimeMillis()
                    json.decodeFromString(CacheFile.serializer(), f.readText()).rows
                        .filter { now - it.at < LocatorConfig.cacheTtlMs }
                        .forEach { mem[it.key] = it }
                }
            } catch (_: Exception) {
                runCatching { f.delete() }
            }
        }
    }

    private fun persist() {
        synchronized(diskLock) {
            val f = cacheFile ?: return
            try {
                val now = System.currentTimeMillis()
                val rows = mem.values.filter { now - it.at < LocatorConfig.cacheTtlMs }.sortedByDescending { it.at }.take(MAX_ROWS)
                f.writeText(json.encodeToString(CacheFile.serializer(), CacheFile(rows)))
            } catch (_: Exception) {
            }
        }
    }

    private fun lookup(src: String, lat: Double, lon: Double, radiusKm: Int): CacheRow? {
        val row = mem[cacheKey(src, lat, lon)] ?: return null
        val age = System.currentTimeMillis() - row.at
        if (age >= LocatorConfig.cacheTtlMs) { mem.remove(row.key); return null }
        return if (row.radiusKm >= radiusKm) row else null
    }

    private fun store(src: String, lat: Double, lon: Double, radiusKm: Int, places: List<HealthPlace>) {
        val key = cacheKey(src, lat, lon)
        mem[key] = CacheRow(key, System.currentTimeMillis(), radiusKm, places.take(LocatorConfig.maxPlacesPerSource))
        if (mem.size > MAX_ROWS) {
            mem.values.sortedBy { it.at }.take(mem.size - MAX_ROWS).forEach { mem.remove(it.key) }
        }
        persist()
    }

    private fun withDistance(list: List<HealthPlace>, lat: Double, lon: Double): List<HealthPlace> =
        list.map { it.copy(distanceKm = distanceKm(lat, lon, it.lat, it.lon)) }.sortedBy { it.distanceKm }

    // ---------------------------------------------------------------- busca

    /**
     * Busca progressiva. Cada fonte (farmácias / postos-hospitais-clínicas) roda em paralelo e tem seu
     * próprio timeout: o fluxo emite um novo [SearchState] sempre que uma fonte responde ou falha.
     * [only] = repetir só estas fontes (botão "Tentar novamente"). [force] = ignorar cache.
     */
    fun searchFlow(
        context: Context,
        lat: Double,
        lon: Double,
        radiusKm: Int,
        only: Set<String>? = null,
        force: Boolean = false,
    ): Flow<SearchState> = channelFlow {
        val app = context.applicationContext
        withContext(Dispatchers.IO) { ensureDisk(app) }

        val sources = SOURCES.filter { only == null || it in only }
        val lock = Mutex()
        val bySource = HashMap<String, List<HealthPlace>>()
        val ok = LinkedHashSet<String>()
        val failed = LinkedHashSet<String>()
        val cacheTimes = HashMap<String, Long>()
        var finished = false

        suspend fun publish() {
            val snap = lock.withLock {
                val merged = LinkedHashMap<String, HealthPlace>()
                bySource.values.forEach { l -> l.forEach { p -> merged.putIfAbsent(p.id, p) } }
                SearchState(
                    places = merged.values.sortedBy { it.distanceKm },
                    finished = finished,
                    okSources = ok.toSet(),
                    failedSources = failed.toSet(),
                    cacheAt = cacheTimes.values.minOrNull(),
                    radiusKm = radiusKm,
                )
            }
            send(snap)
        }

        // 1) cache: mostra na hora o que já temos
        val toFetch = mutableListOf<String>()
        val now = System.currentTimeMillis()
        lock.withLock {
            for (s in sources) {
                val row = if (force) null else lookup(s, lat, lon, radiusKm)
                if (row != null) {
                    bySource[s] = withDistance(row.places, lat, lon)
                    cacheTimes[s] = row.at
                    if (now - row.at < LocatorConfig.cacheFreshMs) ok += s else toFetch += s
                } else {
                    toFetch += s
                }
            }
        }
        if (bySource.isNotEmpty()) publish()
        if (toFetch.isEmpty()) {
            finished = true
            publish()
            return@channelFlow
        }

        // 2) rede: fontes em paralelo; cada uma publica assim que termina
        coroutineScope {
            toFetch.map { s ->
                launch(Dispatchers.IO) {
                    val fetchedAt = System.currentTimeMillis()
                    // 2a) busca rápida num raio pequeno: aparece em instantes enquanto a completa carrega
                    val hasCache = lock.withLock { bySource.containsKey(s) }
                    var fast: List<HealthPlace>? = null
                    var fastFailed = false
                    if (!hasCache && !force && radiusKm > LocatorConfig.fastRadiusKm) {
                        val fp = fetchSource(s, lat, lon, LocatorConfig.fastRadiusKm, fetchedAt, 8_000L, 1)
                        if (fp != null) {
                            fast = fp
                            lock.withLock { bySource[s] = fp }
                            store(s, lat, lon, LocatorConfig.fastRadiusKm, fp)
                            publish()
                        } else {
                            fastFailed = true
                        }
                    }
                    // 2b) busca completa no raio pedido
                    val full = if (fastFailed) fetchSource(s, lat, lon, radiusKm, fetchedAt, 12_000L, 1)
                    else fetchSource(s, lat, lon, radiusKm, fetchedAt)
                    // une com a rápida: o limite por consulta não pode esconder os locais mais perto
                    val fastList = fast
                    val list = if (full != null && fastList != null) {
                        (full + fastList).distinctBy { it.id }.sortedBy { it.distanceKm }
                    } else full
                    lock.withLock {
                        if (list != null) {
                            bySource[s] = list
                            ok += s; failed -= s; cacheTimes.remove(s)
                        } else {
                            failed += s; ok -= s // mantém dado antigo do cache, se houver
                        }
                    }
                    if (list != null) store(s, lat, lon, radiusKm, list)
                    publish()
                }
            }.joinAll()
        }
        finished = true
        publish()
    }

    private fun buildQuery(src: String, lat: Double, lon: Double, radiusKm: Int): String {
        val r = (radiusKm * 1000).coerceIn(500, 50_000)
        val a = "(around:$r,${"%.5f".format(Locale.US, lat)},${"%.5f".format(Locale.US, lon)})"
        val body = if (src == SRC_FARMACIAS) {
            "nwr[amenity=pharmacy]$a;nwr[healthcare=pharmacy]$a;"
        } else {
            "nwr[amenity=hospital]$a;nwr[healthcare=hospital]$a;nwr[healthcare=centre]$a;" +
                "nwr[amenity=clinic]$a;nwr[amenity=doctors]$a;" +
                "nwr[healthcare=dietitian]$a;nwr[healthcare=nutritionist]$a;" +
                "nwr[\"healthcare:speciality\"~\"nutrition|dietetics|dietitian\"]$a;"
        }
        val t = if (radiusKm <= LocatorConfig.fastRadiusKm) 8 else 15
        return "[out:json][timeout:$t];($body);out tags center qt ${LocatorConfig.maxPlacesPerSource};"
    }

    /** Uma fonte: até maxAttempts corridas entre servidores, com backoff exponencial e teto de tempo. */
    private suspend fun fetchSource(
        src: String, lat: Double, lon: Double, radiusKm: Int, fetchedAt: Long,
        budgetMs: Long = LocatorConfig.sourceBudgetMs,
        attempts: Int = LocatorConfig.maxAttempts,
    ): List<HealthPlace>? {
        val body = "data=" + URLEncoder.encode(buildQuery(src, lat, lon, radiusKm), "UTF-8")
        return withTimeoutOrNull(budgetMs) {
            var result: List<HealthPlace>? = null
            var attempt = 0
            while (result == null && attempt < attempts) {
                if (attempt > 0) delay(LocatorConfig.backoffBaseMs shl (attempt - 1))
                result = raceMirrors(body, lat, lon, fetchedAt)
                attempt++
            }
            result
        }
    }

    /**
     * Servidor 1 sai na hora; os reservas só entram se o anterior demorar (evita sobrecarregar servidores
     * públicos). O primeiro que responder com sucesso vence e os demais têm a conexão abortada.
     * Lista vazia com resposta válida conta como SUCESSO (região sem estabelecimentos).
     */
    private suspend fun raceMirrors(body: String, lat: Double, lon: Double, fetchedAt: Long): List<HealthPlace>? =
        coroutineScope {
            val mirrors = orderedMirrors()
            val results = Channel<Pair<String, List<HealthPlace>?>>(mirrors.size)
            val jobs = mirrors.mapIndexed { i, ep ->
                launch(Dispatchers.IO) {
                    if (i > 0) delay(LocatorConfig.hedgeDelayMs * i)
                    val r: List<HealthPlace>? = try {
                        val text = withTimeoutOrNull(LocatorConfig.mirrorTimeoutMs) {
                            http(ep, body, 4_000, LocatorConfig.mirrorTimeoutMs.toInt())
                        }
                        text?.let { parseElements(it, lat, lon, fetchedAt) }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (_: Exception) {
                        null
                    }
                    results.send(ep to r)
                }
            }
            var winner: List<HealthPlace>? = null
            for (i in mirrors.indices) {
                val (ep, r) = results.receive()
                if (r != null) { winner = r; preferredMirror = ep; break }
            }
            jobs.forEach { it.cancel() }
            winner
        }

    private val RX_UBS = Regex("(^|[^a-z0-9])(ubs|usf|esf|caps)([^a-z0-9]|$)")
    private val RX_UPA = Regex("(^|[^a-z0-9])upa([^a-z0-9]|$)")

    private fun parseElements(body: String, lat: Double, lon: Double, fetchedAt: Long): List<HealthPlace> {
        val root = json.parseToJsonElement(body).jsonObject
        val els = root["elements"]?.jsonArray
        val remark = root["remark"]?.jsonPrimitive?.contentOrNull
        // Overpass às vezes devolve 200 com "runtime error" e nada dentro: é falha, não "zero resultados".
        if (els == null || (els.isEmpty() && remark != null && remark.contains("error", ignoreCase = true))) {
            throw IllegalStateException("overpass: ${remark ?: "resposta sem elementos"}")
        }
        val seen = HashSet<String>(els.size * 2)
        return els.mapNotNull { el ->
            val o = el.jsonObject
            val tags = o["tags"]?.jsonObject ?: return@mapNotNull null
            fun t(k: String) = tags[k]?.jsonPrimitive?.contentOrNull.orEmpty()
            val (plat, plon) = coords(o) ?: return@mapNotNull null
            val name = t("name").ifBlank { t("brand") }.ifBlank { null } ?: return@mapNotNull null
            val amenity = t("amenity")
            val hc = t("healthcare")
            val n = name.lowercase()
            val kind = when {
                amenity == "pharmacy" || hc == "pharmacy" -> PlaceKind.FARMACIA
                amenity == "hospital" || hc == "hospital" ||
                    RX_UPA.containsMatchIn(n) || n.contains("pronto") || n.contains("hospital") -> PlaceKind.HOSPITAL
                hc == "centre" || RX_UBS.containsMatchIn(n) ||
                    n.contains("unidade basica") || n.contains("unidade básica") ||
                    n.contains("posto de saude") || n.contains("posto de saúde") ||
                    n.contains("saude da familia") || n.contains("saúde da família") -> PlaceKind.UBS
                else -> PlaceKind.CLINICA
            }
            val spec = t("healthcare:speciality").lowercase()
            val isNutri = kind != PlaceKind.FARMACIA && (
                hc == "dietitian" || hc == "nutritionist" ||
                    spec.contains("nutrition") || spec.contains("dietet") || spec.contains("dietitian") ||
                    n.contains("nutri") || n.contains("dietet")
                )
            val key = "${n}_${"%.4f".format(Locale.US, plat)}_${"%.4f".format(Locale.US, plon)}"
            if (!seen.add(key)) return@mapNotNull null
            val street = t("addr:street")
            val number = t("addr:housenumber")
            val district = t("addr:suburb").ifBlank { t("addr:district") }
            val city = t("addr:city")
            val address = listOf(
                listOf(street, number).filter { it.isNotBlank() }.joinToString(", "),
                district, city,
            ).filter { it.isNotBlank() }.joinToString(" · ")
            val hours = t("opening_hours")
            HealthPlace(
                id = "${o["type"]?.jsonPrimitive?.contentOrNull}_${o["id"]?.jsonPrimitive?.contentOrNull}",
                name = name,
                kind = kind,
                lat = plat,
                lon = plon,
                distanceKm = distanceKm(lat, lon, plat, plon),
                address = address,
                phone = t("phone").ifBlank { t("contact:phone") }.ifBlank { t("contact:mobile") }
                    .split(";").first().trim(),
                hours = hours,
                is24h = hours.trim() == "24/7",
                website = t("website").ifBlank { t("contact:website") },
                brand = (
                    t("brand") +
                        (if (isNutri) " nutricionista nutrição dietista" else "") +
                        t("ref:CRN").ifBlank { t("ref:crn") }.ifBlank { t("contact:crn") }
                            .let { if (it.isBlank()) "" else " CRN $it" }
                    ).trim(),
                fetchedAt = fetchedAt,
            )
        }.sortedBy { it.distanceKm }
    }

    private fun coords(o: JsonObject): Pair<Double, Double>? {
        val lat = o["lat"]?.jsonPrimitive?.doubleOrNull
            ?: o["center"]?.jsonObject?.get("lat")?.jsonPrimitive?.doubleOrNull
        val lon = o["lon"]?.jsonPrimitive?.doubleOrNull
            ?: o["center"]?.jsonObject?.get("lon")?.jsonPrimitive?.doubleOrNull
        return if (lat != null && lon != null) lat to lon else null
    }

    fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2) * sin(dLon / 2)
        return r * 2 * atan2(sqrt(a), sqrt(1 - a))
    }
}
