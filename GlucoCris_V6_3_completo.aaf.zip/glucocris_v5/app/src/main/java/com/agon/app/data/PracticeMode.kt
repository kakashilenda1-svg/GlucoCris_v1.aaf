package com.agon.app.data

/**
 * Modo simulação do tour: enquanto ativo, nada é gravado de verdade.
 * Os dados do app viram dados de exemplo e as preferências usam arquivos
 * temporários (apagados ao sair da simulação).
 */
object PracticeMode {
    @Volatile
    var active: Boolean = false

    val names: MutableSet<String> = java.util.Collections.synchronizedSet(mutableSetOf<String>())

    fun map(name: String): String =
        if (active) {
            val n = "practice__$name"
            names.add(n)
            n
        } else {
            name
        }
}
