package com.agon.app.data

import java.util.Calendar
import java.util.TimeZone

/** Primeiro nome do nome completo cadastrado (vazio se não houver). */
fun firstName(fullName: String): String = fullName.trim().split(Regex("\\s+")).firstOrNull().orEmpty()

/** Data de nascimento guardada como "aaaa-MM-dd". */
fun parseBirthDate(iso: String): Triple<Int, Int, Int>? {
    val p = iso.split("-")
    if (p.size != 3) return null
    val y = p[0].toIntOrNull() ?: return null
    val m = p[1].toIntOrNull() ?: return null
    val d = p[2].toIntOrNull() ?: return null
    if (m !in 1..12 || d !in 1..31) return null
    return Triple(y, m, d)
}

fun formatBirthDate(iso: String): String =
    parseBirthDate(iso)?.let { (y, m, d) -> "%02d/%02d/%04d".format(d, m, y) }.orEmpty()

/** Idade considerando se o aniversário já aconteceu neste ano. */
fun ageFrom(iso: String, now: Calendar = Calendar.getInstance()): Int? {
    val (y, m, d) = parseBirthDate(iso) ?: return null
    val cy = now.get(Calendar.YEAR)
    val cm = now.get(Calendar.MONTH) + 1
    val cd = now.get(Calendar.DAY_OF_MONTH)
    var age = cy - y
    if (cm < m || (cm == m && cd < d)) age--
    return if (age in 0..130) age else null
}

/** Converte o valor do seletor de data (meia-noite UTC) em "aaaa-MM-dd". */
fun isoFromPickerMillis(ms: Long): String {
    val c = Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply { timeInMillis = ms }
    return "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
}

fun pickerMillisFromIso(iso: String): Long? {
    val (y, m, d) = parseBirthDate(iso) ?: return null
    return Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
        clear(); set(y, m - 1, d)
    }.timeInMillis
}

fun formatCpf(digits: String): String {
    val d = digits.filter { it.isDigit() }.take(11)
    return buildString {
        d.forEachIndexed { i, c ->
            if (i == 3 || i == 6) append('.')
            if (i == 9) append('-')
            append(c)
        }
    }
}

/** Valida os dois dígitos verificadores do CPF. */
fun isValidCpf(raw: String): Boolean {
    val d = raw.filter { it.isDigit() }
    if (d.length != 11 || d.all { it == d[0] }) return false
    val n = d.map { it - '0' }
    fun dv(len: Int): Int {
        val sum = (0 until len).sumOf { n[it] * (len + 1 - it) }
        val r = (sum * 10) % 11
        return if (r == 10) 0 else r
    }
    return dv(9) == n[9] && dv(10) == n[10]
}

data class Mood(val id: String, val emoji: String, val label: String)

val MOODS = listOf(
    Mood("muito_feliz", "😄", "Muito feliz"),
    Mood("feliz", "🙂", "Feliz"),
    Mood("tranquilo", "😌", "Tranquilo"),
    Mood("neutro", "😐", "Neutro"),
    Mood("cansado", "😴", "Cansado"),
    Mood("ansioso", "😟", "Ansioso"),
    Mood("triste", "😢", "Triste"),
    Mood("irritado", "😠", "Irritado"),
)

fun moodOf(id: String): Mood? = MOODS.firstOrNull { it.id == id }
