package com.agon.app.data.insulin

/**
 * Geografia básica do Brasil para o localizador offline.
 * Lista completa extraída da versão original (194 municípios).
 */
object BrazilGeo {

    val ufs: List<UfInfo> = listOf(
        UfInfo("AC", "Acre", "Norte"),
        UfInfo("AL", "Alagoas", "Nordeste"),
        UfInfo("AP", "Amapá", "Norte"),
        UfInfo("AM", "Amazonas", "Norte"),
        UfInfo("BA", "Bahia", "Nordeste"),
        UfInfo("CE", "Ceará", "Nordeste"),
        UfInfo("DF", "Distrito Federal", "Centro-Oeste"),
        UfInfo("ES", "Espírito Santo", "Sudeste"),
        UfInfo("GO", "Goiás", "Centro-Oeste"),
        UfInfo("MA", "Maranhão", "Nordeste"),
        UfInfo("MT", "Mato Grosso", "Centro-Oeste"),
        UfInfo("MS", "Mato Grosso do Sul", "Centro-Oeste"),
        UfInfo("MG", "Minas Gerais", "Sudeste"),
        UfInfo("PA", "Pará", "Norte"),
        UfInfo("PB", "Paraíba", "Nordeste"),
        UfInfo("PR", "Paraná", "Sul"),
        UfInfo("PE", "Pernambuco", "Nordeste"),
        UfInfo("PI", "Piauí", "Nordeste"),
        UfInfo("RJ", "Rio de Janeiro", "Sudeste"),
        UfInfo("RN", "Rio Grande do Norte", "Nordeste"),
        UfInfo("RS", "Rio Grande do Sul", "Sul"),
        UfInfo("RO", "Rondônia", "Norte"),
        UfInfo("RR", "Roraima", "Norte"),
        UfInfo("SC", "Santa Catarina", "Sul"),
        UfInfo("SP", "São Paulo", "Sudeste"),
        UfInfo("SE", "Sergipe", "Nordeste"),
        UfInfo("TO", "Tocantins", "Norte"),
    )

    private val RAW_CITIES = """
AC|Rio Branco|-9.97|-67.81|C
AC|Cruzeiro do Sul|-7.63|-72.67|I
AC|Sena Madureira|-9.07|-68.67|I
AC|Tarauacá|-8.16|-70.77|I
AL|Maceió|-9.67|-35.74|C
AL|Arapiraca|-9.75|-36.66|I
AL|Rio Largo|-9.48|-35.85|M
AL|Palmeira dos Índios|-9.41|-36.63|I
AL|União dos Palmares|-9.16|-36.03|I
AP|Macapá|0.03|-51.07|C
AP|Santana|0.04|-51.18|M
AP|Laranjal do Jari|-0.80|-52.50|I
AP|Oiapoque|3.84|-51.83|I
AM|Manaus|-3.12|-60.02|C
AM|Parintins|-2.63|-56.74|I
AM|Manacapuru|-3.30|-60.62|M
AM|Itacoatiara|-3.14|-58.44|I
AM|Coari|-4.09|-63.14|I
AM|Tefé|-3.35|-64.71|I
BA|Salvador|-12.97|-38.50|C
BA|Feira de Santana|-12.27|-38.97|I
BA|Vitória da Conquista|-14.87|-40.84|I
BA|Camaçari|-12.70|-38.32|M
BA|Lauro de Freitas|-12.89|-38.33|M
BA|Itabuna|-14.79|-39.28|I
BA|Ilhéus|-14.79|-39.03|I
BA|Juazeiro|-9.42|-40.50|I
BA|Barreiras|-12.15|-44.99|I
BA|Alagoinhas|-12.14|-38.42|I
BA|Teófilo Otoni|-17.86|-41.51|I
CE|Fortaleza|-3.73|-38.52|C
CE|Caucaia|-3.73|-38.66|M
CE|Maracanaú|-3.87|-38.63|M
CE|Juazeiro do Norte|-7.21|-39.32|I
CE|Sobral|-3.69|-40.35|I
CE|Crato|-7.23|-39.41|I
CE|Iguatu|-6.36|-39.30|I
DF|Brasília (Plano Piloto)|-15.79|-47.88|C
DF|Ceilândia|-15.82|-48.11|M
DF|Taguatinga|-15.83|-48.05|M
DF|Gama|-16.02|-48.06|M
DF|Planaltina|-15.45|-47.61|M
DF|Samambaia|-15.88|-48.08|M
ES|Vitória|-20.32|-40.34|C
ES|Vila Velha|-20.33|-40.29|M
ES|Serra|-20.13|-40.31|M
ES|Cariacica|-20.26|-40.42|M
ES|Cachoeiro de Itapemirim|-20.85|-41.11|I
ES|Linhares|-19.39|-40.07|I
ES|Colatina|-19.54|-40.63|I
GO|Goiânia|-16.69|-49.26|C
GO|Aparecida de Goiânia|-16.82|-49.24|M
GO|Anápolis|-16.33|-48.95|I
GO|Rio Verde|-17.80|-50.93|I
GO|Luziânia|-16.25|-47.95|M
GO|Itumbiara|-18.42|-49.22|I
GO|Catalão|-18.17|-47.94|I
MA|São Luís|-2.53|-44.30|C
MA|São José de Ribamar|-2.56|-44.05|M
MA|Imperatriz|-5.53|-47.48|I
MA|Timon|-5.09|-42.84|I
MA|Caxias|-4.86|-43.36|I
MA|Bacabal|-4.23|-44.78|I
MT|Cuiabá|-15.60|-56.10|C
MT|Várzea Grande|-15.65|-56.13|M
MT|Rondonópolis|-16.47|-54.64|I
MT|Sinop|-11.86|-55.50|I
MT|Cáceres|-16.07|-57.68|I
MT|Sorriso|-12.54|-55.71|I
MS|Campo Grande|-20.44|-54.65|C
MS|Dourados|-22.22|-54.81|I
MS|Três Lagoas|-20.75|-51.68|I
MS|Corumbá|-19.01|-57.65|I
MS|Ponta Porã|-22.54|-55.73|I
MG|Belo Horizonte|-19.92|-43.94|C
MG|Contagem|-19.93|-44.05|M
MG|Betim|-19.97|-44.20|M
MG|Uberlândia|-18.91|-48.26|I
MG|Juiz de Fora|-21.76|-43.35|I
MG|Montes Claros|-16.73|-43.86|I
MG|Uberaba|-19.75|-47.93|I
MG|Governador Valadares|-18.85|-41.95|I
MG|Ipatinga|-19.47|-42.54|I
MG|Divinópolis|-20.14|-44.89|I
MG|Poços de Caldas|-21.79|-46.56|I
MG|Pouso Alegre|-22.23|-45.94|I
MG|Barbacena|-21.23|-43.77|I
MG|Sete Lagoas|-19.46|-44.25|M
PA|Belém|-1.46|-48.50|C
PA|Ananindeua|-1.37|-48.37|M
PA|Santarém|-2.44|-54.70|I
PA|Marabá|-5.37|-49.12|I
PA|Castanhal|-1.30|-47.92|M
PA|Parauapebas|-6.07|-49.90|I
PA|Altamira|-3.20|-52.21|I
PB|João Pessoa|-7.12|-34.86|C
PB|Campina Grande|-7.23|-35.88|I
PB|Santa Rita|-7.11|-34.97|M
PB|Bayeux|-7.13|-34.93|M
PB|Patos|-7.02|-37.28|I
PB|Sousa|-6.76|-38.23|I
PR|Curitiba|-25.43|-49.27|C
PR|São José dos Pinhais|-25.53|-49.20|M
PR|Colombo|-25.29|-49.22|M
PR|Londrina|-23.31|-51.16|I
PR|Maringá|-23.42|-51.94|I
PR|Ponta Grossa|-25.09|-50.16|I
PR|Cascavel|-24.96|-53.46|I
PR|Foz do Iguaçu|-25.52|-54.59|I
PR|Guarapuava|-25.39|-51.46|I
PR|Paranaí|-23.07|-52.46|I
PE|Recife|-8.05|-34.88|C
PE|Jaboatão dos Guararapes|-8.11|-35.01|M
PE|Olinda|-8.01|-34.86|M
PE|Paulista|-7.94|-34.87|M
PE|Caruaru|-8.28|-35.98|I
PE|Petrolina|-9.39|-40.50|I
PE|Cabo de Santo Agostinho|-8.29|-35.03|M
PE|Garanhuns|-8.88|-36.50|I
PI|Teresina|-5.09|-42.80|C
PI|Parnaíba|-2.90|-41.78|I
PI|Picos|-7.08|-41.47|I
PI|Floriano|-6.77|-43.02|I
PI|Piripiri|-4.27|-41.78|I
RJ|Rio de Janeiro|-22.91|-43.17|C
RJ|Niterói|-22.88|-43.10|M
RJ|São Gonçalo|-22.83|-43.05|M
RJ|Duque de Caxias|-22.79|-43.31|M
RJ|Nova Iguaçu|-22.76|-43.45|M
RJ|Belford Roxo|-22.76|-43.40|M
RJ|Campos dos Goytacazes|-21.75|-41.33|I
RJ|Petrópolis|-22.51|-43.18|M
RJ|Volta Redonda|-22.52|-44.10|I
RJ|Macaé|-22.37|-41.79|I
RJ|Cabo Frio|-22.88|-42.02|I
RN|Natal|-5.79|-35.21|C
RN|Parnamirim|-5.92|-35.26|M
RN|Mossoró|-5.19|-37.34|I
RN|Caicó|-6.46|-37.10|I
RN|Ceará-Mirim|-5.64|-35.42|M
RS|Porto Alegre|-30.03|-51.23|C
RS|Canoas|-29.92|-51.18|M
RS|Gravataí|-29.94|-50.99|M
RS|Novo Hamburgo|-29.69|-51.13|M
RS|Caxias do Sul|-29.17|-51.18|I
RS|Pelotas|-31.77|-52.34|I
RS|Santa Maria|-29.68|-53.81|I
RS|Passo Fundo|-28.26|-52.41|I
RS|Rio Grande|-32.03|-52.10|I
RS|Uruguaiana|-29.76|-57.09|I
RO|Porto Velho|-8.76|-63.90|C
RO|Ji-Paraná|-10.88|-61.95|I
RO|Ariquemes|-9.91|-63.04|I
RO|Vilhena|-12.74|-60.15|I
RO|Cacoal|-11.44|-61.45|I
RR|Boa Vista|2.82|-60.67|C
RR|Rorainópolis|0.94|-60.44|I
RR|Caracaraí|1.82|-61.13|I
SC|Florianópolis|-27.60|-48.55|C
SC|São José|-27.61|-48.63|M
SC|Joinville|-26.30|-48.85|I
SC|Blumenau|-26.92|-49.07|I
SC|Chapecó|-27.10|-52.62|I
SC|Criciúma|-28.68|-49.37|I
SC|Itajaí|-26.91|-48.66|I
SC|Lages|-27.82|-50.33|I
SP|São Paulo|-23.55|-46.63|C
SP|Guarulhos|-23.46|-46.53|M
SP|São Bernardo do Campo|-23.69|-46.56|M
SP|Santo André|-23.66|-46.53|M
SP|Osasco|-23.53|-46.79|M
SP|Campinas|-22.91|-47.06|I
SP|Santos|-23.96|-46.33|I
SP|Ribeirão Preto|-21.18|-47.81|I
SP|Sorocaba|-23.50|-47.46|I
SP|São José dos Campos|-23.18|-45.89|I
SP|Bauru|-22.31|-49.06|I
SP|Piracicaba|-22.73|-47.65|I
SP|São José do Rio Preto|-20.81|-49.38|I
SP|Presidente Prudente|-22.12|-51.39|I
SP|Araçatuba|-21.21|-50.43|I
SP|Marília|-22.21|-49.95|I
SP|Jundiaí|-23.19|-46.88|I
SP|Taubaté|-23.03|-45.56|I
SP|Franca|-20.54|-47.40|I
SP|Mogi das Cruzes|-23.52|-46.19|M
SE|Aracaju|-10.91|-37.07|C
SE|Nossa Senhora do Socorro|-10.85|-37.13|M
SE|Lagarto|-10.92|-37.67|I
SE|Itabaiana|-10.68|-37.43|I
TO|Palmas|-10.18|-48.33|C
TO|Araguaína|-7.19|-48.21|I
TO|Gurupi|-11.73|-49.07|I
TO|Porto Nacional|-10.71|-48.42|M
""".trimIndent()

    val cities: List<City> by lazy {
        RAW_CITIES.lines().mapNotNull { line ->
            val p = line.split("|")
            if (p.size < 5) return@mapNotNull null
            val tier = when (p[4].trim()) {
                "C" -> CityTier.CAPITAL
                "M" -> CityTier.METROPOLITANA
                else -> CityTier.INTERIOR
            }
            val normName = p[1].lowercase()
                .replace(Regex("[^a-z0-9]+"), "-")
                .trim('-')
            val id = "${p[0].lowercase()}-$normName"
            City(
                id = id,
                name = p[1],
                uf = p[0],
                lat = p[2].toDoubleOrNull() ?: 0.0,
                lon = p[3].toDoubleOrNull() ?: 0.0,
                tier = tier,
            )
        }
    }

    private val byId: Map<String, City> by lazy { cities.associateBy { it.id } }

    fun cityById(id: String): City? = byId[id]

    fun capitalOf(uf: String): City? =
        cities.find { it.uf == uf && it.tier == CityTier.CAPITAL }

    fun citiesOf(uf: String): List<City> =
        cities.filter { it.uf == uf }

    fun ufByCode(code: String): UfInfo? = ufs.find { it.code == code }

    fun searchCities(query: String): List<City> {
        if (query.isBlank()) return emptyList()
        val q = query.lowercase().trim()
        return cities.filter {
            it.name.lowercase().contains(q) || it.uf.lowercase() == q
        }.take(30)
    }
}
