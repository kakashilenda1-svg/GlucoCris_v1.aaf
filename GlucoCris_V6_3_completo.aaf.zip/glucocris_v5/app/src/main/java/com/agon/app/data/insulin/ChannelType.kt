package com.agon.app.data.insulin

/**
 * Canais oficiais de acesso à insulina no Brasil.
 * Dados baseados em fontes públicas (Ministério da Saúde, DATASUS, CMED/Anvisa).
 */
enum class ChannelType(
    val id: String,
    val officialName: String,
    val short: String,
    val reliability: Int,
    val priceTier: PriceTier,
    val stock: StockStatus,
    val sourceName: String,
    val sourceUrl: String,
    val phone: String,
    val hours: String,
) {
    FARMACIA_POPULAR(
        id = "farmacia_popular",
        officialName = "Programa Farmácia Popular do Brasil (Aqui Tem Farmácia Popular)",
        short = "Farmácia Popular",
        reliability = 88,
        priceTier = PriceTier.GRATUITO,
        stock = StockStatus.PROGRAMA_CONTINUO,
        sourceName = "Ministério da Saúde — Dados Abertos / Painel Farmácia Popular",
        sourceUrl = "https://www.gov.br/saude/pt-br/assuntos/farmacia-popular",
        phone = "Disque Saúde 136",
        hours = "Horário comercial das drogarias credenciadas (geralmente 8h–20h)",
    ),
    ATENCAO_BASICA(
        id = "atencao_basica",
        officialName = "Atenção Básica / Farmácia do SUS",
        short = "UBS / SUS",
        reliability = 92,
        priceTier = PriceTier.GRATUITO,
        stock = StockStatus.PROGRAMA_CONTINUO,
        sourceName = "CNES/DATASUS — Cadastro Nacional de Estabelecimentos de Saúde",
        sourceUrl = "https://cnes.datasus.gov.br",
        phone = "Disque Saúde 136",
        hours = "Geralmente das 7h às 17h em dias úteis (varia por município)",
    ),
    CEAF(
        id = "ceaf",
        officialName = "Farmácia do Componente Especializado da Assistência Farmacêutica (CEAF)",
        short = "CEAF / Alto custo",
        reliability = 90,
        priceTier = PriceTier.GRATUITO_PROCESSO,
        stock = StockStatus.MEDIANTE_PROCESSO,
        sourceName = "Ministério da Saúde / Secretaria de Estado da Saúde",
        sourceUrl = "https://www.gov.br/saude/pt-br",
        phone = "Disque Saúde 136 / Ouvidoria da SES",
        hours = "Dias úteis, conforme a unidade de referência estadual",
    ),
    PRIVADA(
        id = "privada",
        officialName = "Farmácias e drogarias da rede privada",
        short = "Rede privada",
        reliability = 68,
        priceTier = PriceTier.PMC_CMED,
        stock = StockStatus.NAO_MONITORADO,
        sourceName = "CMED/Anvisa — tabela oficial de preços de medicamentos",
        sourceUrl = "https://www.gov.br/anvisa/pt-br/assuntos/medicamentos/cmed",
        phone = "Consulte o estabelecimento",
        hours = "Varia por estabelecimento",
    );

    companion object {
        val allIds: Set<String> by lazy { entries.map { it.id }.toSet() }
        fun byId(id: String): ChannelType? = entries.find { it.id == id }
    }
}
