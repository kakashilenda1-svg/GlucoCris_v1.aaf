package com.agon.app.data.insulin

object InsulinCatalog {

    const val CH_ATENCAO_BASICA = "atencao_basica"
    const val CH_FARMACIA_POPULAR = "farmacia_popular"
    const val CH_CEAF = "ceaf"
    const val CH_PRIVADA = "privada"

    private val sus = setOf(CH_ATENCAO_BASICA, CH_FARMACIA_POPULAR)
    private val especializado = setOf(CH_CEAF)
    private val apenasPrivada = setOf(CH_PRIVADA)

    private const val NOTE_SUS =
        "Insulina humana 100 UI/mL dispensada gratuitamente na Atenção Primária do SUS e no Programa Farmácia Popular (lista oficial do Ministério da Saúde)."
    private const val NOTE_CEAF =
        "Disponível no Componente Especializado após processo administrativo (LME) conforme PCDT vigente."
    private const val NOTE_PRIVADA =
        "Disponível na rede privada. Preço regulado pelo teto PMC da CMED/Anvisa."

    val categories: List<InsulinCategory> = listOf(
        InsulinCategory(
            "regular", "Insulina humana regular (ação rápida)", "Humana Regular",
            "Insulina humana de ação rápida, usada em bolus de refeição e correção. Consta da RENAME e do Programa Farmácia Popular.",
            "30 min", "2 h a 3 h", "5 h a 8 h", "RENAME / Ministério da Saúde"
        ),
        InsulinCategory(
            "nph", "Insulina humana NPH (ação intermediária)", "Humana NPH",
            "Insulina humana de ação intermediária usada como basal. Consta da RENAME e do Programa Farmácia Popular.",
            "2 h a 4 h", "4 h a 10 h", "10 h a 18 h", "RENAME / Ministério da Saúde"
        ),
        InsulinCategory(
            "analogo_rapido", "Análogos de insulina de ação rápida / ultrarrápida", "Análogo rápido",
            "Análogos prandiais (lispro, asparte, glulisina). Dispensados pelo CEAF conforme critérios do PCDT do Diabete Melito tipo 1.",
            "5 min a 15 min", "1 h a 2 h", "3 h a 5 h", "PCDT Diabete Melito tipo 1 / Anvisa"
        ),
        InsulinCategory(
            "analogo_longo", "Análogos de insulina de ação prolongada (basal)", "Análogo basal",
            "Análogos basais (glargina, detemir, degludeca). Disponibilidade pública varia conforme PCDT e protocolos estaduais.",
            "1 h a 2 h", "sem pico pronunciado", "18 h a 42 h, conforme o análogo", "PCDT Diabete Melito tipo 1 / Anvisa"
        ),
        InsulinCategory(
            "pre_mistura", "Insulinas pré-misturadas (bifásicas)", "Pré-mistura",
            "Associações fixas de insulina de ação rápida com insulina de ação intermediária/prolongada em uma mesma apresentação.",
            "conforme o componente rápido", "bifásico", "conforme o componente basal", "Bulas e registros publicados pela Anvisa"
        ),
    )

    val products: List<InsulinProduct> = listOf(
        InsulinProduct("nph_generica", "Insulina Humana NPH 100 UI/mL", "insulina humana NPH (DNA recombinante)", "Laboratórios registrados na Anvisa / fornecimento SUS", "nph", listOf("100 UI/mL"), listOf("Frasco-ampola 10 mL", "Refil (carpule) 3 mL", "Caneta descartável 3 mL"), sus, NOTE_SUS, "RENAME / Programa Farmácia Popular"),
        InsulinProduct("humulin_n", "Humulin N", "insulina humana NPH (DNA recombinante)", "Eli Lilly", "nph", listOf("100 UI/mL"), listOf("Frasco-ampola 10 mL", "Refil 3 mL", "Caneta KwikPen 3 mL"), sus, NOTE_SUS, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("novolin_n", "Novolin N", "insulina humana NPH (DNA recombinante)", "Novo Nordisk", "nph", listOf("100 UI/mL"), listOf("Frasco-ampola 10 mL", "Refil Penfill 3 mL"), sus, NOTE_SUS, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("regular_generica", "Insulina Humana Regular 100 UI/mL", "insulina humana regular (DNA recombinante)", "Laboratórios registrados na Anvisa / fornecimento SUS", "regular", listOf("100 UI/mL"), listOf("Frasco-ampola 10 mL", "Refil (carpule) 3 mL"), sus, NOTE_SUS, "RENAME / Programa Farmácia Popular"),
        InsulinProduct("humulin_r", "Humulin R", "insulina humana regular (DNA recombinante)", "Eli Lilly", "regular", listOf("100 UI/mL"), listOf("Frasco-ampola 10 mL", "Refil 3 mL", "Caneta KwikPen 3 mL"), sus, NOTE_SUS, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("novolin_r", "Novolin R", "insulina humana regular (DNA recombinante)", "Novo Nordisk", "regular", listOf("100 UI/mL"), listOf("Frasco-ampola 10 mL", "Refil Penfill 3 mL"), sus, NOTE_SUS, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("humalog", "Humalog", "insulina lispro", "Eli Lilly", "analogo_rapido", listOf("100 UI/mL", "200 UI/mL"), listOf("Frasco-ampola 10 mL", "Refil 3 mL", "Caneta KwikPen 3 mL"), especializado, NOTE_CEAF, "PCDT Diabete Melito tipo 1 / Anvisa"),
        InsulinProduct("novorapid", "NovoRapid", "insulina asparte", "Novo Nordisk", "analogo_rapido", listOf("100 UI/mL"), listOf("Frasco-ampola 10 mL", "Refil Penfill 3 mL", "Caneta FlexPen 3 mL"), especializado, NOTE_CEAF, "PCDT Diabete Melito tipo 1 / Anvisa"),
        InsulinProduct("apidra", "Apidra", "insulina glulisina", "Sanofi", "analogo_rapido", listOf("100 UI/mL"), listOf("Frasco-ampola 10 mL", "Caneta SoloStar 3 mL", "Refil 3 mL"), especializado, NOTE_CEAF, "PCDT / registro Anvisa"),
        InsulinProduct("fiasp", "Fiasp", "insulina asparte (fórmula ultrarrápida)", "Novo Nordisk", "analogo_rapido", listOf("100 UI/mL"), listOf("Refil Penfill 3 mL", "Caneta FlexTouch 3 mL"), apenasPrivada, NOTE_PRIVADA, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("lyumjev", "Lyumjev", "insulina lispro (fórmula ultrarrápida)", "Eli Lilly", "analogo_rapido", listOf("100 UI/mL", "200 UI/mL"), listOf("Caneta KwikPen 3 mL", "Refil 3 mL"), apenasPrivada, NOTE_PRIVADA, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("lantus", "Lantus", "insulina glargina", "Sanofi", "analogo_longo", listOf("100 UI/mL"), listOf("Frasco-ampola 10 mL", "Caneta SoloStar 3 mL", "Refil 3 mL"), especializado, NOTE_CEAF, "PCDT Diabete Melito tipo 1 / Anvisa"),
        InsulinProduct("basaglar", "Basaglar", "insulina glargina", "Eli Lilly", "analogo_longo", listOf("100 UI/mL"), listOf("Caneta KwikPen 3 mL"), apenasPrivada, NOTE_PRIVADA, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("toujeo", "Toujeo", "insulina glargina 300 UI/mL", "Sanofi", "analogo_longo", listOf("300 UI/mL"), listOf("Caneta SoloStar 1,5 mL", "Caneta SoloStar 3 mL"), apenasPrivada, NOTE_PRIVADA, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("levemir", "Levemir", "insulina detemir", "Novo Nordisk", "analogo_longo", listOf("100 UI/mL"), listOf("Refil Penfill 3 mL", "Caneta FlexPen 3 mL"), apenasPrivada, NOTE_PRIVADA, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("tresiba", "Tresiba", "insulina degludeca", "Novo Nordisk", "analogo_longo", listOf("100 UI/mL", "200 UI/mL"), listOf("Refil Penfill 3 mL", "Caneta FlexTouch 3 mL"), apenasPrivada, NOTE_PRIVADA, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("humulin_7030", "Humulin 70/30", "insulina humana NPH 70% + insulina humana regular 30%", "Eli Lilly", "pre_mistura", listOf("100 UI/mL"), listOf("Frasco-ampola 10 mL", "Caneta KwikPen 3 mL"), apenasPrivada, NOTE_PRIVADA, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("novomix_30", "NovoMix 30", "insulina asparte bifásica (30% solúvel + 70% protamina)", "Novo Nordisk", "pre_mistura", listOf("100 UI/mL"), listOf("Refil Penfill 3 mL", "Caneta FlexPen 3 mL"), apenasPrivada, NOTE_PRIVADA, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("humalog_mix25", "Humalog Mix25", "insulina lispro 25% + insulina lispro protamina 75%", "Eli Lilly", "pre_mistura", listOf("100 UI/mL"), listOf("Caneta KwikPen 3 mL", "Refil 3 mL"), apenasPrivada, NOTE_PRIVADA, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("humalog_mix50", "Humalog Mix50", "insulina lispro 50% + insulina lispro protamina 50%", "Eli Lilly", "pre_mistura", listOf("100 UI/mL"), listOf("Caneta KwikPen 3 mL"), apenasPrivada, NOTE_PRIVADA, "Registro/bula publicados pela Anvisa"),
        InsulinProduct("ryzodeg", "Ryzodeg", "insulina degludeca 70% + insulina asparte 30%", "Novo Nordisk", "pre_mistura", listOf("100 UI/mL"), listOf("Refil Penfill 3 mL", "Caneta FlexTouch 3 mL"), apenasPrivada, NOTE_PRIVADA, "Registro/bula publicados pela Anvisa"),
    )

    fun categoryById(id: String): InsulinCategory? = categories.find { it.id == id }
    fun productById(id: String): InsulinProduct? = products.find { it.id == id }
    fun productsOf(categoryId: String): List<InsulinProduct> = products.filter { it.categoryId == categoryId }

    fun search(query: String): List<InsulinProduct> {
        if (query.isBlank()) return products
        val q = query.lowercase().trim()
        return products.filter { it.searchBlob.contains(q) || it.id.contains(q) }
    }
}
