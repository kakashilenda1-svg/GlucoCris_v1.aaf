package com.agon.app.data.insulin

enum class CityTier(val label: String) {
    CAPITAL("Capital"),
    METROPOLITANA("Região metropolitana"),
    INTERIOR("Interior");
}

enum class LocatorScope(val label: String) {
    BRASIL("Todo o Brasil"),
    UF("Estado"),
    CIDADE("Município");
}

enum class SortMode(val label: String) {
    PROXIMIDADE("Proximidade"),
    CONFIABILIDADE("Confiabilidade"),
    PRECO("Preço");
}

enum class PriceTier(val order: Int, val label: String, val detail: String) {
    GRATUITO(0, "Gratuito pelo SUS", "Dispensação gratuita (R$ 0,00) conforme a lista oficial do Ministério da Saúde."),
    GRATUITO_PROCESSO(1, "Gratuito mediante processo", "Dispensação gratuita após deferimento do processo no CEAF, conforme PCDT."),
    PMC_CMED(2, "Preço regulado — teto PMC", "Venda na rede privada com preço limitado ao PMC da CMED/Anvisa.");
}

enum class StockStatus(val label: String, val detail: String) {
    PROGRAMA_CONTINUO(
        "Abastecimento contínuo do programa",
        "O programa tem fornecimento contínuo, mas o estoque de cada unidade não é divulgado em tempo real. Confirme por telefone antes de se deslocar."
    ),
    MEDIANTE_PROCESSO(
        "Entrega programada após deferimento",
        "A entrega é programada pela SES após o deferimento do processo. O estoque não é publicado em tempo real."
    ),
    NAO_MONITORADO(
        "Estoque não monitorado oficialmente",
        "Não existe fonte oficial pública com o estoque das drogarias privadas. Consulte o estabelecimento."
    );
}

data class City(
    val id: String,
    val name: String,
    val uf: String,
    val lat: Double,
    val lon: Double,
    val tier: CityTier,
) {
    val label: String get() = "$name — $uf"
}

data class UfInfo(val code: String, val name: String, val region: String)

/** Categoria com farmacocinética (igual à v1). */
data class InsulinCategory(
    val id: String,
    val name: String,
    val shortName: String,
    val description: String,
    val onset: String,
    val peak: String,
    val duration: String,
    val source: String,
)

data class InsulinProduct(
    val id: String,
    val brandName: String,
    val activeIngredient: String,
    val manufacturer: String,
    val categoryId: String,
    val concentrations: List<String>,
    val presentations: List<String>,
    val channels: Set<String>,
    val publicNote: String,
    val source: String,
) {
    val name: String get() = brandName
    val searchBlob: String by lazy {
        listOf(brandName, activeIngredient, manufacturer)
            .plus(presentations)
            .plus(concentrations)
            .joinToString(" ")
            .lowercase()
    }
}

data class SupplyPoint(
    val id: String,
    val channel: ChannelType,
    val city: City,
    val productIds: Set<String>,
    val addressHint: String,
    val coverage: String,
    val conditions: List<String>,
    val secondarySource: String?,
    val distanceKm: Double = 0.0,
)

data class LocatorQuery(
    val text: String = "",
    val productId: String = "all",
    val categoryIds: Set<String> = emptySet(),
    val channelIds: Set<String> = emptySet(),
    val scope: LocatorScope = LocatorScope.BRASIL,
    val uf: String? = null,
    val cityId: String? = null,
    val onlyFree: Boolean = false,
    val sort: SortMode = SortMode.PROXIMIDADE,
)

data class LocatorResult(
    val points: List<SupplyPoint>,
    val matchedProducts: List<InsulinProduct>,
    val citiesCovered: Int,
    val ufsCovered: Int,
)
