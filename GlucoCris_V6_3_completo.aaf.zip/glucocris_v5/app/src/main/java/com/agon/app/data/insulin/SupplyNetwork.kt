package com.agon.app.data.insulin

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Rede de fornecimento de insulina no Brasil (offline).
 * Gera pontos de acesso por canal + cidade a partir do catálogo e da geografia.
 */
object SupplyNetwork {

    private val condDocs = listOf(
        "Documento de identidade com foto",
        "Cartão do SUS (CNS) ou CPF",
    )

    fun conditionsFor(channel: ChannelType): List<String> = when (channel) {
        ChannelType.FARMACIA_POPULAR -> condDocs + listOf(
            "Receita médica dentro do prazo de validade aceito pelo programa (uso contínuo: até 120 dias)",
            "Receita de serviço público ou privado é aceita",
            "Retirada da quantidade prevista para o tratamento mensal, conforme regras do programa",
        )
        ChannelType.ATENCAO_BASICA -> condDocs + listOf(
            "Receita emitida pela rede pública, conforme fluxo do município",
            "Cadastro na UBS de referência do seu endereço",
            "Fornecimento conforme padronização municipal/estadual",
        )
        ChannelType.CEAF -> condDocs + listOf(
            "Laudo para Solicitação, Avaliação e Autorização de Medicamentos (LME) preenchido pelo médico",
            "Receita médica e exames exigidos pelo PCDT do Diabete Melito tipo 1",
            "Comprovante de residência e documentação do processo administrativo",
            "Renovação periódica do processo conforme prazo da Secretaria de Estado da Saúde",
        )
        ChannelType.PRIVADA -> listOf(
            "Receita médica (retenção conforme exigência do produto)",
            "Preço limitado ao teto PMC da CMED/Anvisa para a UF",
            "Programas de desconto de laboratórios podem existir — confirme diretamente com o fabricante",
        )
    }

    private fun addressFor(channel: ChannelType, city: City): String = when (channel) {
        ChannelType.FARMACIA_POPULAR ->
            "Drogarias credenciadas com o selo \"Aqui Tem Farmácia Popular\" em ${city.name}/${city.uf}. A relação nominal com endereço completo é publicada pelo Ministério da Saúde no painel infoms.saude.gov.br e nos Dados Abertos."
        ChannelType.ATENCAO_BASICA ->
            "Unidades Básicas de Saúde (UBS) e farmácias da atenção básica do município de ${city.name}/${city.uf}. Consulte a UBS de referência do seu endereço ou a Secretaria Municipal de Saúde."
        ChannelType.CEAF ->
            "Unidade de referência do Componente Especializado da Assistência Farmacêutica (CEAF) do estado ${city.uf}. O atendimento é estadual; o município de residência define a unidade de referência."
        ChannelType.PRIVADA ->
            "Farmácias e drogarias da rede privada em ${city.name}/${city.uf}. Consulte disponibilidade e preço no estabelecimento."
    }

    private fun coverageFor(channel: ChannelType, city: City): String = when (channel) {
        ChannelType.FARMACIA_POPULAR -> "Cobertura do programa no município — ${city.name}/${city.uf}"
        ChannelType.ATENCAO_BASICA -> "Rede municipal de atenção básica — ${city.name}/${city.uf}"
        ChannelType.CEAF -> {
            val ufName = BrazilGeo.ufByCode(city.uf)?.name ?: city.uf
            "Atende todo o estado — $ufName"
        }
        ChannelType.PRIVADA -> "Cobertura comercial — ${city.name}/${city.uf}"
    }

    private fun secondarySourceFor(channel: ChannelType): String? = when (channel) {
        ChannelType.FARMACIA_POPULAR -> "https://dados.gov.br/dataset/farmacia_popular_estabelecimento"
        ChannelType.ATENCAO_BASICA, ChannelType.CEAF -> "https://www.gov.br/saude/pt-br"
        ChannelType.PRIVADA -> "https://consultas.anvisa.gov.br"
    }

    private fun haversineKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2)
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }

    /**
     * Busca offline de pontos de fornecimento.
     * @param query filtros da consulta
     * @param reference cidade de referência para cálculo de distância (pode ser null)
     */
    fun search(query: LocatorQuery, reference: City? = null): LocatorResult {
        // Produtos que batem com a consulta
        val matchedProducts = when {
            query.productId != "all" && query.productId.isNotBlank() ->
                listOfNotNull(InsulinCatalog.productById(query.productId))
            query.categoryIds.isNotEmpty() ->
                InsulinCatalog.products.filter { it.categoryId in query.categoryIds }
            query.text.isNotBlank() ->
                InsulinCatalog.search(query.text)
            else ->
                InsulinCatalog.products
        }.filter { product ->
            if (query.onlyFree) {
                product.channels.any { ch ->
                    ChannelType.byId(ch)?.priceTier == PriceTier.GRATUITO ||
                        ChannelType.byId(ch)?.priceTier == PriceTier.GRATUITO_PROCESSO
                }
            } else true
        }

        if (matchedProducts.isEmpty()) {
            return LocatorResult(emptyList(), emptyList(), 0, 0)
        }

        val productIds = matchedProducts.map { it.id }.toSet()
        val allowedChannels = if (query.channelIds.isEmpty()) {
            ChannelType.entries.toList()
        } else {
            ChannelType.entries.filter { it.id in query.channelIds }
        }

        // Cidades no escopo (Brasil = capitais + metropolitanas para ficar leve;
        // UF/CIDADE usa a lista completa do estado)
        val citiesInScope: List<City> = when (query.scope) {
            LocatorScope.CIDADE -> {
                val id = query.cityId
                if (id != null) listOfNotNull(BrazilGeo.cityById(id))
                else emptyList()
            }
            LocatorScope.UF -> {
                val uf = query.uf
                if (uf != null) BrazilGeo.citiesOf(uf)
                else emptyList()
            }
            LocatorScope.BRASIL -> BrazilGeo.cities.filter {
                it.tier == CityTier.CAPITAL || it.tier == CityTier.METROPOLITANA
            }
        }

        val points = mutableListOf<SupplyPoint>()
        for (city in citiesInScope) {
            for (channel in allowedChannels) {
                // Só gera ponto se algum produto do resultado está disponível no canal
                val availableForChannel = matchedProducts.filter { channel.id in it.channels }
                if (availableForChannel.isEmpty()) continue

                val dist = if (reference != null) {
                    haversineKm(reference.lat, reference.lon, city.lat, city.lon)
                } else 0.0

                points += SupplyPoint(
                    id = "${channel.id}_${city.id}",
                    channel = channel,
                    city = city,
                    productIds = availableForChannel.map { it.id }.toSet(),
                    addressHint = addressFor(channel, city),
                    coverage = coverageFor(channel, city),
                    conditions = conditionsFor(channel),
                    secondarySource = secondarySourceFor(channel),
                    distanceKm = dist,
                )
            }
        }

        // Ordenação
        val sorted = when (query.sort) {
            SortMode.PROXIMIDADE -> points.sortedBy { it.distanceKm }
            SortMode.CONFIABILIDADE -> points.sortedByDescending { it.channel.reliability }
            SortMode.PRECO -> points.sortedBy { it.channel.priceTier.order }
        }

        val citiesCovered = sorted.map { it.city.id }.toSet().size
        val ufsCovered = sorted.map { it.city.uf }.toSet().size

        return LocatorResult(
            points = sorted,
            matchedProducts = matchedProducts,
            citiesCovered = citiesCovered,
            ufsCovered = ufsCovered,
        )
    }
}
