package com.agon.app.insights

import com.agon.app.data.AppData
import com.agon.app.data.GlucoseEntry
import com.agon.app.data.Meal
import com.agon.app.data.toMgDl
import java.text.Normalizer
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlin.math.sqrt

/** Uma medição já convertida para mg/dL. [fromCgm] = veio de sensor (id sensor-*). */
data class Reading(val at: Long, val mg: Double, val fromCgm: Boolean = false)

data class RangeStats(
    val count: Int,
    val mean: Double,
    val sd: Double,
    /** Coeficiente de variação em %. Até ~36% é considerado estável. */
    val cv: Double,
    val min: Double,
    val max: Double,
    val veryLowPct: Double,
    val lowPct: Double,
    val inRangePct: Double,
    val highPct: Double,
    val veryHighPct: Double,
    /** GMI (Glucose Management Indicator) estimado. Nunca é HbA1c laboratorial. */
    val gmi: Double,
    /** A GMI só deve ser apresentada como estimativa quando [gmiReliable] for true. */
    val gmiReliable: Boolean = false,
    /** Motivo quando a GMI não é confiável (exibida ao usuário). */
    val gmiNote: String = "",
    /** Dias cobertos pelas medições (do primeiro ao último registro no período). */
    val spanDays: Int = 0,
    /** Origem predominante dos dados usados no cálculo. */
    val dataOrigin: DataOrigin = DataOrigin.METER,
    /** Cobertura temporal estimada (0–100) só relevante para CGM. */
    val coveragePct: Double = 0.0,
    /** true quando faz sentido falar em "tempo nas faixas" (CGM com cobertura adequada). */
    val timeInRangeMeaningful: Boolean = false,
)

enum class DataOrigin { METER, CGM, MIXED }

/**
 * Critérios de qualidade para GMI e nomenclatura de faixas.
 * Glicosímetro: medições pontuais — percentuais = distribuição das medições, não tempo.
 * CGM: id começando com "sensor-" — tempo nas faixas só com cobertura adequada.
 */
object GmiQuality {
    const val METER_MIN_READINGS = 14
    const val METER_MIN_SPAN_DAYS = 7
    const val METER_MIN_DISTINCT_DAYS = 5
    /** Referência CGM: ~14 dias com ≥70% de cobertura (amostragem ~5 min → 288/dia). */
    const val CGM_REF_DAYS = 14
    const val CGM_MIN_COVERAGE = 0.70
    const val CGM_SAMPLES_PER_DAY = 288

    /**
     * CGM somente quando o id foi gerado pelo import de sensor (`sensor-{provider}-{minuto}`).
     * Não usa texto livre em notes (evita falso positivo por palavra "Sensor").
     * Sem metadado de origem → não é CGM.
     */
    fun isCgmEntry(id: String, notes: String = ""): Boolean =
        id.startsWith("sensor-")

    fun originOf(list: List<Reading>): DataOrigin {
        if (list.isEmpty()) return DataOrigin.METER
        val cgm = list.count { it.fromCgm }
        return when {
            cgm == 0 -> DataOrigin.METER
            cgm == list.size -> DataOrigin.CGM
            else -> DataOrigin.MIXED
        }
    }

    /**
     * Cobertura CGM (%): estima o intervalo médio entre amostras a partir dos dados
     * (mediana dos deltas), depois compara o tempo coberto (n * intervalo) com o
     * período de referência de [CGM_REF_DAYS] dias. Lacunas > 2× o intervalo mediano
     * não contam como tempo monitorado.
     * Se houver menos de 3 intervalos, a cobertura não é confiável (retorna 0 e
     * [coverageKnown]=false via assess).
     */
    data class Coverage(val pct: Double, val known: Boolean, val medianIntervalMs: Long)

    fun computeCoverage(list: List<Reading>, refDays: Int = CGM_REF_DAYS): Coverage {
        if (list.size < 4) return Coverage(0.0, false, 0L)
        val sorted = list.sortedBy { it.at }
        val deltas = mutableListOf<Long>()
        for (i in 1 until sorted.size) {
            val d = sorted[i].at - sorted[i - 1].at
            if (d > 0) deltas.add(d)
        }
        if (deltas.size < 3) return Coverage(0.0, false, 0L)
        val med = deltas.sorted()[deltas.size / 2]
        // Intervalos típicos de CGM: 1–15 min; fora disso não assumimos frequência
        if (med < 30_000L || med > 20 * 60_000L) return Coverage(0.0, false, med)
        val gapLimit = med * 2
        var coveredMs = 0L
        for (d in deltas) {
            if (d <= gapLimit) coveredMs += d
            // lacunas maiores: não somam cobertura
        }
        val refMs = refDays * Insights.DAY_MS.toDouble()
        val pct = (coveredMs / refMs * 100.0).coerceIn(0.0, 100.0)
        return Coverage(pct, true, med)
    }

    @Deprecated("Use computeCoverage", ReplaceWith("computeCoverage(list, spanDays).pct"))
    fun coveragePct(list: List<Reading>, spanDays: Int): Double =
        computeCoverage(list, spanDays.coerceAtLeast(1)).pct

    data class Assessment(
        val reliable: Boolean,
        val note: String,
        val origin: DataOrigin,
        val coveragePct: Double,
        val timeInRangeMeaningful: Boolean,
    )

    fun assess(list: List<Reading>): Assessment {
        if (list.isEmpty()) {
            return Assessment(false, "Sem medições no período.", DataOrigin.METER, 0.0, false)
        }
        val origin = originOf(list)
        val spanMs = (list.maxOf { it.at } - list.minOf { it.at }).coerceAtLeast(0L)
        val spanDays = (spanMs / Insights.DAY_MS).toInt() + 1
        val distinctDays = list.map { it.at / Insights.DAY_MS }.toSet().size

        return when (origin) {
            DataOrigin.CGM -> {
                val cov = computeCoverage(list, CGM_REF_DAYS)
                // GMI CGM: período de referência 14 dias E cobertura ≥ 70% E cobertura conhecida
                val spanOk = spanDays >= CGM_REF_DAYS
                val covOk = cov.known && cov.pct >= CGM_MIN_COVERAGE * 100.0
                val reliable = spanOk && covOk && distinctDays >= 10
                val tirOk = reliable // mesmas regras para tempo nas faixas
                val note = when {
                    !cov.known ->
                        "Não foi possível confirmar a frequência de amostragem do sensor; cobertura CGM indeterminada. " +
                            "GMI e tempo nas faixas não são apresentados como representativos."
                    reliable ->
                        "GMI estimado a partir de dados de CGM: ${list.size} leituras, $spanDays dia(s) de período, " +
                            "cobertura ≈ ${cov.pct.toInt()}% em ${CGM_REF_DAYS} dias de referência " +
                            "(intervalo mediano ${cov.medianIntervalMs / 60_000} min). " +
                            "O GMI é uma estimativa calculada a partir dos dados de glicose disponíveis. " +
                            "Não equivale à hemoglobina glicada laboratorial (HbA1c)."
                    else ->
                        "Dados de CGM insuficientes para GMI representativo " +
                            "(período $spanDays dia(s), cobertura ≈ ${cov.pct.toInt()}%, " +
                            "referência: ${CGM_REF_DAYS} dias com ≥${(CGM_MIN_COVERAGE * 100).toInt()}% de cobertura)."
                }
                Assessment(reliable, note, origin, if (cov.known) cov.pct else 0.0, tirOk)
            }
            DataOrigin.MIXED -> {
                // Misto: trata como glicosímetro para métricas temporais; GMI só se volume razoável
                val ok = list.size >= METER_MIN_READINGS && spanDays >= METER_MIN_SPAN_DAYS && distinctDays >= METER_MIN_DISTINCT_DAYS
                val note = if (ok) {
                    "Estimativa a partir de medições mistas (glicosímetro e sensor): ${list.size} registros em $spanDays dia(s). " +
                        "O GMI é uma estimativa calculada a partir dos dados de glicose disponíveis. " +
                        "Não equivale à hemoglobina glicada laboratorial (HbA1c). " +
                        "Percentuais refletem a distribuição das medições, não o tempo real nas faixas."
                } else {
                    "Dados mistos insuficientes para estimar o GMI (${list.size} medições em $spanDays dia(s))."
                }
                Assessment(ok, note, origin, 0.0, false)
            }
            DataOrigin.METER -> {
                val ok = list.size >= METER_MIN_READINGS && spanDays >= METER_MIN_SPAN_DAYS && distinctDays >= METER_MIN_DISTINCT_DAYS
                val note = if (ok) {
                    "GMI estimado a partir de ${list.size} medições de glicosímetro em $spanDays dia(s) ($distinctDays dias com registro). " +
                        "O GMI é uma estimativa calculada a partir dos dados de glicose disponíveis. " +
                        "Não equivale à hemoglobina glicada laboratorial (HbA1c). " +
                        "Não representa automaticamente todas as horas do dia."
                } else {
                    "Dados de glicosímetro insuficientes para estimar o GMI " +
                        "(${list.size} medições, $spanDays dia(s), $distinctDays dias com registro)."
                }
                Assessment(ok, note, origin, 0.0, false)
            }
        }
    }
}

data class HourBucket(val hour: Int, val count: Int, val mean: Double, val lows: Int, val highs: Int)

data class DayPart(val label: String, val count: Int, val mean: Double?)

object Insights {
    const val DAY_MS = 86_400_000L

    /** Medições próprias (os registros de exemplo "demo-" ficam de fora) dos últimos [days] dias. */
    fun readings(data: AppData, days: Int, now: Long = System.currentTimeMillis()): List<Reading> =
        readingsBetween(data, now - days * DAY_MS, now)

    fun readingsBetween(data: AppData, from: Long, to: Long): List<Reading> =
        data.glucose
            .filter { !it.id.startsWith("demo-") && it.at in from..to }
            .map { Reading(it.at, toMgDl(it.value, it.unit), GmiQuality.isCgmEntry(it.id)) }
            .sortedBy { it.at }

    fun stats(list: List<Reading>, low: Int, high: Int): RangeStats? {
        if (list.isEmpty()) return null
        val v = list.map { it.mg }
        val n = v.size
        val mean = v.average()
        val sd = if (n > 1) sqrt(v.sumOf { (it - mean) * (it - mean) } / (n - 1)) else 0.0
        val veryLowLimit = minOf(54, low).toDouble()
        val veryHighLimit = maxOf(250, high).toDouble()
        val veryLow = v.count { it < veryLowLimit }
        val lowC = v.count { it >= veryLowLimit && it < low }
        val inR = v.count { it >= low && it <= high }
        val veryHigh = v.count { it > veryHighLimit }
        val highC = v.count { it > high && it <= veryHighLimit }
        fun pct(c: Int) = c * 100.0 / n
        val assessment = GmiQuality.assess(list)
        val spanMs = if (list.isEmpty()) 0L else (list.maxOf { it.at } - list.minOf { it.at }).coerceAtLeast(0L)
        val spanDays = if (list.isEmpty()) 0 else (spanMs / DAY_MS).toInt() + 1
        return RangeStats(
            count = n, mean = mean, sd = sd, cv = if (mean > 0) sd / mean * 100.0 else 0.0,
            min = v.min(), max = v.max(),
            veryLowPct = pct(veryLow), lowPct = pct(lowC), inRangePct = pct(inR), highPct = pct(highC), veryHighPct = pct(veryHigh),
            gmi = 3.31 + 0.02392 * mean,
            gmiReliable = assessment.reliable,
            gmiNote = assessment.note,
            spanDays = spanDays,
            dataOrigin = assessment.origin,
            coveragePct = assessment.coveragePct,
            timeInRangeMeaningful = assessment.timeInRangeMeaningful,
        )
    }

    private fun hourOf(ms: Long): Int = Calendar.getInstance().apply { timeInMillis = ms }.get(Calendar.HOUR_OF_DAY)

    fun byHour(list: List<Reading>, low: Int, high: Int): List<HourBucket> =
        (0..23).map { h ->
            val items = list.filter { hourOf(it.at) == h }
            HourBucket(
                hour = h,
                count = items.size,
                mean = if (items.isEmpty()) 0.0 else items.map { it.mg }.average(),
                lows = items.count { it.mg < low },
                highs = items.count { it.mg > high },
            )
        }

    fun dayParts(list: List<Reading>): List<DayPart> {
        fun part(label: String, range: IntRange): DayPart {
            val items = list.filter { hourOf(it.at) in range }
            return DayPart(label, items.size, if (items.isEmpty()) null else items.map { it.mg }.average())
        }
        return listOf(
            part("Madrugada (0–5h)", 0..5),
            part("Manhã (6–11h)", 6..11),
            part("Tarde (12–17h)", 12..17),
            part("Noite (18–23h)", 18..23),
        )
    }

    /** Horas com mais hipoglicemias (precisa de pelo menos 2 medições no horário e 1 baixa). */
    fun criticalLowHours(buckets: List<HourBucket>, top: Int = 3): List<HourBucket> =
        buckets.filter { it.count >= 2 && it.lows > 0 }.sortedByDescending { it.lows.toDouble() / it.count }.take(top)

    fun criticalHighHours(buckets: List<HourBucket>, top: Int = 3): List<HourBucket> =
        buckets.filter { it.count >= 2 && it.highs > 0 }.sortedByDescending { it.highs.toDouble() / it.count }.take(top)

    /** Média por dia (mais antigo primeiro) para o gráfico de tendência. */
    fun dailyMeans(list: List<Reading>, days: Int, now: Long = System.currentTimeMillis()): List<Pair<Long, Double?>> {
        val cal = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }
        val todayStart = cal.timeInMillis
        return (days - 1 downTo 0).map { back ->
            val c = Calendar.getInstance().apply { timeInMillis = todayStart; add(Calendar.DAY_OF_YEAR, -back) }
            val start = c.timeInMillis
            val end = Calendar.getInstance().apply { timeInMillis = start; add(Calendar.DAY_OF_YEAR, 1) }.timeInMillis
            val items = list.filter { it.at in start until end }
            start to (if (items.isEmpty()) null else items.map { it.mg }.average())
        }
    }

    fun hourLabel(h: Int): String = "%02dh".format(h)

    fun f1(d: Double): String = "%.1f".format(java.util.Locale("pt", "BR"), d)
    fun f0(d: Double): String = d.roundToInt().toString()
}

// ───────────────────────── Resposta glicêmica por alimento ─────────────────────────

data class FoodResponseRow(
    val name: String,
    val meals: Int,
    val avg1h: Double?,
    val n1h: Int,
    val avg2h: Double?,
    val n2h: Int,
    val rise1h: Double?,
    val rise2h: Double?,
    val avgCarbs: Double?,
)

object FoodResponse {
    private val gramsRegex = Regex("""\b\d+([.,]\d+)?\s?(g|gr|kg|ml|l|un|und|unidades?|fatias?|colheres?|conchas?)\b""", RegexOption.IGNORE_CASE)
    private val parenRegex = Regex("""\([^)]*\)""")
    private val splitRegex = Regex("""\s*(?:,|;|\+|\n|/|\s+e\s+)\s*""", RegexOption.IGNORE_CASE)

    fun key(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").trim()

    /** Separa a descrição de uma refeição em alimentos ("arroz (120 g), feijão" → "arroz", "feijão"). */
    fun parseFoods(description: String): List<String> =
        description.replace(parenRegex, " ")
            .split(splitRegex)
            .map { gramsRegex.replace(it, " ").replace(Regex("^[\\d\\s.,xX-]+"), "").replace(Regex("\\s+"), " ").trim(' ', '-', '.', ':') }
            .filter { it.length >= 3 }
            .distinct()

    private fun closest(list: List<GlucoseEntry>, target: Long, tolMs: Long): Double? =
        list.filter { abs(it.at - target) <= tolMs }.minByOrNull { abs(it.at - target) }?.let { toMgDl(it.value, it.unit) }

    private class Acc {
        var meals = 0
        val v1 = mutableListOf<Double>(); val v2 = mutableListOf<Double>()
        val r1 = mutableListOf<Double>(); val r2 = mutableListOf<Double>()
        val carbs = mutableListOf<Double>()
        var shown = ""
    }

    /**
     * Cruza cada refeição do diário com a glicemia ~1 h (40–80 min) e ~2 h (100–150 min) depois.
     * A "subida" é a diferença para a medição feita até 1 h antes da refeição (quando existe).
     * Observação: numa refeição com vários alimentos, a resposta é da refeição toda, não de um item isolado.
     */
    fun compute(data: AppData, now: Long = System.currentTimeMillis()): List<FoodResponseRow> {
        val gl = data.glucose.filter { !it.id.startsWith("demo-") }.sortedBy { it.at }
        val acc = LinkedHashMap<String, Acc>()
        for (m: Meal in data.meals) {
            if (m.id.startsWith("demo-") || m.description.isBlank()) continue
            if (now - m.at < 40 * 60_000L) continue
            val base = gl.filter { it.at in (m.at - 60 * 60_000L)..(m.at + 10 * 60_000L) }.maxByOrNull { it.at }?.let { toMgDl(it.value, it.unit) }
            val h1 = closest(gl, m.at + 60 * 60_000L, 20 * 60_000L)
            val h2 = closest(gl, m.at + 120 * 60_000L, 30 * 60_000L)
            if (h1 == null && h2 == null) continue
            for (food in parseFoods(m.description)) {
                val a = acc.getOrPut(key(food)) { Acc().also { it.shown = food.replaceFirstChar { c -> c.uppercase() } } }
                a.meals++
                if (h1 != null) { a.v1.add(h1); if (base != null) a.r1.add(h1 - base) }
                if (h2 != null) { a.v2.add(h2); if (base != null) a.r2.add(h2 - base) }
                m.carbs?.let { a.carbs.add(it) }
            }
        }
        return acc.values.map {
            FoodResponseRow(
                name = it.shown, meals = it.meals,
                avg1h = it.v1.takeIf { l -> l.isNotEmpty() }?.average(), n1h = it.v1.size,
                avg2h = it.v2.takeIf { l -> l.isNotEmpty() }?.average(), n2h = it.v2.size,
                rise1h = it.r1.takeIf { l -> l.isNotEmpty() }?.average(),
                rise2h = it.r2.takeIf { l -> l.isNotEmpty() }?.average(),
                avgCarbs = it.carbs.takeIf { l -> l.isNotEmpty() }?.average(),
            )
        }.sortedByDescending { it.rise2h ?: it.rise1h ?: it.avg2h ?: it.avg1h ?: 0.0 }
    }
}

// ───────────────────────── Resumo semanal ─────────────────────────

data class WeeklySummaryData(
    val from: Long,
    val to: Long,
    val cur: RangeStats?,
    val prev: RangeStats?,
    val lowEvents: Int,
    val highEvents: Int,
    val measuresPerDay: Double,
    val worstHigh: HourBucket?,
    val worstLow: HourBucket?,
    val mealsCount: Int,
    val avgCarbsPerMeal: Double?,
    val topFoods: List<FoodResponseRow>,
    val insulinApplications: Int,
)

object WeeklySummary {
    fun build(data: AppData, now: Long = System.currentTimeMillis()): WeeklySummaryData {
        val s = data.settings
        val from = now - 7 * Insights.DAY_MS
        val cur = Insights.readingsBetween(data, from, now)
        val prev = Insights.readingsBetween(data, from - 7 * Insights.DAY_MS, from)
        val buckets = Insights.byHour(cur, s.targetLow, s.targetHigh)
        val meals = data.meals.filter { !it.id.startsWith("demo-") && it.at in from..now }
        val carbs = meals.mapNotNull { it.carbs }
        return WeeklySummaryData(
            from = from, to = now,
            cur = Insights.stats(cur, s.targetLow, s.targetHigh),
            prev = Insights.stats(prev, s.targetLow, s.targetHigh),
            lowEvents = cur.count { it.mg < s.targetLow },
            highEvents = cur.count { it.mg > s.targetHigh },
            measuresPerDay = cur.size / 7.0,
            worstHigh = Insights.criticalHighHours(buckets, 1).firstOrNull(),
            worstLow = Insights.criticalLowHours(buckets, 1).firstOrNull(),
            mealsCount = meals.size,
            avgCarbsPerMeal = carbs.takeIf { it.isNotEmpty() }?.average(),
            topFoods = FoodResponse.compute(data, now).filter { (it.rise2h ?: it.rise1h) != null }.take(3),
            insulinApplications = data.insulin.count { !it.id.startsWith("demo-") && it.kind == "aplicacao" && it.at in from..now },
        )
    }

    private fun trend(cur: Double, prev: Double, better: Boolean): String {
        val d = cur - prev
        return when {
            abs(d) < 1.0 -> "ficou igual"
            (d > 0) == better -> "melhorou ${"%.0f".format(abs(d))} ponto(s) percentual(is)"
            else -> "piorou ${"%.0f".format(abs(d))} ponto(s) percentual(is)"
        }
    }

    /** Texto base, escrito só com os números do app (sem IA). Nunca calcula nem sugere dose de insulina. */
    fun plainText(w: WeeklySummaryData, lowLimit: Int, highLimit: Int): String {
        val c = w.cur ?: return "Ainda não há medições suas nos últimos 7 dias. Registre a glicemia para a Cris poder resumir sua semana."
        val sb = StringBuilder()
        sb.appendLine("Sua semana em números:")
        sb.appendLine("• ${c.count} medições (${"%.1f".format(w.measuresPerDay)} por dia), média de ${Insights.f0(c.mean)} mg/dL.")
        sb.appendLine("• ${Insights.f0(c.inRangePct)}% do tempo na meta ($lowLimit–$highLimit mg/dL).")
        w.prev?.let { p ->
            sb.appendLine("• Comparado com a semana anterior: tempo na meta ${trend(c.inRangePct, p.inRangePct, true)}; média ${if (c.mean < p.mean) "menor" else "maior"} (${Insights.f0(p.mean)} → ${Insights.f0(c.mean)} mg/dL).")
        }
        sb.appendLine("• Variabilidade: CV ${Insights.f0(c.cv)}% (${if (c.cv <= 36) "dentro do esperado, até 36%" else "acima de 36%, glicose oscilou bastante"}).")
        if (w.lowEvents > 0) sb.appendLine("• ${w.lowEvents} medição(ões) abaixo de $lowLimit mg/dL${w.worstLow?.let { ", mais comuns por volta das ${Insights.hourLabel(it.hour)}" } ?: ""}.")
        else sb.appendLine("• Nenhuma medição abaixo da meta.")
        if (w.highEvents > 0) sb.appendLine("• ${w.highEvents} medição(ões) acima de $highLimit mg/dL${w.worstHigh?.let { ", mais comuns por volta das ${Insights.hourLabel(it.hour)}" } ?: ""}.")
        else sb.appendLine("• Nenhuma medição acima da meta.")
        if (w.mealsCount > 0) sb.appendLine("• ${w.mealsCount} refeições no diário${w.avgCarbsPerMeal?.let { ", ~${Insights.f0(it)} g de carboidrato em média" } ?: ""}.")
        if (w.topFoods.isNotEmpty()) {
            sb.appendLine("• Alimentos com maior subida depois das refeições: " + w.topFoods.joinToString(", ") { it.name } + ".")
        }
        sb.appendLine()
        sb.appendLine("Perguntas para levar ao médico:")
        sb.appendLine("1. ${w.worstHigh?.let { "Por que minha glicemia costuma subir por volta das ${Insights.hourLabel(it.hour)}? Meu plano precisa ser revisado?" } ?: "Minha meta de glicemia está adequada para mim?"}")
        sb.appendLine("2. ${w.worstLow?.let { "O que posso fazer sobre as quedas perto das ${Insights.hourLabel(it.hour)}?" } ?: "Como posso manter o tempo na meta por mais horas do dia?"}")
        sb.appendLine("3. Com que frequência devo medir e quando pedir hemoglobina glicada?")
        sb.appendLine()
        sb.append("A Cris só resume o que você registrou. Ela não calcula nem recomenda dose de insulina: ajustes de dose são com sua equipe de saúde.")
        return sb.toString()
    }

    /** Dados compactos para a IA reescrever em tom amigável (a IA recebe só números agregados). */
    fun promptFor(w: WeeklySummaryData, base: String): String =
        "Reescreva o resumo semanal abaixo de forma acolhedora, clara e curta (até 12 linhas), em português do Brasil. " +
            "Diga o que melhorou e o que piorou, aponte padrões e termine com até 3 perguntas para levar ao médico. " +
            "REGRAS: use somente os números do texto; não invente dados; NÃO calcule, sugira ou ajuste dose de insulina; " +
            "não faça diagnóstico; lembre que decisões de tratamento são com a equipe de saúde.\n\n$base"
}
