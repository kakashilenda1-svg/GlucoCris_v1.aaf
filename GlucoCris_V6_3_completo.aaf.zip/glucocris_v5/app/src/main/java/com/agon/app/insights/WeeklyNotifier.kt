package com.agon.app.insights

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.compose.runtime.mutableStateOf
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.agon.app.MainActivity
import com.agon.app.R
import com.agon.app.data.GlucoStorage
import com.agon.app.data.GlucoViewModel
import java.util.Calendar
import java.util.concurrent.TimeUnit

/** Pedido de abrir uma tela específica (usado pela notificação do resumo semanal). */
object OpenRoute {
    const val EXTRA = "open_route"
    val route = mutableStateOf<String?>(null)
}

object WeeklyPrefs {
    private const val PREFS = "gluco_weekly_v1"
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
    fun notifyOn(ctx: Context) = sp(ctx).getBoolean("notify_on", true)
    fun setNotifyOn(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("notify_on", v).apply()
    fun lastWeek(ctx: Context) = sp(ctx).getString("last_week", "") ?: ""
    fun setLastWeek(ctx: Context, v: String) = sp(ctx).edit().putString("last_week", v).apply()
    fun cachedText(ctx: Context) = sp(ctx).getString("cached_text", "") ?: ""
    fun cachedAt(ctx: Context) = sp(ctx).getLong("cached_at", 0L)
    fun cache(ctx: Context, text: String) = sp(ctx).edit().putString("cached_text", text).putLong("cached_at", System.currentTimeMillis()).apply()
}

class WeeklySummaryWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val ctx = applicationContext
        return try {
            if (!WeeklyPrefs.notifyOn(ctx)) return Result.success()
            val cal = Calendar.getInstance()
            // Domingo, a partir das 18h: um aviso por semana
            if (cal.get(Calendar.DAY_OF_WEEK) != Calendar.SUNDAY || cal.get(Calendar.HOUR_OF_DAY) < 18) return Result.success()
            val weekKey = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.WEEK_OF_YEAR)}"
            if (WeeklyPrefs.lastWeek(ctx) == weekKey) return Result.success()
            val live = GlucoViewModel.liveInstance()
            val data = if (live != null && !live.practice.value) live.data.value else GlucoStorage.read(ctx)
            if (data == null) return Result.success()
            val w = WeeklySummary.build(data)
            if (w.cur == null) return Result.success()
            val text = WeeklySummary.plainText(w, data.settings.targetLow, data.settings.targetHigh)
            WeeklyPrefs.cache(ctx, text)
            WeeklyPrefs.setLastWeek(ctx, weekKey)
            notify(ctx, "Seu resumo da semana está pronto 💜", "${w.cur.inRangePct.toInt()}% do tempo na meta, média de ${w.cur.mean.toInt()} mg/dL. Toque para ver o que melhorou e o que pode ser conversado com o médico.")
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            Result.success()
        }
    }

    private fun notify(ctx: Context, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) return
        try {
            val channel = "gluco_resumo_semanal_v1"
            if (Build.VERSION.SDK_INT >= 26) {
                val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                nm.createNotificationChannel(NotificationChannel(channel, "Resumo semanal da Cris", NotificationManager.IMPORTANCE_DEFAULT))
            }
            val open = Intent(ctx, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra(OpenRoute.EXTRA, com.agon.app.Routes.WEEKLY)
            }
            val b = NotificationCompat.Builder(ctx, channel)
                .setSmallIcon(R.drawable.ic_stat_drop)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setColor(0xFF6D28D9.toInt())
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(ctx, 7741, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            NotificationManagerCompat.from(ctx).notify(7741, b.build())
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }
}

object WeeklySummaryScheduler {
    private const val NAME = "gluco_weekly_summary"
    fun ensurePeriodic(ctx: Context) {
        try {
            val req = PeriodicWorkRequestBuilder<WeeklySummaryWorker>(3, TimeUnit.HOURS).build()
            WorkManager.getInstance(ctx.applicationContext).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
        } catch (_: Exception) {
        }
    }
}
