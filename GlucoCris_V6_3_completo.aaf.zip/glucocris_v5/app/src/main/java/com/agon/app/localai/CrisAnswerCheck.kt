package com.agon.app.localai

/** Resultado da conferência local entre a resposta do Gemini e as fontes pesquisadas. É SUSPEITA, nunca prova. */
enum class Verdict {
    /** Mesmo assunto e nada contradiz (valores/datas batem, ou não há valores para comparar). */
    CONSISTENT,
    /** Poucos dados para comparar (trechos curtos, ou valores só de um lado). Não confirma nem contradiz. */
    INCONCLUSIVE,
    /** A resposta e as fontes parecem tratar de coisas diferentes: sem confirmação, mas sem prova de erro. */
    WEAK,
    /** Mesmo assunto, mas valores/datas/doses diferentes: possível divergência (ainda uma suspeita). */
    CONFLICT,
    /** A resposta não afirma nada (ex.: "não sei"): as fontes podem completar. */
    NO_ANSWER,
}

data class AnswerAssessment(val verdict: Verdict, val detail: String = "") {
    /** As fontes pesquisadas apoiam a resposta (o que não é o mesmo que "está provado"). */
    val confirmed: Boolean get() = verdict == Verdict.CONSISTENT
    /** Vale uma síntese, um aviso ou a colaboração da IA local. */
    val needsReview: Boolean get() = verdict == Verdict.WEAK || verdict == Verdict.CONFLICT || verdict == Verdict.NO_ANSWER
}

/**
 * Compara a resposta do Gemini com as fontes pesquisadas, sem gastar chamada nenhuma. Não depende só de nomes e números:
 *  1. a resposta afirma alguma coisa? (hesitação/"não sei" => NO_ANSWER);
 *  2. assunto em comum: raízes de palavras relevantes (tolera flexão: "sancionou"/"sancionada"), por fonte;
 *  3. valores comparáveis (datas completas, doses, números significativos) já normalizados pela formatação: só gera
 *     CONFLICT quando a MESMA fonte que trata do assunto traz valores e nenhum deles aparece na resposta.
 * Qualquer fonte que trate do assunto e concorde basta para CONSISTENT. Anos soltos e inteiros pequenos nunca contam.
 */
object CrisAnswerCheck {

    private val NO_ANSWER = Regex(
        """(?<![a-z])(nao sei|nao tenho (essa |a )?(informacao|certeza)|nao encontrei|nao consegui (confirmar|encontrar|verificar)|""" +
            """nao foi possivel (confirmar|encontrar|verificar)|nao posso (confirmar|informar)|desconheco|sem informacao)""",
    )

    private val STOP = setOf(
        "para", "pelos", "pelas", "pela", "pelo", "como", "mais", "muito", "mesmo", "depois", "entre", "sobre", "desde", "ainda",
        "tambem", "apos", "quando", "onde", "quem", "qual", "quais", "essa", "esse", "esta", "este", "isso", "aquele", "aquela",
        "nesta", "neste", "numa", "dele", "dela", "seus", "suas", "nosso", "nossa", "fazer", "feito", "sera", "estao", "estar",
        "tinha", "havia", "pode", "podem", "hoje", "ontem", "agora", "atual", "atuais", "segundo", "conforme", "foram", "sendo",
        "cada", "todo", "toda", "todos", "todas", "outro", "outra", "outros", "outras", "apenas", "porque", "entao", "assim",
    )

    private const val MIN_STEMS = 3
    private const val MIN_COVERAGE = 0.2
    private const val MIN_SHARED = 2

    /** Raízes (5 primeiras letras) das palavras relevantes: tolera flexão e acento. */
    internal fun stems(text: String): Set<String> =
        CrisTypo.fold(text).split(Regex("[^a-z0-9]+")).asSequence()
            .filter { it.length >= 4 && it !in STOP && !it.all { c -> c.isDigit() } }
            .map { if (it.length > 5) it.take(5) else it }
            .toSet()

    private class Src(val stems: Set<String>, val anchors: List<Set<String>>)

    private fun srcOf(h: WebHit): Src {
        val text = h.title + " " + h.snippet.take(300)
        return Src(stems(text), CrisFactGuard.anchors(text))
    }

    private fun intersects(a: List<Set<String>>, b: List<Set<String>>): Boolean =
        a.any { x -> b.any { y -> x.any { it in y } } }

    fun assess(answer: String, hits: List<WebHit>): AnswerAssessment {
        if (answer.isBlank() || hits.isEmpty()) return AnswerAssessment(Verdict.INCONCLUSIVE, "sem dados para comparar")
        val folded = CrisTypo.fold(answer)
        if (folded.length < 300 && NO_ANSWER.containsMatchIn(folded.take(200))) {
            return AnswerAssessment(Verdict.NO_ANSWER, "a resposta não afirma nada")
        }
        val srcs = hits.sortedByDescending { it.score }.take(3).map { srcOf(it) }.filter { it.stems.size >= MIN_STEMS }
        if (srcs.isEmpty()) return AnswerAssessment(Verdict.INCONCLUSIVE, "trechos curtos demais")

        val aStems = stems(answer)
        // Fontes que tratam do mesmo assunto da resposta (cobertura mínima E pelo menos 2 raízes em comum).
        val matching = srcs.filter { s ->
            val shared = s.stems.count { it in aStems }
            shared >= MIN_SHARED && shared.toDouble() / s.stems.size >= MIN_COVERAGE
        }
        if (matching.isEmpty()) return AnswerAssessment(Verdict.WEAK, "as fontes tratam de outro assunto ou não repetem a resposta")

        val aAnchors = CrisFactGuard.anchors(answer)
        if (aAnchors.isEmpty()) return AnswerAssessment(Verdict.CONSISTENT, "mesmo assunto, sem valores para comparar")
        if (matching.any { intersects(aAnchors, it.anchors) }) return AnswerAssessment(Verdict.CONSISTENT, "valores/datas conferem")
        return if (matching.any { it.anchors.isNotEmpty() }) {
            AnswerAssessment(Verdict.CONFLICT, "mesmo assunto, mas valores/datas diferentes")
        } else {
            AnswerAssessment(Verdict.INCONCLUSIVE, "a resposta tem valores e as fontes não")
        }
    }

    /** Compatibilidade: verdadeiro quando vale uma conferência (WEAK, CONFLICT ou NO_ANSWER). */
    fun mismatch(answer: String, hits: List<WebHit>): Boolean = assess(answer, hits).needsReview

    /** As próprias fontes parecem discordar entre si (mesmo assunto, valores/datas sem nada em comum)? Também é só suspeita. */
    fun sourcesDisagree(hits: List<WebHit>): Boolean {
        val srcs = hits.sortedByDescending { it.score }.take(3).map { srcOf(it) }.filter { it.stems.size >= MIN_STEMS }
        for (i in srcs.indices) for (j in i + 1 until srcs.size) {
            val a = srcs[i]
            val b = srcs[j]
            if (a.anchors.isEmpty() || b.anchors.isEmpty()) continue
            if (a.stems.count { it in b.stems } < MIN_SHARED) continue
            if (!intersects(a.anchors, b.anchors)) return true
        }
        return false
    }
}
