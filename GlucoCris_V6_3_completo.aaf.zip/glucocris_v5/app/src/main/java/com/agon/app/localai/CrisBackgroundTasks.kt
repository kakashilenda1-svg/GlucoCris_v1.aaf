package com.agon.app.localai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.agon.app.MainActivity
import com.agon.app.R
import com.agon.app.data.uid
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.concurrent.atomic.AtomicInteger

/** Estado de uma pergunta/pesquisa da Cris IA que pode continuar com o app fechado ou a tela apagada. */
@Serializable
data class CrisTask(
    val id: String,
    val convId: String,
    val question: String,
    val requestedAt: Long,
    val state: String,          // RUNNING | DONE | ERROR
    val online: Boolean,        // havia internet quando foi pedida (a pesquisa online só roda com internet)
    val finishedAt: Long = 0L,
    val error: String = "",
)

/**
 * Tarefas da Cris em segundo plano. Cada tarefa tem id único, é salva em disco (pergunta, estado, conversa)
 * e roda num escopo do processo, mantido vivo por um serviço em primeiro plano com notificação.
 * Não mantém tela nem CPU ligadas artificialmente. Se o Android encerrar o processo (ou o app for forçado a parar),
 * a tarefa fica marcada como interrompida e pode ser reenviada com um toque.
 */
object CrisBackgroundTasks {
    const val EXTRA_CONV_ID = "cris_open_conv"
    private const val PREFS = "cris_bg_tasks"
    private const val KEY = "tasks"
    private const val MAX_KEPT = 40
    private const val CH_DONE = "cris_task_done"
    private const val CH_DONE_QUIET = "cris_task_done_quiet"
    private const val CH_RUN = "cris_task_running"
    private const val RUN_ID = 4721

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val active = AtomicInteger(0)

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized
    fun all(c: Context): List<CrisTask> = try {
        json.decodeFromString<List<CrisTask>>(prefs(c).getString(KEY, "[]") ?: "[]")
    } catch (_: Exception) { emptyList() }

    @Synchronized
    private fun save(c: Context, list: List<CrisTask>) {
        prefs(c).edit().putString(KEY, json.encodeToString(list.sortedByDescending { it.requestedAt }.take(MAX_KEPT))).apply()
    }

    @Synchronized
    private fun update(c: Context, id: String, f: (CrisTask) -> CrisTask) {
        save(c, all(c).map { if (it.id == id) f(it) else it })
    }

    /** Ao abrir o app: tarefas que ficaram "em andamento" de um processo que morreu viram "interrompidas". */
    @Synchronized
    fun recoverInterrupted(c: Context) {
        if (active.get() > 0) return
        val list = all(c)
        if (list.none { it.state == "RUNNING" }) return
        save(c, list.map {
            if (it.state == "RUNNING") it.copy(state = "ERROR", error = "Foi interrompida (o Android encerrou o app). Toque em tentar de novo.", finishedAt = System.currentTimeMillis()) else it
        })
    }

    /** Registra a tarefa e liga o serviço que mantém o processo vivo. Devolve o id único. */
    fun begin(c: Context, convId: String, question: String): String {
        val app = c.applicationContext
        val id = uid()
        val online = CrisConnectivityManager.isOnline(app)
        synchronized(this) {
            save(app, all(app) + CrisTask(id, convId, question, System.currentTimeMillis(), "RUNNING", online))
        }
        if (active.incrementAndGet() == 1) {
            try { ContextCompat.startForegroundService(app, Intent(app, CrisTaskService::class.java)) } catch (_: Exception) {}
        }
        return id
    }

    private fun release(c: Context) {
        if (active.decrementAndGet() <= 0) {
            active.set(0)
            try { c.applicationContext.stopService(Intent(c.applicationContext, CrisTaskService::class.java)) } catch (_: Exception) {}
        }
    }

    /**
     * Conclui a tarefa. [userIsLooking] = a conversa está na tela agora (então não notifica).
     * Sem duplicar: a notificação usa o id da tarefa como identificador.
     */
    fun finish(c: Context, taskId: String, error: String?, userIsLooking: Boolean) {
        val app = c.applicationContext
        update(app, taskId) { it.copy(state = if (error == null) "DONE" else "ERROR", error = error.orEmpty(), finishedAt = System.currentTimeMillis()) }
        release(app)
        if (!userIsLooking && error == null && LocalAiSettings.taskNotify(app)) {
            all(app).firstOrNull { it.id == taskId }?.let { notifyDone(app, it) }
        }
    }

    fun discard(c: Context, taskId: String) {
        val app = c.applicationContext
        save(app, all(app).filter { it.id != taskId })
    }

    private fun ensureChannels(c: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (nm.getNotificationChannel(CH_DONE) == null) {
            nm.createNotificationChannel(NotificationChannel(CH_DONE, "Cris IA terminou (com som)", NotificationManager.IMPORTANCE_DEFAULT))
        }
        if (nm.getNotificationChannel(CH_DONE_QUIET) == null) {
            nm.createNotificationChannel(NotificationChannel(CH_DONE_QUIET, "Cris IA terminou (sem som)", NotificationManager.IMPORTANCE_LOW))
        }
        if (nm.getNotificationChannel(CH_RUN) == null) {
            nm.createNotificationChannel(NotificationChannel(CH_RUN, "Cris IA trabalhando", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun openIntent(c: Context, convId: String, req: Int): PendingIntent =
        PendingIntent.getActivity(
            c, req,
            Intent(c, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(EXTRA_CONV_ID, convId),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun notifyDone(c: Context, t: CrisTask) {
        ensureChannels(c)
        val channel = if (LocalAiSettings.taskSound(c)) CH_DONE else CH_DONE_QUIET
        val n = NotificationCompat.Builder(c, channel)
            .setSmallIcon(R.drawable.ic_stat_drop)
            .setContentTitle("💜 Cris IA terminou sua pesquisa!")
            .setContentText("Toque para ver a resposta.")
            .setPriority(if (channel == CH_DONE) NotificationCompat.PRIORITY_DEFAULT else NotificationCompat.PRIORITY_LOW)
            .setAutoCancel(true)
            .setContentIntent(openIntent(c, t.convId, t.id.hashCode()))
            .build()
        try {
            // Mesmo id por tarefa: se o aviso for disparado duas vezes, a segunda apenas substitui a primeira.
            (c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(("cris_task_" + t.id).hashCode(), n)
        } catch (_: Exception) {}
    }

    internal fun runningNotification(c: Context): Notification {
        ensureChannels(c)
        return NotificationCompat.Builder(c, CH_RUN)
            .setSmallIcon(R.drawable.ic_stat_drop)
            .setContentTitle("Cris IA está trabalhando na sua pergunta")
            .setContentText("Você pode sair do app ou apagar a tela. Aviso quando terminar.")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(0, 0, true)
            .setContentIntent(openIntent(c, "", 1))
            .build()
    }

    internal const val RUNNING_NOTIF_ID = RUN_ID
}

/** Serviço em primeiro plano (tipo dataSync) que só existe enquanto há pergunta da Cris em andamento. */
class CrisTaskService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        try {
            ServiceCompat.startForeground(
                this, CrisBackgroundTasks.RUNNING_NOTIF_ID, CrisBackgroundTasks.runningNotification(this),
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
            )
        } catch (_: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    /** Android 15+: serviço dataSync tem limite diário; ao estourar, só encerra o serviço (as tarefas ficam salvas). */
    override fun onTimeout(startId: Int, fgsType: Int) {
        stopSelf()
    }
}

/** Pedido para abrir uma conversa da Cris (vindo do toque na notificação). Vazio = só abrir a Cris. */
object CrisOpenRequest {
    val convId = androidx.compose.runtime.mutableStateOf<String?>(null)
}
