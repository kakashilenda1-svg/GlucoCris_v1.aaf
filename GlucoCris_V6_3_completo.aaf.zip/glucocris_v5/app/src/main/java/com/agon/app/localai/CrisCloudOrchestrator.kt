package com.agon.app.localai

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.async
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.withTimeoutOrNull

/** Resultado de uma chamada ao Gemini (sem detalhes de rede). [text] nulo = não respondeu. */
data class GemResult(
    val text: String?,
    /** O próprio Gemini pesquisou no Google (resposta já fundamentada). */
    val searched: Boolean = false,
    val sources: List<Pair<String, String>> = emptyList(),
    /** Motivo da falha DESTA chamada (nunca lido de estado global: duas perguntas simultâneas não se misturam). */
    val error: String = "",
) {
    val ok: Boolean get() = !text.isNullOrBlank()
}

/** Tempos independentes: cada serviço tem o seu e um não depende do outro. */
data class CloudTimeouts(
    val geminiMs: Long = 60_000L,
    val searchMs: Long = 15_000L,
    val synthMs: Long = 40_000L,
    /**
     * O Gemini já respondeu com Google E trouxe fontes: a pesquisa independente só serve para conferir/anexar,
     * então ganha uma espera moderada (antes eram 2,5 s fixos e o resultado útil era descartado).
     */
    val lateSearchGraceMs: Long = 4_000L,
    /** O Gemini respondeu com Google mas sem fontes: a pesquisa independente é a única fonte citável, espera um pouco mais. */
    val lateSearchGraceNoSourcesMs: Long = 6_000L,
    /** A pesquisa terminou primeiro com resultados úteis: quanto ainda vale esperar o Gemini (que já foi chamado). */
    val geminiPatienceMs: Long = 8_000L,
    /** Idem, quando a pesquisa já trouxe dado estruturado (ex.: cargo na Wikidata) e a resposta direta é confiável. */
    val geminiPatienceStrongMs: Long = 3_000L,
)

/** Serviços reais ou simulados (testes). Nada aqui conhece Android. */
class CloudDeps(
    /** Chama o Gemini. [webContext] vazio = 1ª geração (começa sem esperar ninguém); preenchido = síntese com resultados. */
    val gemini: suspend (webContext: String) -> GemResult,
    /** Pesquisa independente (Tavily + fontes abertas). Já deve respeitar privacidade, cache e cotas. */
    val search: suspend () -> WebPrep?,
    /** A cota do Gemini permite uma 2ª chamada de síntese? */
    val canSynthesize: () -> Boolean,
    /** (Compatibilidade) IA local resume os resultados; null se indisponível ou se falhar. Preferir [localReview]. */
    val localSummarize: (suspend (WebPrep) -> String?)? = null,
    /** IA local colabora (tradução, resumo, clareza, contradições) conforme o plano; null se indisponível ou se falhar. */
    val localReview: (suspend (LocalReviewRequest) -> String?)? = null,
)

sealed class CloudOutcome {
    /** Gemini respondeu. [web] = resultados usados para fontes (pode ser nulo). [unverified] = deveria ter pesquisado e não conseguiu. */
    data class GeminiAnswer(val gem: GemResult, val web: WebPrep?, val unverified: Boolean) : CloudOutcome()
    /** Segunda etapa: o Gemini sintetizou a resposta a partir dos resultados do Tavily. */
    data class Synthesized(val gem: GemResult, val web: WebPrep) : CloudOutcome()
    /**
     * Gemini respondeu, a pesquisa trouxe algo que pede conferência, mas não houve síntese (sem cota/falha).
     * [assessment] é uma SUSPEITA calculada localmente, nunca uma certeza de que o Gemini errou.
     */
    data class AnswerPlusResults(
        val gem: GemResult,
        val web: WebPrep,
        val assessment: AnswerAssessment,
        val localSummary: String?,
        val localTasks: Set<LocalTask> = emptySet(),
    ) : CloudOutcome() {
        val divergent: Boolean get() = assessment.needsReview
    }
    /** Gemini indisponível (ou lento demais, [geminiSlow]) e pesquisa com resultados reais. */
    data class SearchOnly(val web: WebPrep, val geminiError: String, val geminiSlow: Boolean = false) : CloudOutcome()
    /** Nenhum serviço online respondeu. O chamador tenta IA local, servidor Cris e respostas básicas. */
    data class NothingOnline(val web: WebPrep?, val geminiError: String, val geminiTried: Boolean) : CloudOutcome()
}

/**
 * Orquestra Gemini e pesquisa independente de forma CONCORRENTE:
 *  - as duas chamadas começam juntas; a 1ª geração do Gemini NÃO recebe os resultados do Tavily;
 *  - quem terminar primeiro é aproveitado: pesquisa útil primeiro => espera o Gemini só por uma janela curta
 *    (proporcional, não os 60 s) e, passada ela, responde com os resultados já disponíveis;
 *    Gemini primeiro (com Google) => a pesquisa ganha uma janela para anexar fontes/conferir;
 *  - cada pergunta roda no seu próprio Job (filho do chamador): cancelar uma não toca nas outras, e ao devolver a resposta
 *    o que sobrou em andamento é cancelado SEM esperar (chamadas HTTP bloqueantes não seguram a resposta);
 *  - só se faz uma 2ª chamada ao Gemini (síntese) quando a resposta não foi confirmada pelas fontes, e se a cota permitir;
 *  - nada aqui lê estado global: o que cada serviço devolve (inclusive o erro) fica na própria chamada.
 */
object CrisCloudOrchestrator {

    /** Score a partir do qual um resultado é dado estruturado (Wikidata) e a resposta direta é confiável. */
    private const val STRONG_SCORE = 100

    suspend fun run(deps: CloudDeps, needsWeb: Boolean, geminiOn: Boolean, t: CloudTimeouts = CloudTimeouts()): CloudOutcome {
        val ctx = currentCoroutineContext()
        // Job próprio, filho do chamador: cancelar o chamador cancela tudo daqui; terminar aqui não espera o que sobrou.
        val job = SupervisorJob(ctx[Job])
        val scope = CoroutineScope(ctx + job)
        try {
            return race(scope, deps, needsWeb, geminiOn, t)
        } finally {
            job.cancel()
        }
    }

    private suspend fun race(scope: CoroutineScope, deps: CloudDeps, needsWeb: Boolean, geminiOn: Boolean, t: CloudTimeouts): CloudOutcome {
        // INÍCIO CONCORRENTE: as duas tarefas são lançadas em sequência imediata, sem await entre elas.
        val searchD: Deferred<WebPrep?>? = if (needsWeb) scope.async { guarded(t.searchMs) { deps.search() } } else null
        val gemD: Deferred<GemResult>? = if (geminiOn) scope.async { guardedGemini(t.geminiMs) { deps.gemini("") } } else null

        if (gemD == null) {
            // Sem Gemini: a pesquisa (se houve) é a resposta.
            val web = searchD?.await()
            return if (web != null && web.hits.isNotEmpty()) CloudOutcome.SearchOnly(web, "")
            else CloudOutcome.NothingOnline(web, "", geminiTried = false)
        }
        if (searchD == null) {
            val gem = gemD.await()
            return if (gem.ok) CloudOutcome.GeminiAnswer(gem, null, unverified = false)
            else CloudOutcome.NothingOnline(null, gem.error, geminiTried = true)
        }

        // Quem termina primeiro? (true = Gemini)
        val geminiFirst = select<Boolean> {
            gemD.onAwait { true }
            searchD.onAwait { false }
        }

        if (!geminiFirst) {
            val web = searchD.await()
            if (web != null && web.hits.isNotEmpty()) {
                // Resultado útil já em mãos: o Gemini só tem uma janela (e não os 60 s) para aparecer.
                val patience = if (web.hits.any { it.score >= STRONG_SCORE }) t.geminiPatienceStrongMs else t.geminiPatienceMs
                val g = withTimeoutOrNull(patience) { gemD.await() }
                    ?: return CloudOutcome.SearchOnly(web, "", geminiSlow = true)
                if (!g.ok) return CloudOutcome.SearchOnly(web, g.error)
                return judge(deps, g, web, t)
            }
            // Pesquisa sem nada útil: só resta o Gemini.
            val g = gemD.await()
            return if (g.ok) CloudOutcome.GeminiAnswer(g, web, unverified = !g.searched)
            else CloudOutcome.NothingOnline(web, g.error, geminiTried = true)
        }

        val g = gemD.await()
        if (!g.ok) {
            // Gemini falhou/estourou o tempo: a pesquisa já estava rodando e segue independente (limite próprio).
            val web = searchD.await()
            return if (web != null && web.hits.isNotEmpty()) CloudOutcome.SearchOnly(web, g.error)
            else CloudOutcome.NothingOnline(web, g.error, geminiTried = true)
        }
        val web: WebPrep? = when {
            searchD.isCompleted -> searchD.await()
            g.searched -> {
                // Gemini já pesquisou no Google: a pesquisa independente ganha uma janela moderada para conferir/anexar fontes.
                val grace = if (g.sources.isNotEmpty()) t.lateSearchGraceMs else t.lateSearchGraceNoSourcesMs
                withTimeoutOrNull(grace) { searchD.await() }
            }
            // Resposta de memória: a pesquisa é a única confirmação possível, espera o seu próprio limite.
            else -> searchD.await()
        }
        return judge(deps, g, web, t)
    }

    /** Decide o que fazer com uma resposta do Gemini e (talvez) resultados da pesquisa. */
    private suspend fun judge(deps: CloudDeps, gem: GemResult, web: WebPrep?, t: CloudTimeouts): CloudOutcome {
        val hits = web?.hits.orEmpty()
        if (web == null || hits.isEmpty()) {
            // Não afirmamos verificação: se o Gemini não pesquisou no Google, sinalizamos.
            return CloudOutcome.GeminiAnswer(gem, web, unverified = !gem.searched)
        }
        val assessment = CrisAnswerCheck.assess(gem.text.orEmpty(), hits)
        // Síntese só quando há motivo: suspeita/conflito/resposta vazia, ou resposta de memória que as fontes não confirmaram.
        val needSynth = assessment.needsReview || (!gem.searched && !assessment.confirmed)
        if (!needSynth) return CloudOutcome.GeminiAnswer(gem, web, unverified = false)
        if (deps.canSynthesize()) {
            val s = guarded(t.synthMs) { deps.gemini(web.promptBlock) }
            if (s != null && s.ok) return CloudOutcome.Synthesized(s, web)
        }
        // Sem cota/falha na síntese: a IA local colabora SE o plano indicar valor real (uma única chamada).
        val plan = CrisLocalReview.plan(web, gem.text, assessment)
        val reviewer = reviewerOf(deps)
        val local = if (reviewer != null && plan.worthIt) {
            guarded(t.synthMs) { reviewer(LocalReviewRequest(web, gem.text, plan)) }
        } else null
        val usable = local?.takeIf { it.isNotBlank() }
        return CloudOutcome.AnswerPlusResults(gem, web, assessment, usable, if (usable != null) plan.tasks else emptySet())
    }

    private fun reviewerOf(deps: CloudDeps): (suspend (LocalReviewRequest) -> String?)? {
        deps.localReview?.let { return it }
        val legacy = deps.localSummarize ?: return null
        val adapted: suspend (LocalReviewRequest) -> String? = { r -> legacy(r.web) }
        return adapted
    }

    /** Timeout próprio + falha isolada. Só CancellationException externa se propaga. */
    private suspend fun <T> guarded(ms: Long, block: suspend () -> T?): T? =
        try {
            withTimeoutOrNull(ms) { block() }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            null
        }

    /** Igual a [guarded], mas sempre devolve um [GemResult] (com o motivo da falha desta chamada). */
    private suspend fun guardedGemini(ms: Long, block: suspend () -> GemResult): GemResult =
        try {
            withTimeoutOrNull(ms) { block() } ?: GemResult(null, error = "demorou demais (timeout)")
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            GemResult(null, error = "erro inesperado na IA online")
        }
}

/** Seleção e limpeza de fontes: remove duplicatas, descarta vazias/sem https e mantém a ordem de confiança. */
object CrisSourceQuality {
    private val TRACKING = Regex("""[?&](utm_[a-z]+|fbclid|gclid|ref|source)=[^&#]*""", RegexOption.IGNORE_CASE)

    fun normalizeUrl(u: String): String =
        TRACKING.replace(u.trim(), "").replace(Regex("""#.*$"""), "").removeSuffix("/")
            .replaceFirst("https://www.", "https://").lowercase()

    fun curate(hits: List<WebHit>, max: Int = 6): List<WebHit> {
        val clean = hits.filter { it.url.startsWith("https://") && (it.title.isNotBlank() || it.snippet.isNotBlank()) }
        val byUrl = LinkedHashMap<String, WebHit>()
        for (h in clean) {
            val k = normalizeUrl(h.url)
            val old = byUrl[k]
            if (old == null || h.score > old.score) byUrl[k] = h
        }
        val byTitle = LinkedHashMap<String, WebHit>()
        for (h in byUrl.values) {
            val k = CrisTypo.fold(h.title).replace(Regex("[^a-z0-9]+"), " ").trim().ifBlank { h.url }
            val old = byTitle[k]
            if (old == null || h.score > old.score) byTitle[k] = h
        }
        return byTitle.values.sortedWith(compareByDescending<WebHit> { it.score }.thenByDescending { it.date.isNotBlank() }).take(max)
    }
}
