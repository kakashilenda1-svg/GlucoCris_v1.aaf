package com.agon.app.localai

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/** Informa se há internet de verdade (com capacidade validada) para rotular respostas e decidir fallback. */
object CrisConnectivityManager {
    fun isOnline(context: Context): Boolean = try {
        val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        // VALIDATED = o Android confirmou internet. Alguns aparelhos (ROMs, DNS privado, VPN) não validam mesmo com internet
        // funcionando, e isso fazia a Cris se declarar "offline" à toa. Sem VALIDATED, só consideramos offline se for portal
        // cativo; se a rede realmente não sair, cada serviço (Gemini, pesquisa) acusa a própria falha com mensagem própria.
        caps != null &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ||
                !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_CAPTIVE_PORTAL))
    } catch (_: Exception) {
        false
    }

    fun observe(context: Context): Flow<Boolean> = callbackFlow {
        val app = context.applicationContext
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { trySend(isOnline(app)) }
            override fun onLost(network: Network) { trySend(isOnline(app)) }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { trySend(isOnline(app)) }
        }
        trySend(isOnline(app))
        try { cm.registerDefaultNetworkCallback(cb) } catch (_: Exception) {}
        awaitClose { try { cm.unregisterNetworkCallback(cb) } catch (_: Exception) {} }
    }.distinctUntilChanged()
}
