package com.agon.app.localai

import java.math.BigDecimal

/**
 * Impede que a IA local invente números, datas ou doses ao resumir/traduzir/revisar pesquisas, SEM rejeitar texto correto
 * só porque a formatação mudou ("5,42" = "5.42" = "R$ 5,42"; "1.000" = "1000"; "1,5 milhão" = "1.500.000";
 * "12 de novembro de 2026" = "12/11/2026").
 *
 * Regras:
 *  - todo valor significativo do texto gerado (decimal, 3+ dígitos, com %, R$ ou "mil/milhão") precisa existir nas fontes
 *    (ou na pergunta) depois de normalizado; inteiros pequenos soltos ("2 estudos") não são cobrados;
 *  - toda data precisa existir nas fontes (dia/mês/ano compatíveis; sem ano na fonte, o ano precisa aparecer nelas);
 *  - toda dose (valor + unidade) precisa vir das FONTES, com a mesma unidade ("10 UI" não vale como "10 mg");
 *    a pergunta da pessoa não serve de fonte para doses;
 *  - arredondar ou calcular um valor novo conta como valor não sustentado (conservador de propósito).
 * Lógica pura (sem Android), coberta por testes.
 */
object CrisFactGuard {

    data class Report(val ok: Boolean, val unsupported: List<String>)

    private val MONTHS = mapOf(
        "janeiro" to 1, "fevereiro" to 2, "marco" to 3, "abril" to 4, "maio" to 5, "junho" to 6,
        "julho" to 7, "agosto" to 8, "setembro" to 9, "outubro" to 10, "novembro" to 11, "dezembro" to 12,
    )
    private val MONTH_ALT = MONTHS.keys.joinToString("|")

    // Todos os padrões rodam sobre texto já "dobrado" (minúsculo, sem acento).
    private val DATE_ISO = Regex("""(?<!\d)(\d{4})-(\d{1,2})-(\d{1,2})(?!\d)""")
    private val DATE_TEXT = Regex("""(?<!\d)(\d{1,2})\s*(?:º|°)?\s+de\s+($MONTH_ALT)(?:\s+de\s+(\d{4}))?(?![a-z])""")
    private val DATE_MONTH_YEAR = Regex("""(?<![a-z])($MONTH_ALT)\s+(?:de\s+)?(\d{4})(?!\d)""")
    private val DATE_FULL = Regex("""(?<![\d./-])(\d{1,2})[./-](\d{1,2})[./-](\d{4}|\d{2})(?!\d)""")
    private val DATE_SLASH = Regex("""(?<![\d/])(\d{1,2})/(\d{1,2})(?![\d/])""")

    private const val UNIT_ALT = "mg/dl|mmol/l|mcg|µg|μg|ug|miligramas?|mg|gramas?|ml|u\\.i\\.|ui|unidades?|comprimidos?|capsulas?|gotas?|g"
    private val DOSE_RANGE = Regex(
        """(?<![\p{L}\d.,])(\d(?:[\d.,]*\d)?)\s*(?:a|ate|e|ou|-|–|—)\s*(\d(?:[\d.,]*\d)?)\s*($UNIT_ALT)(?![\p{L}])""",
    )
    private val DOSE = Regex("""(?<![\p{L}\d.,])(\d(?:[\d.,]*\d)?)\s*($UNIT_ALT)(?![\p{L}])""")

    private val NUM_TOKEN = Regex("""(?<![\p{L}\d])\d(?:[\d.,\u00A0\u202F]*\d)?""")
    private val MULT = Regex("""^\s*(mil|milhao|milhoes|mi|bilhao|bilhoes|bi)(?![\p{L}])""")
    private val PERCENT = Regex("""^\s*(%|por cento)""")

    private class DateTok(val raw: String, val y: Int?, val m: Int, val d: Int?)
    private class DoseTok(val raw: String, val keys: Set<String>)
    private class NumTok(val raw: String, val forms: Set<String>, val rawForms: Set<String>, val significant: Boolean, val year: Boolean)
    private class Scan(val dates: List<DateTok>, val doses: List<DoseTok>, val nums: List<NumTok>)

    // ---------------------------------------------------------------------------------------------------------------
    // API

    /** Verifica o texto gerado contra as fontes (e a pergunta, que só vale para números/datas, nunca para doses). */
    fun verify(output: String, sources: List<String>, question: String = ""): Report {
        val src = CrisTypo.fold(sources.joinToString("\n"))
        val q = CrisTypo.fold(question)
        val out = scan(CrisTypo.fold(output))
        val srcScan = scan(src)
        val qScan = scan(q)

        // Valores numéricos de qualquer tipo nas fontes/pergunta (inclui componentes de datas e doses: "2026", "10").
        val allowedNumbers = HashSet<String>()
        for (tok in numTokens(src) + numTokens(q)) {
            allowedNumbers.addAll(tok.forms)
            allowedNumbers.addAll(tok.rawForms)
        }
        val allowedDates = srcScan.dates + qScan.dates
        val allowedDoses = HashSet<String>()
        for (d in srcScan.doses) allowedDoses.addAll(d.keys)

        val bad = ArrayList<String>()
        for (d in out.dates) {
            if (!dateSupported(d, allowedDates, allowedNumbers) && !(src.contains(d.raw) || q.contains(d.raw))) bad.add(d.raw)
        }
        for (d in out.doses) {
            if (d.keys.none { it in allowedDoses }) bad.add(d.raw)
        }
        for (n in out.nums) {
            if (n.significant && n.forms.none { it in allowedNumbers }) bad.add(n.raw)
        }
        return Report(bad.isEmpty(), bad)
    }

    /** Compatibilidade: todas as strings recebidas valem como fonte (inclusive para doses). */
    fun numbersSupported(output: String, vararg allowedSources: String): Boolean =
        verify(output, allowedSources.toList(), "").ok

    /**
     * "Âncoras" de um texto para comparar com outro (usado por [CrisAnswerCheck]): datas completas, doses e valores
     * significativos (exceto anos soltos). Cada âncora é um conjunto de formas canônicas equivalentes.
     */
    internal fun anchors(text: String): List<Set<String>> {
        val s = scan(CrisTypo.fold(text))
        val out = ArrayList<Set<String>>()
        for (d in s.dates) {
            if (d.d == null) continue
            val keys = LinkedHashSet<String>()
            keys.add("d|${d.m}|${d.d}")
            if (d.y != null) keys.add("d${d.y}|${d.m}|${d.d}")
            out.add(keys)
        }
        for (x in s.doses) out.add(x.keys)
        for (n in s.nums) if (n.significant && !n.year) out.add(n.forms)
        return out
    }

    // ---------------------------------------------------------------------------------------------------------------
    // Varredura

    private fun blank(sb: StringBuilder, r: IntRange) {
        for (i in r) sb.setCharAt(i, ' ')
    }

    private fun yearOf(s: String): Int {
        val n = s.toInt()
        return if (s.length == 2) (if (n < 70) 2000 + n else 1900 + n) else n
    }

    /** Extrai datas, doses e números; o que vira data/dose é apagado do texto para não ser cobrado duas vezes como número. */
    private fun scan(folded: String): Scan {
        val sb = StringBuilder(folded)
        val dates = ArrayList<DateTok>()
        val doses = ArrayList<DoseTok>()

        fun each(rx: Regex, f: (MatchResult) -> Boolean) {
            for (m in rx.findAll(sb.toString()).toList()) {
                if (f(m)) blank(sb, m.range)
            }
        }

        each(DATE_ISO) { m ->
            val y = m.groupValues[1].toInt()
            val mo = m.groupValues[2].toInt()
            val d = m.groupValues[3].toInt()
            if (mo in 1..12 && d in 1..31) { dates.add(DateTok(m.value, y, mo, d)); true } else false
        }
        each(DATE_TEXT) { m ->
            val d = m.groupValues[1].toInt()
            val mo = MONTHS[m.groupValues[2]] ?: 0
            val ys = m.groupValues[3]
            if (mo in 1..12 && d in 1..31) { dates.add(DateTok(m.value, if (ys.isEmpty()) null else ys.toInt(), mo, d)); true } else false
        }
        each(DATE_MONTH_YEAR) { m ->
            val mo = MONTHS[m.groupValues[1]] ?: 0
            if (mo in 1..12) { dates.add(DateTok(m.value, m.groupValues[2].toInt(), mo, null)); true } else false
        }
        each(DATE_FULL) { m ->
            val d = m.groupValues[1].toInt()
            val mo = m.groupValues[2].toInt()
            if (mo in 1..12 && d in 1..31) { dates.add(DateTok(m.value, yearOf(m.groupValues[3]), mo, d)); true } else false
        }
        each(DATE_SLASH) { m ->
            val d = m.groupValues[1].toInt()
            val mo = m.groupValues[2].toInt()
            if (mo in 1..12 && d in 1..31) { dates.add(DateTok(m.value, null, mo, d)); true } else false
        }

        each(DOSE_RANGE) { m ->
            val unit = unitOf(m.groupValues[3])
            val keys = LinkedHashSet<String>()
            for (g in 1..2) for (f in numberForms(m.groupValues[g])) keys.add("$f|$unit")
            if (keys.isEmpty()) false else { doses.add(DoseTok(m.value, keys)); true }
        }
        each(DOSE) { m ->
            val unit = unitOf(m.groupValues[2])
            val keys = LinkedHashSet<String>()
            for (f in numberForms(m.groupValues[1])) keys.add("$f|$unit")
            if (keys.isEmpty()) false else { doses.add(DoseTok(m.value, keys)); true }
        }
        return Scan(dates, doses, numTokens(sb.toString()))
    }

    private fun unitOf(u: String): String = when (u) {
        "mcg", "µg", "μg", "ug" -> "mcg"
        "mg", "miligrama", "miligramas" -> "mg"
        "g", "grama", "gramas" -> "g"
        "ui", "u.i.", "unidade", "unidades" -> "ui"
        "comprimido", "comprimidos" -> "comp"
        "capsula", "capsulas" -> "caps"
        "gota", "gotas" -> "gota"
        else -> u   // mg/dl, mmol/l, ml
    }

    private fun numTokens(text: String): List<NumTok> {
        val out = ArrayList<NumTok>()
        for (m in NUM_TOKEN.findAll(text)) {
            val raw = m.value.trimEnd('.', ',')
            val base = numberForms(raw)
            if (base.isEmpty()) continue
            val after = text.substring(minOf(text.length, m.range.last + 1)).take(14)
            val before = text.substring(maxOf(0, m.range.first - 4), m.range.first)
            val mult = MULT.find(after)?.groupValues?.get(1)?.let { multiplierOf(it) }
            val percent = PERCENT.containsMatchIn(after)
            val currency = before.contains('$')
            val forms = if (mult == null) base else base.map { applyMultiplier(it, mult) }.toSet()
            val decimal = forms.any { it.contains('.') }
            val big = forms.any { !it.contains('.') && it.length >= 3 }
            val significant = decimal || big || percent || currency || mult != null
            val year = mult == null && !percent && !currency && forms.any { f -> f.length == 4 && f.toIntOrNull()?.let { it in 1900..2100 } == true }
            out.add(NumTok(raw, forms, base, significant, year))
        }
        return out
    }

    private fun multiplierOf(w: String): BigDecimal = when (w) {
        "mil" -> BigDecimal(1_000)
        "milhao", "milhoes", "mi" -> BigDecimal(1_000_000)
        else -> BigDecimal(1_000_000_000)
    }

    private fun applyMultiplier(form: String, m: BigDecimal): String =
        BigDecimal(form).multiply(m).stripTrailingZeros().toPlainString()

    /**
     * Interpretações numéricas de um token ("5,42", "5.42", "1.000", "1,234.56", "1.500.000").
     * Ambíguo (um único separador seguido de exatamente 3 dígitos, ex.: "1.000"/"2,500") devolve as duas leituras.
     */
    private fun numberForms(raw: String): Set<String> {
        val s = raw.trim().trimEnd('.', ',').replace("\u00A0", "").replace("\u202F", "")
        if (s.isEmpty() || !s[0].isDigit()) return emptySet()
        val out = LinkedHashSet<String>()
        fun add(intPart: String, frac: String) {
            try {
                val text = if (frac.isEmpty()) intPart else "$intPart.$frac"
                out.add(BigDecimal(text).stripTrailingZeros().toPlainString())
            } catch (_: NumberFormatException) {
            }
        }
        val dots = s.count { it == '.' }
        val commas = s.count { it == ',' }
        if (dots == 0 && commas == 0) {
            add(s, "")
        } else if (dots > 0 && commas > 0) {
            // Os dois separadores: o último é o decimal ("1.234,56" ou "1,234.56").
            val last = maxOf(s.lastIndexOf('.'), s.lastIndexOf(','))
            add(s.substring(0, last).replace(".", "").replace(",", ""), s.substring(last + 1))
        } else {
            val sep = if (dots > 0) '.' else ','
            if (dots + commas >= 2) {
                // Vários separadores iguais: milhar ("1.500.000"); se algum grupo não tem 3 dígitos, não é número.
                val groups = s.split(sep)
                if (groups.drop(1).all { it.length == 3 }) add(groups.joinToString(""), "")
            } else {
                val i = s.indexOf(sep)
                val head = s.substring(0, i)
                val tail = s.substring(i + 1)
                if (tail.length == 3 && head.length in 1..3 && head != "0") {
                    add(head + tail, "")   // leitura "milhar"
                    add(head, tail)        // leitura "decimal"
                } else {
                    add(head, tail)
                }
            }
        }
        return out
    }

    private fun dateSupported(d: DateTok, src: List<DateTok>, allowedNumbers: Set<String>): Boolean = src.any { s ->
        when {
            s.m != d.m -> false
            // Dia citado precisa existir na fonte (mês/ano sozinhos na fonte não provam um dia).
            d.d != null && (s.d == null || s.d != d.d) -> false
            d.y != null -> if (s.y != null) s.y == d.y else d.y.toString() in allowedNumbers
            else -> true
        }
    }
}
