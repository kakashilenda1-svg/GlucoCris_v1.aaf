package com.agon.app.localai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import java.net.HttpURLConnection
import java.net.URL

/**
 * Baixa fotos para a resposta da Cris. Só aceita HTTPS e só dos servidores de imagem da Wikimedia
 * (a pessoa não é levada a nenhum outro site). Tamanho limitado e redução da imagem para economizar memória.
 */
object CrisImageLoader {
    private val cache = LruCache<String, Bitmap>(6)
    private val ALLOWED_HOSTS = setOf("commons.wikimedia.org", "upload.wikimedia.org")
    private const val UA = "GlucoCris/1.17 (Android; foto da resposta da Cris IA)"
    private const val MAX_BYTES = 4_000_000
    private const val MAX_SIDE = 1000

    private fun allowed(url: String): Boolean {
        if (!url.startsWith("https://")) return false
        val host = try { URL(url).host.lowercase() } catch (_: Exception) { return false }
        return host in ALLOWED_HOSTS
    }

    /** Chamar fora da thread principal. Devolve null se não foi possível carregar. */
    fun load(url: String): Bitmap? {
        cache.get(url)?.let { return it }
        return try {
            val bytes = download(url, 0) ?: return null
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, opts) ?: return null
            cache.put(url, bmp)
            bmp
        } catch (_: Exception) {
            null
        } catch (_: OutOfMemoryError) {
            null
        }
    }

    private fun download(url: String, depth: Int): ByteArray? {
        if (!allowed(url) || depth > 3) return null
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 6_000
            c.readTimeout = 10_000
            c.instanceFollowRedirects = false
            c.setRequestProperty("User-Agent", UA)
            val code = c.responseCode
            if (code in 301..308) {
                val loc = c.getHeaderField("Location") ?: return null
                return download(URL(URL(url), loc).toString(), depth + 1)
            }
            if (code !in 200..299) return null
            val out = java.io.ByteArrayOutputStream()
            val buf = ByteArray(8192)
            c.inputStream.use { input ->
                while (true) {
                    val n = input.read(buf)
                    if (n < 0) break
                    out.write(buf, 0, n)
                    if (out.size() > MAX_BYTES) return null
                }
            }
            return out.toByteArray()
        } finally {
            c.disconnect()
        }
    }
}
