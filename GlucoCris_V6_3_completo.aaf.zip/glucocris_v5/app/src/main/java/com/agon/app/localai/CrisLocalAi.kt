package com.agon.app.localai

import android.content.Context
import com.agon.app.data.AppData
import com.agon.app.data.CrisMemory
import com.agon.app.ui.screens.buildCrisContext

/** Orquestra a IA local: prompt, contexto do app, memória, segurança. */
object CrisLocalAi {

    /** Rótulos de origem mostrados na conversa. */
    const val SRC_LOCAL = "local"
    const val SRC_LOCAL_WEB = "local_web"
    const val SRC_CALC = "calculo"
    const val SRC_APP = "app"
    const val SRC_ONLINE = "online"
    const val SRC_SAFETY = "seguranca"
    const val SRC_BASIC = "basica"

    fun label(source: String): String = when (source) {
        SRC_LOCAL -> "🔒 IA no aparelho"
        SRC_LOCAL_WEB -> "🔒 IA no aparelho + 🌐 pesquisa online"
        SRC_CALC -> "🧮 conta exata do app"
        SRC_APP -> "📋 dados do seu app"
        SRC_ONLINE -> "🌐 consulta online"
        SRC_SAFETY -> "⚕️ aviso de segurança"
        SRC_BASIC -> "💬 respostas básicas offline"
        else -> ""
    }

    fun isReady(context: Context): Boolean =
        LocalAiSettings.enabled(context) && LocalModelManager.get(context).isInstalled()

    /** Explicação honesta quando não há como gerar uma resposta geral agora. */
    fun limitationNotice(context: Context): String {
        val online = CrisConnectivityManager.isOnline(context)
        return if (!LocalModelManager.get(context).isInstalled()) {
            "Ainda não tenho a IA local instalada neste aparelho, então só consigo respostas básicas" +
                (if (online) " e pesquisas simples" else " (e estou sem internet)") + ". " +
                "Toque no status sob meu nome, no chat, e escolha Baixar IA local (uma vez, no Wi-Fi): depois converso sobre qualquer assunto, até offline. " +
                "Enquanto isso, posso mostrar seus registros, criar lembretes ou abrir o localizador de insulina."
        } else {
            "Não consegui gerar a resposta agora: o modelo local não respondeu (pode ser memória ou aquecimento do aparelho). Tente de novo em instantes. " +
                "Não vou inventar uma resposta."
        }
    }

    private val HEALTH_RE = Regex(
        "glic|insulin|dose|bolus|a1c|hba1c|carbo|alimenta|refei|lembrete|hidrat|\\b[aá]gua\\b|semana|resumo|registro|diabet|hipo|hiper|consulta|meus dados|minha m[eé]dia|\\bmeu\\b|\\bminha\\b|medic|m[eé]dic|rem[eé]dio|bula|anvisa|vacina|sintoma|exame|press[aã]o|sa[uú]de|tratamento|tontura|jejum",
        RegexOption.IGNORE_CASE,
    )

    /** Recusas genéricas típicas do modelo pequeno ("Desculpe, não posso...", "não é minha área", "muito pessoal"). */
    private val REFUSAL = Regex(
        "^\\W*(desculpe|sinto muito|lamento|infelizmente)[^\\n]{0,80}(n[aã]o posso|n[aã]o consigo|n[aã]o tenho como)|" +
            "^\\W*(n[aã]o posso|n[aã]o consigo) (fornecer|ajudar com|te ajudar com|dar|passar|responder)|" +
            "muito pessoal|n[aã]o [eé] (a )?minha (a[aá]rea|especialidade)|fora d[aeo] minha (a[aá]rea|compet[eê]ncia)|n[aã]o tenho expertise",
        RegexOption.IGNORE_CASE,
    )

    /** Assuntos em que uma recusa pode ser legítima: nesses NÃO insistimos nem repetimos a geração. */
    private val RISKY_TOPIC = Regex(
        "insulin|dose|unidades|medica|rem[eé]dio|tratamento|prescri|suic|me matar|droga|arma\\b|explosiv|veneno|hack",
        RegexOption.IGNORE_CASE,
    )

    fun buildSystemPrompt(
        context: Context,
        data: AppData,
        memory: CrisMemory,
        userName: String,
        extraBlock: String = "",
        includeAppData: Boolean = true,
    ): String {
        val online = CrisConnectivityManager.isOnline(context)
        // Pergunta que NÃO é de saúde/registros: prompt enxuto e neutro. O prompt completo (regras de diabetes, médica,
        // insulina) fazia o modelo pequeno desviar "passo a passo do pneu" para "não sou médica" e conselhos de saúde.
        // As travas de dose e de emergência continuam por código (CrisSafetyGuard.precheck/postcheck), independentes do prompt.
        if (!includeAppData) {
            return buildString {
                append("Você é a Cris ❤️, assistente do aplicativo Gluco Cris. Fale em português do Brasil, de forma natural, simpática e correta. ")
                append("Não cite modelo, empresa ou tecnologia por trás de você.\n")
                append("Responda QUALQUER pergunta de qualquer assunto, direto ao ponto. Atenda o pedido; nunca recuse por ser \"pessoal\" ou \"fora da sua área\".\n")
                append("Use a conversa anterior para entender \"isso\", \"ele\", \"o passo a passo\" etc.: continue exatamente o assunto da pergunta anterior.\n")
                append("Para \"como fazer\": passos numerados, curtos e práticos, só com o que você tem certeza. Para receitas: ingredientes com medidas e modo de preparo.\n")
                append("Não invente. Se não souber ou não tiver certeza, diga isso em uma frase. Não fale de saúde, diabetes ou médicos se a pessoa não perguntou sobre isso.\n")
                if (userName.isNotBlank()) append("Nome da pessoa: $userName\n")
                if (!online) append("SEM INTERNET agora: não finja ter pesquisado; em fatos atuais diga que não consegue confirmar.\n")
                append("Data e hora do aparelho: ${java.text.SimpleDateFormat("EEEE, dd/MM/yyyy HH:mm", java.util.Locale("pt", "BR")).format(java.util.Date())}.\n")
                if (extraBlock.isNotBlank()) append(extraBlock)
                val mem = LocalMemoryManager.promptBlock(context)
                if (mem.isNotBlank()) append("\n").append(mem)
                if (memory.noteToSelf.isNotBlank()) append("Preferência da pessoa: ${memory.noteToSelf}\n")
            }
        }
        return buildString {
            append("Você é a Cris ❤️, assistente do aplicativo Gluco Cris. Fale em português do Brasil, com voz natural, carinhosa e profissional. ")
            append("Seu nome é Cris: não cite modelo, empresa ou tecnologia por trás de você e não finja ser humana.\n")
            append("Você responde sobre QUALQUER assunto, não só diabetes. Entenda a pergunta mesmo com erros de digitação.\n")
            append("Você ajuda com receitas, culinária, contas, textos, curiosidades, dicas do dia a dia e conversa livre. ")
            append("NUNCA recuse por \"ser pessoal\", \"não ser minha área\" ou \"não ter expertise\": faça o pedido. ")
            append("As únicas recusas permitidas são dose de insulina/mudança de tratamento (regras abaixo) e algo perigoso ou ilegal.\n")
            append("Receitas: dê ingredientes com medidas e modo de preparo em passos curtos. Se a pessoa tem diabetes, ofereça de bônus uma versão com menos açúcar, sem inventar valores nutricionais.\n")
            append("COMO RESPONDER:\n")
            append("- Comece direto pela resposta. Sem saudação, sem repetir a pergunta, sem rodeios e sem \"como assistente\".\n")
            append("- Dê informação concreta (nomes, números, passos, exemplos). Se algo \"depende\", diga do quê e responda para o caso mais comum.\n")
            val direct = memory.shortAnswers || LocalAiSettings.isDirectStyle(context)
            if (direct) {
                append("- Pergunta simples: 1 a 2 frases. Pergunta complexa: resposta completa mas enxuta, até 6 frases ou passos curtos.\n")
            } else {
                append("- Pergunta simples: 1 a 3 frases. Pergunta complexa: resposta detalhada e organizada, em parágrafos curtos ou passos numerados.\n")
            }
            append("- Só faça pergunta de volta se faltar um dado indispensável.\n")
            append("- NÃO inclua fontes, links, referências nem explique como achou a resposta, a menos que a pessoa peça. Não termine com ofertas genéricas.\n")
            append("- Em contas, resolva passo a passo. Se não souber, diga com honestidade, sem inventar.\n")
            append("- Para fatos atuais (cargos, eleições, notícias, preços, resultados), use SOMENTE o bloco PESQUISA NA INTERNET se existir.\n")
            append("\n")
            if (userName.isNotBlank()) append("Nome da pessoa: $userName\n")
            if (!online) {
                append("SEM INTERNET agora. Em fato atual (quem ocupa um cargo hoje, notícias, preços, placares), diga em uma frase que sem internet não consegue confirmar e, se souber, informe o que sabia pelo treinamento avisando que pode estar desatualizado.\n")
            }
            append("Data e hora do aparelho: ${java.text.SimpleDateFormat("EEEE, dd/MM/yyyy HH:mm", java.util.Locale("pt", "BR")).format(java.util.Date())}.\n")
            append(CrisSafetyGuard.SYSTEM_RULES)
            if (extraBlock.isNotBlank()) append(extraBlock)
            val mem = LocalMemoryManager.promptBlock(context)
            if (mem.isNotBlank()) append("\n").append(mem)
            if (memory.noteToSelf.isNotBlank()) append("Preferência da pessoa: ${memory.noteToSelf}\n")
            if (includeAppData) {
                append("\nDADOS DO APP (registros reais da pessoa, só neste aparelho; não invente nada fora deles):\n")
                append(try { buildCrisContext(data) } catch (_: Exception) { "indisponível\n" })
            }
        }
    }

    /**
     * Conversa pela IA local. Retorna null se a IA local não estiver disponível ou falhar (o chamador usa o fallback).
     * [summary] = resumo das mensagens antigas DESTA conversa; [onPartial] recebe o texto parcial (geração progressiva).
     */
    suspend fun chat(
        context: Context,
        text: String,
        history: List<Pair<Boolean, String>>,
        data: AppData,
        memory: CrisMemory,
        userName: String,
        extraBlock: String = "",
        summary: String = "",
        onPartial: (String) -> Unit = {},
    ): String? {
        if (!isReady(context)) return null
        return try {
            // Dados de saúde só entram no prompt quando o assunto é saúde/registros (prompt menor = resposta mais rápida).
            val needsData = HEALTH_RE.containsMatchIn(text) || history.takeLast(2).any { HEALTH_RE.containsMatchIn(it.second) }
            val block = buildString {
                if (summary.isNotBlank()) append("\nRESUMO DO COMEÇO DESTA CONVERSA (contexto; use só se ajudar):\n").append(summary).append("\n")
                append(extraBlock)
            }
            val system = buildSystemPrompt(context, data, memory, userName, block, includeAppData = needsData)
            val engine = LocalAiEngine.get(context)
            val askedRisky = RISKY_TOPIC.containsMatchIn(text)
            // Não mostra na tela uma recusa que vamos tentar corrigir (evita piscar "Desculpe, não posso..." e sumir).
            val guarded: (String) -> Unit = { p -> if (askedRisky || !REFUSAL.containsMatchIn(p.take(220))) onPartial(p) }
            var out = engine.generate(system, history, text, onPartial = guarded).trim()
            if (!askedRisky && REFUSAL.containsMatchIn(out.take(220))) {
                // Modelo pequeno recusou um pedido comum: uma nova tentativa, com a diretriz no começo do prompt e junto da pergunta.
                android.util.Log.w("CrisLocalAi", "Falsa recusa detectada; tentando de novo")
                val retrySystem = "DIRETRIZ: o pedido abaixo é normal e permitido. Atenda direto, sem pedir desculpas e sem recusar.\n" + system
                val retryText = text + "\n(Responda ao pedido agora, de forma completa e direta.)"
                val second = engine.generate(retrySystem, history, retryText, onPartial = { p -> if (!REFUSAL.containsMatchIn(p.take(220))) onPartial(p) }).trim()
                if (second.isNotBlank() && !REFUSAL.containsMatchIn(second.take(220))) out = second
            }
            CrisServiceHealth.local(error = out.isBlank())
            if (out.isBlank()) null else out
        } catch (t: Throwable) {
            android.util.Log.e("CrisLocalAi", "Falha na geração local", t)
            CrisServiceHealth.local(error = true)
            null
        }
    }
}
