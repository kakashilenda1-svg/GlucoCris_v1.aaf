package com.agon.app.localai

/** Tipos de colaboração opcional da IA local (no aparelho) com a pesquisa online. */
enum class LocalTask { TRANSLATE, SUMMARIZE, CLARIFY, CONTRADICTIONS }

data class LocalReviewPlan(val tasks: Set<LocalTask>) {
    /** Só vale chamar a IA local se houver algo além de "clareza": clareza sozinha nunca justifica uma chamada. */
    val worthIt: Boolean get() = tasks.any { it != LocalTask.CLARIFY }
}

/** O que a IA local recebe: os resultados da pesquisa, a resposta anterior do Gemini (se houver) e o plano. */
data class LocalReviewRequest(val web: WebPrep, val geminiAnswer: String?, val plan: LocalReviewPlan)

/**
 * Decide, SEM chamar nenhum modelo, se a IA local agrega valor e o que pedir a ela, numa ÚNICA chamada:
 *  - TRADUZIR: algum trecho relevante está em outro idioma;
 *  - RESUMIR: há conteúdo suficiente nos trechos para resumir (só manchetes curtíssimas não valem uma chamada);
 *  - CONTRADIÇÕES: a resposta diverge das fontes ou as fontes divergem entre si (apontar, sem escolher lado);
 *  - CLAREZA: só acompanha outra tarefa quando a resposta anterior é longa; nunca dispara uma chamada sozinha.
 * A saída é conferida por [CrisFactGuard]: número, data ou dose que não esteja nas fontes derruba o texto local.
 */
object CrisLocalReview {
    private const val LONG_ANSWER = 1_200
    private const val MIN_CONTENT = 80

    fun plan(web: WebPrep, geminiAnswer: String?, assessment: AnswerAssessment?): LocalReviewPlan {
        val hits = web.hits.take(4)
        if (hits.isEmpty()) return LocalReviewPlan(emptySet())
        val tasks = LinkedHashSet<LocalTask>()
        val content = hits.sumOf { it.title.length + it.snippet.length }
        if (hits.any { CrisWebSearch.looksForeign(it.snippet.ifBlank { it.title }) }) tasks.add(LocalTask.TRANSLATE)
        if (content >= MIN_CONTENT) tasks.add(LocalTask.SUMMARIZE)
        if (assessment?.verdict == Verdict.CONFLICT || CrisAnswerCheck.sourcesDisagree(hits)) tasks.add(LocalTask.CONTRADICTIONS)
        if (tasks.isNotEmpty() && (geminiAnswer?.length ?: 0) >= LONG_ANSWER) tasks.add(LocalTask.CLARIFY)
        return LocalReviewPlan(tasks)
    }

    /** Bloco de instruções a acrescentar ao prompt da IA local (vazio se não vale a pena). */
    fun instruction(plan: LocalReviewPlan, geminiAnswer: String?): String {
        if (!plan.worthIt) return ""
        val hasAnswer = !geminiAnswer.isNullOrBlank()
        val sb = StringBuilder()
        sb.append("\nTAREFA DE REVISÃO (use SOMENTE os trechos da pesquisa")
        if (hasAnswer) sb.append(" e a resposta anterior abaixo")
        sb.append("):\n")
        if (LocalTask.TRANSLATE in plan.tasks) sb.append("- Traduza para português do Brasil o que estiver em outro idioma.\n")
        if (LocalTask.SUMMARIZE in plan.tasks) sb.append("- Resuma em poucas frases o que os trechos dizem sobre a pergunta.\n")
        if (LocalTask.CONTRADICTIONS in plan.tasks) {
            sb.append("- Se houver informações diferentes entre as fontes, ou entre as fontes e a resposta anterior, diga quais são, ")
            sb.append("sem escolher um lado e sem afirmar qual está certa.\n")
        }
        if (LocalTask.CLARIFY in plan.tasks) sb.append("- Escreva de forma clara e curta, sem rodeios.\n")
        sb.append("REGRAS: preserve exatamente números, datas, doses, nomes e fatos como estão nos trechos. ")
        sb.append("Não acrescente nenhum número, data, dose, nome ou fato que não esteja nos trechos. ")
        sb.append("Se os trechos não bastarem, diga que não foi possível confirmar. ")
        sb.append("Não indique dose de insulina nem mudança de tratamento.\n")
        if (hasAnswer) sb.append("RESPOSTA ANTERIOR (a ser conferida; não é fonte confirmada):\n").append(geminiAnswer!!.take(1_500)).append('\n')
        return sb.toString()
    }

    /** O texto da IA local só vale se não trouxer número, data ou dose fora das fontes (e da pergunta, para números/datas). */
    fun isSafe(output: String, web: WebPrep, geminiAnswer: String?, question: String): Boolean =
        output.isNotBlank() && CrisFactGuard.verify(output, listOfNotNull(web.promptBlock, geminiAnswer), question).ok
}
