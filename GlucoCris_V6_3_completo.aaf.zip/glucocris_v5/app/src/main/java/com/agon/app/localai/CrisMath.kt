package com.agon.app.localai

import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.util.Locale

/**
 * Contas exatas feitas pelo próprio app (sem modelo, sem internet). Só age quando a mensagem é claramente uma conta;
 * nunca toca em cálculos de glicemia/insulina (mensagens de saúde são ignoradas aqui).
 */
object CrisMath {
    private val HEALTH = Regex("insulin|glic|dose|bolus|carbo|mg/?dl|unidade|refei", RegexOption.IGNORE_CASE)
    private val FILLER = Regex("""\b(quanto e|quanto da|quanto fica|quanto vai ser|calcule|calcular|calcula|me diga|qual e o resultado d[eao]|qual o resultado d[eao]|resultado d[eao]|qual e|cris|por favor|pra mim)\b""")
    private val NUM = """\d+(?:[.,]\d+)*"""

    private fun num(s: String): Double {
        val t = if (Regex("""^\d{1,3}(\.\d{3})+(,\d+)?$""").matches(s)) s.replace(".", "").replace(',', '.') else s.replace(',', '.')
        return t.toDouble()
    }

    private val fmt = DecimalFormat("#,##0.######", DecimalFormatSymbols(Locale("pt", "BR")))
    private fun show(v: Double) = fmt.format(v)

    fun tryAnswer(text: String): String? {
        if (HEALTH.containsMatchIn(text)) return null
        var t = CrisTypo.fold(text).replace("?", " ").replace("=", " ")
        t = FILLER.replace(t, " ").replace(Regex("\\s+"), " ").trim()
        if (t.isEmpty() || !t.any { it.isDigit() }) return null
        if (Regex("""^\d{1,2}[-/]\d{1,2}[-/]\d{2,4}$""").matches(t)) return null

        Regex("""^($NUM)\s*(?:%|por cento)\s*d[eao]\s*($NUM)$""").find(t)?.let {
            val a = num(it.groupValues[1]); val b = num(it.groupValues[2])
            return "${show(a)}% de ${show(b)} = ${show(a * b / 100)}. Conta feita aqui no app, com precisão. 😊"
        }
        Regex("""^raiz quadrada d[eao]\s*($NUM)$""").find(t)?.let {
            val a = num(it.groupValues[1])
            return "A raiz quadrada de ${show(a)} é ${show(Math.sqrt(a))}. Conta feita aqui no app, com precisão. 😊"
        }

        t = t.replace(Regex("""(?<=\d)\s*x\s*(?=\d)"""), " * ")
            .replace(Regex("""\b(vezes|multiplicado por|multiplicado)\b"""), " * ")
            .replace(Regex("""\b(dividido por|dividido)\b"""), " / ").replace("÷", "/")
            .replace(Regex("""\bmais\b"""), " + ").replace(Regex("""\bmenos\b"""), " - ")
            .replace(Regex("""\b(elevado a|elevado ao)\b"""), " ^ ")
            .replace(Regex("""\bao quadrado\b"""), " ^ 2 ").replace(Regex("""\bao cubo\b"""), " ^ 3 ")
            .replace(Regex("\\s+"), " ").trim()
        if (!Regex("""^[0-9+\-*/^().,\s]+$""").matches(t)) return null
        if (!Regex("""[+\-*/^]""").containsMatchIn(t)) return null

        val value = try { Parser(t).parse() } catch (_: ArithmeticException) {
            return "Essa conta tem divisão por zero, e isso não tem resultado. 🙂"
        } catch (_: Exception) { return null }
        if (value.isNaN() || value.isInfinite()) return null
        val shown = Regex(NUM).replace(t) { show(num(it.value)) }.replace("*", "×").replace("/", "÷")
        return "$shown = ${show(value)}. Conta feita aqui no app, com precisão. 😊"
    }

    private class Parser(src: String) {
        private val s = src.replace(" ", "")
        private var i = 0
        fun parse(): Double { val v = expr(); if (i != s.length) throw IllegalArgumentException(); return v }
        private fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) { val op = s[i++]; val r = term(); v = if (op == '+') v + r else v - r }
            return v
        }
        private fun term(): Double {
            var v = power()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) {
                val op = s[i++]; val r = power()
                if (op == '/' && r == 0.0) throw ArithmeticException()
                v = if (op == '*') v * r else v / r
            }
            return v
        }
        private fun power(): Double {
            val b = unary()
            if (i < s.length && s[i] == '^') { i++; return Math.pow(b, power()) }
            return b
        }
        private fun unary(): Double {
            if (i < s.length && s[i] == '-') { i++; return -unary() }
            if (i < s.length && s[i] == '(') { i++; val v = expr(); if (i >= s.length || s[i] != ')') throw IllegalArgumentException(); i++; return v }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.' || s[i] == ',')) i++
            if (st == i) throw IllegalArgumentException()
            return num(s.substring(st, i))
        }
    }
}
