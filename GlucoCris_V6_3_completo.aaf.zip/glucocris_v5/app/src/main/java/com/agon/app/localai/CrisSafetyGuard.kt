package com.agon.app.localai

/**
 * Camada de segurança médica da Cris IA. Não substitui a lógica determinística do app:
 * - cálculos de glicemia/insulina continuam nas telas e funções originais;
 * - a IA generativa nunca decide dose.
 */
object CrisSafetyGuard {

    /** Regras que entram no prompt da IA local. */
    const val SYSTEM_RULES = """
Regras de segurança (obrigatórias):
- Você é uma assistente de apoio, não uma médica. Não prescreva, não altere tratamento e NUNCA diga quantas unidades de insulina aplicar ou como mudar a dose. Para dose, diga que isso é com a equipe de saúde e que a calculadora do app usa os fatores definidos por ela.
- Nunca invente medições, horários, doses, calorias ou carboidratos. Só cite valores que estejam no bloco "DADOS DO APP" ou escritos pela própria pessoa. Se não houver o dado, diga que não encontrou.
- Se a pessoa descrever sintomas graves (desmaio, confusão, convulsão, falta de ar, dor no peito, vômitos com glicose alta, glicose muito baixa que não melhora), oriente procurar atendimento de emergência (SAMU 192) imediatamente.
- Se não souber algo, diga que não sabe. Não finja ter consultado a internet quando estiver offline.
"""

    private val SELF_HARM = Regex("""(quero (me )?morrer|vou me matar|me matar|tirar (a )?minha vida|acabar com (a )?minha vida|n[aã]o quero mais viver|me machucar)""", RegexOption.IGNORE_CASE)
    private val SEVERE = Regex("""(n[aã]o consigo respirar|falta de ar forte|perdi a consci[eê]ncia|inconsciente|cetoacidose|hip[o]glicemia grave|glicose muito baixa e n[aã]o melhora)""", RegexOption.IGNORE_CASE)

    /** Resposta fixa para situações que não devem passar pela IA generativa. Null = seguir normalmente. */
    fun precheck(text: String): String? {
        if (SELF_HARM.containsMatchIn(text)) {
            return "Sinto muito que você esteja passando por isso, e fico feliz que tenha me contado. " +
                "Você não precisa enfrentar isso sozinha. Ligue agora para o CVV, no 188 (24 horas, gratuito), " +
                "ou para o SAMU, no 192, se estiver em perigo. Se puder, fale também com alguém de confiança que esteja perto de você."
        }
        if (SEVERE.containsMatchIn(text)) {
            return "Isso pode ser uma emergência. Ligue para o SAMU no 192 ou vá ao pronto-atendimento agora, sem esperar esta conversa."
        }
        return null
    }

    private val DOSE_ORDER = Regex(
        """(tome|aplique|use|injete|administre|aumente|diminua|reduza|dobre)\b[^.\n]{0,50}\b(\d+([.,]\d+)?\s*(ui|u\b|unidades?)|dose)""",
        RegexOption.IGNORE_CASE,
    )
    private val DOSE_AMOUNT = Regex("""\b(aplicar|aplique|tomar|tome)\s+\d+([.,]\d+)?\s*(ui|unidades?)\b""", RegexOption.IGNORE_CASE)

    const val DOSE_REFUSAL = "Não posso indicar nem ajustar dose de insulina. Isso é decisão da sua equipe de saúde. " +
        "A calculadora de bolus do app usa só os fatores definidos por ela, e eu posso montar um resumo dos seus registros para levar à consulta."

    /** Filtra a saída da IA generativa antes de mostrar. */
    fun postcheck(reply: String): String =
        if (DOSE_ORDER.containsMatchIn(reply) || DOSE_AMOUNT.containsMatchIn(reply)) DOSE_REFUSAL else reply
}
