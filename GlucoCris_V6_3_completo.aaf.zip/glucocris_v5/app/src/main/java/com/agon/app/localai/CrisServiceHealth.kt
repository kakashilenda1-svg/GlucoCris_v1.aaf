package com.agon.app.localai

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

/** Estado de um serviço da Cris, medido pelas chamadas reais (não por suposição). */
enum class ServiceState { UNKNOWN, OK, QUOTA, UNAVAILABLE, NOT_CONFIGURED }

data class CrisHealth(
    val gemini: ServiceState = ServiceState.UNKNOWN,
    val geminiAt: Long = 0L,
    val tavily: ServiceState = ServiceState.UNKNOWN,
    val tavilyAt: Long = 0L,
    /** Servidor (Cloudflare Worker) que intermedia Gemini e Tavily: UNAVAILABLE = nem chegou a responder. */
    val worker: ServiceState = ServiceState.UNKNOWN,
    val workerAt: Long = 0L,
    /** A IA local está instalada, mas a última geração falhou. */
    val localError: Boolean = false,
    val localAt: Long = 0L,
)

/**
 * Guarda o resultado da última chamada a cada serviço, para o indicador de status refletir o que
 * realmente aconteceu (sem internet x Gemini sem cota x pesquisa indisponível x IA local não instalada).
 * Nada aqui faz chamada de rede nem gasta cota.
 */
object CrisServiceHealth {
    /** Depois disso o último resultado é considerado velho e o indicador volta ao neutro. */
    const val FRESH_MS = 30 * 60_000L

    private val _state = MutableStateFlow(CrisHealth())
    val state: StateFlow<CrisHealth> = _state

    // update{} é atômico: chamadas concorrentes (Gemini e Tavily em paralelo) não se sobrescrevem.
    fun gemini(s: ServiceState, now: Long = System.currentTimeMillis()) {
        _state.update { it.copy(gemini = s, geminiAt = now) }
    }

    fun tavily(s: ServiceState, now: Long = System.currentTimeMillis()) {
        _state.update { it.copy(tavily = s, tavilyAt = now) }
    }

    /** OK = o servidor respondeu (mesmo com erro de cota); UNAVAILABLE = sem conexão com ele. */
    fun worker(s: ServiceState, now: Long = System.currentTimeMillis()) {
        _state.update { it.copy(worker = s, workerAt = now) }
    }

    fun local(error: Boolean, now: Long = System.currentTimeMillis()) {
        _state.update { it.copy(localError = error, localAt = now) }
    }

    /** Traduz o último motivo de falha do Gemini (texto interno) para um estado. */
    fun classifyGeminiError(error: String, quotaFlag: Boolean = false): ServiceState {
        val e = error.lowercase()
        return when {
            quotaFlag || "429" in e || "cota" in e || "limite" in e || "quota" in e -> ServiceState.QUOTA
            "não configurad" in e || "nao configurad" in e || "not_configured" in e -> ServiceState.NOT_CONFIGURED
            else -> ServiceState.UNAVAILABLE
        }
    }

    /** Aviso curto e honesto quando o Gemini não respondeu (sem detalhe técnico, que fica só no log). */
    fun geminiFailureNote(error: String): String = when (classifyGeminiError(error)) {
        ServiceState.QUOTA -> "A IA online está sem cota no momento."
        ServiceState.NOT_CONFIGURED -> ""
        else -> "A IA online não respondeu agora (serviço instável ou sem conexão com o servidor)."
    }

    private fun fresh(at: Long, now: Long) = at > 0L && now - at <= FRESH_MS

    /** Texto do indicador sob o nome da Cris (curto: a área é estreita). Cada situação tem sua própria mensagem. */
    fun headline(online: Boolean, localReady: Boolean, h: CrisHealth, now: Long = System.currentTimeMillis(), localInstalled: Boolean = localReady): String {
        if (!online) return if (localReady) "IA no aparelho · sem internet" else "sem internet · sem IA local"
        val issues = mutableListOf<String>()
        val workerDown = fresh(h.workerAt, now) && h.worker == ServiceState.UNAVAILABLE
        if (workerDown) {
            // Se o servidor não responde, Gemini e busca ficam fora juntos: um aviso só, sem culpar cada um.
            issues += "servidor da Cris indisponível"
        } else {
            if (fresh(h.geminiAt, now)) when (h.gemini) {
                ServiceState.QUOTA -> issues += "Gemini sem cota"
                ServiceState.UNAVAILABLE -> issues += "Gemini indisponível"
                else -> Unit
            }
            if (fresh(h.tavilyAt, now)) when (h.tavily) {
                ServiceState.QUOTA -> issues += "busca sem cota"
                ServiceState.UNAVAILABLE -> issues += "busca indisponível"
                ServiceState.NOT_CONFIGURED -> issues += "busca não configurada"
                else -> Unit
            }
        }
        if (localInstalled && h.localError && fresh(h.localAt, now)) issues += "IA local com erro"
        val base = if (localReady) "IA no aparelho · online" else "online"
        return when {
            issues.isNotEmpty() -> base + " · " + issues.joinToString(" · ")
            localReady -> base
            else -> "online · IA local não instalada"
        }
    }

    /** Mensagem final quando NENHUM recurso conseguiu responder. Não promete resposta nem inventa conteúdo. */
    fun allDownMessage(online: Boolean, localInstalled: Boolean, geminiError: String): String {
        if (!online) {
            return if (localInstalled) "Estou sem internet e o modelo local não conseguiu responder agora. Tente de novo em instantes. Não vou inventar uma resposta."
            else "Estou sem internet e a IA local não está instalada, então não consigo responder essa pergunta agora. Posso mostrar seus registros, criar lembretes ou abrir o localizador de insulina."
        }
        val why = geminiFailureNote(geminiError).ifBlank { "A IA online não respondeu." }
        val local = if (localInstalled) "O modelo local também não respondeu." else "A IA local não está instalada."
        return "$why A pesquisa na internet também não retornou resultados. $local " +
            "Não vou inventar uma resposta: toque em \"Tentar novamente\" daqui a pouco. Enquanto isso, posso mostrar seus registros, criar lembretes ou abrir o localizador."
    }
}
