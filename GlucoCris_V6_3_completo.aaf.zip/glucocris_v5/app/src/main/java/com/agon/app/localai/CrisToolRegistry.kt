package com.agon.app.localai

import com.agon.app.data.AppData
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.MEAL_LABEL
import com.agon.app.data.formatClock
import com.agon.app.data.formatDateTime
import com.agon.app.data.toMgDl
import kotlin.math.roundToInt

/** Ferramenta interna, somente leitura: responde com dados REAIS do app, sem passar pela IA generativa. */
class CrisTool(
    val name: String,
    val description: String,
    val triggers: List<Regex>,
    val run: (AppData) -> String,
)

data class ToolAnswer(val tool: String, val text: String)

/**
 * Registro de ferramentas permitidas. A IA só opera por estas funções (sem shell, sem código arbitrário).
 * Para adicionar uma nova função no futuro: [register].
 */
object CrisToolRegistry {
    private val tools = mutableListOf<CrisTool>()

    fun register(tool: CrisTool) { tools.add(tool) }
    fun names(): List<String> = tools.map { it.name }

    fun tryAnswer(text: String, data: AppData): ToolAnswer? {
        val t = tools.firstOrNull { tool -> tool.triggers.any { it.containsMatchIn(text) } } ?: return null
        return try { ToolAnswer(t.name, t.run(data)) } catch (_: Exception) { null }
    }

    private fun rx(vararg p: String) = p.map { Regex(it, RegexOption.IGNORE_CASE) }

    private fun mg(v: Double, unit: String) = toMgDl(v, unit).roundToInt()

    init {
        register(CrisTool(
            "ultima_glicemia", "Última glicemia registrada",
            rx("""[uú]ltima (glicemia|glicose|medi[cç][aã]o)""", """qual (foi )?(a )?minha (glicemia|glicose) (mais )?recente"""),
        ) { d ->
            val g = d.glucose.maxByOrNull { it.at }
            if (g == null) "Não há nenhuma glicemia registrada no app ainda."
            else "Sua última glicemia registrada foi ${mg(g.value, g.unit)} mg/dL (${GLUCOSE_CONTEXT_LABEL[g.context] ?: g.context}), em ${formatDateTime(g.at)}. Esse valor veio dos seus registros no app."
        })

        register(CrisTool(
            "historico_glicemia", "Medições recentes de glicemia",
            rx("""[uú]ltimas medi[cç][oõ]es""", """hist[oó]rico( de)? (glicemia|glicose)""", """como est[aá] meu hist[oó]rico""", """registros recentes""", """minhas medi[cç][oõ]es"""),
        ) { d ->
            val list = d.glucose.sortedByDescending { it.at }.take(7)
            if (list.isEmpty()) "Não há glicemias registradas no app ainda."
            else "Suas últimas medições registradas:\n" + list.joinToString("\n") {
                "• ${mg(it.value, it.unit)} mg/dL, ${GLUCOSE_CONTEXT_LABEL[it.context] ?: it.context}, ${formatDateTime(it.at)}"
            } + "\n\nPara gráficos e média, veja a aba Histórico."
        })

        register(CrisTool(
            "registros_insulina", "Registros de insulina",
            rx("""[uú]ltima insulina""", """[uú]ltimas insulinas""", """registros de insulina""", """quando (eu )?(apliquei|tomei) (a )?insulina"""),
        ) { d ->
            val list = d.insulin.sortedByDescending { it.at }.take(5)
            if (list.isEmpty()) "Não há aplicações de insulina registradas no app."
            else "Suas últimas aplicações registradas:\n" + list.joinToString("\n") {
                "• ${it.name}: ${it.dose.let { v -> if (v % 1.0 == 0.0) v.toInt().toString() else v.toString() }} ${it.unit}, ${formatDateTime(it.at)}"
            } + "\n\nEsses são só os registros que você fez; eu não calculo nem indico doses."
        })

        register(CrisTool(
            "registros_alimentacao", "Refeições registradas",
            rx("""o que (eu )?(registrei|anotei) (na|no) (alimenta[cç][aã]o|di[aá]rio)""", """o que (eu )?comi""", """minhas refei[cç][oõ]es""", """[uú]ltimas refei[cç][oõ]es"""),
        ) { d ->
            val list = d.meals.sortedByDescending { it.at }.take(6)
            if (list.isEmpty()) "Não há refeições registradas no diário alimentar."
            else "Suas últimas refeições registradas:\n" + list.joinToString("\n") {
                "• ${MEAL_LABEL[it.type] ?: it.type}: ${it.description}" +
                    (it.carbs?.let { c -> " (~${c.roundToInt()} g de carboidrato, valor que você registrou)" } ?: "") +
                    ", ${formatDateTime(it.at)}"
            }
        })

        register(CrisTool(
            "lembretes_programados", "Lembretes programados",
            rx("""quais lembretes""", """lembretes (programados|ativos)"""),
        ) { d ->
            val list = d.reminders.filter { it.enabled }.sortedWith(compareBy({ it.hour }, { it.minute }))
            if (list.isEmpty()) "Você não tem lembretes ativos no momento."
            else "Lembretes ativos:\n" + list.joinToString("\n") { "• ${it.title} às ${formatClock(it.hour, it.minute)}" }
        })

        register(CrisTool(
            "resumo_glicemia", "Resumo da glicemia na semana",
            rx(
                """como (est[aá]|estou) (essa|esta|a) semana""",
                """resumo (da |de )?(semana|glicemia|glicose)""",
                """m[eé]dia (da |de )?(semana|glicemia|glicose)""",
                """como est[aá] minha glicose""",
                """padr[aã]o (da |de )?glicemia""",
            ),
        ) { d ->
            val week = d.glucose.filter { it.at >= System.currentTimeMillis() - 7L * 86_400_000 }
            if (week.isEmpty()) return@CrisTool "Nesta semana ainda não há glicemias registradas no app."
            val vals = week.map { toMgDl(it.value, it.unit) }
            val avg = vals.average().roundToInt()
            val min = vals.minOrNull()?.roundToInt() ?: 0
            val max = vals.maxOrNull()?.roundToInt() ?: 0
            val hypo = vals.count { it < 70.0 }
            val hyper = vals.count { it > 180.0 }
            val low = d.settings.targetLow
            val high = d.settings.targetHigh
            val inRange = vals.count { it >= low && it <= high }
            val pct = (inRange * 100.0 / vals.size).roundToInt()
            buildString {
                append("Resumo dos seus registros nos últimos 7 dias (${week.size} medições):\n")
                append("• Média: ~$avg mg/dL (mín $min · máx $max)\n")
                append("• Na meta do app (${low.toInt()}-${high.toInt()} mg/dL): ~$pct%\n")
                if (hypo > 0) append("• Abaixo de 70: $hypo vez(es)\n")
                if (hyper > 0) append("• Acima de 180: $hyper vez(es)\n")
                // Padrão manhã vs resto
                val morning = week.filter {
                    val h = java.util.Calendar.getInstance().apply { timeInMillis = it.at }.get(java.util.Calendar.HOUR_OF_DAY)
                    h in 5..11
                }
                if (morning.size >= 2) {
                    val mAvg = morning.map { toMgDl(it.value, it.unit) }.average().roundToInt()
                    append("• Manhãs (5h–11h): média ~$mAvg mg/dL em ${morning.size} medições\n")
                }
                append("\nIsso veio só dos seus registros no aparelho. Não substitui orientação da sua equipe de saúde.")
            }
        })

        register(CrisTool(
            "hipoglicemias", "Episódios de hipoglicemia recentes",
            rx("""hipo(glicemia)?s?""", """baixas? (de )?glicose""", """glicose baixa""", """caiu (a )?glicose"""),
        ) { d ->
            val list = d.glucose.sortedByDescending { it.at }
                .filter { toMgDl(it.value, it.unit) < 70.0 }
                .take(5)
            if (list.isEmpty()) "Nos registros do app não há medições abaixo de 70 mg/dL recentemente."
            else "Medições abaixo de 70 mg/dL nos seus registros:\n" + list.joinToString("\n") {
                "• ${mg(it.value, it.unit)} mg/dL, ${GLUCOSE_CONTEXT_LABEL[it.context] ?: it.context}, ${formatDateTime(it.at)}"
            } + "\n\nSe estiver se sentindo mal agora, siga o plano combinado com sua equipe de saúde."
        })

    }
}
