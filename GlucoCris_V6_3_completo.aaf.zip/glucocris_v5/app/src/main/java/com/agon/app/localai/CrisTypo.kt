package com.agon.app.localai

import java.text.Normalizer

/** Tolerância a erros de digitação: corrige só palavras-chave conhecidas (usado para decidir/pesquisar, nunca mostrado). */
object CrisTypo {
    fun fold(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").lowercase()

    private val VOCAB = listOf(
        "presidente", "atualmente", "notícias", "notícia", "semana", "descobriu", "brasil", "governador", "prefeito",
        "ministro", "aconteceu", "acontecendo", "importante", "importantes", "principais", "recentes", "últimas",
        "resultado", "cotação", "dólar", "medicamento", "remédio", "vacina", "quanto", "capital", "frança",
        "estados", "unidos", "mundial", "campeão", "inteligência", "artificial", "funciona", "explique", "pesquise",
        "internet", "argentina", "portugal", "alemanha", "espanha", "itália", "inglaterra", "japão", "china", "rússia",
    )
    private val VOCAB_F = VOCAB.map { fold(it) }
    private val SHORT = mapOf("oje" to "hoje", "hj" to "hoje", "ontm" to "ontem", "qm" to "quem", "pq" to "porque", "vc" to "você")

    private fun dist(a: String, b: String): Int {
        if (a == b) return 0
        var prev = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            val cur = IntArray(b.length + 1)
            cur[0] = i
            for (j in 1..b.length) {
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + if (a[i - 1] == b[j - 1]) 0 else 1)
            }
            prev = cur
        }
        return prev[b.length]
    }

    private fun fixToken(tok: String): String {
        SHORT[tok.lowercase()]?.let { return it }
        val f = fold(tok)
        if (f.length < 5 || f.any { !it.isLetter() }) return tok
        if (VOCAB_F.contains(f)) return tok
        val max = if (f.length >= 8) 2 else 1
        var best = -1
        var bestD = max + 1
        var ambiguous = false
        for (i in VOCAB_F.indices) {
            val v = VOCAB_F[i]
            if (v[0] != f[0] || kotlin.math.abs(v.length - f.length) > max) continue
            val d = dist(f, v)
            if (d < bestD) { bestD = d; best = i; ambiguous = false } else if (d == bestD) ambiguous = true
        }
        return if (best >= 0 && bestD <= max && !ambiguous) VOCAB[best] else tok
    }

    fun fix(text: String): String =
        Regex("""\p{L}+""").replace(text) { fixToken(it.value) }
}
