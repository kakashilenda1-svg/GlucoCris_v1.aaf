package com.agon.app.localai

import android.content.Context

/**
 * Preferências da IA local (SharedPreferences privado, lido de forma síncrona).
 * Padrões conservadores: nada de dados de saúde ou texto de respostas sai do aparelho sem autorização.
 */
object LocalAiSettings {
    private const val FILE = "cris_localai_settings"
    private fun p(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** Usa o modelo local quando ele estiver instalado. */
    fun enabled(c: Context): Boolean = p(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()

    /** Voz natural da nuvem (envia o texto da resposta ao servidor). Padrão: desligado. */
    fun cloudVoiceAllowed(c: Context): Boolean = p(c).getBoolean("cloud_voice", false)
    fun setCloudVoiceAllowed(c: Context, v: Boolean) = p(c).edit().putBoolean("cloud_voice", v).apply()

    /** Permite enviar o resumo de glicemia/insulina/alimentação a serviços online (Gemini/servidor). Padrão: desligado. */
    fun onlineHealthContextAllowed(c: Context): Boolean = p(c).getBoolean("online_health", false)
    fun setOnlineHealthContextAllowed(c: Context, v: Boolean) = p(c).edit().putBoolean("online_health", v).apply()

    /** Id do modelo cujo download a usuária autorizou. */
    fun consentedModel(c: Context): String = p(c).getString("consent_model", "") ?: ""
    fun setConsentedModel(c: Context, id: String) = p(c).edit().putString("consent_model", id).apply()

    /** Pesquisa online automática como ferramenta da Cris (a IA local continua respondendo). Padrão: ligada. */
    fun webSearchEnabled(c: Context): Boolean = p(c).getBoolean("web_search", true)
    fun setWebSearchEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("web_search", v).apply()

    /** Pesquisa geral (Tavily) disponível: o APK foi gerado com o endereço do proxy. A chave da Tavily NÃO fica no app. */
    fun tavilyAvailable(c: Context): Boolean = TavilySearch.isConfigured()

    /** A pergunta "baixar a IA local?" da primeira abertura já foi respondida (sim ou não). */
    fun downloadOfferAnswered(c: Context): Boolean = p(c).getBoolean("download_offer_answered", false)
    fun setDownloadOfferAnswered(c: Context, v: Boolean) = p(c).edit().putBoolean("download_offer_answered", v).apply()

    /** Mantém o download da IA local em segundo plano (serviço com notificação). Padrão: ligado. */
    fun backgroundDownload(c: Context): Boolean = p(c).getBoolean("bg_download", true)
    fun setBackgroundDownload(c: Context, v: Boolean) = p(c).edit().putBoolean("bg_download", v).apply()


    /** Estilo de resposta: "direct" (1–3 frases) ou "explain" (mais detalhe). */
    fun answerStyle(c: Context): String = p(c).getString("answer_style", "direct") ?: "direct"
    fun setAnswerStyle(c: Context, v: String) = p(c).edit().putString("answer_style", v).apply()
    fun isDirectStyle(c: Context): Boolean = answerStyle(c) != "explain"

    /** Modelo escolhido (id do LocalModels). Vazio = DEFAULT. */
    fun selectedModelId(c: Context): String = p(c).getString("selected_model", "") ?: ""
    fun setSelectedModelId(c: Context, id: String) = p(c).edit().putString("selected_model", id).apply()

    /** Avisar (notificação) quando a Cris terminar uma pergunta/pesquisa em segundo plano. Padrão: ligado. */
    fun taskNotify(c: Context): Boolean = p(c).getBoolean("task_notify", true)
    fun setTaskNotify(c: Context, v: Boolean) = p(c).edit().putBoolean("task_notify", v).apply()

    /** Som na notificação de tarefa concluída (respeita volume e modo silencioso do aparelho). Padrão: ligado. */
    fun taskSound(c: Context): Boolean = p(c).getBoolean("task_sound", true)
    fun setTaskSound(c: Context, v: Boolean) = p(c).edit().putBoolean("task_sound", v).apply()

    // ---- Escolha/instalação de modelo (atualização de usuários antigos) ----

    /** Modelo instalado, validado e em uso. Vazio = ainda não definido (migração infere do disco). */
    fun activeModelId(c: Context): String = p(c).getString("active_model", "") ?: ""
    fun setActiveModelId(c: Context, id: String) = p(c).edit().putString("active_model", id).apply()

    /** Modelo que está sendo baixado/instalado agora (o ativo continua intacto até a troca ser concluída). */
    fun targetModelId(c: Context): String = p(c).getString("target_model", "") ?: ""
    fun setTargetModelId(c: Context, id: String) = p(c).edit().putString("target_model", id).apply()

    /** Versão do catálogo do modelo instalado (0 = desconhecida / veio de versão antiga do app). */
    fun installedModelVersion(c: Context, id: String): Int = p(c).getInt("model_ver_$id", 0)
    fun setInstalledModelVersion(c: Context, id: String, v: Int) = p(c).edit().putInt("model_ver_$id", v).apply()

    /** Último erro de download (persistido para o estado "falhou" sobreviver ao reinício do processo). */
    fun downloadError(c: Context): String = p(c).getString("download_error", "") ?: ""
    fun setDownloadError(c: Context, msg: String) = p(c).edit().putString("download_error", msg).apply()

    /** Permite baixar com dados móveis (senão o WorkManager só roda no Wi-Fi). */
    fun allowMeteredDownload(c: Context): Boolean = p(c).getBoolean("allow_metered", false)
    fun setAllowMeteredDownload(c: Context, v: Boolean) = p(c).edit().putBoolean("allow_metered", v).apply()

    /** versionCode do app na última abertura (0 = nunca gravado: instalação nova OU versão anterior à 1.25). */
    fun lastRunVersionCode(c: Context): Int = p(c).getInt("last_run_version", 0)
    fun setLastRunVersionCode(c: Context, v: Int) = p(c).edit().putInt("last_run_version", v).apply()

    /** versionCode em que a pessoa tocou "Agora não" na tela de escolha (não insistir na mesma versão). */
    fun chooserDismissedVersion(c: Context): Int = p(c).getInt("chooser_dismissed", 0)
    fun setChooserDismissedVersion(c: Context, v: Int) = p(c).edit().putInt("chooser_dismissed", v).apply()

    /** versionCode em que a pessoa já viu "manter ou trocar o modelo atual". */
    fun keepOrChangeSeenVersion(c: Context): Int = p(c).getInt("keep_or_change_seen", 0)
    fun setKeepOrChangeSeenVersion(c: Context, v: Int) = p(c).edit().putInt("keep_or_change_seen", v).apply()

    /** O usuário quer que o download continue (false = pausado/cancelado). Sobrevive ao reinício do processo. */
    fun downloadWanted(c: Context): Boolean = p(c).getBoolean("download_wanted", false)
    fun setDownloadWanted(c: Context, v: Boolean) = p(c).edit().putBoolean("download_wanted", v).apply()
}
