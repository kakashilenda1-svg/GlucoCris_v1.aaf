package com.agon.app.localai

import android.content.Context
import com.agon.app.data.uid
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/** Fato guardado a pedido explícito da usuária. Fica só neste aparelho. */
@Serializable
data class CrisFact(val id: String, val text: String, val createdAt: Long)

/**
 * Memória de longo prazo da Cris, separada do histórico de conversa.
 * Só entra algo aqui quando a usuária pede ("lembre que ...") ou cria/edita na tela de configurações.
 */
object LocalMemoryManager {
    private const val FILE = "cris_localai_memory"
    private const val KEY = "facts.v1"
    private const val MAX_FACTS = 60
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    private fun p(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    @Synchronized
    fun load(c: Context): List<CrisFact> {
        val raw = p(c).getString(KEY, null) ?: return emptyList()
        return try { json.decodeFromString<List<CrisFact>>(raw) } catch (_: Exception) { emptyList() }
    }

    @Synchronized
    private fun save(c: Context, list: List<CrisFact>) {
        p(c).edit().putString(KEY, json.encodeToString(list.takeLast(MAX_FACTS))).apply()
    }

    fun add(c: Context, text: String): CrisFact? {
        val t = text.trim().take(300)
        if (t.length < 3) return null
        val f = CrisFact(uid(), t, System.currentTimeMillis())
        save(c, load(c) + f)
        return f
    }

    fun update(c: Context, id: String, text: String) {
        val t = text.trim().take(300)
        if (t.isBlank()) return
        save(c, load(c).map { if (it.id == id) it.copy(text = t) else it })
    }

    fun remove(c: Context, id: String) = save(c, load(c).filterNot { it.id == id })

    fun clear(c: Context) = p(c).edit().remove(KEY).apply()

    private val SAVE_RE = Regex("""^\s*(?:cris[,!]?\s*)?(?:por favor[,]?\s*)?(?:lembre|lembra|guarde|guarda|memorize|anote|anota)\s+(?:que\s+|isso:?\s*|aí:?\s*)?(.+)$""", RegexOption.IGNORE_CASE)
    private val FORGET_RE = Regex("""^\s*(?:cris[,!]?\s*)?(?:esque[cç]a|apague|apaga|remova|remove)\s+(?:que\s+|a memória sobre\s+|o que (?:eu )?(?:disse|falei) sobre\s+)(.+)$""", RegexOption.IGNORE_CASE)
    private val LIST_RE = Regex("""(o que (você|voce|vc) (sabe|lembra|guardou)( sobre mim)?|suas? mem[oó]rias|minhas mem[oó]rias|o que (você|voce|vc) anotou)""", RegexOption.IGNORE_CASE)
    private val CLEAR_RE = Regex("""(apague|apaga|limpe|limpa|esque[cç]a)\s+(tudo|todas as (minhas )?mem[oó]rias|todas as mem[oó]rias)""", RegexOption.IGNORE_CASE)

    /** Resposta direta para comandos de memória, ou null se a mensagem não for um comando. */
    fun handleCommand(c: Context, text: String): String? {
        if (CLEAR_RE.containsMatchIn(text)) {
            clear(c)
            return "Pronto, apaguei tudo o que eu tinha guardado sobre você neste aparelho."
        }
        FORGET_RE.find(text)?.let { m ->
            val term = m.groupValues[1].trim().lowercase()
            val facts = load(c)
            val hit = facts.filter { term.length >= 3 && it.text.lowercase().contains(term) }
            if (hit.isEmpty()) return "Não encontrei nada guardado sobre \"$term\"."
            hit.forEach { remove(c, it.id) }
            return "Esqueci ${hit.size} item(ns) sobre \"$term\"."
        }
        if (LIST_RE.containsMatchIn(text)) {
            val facts = load(c)
            return if (facts.isEmpty()) "Ainda não guardei nada sobre você. Se quiser, diga \"lembre que ...\"."
            else "Isto é o que guardei (só neste aparelho):\n" + facts.joinToString("\n") { "• ${it.text}" } +
                "\n\nVocê pode editar ou apagar na tela de configurações da Cris IA."
        }
        SAVE_RE.find(text)?.let { m ->
            val body = m.groupValues[1].trim().trimEnd('.', '!')
            // Não confunde com a nota de preferência já tratada pela Cris local antiga:
            // aqui guardamos qualquer fato pedido explicitamente.
            val f = add(c, body) ?: return null
            return "Guardei: \"${f.text}\". Fica só neste aparelho e você pode apagar quando quiser."
        }
        return null
    }

    /** Bloco de texto para o prompt da IA local. */
    fun promptBlock(c: Context): String {
        val f = load(c)
        if (f.isEmpty()) return ""
        return "Coisas que a pessoa pediu para você lembrar:\n" + f.joinToString("\n") { "- ${it.text}" } + "\n"
    }
}
