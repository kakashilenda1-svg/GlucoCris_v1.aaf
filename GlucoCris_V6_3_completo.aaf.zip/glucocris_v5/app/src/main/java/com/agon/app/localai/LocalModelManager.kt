package com.agon.app.localai

import android.content.Context
import android.os.StatFs
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/** Modelo local GGUF (llama.cpp). Tamanho conferido no repositório Hugging Face. */
data class LocalModelSpec(
    val id: String,
    val displayName: String,
    val fileName: String,
    val url: String,
    val sizeBytes: Long,
    val sha256: String,
    val license: String,
    /** Nome curto mostrado na tela de escolha (ex.: "Leve"). */
    val tierName: String = displayName.substringBefore('·').trim(),
    /** RAM total mínima e recomendada do aparelho, em GB (texto da tela de escolha; o ModelAdvisor decide a compatibilidade real). */
    val minRamGb: Int = 3,
    val recommendedRamGb: Int = 4,
    val highlights: List<String> = emptyList(),
    /** Sobe quando o arquivo/URL do modelo muda (permite oferecer "atualizar o modelo" no futuro). */
    val version: Int = 1,
)

object LocalModels {
    /** Leve: ~1,04 GB, para aparelhos com menos recursos. Os ids/arquivos são os mesmos das versões anteriores do app. */
    val QWEN25_1_5B = LocalModelSpec(
        id = "qwen2.5-1.5b-instruct-q4_k_m",
        displayName = "Rápida · Qwen2.5 1.5B",
        fileName = "qwen2.5-1.5b-instruct-q4_k_m.gguf",
        url = "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf",
        sizeBytes = 1_117_320_736L,
        sha256 = "",
        license = "Apache-2.0 (Qwen)",
        tierName = "IA local mais leve",
        minRamGb = 3,
        recommendedRamGb = 4,
        highlights = listOf(
            "Responde mais depressa",
            "Gasta menos memória e bateria",
            "Roda bem em aparelhos simples",
            "Download menor",
        ),
    )

    /** Potente: ~1,96 GB, mais qualidade em perguntas difíceis, mais lenta. */
    val QWEN25_3B = LocalModelSpec(
        id = "qwen2.5-3b-instruct-q4_k_m",
        displayName = "Precisa · Qwen2.5 3B",
        fileName = "qwen2.5-3b-instruct-q4_k_m.gguf",
        url = "https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf",
        sizeBytes = 2_104_932_768L,
        sha256 = "",
        license = "Apache-2.0 (Qwen)",
        tierName = "IA local mais potente",
        minRamGb = 6,
        recommendedRamGb = 8,
        highlights = listOf(
            "Respostas com mais qualidade",
            "Entende melhor perguntas difíceis",
            "Mais lenta que a leve",
            "Precisa de aparelho com mais memória",
        ),
    )

    val LIGHT = QWEN25_1_5B
    val POWERFUL = QWEN25_3B
    val DEFAULT = QWEN25_1_5B
    val ALL = listOf(QWEN25_1_5B, QWEN25_3B)
    fun byId(id: String): LocalModelSpec = ALL.firstOrNull { it.id == id } ?: DEFAULT
    fun byIdOrNull(id: String): LocalModelSpec? = ALL.firstOrNull { it.id == id }
}

/** Resultado da checagem de um arquivo de modelo no disco. */
enum class ModelCheck { NOT_INSTALLED, OK, INCOMPLETE, CORRUPT }

sealed interface ModelState {
    data object Missing : ModelState
    data class Downloading(val done: Long, val total: Long) : ModelState
    data class Paused(val done: Long, val total: Long) : ModelState
    /** Na fila do WorkManager: aguardando rede/Wi-Fi, reconectando ou esperando para começar. */
    data class Waiting(val done: Long, val total: Long, val note: String) : ModelState
    data class Failed(val message: String, val done: Long, val total: Long) : ModelState
    data object Verifying : ModelState
    data object Ready : ModelState
}

sealed interface SelectResult {
    /** O modelo já estava instalado e íntegro: virou o modelo em uso na hora, sem baixar nada. */
    data object Activated : SelectResult
    data object Started : SelectResult
    data class NoSpace(val needBytes: Long, val haveBytes: Long) : SelectResult
}

sealed interface DownloadOutcome {
    data object Success : DownloadOutcome
    /** Falha passageira (rede, servidor): o WorkManager tenta de novo com espera crescente. */
    data class Retry(val message: String) : DownloadOutcome
    data class Failure(val message: String) : DownloadOutcome
}

/**
 * Guarda os modelos em diretório privado do app (noBackupFilesDir: fora do backup automático, preservado em
 * atualizações do app).
 *
 * Conceitos:
 *  - modelo ATIVO ([activeSpec]): instalado, íntegro e em uso pela Cris. Só muda depois que outro é validado.
 *  - modelo ALVO ([targetSpec]): o que está sendo baixado. Enquanto baixa, o ativo continua intacto.
 *  - [state] descreve o alvo (se houver) ou o ativo.
 *
 * O download em si roda no [ModelDownloadWorker] (WorkManager); este objeto guarda o estado e a lógica.
 */
class LocalModelManager private constructor(context: Context) {
    private val app = context.applicationContext

    private val dir: File get() = File(app.noBackupFilesDir, "localai/models").apply { mkdirs() }
    private val verified = ConcurrentHashMap<String, Pair<Long, Long>>()

    fun fileOf(s: LocalModelSpec): File = File(dir, s.fileName)
    private fun partOf(s: LocalModelSpec): File = File(dir, s.fileName + ".part")
    /** Projetor multimodal opcional (mmproj) para visão via llama.cpp. */
    fun mmprojOf(s: LocalModelSpec): File = File(dir, "mmproj-" + s.id + ".gguf")

    // ---------------------------------------------------------------- inspeção

    /** Confere o arquivo: existe, tem o tamanho exato e começa com o cabeçalho "GGUF". Resultado em cache por (tamanho, data). */
    fun inspect(s: LocalModelSpec): ModelCheck {
        val f = fileOf(s)
        if (!f.exists()) return ModelCheck.NOT_INSTALLED
        if (f.length() != s.sizeBytes) return ModelCheck.INCOMPLETE
        val key = Pair(f.length(), f.lastModified())
        if (verified[s.id] == key) return ModelCheck.OK
        if (!hasGgufMagic(f)) return ModelCheck.CORRUPT
        verified[s.id] = key
        return ModelCheck.OK
    }

    private fun hasGgufMagic(f: File): Boolean = try {
        f.inputStream().use { ins ->
            val b = ByteArray(4)
            ins.read(b) == 4 && b[0] == 'G'.code.toByte() && b[1] == 'G'.code.toByte() &&
                b[2] == 'U'.code.toByte() && b[3] == 'F'.code.toByte()
        }
    } catch (_: Exception) {
        false
    }

    /** Modelos instalados e íntegros (podem ser 0, 1 ou 2; versões antigas permitiam baixar os dois). */
    fun installedSpecs(): List<LocalModelSpec> = LocalModels.ALL.filter { inspect(it) == ModelCheck.OK }

    /** Há arquivo no lugar de um modelo, mas ele está incompleto/corrompido. */
    fun damagedSpecs(): List<LocalModelSpec> = LocalModels.ALL.filter {
        val c = inspect(it); c == ModelCheck.INCOMPLETE || c == ModelCheck.CORRUPT
    }

    /** Versão do catálogo do modelo instalado (arquivos de versões antigas do app contam como versão 1). */
    fun installedVersion(s: LocalModelSpec): Int =
        LocalAiSettings.installedModelVersion(app, s.id).let { if (it == 0 && inspect(s) == ModelCheck.OK) 1 else it }

    fun updateAvailable(s: LocalModelSpec): Boolean = inspect(s) == ModelCheck.OK && s.version > installedVersion(s)

    // ---------------------------------------------------------------- modelo ativo / alvo

    /**
     * Modelo em uso. Migração: se o app antigo não gravava o ativo, usa o modelo que a pessoa tinha escolhido
     * (ou o padrão) quando o arquivo está íntegro; senão qualquer outro instalado. Nada é apagado ou rebaixado.
     */
    val activeSpec: LocalModelSpec?
        @Synchronized get() {
            val saved = LocalModels.byIdOrNull(LocalAiSettings.activeModelId(app))
            if (saved != null && inspect(saved) == ModelCheck.OK) return saved
            val legacy = LocalModels.byIdOrNull(LocalAiSettings.selectedModelId(app))
            val found = (listOfNotNull(legacy) + LocalModels.ALL).distinct().firstOrNull { inspect(it) == ModelCheck.OK }
            if (found != null) {
                LocalAiSettings.setActiveModelId(app, found.id)
                if (LocalAiSettings.installedModelVersion(app, found.id) == 0) LocalAiSettings.setInstalledModelVersion(app, found.id, 1)
            } else if (saved != null) {
                LocalAiSettings.setActiveModelId(app, "")
            }
            return found
        }

    val targetSpec: LocalModelSpec? get() = LocalModels.byIdOrNull(LocalAiSettings.targetModelId(app))

    /** Modelo "em foco": o que está baixando, senão o ativo, senão o recomendado para o aparelho. */
    val spec: LocalModelSpec
        get() = targetSpec ?: activeSpec ?: (try { ModelAdvisor.advise(app).recommended } catch (_: Exception) { LocalModels.DEFAULT })

    /** Arquivo do modelo em uso (se não houver, o caminho do modelo em foco, que ainda não existe). */
    val modelFile: File get() = fileOf(activeSpec ?: spec)
    val mmprojFile: File get() = mmprojOf(activeSpec ?: spec)

    fun isInstalled(): Boolean = activeSpec != null

    // ---------------------------------------------------------------- estado

    private val _state = MutableStateFlow<ModelState>(ModelState.Missing)
    val state: StateFlow<ModelState> = _state.asStateFlow()

    /** Velocidade média recente do download (bytes/s); 0 quando não há download ativo. */
    private val _speed = MutableStateFlow(0L)
    val speedBytesPerSec: StateFlow<Long> = _speed.asStateFlow()

    init { refresh() }

    /** Reavalia o estado a partir do disco e das preferências (chamar ao abrir a tela). */
    fun refresh() {
        val cur = _state.value
        if (cur is ModelState.Downloading || cur is ModelState.Verifying) return
        val t = targetSpec
        if (t != null && inspect(t) == ModelCheck.OK) {
            // Terminou de instalar mas o processo morreu antes de ativar: conclui agora.
            activate(t, deletePrevious = true)
            return
        }
        _state.value = when {
            t != null -> {
                val part = partLen(t)
                val err = LocalAiSettings.downloadError(app)
                when {
                    LocalAiSettings.downloadWanted(app) -> ModelState.Waiting(part, t.sizeBytes, "Na fila do Android; começa assim que houver conexão.")
                    err.isNotBlank() -> ModelState.Failed(err, part, t.sizeBytes)
                    part > 0 -> ModelState.Paused(part, t.sizeBytes)
                    else -> ModelState.Missing
                }
            }
            activeSpec != null -> ModelState.Ready
            else -> ModelState.Missing
        }
    }

    fun freeBytes(): Long = try { StatFs(dir.path).availableBytes } catch (_: Exception) { 0L }

    /** Bytes que ainda precisam ser baixados + margem de 400 MB para o motor llama.cpp. */
    fun requiredFreeBytes(s: LocalModelSpec = spec): Long =
        (s.sizeBytes - partLen(s)).coerceAtLeast(0L) + 400L * 1024 * 1024

    fun hasEnoughSpace(s: LocalModelSpec = spec): Boolean = freeBytes() >= requiredFreeBytes(s)

    private fun partLen(s: LocalModelSpec): Long = partOf(s).let { if (it.exists()) it.length() else 0L }

    private fun idleState(t: LocalModelSpec): ModelState =
        if (LocalAiSettings.downloadWanted(app)) ModelState.Waiting(partLen(t), t.sizeBytes, "Aguardando conexão…")
        else ModelState.Paused(partLen(t), t.sizeBytes)

    // ---------------------------------------------------------------- ações da pessoa

    /**
     * Escolhe um modelo. Se ele já está instalado e íntegro, passa a ser usado na hora. Senão agenda o download
     * no WorkManager. O modelo em uso NUNCA é apagado aqui: só depois que o novo for baixado, validado e ativado.
     */
    fun select(s: LocalModelSpec, allowMetered: Boolean = LocalAiSettings.allowMeteredDownload(app)): SelectResult {
        if (inspect(s) == ModelCheck.OK) {
            ModelDownloadScheduler.cancel(app)
            activate(s, deletePrevious = false)
            return SelectResult.Activated
        }
        if (inspect(s) != ModelCheck.NOT_INSTALLED) {
            // Arquivo final incompleto/corrompido do mesmo modelo: descarta só ele (não é o modelo em uso: este não está íntegro).
            fileOf(s).delete()
            verified.remove(s.id)
        }
        LocalAiSettings.setTargetModelId(app, s.id)
        LocalAiSettings.setConsentedModel(app, s.id)
        LocalAiSettings.setDownloadError(app, "")
        LocalAiSettings.setAllowMeteredDownload(app, allowMetered)
        val need = requiredFreeBytes(s)
        val have = freeBytes()
        if (have < need) {
            LocalAiSettings.setDownloadWanted(app, false)
            val msg = "Espaço insuficiente: precisa de ${fmtBytes(need)} livres e há ${fmtBytes(have)}. " +
                (if (activeSpec != null) "O modelo que você usa hoje foi mantido. " else "") + "Libere espaço e tente de novo."
            LocalAiSettings.setDownloadError(app, msg)
            _state.value = ModelState.Failed(msg, partLen(s), s.sizeBytes)
            return SelectResult.NoSpace(need, have)
        }
        LocalAiSettings.setDownloadWanted(app, true)
        _state.value = ModelState.Waiting(partLen(s), s.sizeBytes, "Na fila…")
        ModelDownloadScheduler.enqueue(app, allowMetered)
        return SelectResult.Started
    }

    /** Inicia ou retoma o download do modelo em foco (alvo, ou o recomendado se não há nada). */
    fun start(allowMetered: Boolean = LocalAiSettings.allowMeteredDownload(app)): SelectResult = select(spec, allowMetered)

    fun pause() {
        LocalAiSettings.setDownloadWanted(app, false)
        ModelDownloadScheduler.cancel(app)
        _speed.value = 0L
        targetSpec?.let { _state.value = ModelState.Paused(partLen(it), it.sizeBytes) }
    }

    /** Cancela o download em andamento e apaga só o arquivo parcial. Modelo já instalado não é tocado. */
    fun cancel() {
        LocalAiSettings.setDownloadWanted(app, false)
        ModelDownloadScheduler.cancel(app)
        targetSpec?.let { partOf(it).delete() }
        LocalAiSettings.setTargetModelId(app, "")
        LocalAiSettings.setDownloadError(app, "")
        _speed.value = 0L
        _state.value = if (activeSpec != null) ModelState.Ready else ModelState.Missing
    }

    /** Apaga um modelo instalado (e o parcial dele). Se era o ativo, o app volta às respostas básicas (ou a outro modelo instalado). */
    fun deleteModel(s: LocalModelSpec) {
        val wasTarget = LocalAiSettings.targetModelId(app) == s.id
        if (wasTarget) cancel()
        LocalAiEngine.get(app).unload()
        fileOf(s).delete(); partOf(s).delete(); mmprojOf(s).delete()
        verified.remove(s.id)
        LocalAiSettings.setInstalledModelVersion(app, s.id, 0)
        if (LocalAiSettings.activeModelId(app) == s.id) LocalAiSettings.setActiveModelId(app, "")
        if (LocalAiSettings.selectedModelId(app) == s.id) LocalAiSettings.setSelectedModelId(app, "")
        refresh()
    }

    // ---------------------------------------------------------------- ativação

    /** Torna [s] o modelo em uso. Só é chamado com [s] já íntegro. O anterior só é apagado depois disso e só se [deletePrevious]. */
    private fun activate(s: LocalModelSpec, deletePrevious: Boolean) {
        val prev = activeSpec?.takeIf { it.id != s.id }
        LocalAiSettings.setActiveModelId(app, s.id)
        LocalAiSettings.setSelectedModelId(app, s.id)
        LocalAiSettings.setInstalledModelVersion(app, s.id, s.version)
        LocalAiSettings.setTargetModelId(app, "")
        LocalAiSettings.setDownloadError(app, "")
        LocalAiSettings.setDownloadWanted(app, false)
        LocalAiEngine.get(app).unload()
        if (deletePrevious && prev != null && inspect(s) == ModelCheck.OK) {
            fileOf(prev).delete(); mmprojOf(prev).delete()
            verified.remove(prev.id)
            LocalAiSettings.setInstalledModelVersion(app, prev.id, 0)
        }
        // Restos de downloads abandonados de outros modelos só ocupam espaço
        LocalModels.ALL.filter { it.id != s.id }.forEach { partOf(it).delete() }
        // Modelo antigo LiteRT (migração Gemma → llama.cpp)
        try { File(dir, "gemma-4-E2B-it.litertlm").delete() } catch (_: Exception) {}
        _speed.value = 0L
        _state.value = ModelState.Ready
    }

    // ---------------------------------------------------------------- download (chamado pelo ModelDownloadWorker)

    /** Chamado pelo worker ao ser parado (pausa, perda de rede, limite do Android): reflete o estado certo na interface. */
    internal fun onWorkerStopped() {
        _speed.value = 0L
        val t = targetSpec ?: return
        if (_state.value is ModelState.Downloading || _state.value is ModelState.Verifying) _state.value = idleState(t)
    }

    internal fun onWorkerWaiting(note: String) {
        val t = targetSpec ?: return
        _speed.value = 0L
        _state.value = ModelState.Waiting(partLen(t), t.sizeBytes, note)
    }

    /**
     * Baixa o modelo alvo (com retomada por Range), valida (tamanho, cabeçalho GGUF e SHA-256 se conhecido), instala e ativa.
     * Cancelamento (pausa) lança [CancellationException]; o arquivo parcial é mantido.
     */
    internal suspend fun downloadTarget(onProgress: suspend (done: Long, total: Long) -> Unit): DownloadOutcome {
        val s = targetSpec ?: return DownloadOutcome.Failure("Nenhum modelo selecionado.")
        val total = s.sizeBytes
        try {
            if (inspect(s) == ModelCheck.OK) { activate(s, deletePrevious = true); return DownloadOutcome.Success }
            if (freeBytes() < requiredFreeBytes(s)) {
                return DownloadOutcome.Failure(
                    "Espaço insuficiente. Libere pelo menos ${fmtBytes(requiredFreeBytes(s))}. " +
                        (if (activeSpec != null) "O modelo atual foi mantido." else ""),
                )
            }
            var existing = partLen(s)
            _state.value = ModelState.Downloading(existing, total)

            if (existing < total) {
                val conn = openWithRedirects(s.url, existing)
                try {
                    val code = conn.responseCode
                    when {
                        code == 206 -> {}
                        code == 200 -> { partOf(s).delete(); existing = 0L }   // servidor ignorou o Range: recomeça
                        code == 416 -> { partOf(s).delete(); return DownloadOutcome.Retry("Retomada recusada pelo servidor; recomeçando.") }
                        code in 500..599 -> return DownloadOutcome.Retry("Servidor indisponível (HTTP $code).")
                        else -> return DownloadOutcome.Failure("Servidor respondeu HTTP $code.")
                    }
                    withContext(Dispatchers.IO) {
                        coroutineScope {
                            // Ao pausar/cancelar, fecha a conexão para destravar a leitura bloqueada na hora.
                            val closer = launch { try { awaitCancellation() } finally { try { conn.disconnect() } catch (_: Exception) {} } }
                            try {
                                RandomAccessFile(partOf(s), "rw").use { raf ->
                                    raf.seek(existing)
                                    var done = existing
                                    val buf = ByteArray(256 * 1024)
                                    var lastEmit = 0L
                                    var speedT = System.currentTimeMillis()
                                    var speedB = existing
                                    conn.inputStream.use { input ->
                                        while (true) {
                                            if (!currentCoroutineContext().isActive) throw CancellationException("pausado")
                                            val n = input.read(buf)
                                            if (n < 0) break
                                            raf.write(buf, 0, n)
                                            done += n
                                            val now = System.currentTimeMillis()
                                            if (now - lastEmit > 300) {
                                                lastEmit = now
                                                if (now - speedT >= 1500) {
                                                    _speed.value = ((done - speedB) * 1000L / (now - speedT)).coerceAtLeast(0L)
                                                    speedT = now; speedB = done
                                                }
                                                _state.value = ModelState.Downloading(done, total)
                                                onProgress(done, total)
                                            }
                                        }
                                    }
                                }
                            } finally {
                                closer.cancel()
                            }
                        }
                    }
                } finally {
                    try { conn.disconnect() } catch (_: Exception) {}
                }
            }

            if (partLen(s) != total) {
                return DownloadOutcome.Retry("Download incompleto (${fmtBytes(partLen(s))} de ${fmtBytes(total)}).")
            }

            // ---- Validação antes de instalar (o modelo em uso continua intocado)
            _speed.value = 0L
            _state.value = ModelState.Verifying
            onProgress(total, total)
            val ok = withContext(Dispatchers.IO) {
                if (!hasGgufMagic(partOf(s))) false
                else s.sha256.isBlank() || sha256(partOf(s)).equals(s.sha256, ignoreCase = true)
            }
            if (!ok) {
                partOf(s).delete()
                return DownloadOutcome.Failure("A verificação de integridade falhou (arquivo corrompido). O download parcial foi apagado; tente de novo.")
            }
            fileOf(s).delete()
            if (!partOf(s).renameTo(fileOf(s))) {
                return DownloadOutcome.Failure("Não consegui instalar o arquivo no armazenamento privado.")
            }
            verified.remove(s.id)
            if (inspect(s) != ModelCheck.OK) {
                fileOf(s).delete()
                return DownloadOutcome.Failure("O arquivo instalado não passou na conferência final. Tente baixar de novo.")
            }
            // Só agora o novo vira o modelo em uso e o anterior pode ser removido (para liberar espaço).
            activate(s, deletePrevious = true)
            return DownloadOutcome.Success
        } catch (e: CancellationException) {
            onWorkerStopped()
            throw e
        } catch (e: Exception) {
            // Pausa pedida: fechar a conexão faz a leitura falhar com IOException; isso não é erro de rede.
            if (!currentCoroutineContext().isActive) {
                onWorkerStopped()
                throw CancellationException("pausado")
            }
            _speed.value = 0L
            val msg = e.message.orEmpty()
            return when {
                e is IOException && (msg.contains("ENOSPC") || msg.contains("No space left", ignoreCase = true)) ->
                    DownloadOutcome.Failure(
                        "O aparelho ficou sem espaço durante o download. O que já foi baixado foi mantido; libere espaço e toque em Tentar de novo." +
                            (if (activeSpec != null) " O modelo atual foi mantido." else ""),
                    )
                e is IOException -> DownloadOutcome.Retry(if (msg.isBlank()) "Falha de conexão." else msg)
                else -> DownloadOutcome.Failure(if (msg.isBlank()) "Falha inesperada no download." else msg)
            }
        }
    }

    internal fun markFailed(message: String) {
        val t = targetSpec
        LocalAiSettings.setDownloadWanted(app, false)
        LocalAiSettings.setDownloadError(app, message)
        _speed.value = 0L
        _state.value = ModelState.Failed(message, t?.let { partLen(it) } ?: 0L, t?.sizeBytes ?: 0L)
    }

    /** Segue redirecionamentos manualmente para manter o cabeçalho Range (o Hugging Face redireciona para um CDN). */
    private fun openWithRedirects(start: String, from: Long): HttpURLConnection {
        var url = start
        repeat(6) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", "GlucoCris/1.0 (Android)")
            if (from > 0) c.setRequestProperty("Range", "bytes=$from-")
            val code = c.responseCode
            if (code in intArrayOf(301, 302, 303, 307, 308)) {
                val loc = c.getHeaderField("Location") ?: throw IllegalStateException("Redirecionamento sem destino.")
                url = URL(URL(url), loc).toString()
                c.disconnect()
            } else {
                return c
            }
        }
        throw IllegalStateException("Redirecionamentos demais.")
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins ->
            val buf = ByteArray(1024 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    companion object {
        @Volatile private var inst: LocalModelManager? = null
        fun get(context: Context): LocalModelManager =
            inst ?: synchronized(this) { inst ?: LocalModelManager(context).also { inst = it } }

        fun fmtBytes(b: Long): String = when {
            b >= 1L shl 30 -> "%.2f GB".format(b / (1024.0 * 1024.0 * 1024.0))
            b >= 1L shl 20 -> "%.0f MB".format(b / (1024.0 * 1024.0))
            else -> "$b B"
        }
    }
}
