package com.agon.app.localai

import android.content.Context
import android.os.Build
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.Voice
import java.util.Locale

/**
 * Apoio à voz offline.
 * - Reconhecimento: usa o reconhecedor "no aparelho" do Android (API 33+) quando existir; a disponibilidade real
 *   do pacote pt-BR só é descoberta ao usar (o sistema devolve erro de idioma), então quem chama trata o erro.
 * - Fala: escolhe uma voz pt-BR que não exige rede, preferindo vozes marcadas como femininas quando o nome indica.
 * Vosk / whisper.cpp NÃO foram integrados nesta versão.
 */
object LocalSpeech {

    fun onDeviceRecognitionAvailable(context: Context): Boolean =
        Build.VERSION.SDK_INT >= 33 && try {
            SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        } catch (_: Exception) {
            false
        }

    /** Reconhecedor no aparelho (API 33+) ou null. */
    fun createOnDevice(context: Context): SpeechRecognizer? =
        if (Build.VERSION.SDK_INT >= 33 && onDeviceRecognitionAvailable(context)) {
            try { SpeechRecognizer.createOnDeviceSpeechRecognizer(context) } catch (_: Exception) { null }
        } else null

    /** Códigos de erro 12 e 13 = idioma não suportado / pacote de idioma indisponível (API 31+). */
    fun isLanguageError(error: Int): Boolean = error == 12 || error == 13

    /** Melhor voz pt-BR local disponível, ou null (mantém a voz padrão do TTS). */
    fun pickVoice(tts: TextToSpeech): Voice? = try {
        val ptbr = tts.voices.orEmpty().filter {
            it.locale.language.equals("pt", true) && it.locale.country.equals("BR", true) && !it.isNetworkConnectionRequired
        }
        ptbr.sortedByDescending { v ->
            val n = v.name.lowercase()
            var s = 0
            if ("female" in n || "-afs-" in n || "-ptd-" in n) s += 3
            if ("male" in n && "female" !in n) s -= 3
            if ("local" in n) s += 1
            if (v.quality >= Voice.QUALITY_HIGH) s += 1
            s
        }.firstOrNull()
    } catch (_: Exception) {
        null
    }

    fun ptBr(): Locale = Locale("pt", "BR")
}
