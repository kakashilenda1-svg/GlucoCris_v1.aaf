package com.agon.app.localai

import android.content.Context
import android.graphics.Bitmap
import com.agon.app.ui.screens.EXTRA_FOODS
import com.agon.app.ui.screens.loadTacoFoods
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.text.Normalizer
import kotlin.coroutines.resume

data class VisionResult(val text: String, val ocrText: String)

/**
 * Visão 100% no aparelho:
 * - OCR (ML Kit) para rótulos e texto
 * - Rótulos de imagem (ML Kit Image Labeling) para objetos/comida
 * - Modelo local (llama.cpp) interpreta em português no estilo Cris
 * - Se houver mmproj, também tenta envio nativo da imagem ao modelo
 */
object LocalVisionManager {

    private fun norm(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "").trim()

    suspend fun ocr(bitmap: Bitmap): String = suspendCancellableCoroutine { cont ->
        try {
            val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            rec.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { r -> rec.close(); if (cont.isActive) cont.resume(r.text.trim()) }
                .addOnFailureListener { rec.close(); if (cont.isActive) cont.resume("") }
        } catch (_: Exception) {
            if (cont.isActive) cont.resume("")
        }
    }

    /** Objetos / cenas detectados no aparelho (visão nativa ML Kit). */
    suspend fun labels(bitmap: Bitmap): List<String> = suspendCancellableCoroutine { cont ->
        try {
            val client = ImageLabeling.getClient(
                ImageLabelerOptions.Builder().setConfidenceThreshold(0.55f).build(),
            )
            client.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { list ->
                    client.close()
                    if (cont.isActive) {
                        cont.resume(
                            list.sortedByDescending { it.confidence }
                                .map { it.text.trim() }
                                .filter { it.isNotBlank() }
                                .distinct()
                                .take(12),
                        )
                    }
                }
                .addOnFailureListener {
                    client.close()
                    if (cont.isActive) cont.resume(emptyList())
                }
        } catch (_: Exception) {
            if (cont.isActive) cont.resume(emptyList())
        }
    }

    private fun saveTemp(context: Context, bmp: Bitmap): File {
        val f = File(context.cacheDir, "cris_vision_${System.currentTimeMillis()}.jpg")
        val scaled = if (maxOf(bmp.width, bmp.height) > 1280) {
            val k = 1280f / maxOf(bmp.width, bmp.height)
            Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * k).toInt().coerceAtLeast(1),
                (bmp.height * k).toInt().coerceAtLeast(1),
                true,
            )
        } else bmp
        FileOutputStream(f).use { scaled.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        return f
    }

    suspend fun analyze(
        context: Context,
        bitmap: Bitmap,
        question: String,
        systemBase: String,
        history: List<Pair<Boolean, String>>,
    ): VisionResult = withContext(Dispatchers.Default) {
        coroutineScope {
            val ocrDef = async { ocr(bitmap) }
            val labelsDef = async { labels(bitmap) }
            val ocrText = ocrDef.await()
            val labelList = labelsDef.await()
            val file = saveTemp(context, bitmap)
            try {
                val system = systemBase + """

Análise de foto (visão no aparelho):
- Use os rótulos detectados e o texto OCR abaixo como evidência do que aparece.
- Se a imagem estiver escura, tremida ou incerta, diga isso e peça outra foto.
- Se houver rótulo nutricional, use APENAS os números do OCR. Não invente números.
- Para pratos, não invente calorias/macros; marque porções como estimativa.
- Resposta objetiva: 2 a 5 frases.
- Termine com uma linha: ALIMENTOS: nome1, nome2 (ou ALIMENTOS: nenhum)
- Não indique dose de insulina.
""".trimIndent()

                val q = buildString {
                    append(question.ifBlank { "Analise esta foto e diga o que for relevante, de forma objetiva." })
                    if (labelList.isNotEmpty()) {
                        append("\n\nObjetos/cenas detectados no aparelho: ")
                        append(labelList.joinToString(", "))
                    }
                    if (ocrText.isNotBlank()) {
                        append("\n\nTexto lido na imagem (OCR, pode ter erros):\n")
                        append(ocrText.take(1500))
                    }
                    if (labelList.isEmpty() && ocrText.isBlank()) {
                        append("\n\n(Não houve detecção clara de objetos nem texto. Peça descrição ou outra foto se necessário.)")
                    }
                }

                val eng = LocalAiEngine.get(context)
                val raw = try {
                    eng.generate(system, history, q, imagePath = file.absolutePath)
                } catch (_: Exception) {
                    eng.generate(system, history, q, imagePath = null)
                }
                VisionResult(withNutritionBase(context, raw), ocrText)
            } finally {
                file.delete()
            }
        }
    }

    private fun withNutritionBase(context: Context, reply: String): String {
        val line = Regex("""(?im)^\s*ALIMENTOS:\s*(.+)$""").find(reply)
        val body = reply.replace(Regex("""(?im)^\s*ALIMENTOS:.*$"""), "").trim()
        val names = line?.groupValues?.get(1)?.split(',', ';')?.map { it.trim() }
            ?.filter { it.isNotBlank() && norm(it) != "nenhum" }?.take(6).orEmpty()
        if (names.isEmpty()) {
            return body.ifBlank { "Não consegui identificar bem a foto. Tente outra com mais luz." }
        }
        val taco = try { EXTRA_FOODS + loadTacoFoods(context) } catch (_: Exception) { emptyList() }
        val found = names.mapNotNull { n ->
            val k = norm(n)
            val hit = taco.filter { norm(it.name).contains(k) || k.contains(norm(it.name)) }
                .minByOrNull { it.name.length }
            hit?.let { n to it }
        }
        return buildString {
            append(body)
            if (found.isNotEmpty()) {
                append("\n\nValores do catálogo Gluco Cris (por 100 g ou pela porção indicada, não pela porção da foto):\n")
                found.forEach { (_, f) ->
                    append("• ${f.name}: ${f.kcal.toInt()} kcal, ${"%.1f".format(f.carbs)} g carb, ${"%.1f".format(f.protein)} g prot, ${"%.1f".format(f.fat)} g gord\n")
                }
            }
            val missing = names.filter { n -> found.none { it.first == n } }
            if (missing.isNotEmpty()) {
                append("\nSem correspondência no catálogo Gluco Cris: ${missing.joinToString(", ")}.")
            }
            append("\n\n(Estimativa no aparelho. Confira antes de registrar; não use para dose de insulina.)")
        }.trim()
    }
}
