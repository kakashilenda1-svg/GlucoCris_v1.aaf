package com.agon.app.localai

import android.app.ActivityManager
import android.content.Context
import android.os.Build
import android.os.StatFs
import java.io.File

/** Retrato do aparelho usado para recomendar o modelo de IA local mais estável. */
data class DeviceProfile(
    val totalRamBytes: Long,
    val availRamBytes: Long,
    val freeStorageBytes: Long,
    val abis: List<String>,
    val lowRamDevice: Boolean,
) {
    /** O motor llama.cpp do app traz bibliotecas nativas só para arm64-v8a e x86_64. */
    val engineCompatible: Boolean
        get() = abis.any { it == "arm64-v8a" || it == "x86_64" }
    val totalRamGb: Double get() = totalRamBytes / (1024.0 * 1024.0 * 1024.0)
}

/** Resultado da recomendação: modelo sugerido, motivo em linguagem simples e avisos. */
data class ModelAdvice(
    val recommended: LocalModelSpec,
    val reason: String,
    val warnings: List<String>,
    /** false = nem o modelo rápido deve rodar com segurança neste aparelho. */
    val canRunAny: Boolean,
)

/**
 * Escolhe o modelo mais estável para o aparelho (RAM, arquitetura, espaço livre).
 * É só uma RECOMENDAÇÃO: a usuária pode escolher manualmente Rápida ou Precisa.
 */
object ModelAdvisor {
    private const val GB = 1024L * 1024L * 1024L
    private const val MB = 1024L * 1024L

    fun profile(context: Context): DeviceProfile {
        val app = context.applicationContext
        val am = app.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
        val mi = ActivityManager.MemoryInfo()
        try { am?.getMemoryInfo(mi) } catch (_: Exception) {}
        val dir = File(app.noBackupFilesDir, "localai/models").apply { mkdirs() }
        val free = try { StatFs(dir.path).availableBytes } catch (_: Exception) { 0L }
        return DeviceProfile(
            totalRamBytes = mi.totalMem,
            availRamBytes = mi.availMem,
            freeStorageBytes = free,
            abis = Build.SUPPORTED_ABIS.toList(),
            lowRamDevice = try { am?.isLowRamDevice == true } catch (_: Exception) { false },
        )
    }

    /** RAM mínima (total do aparelho) sugerida para cada modelo. */
    private fun minTotalRam(m: LocalModelSpec): Long =
        if (m.id == LocalModels.QWEN25_3B.id) 6L * GB - 400L * MB else 3L * GB - 400L * MB

    /** Memória livre necessária para carregar o modelo (arquivo mapeado + contexto + folga). */
    private fun neededAvail(m: LocalModelSpec): Long =
        if (m.id == LocalModels.QWEN25_3B.id) 2_600L * MB else 1_500L * MB

    fun canRun(p: DeviceProfile, m: LocalModelSpec): Boolean =
        p.engineCompatible && !p.lowRamDevice && p.totalRamBytes >= minTotalRam(m)

    fun advise(context: Context): ModelAdvice = advise(profile(context))

    fun advise(p: DeviceProfile): ModelAdvice {
        val warnings = mutableListOf<String>()
        if (!p.engineCompatible) {
            warnings += "O processador deste aparelho (${p.abis.firstOrNull() ?: "desconhecido"}) não é compatível com o motor da IA local."
            return ModelAdvice(LocalModels.QWEN25_1_5B, "Sem compatibilidade com a IA local; a Cris usa respostas básicas e pesquisa online.", warnings, false)
        }
        val ramText = "%.1f GB".format(p.totalRamGb)
        val canPrecise = canRun(p, LocalModels.QWEN25_3B) && p.availRamBytes >= neededAvail(LocalModels.QWEN25_3B)
        val canFast = canRun(p, LocalModels.QWEN25_1_5B)
        if (p.freeStorageBytes in 1 until (LocalModels.QWEN25_1_5B.sizeBytes + 400L * MB)) {
            warnings += "Pouco espaço livre (${LocalModelManager.fmtBytes(p.freeStorageBytes)}). Libere espaço antes de baixar."
        }
        return when {
            canPrecise -> ModelAdvice(
                LocalModels.QWEN25_3B,
                "Seu aparelho tem $ramText de memória: aguenta a opção Precisa com folga.",
                warnings, true,
            )
            canFast -> {
                if (p.totalRamBytes >= minTotalRam(LocalModels.QWEN25_3B)) {
                    warnings += "Há pouca memória livre agora. Feche outros apps se quiser usar a opção Precisa."
                }
                ModelAdvice(
                    LocalModels.QWEN25_1_5B,
                    "Seu aparelho tem $ramText de memória: a opção Rápida é a mais estável e não trava.",
                    warnings, true,
                )
            }
            else -> {
                warnings += "Este aparelho tem pouca memória ($ramText). A IA local pode travar ou fechar o app."
                ModelAdvice(LocalModels.QWEN25_1_5B, "Mesmo a opção Rápida pode ficar pesada aqui.", warnings, false)
            }
        }
    }

    /** Aviso específico ao escolher manualmente um modelo (null = tudo certo). */
    fun manualWarning(context: Context, m: LocalModelSpec): String? {
        val p = profile(context)
        if (!p.engineCompatible) return "Este processador não é compatível com a IA local."
        if (!canRun(p, m)) {
            return "Este aparelho tem pouca memória para a opção ${m.displayName.substringBefore('·').trim()}. " +
                "Ela pode ficar lenta ou fechar o app. A opção Rápida é mais segura."
        }
        if (p.availRamBytes < neededAvail(m)) {
            return "No momento há pouca memória livre. Feche outros apps antes de usar essa opção."
        }
        return null
    }

    const val EXPLAIN_FAST =
        "Rápida (1,5B, ~1 GB): responde mais depressa, gasta menos memória e bateria. Ótima para o dia a dia."
    const val EXPLAIN_PRECISE =
        "Precisa (3B, ~2 GB): responde com mais qualidade em perguntas difíceis, mas é mais lenta e exige aparelho com mais memória."
}
