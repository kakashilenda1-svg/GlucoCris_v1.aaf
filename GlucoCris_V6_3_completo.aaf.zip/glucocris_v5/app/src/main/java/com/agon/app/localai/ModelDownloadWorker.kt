package com.agon.app.localai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.BackoffPolicy
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.ForegroundInfo
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.OutOfQuotaPolicy
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.agon.app.MainActivity
import com.agon.app.R
import java.util.concurrent.TimeUnit

/**
 * Agenda/cancela o download do modelo no WorkManager. Um único trabalho único ("unique work"): continua com o app
 * fechado ou a tela apagada, sobrevive a reinício do aparelho e só roda com rede (Wi-Fi, a menos que a pessoa
 * tenha autorizado dados móveis).
 */
object ModelDownloadScheduler {
    const val UNIQUE = "cris_model_download"

    fun enqueue(context: Context, allowMetered: Boolean) {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(if (allowMetered) NetworkType.CONNECTED else NetworkType.UNMETERED)
            .build()
        val req = OneTimeWorkRequestBuilder<ModelDownloadWorker>()
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
            // Expedited: pode iniciar o serviço em primeiro plano mesmo com o app em segundo plano (Android 12+).
            // Sem cota, roda como trabalho normal (a notificação continua via setForeground).
            .setExpedited(OutOfQuotaPolicy.RUN_AS_NON_EXPEDITED_WORK_REQUEST)
            .addTag(UNIQUE)
            .build()
        WorkManager.getInstance(context.applicationContext).enqueueUniqueWork(UNIQUE, ExistingWorkPolicy.REPLACE, req)
    }

    fun cancel(context: Context) {
        try { WorkManager.getInstance(context.applicationContext).cancelUniqueWork(UNIQUE) } catch (_: Exception) {}
        ModelDownloadNotifications.clearOngoing(context)
    }
}

class ModelDownloadWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun getForegroundInfo(): ForegroundInfo =
        ModelDownloadNotifications.foreground(applicationContext, "Preparando o download…", 0, 0, true)

    override suspend fun doWork(): Result {
        val ctx = applicationContext
        val mgr = LocalModelManager.get(ctx)
        if (!LocalAiSettings.downloadWanted(ctx) || mgr.targetSpec == null) return Result.success()

        // Notificação persistente. Se o Android negar o serviço em primeiro plano, segue sem ela; o parcial é mantido e retomado.
        try { setForeground(getForegroundInfo()) } catch (_: Exception) {}
        ModelDownloadNotifications.clearPaused(ctx)

        var lastKey = -1
        val outcome = mgr.downloadTarget { done, total ->
            val pct = if (total > 0) (done * 100 / total).toInt() else 0
            val sp = mgr.speedBytesPerSec.value
            val key = pct * 1000 + (sp / (256 * 1024)).toInt().coerceAtMost(999)
            if (key != lastKey) {
                lastKey = key
                val speedTxt = if (sp > 0) " · " + LocalModelManager.fmtBytes(sp) + "/s" else ""
                val text = LocalModelManager.fmtBytes(done) + " de " + LocalModelManager.fmtBytes(total) + " ($pct%)" + speedTxt
                try { setForeground(ModelDownloadNotifications.foreground(ctx, text, pct, 100, false)) } catch (_: Exception) {}
            }
        }
        return when (outcome) {
            DownloadOutcome.Success -> {
                ModelDownloadNotifications.done(ctx, "A IA da Cris está pronta! 💜")
                Result.success()
            }
            is DownloadOutcome.Retry -> {
                if (runAttemptCount >= MAX_ATTEMPTS) {
                    val msg = outcome.message + " O que já foi baixado foi mantido; abra o app e toque em Tentar de novo."
                    mgr.markFailed(msg)
                    ModelDownloadNotifications.done(ctx, "Download interrompido. Abra o app para continuar.")
                    Result.failure()
                } else {
                    mgr.onWorkerWaiting("Reconectando… (${outcome.message})")
                    Result.retry()
                }
            }
            is DownloadOutcome.Failure -> {
                mgr.markFailed(outcome.message)
                ModelDownloadNotifications.done(ctx, "Download interrompido. Abra o app para ver o motivo.")
                Result.failure()
            }
        }
    }

    companion object { private const val MAX_ATTEMPTS = 8 }
}

/** Botões Pausar / Continuar / Cancelar da notificação. */
class ModelDownloadActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val mgr = LocalModelManager.get(context)
        when (intent.action) {
            ACTION_PAUSE -> { mgr.pause(); ModelDownloadNotifications.paused(context) }
            ACTION_RESUME -> { ModelDownloadNotifications.clearPaused(context); mgr.start() }
            ACTION_CANCEL -> { mgr.cancel(); ModelDownloadNotifications.clearPaused(context) }
        }
    }

    companion object {
        const val ACTION_PAUSE = "com.agon.app.localai.PAUSE_DOWNLOAD"
        const val ACTION_RESUME = "com.agon.app.localai.RESUME_DOWNLOAD"
        const val ACTION_CANCEL = "com.agon.app.localai.CANCEL_DOWNLOAD"
    }
}

internal object ModelDownloadNotifications {
    private const val CHANNEL = "cris_ai_download"
    const val ONGOING_ID = 4711
    private const val DONE_ID = 4712
    private const val PAUSED_ID = 4713

    private fun nm(c: Context) = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

    private fun ensureChannel(c: Context) {
        if (Build.VERSION.SDK_INT >= 26 && nm(c).getNotificationChannel(CHANNEL) == null) {
            nm(c).createNotificationChannel(NotificationChannel(CHANNEL, "Download da IA da Cris", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun openApp(c: Context): PendingIntent =
        PendingIntent.getActivity(
            c, 0,
            Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun action(c: Context, code: Int, act: String): PendingIntent =
        PendingIntent.getBroadcast(
            c, code,
            Intent(c, ModelDownloadActionReceiver::class.java).setAction(act).setPackage(c.packageName),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    fun foreground(c: Context, text: String, progress: Int, max: Int, indeterminate: Boolean): ForegroundInfo {
        ensureChannel(c)
        val n: Notification = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_drop)
            .setContentTitle("Baixando a IA da Cris")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(max, progress, indeterminate)
            .setContentIntent(openApp(c))
            .addAction(0, "Pausar", action(c, 1, ModelDownloadActionReceiver.ACTION_PAUSE))
            .addAction(0, "Cancelar", action(c, 2, ModelDownloadActionReceiver.ACTION_CANCEL))
            .build()
        return if (Build.VERSION.SDK_INT >= 29) ForegroundInfo(ONGOING_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        else ForegroundInfo(ONGOING_ID, n)
    }

    fun paused(c: Context) {
        ensureChannel(c)
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_drop)
            .setContentTitle("Download da IA da Cris pausado")
            .setContentText("Toque em Continuar para retomar de onde parou.")
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp(c))
            .addAction(0, "Continuar", action(c, 3, ModelDownloadActionReceiver.ACTION_RESUME))
            .addAction(0, "Cancelar", action(c, 2, ModelDownloadActionReceiver.ACTION_CANCEL))
            .build()
        try { nm(c).notify(PAUSED_ID, n) } catch (_: Exception) {}
    }

    fun done(c: Context, message: String) {
        ensureChannel(c)
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_drop)
            .setContentTitle("IA da Cris")
            .setContentText(message)
            .setAutoCancel(true)
            .setContentIntent(openApp(c))
            .build()
        try { nm(c).notify(DONE_ID, n) } catch (_: Exception) {}
    }

    fun clearOngoing(c: Context) { try { nm(c).cancel(ONGOING_ID) } catch (_: Exception) {} }
    fun clearPaused(c: Context) { try { nm(c).cancel(PAUSED_ID) } catch (_: Exception) {} }
}
