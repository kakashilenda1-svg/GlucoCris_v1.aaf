package com.agon.app.localai

import android.content.Context
import com.agon.app.BuildConfig

/**
 * Decide, na abertura do app, se a pessoa deve ver a tela de escolha do modelo de IA local:
 *  - instalação nova;
 *  - atualização de versão antiga sem modelo, com modelo corrompido/incompleto ou incompatível com o aparelho;
 *  - atualização com modelo compatível: oferta única de "manter ou trocar" (nada é baixado de novo sem a pessoa querer).
 */
object ModelGate {
    enum class LaunchKind { FRESH, UPGRADE, NORMAL }

    enum class Reason { NO_MODEL, DAMAGED, INCOMPATIBLE }

    sealed interface Decision {
        data object None : Decision
        /** Mostrar a tela de escolha. [mandatory] = instalação nova em aparelho capaz: só sai com o modelo pronto (ou se falhar/sem internet). */
        data class NeedModel(val reason: Reason, val mandatory: Boolean) : Decision
        /** Já tem um modelo compatível: perguntar uma vez se quer manter ou trocar. */
        data class KeepOrChange(val active: LocalModelSpec) : Decision
    }

    /**
     * Classifica a abertura. Deve ser chamada uma vez por processo, ANTES de gravar a versão atual.
     * Instalação nova = nunca gravou versão e ainda não há conta Google. Versões anteriores à 1.25 não gravavam a versão:
     * quem tem conta e versão 0 é atualização.
     */
    fun classifyLaunch(context: Context, hasAccount: Boolean): LaunchKind {
        val last = LocalAiSettings.lastRunVersionCode(context)
        val now = BuildConfig.VERSION_CODE
        return when {
            last == 0 && !hasAccount -> LaunchKind.FRESH
            last < now -> LaunchKind.UPGRADE
            else -> LaunchKind.NORMAL
        }
    }

    fun markLaunched(context: Context) = LocalAiSettings.setLastRunVersionCode(context, BuildConfig.VERSION_CODE)

    /** Modelo compatível = o motor roda neste processador e a memória comporta o modelo (o mais leve é sempre aceito: não há opção menor). */
    fun isCompatible(context: Context, spec: LocalModelSpec): Boolean {
        val p = ModelAdvisor.profile(context)
        return p.engineCompatible && (ModelAdvisor.canRun(p, spec) || spec.id == LocalModels.LIGHT.id)
    }

    fun evaluate(context: Context, kind: LaunchKind): Decision {
        val app = context.applicationContext
        val p = ModelAdvisor.profile(app)
        if (!p.engineCompatible) return Decision.None           // sem motor compatível: nada para escolher
        val mgr = LocalModelManager.get(app)
        mgr.refresh()
        val v = BuildConfig.VERSION_CODE

        val st = mgr.state.value
        val busy = st is ModelState.Downloading || st is ModelState.Waiting || st is ModelState.Verifying
        val active = mgr.activeSpec
        val compatibleActive = active?.takeIf { isCompatible(app, it) }

        if (compatibleActive != null) {
            if (kind != LaunchKind.UPGRADE || busy) return Decision.None
            if (LocalAiSettings.keepOrChangeSeenVersion(app) >= v) return Decision.None
            // Só vale perguntar se existe outra opção que o aparelho aguenta.
            val hasAlternative = LocalModels.ALL.any { it.id != compatibleActive.id && isCompatible(app, it) }
            return if (hasAlternative) Decision.KeepOrChange(compatibleActive) else Decision.None
        }

        // Sem modelo compatível instalado.
        if (busy && kind != LaunchKind.FRESH) return Decision.None   // já tem download andando: a pessoa acompanha na notificação/configurações
        val dismissed = LocalAiSettings.chooserDismissedVersion(app) >= v
        if (dismissed && kind != LaunchKind.FRESH) return Decision.None
        val reason = when {
            active != null -> Reason.INCOMPATIBLE
            mgr.damagedSpecs().isNotEmpty() -> Reason.DAMAGED
            else -> Reason.NO_MODEL
        }
        val mandatory = kind == LaunchKind.FRESH && !dismissed && deviceMeetsRequiredAiRam(app)
        return Decision.NeedModel(reason, mandatory)
    }

    /** Só aparelhos com bastante RAM são obrigados (instalação nova) a baixar a IA antes de entrar; os demais podem pular. */
    private const val MIN_RAM_FOR_REQUIRED_AI = 5_000_000_000L
    fun deviceMeetsRequiredAiRam(context: Context): Boolean = try {
        ModelAdvisor.profile(context).totalRamBytes >= MIN_RAM_FOR_REQUIRED_AI
    } catch (_: Exception) {
        true
    }
}
