package com.agon.app.localai

import android.content.Context
import com.agon.app.cloud.CloudBackup
import com.agon.app.cloud.CloudState
import com.agon.app.data.CrisGemini
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.HttpURLConnection
import java.net.URL

/**
 * Verificações reais e independentes dos serviços da Cris (V6.1).
 * Cada probe tem timeout próprio, não bloqueia a UI e evita chamadas repetidas em rajada.
 * Não expõe chaves, tokens nem dados de saúde.
 */
object ServiceProbe {
    enum class Kind { GEMINI, TAVILY, WORKER, LOCAL_AI, INTERNET, BACKUP }

    data class Result(
        val kind: Kind,
        val state: ServiceState,
        val message: String,
        val latencyMs: Long? = null,
        val lastError: String? = null,
        val checkedAt: Long = System.currentTimeMillis(),
        val lastOkAt: Long? = null,
    )

    private val mutex = Mutex()
    private var lastRunAt = 0L
    private const val MIN_INTERVAL_MS = 4_000L
    private const val TIMEOUT_MS = 12_000L

    /** Resultado da última verificação manual (para a tela de diagnóstico). */
    @Volatile
    var lastResults: Map<Kind, Result> = emptyMap()
        private set

    /**
     * Executa probes reais em paralelo (com timeout individual).
     * Se chamada em menos de [MIN_INTERVAL_MS], devolve o último resultado.
     */
    suspend fun runAll(context: Context, force: Boolean = false): Map<Kind, Result> = mutex.withLock {
        val now = System.currentTimeMillis()
        if (!force && lastResults.isNotEmpty() && now - lastRunAt < MIN_INTERVAL_MS) {
            return@withLock lastResults
        }
        lastRunAt = now
        val app = context.applicationContext
        val results = coroutineScope {
            val internet = async { probeInternet(app) }
            val worker = async { probeWorker(app) }
            val gemini = async { probeGemini(app) }
            val tavily = async { probeTavily(app) }
            val local = async { probeLocalAi(app) }
            val backup = async { probeBackup(app) }
            listOf(internet.await(), worker.await(), gemini.await(), tavily.await(), local.await(), backup.await())
        }
        // Atualiza o health compartilhado com evidências reais
        results.forEach { r ->
            when (r.kind) {
                Kind.GEMINI -> CrisServiceHealth.gemini(r.state, r.checkedAt)
                Kind.TAVILY -> CrisServiceHealth.tavily(r.state, r.checkedAt)
                Kind.WORKER -> CrisServiceHealth.worker(r.state, r.checkedAt)
                Kind.LOCAL_AI -> CrisServiceHealth.local(r.state != ServiceState.OK, r.checkedAt)
                else -> Unit
            }
        }
        lastResults = results.associateBy { it.kind }
        lastResults
    }

    private suspend fun probeInternet(ctx: Context): Result = withContext(Dispatchers.IO) {
        val t0 = System.currentTimeMillis()
        val online = CrisConnectivityManager.isOnline(ctx)
        val lat = System.currentTimeMillis() - t0
        if (online) {
            Result(Kind.INTERNET, ServiceState.OK, "Internet disponível", lat, checkedAt = System.currentTimeMillis(), lastOkAt = System.currentTimeMillis())
        } else {
            Result(Kind.INTERNET, ServiceState.UNAVAILABLE, "Sem conexão com a internet", lat, lastError = "offline")
        }
    }

    private suspend fun probeWorker(ctx: Context): Result = withContext(Dispatchers.IO) {
        val url = com.agon.app.BuildConfig.TAVILY_PROXY_URL.trim()
        if (url.isBlank()) {
            return@withContext Result(Kind.WORKER, ServiceState.NOT_CONFIGURED, "Proxy do Worker não configurado")
        }
        val t0 = System.currentTimeMillis()
        val outcome = withTimeoutOrNull(TIMEOUT_MS) {
            try {
                // HEAD no endpoint base (ou GET leve) — não gasta cota de pesquisa/Gemini
                val u = URL(if (url.endsWith("/")) url else "$url/")
                val conn = (u.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 8_000
                    readTimeout = 8_000
                    instanceFollowRedirects = true
                    setRequestProperty("User-Agent", "GlucoCris-Diagnosis/6.1")
                }
                val code = try {
                    conn.responseCode
                } finally {
                    conn.disconnect()
                }
                val lat = System.currentTimeMillis() - t0
                when {
                    code in 200..499 -> Result(Kind.WORKER, ServiceState.OK, "Worker respondeu (HTTP $code)", lat, lastOkAt = System.currentTimeMillis())
                    code >= 500 -> Result(Kind.WORKER, ServiceState.UNAVAILABLE, "Worker com falha (HTTP $code)", lat, lastError = "HTTP $code")
                    else -> Result(Kind.WORKER, ServiceState.UNAVAILABLE, "Worker respondeu de forma inesperada (HTTP $code)", lat, lastError = "HTTP $code")
                }
            } catch (e: Exception) {
                val lat = System.currentTimeMillis() - t0
                Result(Kind.WORKER, ServiceState.UNAVAILABLE, "Não foi possível contatar o Worker", lat, lastError = e.message?.take(80))
            }
        }
        outcome ?: Result(Kind.WORKER, ServiceState.UNAVAILABLE, "Timeout ao contatar o Worker", TIMEOUT_MS, lastError = "timeout")
    }

    private suspend fun probeGemini(ctx: Context): Result = withContext(Dispatchers.IO) {
        if (!CrisGemini.isConfigured()) {
            return@withContext Result(Kind.GEMINI, ServiceState.NOT_CONFIGURED, "Proxy Gemini não configurado")
        }
        val t0 = System.currentTimeMillis()
        val outcome = withTimeoutOrNull(TIMEOUT_MS) {
            try {
                val (ok, msg) = CrisGemini.ping()
                val lat = System.currentTimeMillis() - t0
                when {
                    ok -> Result(Kind.GEMINI, ServiceState.OK, msg, lat, lastOkAt = System.currentTimeMillis())
                    "429" in msg || "cota" in msg.lowercase() ->
                        Result(Kind.GEMINI, ServiceState.QUOTA, msg, lat, lastError = msg)
                    "401" in msg || "token" in msg.lowercase() || "recusado" in msg.lowercase() ->
                        Result(Kind.GEMINI, ServiceState.UNAVAILABLE, "Erro de autenticação no proxy", lat, lastError = msg)
                    "não está configurada" in msg || "not_configured" in msg.lowercase() ->
                        Result(Kind.GEMINI, ServiceState.NOT_CONFIGURED, msg, lat, lastError = msg)
                    else -> Result(Kind.GEMINI, ServiceState.UNAVAILABLE, msg, lat, lastError = msg)
                }
            } catch (e: Exception) {
                val lat = System.currentTimeMillis() - t0
                Result(Kind.GEMINI, ServiceState.UNAVAILABLE, "Falha ao verificar Gemini", lat, lastError = e.message?.take(80))
            }
        }
        outcome ?: Result(Kind.GEMINI, ServiceState.UNAVAILABLE, "Timeout ao verificar Gemini", TIMEOUT_MS, lastError = "timeout")
    }

    private suspend fun probeTavily(ctx: Context): Result = withContext(Dispatchers.IO) {
        if (!TavilySearch.isConfigured()) {
            return@withContext Result(Kind.TAVILY, ServiceState.NOT_CONFIGURED, "Proxy Tavily não configurado")
        }
        // Verificação leve: o mesmo endpoint do Worker já foi testado; aqui só confirma configuração
        // e se a última evidência de uso (CrisServiceHealth) indica cota/erro.
        val h = CrisServiceHealth.state.value
        val now = System.currentTimeMillis()
        val fresh = h.tavilyAt > 0L && now - h.tavilyAt <= CrisServiceHealth.FRESH_MS
        when {
            fresh && h.tavily == ServiceState.QUOTA ->
                Result(Kind.TAVILY, ServiceState.QUOTA, "Limite de utilização da busca atingido (evidência recente)", lastError = "quota")
            fresh && h.tavily == ServiceState.UNAVAILABLE ->
                Result(Kind.TAVILY, ServiceState.UNAVAILABLE, "Busca indisponível na última tentativa", lastError = "unavailable")
            fresh && h.tavily == ServiceState.OK ->
                Result(Kind.TAVILY, ServiceState.OK, "Busca funcionou recentemente", lastOkAt = h.tavilyAt)
            else ->
                // Worker OK implica caminho de Tavily disponível; não dispara pesquisa completa
                Result(Kind.TAVILY, ServiceState.OK, "Proxy configurado (sem pesquisa completa para poupar cota)")
        }
    }

    private suspend fun probeLocalAi(ctx: Context): Result = withContext(Dispatchers.IO) {
        try {
            val mgr = LocalModelManager.get(ctx)
            val installed = mgr.installedSpecs()
            if (installed.isEmpty()) {
                Result(Kind.LOCAL_AI, ServiceState.NOT_CONFIGURED, "Nenhum modelo de IA local instalado")
            } else {
                val active = installed.first()
                val check = mgr.inspect(active)
                if (check == ModelCheck.OK) {
                    Result(Kind.LOCAL_AI, ServiceState.OK, "Modelo local instalado e íntegro (${active.id})", lastOkAt = System.currentTimeMillis())
                } else {
                    Result(Kind.LOCAL_AI, ServiceState.UNAVAILABLE, "Modelo local presente mas danificado/incompleto", lastError = check.name)
                }
            }
        } catch (e: Exception) {
            Result(Kind.LOCAL_AI, ServiceState.UNAVAILABLE, "Não foi possível verificar a IA local", lastError = e.message?.take(80))
        }
    }

    private suspend fun probeBackup(ctx: Context): Result = withContext(Dispatchers.IO) {
        try {
            val cloud = CloudBackup(ctx)
            val status = cloud.initialStatus()
            when (status.state) {
                CloudState.OK -> Result(Kind.BACKUP, ServiceState.OK, status.message.ifBlank { "Sincronização em dia" }, lastOkAt = status.lastSyncAt)
                CloudState.SYNCING -> Result(Kind.BACKUP, ServiceState.OK, "Sincronizando agora…")
                CloudState.IDLE -> Result(Kind.BACKUP, ServiceState.OK, status.message.ifBlank { "Backup ativo" }, lastOkAt = status.lastSyncAt)
                CloudState.OFFLINE -> Result(Kind.BACKUP, ServiceState.UNAVAILABLE, "Sem internet para sincronizar", lastError = "offline")
                CloudState.QUOTA -> Result(Kind.BACKUP, ServiceState.QUOTA, "Limite do Firebase atingido", lastError = "quota")
                CloudState.SIGNED_OUT -> Result(Kind.BACKUP, ServiceState.NOT_CONFIGURED, "Conta não conectada")
                CloudState.EMAIL_UNVERIFIED -> Result(Kind.BACKUP, ServiceState.UNAVAILABLE, "E-mail da conta não verificado", lastError = "email")
                CloudState.ACCOUNT_MISMATCH -> Result(Kind.BACKUP, ServiceState.UNAVAILABLE, "Conta incompatível com os dados locais", lastError = "mismatch")
                CloudState.ERROR -> Result(Kind.BACKUP, ServiceState.UNAVAILABLE, status.message.ifBlank { "Erro na sincronização" }, lastError = status.message)
            }
        } catch (e: Exception) {
            Result(Kind.BACKUP, ServiceState.UNAVAILABLE, "Não foi possível consultar o backup", lastError = e.message?.take(80))
        }
    }
}
