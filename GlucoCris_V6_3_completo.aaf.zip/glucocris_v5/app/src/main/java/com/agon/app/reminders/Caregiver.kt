package com.agon.app.reminders

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.agon.app.MainActivity
import com.agon.app.R
import com.agon.app.data.AppData
import com.agon.app.data.formatTime
import com.agon.app.insights.Insights
import kotlin.math.roundToInt

/**
 * Modo cuidador / família.
 * Um contato de confiança pode receber, COM A PERMISSÃO da pessoa, o aviso de glicemia muito baixa ou muito alta
 * e o resumo do dia. O envio é feito pelo SMS ou WhatsApp do próprio aparelho: o app prepara a mensagem
 * e a pessoa toca em enviar. Nada é enviado escondido e nenhum servidor recebe esses dados.
 */
object Caregiver {
    private const val PREFS = "gluco_caregiver_v1"
    const val CHANNEL = "gluco_cuidador_v1"
    private const val NOTIF_ID = 7731

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun consent(ctx: Context) = sp(ctx).getBoolean("consent", false)
    fun setConsent(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("consent", v).apply()

    fun name(ctx: Context) = sp(ctx).getString("name", "") ?: ""
    fun setName(ctx: Context, v: String) = sp(ctx).edit().putString("name", v.trim()).apply()

    /** Telefone só com dígitos, com DDI (ex.: 5511999998888). */
    fun phone(ctx: Context) = sp(ctx).getString("phone", "") ?: ""
    fun setPhone(ctx: Context, v: String) = sp(ctx).edit().putString("phone", v.filter { it.isDigit() }).apply()

    fun alertsOn(ctx: Context) = sp(ctx).getBoolean("alerts_on", true)
    fun setAlertsOn(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("alerts_on", v).apply()

    fun summaryAllowed(ctx: Context) = sp(ctx).getBoolean("summary_on", true)
    fun setSummaryAllowed(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("summary_on", v).apply()

    /** Limite de glicemia grave baixa (mg/dL). */
    fun severeLow(ctx: Context) = sp(ctx).getInt("severe_low", 54).coerceIn(30, 70)
    fun setSevereLow(ctx: Context, v: Int) = sp(ctx).edit().putInt("severe_low", v.coerceIn(30, 70)).apply()

    /** Limite de glicemia grave alta (mg/dL). */
    fun severeHigh(ctx: Context) = sp(ctx).getInt("severe_high", 300).coerceIn(200, 500)
    fun setSevereHigh(ctx: Context, v: Int) = sp(ctx).edit().putInt("severe_high", v.coerceIn(200, 500)).apply()

    /** Canal preferido: "sms" ou "whatsapp". */
    fun channel(ctx: Context) = sp(ctx).getString("channel", "sms") ?: "sms"
    fun setChannel(ctx: Context, v: String) = sp(ctx).edit().putString("channel", v).apply()

    fun ready(ctx: Context) = consent(ctx) && phone(ctx).length >= 8

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Aviso ao cuidador", NotificationManager.IMPORTANCE_HIGH)
        ch.description = "Quando a glicemia fica muito baixa ou muito alta, deixa pronta a mensagem para seu contato de confiança."
        nm.createNotificationChannel(ch)
    }

    fun smsIntent(phone: String, body: String): Intent =
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone")).putExtra("sms_body", body).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun whatsappIntent(phone: String, body: String): Intent =
        Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$phone?text=" + Uri.encode(body))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    fun sendIntent(ctx: Context, body: String): Intent =
        if (channel(ctx) == "whatsapp") whatsappIntent(phone(ctx), body) else smsIntent(phone(ctx), body)

    fun alertText(person: String, mg: Double, at: Long, low: Boolean): String =
        "Aviso do Gluco Cris: a glicemia de $person está ${if (low) "MUITO BAIXA" else "MUITO ALTA"} (${mg.roundToInt()} mg/dL, às ${formatTime(at)}). " +
            "Por favor, entre em contato e ajude a seguir o plano indicado pela equipe de saúde. Em emergência, ligue 192 (SAMU)."

    fun dailySummaryText(ctx: Context, data: AppData, now: Long = System.currentTimeMillis()): String {
        val s = data.settings
        val dayStart = java.util.Calendar.getInstance().apply {
            timeInMillis = now
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis
        val today = Insights.readingsBetween(data, dayStart, now)
        val st = Insights.stats(today, s.targetLow, s.targetHigh)
        val last = today.lastOrNull()
        val meals = data.meals.count { !it.id.startsWith("demo-") && it.at >= dayStart }
        val sb = StringBuilder("Resumo do dia de ${s.displayName} (Gluco Cris):\n")
        if (st == null) sb.append("• Nenhuma glicemia registrada hoje.\n")
        else {
            sb.append("• ${st.count} medições, média ${st.mean.roundToInt()} mg/dL (mín ${st.min.roundToInt()}, máx ${st.max.roundToInt()}).\n")
            sb.append("• ${st.inRangePct.roundToInt()}% na meta (${s.targetLow}–${s.targetHigh}).\n")
            last?.let { sb.append("• Última: ${it.mg.roundToInt()} mg/dL às ${formatTime(it.at)}.\n") }
        }
        if (meals > 0) sb.append("• $meals refeição(ões) registrada(s).\n")
        sb.append("Enviado com a permissão de ${s.displayName}.")
        return sb.toString()
    }

    /**
     * Chamado a cada nova glicemia (digitada, atalho ou sensor). Se passar do limite grave, mostra uma notificação
     * que abre a mensagem pronta para o contato. Cada leitura grave avisa uma vez e há um intervalo mínimo de 30 min.
     */
    fun onNewGlucose(ctx: Context, mg: Double, at: Long, person: String = "") {
        val app = ctx.applicationContext
        if (!ready(app) || !alertsOn(app)) return
        val now = System.currentTimeMillis()
        if (now - at > 20 * 60_000L) return // leitura antiga (importação): não avisa
        val low = mg < severeLow(app)
        val high = mg > severeHigh(app)
        if (!low && !high) return
        val state = sp(app)
        if (now - state.getLong("last_alert_at", 0L) < 30 * 60_000L) return
        state.edit().putLong("last_alert_at", now).apply()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(app, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) return
        try {
            ensureChannel(app)
            val who = person.ifBlank { "quem usa o app" }
            val body = alertText(who, mg, at, low)
            val send = PendingIntent.getActivity(app, NOTIF_ID, sendIntent(app, body), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            val open = PendingIntent.getActivity(
                app, NOTIF_ID + 1,
                Intent(app, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP },
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val contact = name(app).ifBlank { "seu contato" }
            val text = "Glicemia ${if (low) "muito baixa" else "muito alta"}: ${mg.roundToInt()} mg/dL. Toque para avisar $contact."
            val n = NotificationCompat.Builder(app, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_drop)
                .setContentTitle("Avisar o cuidador?")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setColor(0xFFDC2626.toInt())
                .setAutoCancel(true)
                .setContentIntent(send)
                .addAction(0, "Avisar $contact", send)
                .addAction(0, "Abrir app", open)
                .build()
            NotificationManagerCompat.from(app).notify(NOTIF_ID, n)
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }
}
