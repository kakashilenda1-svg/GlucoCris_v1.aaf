package com.agon.app.reminders

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.agon.app.MainActivity
import com.agon.app.R
import com.agon.app.data.AppData
import com.agon.app.data.GlucoStorage
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.formatTime
import com.agon.app.data.toMgDl
import java.util.Calendar
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

/**
 * Alertas ligados aos valores medidos (a tela de Lembretes só avisa horários):
 * - glicemia baixa há X horas sem nova medida;
 * - glicemia alta há X horas sem nova medida (desligado por padrão);
 * - sem medir hoje (a partir de uma hora escolhida).
 * Cada situação avisa uma vez (por medição / por dia). Os registros de exemplo ("demo-") nunca geram alerta.
 */
object GlucoseAlerts {
    private const val PREFS = "gluco_alerts_v1"
    const val CHANNEL = "gluco_alertas_v1"
    private const val NOTIF_LOW = 7711
    private const val NOTIF_HIGH = 7712
    private const val NOTIF_MISS = 7713
    private const val STALE_MS = 12L * 3_600_000L // medição mais antiga que isso não gera alerta de "ainda baixa/alta"

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun lowOn(ctx: Context) = sp(ctx).getBoolean("low_on", true)
    fun setLowOn(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("low_on", v).apply()
    fun lowHours(ctx: Context) = sp(ctx).getInt("low_hours", 1).coerceIn(1, 6)
    fun setLowHours(ctx: Context, v: Int) = sp(ctx).edit().putInt("low_hours", v.coerceIn(1, 6)).apply()

    fun highOn(ctx: Context) = sp(ctx).getBoolean("high_on", false)
    fun setHighOn(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("high_on", v).apply()
    fun highHours(ctx: Context) = sp(ctx).getInt("high_hours", 3).coerceIn(1, 12)
    fun setHighHours(ctx: Context, v: Int) = sp(ctx).edit().putInt("high_hours", v.coerceIn(1, 12)).apply()

    fun missOn(ctx: Context) = sp(ctx).getBoolean("miss_on", true)
    fun setMissOn(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("miss_on", v).apply()
    fun missHour(ctx: Context) = sp(ctx).getInt("miss_hour", 20).coerceIn(8, 23)
    fun setMissHour(ctx: Context, v: Int) = sp(ctx).edit().putInt("miss_hour", v.coerceIn(8, 23)).apply()

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Alertas de glicemia", NotificationManager.IMPORTANCE_HIGH)
        ch.description = "Avisos quando a glicemia medida está fora da meta ou quando falta medir."
        ch.enableVibration(true)
        nm.createNotificationChannel(ch)
    }

    private fun notify(ctx: Context, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) return
        try {
            ensureChannel(ctx)
            val open = Intent(ctx, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP }
            val b = NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_drop)
                .setContentTitle(title)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setColor(0xFF6D28D9.toInt())
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(ctx, id, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            NotificationManagerCompat.from(ctx).notify(id, b.build())
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }

    private fun startOfDay(now: Long): Long = Calendar.getInstance().apply {
        timeInMillis = now
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun hoursText(ms: Long): String {
        val h = (ms / 3_600_000.0).roundToInt().coerceAtLeast(1)
        return if (h == 1) "1 hora" else "$h horas"
    }

    /** Confere os valores medidos e avisa se for o caso. Seguro para chamar várias vezes (cada aviso sai uma vez). */
    fun check(context: Context, data: AppData, now: Long = System.currentTimeMillis()) {
        val ctx = context.applicationContext
        val real = data.glucose.filter { !it.id.startsWith("demo-") && it.at <= now }
        val latest = real.maxByOrNull { it.at } ?: return // sem nenhuma medição própria ainda: nada a cobrar
        val s = data.settings
        val state = sp(ctx)
        val mg = toMgDl(latest.value, latest.unit)
        val age = now - latest.at

        if (lowOn(ctx) && mg < s.targetLow && age >= lowHours(ctx) * 3_600_000L && age <= STALE_MS &&
            state.getString("last_low_id", "") != latest.id
        ) {
            state.edit().putString("last_low_id", latest.id).apply()
            notify(
                ctx, NOTIF_LOW, "Glicemia baixa há ${hoursText(age)}",
                "A última medição foi ${mg.roundToInt()} mg/dL (${formatTime(latest.at)}), abaixo da sua meta de ${s.targetLow}. " +
                    "Meça de novo. Se tiver sintomas, siga o plano indicado pela sua equipe de saúde.",
            )
        }
        if (highOn(ctx) && mg > s.targetHigh && age >= highHours(ctx) * 3_600_000L && age <= STALE_MS &&
            state.getString("last_high_id", "") != latest.id
        ) {
            state.edit().putString("last_high_id", latest.id).apply()
            notify(
                ctx, NOTIF_HIGH, "Glicemia alta há ${hoursText(age)}",
                "A última medição foi ${mg.roundToInt()} mg/dL (${formatTime(latest.at)}), acima da sua meta de ${s.targetHigh}. " +
                    "Meça de novo e siga a orientação da sua equipe de saúde.",
            )
        }
        if (missOn(ctx)) {
            val cal = Calendar.getInstance().apply { timeInMillis = now }
            val dayStart = startOfDay(now)
            val today = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.DAY_OF_YEAR)}"
            if (cal.get(Calendar.HOUR_OF_DAY) >= missHour(ctx) && real.none { it.at >= dayStart } &&
                state.getString("last_miss_day", "") != today
            ) {
                state.edit().putString("last_miss_day", today).apply()
                notify(ctx, NOTIF_MISS, "Você ainda não mediu hoje", "Nenhuma glicemia registrada hoje. Que tal medir agora?")
            }
        }
    }
}

class GlucoseAlertWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        return try {
            val live = GlucoViewModel.liveInstance()
            // Na simulação do tour os dados do app são de exemplo: usa os reais, guardados no aparelho.
            val data = if (live != null && !live.practice.value) live.data.value else GlucoStorage.read(applicationContext)
            if (data != null) GlucoseAlerts.check(applicationContext, data)
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            Result.success()
        }
    }
}

object GlucoseAlertScheduler {
    private const val NAME = "gluco_glucose_alerts"

    /** Confere a cada 15 minutos (o mínimo do Android). É leve: só lê os dados do aparelho. */
    fun ensurePeriodic(ctx: Context) {
        try {
            val req = PeriodicWorkRequestBuilder<GlucoseAlertWorker>(15, TimeUnit.MINUTES).build()
            WorkManager.getInstance(ctx.applicationContext).enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, req)
        } catch (_: Exception) {
        }
    }
}
