package com.agon.app.reminders

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.OpenableColumns
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.agon.app.MainActivity
import com.agon.app.R
import com.agon.app.data.GlucoStorage
import com.agon.app.data.Reminder
import com.agon.app.data.formatClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.File
import java.util.Calendar
import java.util.UUID

data class SoundPreset(val id: String, val name: String, val description: String, val resId: Int)

val SOUND_PRESETS = listOf(
    SoundPreset("suave", "Suave", "Dois tons baixos e calmos", R.raw.snd_suave),
    SoundPreset("claro", "Claro", "Sequência luminosa de três notas", R.raw.snd_claro),
    SoundPreset("pulso", "Pulso", "Pulsos curtos para insulina", R.raw.snd_pulso),
    SoundPreset("alerta", "Alerta", "Tom mais presente para atenção", R.raw.snd_alerta),
    SoundPreset("sistema", "Padrão do aparelho", "Som de notificação padrão do celular", 0),
)

fun presetById(id: String): SoundPreset =
    SOUND_PRESETS.firstOrNull { it.id == id } ?: SOUND_PRESETS[0]

fun isCustomSound(id: String) = id.startsWith("custom:") || id.startsWith("uri:")

/** Copia um áudio escolhido pelo usuário para dentro do app, para tocar sempre, mesmo com o app fechado. */
object CustomSounds {
    private const val MAX_BYTES = 10L * 1024 * 1024

    private fun displayName(context: Context, uri: Uri): String? = try {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    } catch (_: Exception) {
        null
    }

    /** Devolve o id do som ("custom:..." ou "uri:...") ou null se não foi possível usar o arquivo. */
    fun import(context: Context, uri: Uri): String? {
        val app = context.applicationContext
        val name = displayName(app, uri) ?: "som"
        val ext = name.substringAfterLast('.', "").lowercase()
            .takeIf { it.length in 2..4 && it.all { c -> c.isLetterOrDigit() } } ?: "mp3"
        val base = name.substringBeforeLast('.')
            .replace(Regex("[^\\p{L}\\p{N} _-]"), "")
            .trim().take(30).ifBlank { "som" }
        val dir = File(app.filesDir, "sounds").apply { mkdirs() }
        val file = File(dir, UUID.randomUUID().toString().take(8) + "__" + base + "." + ext)
        try {
            val input = app.contentResolver.openInputStream(uri)
            if (input != null) {
                input.use { ins ->
                    file.outputStream().use { out ->
                        val buf = ByteArray(8192)
                        var total = 0L
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            total += n
                            if (total > MAX_BYTES) throw java.io.IOException("arquivo grande demais")
                            out.write(buf, 0, n)
                        }
                    }
                }
                return "custom:" + file.name
            }
        } catch (_: Exception) {
            file.delete()
        }
        // Som do sistema (toques do aparelho): dá para tocar direto pela referência.
        val s = uri.toString()
        if (s.startsWith("content://media/internal") || s.startsWith("content://settings")) return "uri:$s"
        return null
    }
}

object SoundPlayer {
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var stopRunnable: Runnable? = null

    /** Nome amigável do som para mostrar na tela. */
    fun soundLabel(context: Context, id: String): String = when {
        id.startsWith("custom:") -> id.removePrefix("custom:").substringAfter("__").substringBeforeLast('.')
        id.startsWith("uri:") -> try {
            RingtoneManager.getRingtone(context, Uri.parse(id.removePrefix("uri:")))?.getTitle(context) ?: "Som do celular"
        } catch (_: Exception) {
            "Som do celular"
        }
        else -> presetById(id).name
    }

    private fun defaultUri(): Uri =
        RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)

    private fun fallback(context: Context) {
        try {
            RingtoneManager.getRingtone(context, defaultUri())?.play()
        } catch (_: Exception) {
        }
    }

    /**
     * Toca o som no volume do ALARME (o mesmo usado quando o lembrete dispara).
     * [maxMs] > 0 corta o som depois desse tempo. [onDone] roda quando termina ou falha.
     */
    fun play(context: Context, id: String, maxMs: Long = 0L, onDone: (() -> Unit)? = null) {
        stop()
        val app = context.applicationContext
        var done = false
        val finishOnce = {
            if (!done) {
                done = true
                onDone?.invoke()
            }
        }
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build(),
            )
            when {
                id.startsWith("custom:") -> {
                    val f = File(File(app.filesDir, "sounds"), id.removePrefix("custom:"))
                    mp.setDataSource(f.absolutePath)
                }
                id.startsWith("uri:") -> mp.setDataSource(app, Uri.parse(id.removePrefix("uri:")))
                id == "sistema" || id == "celular" -> mp.setDataSource(app, defaultUri())
                else -> {
                    val afd = app.resources.openRawResourceFd(presetById(id).resId)
                    mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                    afd.close()
                }
            }
            try {
                mp.setWakeMode(app, PowerManager.PARTIAL_WAKE_LOCK)
            } catch (_: Exception) {
            }
            mp.setVolume(1.0f, 1.0f)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener {
                stop()
                finishOnce()
            }
            mp.setOnErrorListener { _, _, _ ->
                stop()
                fallback(app)
                finishOnce()
                true
            }
            player = mp
            if (maxMs > 0) {
                val r = Runnable {
                    stop()
                    finishOnce()
                }
                stopRunnable = r
                handler.postDelayed(r, maxMs)
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            stop()
            fallback(app)
            finishOnce()
        }
    }

    fun stop() {
        stopRunnable?.let { handler.removeCallbacks(it) }
        stopRunnable = null
        try {
            player?.stop()
        } catch (_: Exception) {
        }
        try {
            player?.release()
        } catch (_: Exception) {
        }
        player = null
    }
}

object ReminderScheduler {
    const val EXTRA_ID = "id"
    const val EXTRA_KIND = "kind"
    const val EXTRA_TITLE = "title"
    const val EXTRA_HOUR = "hour"
    const val EXTRA_MINUTE = "minute"
    const val EXTRA_DAYS = "days"
    const val EXTRA_SOUND = "sound"
    const val EXTRA_NOTES = "notes"

    const val CHANNEL_ID = "gluco_lembretes_v2"

    /** Um único canal sem som próprio: o som é tocado pelo app (volume do alarme), igual à prévia. */
    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        try {
            nm.notificationChannels
                .filter { it.id.startsWith("gluco_lembretes_") && it.id != CHANNEL_ID }
                .forEach { nm.deleteNotificationChannel(it.id) }
        } catch (_: Exception) {
        }
        val ch = NotificationChannel(CHANNEL_ID, "Lembretes de glicose e insulina", android.app.NotificationManager.IMPORTANCE_HIGH)
        ch.description = "O som do lembrete é tocado pelo aplicativo, no volume do alarme."
        ch.enableVibration(true)
        ch.vibrationPattern = longArrayOf(0, 400, 200, 400)
        ch.setSound(null, null)
        nm.createNotificationChannel(ch)
    }

    fun nextTrigger(hour: Int, minute: Int, days: List<Int>, after: Long = System.currentTimeMillis()): Long? {
        if (days.isEmpty()) return null
        for (i in 0 until 8) {
            val c = Calendar.getInstance()
            c.timeInMillis = after
            c.add(Calendar.DAY_OF_YEAR, i)
            c.set(Calendar.HOUR_OF_DAY, hour)
            c.set(Calendar.MINUTE, minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            if ((c.get(Calendar.DAY_OF_WEEK) - 1) in days && c.timeInMillis > after) return c.timeInMillis
        }
        return null
    }

    private fun pendingIntent(context: Context, id: String, extras: Intent?): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            action = "com.agon.app.REMINDER"
            data = Uri.parse("gluco://reminder/$id")
            if (extras != null) putExtras(extras)
        }
        return PendingIntent.getBroadcast(context, id.hashCode(), intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
    }

    fun cancel(context: Context, id: String) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pendingIntent(context, id, null))
    }

    fun schedule(context: Context, id: String, kind: String, title: String, hour: Int, minute: Int, days: List<Int>, soundId: String, notes: String) {
        val trigger = nextTrigger(hour, minute, days) ?: return
        val extras = Intent().apply {
            putExtra(EXTRA_ID, id)
            putExtra(EXTRA_KIND, kind)
            putExtra(EXTRA_TITLE, title)
            putExtra(EXTRA_HOUR, hour)
            putExtra(EXTRA_MINUTE, minute)
            putExtra(EXTRA_DAYS, days.toIntArray())
            putExtra(EXTRA_SOUND, soundId)
            putExtra(EXTRA_NOTES, notes)
        }
        val pi = pendingIntent(context, id, extras)
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val exact = if (Build.VERSION.SDK_INT >= 31) am.canScheduleExactAlarms() else true
        try {
            if (exact) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, trigger, pi)
        }
    }

    fun scheduleReminder(context: Context, r: Reminder) =
        schedule(context, r.id, r.kind, r.title, r.hour, r.minute, r.days, r.soundId, r.notes)

    fun sync(context: Context, old: List<Reminder>, new: List<Reminder>) {
        val ids = new.map { it.id }.toSet()
        old.filter { it.id !in ids }.forEach { cancel(context, it.id) }
        new.forEach { if (it.enabled) scheduleReminder(context, it) else cancel(context, it.id) }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getStringExtra(ReminderScheduler.EXTRA_ID) ?: return
        val kind = intent.getStringExtra(ReminderScheduler.EXTRA_KIND) ?: "glicose"
        val title = intent.getStringExtra(ReminderScheduler.EXTRA_TITLE) ?: "Lembrete"
        val hour = intent.getIntExtra(ReminderScheduler.EXTRA_HOUR, 8)
        val minute = intent.getIntExtra(ReminderScheduler.EXTRA_MINUTE, 0)
        val days = intent.getIntArrayExtra(ReminderScheduler.EXTRA_DAYS)?.toList() ?: emptyList()
        val sound = intent.getStringExtra(ReminderScheduler.EXTRA_SOUND) ?: "suave"
        val notes = intent.getStringExtra(ReminderScheduler.EXTRA_NOTES) ?: ""

        // Relógio inteligente da água: se a meta do dia já foi batida, não incomoda.
        if (kind == "agua" && com.agon.app.ui.screens.waterGoalMet(context)) {
            ReminderScheduler.schedule(context, id, kind, title, hour, minute, days, sound, notes)
            return
        }

        val pending = goAsync()
        var finished = false
        val finish = {
            if (!finished) {
                finished = true
                try {
                    pending.finish()
                } catch (_: Exception) {
                }
            }
        }

        try {
            ReminderScheduler.ensureChannels(context)
            if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                val open = Intent(context, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP }
                val whenText = "$title · ${formatClock(hour, minute)}"
                val big = whenText + if (notes.isNotBlank()) "\n$notes" else ""
                val builder = NotificationCompat.Builder(context, ReminderScheduler.CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_stat_drop)
                    .setContentTitle(when (kind) { "glicose" -> "Hora de medir a glicose"; "agua" -> "Hora de beber água 💧"; else -> "Hora da insulina" })
                    .setContentText(whenText)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(big))
                    .setPriority(NotificationCompat.PRIORITY_HIGH)
                    .setCategory(NotificationCompat.CATEGORY_REMINDER)
                    .setColor(0xFF6D28D9.toInt())
                    .setAutoCancel(true)
                    .setContentIntent(PendingIntent.getActivity(context, id.hashCode(), open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                if (Build.VERSION.SDK_INT < 26) {
                    builder.setSound(null)
                    builder.setVibrate(longArrayOf(0, 400, 200, 400))
                }
                try {
                    NotificationManagerCompat.from(context).notify(id.hashCode(), builder.build())
                } catch (e: SecurityException) {
                }
            }
            ReminderScheduler.schedule(context, id, kind, title, hour, minute, days, sound, notes)
        } catch (e: Exception) {
        }

        // O som é tocado aqui, no volume do alarme, mesmo com o app fechado.
        try {
            Handler(Looper.getMainLooper()).postDelayed({
                SoundPlayer.stop()
                finish()
            }, 9000L)
            SoundPlayer.play(context, sound, maxMs = 8000L) { finish() }
        } catch (e: Exception) {
            finish()
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val data = GlucoStorage.read(context)
                data?.reminders?.filter { it.enabled }?.forEach { ReminderScheduler.scheduleReminder(context, it) }
                com.agon.app.ui.screens.syncWaterClock(context)
                QuickGlucoseNotifier.refresh(context)
            } catch (e: Exception) {
            } finally {
                pending.finish()
            }
        }
    }
}

