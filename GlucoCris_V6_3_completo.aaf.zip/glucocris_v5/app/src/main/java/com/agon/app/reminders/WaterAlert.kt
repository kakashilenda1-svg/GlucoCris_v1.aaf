package com.agon.app.reminders

import android.content.Context
import android.content.Intent
import android.app.PendingIntent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.agon.app.MainActivity
import com.agon.app.R

/** Alerta para beber água quando a glicose está alta (liga/desliga dentro do Cris Hidrata). */
object WaterAlert {
    private const val PREFS = "gluco_water_v1"
    private const val KEY_HIGH = "high_alert_on"
    private const val NOTIF_ID = 7701

    fun isOn(ctx: Context): Boolean =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_HIGH, true)

    fun setOn(ctx: Context, on: Boolean) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_HIGH, on).apply()
    }

    fun notifyHighGlucose(ctx: Context, mgDl: Double) {
        val app = ctx.applicationContext
        if (!isOn(app)) return
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(app, android.Manifest.permission.POST_NOTIFICATIONS) !=
            android.content.pm.PackageManager.PERMISSION_GRANTED
        ) return
        try {
            ReminderScheduler.ensureChannels(app)
            val open = Intent(app, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val text = "Sua última medição foi ${mgDl.toInt()} mg/dL. Beber água ajuda na hidratação; siga a orientação da sua equipe de saúde."
            val b = NotificationCompat.Builder(app, ReminderScheduler.CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_stat_drop)
                .setContentTitle("Glicose alta: hora de beber água 💧")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(app, NOTIF_ID, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
            NotificationManagerCompat.from(app).notify(NOTIF_ID, b.build())
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }
}
