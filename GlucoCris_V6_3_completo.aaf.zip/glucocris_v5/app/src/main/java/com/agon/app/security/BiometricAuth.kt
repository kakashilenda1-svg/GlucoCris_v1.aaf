package com.agon.app.security

import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Ponte com as APIs oficiais (AndroidX BiometricPrompt / BiometricManager).
 * Só BIOMETRIC_STRONG: o Android decide, entre as biometrias fortes cadastradas, quais aparecem (digital, rosto forte).
 * Sem credencial do aparelho, PIN ou senha própria. O app nunca recebe imagem nem modelo biométrico: só "aprovou/não aprovou".
 */
object BiometricAuth {
    private const val STRONG = BiometricManager.Authenticators.BIOMETRIC_STRONG
    private const val FEATURE_FACE = "android.hardware.biometrics.face"

    /** Uma única janela de autenticação por vez em todo o processo (tela de bloqueio e configurações). */
    private val inFlight = AtomicBoolean(false)

    fun availability(c: Context): Availability = BiometricPolicy.availability(
        try { BiometricManager.from(c).canAuthenticate(STRONG) } catch (_: Exception) { BiometricManager.BIOMETRIC_STATUS_UNKNOWN },
    )

    /** O aparelho declara o sensor da modalidade? (O nível de segurança é conferido por [availability].) */
    fun deviceHas(c: Context, m: Modality): Boolean = try {
        val pm = c.packageManager
        when (m) {
            Modality.FINGERPRINT -> pm.hasSystemFeature(PackageManager.FEATURE_FINGERPRINT)
            Modality.FACE -> pm.hasSystemFeature(FEATURE_FACE)
        }
    } catch (_: Exception) {
        false
    }

    /** Estado de uma modalidade no aparelho. [enrolled] nulo = o Android não informa (não existe API pública para isso). */
    data class ModalityStatus(val hardware: Boolean, val enrolled: Boolean?)

    /** Digital: o sensor vem do PackageManager e o cadastro da API oficial (antiga, mas documentada) do FingerprintManager. */
    @Suppress("DEPRECATION")
    fun fingerprintStatus(c: Context): ModalityStatus {
        val hw = deviceHas(c, Modality.FINGERPRINT)
        val enrolled: Boolean? = if (!hw) false else try {
            c.getSystemService(android.hardware.fingerprint.FingerprintManager::class.java)?.hasEnrolledFingerprints()
        } catch (_: Exception) {
            null
        }
        return ModalityStatus(hw, enrolled)
    }

    /** Rosto: o Android não oferece API pública para saber se há um rosto cadastrado nem se ele é forte; só o sensor é conhecido. */
    fun faceStatus(c: Context): ModalityStatus = ModalityStatus(deviceHas(c, Modality.FACE), null)

    fun activityOf(c: Context): FragmentActivity? {
        var x: Context? = c
        while (x is ContextWrapper) {
            if (x is FragmentActivity) return x
            x = x.baseContext
        }
        return null
    }

    /** Abre o assistente do Android para cadastrar uma biometria forte (ou os ajustes de segurança em versões antigas). */
    fun enrollIntent(): Intent =
        if (Build.VERSION.SDK_INT >= 30) {
            Intent(Settings.ACTION_BIOMETRIC_ENROLL).putExtra(Settings.EXTRA_BIOMETRIC_AUTHENTICATORS_ALLOWED, STRONG)
        } else {
            Intent(Settings.ACTION_SECURITY_SETTINGS)
        }

    /**
     * Pede a biometria. [onSuccess] só roda quando o Android aprovou. [onFailure] roda para cancelamento, bloqueio por
     * tentativas, ausência de cadastro ou erro: quem chama deve MANTER o bloqueio. Tentativas recusadas (dedo/rosto não
     * reconhecido) deixam a janela do sistema aberta para nova tentativa e, ao esgotar, chegam como LOCKED_OUT.
     * @return false se não abriu uma janela (já há outra aberta, sem Activity ou sem biometria forte disponível).
     */
    fun authenticate(
        context: Context,
        title: String,
        subtitle: String,
        onSuccess: () -> Unit,
        onFailure: (AuthFailure) -> Unit,
    ): Boolean {
        val activity = activityOf(context) ?: return false
        val avail = availability(activity)
        if (avail != Availability.AVAILABLE) {
            onFailure(if (avail == Availability.NONE_ENROLLED) AuthFailure.NOT_ENROLLED else AuthFailure.UNAVAILABLE)
            return true
        }
        if (!inFlight.compareAndSet(false, true)) return false
        return try {
            val executor = ContextCompat.getMainExecutor(activity)
            val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    inFlight.set(false)
                    onSuccess()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    inFlight.set(false)
                    onFailure(BiometricPolicy.classifyError(errorCode))
                }
            })
            val info = BiometricPrompt.PromptInfo.Builder()
                .setTitle(title)
                .setSubtitle(subtitle)
                .setAllowedAuthenticators(STRONG)
                .setConfirmationRequired(true)
                .setNegativeButtonText("Cancelar")
                .build()
            prompt.authenticate(info)
            true
        } catch (_: Exception) {
            inFlight.set(false)
            onFailure(AuthFailure.OTHER)
            true
        }
    }
}
