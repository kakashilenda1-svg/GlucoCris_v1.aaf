package com.agon.app.security

/** Modalidades que a pessoa pode ligar nas configurações. */
enum class Modality { FINGERPRINT, FACE }

/** Situação da biometria FORTE no aparelho (traduzida do código do BiometricManager). */
enum class Availability { AVAILABLE, NONE_ENROLLED, NO_HARDWARE, TEMPORARILY_UNAVAILABLE, UPDATE_REQUIRED, UNSUPPORTED }

/** Pode ligar a modalidade? */
enum class EnableDecision { ALLOWED, INCOMPATIBLE_DEVICE, NEED_ENROLL, TEMPORARILY_UNAVAILABLE, UPDATE_REQUIRED }

/** Aviso sobre a escolha de modalidades que o Android não consegue garantir. */
enum class Limitation { NONE, FACE_COULD_ALSO_UNLOCK, FINGERPRINT_COULD_ALSO_UNLOCK }

/** Por que a autenticação não terminou em sucesso (códigos do BiometricPrompt traduzidos). */
enum class AuthFailure { CANCELED, LOCKED_OUT, NOT_ENROLLED, UNAVAILABLE, OTHER }

/**
 * Regras de segurança sem Android (testáveis na JVM).
 * Os códigos numéricos são os de androidx.biometric (BiometricManager.BIOMETRIC_* e BiometricPrompt.ERROR_*).
 * Só biometria FORTE conta (Authenticators.BIOMETRIC_STRONG): reconhecimento facial classificado como fraco pelo Android
 * nunca é aceito, e este fluxo não aceita a credencial do aparelho. O PIN do app só entra como recuperação quando a biometria do aparelho
 * não funciona mais (ver [recoveryAllowed]); cancelar, recusar ou errar NUNCA abrem o app.
 */
object BiometricPolicy {
    private const val STATUS_SUCCESS = 0
    private const val STATUS_HW_UNAVAILABLE = 1
    private const val STATUS_NONE_ENROLLED = 11
    private const val STATUS_NO_HARDWARE = 12
    private const val STATUS_SECURITY_UPDATE_REQUIRED = 15

    fun availability(canAuthenticateCode: Int): Availability = when (canAuthenticateCode) {
        STATUS_SUCCESS -> Availability.AVAILABLE
        STATUS_NONE_ENROLLED -> Availability.NONE_ENROLLED
        STATUS_NO_HARDWARE -> Availability.NO_HARDWARE
        STATUS_HW_UNAVAILABLE -> Availability.TEMPORARILY_UNAVAILABLE
        STATUS_SECURITY_UPDATE_REQUIRED -> Availability.UPDATE_REQUIRED
        else -> Availability.UNSUPPORTED   // inclui "desconhecido" e "não suportado": nunca presume que funciona
    }

    /** A proteção vale com a chave geral ligada E pelo menos uma modalidade (digital ou rosto) ligada. Com as duas desligadas o app abre normalmente. */
    fun protectionRequired(enabled: Boolean, fingerprint: Boolean, face: Boolean): Boolean = enabled && (fingerprint || face)

    /**
     * O Android NÃO tem API pública para aceitar só a digital ou só o rosto: o BiometricPrompt aceita qualquer biometria
     * forte cadastrada. Esta função diz, para a escolha feita e os sensores do aparelho, se a escolha pode ser garantida.
     * Só há garantia quando o aparelho não tem outro sensor que também desbloquearia, ou quando todos os sensores foram permitidos.
     */
    fun limitation(deviceHasFingerprint: Boolean, deviceHasFace: Boolean, fingerprintOn: Boolean, faceOn: Boolean): Limitation = when {
        fingerprintOn && !faceOn && deviceHasFace -> Limitation.FACE_COULD_ALSO_UNLOCK
        faceOn && !fingerprintOn && deviceHasFingerprint -> Limitation.FINGERPRINT_COULD_ALSO_UNLOCK
        else -> Limitation.NONE
    }

    fun limitationMessage(l: Limitation): String = when (l) {
        Limitation.NONE -> ""
        Limitation.FACE_COULD_ALSO_UNLOCK ->
            "Limitação do Android: não é possível aceitar SÓ a digital. Este aparelho também tem reconhecimento facial e, " +
                "se houver um rosto cadastrado como biometria forte, ele também poderá desbloquear."
        Limitation.FINGERPRINT_COULD_ALSO_UNLOCK ->
            "Limitação do Android: não é possível aceitar SÓ o rosto. Este aparelho também tem leitor de digital e, " +
                "se houver uma digital cadastrada, ela também poderá desbloquear."
    }

    /** [deviceHasModality]: o aparelho declara o sensor (digital/rosto). [availability]: biometria FORTE cadastrada e pronta. */
    fun canEnable(deviceHasModality: Boolean, availability: Availability): EnableDecision = when {
        !deviceHasModality -> EnableDecision.INCOMPATIBLE_DEVICE
        availability == Availability.AVAILABLE -> EnableDecision.ALLOWED
        availability == Availability.NONE_ENROLLED -> EnableDecision.NEED_ENROLL
        availability == Availability.TEMPORARILY_UNAVAILABLE -> EnableDecision.TEMPORARILY_UNAVAILABLE
        availability == Availability.UPDATE_REQUIRED -> EnableDecision.UPDATE_REQUIRED
        else -> EnableDecision.INCOMPATIBLE_DEVICE
    }

    fun classifyError(errorCode: Int): AuthFailure = when (errorCode) {
        5, 10, 13 -> AuthFailure.CANCELED               // ERROR_CANCELED, ERROR_USER_CANCELED, ERROR_NEGATIVE_BUTTON
        7, 9 -> AuthFailure.LOCKED_OUT                  // ERROR_LOCKOUT, ERROR_LOCKOUT_PERMANENT
        11 -> AuthFailure.NOT_ENROLLED                  // ERROR_NO_BIOMETRICS
        1, 12, 14, 15 -> AuthFailure.UNAVAILABLE        // HW_UNAVAILABLE, HW_NOT_PRESENT, NO_DEVICE_CREDENTIAL, SECURITY_UPDATE_REQUIRED
        else -> AuthFailure.OTHER
    }

    fun enableMessage(d: EnableDecision, modality: Modality?): String {
        val nome = when (modality) {
            Modality.FACE -> "reconhecimento facial"
            Modality.FINGERPRINT -> "impressão digital"
            null -> "biometria"
        }
        return when (d) {
            EnableDecision.ALLOWED -> ""
            EnableDecision.INCOMPATIBLE_DEVICE ->
                "Este aparelho não oferece $nome com o nível de segurança exigido (biometria forte). A opção não pode ser ativada."
            EnableDecision.NEED_ENROLL ->
                "Nenhuma biometria forte está cadastrada. Cadastre uma digital ou rosto nas configurações do Android e volte aqui."
            EnableDecision.TEMPORARILY_UNAVAILABLE -> "A biometria está indisponível agora. Tente novamente em instantes."
            EnableDecision.UPDATE_REQUIRED -> "O Android precisa de uma atualização de segurança para liberar a biometria."
        }
    }

    fun lockMessage(f: AuthFailure): String = when (f) {
        AuthFailure.CANCELED -> "Autenticação cancelada. O Gluco Cris continua bloqueado."
        AuthFailure.LOCKED_OUT -> "Muitas tentativas. Aguarde um pouco (ou use o bloqueio do Android) e tente de novo."
        AuthFailure.NOT_ENROLLED -> "Nenhuma biometria cadastrada. Cadastre uma digital ou rosto nas configurações do Android para entrar."
        AuthFailure.UNAVAILABLE -> "A biometria está indisponível agora. O Gluco Cris continua bloqueado."
        AuthFailure.OTHER -> "Não foi possível autenticar. O Gluco Cris continua bloqueado."
    }

    /** O PIN do app (se existir) pode servir de recuperação? Só quando a biometria deixou de existir no aparelho; nunca por cancelar, recusar ou bloqueio temporário. */
    fun recoveryAllowed(pinEnabled: Boolean, availability: Availability): Boolean = pinEnabled && when (availability) {
        Availability.NONE_ENROLLED, Availability.NO_HARDWARE, Availability.UNSUPPORTED, Availability.UPDATE_REQUIRED -> true
        Availability.AVAILABLE, Availability.TEMPORARILY_UNAVAILABLE -> false
    }

    fun availabilityMessage(a: Availability): String = when (a) {
        Availability.AVAILABLE -> "Biometria forte cadastrada e pronta."
        Availability.NONE_ENROLLED -> "Nenhuma biometria forte cadastrada no Android."
        Availability.NO_HARDWARE -> "Este aparelho não tem biometria forte."
        Availability.TEMPORARILY_UNAVAILABLE -> "Biometria temporariamente indisponível (ou bloqueada pelo Android)."
        Availability.UPDATE_REQUIRED -> "O Android precisa de uma atualização de segurança para liberar a biometria."
        Availability.UNSUPPORTED -> "O Android deste aparelho não informa suporte a biometria forte."
    }

    fun enrollmentChangedMessage(): String =
        "As biometrias cadastradas no Android mudaram desde a última vez. Se não foi você, revise as biometrias do aparelho."
}

/** Resultado do plano de migração da antiga opção "Entrar com digital ou rosto". */
object LegacyMigration {
    enum class Note { NONE, MIGRATED, NOT_MIGRATED_WEAK_OR_MISSING, ALREADY_CONFIGURED }

    data class Plan(val enableNew: Boolean, val fingerprint: Boolean, val face: Boolean, val clearLegacy: Boolean, val note: Note)

    /**
     * A opção antiga (BIOMETRIC_WEAK, só trocava o teclado do PIN) deixa de existir como controle à parte.
     *  - antiga desligada: nada a migrar;
     *  - nova já configurada: a nova vale, a antiga só é desligada (nada é sobrescrito);
     *  - antiga ligada e biometria FORTE pronta: liga o novo bloqueio com as modalidades que o aparelho tem;
     *  - antiga ligada mas sem biometria forte: NÃO liga o novo (não deixa ninguém trancado), avisa o motivo, e o PIN continua valendo.
     */
    fun plan(legacyOn: Boolean, newConfigured: Boolean, strong: Availability, hasFingerprint: Boolean, hasFace: Boolean): Plan {
        if (!legacyOn) return Plan(false, false, false, false, Note.NONE)
        if (newConfigured) return Plan(false, false, false, true, Note.ALREADY_CONFIGURED)
        if (strong == Availability.AVAILABLE && (hasFingerprint || hasFace)) {
            return Plan(true, hasFingerprint, hasFace, true, Note.MIGRATED)
        }
        return Plan(false, false, false, true, Note.NOT_MIGRATED_WEAK_OR_MISSING)
    }
}
