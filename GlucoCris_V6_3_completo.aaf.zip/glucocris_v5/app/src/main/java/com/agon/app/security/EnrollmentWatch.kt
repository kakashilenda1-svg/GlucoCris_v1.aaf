package com.agon.app.security

import android.os.Build
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyPermanentlyInvalidatedException
import android.security.keystore.KeyProperties
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey

/**
 * Detecta mudança nas biometrias cadastradas no Android (cadastro novo ou remoção) usando só o Android Keystore:
 * uma chave "sentinela" é invalidada pelo próprio sistema quando as biometrias mudam ([KeyPermanentlyInvalidatedException]).
 * É só um AVISO: a chave não guarda nada, não protege dado algum e nunca libera nem bloqueia o app sozinha.
 * Se o Keystore não permitir (ex.: aparelho sem tela de bloqueio segura), o resultado é "desconhecido" e nada muda.
 */
object EnrollmentWatch {
    private const val ALIAS = "gluco_bio_probe_v1"
    private const val TRANSFORM = "AES/GCM/NoPadding"

    /** (Re)cria a sentinela com as biometrias de agora. Chamar depois de uma autenticação aprovada. */
    fun arm(): Boolean = try {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        if (ks.containsAlias(ALIAS)) ks.deleteEntry(ALIAS)
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val b = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setUserAuthenticationRequired(true)
            .setInvalidatedByBiometricEnrollment(true)
        if (Build.VERSION.SDK_INT >= 30) {
            b.setUserAuthenticationParameters(0, KeyProperties.AUTH_BIOMETRIC_STRONG)
        } else {
            @Suppress("DEPRECATION")
            b.setUserAuthenticationValidityDurationSeconds(-1)
        }
        gen.init(b.build())
        gen.generateKey()
        true
    } catch (_: Exception) {
        false
    }

    /** true = as biometrias mudaram desde [arm]; false = iguais; null = não dá para saber (sem sentinela ou Keystore indisponível). */
    fun changedSinceArm(): Boolean? = try {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val key = ks.getKey(ALIAS, null) as? SecretKey
        if (key == null) {
            null
        } else {
            try {
                Cipher.getInstance(TRANSFORM).init(Cipher.ENCRYPT_MODE, key)
                false
            } catch (_: KeyPermanentlyInvalidatedException) {
                true
            }
        }
    } catch (_: Exception) {
        null
    }
}
