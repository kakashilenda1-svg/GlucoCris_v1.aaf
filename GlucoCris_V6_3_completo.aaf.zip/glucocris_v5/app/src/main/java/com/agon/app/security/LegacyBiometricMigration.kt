package com.agon.app.security

import android.content.Context
import com.agon.app.data.GlucoViewModel

/**
 * Migra, uma única vez, a antiga opção "Entrar com digital ou rosto" (que só trocava o teclado do PIN e aceitava biometria
 * fraca) para o Bloqueio biométrico novo. O plano é decidido por [LegacyMigration.plan] (sem Android, testado):
 * nada é apagado, PIN e dados seguem como estão, e a opção antiga fica desligada para não existir em paralelo.
 */
object LegacyBiometricMigration {
    fun run(c: Context, vm: GlucoViewModel) {
        val legacyOn = vm.data.value.settings.biometricEnabled
        val current = SecurityPrefs.read(c)
        val plan = LegacyMigration.plan(
            legacyOn = legacyOn,
            newConfigured = current.configured,
            strong = BiometricAuth.availability(c),
            hasFingerprint = BiometricAuth.deviceHas(c, Modality.FINGERPRINT),
            hasFace = BiometricAuth.deviceHas(c, Modality.FACE),
        )
        if (plan.note == LegacyMigration.Note.NONE) return
        if (plan.enableNew) {
            // Se não conseguir gravar, nada muda e a opção antiga continua registrada: tenta de novo na próxima abertura.
            if (!SecurityPrefs.write(c, true, plan.fingerprint, plan.face, RelockPolicy.DEFAULT)) return
            EnrollmentWatch.arm()
            SecurityPrefs.markSessionUnlocked(c)   // esta sessão já está aberta; a proteção vale a partir da próxima abertura/saída
        }
        SecurityPrefs.setLegacyNote(c, plan.note)
        if (plan.clearLegacy) vm.updateSettings { it.copy(biometricEnabled = false) }
    }
}
