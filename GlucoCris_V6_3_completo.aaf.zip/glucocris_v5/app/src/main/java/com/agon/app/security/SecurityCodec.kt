package com.agon.app.security

/** Quando voltar do segundo plano exige biometria de novo. Uma NOVA abertura (processo/Activity novos) sempre exige, em qualquer política. */
enum class RelockPolicy(val seconds: Int, val label: String) {
    IMMEDIATE(0, "Imediatamente"),
    AFTER_30S(30, "30 segundos"),
    AFTER_1MIN(60, "1 minuto"),
    AFTER_5MIN(300, "5 minutos");

    val millis: Long get() = seconds * 1000L

    companion object {
        val DEFAULT = AFTER_1MIN
        fun fromSeconds(s: Int?): RelockPolicy = values().firstOrNull { it.seconds == s } ?: DEFAULT
    }
}

/**
 * Formato das preferências de segurança: texto simples + assinatura (HMAC). Se a assinatura não confere (arquivo alterado,
 * restaurado de outro aparelho ou chave perdida), a proteção passa a valer como ligada, com as duas modalidades e bloqueio
 * imediato: falha fechando, nunca abrindo. Nenhum dado biométrico existe aqui: só preferências.
 *
 * v2: "v2;on=1;fp=1;face=0;rl=60"   (on = chave geral, fp = digital, face = rosto, rl = segundos até travar ao voltar do 2º plano)
 * v1 (versão anterior, só digital/rosto) continua sendo lida: on = fp || face, rl = padrão.
 */
object SecurityCodec {
    data class Flags(
        val enabled: Boolean,
        val fingerprint: Boolean,
        val face: Boolean,
        val relock: RelockPolicy = RelockPolicy.DEFAULT,
        val tampered: Boolean = false,
        /** false = nunca houve configuração salva (instalação nova ou apenas atualizada). */
        val configured: Boolean = true,
    ) {
        /** A proteção só vale com a chave geral ligada E pelo menos uma modalidade ligada. */
        val required: Boolean get() = BiometricPolicy.protectionRequired(enabled, fingerprint, face)
    }

    private const val V1 = "v1"
    private const val V2 = "v2"

    fun encode(enabled: Boolean, fingerprint: Boolean, face: Boolean, relock: RelockPolicy): String =
        "$V2;on=${b(enabled)};fp=${b(fingerprint)};face=${b(face)};rl=${relock.seconds}"

    private fun b(x: Boolean) = if (x) 1 else 0

    val NOT_CONFIGURED = Flags(enabled = false, fingerprint = false, face = false, relock = RelockPolicy.DEFAULT, configured = false)
    val TAMPERED = Flags(enabled = true, fingerprint = true, face = true, relock = RelockPolicy.IMMEDIATE, tampered = true)

    /** [payload] nulo = nunca configurado (desligado). [macOf] calcula a assinatura esperada do texto. */
    fun decode(payload: String?, mac: String?, macOf: (String) -> String): Flags {
        if (payload == null) return NOT_CONFIGURED
        val expected = macOf(payload)
        if (mac == null || !constantTimeEquals(mac, expected)) return TAMPERED
        val parts = payload.split(';')
        return when (parts.firstOrNull()) {
            V1 -> decodeV1(parts)
            V2 -> decodeV2(parts)
            else -> TAMPERED
        }
    }

    private fun flag(part: String, name: String): Boolean? {
        if (!part.startsWith("$name=")) return null
        return when (part.removePrefix("$name=")) { "0" -> false; "1" -> true; else -> null }
    }

    private fun decodeV1(parts: List<String>): Flags {
        if (parts.size != 3) return TAMPERED
        val fp = flag(parts[1], "fp") ?: return TAMPERED
        val face = flag(parts[2], "face") ?: return TAMPERED
        return Flags(enabled = fp || face, fingerprint = fp, face = face)
    }

    private fun decodeV2(parts: List<String>): Flags {
        if (parts.size != 5) return TAMPERED
        val on = flag(parts[1], "on") ?: return TAMPERED
        val fp = flag(parts[2], "fp") ?: return TAMPERED
        val face = flag(parts[3], "face") ?: return TAMPERED
        if (!parts[4].startsWith("rl=")) return TAMPERED
        val rl = parts[4].removePrefix("rl=").toIntOrNull() ?: return TAMPERED
        val policy = RelockPolicy.values().firstOrNull { it.seconds == rl } ?: return TAMPERED
        return Flags(enabled = on, fingerprint = fp, face = face, relock = policy)
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        if (a.length != b.length) return false
        var r = 0
        for (i in a.indices) r = r or (a[i].code xor b[i].code)
        return r == 0
    }
}
