package com.agon.app.security

import android.content.Context
import android.provider.Settings
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyStore
import java.util.UUID
import javax.crypto.KeyGenerator
import javax.crypto.Mac
import javax.crypto.SecretKey

/**
 * Preferências de segurança (chave geral, digital, rosto, política ao voltar do segundo plano), persistentes e assinadas com
 * uma chave HMAC do Android Keystore (a chave nunca sai do aparelho). Nenhuma imagem, impressão ou dado biométrico é guardado.
 * Arquivo próprio, excluído do backup (res/xml/backup_rules.xml e data_extraction_rules.xml).
 * Usa sempre o contexto do aplicativo (a simulação do tour troca o arquivo de preferências só na Activity).
 *
 * Também guarda, fora da assinatura (não decide nada sozinho): a "marca da sessão desbloqueada" e o aviso da migração antiga.
 */
object SecurityPrefs {
    private const val FILE = "gluco_security_v1"
    private const val KEY_PAYLOAD = "p"
    private const val KEY_MAC = "m"
    private const val KEY_STAMP = "s"
    private const val KEY_LEGACY_NOTE = "ln"
    private const val ALIAS = "gluco_security_mac_v1"
    private const val NO_KEYSTORE = "nomac"

    /** Novo a cada processo: uma marca de sessão gravada por outro processo nunca confere com este. */
    private val processToken: String = UUID.randomUUID().toString()

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** Leitura síncrona (necessária antes da primeira tela para já nascer bloqueado). Nunca lança exceção. */
    fun read(c: Context): SecurityCodec.Flags = try {
        val p = prefs(c)
        SecurityCodec.decode(p.getString(KEY_PAYLOAD, null), p.getString(KEY_MAC, null), ::macOf)
    } catch (_: Exception) {
        SecurityCodec.TAMPERED   // na dúvida, protegido
    }

    /** Grava de forma síncrona. Devolve false se não conseguiu gravar (a proteção não muda). */
    fun write(c: Context, enabled: Boolean, fingerprint: Boolean, face: Boolean, relock: RelockPolicy): Boolean = try {
        val payload = SecurityCodec.encode(enabled, fingerprint, face, relock)
        prefs(c).edit().putString(KEY_PAYLOAD, payload).putString(KEY_MAC, macOf(payload)).commit()
    } catch (_: Exception) {
        false
    }

    // ---- marca da sessão (não depende só de variável em memória) ----

    private fun bootCount(c: Context): Int = try {
        Settings.Global.getInt(c.applicationContext.contentResolver, Settings.Global.BOOT_COUNT, -1)
    } catch (_: Exception) {
        -1
    }

    private fun currentStamp(c: Context): String = SessionStamp.make(processToken, bootCount(c))

    /** Chamado quando uma nova sessão começa (Activity nova): qualquer marca antiga deixa de valer. */
    fun clearSession(c: Context) {
        try { prefs(c).edit().remove(KEY_STAMP).apply() } catch (_: Exception) { }
    }

    /** Chamado quando a autenticação foi aprovada: grava "esta sessão, neste processo, nesta inicialização, está aberta". */
    fun markSessionUnlocked(c: Context) {
        try { prefs(c).edit().putString(KEY_STAMP, currentStamp(c)).apply() } catch (_: Exception) { }
    }

    /** A marca guardada confere com este processo e esta inicialização? Erro ao ler = não confere (trava). */
    fun sessionStampValid(c: Context): Boolean = try {
        SessionStamp.isValid(prefs(c).getString(KEY_STAMP, null), currentStamp(c))
    } catch (_: Exception) {
        false
    }

    // ---- aviso da migração da opção antiga ----

    fun legacyNote(c: Context): LegacyMigration.Note = try {
        LegacyMigration.Note.values().getOrNull(prefs(c).getInt(KEY_LEGACY_NOTE, 0)) ?: LegacyMigration.Note.NONE
    } catch (_: Exception) {
        LegacyMigration.Note.NONE
    }

    fun setLegacyNote(c: Context, note: LegacyMigration.Note) {
        try { prefs(c).edit().putInt(KEY_LEGACY_NOTE, note.ordinal).apply() } catch (_: Exception) { }
    }

    private fun key(): SecretKey? = try {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey) ?: run {
            val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_HMAC_SHA256, "AndroidKeyStore")
            gen.init(KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN).build())
            gen.generateKey()
        }
    } catch (_: Exception) {
        null
    }

    private fun macOf(payload: String): String {
        val k = key() ?: return NO_KEYSTORE   // sem Keystore: fica só o armazenamento privado do app
        return try {
            val mac = Mac.getInstance("HmacSHA256")
            mac.init(k)
            mac.doFinal(payload.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
        } catch (_: Exception) {
            NO_KEYSTORE
        }
    }
}
