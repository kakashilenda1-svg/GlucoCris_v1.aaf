package com.agon.app.security

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Guarda o bloqueio da sessão. Vive enquanto a Activity vive (sobrevive a girar a tela); uma nova Activity ou um novo
 * processo (encerramento completo, reinício do aparelho, recriação pelo Android) cria um ViewModel novo e, com a proteção
 * ligada, nasce BLOQUEADO, sem olhar para nenhuma sessão anterior.
 * Começa bloqueado (falha fechando) até [init] ler a preferência, o que acontece antes da primeira tela.
 */
class SecurityViewModel : ViewModel() {
    private val lock = SessionLock()
    private val throttle = RecoveryThrottle()
    private val _locked = MutableStateFlow(true)
    val locked: StateFlow<Boolean> = _locked.asStateFlow()
    private var initialized = false
    private var lastFailure: AuthFailure? = null
    private val _message = MutableStateFlow("")
    val message: StateFlow<String> = _message.asStateFlow()

    /** @return true se esta é uma sessão NOVA (primeira vez neste ViewModel); false se só a tela foi recriada (ex.: girou). */
    fun init(required: Boolean): Boolean {
        if (initialized) return false
        initialized = true
        lock.start(required)
        _locked.value = lock.locked
        return true
    }

    fun onBackground(now: Long) = lock.onBackground(now)

    fun onForeground(now: Long, required: Boolean, relockMs: Long, stampValid: Boolean) {
        lock.onForeground(now, required, relockMs, stampValid)
        _locked.value = lock.locked
    }

    fun beginPrompt(auto: Boolean): Boolean = lock.beginPrompt(auto)

    fun onAuthSuccess() {
        lock.onSuccess()
        lastFailure = null
        _message.value = ""
        _locked.value = lock.locked
    }

    fun onAuthFailure(f: AuthFailure) {
        lock.onFailure()
        lastFailure = f
        _message.value = BiometricPolicy.lockMessage(f)
        _locked.value = lock.locked   // continua true
    }

    /** O prompt não chegou a abrir (ex.: já havia outra janela): libera o controle sem liberar o app. */
    fun onPromptNotShown() = lock.onFailure()

    fun needsEnroll(): Boolean = lastFailure == AuthFailure.NOT_ENROLLED

    /** Aviso informativo na tela de bloqueio (ex.: biometrias do Android mudaram). Não libera nem bloqueia nada. */
    fun showNotice(text: String) {
        if (_message.value.isBlank()) _message.value = text
    }

    // ---- recuperação por PIN (só quando a biometria do aparelho não funciona; ver BiometricPolicy.recoveryAllowed) ----

    fun recoveryTriesLeftSeconds(now: Long): Int = throttle.secondsLeft(now)

    /** @param pinOk o PIN digitado conferiu com o PIN já existente no app. */
    fun onRecoveryAttempt(now: Long, pinOk: Boolean): Boolean {
        if (!throttle.canTry(now)) return false
        if (!pinOk) {
            throttle.onFail(now)
            return false
        }
        throttle.onSuccess()
        onAuthSuccess()
        return true
    }

    fun canTryRecovery(now: Long): Boolean = throttle.canTry(now)
}
