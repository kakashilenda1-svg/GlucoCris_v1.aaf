package com.agon.app.security

/**
 * Estado de bloqueio da sessão (sem Android, testável). Regras:
 *  - TODA nova sessão (processo ou Activity novos, reinício do aparelho) com proteção ligada nasce BLOQUEADA: não existe
 *    tolerância de tempo para uma nova abertura ([start] não olha para nenhum relógio nem para sessões anteriores);
 *  - só [onSuccess] libera; cancelar, recusar, erro, voltar de tela ou recriar a tela NUNCA liberam;
 *  - ao voltar do segundo plano vale a política escolhida nas configurações ([RelockPolicy]): imediata ou após 30 s / 1 min / 5 min;
 *  - uma "marca de sessão" gravada fora da memória ([stampValid]) também é conferida ao voltar: se o processo ou a
 *    inicialização do aparelho mudaram, o app trava mesmo que algum estado em memória diga o contrário;
 *  - no máximo um pedido de biometria por vez; depois de cancelar/recusar, o pedido automático só volta numa nova ida ao
 *    segundo plano (o botão "Desbloquear" continua disponível), para não entrar em laço de janelas.
 */
class SessionLock {
    var locked: Boolean = true
        private set
    var promptInFlight: Boolean = false
        private set
    private var backgroundedAt: Long = NEVER
    private var autoPromptAllowed: Boolean = true

    fun start(required: Boolean) {
        locked = required
        promptInFlight = false
        backgroundedAt = NEVER
        autoPromptAllowed = true
    }

    fun onBackground(now: Long) {
        if (backgroundedAt == NEVER) backgroundedAt = now
    }

    /**
     * @param relockMs tempo fora do app a partir do qual voltar exige biometria (0 = sempre).
     * @param stampValid a marca de sessão guardada confere com este processo e esta inicialização do aparelho.
     * @return true se esta volta ao primeiro plano bloqueou a sessão.
     */
    fun onForeground(now: Long, required: Boolean, relockMs: Long, stampValid: Boolean = true): Boolean {
        val away = backgroundedAt
        backgroundedAt = NEVER
        if (!required) {
            locked = false
            return false
        }
        if (away != NEVER) autoPromptAllowed = true
        if (locked) return false
        val tooLong = away != NEVER && (relockMs <= 0L || now - away > relockMs)
        if (tooLong || !stampValid) {
            locked = true
            return true
        }
        return false
    }

    /** @param auto pedido automático (ao mostrar a tela); manual = toque em "Desbloquear". */
    fun beginPrompt(auto: Boolean): Boolean {
        if (!locked || promptInFlight) return false
        if (auto && !autoPromptAllowed) return false
        promptInFlight = true
        return true
    }

    fun onSuccess() {
        locked = false
        promptInFlight = false
        autoPromptAllowed = true
    }

    /** Cancelado, recusado ou com erro: continua bloqueado. */
    fun onFailure() {
        promptInFlight = false
        autoPromptAllowed = false
    }

    private companion object {
        const val NEVER = -1L
    }
}

/**
 * Marca da sessão desbloqueada, guardada fora da memória do app: "[token do processo]|[contagem de inicializações do aparelho]".
 * O token muda a cada novo processo e a contagem muda a cada reinício; por isso uma marca de outro processo ou de antes
 * de um reinício nunca vale como sessão aberta.
 */
object SessionStamp {
    fun make(processToken: String, bootCount: Int): String = "$processToken|$bootCount"

    fun isValid(stored: String?, current: String): Boolean = !stored.isNullOrEmpty() && stored == current
}

/** Limita tentativas de PIN de recuperação (só aparece quando a biometria do aparelho não funciona). */
class RecoveryThrottle(private val maxAttempts: Int = 5, private val lockMs: Long = 60_000L) {
    private var fails = 0
    private var blockedUntil = 0L

    fun canTry(now: Long): Boolean = now >= blockedUntil

    fun onFail(now: Long) {
        fails += 1
        if (fails >= maxAttempts) {
            fails = 0
            blockedUntil = now + lockMs
        }
    }

    fun onSuccess() {
        fails = 0
        blockedUntil = 0L
    }

    fun secondsLeft(now: Long): Int = if (now >= blockedUntil) 0 else ((blockedUntil - now + 999L) / 1000L).toInt()
}
