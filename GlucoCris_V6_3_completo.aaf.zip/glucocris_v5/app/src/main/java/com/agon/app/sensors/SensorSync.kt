package com.agon.app.sensors

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.agon.app.cloud.SyncMerge
import com.agon.app.data.AppData
import com.agon.app.data.GlucoStorage
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.GlucoseEntry
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.KeyStore
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.TimeUnit
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Uma leitura de sensor (sempre em mg/dL). */
data class SensorReading(val at: Long, val mg: Double, val trend: String = "")

/** Guarda senhas cifradas com uma chave do Android Keystore (a chave nunca sai do aparelho). */
object SecretBox {
    private const val ALIAS = "gluco_sensor_key_v1"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        kg.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .build(),
        )
        return kg.generateKey()
    }

    fun encrypt(plain: String): String {
        if (plain.isEmpty()) return ""
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, key())
            val out = c.iv + c.doFinal(plain.toByteArray(Charsets.UTF_8))
            Base64.encodeToString(out, Base64.NO_WRAP)
        } catch (_: Exception) {
            ""
        }
    }

    fun decrypt(text: String): String {
        if (text.isEmpty()) return ""
        return try {
            val raw = Base64.decode(text, Base64.NO_WRAP)
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, raw, 0, 12))
            String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
        } catch (_: Exception) {
            ""
        }
    }
}

/** Configuração do sensor (fica só neste aparelho; senhas cifradas). */
object SensorConfig {
    private const val PREFS = "gluco_sensor_v1"
    const val NONE = "none"
    const val NIGHTSCOUT = "nightscout"
    const val DEXCOM = "dexcom"
    const val LIBRE = "libre"

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun provider(ctx: Context): String = sp(ctx).getString("provider", NONE) ?: NONE
    fun setProvider(ctx: Context, v: String) = sp(ctx).edit().putString("provider", v).apply()

    fun url(ctx: Context): String = sp(ctx).getString("ns_url", "") ?: ""
    fun setUrl(ctx: Context, v: String) = sp(ctx).edit().putString("ns_url", v.trim()).apply()
    fun token(ctx: Context): String = SecretBox.decrypt(sp(ctx).getString("ns_token", "") ?: "")
    fun setToken(ctx: Context, v: String) = sp(ctx).edit().putString("ns_token", SecretBox.encrypt(v.trim())).apply()

    fun user(ctx: Context, p: String): String = sp(ctx).getString("user_$p", "") ?: ""
    fun setUser(ctx: Context, p: String, v: String) = sp(ctx).edit().putString("user_$p", v.trim()).apply()
    fun pass(ctx: Context, p: String): String = SecretBox.decrypt(sp(ctx).getString("pass_$p", "") ?: "")
    fun setPass(ctx: Context, p: String, v: String) = sp(ctx).edit().putString("pass_$p", SecretBox.encrypt(v)).apply()

    /** Dexcom: "ous" (fora dos EUA, inclui o Brasil) ou "us". */
    fun dexRegion(ctx: Context): String = sp(ctx).getString("dex_region", "ous") ?: "ous"
    fun setDexRegion(ctx: Context, v: String) = sp(ctx).edit().putString("dex_region", v).apply()

    fun autoOn(ctx: Context): Boolean = sp(ctx).getBoolean("auto", false)
    fun setAutoOn(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("auto", v).apply()

    fun lastSync(ctx: Context): Long = sp(ctx).getLong("last_sync", 0L)
    fun lastMsg(ctx: Context): String = sp(ctx).getString("last_msg", "") ?: ""
    fun lastValue(ctx: Context): Double = sp(ctx).getFloat("last_value", 0f).toDouble()
    fun lastTrend(ctx: Context): String = sp(ctx).getString("last_trend", "") ?: ""
    fun lastReadingAt(ctx: Context): Long = sp(ctx).getLong("last_reading_at", 0L)
    fun saveResult(ctx: Context, msg: String, latest: SensorReading? = null) {
        val e = sp(ctx).edit().putLong("last_sync", System.currentTimeMillis()).putString("last_msg", msg)
        if (latest != null) e.putFloat("last_value", latest.mg.toFloat()).putString("last_trend", latest.trend).putLong("last_reading_at", latest.at)
        e.apply()
    }

    fun isConfigured(ctx: Context): Boolean = when (provider(ctx)) {
        NIGHTSCOUT -> url(ctx).isNotBlank()
        DEXCOM -> user(ctx, DEXCOM).isNotBlank() && pass(ctx, DEXCOM).isNotBlank()
        LIBRE -> user(ctx, LIBRE).isNotBlank() && pass(ctx, LIBRE).isNotBlank()
        else -> false
    }
}

class SensorException(message: String) : Exception(message)

/**
 * Leitura de sensores por três caminhos:
 *  - Nightscout (serve o FreeStyle Libre via xDrip+/Juggluco/Nightscout e o Dexcom): API pública e estável;
 *  - Dexcom Share (login da conta Dexcom com o compartilhamento "Share" ligado);
 *  - LibreLinkUp (conta de seguidor do FreeStyle Libre).
 * Dexcom Share e LibreLinkUp são serviços não oficiais para apps de terceiros: podem mudar sem aviso.
 */
object SensorClient {
    private const val DEX_APP_ID = "d89443d2-327c-4a6f-89e5-496bbb0317db"
    private const val LIBRE_VERSION = "4.16.0"

    private fun http(
        method: String,
        url: String,
        headers: Map<String, String> = emptyMap(),
        body: String? = null,
        timeoutMs: Int = 20_000,
    ): Pair<Int, String> {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = method
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.setRequestProperty("Accept", "application/json")
            headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
            if (body != null) {
                c.doOutput = true
                if (!headers.containsKey("Content-Type")) c.setRequestProperty("Content-Type", "application/json")
                c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val stream = if (code in 200..299) c.inputStream else (c.errorStream ?: c.inputStream)
            val text = try { stream.bufferedReader(Charsets.UTF_8).use { it.readText() } } catch (_: Exception) { "" }
            return code to text
        } finally {
            c.disconnect()
        }
    }

    private fun sha1(s: String) = MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun sha256(s: String) = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

    suspend fun fetch(ctx: Context): List<SensorReading> = withContext(Dispatchers.IO) {
        when (SensorConfig.provider(ctx)) {
            SensorConfig.NIGHTSCOUT -> nightscout(SensorConfig.url(ctx), SensorConfig.token(ctx))
            SensorConfig.DEXCOM -> dexcom(SensorConfig.user(ctx, SensorConfig.DEXCOM), SensorConfig.pass(ctx, SensorConfig.DEXCOM), SensorConfig.dexRegion(ctx))
            SensorConfig.LIBRE -> libre(SensorConfig.user(ctx, SensorConfig.LIBRE), SensorConfig.pass(ctx, SensorConfig.LIBRE))
            else -> throw SensorException("Escolha um sensor primeiro.")
        }
    }

    // ───── Nightscout ─────
    private fun nightscout(rawUrl: String, secret: String): List<SensorReading> {
        var base = rawUrl.trim().trimEnd('/')
        if (base.isBlank()) throw SensorException("Informe o endereço do Nightscout.")
        if (!base.startsWith("http")) base = "https://$base"
        val path = "/api/v1/entries/sgv.json?count=300"
        var res: Pair<Int, String>
        if (secret.isBlank()) {
            res = http("GET", base + path)
        } else {
            // Token de acesso (parâmetro ?token=) e, se recusado, API secret (cabeçalho com SHA-1).
            res = http("GET", base + path + "&token=" + URLEncoder.encode(secret, "UTF-8"))
            if (res.first == 401 || res.first == 403) {
                res = http("GET", base + path, mapOf("api-secret" to sha1(secret)))
            }
        }
        if (res.first == 401 || res.first == 403) throw SensorException("O Nightscout recusou o acesso. Confira o token ou o API secret.")
        if (res.first !in 200..299) throw SensorException("Nightscout respondeu com erro ${res.first}.")
        val arr = try { JSONArray(res.second) } catch (_: Exception) { throw SensorException("Resposta inesperada do Nightscout.") }
        val out = mutableListOf<SensorReading>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val sgv = o.optDouble("sgv", Double.NaN)
            val date = o.optLong("date", 0L)
            if (sgv.isNaN() || sgv <= 0 || date <= 0) continue
            out.add(SensorReading(date, sgv, o.optString("direction", "")))
        }
        if (out.isEmpty()) throw SensorException("O Nightscout não trouxe leituras recentes.")
        return out
    }

    // ───── Dexcom Share ─────
    private fun dexcom(user: String, pass: String, region: String): List<SensorReading> {
        if (user.isBlank() || pass.isBlank()) throw SensorException("Informe usuário e senha da conta Dexcom.")
        val base = if (region == "us") "https://share2.dexcom.com/ShareWebServices/Services" else "https://shareous1.dexcom.com/ShareWebServices/Services"
        val ua = mapOf("User-Agent" to "Dexcom Share/3.0.2.11 CFNetwork/672.0.2 Darwin/14.0.0")
        fun unquote(s: String) = s.trim().trim('"')
        val authBody = JSONObject().put("accountName", user).put("applicationId", DEX_APP_ID).put("password", pass).toString()
        val a = http("POST", "$base/General/AuthenticatePublisherAccount", ua, authBody)
        if (a.first !in 200..299) throw SensorException("Dexcom recusou o login (${a.first}). Confira usuário, senha e a região.")
        val accountId = unquote(a.second)
        if (accountId.isBlank() || accountId.startsWith("00000000")) throw SensorException("Login Dexcom inválido.")
        val loginBody = JSONObject().put("accountId", accountId).put("applicationId", DEX_APP_ID).put("password", pass).toString()
        val l = http("POST", "$base/General/LoginPublisherAccountById", ua, loginBody)
        if (l.first !in 200..299) throw SensorException("Dexcom não abriu a sessão (${l.first}).")
        val session = unquote(l.second)
        if (session.isBlank() || session.startsWith("00000000")) throw SensorException("Sessão Dexcom inválida. Ligue o compartilhamento (Share) no app Dexcom.")
        val r = http("POST", "$base/Publisher/ReadPublisherLatestGlucoseValues?sessionId=$session&minutes=1440&maxCount=288", ua, "")
        if (r.first !in 200..299) throw SensorException("Dexcom não entregou as leituras (${r.first}).")
        val arr = try { JSONArray(r.second) } catch (_: Exception) { throw SensorException("Resposta inesperada da Dexcom.") }
        val dateRx = Regex("""\d{10,}""")
        val out = mutableListOf<SensorReading>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val v = o.optDouble("Value", Double.NaN)
            val ts = dateRx.find(o.optString("WT", o.optString("ST", "")))?.value?.toLongOrNull() ?: continue
            if (v.isNaN() || v <= 0) continue
            out.add(SensorReading(ts, v, o.optString("Trend", "")))
        }
        if (out.isEmpty()) throw SensorException("A Dexcom não trouxe leituras nas últimas 24 h.")
        return out
    }

    // ───── FreeStyle Libre (LibreLinkUp) ─────
    private fun libreHeaders(token: String? = null, accountId: String? = null): Map<String, String> {
        val h = linkedMapOf(
            "product" to "llu.android",
            "version" to LIBRE_VERSION,
            "Cache-Control" to "no-cache",
            "User-Agent" to "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36",
        )
        if (token != null) h["Authorization"] = "Bearer $token"
        if (accountId != null) h["Account-Id"] = accountId
        return h
    }

    private fun libre(email: String, pass: String): List<SensorReading> {
        if (email.isBlank() || pass.isBlank()) throw SensorException("Informe e-mail e senha do LibreLinkUp.")
        var base = "https://api.libreview.io"
        val loginBody = JSONObject().put("email", email).put("password", pass).toString()
        var login = http("POST", "$base/llu/auth/login", libreHeaders(), loginBody)
        var root = try { JSONObject(login.second) } catch (_: Exception) { throw SensorException("Resposta inesperada do LibreLinkUp (${login.first}).") }
        val region = root.optJSONObject("data")?.takeIf { it.optBoolean("redirect", false) }?.optString("region", "").orEmpty()
        if (region.isNotBlank()) {
            base = "https://api-$region.libreview.io"
            login = http("POST", "$base/llu/auth/login", libreHeaders(), loginBody)
            root = try { JSONObject(login.second) } catch (_: Exception) { throw SensorException("Resposta inesperada do LibreLinkUp (${login.first}).") }
        }
        val status = root.optInt("status", 0)
        if (status == 920) throw SensorException("O LibreLinkUp exige uma versão mais nova do protocolo. Será preciso atualizar o app.")
        val data = root.optJSONObject("data")
        val ticket = data?.optJSONObject("authTicket")?.optString("token").orEmpty()
        val userId = data?.optJSONObject("user")?.optString("id").orEmpty()
        if (login.first !in 200..299 || ticket.isBlank()) {
            throw SensorException("LibreLinkUp recusou o login. Use a conta de SEGUIDOR (LibreLinkUp) e confira e-mail e senha.")
        }
        val acct = if (userId.isNotBlank()) sha256(userId) else null
        val conns = http("GET", "$base/llu/connections", libreHeaders(ticket, acct))
        if (conns.first !in 200..299) throw SensorException("LibreLinkUp não listou as conexões (${conns.first}).")
        val list = JSONObject(conns.second).optJSONArray("data")
        val patientId = list?.optJSONObject(0)?.optString("patientId").orEmpty()
        if (patientId.isBlank()) throw SensorException("Nenhum sensor compartilhado nessa conta. No app FreeStyle Libre, compartilhe com o LibreLinkUp e aceite o convite.")
        val g = http("GET", "$base/llu/connections/$patientId/graph", libreHeaders(ticket, acct))
        if (g.first !in 200..299) throw SensorException("LibreLinkUp não entregou as leituras (${g.first}).")
        val conn = JSONObject(g.second).optJSONObject("data") ?: throw SensorException("Resposta inesperada do LibreLinkUp.")
        val fmt = SimpleDateFormat("M/d/yyyy h:mm:ss a", Locale.US).apply { timeZone = TimeZone.getTimeZone("UTC") }
        fun parse(o: JSONObject): SensorReading? {
            val v = o.optDouble("ValueInMgPerDl", Double.NaN)
            val ts = o.optString("FactoryTimestamp", "")
            if (v.isNaN() || v <= 0 || ts.isBlank()) return null
            val t = try { fmt.parse(ts)?.time } catch (_: Exception) { null } ?: return null
            return SensorReading(t, v, "")
        }
        val out = mutableListOf<SensorReading>()
        val graph = conn.optJSONArray("graphData")
        if (graph != null) for (i in 0 until graph.length()) graph.optJSONObject(i)?.let { o -> parse(o)?.let { out.add(it) } }
        conn.optJSONObject("connection")?.optJSONObject("glucoseMeasurement")?.let { o ->
            val trendArrow = o.optInt("TrendArrow", 0)
            parse(o)?.let { out.add(it.copy(trend = libreTrend(trendArrow))) }
        }
        if (out.isEmpty()) throw SensorException("O LibreLinkUp não trouxe leituras.")
        return out
    }

    private fun libreTrend(a: Int) = when (a) {
        1 -> "SingleDown"; 2 -> "FortyFiveDown"; 3 -> "Flat"; 4 -> "FortyFiveUp"; 5 -> "SingleUp"; else -> ""
    }

    fun trendArrow(t: String): String = when (t.lowercase().replace("_", "")) {
        "doubleup" -> "⇈"
        "singleup" -> "↑"
        "fortyfiveup" -> "↗"
        "flat" -> "→"
        "fortyfivedown" -> "↘"
        "singledown" -> "↓"
        "doubledown" -> "⇊"
        else -> ""
    }
}

object SensorImporter {
    private const val BUCKET_MS = 15 * 60_000L

    /** Uma leitura a cada 15 min (mais a mais recente) para não lotar o histórico; ids fixos evitam duplicar. */
    fun toEntries(provider: String, readings: List<SensorReading>, data: AppData?): List<GlucoseEntry> {
        if (readings.isEmpty()) return emptyList()
        val label = when (provider) {
            SensorConfig.DEXCOM -> "Sensor Dexcom"
            SensorConfig.LIBRE -> "Sensor FreeStyle Libre"
            else -> "Sensor (Nightscout)"
        }
        val sorted = readings.sortedBy { it.at }
        val latest = sorted.last()
        val picked = sorted.groupBy { it.at / BUCKET_MS }.values.map { it.last() }.toMutableList()
        if (picked.none { it.at == latest.at }) picked.add(latest)
        val known = data?.glucose?.map { it.id }?.toSet() ?: emptySet()
        val deleted = data?.tombstones?.filter { it.col == SyncMerge.GLUCOSE }?.map { it.id }?.toSet() ?: emptySet()
        val now = System.currentTimeMillis()
        return picked.mapNotNull { r ->
            if (r.at > now + 5 * 60_000L) return@mapNotNull null
            val id = "sensor-$provider-${r.at / 60_000L}"
            if (id in known || id in deleted) return@mapNotNull null
            GlucoseEntry(id, Math.round(r.mg).toDouble(), "mg/dL", r.at, "outro", label, now, now)
        }
    }

    /** Sincroniza uma vez: busca, grava no app (pela tela aberta ou direto no armazenamento) e avisa o cuidador se preciso. */
    suspend fun syncOnce(ctx: Context): Result<Int> {
        val app = ctx.applicationContext
        return try {
            val provider = SensorConfig.provider(app)
            val readings = SensorClient.fetch(app)
            val latest = readings.maxByOrNull { it.at }
            val live = GlucoViewModel.liveInstance()
            val added: Int
            if (live != null) {
                val entries = toEntries(provider, readings, live.data.value)
                withContext(Dispatchers.Main) { live.importSensorEntries(entries) }
                added = entries.size
            } else {
                val data = GlucoStorage.read(app)
                val entries = toEntries(provider, readings, data)
                if (data != null && entries.isNotEmpty()) {
                    GlucoStorage.write(app, data.copy(glucose = (entries + data.glucose).sortedByDescending { it.at }))
                }
                added = entries.size
            }
            if (latest != null) {
                com.agon.app.reminders.Caregiver.onNewGlucose(app, latest.mg, latest.at, live?.data?.value?.settings?.displayName.orEmpty())
            }
            SensorConfig.saveResult(app, if (added > 0) "$added leitura(s) nova(s) importada(s)." else "Tudo em dia, sem leituras novas.", latest)
            Result.success(added)
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: SensorException) {
            SensorConfig.saveResult(app, e.message ?: "Falha ao ler o sensor.")
            Result.failure(e)
        } catch (e: Exception) {
            val msg = "Sem conexão ou falha ao ler o sensor."
            SensorConfig.saveResult(app, msg)
            Result.failure(SensorException(msg))
        }
    }
}

class SensorSyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        if (!SensorConfig.autoOn(applicationContext) || !SensorConfig.isConfigured(applicationContext)) return Result.success()
        SensorImporter.syncOnce(applicationContext)
        return Result.success()
    }
}

object SensorSyncScheduler {
    private const val NAME = "gluco_sensor_sync"

    fun refresh(ctx: Context) {
        try {
            val wm = WorkManager.getInstance(ctx.applicationContext)
            if (SensorConfig.autoOn(ctx) && SensorConfig.isConfigured(ctx)) {
                val req = PeriodicWorkRequestBuilder<SensorSyncWorker>(15, TimeUnit.MINUTES)
                    .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                    .build()
                wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
            } else {
                wm.cancelUniqueWork(NAME)
            }
        } catch (_: Exception) {
        }
    }
}
