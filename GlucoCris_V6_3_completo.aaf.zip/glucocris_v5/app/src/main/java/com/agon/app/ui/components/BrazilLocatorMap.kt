package com.agon.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.insulin.City
import com.agon.app.data.insulin.SupplyPoint
import com.agon.app.ui.theme.glucoColors
import kotlin.math.abs

/**
 * Mapa esquemático do Brasil com pontos verdes nas cidades dos resultados.
 * Projeção simples lat/lon → canvas (bounding box do Brasil).
 */
@Composable
fun BrazilLocatorMap(
    points: List<SupplyPoint>,
    selectedCityId: String?,
    onCityClick: (City) -> Unit,
    modifier: Modifier = Modifier,
) {
    val g = glucoColors()
    // Bounding box aproximado do Brasil
    val latMin = -33.8
    val latMax = 5.3
    val lonMin = -74.0
    val lonMax = -34.7

    val cities = remember(points) {
        points.map { it.city }.distinctBy { it.id }
    }

    // Contorno simplificado do Brasil (pontos lon,lat em ordem)
    val outline = remember {
        listOf(
            -51.0 to 4.5, -50.0 to 1.5, -48.5 to -0.5, -44.0 to -1.5,
            -41.5 to -3.0, -38.5 to -4.5, -37.0 to -7.5, -34.9 to -7.0,
            -34.8 to -9.5, -37.5 to -12.5, -38.5 to -15.0, -39.0 to -17.5,
            -40.5 to -20.0, -40.0 to -22.5, -43.0 to -23.0, -44.5 to -23.5,
            -48.0 to -25.5, -48.5 to -28.0, -49.5 to -29.5, -51.5 to -32.0,
            -53.5 to -33.5, -57.0 to -30.5, -57.5 to -27.5, -58.0 to -25.0,
            -57.5 to -22.0, -56.0 to -20.0, -58.0 to -16.0, -60.0 to -13.5,
            -62.5 to -11.0, -65.0 to -9.5, -68.0 to -10.5, -70.5 to -9.0,
            -72.5 to -8.0, -73.5 to -7.0, -70.0 to -4.0, -67.0 to -2.0,
            -64.0 to 0.0, -60.0 to 1.5, -56.0 to 2.5, -54.0 to 4.0,
            -51.0 to 4.5,
        )
    }

    fun project(lon: Double, lat: Double, w: Float, h: Float): Offset {
        val x = ((lon - lonMin) / (lonMax - lonMin) * w).toFloat()
        val y = ((latMax - lat) / (latMax - latMin) * h).toFloat()
        return Offset(x, y)
    }

    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0xFFD4DDD4))
            .border(1.dp, g.line, RoundedCornerShape(14.dp))
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(180.dp)
                .pointerInput(cities) {
                    detectTapGestures { offset ->
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()
                        // Acha cidade mais próxima do toque
                        var best: City? = null
                        var bestDist = 40f
                        for (c in cities) {
                            val p = project(c.lon, c.lat, w, h)
                            val d = abs(p.x - offset.x) + abs(p.y - offset.y)
                            if (d < bestDist) {
                                bestDist = d
                                best = c
                            }
                        }
                        best?.let { onCityClick(it) }
                    }
                }
        ) {
            Canvas(Modifier.fillMaxWidth().height(180.dp).padding(8.dp)) {
                val w = size.width
                val h = size.height

                // Contorno
                val path = Path()
                outline.forEachIndexed { i, (lon, lat) ->
                    val o = project(lon, lat, w, h)
                    if (i == 0) path.moveTo(o.x, o.y) else path.lineTo(o.x, o.y)
                }
                path.close()
                drawPath(path, Color(0xFFB8C9B8))
                drawPath(path, Color(0xFF2E7D32), style = Stroke(width = 2.5f))

                // Pontos das cidades
                for (c in cities) {
                    val o = project(c.lon, c.lat, w, h)
                    val selected = c.id == selectedCityId
                    val radius = if (selected) 7f else 4.5f
                    val color = if (selected) Color(0xFF1B5E20) else Color(0xFF2E7D32)
                    drawCircle(color, radius = radius, center = o)
                    if (selected) {
                        drawCircle(Color(0xFF81C784), radius = radius + 4f, center = o, style = Stroke(width = 2f))
                    }
                }
            }
        }
        if (cities.isNotEmpty()) {
            Text(
                "${cities.size} municípios nos resultados · toque em um ponto",
                fontSize = 11.sp,
                color = g.muted,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            )
        }
    }
}
