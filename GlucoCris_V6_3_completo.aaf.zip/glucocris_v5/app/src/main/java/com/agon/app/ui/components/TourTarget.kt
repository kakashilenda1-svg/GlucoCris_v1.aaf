package com.agon.app.ui.components

import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned

/** Posição na tela dos elementos que o tour pode destacar. */
object TourRegistry {
    val rects = mutableStateMapOf<String, Rect>()
}

/** Marca um elemento da tela para o tour inteligente poder apontar para ele. Não muda o visual. */
fun Modifier.tourTarget(id: String): Modifier = composed {
    DisposableEffect(id) { onDispose { TourRegistry.rects.remove(id) } }
    onGloballyPositioned { c ->
        if (c.isAttached) {
            val r = c.boundsInRoot()
            if (TourRegistry.rects[id] != r) TourRegistry.rects[id] = r
        }
    }
}
