package com.agon.app.ui.screens

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.localai.CrisImageLoader
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Foto e fontes de uma resposta da Cris que usou a internet.
 * [media] vem de CrisWebSearch.mediaOf: linhas "IMG<TAB>url" e "SRC<TAB>nome<TAB>url".
 */
@Composable
internal fun CrisMediaBlock(media: String) {
    val g = glucoColors()
    val context = LocalContext.current
    val rows = remember(media) { media.lines().map { it.split('\t') } }
    val img = remember(media) { rows.firstOrNull { it.size >= 2 && it[0] == "IMG" }?.get(1) }
    val srcs = remember(media) { rows.filter { it.size >= 3 && it[0] == "SRC" }.map { it[1] to it[2] } }

    if (img != null) {
        val bmp by produceState<Bitmap?>(initialValue = null, img) {
            value = withContext(Dispatchers.IO) { CrisImageLoader.load(img) }
        }
        val b = bmp
        if (b != null) {
            Image(
                bitmap = b.asImageBitmap(),
                contentDescription = "Foto",
                contentScale = ContentScale.Crop,
                modifier = Modifier.padding(top = 8.dp).fillMaxWidth().height(200.dp).clip(RoundedCornerShape(14.dp)),
            )
            Text("Foto: Wikimedia Commons", color = g.muted, fontSize = 10.sp, modifier = Modifier.padding(top = 2.dp))
        }
    }
    if (srcs.isNotEmpty()) {
        Row(
            Modifier.padding(top = 8.dp).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            srcs.forEach { (name, url) ->
                Text(
                    name,
                    color = g.violet,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(g.lilacSoft)
                        .clickable {
                            if (url.startsWith("https://")) {
                                try {
                                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                } catch (_: Exception) {
                                }
                            }
                        }
                        .padding(horizontal = 10.dp, vertical = 5.dp),
                )
            }
        }
    }
}
