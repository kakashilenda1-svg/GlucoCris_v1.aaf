package com.agon.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import com.agon.app.localai.CrisConnectivityManager
import com.agon.app.localai.LocalAiSettings
import com.agon.app.localai.LocalModelManager
import com.agon.app.localai.LocalModelSpec
import com.agon.app.localai.LocalModels
import com.agon.app.localai.ModelAdvisor
import com.agon.app.localai.ModelCheck
import com.agon.app.localai.ModelGate
import com.agon.app.localai.ModelState
import com.agon.app.localai.SelectResult
import com.agon.app.ui.theme.glucoColors

private fun isMetered(context: android.content.Context): Boolean = try {
    (context.applicationContext.getSystemService(android.content.Context.CONNECTIVITY_SERVICE) as ConnectivityManager).isActiveNetworkMetered
} catch (_: Exception) {
    true
}

/**
 * Tela de escolha da IA local, exibida (1) na instalação nova, antes do login, e (2) para quem atualizou o app e ainda
 * não tem um modelo compatível. A mesma escolha existe depois em Configurações da Cris IA > Trocar modelo.
 *
 * [mandatory] = instalação nova em aparelho capaz: só libera o app com o modelo pronto. Mesmo assim, se o download
 * falhar ou não houver internet, aparece "Continuar sem a IA por enquanto". Nos demais casos há sempre "Agora não".
 */
@Composable
fun CrisModelGateScreen(reason: ModelGate.Reason, mandatory: Boolean, onDone: () -> Unit) {
    val g = glucoColors()
    val context = LocalContext.current
    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }
    Column(
        Modifier.fillMaxSize().background(g.bg).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(12.dp))
        Text(
            when (reason) {
                ModelGate.Reason.NO_MODEL -> "Escolha a IA da Cris ❤️"
                ModelGate.Reason.DAMAGED -> "Vamos reinstalar a IA da Cris ❤️"
                ModelGate.Reason.INCOMPATIBLE -> "Vamos ajustar a IA da Cris ❤️"
            },
            color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            when (reason) {
                ModelGate.Reason.NO_MODEL ->
                    "Para a Cris conversar com você até sem internet, o aparelho guarda uma IA local. Escolha a que combina com o seu aparelho. É só uma vez."
                ModelGate.Reason.DAMAGED ->
                    "O arquivo da IA local que estava neste aparelho está incompleto ou danificado. Escolha qual instalar de novo."
                ModelGate.Reason.INCOMPATIBLE ->
                    "A IA local instalada é pesada demais para este aparelho. Escolha uma opção que funcione bem. Seus dados e conversas não mudam."
            },
            color = g.muted, fontSize = 14.sp, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(16.dp))
        ModelChooserPanel(
            allowSkip = !mandatory,
            onSkip = {
                LocalAiSettings.setChooserDismissedVersion(context, com.agon.app.BuildConfig.VERSION_CODE)
                onDone()
            },
            onInstalled = onDone,
            onGiveUpOffline = if (mandatory) ({
                LocalAiSettings.setChooserDismissedVersion(context, com.agon.app.BuildConfig.VERSION_CODE)
                onDone()
            }) else null,
        )
    }
}

/** Rota de Configurações da Cris IA > Trocar modelo. */
@Composable
fun CrisModelChooserScreen(nav: NavHostController) {
    val g = glucoColors()
    Column(Modifier.fillMaxSize().background(g.bg)) {
        Row(Modifier.fillMaxWidth().background(g.card).padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = g.ink) }
            Text("Trocar modelo da IA", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp)) {
            Text(
                "Você pode mudar quando quiser. O modelo que você usa hoje só é removido depois que o novo for baixado, conferido e instalado. " +
                    "Suas conversas, memórias e configurações da Cris não são alteradas.",
                color = g.muted, fontSize = 13.sp,
            )
            Spacer(Modifier.height(12.dp))
            ModelChooserPanel(allowSkip = false, onSkip = {}, onInstalled = {}, onGiveUpOffline = null)
        }
    }
}

/**
 * Cartões das duas opções (leve e potente) com tamanho, RAM, vantagens e estado, mais o progresso do download com
 * Pausar / Continuar / Tentar de novo / Cancelar. O download roda no WorkManager (continua com o app fechado).
 */
@Composable
fun ModelChooserPanel(
    allowSkip: Boolean,
    onSkip: () -> Unit,
    onInstalled: () -> Unit,
    onGiveUpOffline: (() -> Unit)?,
) {
    val g = glucoColors()
    val context = LocalContext.current
    val mgr = remember { LocalModelManager.get(context) }
    val state by mgr.state.collectAsState()
    val online by remember { CrisConnectivityManager.observe(context) }
        .collectAsState(initial = CrisConnectivityManager.isOnline(context))
    val metered = remember(online) { isMetered(context) }
    val advice = remember { ModelAdvisor.advise(context) }

    var refreshTick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { mgr.refresh(); refreshTick++ }
    // Recalcula "em uso / instalado" sempre que o estado muda
    val active = remember(state, refreshTick) { mgr.activeSpec }
    var info by remember { mutableStateOf<String?>(null) }
    var pendingInstall by remember { mutableStateOf<LocalModelSpec?>(null) }
    var awaiting by remember { mutableStateOf(state !is ModelState.Ready && state !is ModelState.Missing) }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }

    fun doSelect(spec: LocalModelSpec, allowMetered: Boolean) {
        // Notificação do download (Android 13+): pede uma vez; o download funciona mesmo se a pessoa negar.
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            val sp = context.getSharedPreferences("cris_model_ui", android.content.Context.MODE_PRIVATE)
            if (!sp.getBoolean("asked_notif", false)) {
                sp.edit().putBoolean("asked_notif", true).apply()
                notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        when (val r = mgr.select(spec, allowMetered)) {
            SelectResult.Activated -> { info = "Pronto! A Cris agora usa a ${spec.tierName.lowercase()}. 💜"; onInstalled() }
            SelectResult.Started -> { info = null; awaiting = true }
            is SelectResult.NoSpace -> info = null // a mensagem detalhada aparece no estado "Falhou"
        }
    }

    fun requestInstall(spec: LocalModelSpec) {
        if (online && metered) pendingInstall = spec else doSelect(spec, allowMetered = false)
    }

    LaunchedEffect(state) {
        if (awaiting && state is ModelState.Ready) {
            awaiting = false
            info = "Tudo pronto! 💜 A IA local está instalada."
            onInstalled()
        }
    }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        advice.warnings.forEach { Text("⚠️ $it", color = g.red, fontSize = 12.sp) }

        LocalModels.ALL.forEach { spec ->
            val recommended = advice.canRunAny && advice.recommended.id == spec.id
            val check = mgr.inspect(spec)
            val installed = check == ModelCheck.OK
            val isActive = active?.id == spec.id
            val target = mgr.targetSpec?.id == spec.id
            val busy = state is ModelState.Downloading || state is ModelState.Verifying
            val warn = remember(spec.id, state) { ModelAdvisor.manualWarning(context, spec) }

            Column(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(g.card).padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(spec.tierName, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    when {
                        isActive -> Text("Em uso ✓", color = g.green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        installed -> Text("Instalada", color = g.green, fontSize = 12.sp)
                        recommended -> Text("Recomendada", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
                Text(spec.displayName.substringAfter("·").trim(), color = g.muted, fontSize = 12.sp)
                Text(
                    "Download: ${LocalModelManager.fmtBytes(spec.sizeBytes)} · RAM do aparelho: mínimo ${spec.minRamGb} GB, recomendado ${spec.recommendedRamGb} GB",
                    color = g.ink, fontSize = 13.sp,
                )
                spec.highlights.forEach { Text("• $it", color = g.muted, fontSize = 12.sp) }
                if (recommended) Text(advice.reason, color = g.violet, fontSize = 12.sp)
                if (warn != null) Text("⚠️ $warn", color = g.red, fontSize = 12.sp)
                if (check == ModelCheck.INCOMPLETE || check == ModelCheck.CORRUPT) {
                    Text("⚠️ O arquivo deste modelo no aparelho está incompleto ou danificado; será baixado de novo.", color = g.red, fontSize = 12.sp)
                }
                Spacer(Modifier.height(2.dp))
                when {
                    isActive -> OutlinedButton(onClick = {}, enabled = false) { Text("Manter esta (em uso)") }
                    installed -> Button(enabled = !busy, onClick = { doSelect(spec, allowMetered = false) }) { Text("Usar esta (já instalada)") }
                    target && state !is ModelState.Missing -> Text(
                        "Esta é a opção que está sendo instalada. Veja o andamento abaixo.", color = g.muted, fontSize = 12.sp,
                    )
                    else -> Button(enabled = !busy, onClick = { requestInstall(spec) }) {
                        Text((if (active != null) "Trocar para esta e instalar" else "Instalar") + " (${LocalModelManager.fmtBytes(spec.sizeBytes)})")
                    }
                }
                if (!installed && active != null) {
                    Text("Seu modelo atual continua funcionando até esta opção terminar de baixar e ser conferida.", color = g.muted, fontSize = 11.sp)
                }
            }
        }

        ModelDownloadStatusBlock(onRequestMeteredResume = { pendingInstall = mgr.targetSpec })

        info?.let { Text(it, color = g.green, fontSize = 13.sp, fontWeight = FontWeight.Bold) }
        Text("Livre no aparelho: ${LocalModelManager.fmtBytes(mgr.freeBytes())} · " + if (online) "online" else "sem internet", color = g.muted, fontSize = 12.sp)
        Text(
            "O download continua em segundo plano, com notificação, mesmo se você sair do app ou apagar a tela. Depois de instalada, a IA local funciona sem internet.",
            color = g.muted, fontSize = 12.sp,
        )

        if (!online && state is ModelState.Missing) {
            Text("Sem internet agora. Você pode escolher a opção; o download começa sozinho quando conectar ao Wi-Fi.", color = g.ink, fontSize = 13.sp)
        }
        if (allowSkip) {
            TextButton(onClick = onSkip, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                val inProgress = state is ModelState.Downloading || state is ModelState.Waiting || state is ModelState.Verifying
                Text(
                    when {
                        inProgress -> "Continuar usando o app (o download segue em segundo plano)"
                        active == null -> "Agora não (a Cris usa respostas básicas)"
                        else -> "Fechar"
                    },
                )
            }
        }
        if (onGiveUpOffline != null && (state is ModelState.Failed || (!online && state is ModelState.Missing))) {
            TextButton(onClick = onGiveUpOffline, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Continuar sem a IA por enquanto")
            }
        }
    }

    pendingInstall?.let { spec ->
        AlertDialog(
            onDismissRequest = { pendingInstall = null },
            title = { Text("Baixar com dados móveis?") },
            text = {
                Text(
                    "Você está usando dados móveis e o download é grande (${LocalModelManager.fmtBytes(spec.sizeBytes)}). " +
                        "Se preferir, o app espera você conectar ao Wi-Fi e baixa sozinho.",
                )
            },
            confirmButton = { TextButton(onClick = { pendingInstall = null; doSelect(spec, allowMetered = true) }) { Text("Baixar agora") } },
            dismissButton = { TextButton(onClick = { pendingInstall = null; doSelect(spec, allowMetered = false) }) { Text("Esperar o Wi-Fi") } },
        )
    }
}

/**
 * Andamento do download: tamanho baixado, percentual, velocidade e botões. Usado na tela de escolha e nas Configurações da IA.
 * Não mostra nada quando não há download em andamento, pausado, aguardando ou com falha.
 */
@Composable
fun ModelDownloadStatusBlock(onRequestMeteredResume: () -> Unit = {}) {
    val g = glucoColors()
    val context = LocalContext.current
    val mgr = remember { LocalModelManager.get(context) }
    val state by mgr.state.collectAsState()
    val speed by mgr.speedBytesPerSec.collectAsState()
    val target = mgr.targetSpec
    val label = target?.tierName ?: ""

    fun frac(done: Long, total: Long) = if (total > 0) (done.toFloat() / total).coerceIn(0f, 1f) else 0f

    when (val st = state) {
        is ModelState.Downloading -> Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Baixando $label…", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            LinearProgressIndicator(progress = { frac(st.done, st.total) }, modifier = Modifier.fillMaxWidth())
            Text(
                "${LocalModelManager.fmtBytes(st.done)} de ${LocalModelManager.fmtBytes(st.total)} (${(frac(st.done, st.total) * 100).toInt()}%)" +
                    if (speed > 0) " · ${LocalModelManager.fmtBytes(speed)}/s" else "",
                color = g.ink, fontSize = 13.sp,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { mgr.pause() }) { Text("Pausar") }
                OutlinedButton(onClick = { mgr.cancel() }) { Text("Cancelar") }
            }
        }
        is ModelState.Waiting -> Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Download na fila: $label", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            LinearProgressIndicator(progress = { frac(st.done, st.total) }, modifier = Modifier.fillMaxWidth())
            Text(
                "${LocalModelManager.fmtBytes(st.done)} de ${LocalModelManager.fmtBytes(st.total)}. ${st.note} " +
                    "Começa sozinho quando houver Wi-Fi (ou conexão, se você autorizou dados móveis).",
                color = g.muted, fontSize = 12.sp,
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { mgr.pause() }) { Text("Pausar") }
                OutlinedButton(onClick = { mgr.cancel() }) { Text("Cancelar") }
            }
        }
        is ModelState.Paused -> Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Download pausado: $label", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            LinearProgressIndicator(progress = { frac(st.done, st.total) }, modifier = Modifier.fillMaxWidth())
            Text("Pausado em ${LocalModelManager.fmtBytes(st.done)} de ${LocalModelManager.fmtBytes(st.total)}. O que já foi baixado fica guardado.", color = g.ink, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    val meteredNow = isMetered(context) && CrisConnectivityManager.isOnline(context)
                    if (meteredNow && !LocalAiSettings.allowMeteredDownload(context)) onRequestMeteredResume() else mgr.start()
                }) { Text("Continuar") }
                OutlinedButton(onClick = { mgr.cancel() }) { Text("Cancelar") }
            }
        }
        ModelState.Verifying -> Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
            Text("Conferindo se o arquivo está íntegro e instalando…", color = g.ink, fontSize = 13.sp)
        }
        is ModelState.Failed -> Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(st.message, color = g.red, fontSize = 13.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { mgr.start() }) { Text("Tentar de novo") }
                OutlinedButton(onClick = { mgr.cancel() }) { Text("Descartar") }
            }
        }
        ModelState.Missing, ModelState.Ready -> {}
    }
}
