package com.agon.app.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import com.agon.app.data.CrisChatLine
import com.agon.app.data.CrisMemory
import com.agon.app.data.CrisPrefs
import com.agon.app.data.CrisSpeaker
import com.agon.app.data.GlucoViewModel
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

// Cores do modo voz — fixas (iguais no tema claro e escuro, como na referência).
private val V_BG_CENTER = Color(0xFF0E4A2A)
private val V_BG_EDGE = Color(0xFF03140B)
private val V_GRID = Color(0x1A6EE7A8)
private val V_DOT = Color(0xFF7CF5B5)
private val V_DOT_BLUE = Color(0xFF4F8BFF)
private val V_ACCENT = Color(0xFF22E07A)
private val V_TEXT = Color(0xFFF2FFF7)
private val V_MUTED = Color(0xFF9CC9AE)
private val V_PANEL = Color(0xFF2F5E45)

private enum class VoicePhase { IDLE, LISTENING, THINKING, SPEAKING }

private class SpherePoint(val x: Float, val y: Float, val z: Float, val lon: Float, val blue: Boolean)

private val SPHERE: List<SpherePoint> = run {
    val n = 560
    val golden = PI * (3 - sqrt(5.0))
    (0 until n).map { i ->
        val y = 1 - (i / (n - 1f)) * 2
        val r = sqrt(1 - y * y)
        val theta = golden * i
        val x = (cos(theta) * r).toFloat()
        val z = (sin(theta) * r).toFloat()
        SpherePoint(x, y, z, atan2(z, x), (i * 37) % 13 == 0)
    }
}

@Composable
fun CrisVoiceScreen(vm: GlucoViewModel, nav: NavHostController) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var phase by remember { mutableStateOf(VoicePhase.IDLE) }
    var caption by remember { mutableStateOf("") }
    var userLine by remember { mutableStateOf("") }
    var hint by remember { mutableStateOf<String?>(null) }
    var micGranted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    var micBlocked by remember { mutableStateOf(false) }
    var memory by remember { mutableStateOf(CrisMemory()) }
    var pending by remember { mutableStateOf<PendingAction?>(null) }
    val history = remember { mutableListOf<CrisMsg>() }
    var micLevel by remember { mutableFloatStateOf(0f) }
    var leaving by remember { mutableStateOf(false) }

    val speaker = remember { CrisSpeaker(context) }
    val listenerHolder = remember { arrayOfNulls<CrisListener>(1) }

    fun startListening() {
        if (leaving) return
        speaker.stop()
        hint = null
        userLine = ""
        phase = VoicePhase.LISTENING
        listenerHolder[0]?.start()
    }

    suspend fun handleSpeech(said: String) {
        val cleaned = said.trim()
        if (cleaned.isEmpty()) {
            if (!leaving) startListening()
            return
        }
        phase = VoicePhase.THINKING
        userLine = cleaned
        val before = history.toList()
        history.add(CrisMsg(true, cleaned))
        // Mesma inteligência da Cris (local + Gemini + nuvem + fallback)
        val r = crisRespond(context, vm, cleaned, memory, pending, before, voice = true)
        memory = r.memory
        pending = r.pending
        history.add(CrisMsg(false, r.reply))
        CrisPrefs.saveChat(context, history.map { CrisChatLine(it.fromUser, it.text) })
        if (leaving) return
        caption = r.reply
        if (r.navigateTo != null) {
            // fala breve e navega
            if (memory.speakReplies) {
                phase = VoicePhase.SPEAKING
                speaker.speak(r.reply.take(120)) { }
            }
            leaving = true
            nav.popBackStack()
            nav.navigate(r.navigateTo)
            return
        }
        if (memory.speakReplies) {
            phase = VoicePhase.SPEAKING
            val finished = speaker.speak(r.reply) { phase = VoicePhase.SPEAKING }
            if (leaving) return
            // Conversa contínua: só volta a ouvir quando terminar (ou se interrompida)
            if (!leaving) startListening()
        } else {
            phase = VoicePhase.IDLE
            if (!leaving) startListening()
        }
    }

    if (listenerHolder[0] == null) {
        listenerHolder[0] = CrisListener(
            context,
            onLevel = { micLevel = it },
            onPartial = { userLine = it },
            onResult = { said -> scope.launch { handleSpeech(said) } },
            onFail = { msg ->
                if (phase == VoicePhase.LISTENING) {
                    phase = VoicePhase.IDLE
                    hint = msg
                }
            },
        )
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        micGranted = ok
        if (ok) {
            micBlocked = false
            startListening()
        } else {
            val act = context.findActivity()
            micBlocked = !(act != null && ActivityCompat.shouldShowRequestPermissionRationale(act, Manifest.permission.RECORD_AUDIO))
            hint = if (micBlocked) "O microfone está bloqueado. Libere nas configurações para conversar por voz." else "Sem o microfone eu não consigo te ouvir."
        }
    }

    fun onOrbTap() {
        when (phase) {
            VoicePhase.IDLE -> if (micGranted) startListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO)
            VoicePhase.LISTENING -> { listenerHolder[0]?.stop(); phase = VoicePhase.IDLE; micLevel = 0f }
            VoicePhase.SPEAKING -> {
                speaker.stop()
                phase = VoicePhase.IDLE
                if (micGranted) startListening()
            }
            VoicePhase.THINKING -> {
                hint = "Cancelado. Pode falar."
                phase = VoicePhase.IDLE
                if (micGranted) startListening()
            }
        }
    }

    LaunchedEffect(Unit) {
        memory = CrisPrefs.loadMemory(context)
        history.addAll(CrisPrefs.loadChat(context).map { CrisMsg(it.fromUser, it.text) })
        if (micGranted) {
            val first = vm.data.value.settings.displayName.split(" ").firstOrNull().orEmpty()
            val hello = "Oi${if (first.isNotBlank()) ", $first" else ""}! Tô aqui. Pode falar comigo."
            caption = hello
            phase = VoicePhase.SPEAKING
            scope.launch {
                if (memory.speakReplies) speaker.speak(hello) { phase = VoicePhase.SPEAKING }
                if (!leaving) startListening()
            }
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            leaving = true
            listenerHolder[0]?.stop()
            speaker.release()
        }
    }

    // Energia da esfera conforme o estado
    var time by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        val start = withFrameNanos { it }
        while (true) {
            withFrameNanos { now -> time = (now - start) / 1_000_000_000f }
        }
    }
    val targetEnergy = when (phase) {
        VoicePhase.IDLE -> 0.06f
        VoicePhase.LISTENING -> 0.18f + micLevel * 0.8f
        VoicePhase.THINKING -> 0.22f + 0.12f * sin(time * 4f)
        VoicePhase.SPEAKING -> 0.45f + 0.3f * sin(time * 9f) * sin(time * 3.3f)
    }
    val energy by animateFloatAsState(targetEnergy, tween(180), label = "energy")

    Box(
        Modifier.fillMaxSize().background(Brush.radialGradient(listOf(V_BG_CENTER, V_BG_EDGE), radius = 1400f)),
    ) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Cris", color = V_TEXT, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                    Text("conversa por voz", color = V_MUTED, fontSize = 13.sp)
                }
                Text(
                    if (memory.speakReplies) "Voz ligada" else "Voz desligada",
                    color = V_MUTED, fontSize = 12.sp,
                    modifier = Modifier
                        .padding(end = 10.dp)
                        .clickable {
                            scope.launch {
                                memory = memory.copy(speakReplies = !memory.speakReplies)
                                CrisPrefs.saveMemory(context, memory)
                                if (!memory.speakReplies) speaker.stop()
                            }
                        },
                )
                RoundIcon(Icons.Filled.Close, "Fechar") { leaving = true; listenerHolder[0]?.stop(); speaker.stop(); nav.popBackStack() }
            }

            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Canvas(
                    Modifier.fillMaxWidth().aspectRatio(1f).padding(24.dp)
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onOrbTap() },
                ) {
                    // Grade de fundo
                    val step = 36.dp.toPx()
                    var gx = 0f
                    while (gx <= size.width) { drawLine(V_GRID, Offset(gx, 0f), Offset(gx, size.height), 1f); gx += step }
                    var gy = 0f
                    while (gy <= size.height) { drawLine(V_GRID, Offset(0f, gy), Offset(size.width, gy), 1f); gy += step }

                    val cx = size.width / 2
                    val cy = size.height / 2
                    val baseR = size.minDimension * 0.36f
                    drawCircle(V_DOT.copy(alpha = 0.05f + energy * 0.08f), baseR * (1.25f + energy * 0.15f), Offset(cx, cy))
                    drawCircle(V_DOT.copy(alpha = 0.10f), baseR * 1.45f, Offset(cx, cy), style = androidx.compose.ui.graphics.drawscope.Stroke(1.2f))

                    val rotY = time * 0.45f
                    val tilt = 0.38f + 0.08f * sin(time * 0.3f)
                    val cosY = cos(rotY); val sinY = sin(rotY)
                    val cosX = cos(tilt); val sinX = sin(tilt)
                    val dot = 2.6.dp.toPx()
                    val projected = SPHERE.map { p ->
                        val wave = 1f + energy * 0.22f * sin(p.lon * 3f + p.y * 4f + time * 3.2f) +
                            energy * 0.08f * sin(p.y * 9f - time * 5f)
                        val x0 = p.x * wave; val y0 = p.y * wave; val z0 = p.z * wave
                        val x1 = x0 * cosY + z0 * sinY
                        val z1 = -x0 * sinY + z0 * cosY
                        val y2 = y0 * cosX - z1 * sinX
                        val z2 = y0 * sinX + z1 * cosX
                        floatArrayOf(x1, y2, z2, if (p.blue) 1f else 0f)
                    }.sortedBy { it[2] }
                    projected.forEach { a ->
                        val persp = 2.6f / (2.6f - a[2])
                        val px = cx + a[0] * baseR * persp
                        val py = cy + a[1] * baseR * persp
                        val depth = (a[2] + 1f) / 2f
                        val alpha = 0.12f + depth * 0.88f
                        val c = if (a[3] > 0.5f) V_DOT_BLUE else V_DOT
                        val r = dot * (0.45f + depth * 0.9f) * persp
                        if (depth > 0.7f) drawCircle(c.copy(alpha = alpha * 0.25f), r * 2.4f, Offset(px, py))
                        drawCircle(c.copy(alpha = alpha), r, Offset(px, py))
                    }
                }
            }

            // Legenda
            Column(Modifier.fillMaxWidth().padding(horizontal = 28.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                val shown = when (phase) {
                    VoicePhase.LISTENING -> userLine
                    VoicePhase.THINKING -> userLine.ifBlank { caption }
                    else -> caption
                }
                val clipped = if (shown.length > 170) "…" + shown.takeLast(170).substringAfter(" ") else shown
                val words = clipped.trim().split(" ")
                Text(
                    buildAnnotatedString {
                        if (words.size > 1 && phase != VoicePhase.LISTENING) {
                            append(words.dropLast(1).joinToString(" ") + " ")
                            withStyle(SpanStyle(color = V_ACCENT)) { append(words.last()) }
                        } else {
                            append(clipped)
                        }
                    },
                    color = V_TEXT,
                    fontSize = if (clipped.length > 90) 20.sp else 26.sp,
                    lineHeight = if (clipped.length > 90) 27.sp else 33.sp,
                    fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.heightIn(min = 70.dp),
                )
                Spacer(Modifier.height(10.dp))
                Text(
                    when (phase) {
                        VoicePhase.IDLE -> if (micGranted) "Toque na esfera para falar" else "Toque para permitir o microfone"
                        VoicePhase.LISTENING -> "Ouvindo…"
                        VoicePhase.THINKING -> "Pensando…"
                        VoicePhase.SPEAKING -> "Falando · toque para interromper"
                    },
                    color = V_MUTED,
                    fontSize = 14.sp,
                )
                hint?.let { Text(it, color = Color(0xFFFFC48A), fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp)) }
            }

            if (!micGranted) {
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 12.dp).clip(RoundedCornerShape(18.dp)).background(V_PANEL).padding(16.dp),
                ) {
                    Text("Para conversar por voz", color = V_TEXT, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text("A Cris usa o microfone só enquanto você fala com ela. Nada é gravado no aparelho.", color = V_MUTED, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    Text(
                        if (micBlocked) "Abrir configurações" else "Permitir microfone",
                        color = V_BG_EDGE,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.padding(top = 12.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(V_ACCENT)
                            .clickable {
                                if (micBlocked) {
                                    context.startActivity(
                                        Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                                    )
                                } else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            }
                            .padding(vertical = 14.dp),
                        textAlign = TextAlign.Center,
                    )
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 24.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                RoundIcon(Icons.AutoMirrored.Filled.Chat, "Ver conversa") { leaving = true; nav.popBackStack() }
                Box(
                    Modifier.size(76.dp).clip(CircleShape)
                        .background(if (phase == VoicePhase.LISTENING) V_ACCENT else V_PANEL)
                        .border(2.dp, V_ACCENT.copy(alpha = 0.6f), CircleShape)
                        .clickable { onOrbTap() },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(
                        if (phase == VoicePhase.LISTENING || phase == VoicePhase.SPEAKING) Icons.Filled.Stop else Icons.Filled.Mic,
                        "Falar",
                        tint = if (phase == VoicePhase.LISTENING) V_BG_EDGE else V_TEXT,
                        modifier = Modifier.size(34.dp),
                    )
                }
                Spacer(Modifier.size(52.dp))
            }
        }
    }
}

@Composable
private fun RoundIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(52.dp).clip(CircleShape).background(V_PANEL.copy(alpha = 0.7f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, label, tint = V_TEXT)
    }
}
