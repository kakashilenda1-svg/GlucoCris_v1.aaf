package com.agon.app.ui.screens

import android.content.Context
import android.content.Context.CONNECTIVITY_SERVICE
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.material3.Checkbox
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Meal
import com.agon.app.data.MEAL_LABEL
import com.agon.app.data.uid
import com.agon.app.data.formatDate
import com.agon.app.data.formatTime
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.cancel
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

data class FoodItem(
    val id: String,
    val name: String,
    val brand: String = "",
    val serving: String,
    val servingGrams: Double,
    val kcal: Double,
    val kj: Double = 0.0,
    val carbs: Double,
    val protein: Double,
    val fat: Double,
    val fiber: Double = 0.0,
    val sodium: Double = 0.0,
    val sugars: Double = 0.0,
    val satFat: Double = 0.0,
    val source: String,
    val sourceKey: String = "local",
    val isGeneric: Boolean = false,
    val category: String = "",
    val reliability: String = "alta",
) {
    fun idrPercent(factor: Double = 1.0): Int =
        ((kcal * factor / 2000.0) * 100).roundToInt().coerceAtLeast(0)

    fun scaled(factor: Double) = copy(
        kcal = kcal * factor,
        kj = (if (kj > 0) kj else kcal * 4.184) * factor,
        carbs = carbs * factor,
        protein = protein * factor,
        fat = fat * factor,
        fiber = fiber * factor,
        sodium = sodium * factor,
        sugars = sugars * factor,
        satFat = satFat * factor,
    )

    fun favoriteKey() = id
}

val MEAL_OPTIONS = listOf(
    "cafe" to "Café da Manhã",
    "almoco" to "Almoço",
    "jantar" to "Jantar",
    "lanche" to "Lanches/Outros",
)

val EXTRA_FOODS = listOf(
    // Catálogo de redes de restaurantes integrado à pesquisa principal.
    // Valores BK transcritos da tabela nutricional oficial brasileira; porções conforme documento.
    FoodItem("bk-whopper-oficial", "Whopper", "Burger King", "1 unidade (325 g)", 325.0, 717.0, 3003.0, 47.0, 32.0, 44.0, 5.0, 1369.0, 13.0, 17.0, "Burger King Brasil — tabela nutricional oficial", "restaurant_official", false, "Restaurantes/Fast-food", "alta"),
    FoodItem("bk-whopper-duplo-oficial", "Whopper Duplo", "Burger King", "1 unidade (405 g)", 405.0, 962.0, 4026.0, 47.0, 50.0, 62.0, 5.0, 1400.0, 13.0, 26.0, "Burger King Brasil — tabela nutricional oficial", "restaurant_official", false, "Restaurantes/Fast-food", "alta"),
    FoodItem("bk-whopper-furioso-oficial", "Whopper Furioso", "Burger King", "1 unidade (366 g)", 366.0, 941.0, 3940.0, 69.0, 38.0, 56.0, 6.0, 1550.0, 16.0, 19.0, "Burger King Brasil — tabela nutricional oficial", "restaurant_official", false, "Restaurantes/Fast-food", "alta"),
    FoodItem("bk-whopper-jr-oficial", "Whopper Jr.", "Burger King", "1 unidade (179 g)", 179.0, 388.0, 1624.0, 29.0, 17.0, 23.0, 3.0, 767.0, 8.0, 8.0, "Burger King Brasil — tabela nutricional oficial", "restaurant_official", false, "Restaurantes/Fast-food", "alta"),
    FoodItem("bk-whopper-bbacon-oficial", "Whopper Barbecue Bacon", "Burger King", "1 unidade (335 g)", 335.0, 767.0, 3209.0, 49.0, 35.0, 47.0, 5.0, 1583.0, 15.0, 18.0, "Burger King Brasil — tabela nutricional oficial", "restaurant_official", false, "Restaurantes/Fast-food", "alta"),
    FoodItem("bk-batata-pequena-oficial", "Batata frita pequena", "Burger King", "1 porção (74 g)", 74.0, 203.0, 852.0, 24.0, 3.0, 10.0, 0.0, 360.0, 0.0, 3.0, "Burger King Brasil — tabela nutricional oficial", "restaurant_official", false, "Restaurantes/Fast-food", "alta"),
    FoodItem("bk-batata-media-oficial", "Batata frita média", "Burger King", "1 porção (116 g)", 116.0, 318.0, 1335.0, 37.0, 5.0, 16.0, 0.0, 565.0, 0.0, 5.0, "Burger King Brasil — tabela nutricional oficial", "restaurant_official", false, "Restaurantes/Fast-food", "alta"),
    FoodItem("bk-batata-grande-oficial", "Batata frita grande", "Burger King", "1 porção (142 g)", 142.0, 389.0, 1634.0, 46.0, 7.0, 20.0, 0.0, 695.0, 0.0, 5.0, "Burger King Brasil — tabela nutricional oficial", "restaurant_official", false, "Restaurantes/Fast-food", "alta"),
    FoodItem("bk-onion-rings-media-oficial", "Onion Rings média", "Burger King", "1 porção (91 g)", 91.0, 319.0, 1338.0, 36.0, 5.0, 17.0, 0.0, 570.0, 0.0, 4.0, "Burger King Brasil — tabela nutricional oficial", "restaurant_official", false, "Restaurantes/Fast-food", "alta"),
    // McDonald's: dados exibidos nas fichas nutricionais oficiais do site brasileiro.
    FoodItem("mcd-brabo-brabissimo-1carne", "Brabo Brabíssimo 1 Carne", "McDonald's", "1 unidade (porção oficial)", 0.0, 988.0, 4134.0, 50.0, 37.0, 71.0, 4.0, 1628.54, 16.0, 22.0, "McDonald's Brasil — informação nutricional oficial", "restaurant_official", false, "Restaurantes/Fast-food", "alta"),
    FoodItem("mcd-top-sundae-caramelo", "Top Sundae Caramelo", "McDonald's", "1 porção", 0.0, 401.0, 1678.0, 67.0, 7.1, 12.0, 1.3, 190.81, 55.0, 4.4, "McDonald's Brasil — informação nutricional oficial", "restaurant_official", false, "Restaurantes/Sobremesas", "alta"),
    // Subway: referência de tabela nutricional oficial publicada no Brasil; receitas e porções podem mudar.
    FoodItem("subway-italiano-15cm", "Italiano", "Subway", "1 sanduíche de 15 cm (216 g)", 216.0, 407.0, 1703.0, 45.4, 21.3, 15.4, 5.2, 0.0, 0.0, 5.0, "Subway Brasil — tabela nutricional publicada; açúcares e sódio não informados (aparecem como 0)", "restaurant_official", false, "Restaurantes/Sanduíches", "media"),
    FoodItem("subway-peito-peru-15cm", "Peito de Peru", "Subway", "1 sanduíche de 15 cm (219 g)", 219.0, 293.0, 1226.0, 45.5, 20.2, 3.4, 5.2, 825.0, 0.0, 0.8, "Subway Brasil — tabela nutricional publicada; açúcares não informados (aparecem como 0)", "restaurant_official", false, "Restaurantes/Sanduíches", "media"),
    FoodItem("subway-presunto-15cm", "Presunto", "Subway", "1 sanduíche de 15 cm (207 g)", 207.0, 279.0, 1167.0, 44.7, 17.5, 3.2, 5.2, 549.0, 0.0, 0.9, "Subway Brasil — tabela nutricional publicada; açúcares não informados (aparecem como 0)", "restaurant_official", false, "Restaurantes/Sanduíches", "media"),
    FoodItem("subway-rosbife-15cm", "Rosbife", "Subway", "1 sanduíche de 15 cm (222 g)", 222.0, 308.0, 1289.0, 44.7, 25.2, 3.2, 5.2, 452.0, 0.0, 0.9, "Subway Brasil — tabela nutricional publicada; açúcares não informados (aparecem como 0)", "restaurant_official", false, "Restaurantes/Sanduíches", "media"),
    FoodItem("subway-club-15cm", "Subway Club", "Subway", "1 sanduíche de 15 cm (260 g)", 260.0, 343.0, 1435.0, 45.4, 30.0, 4.4, 5.2, 950.0, 0.0, 1.3, "Subway Brasil — tabela nutricional publicada; açúcares não informados (aparecem como 0)", "restaurant_official", false, "Restaurantes/Sanduíches", "media"),
    FoodItem("subway-melt-15cm", "Subway Melt", "Subway", "1 sanduíche de 15 cm (255 g)", 255.0, 409.0, 1711.0, 46.3, 27.4, 12.3, 5.5, 1263.0, 0.0, 5.4, "Subway Brasil — tabela nutricional publicada; açúcares não informados (aparecem como 0)", "restaurant_official", false, "Restaurantes/Sanduíches", "media"),
    FoodItem("subway-vegetariano-15cm", "Vegetariano", "Subway", "1 sanduíche de 15 cm (162 g)", 162.0, 232.0, 971.0, 44.6, 9.3, 1.8, 5.2, 231.0, 0.0, 0.3, "Subway Brasil — tabela nutricional publicada; açúcares não informados (aparecem como 0)", "restaurant_official", false, "Restaurantes/Sanduíches", "media"),
    // Spoleto: preparações variam por massa, molho e montagem; valores são estimativas por porção.
    FoodItem("spoleto-penne-sugo-est", "Penne ao molho sugo", "Spoleto", "1 prato estimado (350 g)", 350.0, 490.0, 2050.0, 78.0, 16.0, 12.0, 5.0, 900.0, 9.0, 3.0, "Estimativa de preparação — não é ficha oficial Spoleto", "restaurant_estimate", false, "Restaurantes/Massas", "estimada"),
    FoodItem("spoleto-penne-bolonhesa-est", "Penne à bolonhesa", "Spoleto", "1 prato estimado (400 g)", 400.0, 620.0, 2594.0, 82.0, 28.0, 18.0, 6.0, 1100.0, 10.0, 7.0, "Estimativa de preparação — não é ficha oficial Spoleto", "restaurant_estimate", false, "Restaurantes/Massas", "estimada"),
    FoodItem("spoleto-lasagna-est", "Lasanha à bolonhesa", "Spoleto", "1 porção estimada (350 g)", 350.0, 560.0, 2343.0, 55.0, 30.0, 25.0, 4.0, 1200.0, 8.0, 12.0, "Estimativa de preparação — não é ficha oficial Spoleto", "restaurant_estimate", false, "Restaurantes/Massas", "estimada"),
    FoodItem("habibs-esfiha-carne", "Esfiha de Carne", "Habib's", "1 unidade (75 g)", 75.0, 152.0, 636.0, 22.0, 5.5, 4.6, 2.1, 346.0, 3.5, 1.0, "FatSecret / dados públicos", "public", false, "Fast-food", "media"),
    FoodItem("habibs-esfiha-frango", "Esfiha de Frango", "Habib's", "1 unidade (~75 g)", 75.0, 145.0, 607.0, 20.0, 6.0, 4.0, 1.5, 320.0, 2.0, 0.9, "FatSecret / dados públicos", "public", false, "Fast-food", "media"),
    FoodItem("habibs-esfiha-queijo", "Esfiha de Queijo", "Habib's", "1 unidade (~75 g)", 75.0, 160.0, 669.0, 18.0, 7.0, 6.0, 1.0, 350.0, 2.5, 2.5, "Estimativa pública", "public", false, "Fast-food", "estimada"),
    FoodItem("ovo-cozido-local", "Ovo Cozido", "", "1 grande (50 g)", 50.0, 77.0, 322.0, 0.56, 6.26, 5.28, 0.0, 62.0, 0.56, 1.6, "TBCA", "local", true, "Ovos", "alta"),
    FoodItem("ovo-frito-local", "Ovo Frito", "", "1 grande", 46.0, 89.0, 372.0, 0.4, 6.2, 6.8, 0.0, 90.0, 0.4, 1.9, "TBCA", "local", true, "Ovos", "alta"),
    FoodItem("ovo-mexido-local", "Ovo Mexido", "", "2 ovos", 100.0, 199.0, 833.0, 1.6, 13.5, 15.0, 0.0, 170.0, 1.6, 4.5, "TBCA", "local", true, "Ovos", "alta"),
    // Nomes de busca BR (mesmos valores de ovo de galinha / TACO — não inventados)
    FoodItem("ovo-vermelho-cozido", "Ovo vermelho cozido", "", "1 grande (50 g)", 50.0, 77.0, 322.0, 0.56, 6.26, 5.28, 0.0, 62.0, 0.56, 1.6, "TBCA (ovo de galinha)", "local", true, "Ovos", "alta"),
    FoodItem("ovo-vermelho-cru", "Ovo vermelho cru", "", "1 grande (50 g)", 50.0, 74.0, 310.0, 0.6, 6.2, 5.0, 0.0, 70.0, 0.6, 1.6, "TBCA (ovo de galinha)", "local", true, "Ovos", "alta"),
    FoodItem("ovo-caipira-cozido", "Ovo caipira cozido", "", "1 grande (50 g)", 50.0, 77.0, 322.0, 0.56, 6.26, 5.28, 0.0, 62.0, 0.56, 1.6, "TBCA (ovo de galinha)", "local", true, "Ovos", "alta"),
    FoodItem("ovo-branco-cozido", "Ovo branco cozido", "", "1 grande (50 g)", 50.0, 77.0, 322.0, 0.56, 6.26, 5.28, 0.0, 62.0, 0.56, 1.6, "TBCA (ovo de galinha)", "local", true, "Ovos", "alta"),
    FoodItem("ovo-organico-cozido", "Ovo orgânico cozido", "", "1 grande (50 g)", 50.0, 77.0, 322.0, 0.56, 6.26, 5.28, 0.0, 62.0, 0.56, 1.6, "TBCA (ovo de galinha)", "local", true, "Ovos", "alta"),
    FoodItem("manteiga-com-sal", "Manteiga com sal", "", "1 colher de sopa (10 g)", 10.0, 74.0, 310.0, 0.0, 0.1, 8.2, 0.0, 90.0, 0.0, 5.2, "TBCA", "local", true, "Gorduras", "alta"),
    FoodItem("queijo-mussarela-fatia", "Queijo mussarela", "", "1 fatia (20 g)", 20.0, 66.0, 276.0, 0.6, 4.5, 5.0, 0.0, 110.0, 0.4, 3.0, "TBCA", "local", true, "Laticínios", "alta"),
    FoodItem("presunto-fatia", "Presunto", "", "1 fatia (15 g)", 15.0, 23.0, 96.0, 0.3, 2.5, 1.2, 0.0, 180.0, 0.2, 0.4, "TBCA", "local", true, "Carnes", "media"),
    FoodItem("pao-frances-1", "Pão francês", "", "1 unidade (50 g)", 50.0, 150.0, 628.0, 29.0, 4.5, 1.5, 1.0, 300.0, 1.0, 0.3, "TBCA", "local", true, "Cereais", "alta"),
    FoodItem("pao-forma", "Pão de forma", "", "1 fatia (25 g)", 25.0, 65.0, 272.0, 12.0, 2.2, 0.8, 0.6, 150.0, 1.2, 0.2, "TBCA", "local", true, "Cereais", "alta"),
    FoodItem("arroz-branco-prato", "Arroz branco cozido", "", "1 colher de servir (45 g)", 45.0, 58.0, 243.0, 12.6, 1.1, 0.1, 0.0, 0.5, 0.0, 0.0, "TBCA", "local", true, "Cereais", "alta"),
    FoodItem("feijao-carioca-prato", "Feijão carioca cozido", "", "1 concha (140 g)", 140.0, 106.0, 444.0, 19.0, 6.7, 0.7, 11.9, 1.4, 0.0, 0.1, "TBCA", "local", true, "Leguminosas", "alta"),
    FoodItem("banana-prata-1", "Banana prata", "", "1 unidade média (80 g)", 80.0, 71.0, 297.0, 18.0, 0.9, 0.2, 2.0, 1.0, 12.0, 0.1, "TBCA", "local", true, "Frutas", "alta"),
    FoodItem("maca-1", "Maçã", "", "1 unidade média (130 g)", 130.0, 73.0, 305.0, 19.3, 0.3, 0.3, 1.7, 1.0, 13.0, 0.0, "TBCA", "local", true, "Frutas", "alta"),
    FoodItem("laranja-1", "Laranja", "", "1 unidade média (140 g)", 140.0, 65.0, 272.0, 15.0, 1.2, 0.2, 1.4, 1.0, 12.0, 0.0, "TBCA", "local", true, "Frutas", "alta"),
    FoodItem("leite-integral-copo", "Leite de vaca integral", "", "1 copo (200 ml)", 200.0, 122.0, 510.0, 9.2, 6.4, 6.6, 0.0, 86.0, 9.2, 4.0, "TBCA", "local", true, "Laticínios", "alta"),
    FoodItem("iogurte-natural", "Iogurte natural", "", "1 pote (170 g)", 170.0, 87.0, 364.0, 6.5, 6.5, 3.2, 0.0, 80.0, 6.5, 2.0, "TBCA", "local", true, "Laticínios", "alta"),
    FoodItem("frango-grelhado", "Frango grelhado (peito)", "", "100 g", 100.0, 159.0, 665.0, 0.0, 32.0, 2.5, 0.0, 60.0, 0.0, 0.7, "TBCA", "local", true, "Carnes", "alta"),
    FoodItem("carne-bovina-grelhada", "Carne bovina grelhada", "", "100 g", 100.0, 219.0, 916.0, 0.0, 28.0, 11.0, 0.0, 55.0, 0.0, 4.5, "TBCA", "local", true, "Carnes", "alta"),
    FoodItem("batata-cozida", "Batata cozida", "", "100 g", 100.0, 52.0, 218.0, 11.9, 1.2, 0.1, 1.3, 2.0, 0.5, 0.0, "TBCA", "local", true, "Tubérculos", "alta"),
    FoodItem("macarrao-cozido", "Macarrão cozido", "", "100 g", 100.0, 102.0, 427.0, 21.0, 3.5, 0.5, 1.5, 3.0, 0.3, 0.1, "TBCA", "local", true, "Cereais", "alta"),
    FoodItem("suco-laranja", "Suco de laranja natural", "", "1 copo (200 ml)", 200.0, 74.0, 310.0, 17.0, 1.0, 0.2, 0.4, 1.0, 15.0, 0.0, "TBCA", "local", true, "Bebidas", "alta"),
    FoodItem("refrigerante-cola", "Refrigerante tipo cola", "", "1 lata (350 ml)", 350.0, 147.0, 615.0, 37.0, 0.0, 0.0, 0.0, 20.0, 37.0, 0.0, "Rotulagem típica", "public", false, "Bebidas", "media"),
    FoodItem("pizza-mussarela-fatia", "Pizza mussarela", "", "1 fatia (80 g)", 80.0, 200.0, 837.0, 22.0, 9.0, 8.0, 1.2, 400.0, 2.0, 3.5, "Genérico", "public", true, "Salgados", "media"),
    FoodItem("cafe-sem-acucar", "Café preto sem açúcar", "", "1 xícara (50 ml)", 50.0, 2.0, 8.0, 0.0, 0.1, 0.0, 0.0, 2.0, 0.0, 0.0, "TBCA", "local", true, "Bebidas", "alta"),
    FoodItem("acucar-colher", "Açúcar refinado", "", "1 colher de chá (4 g)", 4.0, 16.0, 67.0, 4.0, 0.0, 0.0, 0.0, 0.0, 4.0, 0.0, "TBCA", "local", true, "Açúcares", "alta"),
    FoodItem("azeite-colher", "Azeite de oliva", "", "1 colher de sopa (8 g)", 8.0, 72.0, 301.0, 0.0, 0.0, 8.0, 0.0, 0.0, 0.0, 1.1, "TBCA", "local", true, "Óleos", "alta"),
    FoodItem("queijo-minas", "Queijo minas frescal", "", "1 fatia (30 g)", 30.0, 79.0, 330.0, 0.9, 5.2, 6.1, 0.0, 90.0, 0.9, 3.8, "TBCA", "local", true, "Laticínios", "alta"),
    FoodItem("tapioca-goma", "Tapioca (goma hidratada)", "", "1 unidade média (100 g)", 100.0, 100.0, 418.0, 24.0, 0.2, 0.1, 0.5, 5.0, 0.0, 0.0, "TBCA", "local", true, "Cereais", "alta"),
    FoodItem("pao-parmesao", "Pão parmesão", "", "1 unidade (50 g)", 50.0, 155.0, 649.0, 28.0, 5.5, 2.5, 1.2, 320.0, 1.2, 1.0, "TBCA / padaria (estim. similar pão salgado)", "local", true, "Cereais", "media"),
    FoodItem("pao-de-sal", "Pão de sal", "", "1 unidade (50 g)", 50.0, 150.0, 628.0, 29.0, 4.5, 1.5, 1.0, 300.0, 1.0, 0.3, "TBCA (pão francês)", "local", true, "Cereais", "alta"),
    FoodItem("paozinho", "Pãozinho", "", "1 unidade (40 g)", 40.0, 120.0, 502.0, 23.0, 3.6, 1.2, 0.8, 240.0, 0.8, 0.2, "TBCA (proporcional pão francês)", "local", true, "Cereais", "media"),
    FoodItem("pao-de-queijo", "Pão de queijo", "", "1 unidade (40 g)", 40.0, 120.0, 502.0, 14.0, 3.5, 6.0, 0.3, 200.0, 0.5, 2.5, "TBCA / genérico BR", "local", true, "Salgados", "media"),
    FoodItem("pao-integral", "Pão integral", "", "1 fatia (30 g)", 30.0, 74.0, 310.0, 12.5, 3.5, 1.2, 2.0, 140.0, 1.0, 0.3, "TBCA", "local", true, "Cereais", "alta"),
    FoodItem("bisnaguinha", "Bisnaguinha", "", "1 unidade (20 g)", 20.0, 60.0, 251.0, 11.0, 1.8, 1.0, 0.4, 90.0, 2.0, 0.3, "Rotulagem típica", "public", false, "Cereais", "media"),
    FoodItem("croissant", "Croissant", "", "1 unidade (55 g)", 55.0, 210.0, 879.0, 22.0, 4.0, 12.0, 1.0, 220.0, 3.0, 7.0, "Genérico", "public", true, "Cereais", "media"),
    FoodItem("torrada", "Torrada", "", "1 unidade (10 g)", 10.0, 40.0, 167.0, 7.5, 1.2, 0.5, 0.4, 60.0, 0.5, 0.1, "TBCA", "local", true, "Cereais", "alta"),
)

private var tacoCache: List<FoodItem>? = null
private val onlineCache = linkedMapOf<String, Pair<Long, List<FoodItem>>>()
private const val ONLINE_CACHE_TTL = 90 * 60_000L
private const val ONLINE_CACHE_MAX = 150

private fun getOnlineCached(q: String): List<FoodItem>? {
    val e = onlineCache[q.lowercase().trim()] ?: return null
    if (System.currentTimeMillis() - e.first > ONLINE_CACHE_TTL) return null
    return e.second
}
private fun putOnlineCached(q: String, list: List<FoodItem>) {
    val k = q.lowercase().trim()
    if (k.isBlank() || list.isEmpty()) return
    onlineCache[k] = System.currentTimeMillis() to list
    while (onlineCache.size > ONLINE_CACHE_MAX) {
        onlineCache.remove(onlineCache.keys.first())
    }
}


/** Aviso se os números de um produto parecem incompletos ou inconsistentes (valores por 100 g). */
fun nutritionWarning(kcal: Double, carbs: Double, protein: Double, fat: Double): String? {
    if (kcal <= 0 && carbs <= 0 && protein <= 0 && fat <= 0) return "sem dados nutricionais"
    if (carbs + protein + fat > 105.0) return "macros somam mais de 100 g"
    if (kcal > 0) {
        val expected = 4.0 * carbs + 4.0 * protein + 9.0 * fat
        if (kotlin.math.abs(kcal - expected) > 0.35 * kcal + 30.0) return "calorias não batem com os macros"
    }
    return null
}

/** Catálogo extra offline opcional: assets/catalogo_extra.json (mesmo formato do TACO + campos opcionais). */
private var extraCache: List<FoodItem>? = null

fun loadExtraFoods(context: Context): List<FoodItem> {
    extraCache?.let { return it }
    return readExtraFoods(context).also { extraCache = it }
}

private fun readExtraFoods(context: Context): List<FoodItem> = try {
    val text = context.assets.open("catalogo_extra.json").bufferedReader().readText()
    val arr = JSONArray(text)
    val out = ArrayList<FoodItem>(arr.length())
    for (i in 0 until arr.length()) {
        val o = arr.getJSONObject(i)
        val name = o.optString("name")
        val id = o.optString("id")
        if (name.isBlank() || id.isBlank()) continue
        val kcal = o.optDouble("kcal", 0.0)
        val grams = o.optDouble("servingGrams", 100.0).let { if (it > 0) it else 100.0 }
        out.add(
            FoodItem(
                id = id, name = name, brand = o.optString("brand", ""),
                serving = o.optString("serving", "100 g").ifBlank { "100 g" },
                servingGrams = grams, kcal = kcal,
                kj = o.optDouble("kj", kcal * 4.184),
                carbs = o.optDouble("carbs", 0.0), protein = o.optDouble("protein", 0.0),
                fat = o.optDouble("fat", 0.0), fiber = o.optDouble("fiber", 0.0),
                sodium = o.optDouble("sodium", 0.0), sugars = o.optDouble("sugars", 0.0),
                satFat = o.optDouble("satFat", 0.0),
                source = o.optString("source", "Catálogo extra"),
                sourceKey = o.optString("sourceKey", "local"),
                isGeneric = o.optBoolean("isGeneric", false),
                category = o.optString("category", ""),
                reliability = o.optString("reliability", "media"),
            )
        )
    }
    out
} catch (_: Exception) {
    emptyList()
}

/** Cache offline dos códigos de barras já encontrados (resposta instantânea e sem internet). */
object BarcodeCache {
    private const val FILE = "gluco_barcode_cache"
    private const val MAX = 800

    fun get(ctx: Context, code: String): FoodItem? = try {
        val s = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("c_$code", null) ?: return null
        val o = JSONObject(s)
        FoodItem(
            id = o.getString("id"), name = o.getString("name"), brand = o.optString("brand"),
            serving = o.optString("serving", "100 g"), servingGrams = o.optDouble("sg", 100.0),
            kcal = o.optDouble("kcal"), kj = o.optDouble("kj"), carbs = o.optDouble("carbs"),
            protein = o.optDouble("protein"), fat = o.optDouble("fat"), fiber = o.optDouble("fiber"),
            sodium = o.optDouble("sodium"), sugars = o.optDouble("sugars"), satFat = o.optDouble("satFat"),
            source = o.optString("source") + " (salvo no aparelho)", sourceKey = o.optString("sk", "off"),
            isGeneric = o.optBoolean("gen"), reliability = o.optString("rel", "media"),
            category = o.optString("cat"),
        )
    } catch (_: Exception) {
        null
    }

    fun put(ctx: Context, code: String, f: FoodItem) {
        try {
            val sp = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)
            val o = JSONObject()
                .put("id", f.id).put("name", f.name).put("brand", f.brand).put("serving", f.serving)
                .put("sg", f.servingGrams).put("kcal", f.kcal).put("kj", f.kj).put("carbs", f.carbs)
                .put("protein", f.protein).put("fat", f.fat).put("fiber", f.fiber).put("sodium", f.sodium)
                .put("sugars", f.sugars).put("satFat", f.satFat).put("source", f.source.removeSuffix(" (salvo no aparelho)"))
                .put("sk", f.sourceKey).put("gen", f.isGeneric).put("rel", f.reliability).put("cat", f.category)
            val ed = sp.edit().putString("c_$code", o.toString())
            val keys = sp.all.keys.filter { it.startsWith("c_") }
            if (keys.size >= MAX) keys.take(keys.size - MAX + 1).forEach { ed.remove(it) }
            ed.apply()
        } catch (_: Exception) { }
    }
}

fun loadTacoFoods(context: Context): List<FoodItem> {
    tacoCache?.let { return it }
    return try {
        val text = context.assets.open("taco_br.json").bufferedReader().readText()
        val arr = JSONArray(text)
        val list = mutableListOf<FoodItem>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val kcal = o.optDouble("kcal", 0.0)
            list.add(
                FoodItem(
                    id = o.optString("id"),
                    name = o.optString("name"),
                    serving = "100 g",
                    servingGrams = 100.0,
                    kcal = kcal,
                    kj = o.optDouble("kj", kcal * 4.184),
                    carbs = o.optDouble("carbs", 0.0),
                    protein = o.optDouble("protein", 0.0),
                    fat = o.optDouble("fat", 0.0),
                    fiber = o.optDouble("fiber", 0.0),
                    sodium = o.optDouble("sodium", 0.0),
                    sugars = o.optDouble("sugars", 0.0),
                    satFat = o.optDouble("satFat", 0.0),
                    source = "TACO (NEPA/UNICAMP)",
                    sourceKey = "taco",
                    isGeneric = true,
                    category = o.optString("category", ""),
                    reliability = "alta",
                )
            )
        }
        list.addAll(loadExtraFoods(context))
        tacoCache = list
        list
    } catch (_: Exception) {
        emptyList()
    }
}

// Preferências simples: favoritos e buscas recentes
private const val PREFS = "gluco_food_prefs"
private const val KEY_FAV = "favorites"
private const val KEY_RECENT = "recent_searches"
private const val KEY_CARB_GOAL = "carb_goal_g"

fun loadFavorites(ctx: Context): Set<String> =
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getStringSet(KEY_FAV, emptySet()) ?: emptySet()

fun saveFavorites(ctx: Context, ids: Set<String>) {
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY_FAV, ids).apply()
}

fun loadRecentSearches(ctx: Context): List<String> {
    val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_RECENT, "") ?: ""
    return raw.split("|").map { it.trim() }.filter { it.isNotBlank() }.take(12)
}


fun isNetworkOnline(ctx: Context): Boolean {
    return try {
        val cm = ctx.getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(n) ?: return false
        caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    } catch (_: Exception) {
        true
    }
}

fun isWifiOnline(ctx: Context): Boolean {
    return try {
        val cm = ctx.getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(n) ?: return false
        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
    } catch (_: Exception) {
        false
    }
}

private const val KEY_RECENT_FOODS = "recent_food_ids"
fun loadRecentFoodIds(ctx: Context): List<String> {
    val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_RECENT_FOODS, "") ?: ""
    return raw.split("|").filter { it.isNotBlank() }
}
fun pushRecentFood(ctx: Context, id: String) {
    if (id.isBlank()) return
    val cur = loadRecentFoodIds(ctx).filter { it != id }.toMutableList()
    cur.add(0, id)
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
        .putString(KEY_RECENT_FOODS, cur.take(20).joinToString("|")).apply()
}

fun loadCarbGoal(ctx: Context): Double? {
    val v = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat(KEY_CARB_GOAL, -1f)
    return if (v > 0) v.toDouble() else null
}
fun saveCarbGoal(ctx: Context, grams: Double?) {
    val ed = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
    if (grams == null || grams <= 0) ed.remove(KEY_CARB_GOAL) else ed.putFloat(KEY_CARB_GOAL, grams.toFloat())
    ed.apply()
}

fun pushRecentSearch(ctx: Context, q: String) {
    if (q.isBlank()) return
    val cur = loadRecentSearches(ctx).filter { !it.equals(q, true) }.toMutableList()
    cur.add(0, q.trim())
    val joined = cur.take(12).joinToString("|")
    ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY_RECENT, joined).apply()
}

suspend fun searchOpenFoodFacts(query: String): List<FoodItem> = withContext(Dispatchers.IO) {
    try {
        val q = URLEncoder.encode(query, "UTF-8")
        val fields = "product_name,product_name_pt,brands,nutriments,serving_size,code,countries_tags"
        val endpoints = listOf(
            "https://br.openfoodfacts.org/cgi/search.pl?search_terms=$q&search_simple=1&action=process&json=1&page_size=40&fields=$fields",
            "https://world.openfoodfacts.org/cgi/search.pl?search_terms=$q&search_simple=1&action=process&json=1&page_size=40&fields=$fields",
        )
        fun fetchEndpoint(ep: String): List<FoodItem> {
            return try {
                val conn = (URL(ep).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "GlucoCris/1.7 (Android; nutrition search)")
                    setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9")
                    setRequestProperty("Connection", "close")
                    connectTimeout = 2800
                    readTimeout = 4000
                }
                if (conn.responseCode != 200) return emptyList()
                val json = JSONObject(conn.inputStream.bufferedReader().readText())
                val products = json.optJSONArray("products") ?: return emptyList()
                val list = mutableListOf<FoodItem>()
                val seen = HashSet<String>()
                for (i in 0 until products.length()) {
                    val p = products.getJSONObject(i)
                    val name = p.optString("product_name_pt", "").ifBlank { p.optString("product_name", "") }
                    if (name.isBlank()) continue
                    val code = p.optString("code", "")
                    val dedupe = code.ifBlank { name.lowercase() + "|" + p.optString("brands", "").lowercase() }
                    if (!seen.add(dedupe)) continue
                    val brand = p.optString("brands", "")
                    val nutr = p.optJSONObject("nutriments") ?: continue
                    val kcal = nutr.optDouble("energy-kcal_100g", nutr.optDouble("energy-kcal", 0.0))
                    val carbs = nutr.optDouble("carbohydrates_100g", 0.0)
                    if (kcal <= 0 && carbs <= 0) continue
                    val servingSize = p.optString("serving_size", "").ifBlank { "100 g" }
                    val grams = Regex("""(\d+[.,]?\d*)\s*g""", RegexOption.IGNORE_CASE)
                        .find(servingSize)?.groupValues?.getOrNull(1)
                        ?.replace(",", ".")?.toDoubleOrNull() ?: 100.0
                    list.add(
                        FoodItem(
                            id = "off-${code.ifBlank { uid() }}",
                            name = name,
                            brand = brand,
                            serving = if (grams != 100.0 && servingSize.isNotBlank()) servingSize else "100 g",
                            servingGrams = if (grams > 0) grams else 100.0,
                            kcal = kcal,
                            kj = nutr.optDouble("energy-kj_100g", kcal * 4.184),
                            carbs = carbs,
                            protein = nutr.optDouble("proteins_100g", 0.0),
                            fat = nutr.optDouble("fat_100g", 0.0),
                            fiber = nutr.optDouble("fiber_100g", 0.0),
                            sodium = nutr.optDouble("sodium_100g", 0.0) * 1000,
                            sugars = nutr.optDouble("sugars_100g", 0.0),
                            satFat = nutr.optDouble("saturated-fat_100g", 0.0),
                            source = "Open Food Facts",
                            sourceKey = "off",
                            isGeneric = brand.isBlank(),
                            reliability = "media",
                            category = "",
                        )
                    )
                }
                list
            } catch (_: Exception) {
                emptyList()
            }
        }
        // BR e world em paralelo
        val parts = coroutineScope {
            endpoints.map { ep -> async(Dispatchers.IO) { fetchEndpoint(ep) } }.awaitAll()
        }
        val seen = HashSet<String>()
        val list = mutableListOf<FoodItem>()
        parts.flatten().forEach { item ->
            val key = item.id.ifBlank { item.name.lowercase() + "|" + item.brand.lowercase() }
            if (seen.add(key)) list.add(item)
        }
        list
    } catch (_: Exception) {
        emptyList()
    }
}

suspend fun searchUsda(query: String, apiKey: String = "DEMO_KEY"): List<FoodItem> = withContext(Dispatchers.IO) {
    try {
        val q = URLEncoder.encode(query, "UTF-8")
        val url = URL("https://api.nal.usda.gov/fdc/v1/foods/search?query=$q&pageSize=25&api_key=$apiKey")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = 3000
            readTimeout = 4000
        }
        if (conn.responseCode != 200) return@withContext emptyList()
        val json = JSONObject(conn.inputStream.bufferedReader().readText())
        val foods = json.optJSONArray("foods") ?: return@withContext emptyList()
        val list = mutableListOf<FoodItem>()
        for (i in 0 until foods.length()) {
            val f = foods.getJSONObject(i)
            val name = f.optString("description", "")
            if (name.isBlank()) continue
            val brand = f.optString("brandOwner", f.optString("brandName", ""))
            val nutrients = f.optJSONArray("foodNutrients") ?: continue
            var kcal = 0.0; var protein = 0.0; var fat = 0.0; var carbs = 0.0
            var fiber = 0.0; var sodium = 0.0; var sugars = 0.0; var sat = 0.0
            for (j in 0 until nutrients.length()) {
                val n = nutrients.getJSONObject(j)
                val nname = n.optString("nutrientName", "")
                val v = n.optDouble("value", n.optDouble("amount", 0.0))
                val unit = n.optString("unitName", "")
                when {
                    nname.contains("Energy", true) && unit.equals("KCAL", true) -> kcal = v
                    nname.contains("Protein", true) -> protein = v
                    nname.contains("Total lipid", true) -> fat = v
                    nname.contains("Carbohydrate", true) -> carbs = v
                    nname.contains("Fiber", true) -> fiber = v
                    nname.contains("Sodium", true) -> sodium = v
                    nname.contains("Sugars", true) -> sugars = v
                    nname.contains("Saturated", true) -> sat = v
                }
            }
            if (kcal <= 0 && carbs <= 0) continue
            list.add(
                FoodItem(
                    id = "usda-${f.optLong("fdcId", 0)}",
                    name = name,
                    brand = brand,
                    serving = "100 g",
                    servingGrams = 100.0,
                    kcal = kcal,
                    kj = kcal * 4.184,
                    carbs = carbs,
                    protein = protein,
                    fat = fat,
                    fiber = fiber,
                    sodium = sodium,
                    sugars = sugars,
                    satFat = sat,
                    source = "USDA FoodData Central",
                    sourceKey = "usda",
                    isGeneric = brand.isBlank(),
                    reliability = "alta",
                )
            )
        }
        list
    } catch (_: Exception) {
        emptyList()
    }
}

suspend fun lookupBarcode(code: String, context: Context? = null): FoodItem? = withContext(Dispatchers.IO) {
    val digits = code.filter { it.isDigit() }
    if (digits.length < 8) return@withContext null
    // 0) Cache do aparelho: instantâneo e funciona sem internet
    if (context != null) {
        BarcodeCache.get(context, digits)?.let { return@withContext it }
    }
    // Variantes de código (zeros à esquerda / EAN-13)
    val variants = linkedSetOf(digits, digits.trimStart('0')).apply {
        if (digits.length == 12) add("0$digits")
        if (digits.length == 8) add(digits.padStart(13, '0'))
        if (digits.length in 9..12) add(digits.padStart(13, '0'))
    }.filter { it.length in 8..14 }

    fun parseProduct(json: org.json.JSONObject, codeUsed: String): FoodItem? {
        val status = json.optInt("status", 0)
        val p = json.optJSONObject("product") ?: return null
        if (status != 1 && p.optString("product_name", "").isBlank() && p.optString("product_name_pt", "").isBlank()) return null
        val name = p.optString("product_name_pt", "").ifBlank {
            p.optString("product_name", "").ifBlank { p.optString("generic_name", "") }
        }
        if (name.isBlank()) return null
        val brand = p.optString("brands", "")
        val nutr = p.optJSONObject("nutriments") ?: org.json.JSONObject()
        val kcal = nutr.optDouble("energy-kcal_100g", nutr.optDouble("energy-kcal", 0.0))
        val carbs = nutr.optDouble("carbohydrates_100g", 0.0)
        if (kcal <= 0 && carbs <= 0) {
            // ainda devolve com zeros se houver nome — usuário vê o produto
        }
        val servingSize = p.optString("serving_size", "").ifBlank { "100 g" }
        val grams = Regex("""(\d+[.,]?\d*)\s*g""", RegexOption.IGNORE_CASE)
            .find(servingSize)?.groupValues?.getOrNull(1)
            ?.replace(",", ".")?.toDoubleOrNull() ?: 100.0
        // Open Food Facts traz os valores por 100 g: converte para a porção exibida,
        // senão 1 porção de 30 g mostraria os carboidratos de 100 g.
        val g100 = if (grams > 0) grams else 100.0
        val k = g100 / 100.0
        val protein100 = nutr.optDouble("proteins_100g", 0.0)
        val fat100 = nutr.optDouble("fat_100g", 0.0)
        val warn = nutritionWarning(kcal, carbs, protein100, fat100)
        return FoodItem(
            id = "bc-$codeUsed",
            name = name,
            brand = brand,
            serving = if (grams != 100.0) servingSize else "100 g",
            servingGrams = g100,
            kcal = if (kcal > 0) kcal * k else 0.0,
            kj = nutr.optDouble("energy-kj_100g", kcal * 4.184) * k,
            carbs = carbs * k,
            protein = protein100 * k,
            fat = fat100 * k,
            fiber = nutr.optDouble("fiber_100g", 0.0) * k,
            sodium = nutr.optDouble("sodium_100g", 0.0) * 1000 * k,
            sugars = nutr.optDouble("sugars_100g", 0.0) * k,
            satFat = nutr.optDouble("saturated-fat_100g", 0.0) * k,
            source = if (warn != null) "Open Food Facts — confira: $warn" else "Open Food Facts",
            sourceKey = "off",
            isGeneric = brand.isBlank(),
            reliability = if (warn != null) "verificar" else "media",
            category = p.optString("categories", ""),
        )
    }

    fun fetchProduct(host: String, c: String): FoodItem? {
        return try {
            val url = URL("https://$host/api/v0/product/$c.json?fields=product_name,product_name_pt,generic_name,brands,nutriments,serving_size,categories")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                setRequestProperty("User-Agent", "GlucoCris/1.7 (Android; barcode)")
                setRequestProperty("Accept-Language", "pt-BR,pt;q=0.9")
                setRequestProperty("Connection", "close")
                connectTimeout = 1500
                readTimeout = 2000
            }
            if (conn.responseCode != 200) return null
            val json = org.json.JSONObject(conn.inputStream.bufferedReader().readText())
            parseProduct(json, c)
        } catch (_: Exception) {
            null
        }
    }

    // 0b) Base offline empacotada (assets/catalogo_extra.json), se existir
    if (context != null) {
        val extra = loadExtraFoods(context)
        if (extra.isNotEmpty()) {
            for (c in variants) {
                extra.firstOrNull { it.id == "bc-$c" }?.let { return@withContext it.copy(source = it.source + " (offline)") }
            }
        }
    }
    // 1) Todas as consultas (BR + mundial, cada variante, e a busca por código) em paralelo;
    //    a primeira resposta válida vence e o tempo total é limitado (~2,2 s).
    val tasks = ArrayList<() -> FoodItem?>()
    for (c in variants) {
        tasks.add { fetchProduct("br.openfoodfacts.org", c) }
        tasks.add { fetchProduct("world.openfoodfacts.org", c) }
    }
    variants.firstOrNull()?.let { c ->
        tasks.add {
            try {
                val q = java.net.URLEncoder.encode(c, "UTF-8")
                val ep = "https://world.openfoodfacts.org/cgi/search.pl?search_terms=$q&search_simple=1&action=process&json=1&page_size=5&fields=product_name,product_name_pt,brands,nutriments,serving_size,code"
                val conn = (URL(ep).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    setRequestProperty("User-Agent", "GlucoCris/1.7 (Android; barcode-search)")
                    setRequestProperty("Connection", "close")
                    connectTimeout = 1500
                    readTimeout = 2000
                }
                if (conn.responseCode != 200) null else {
                    val json = org.json.JSONObject(conn.inputStream.bufferedReader().readText())
                    val products = json.optJSONArray("products")
                    if (products != null && products.length() > 0) {
                        val p = products.getJSONObject(0)
                        // só aceita se o código do produto bate com o lido
                        if (p.optString("code").trimStart('0') == c.trimStart('0')) {
                            parseProduct(org.json.JSONObject().put("status", 1).put("product", p), c)
                        } else null
                    } else null
                }
            } catch (_: Exception) { null }
        }
    }
    val result = kotlinx.coroutines.CompletableDeferred<FoodItem?>()
    val pending = java.util.concurrent.atomic.AtomicInteger(tasks.size)
    val fallback = java.util.concurrent.atomic.AtomicReference<FoodItem?>(null)
    // Escopo separado: chamadas de rede bloqueantes não seguram a resposta depois que alguém vence
    val raceScope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.SupervisorJob() + Dispatchers.IO)
    tasks.forEach { task ->
        raceScope.launch {
            val r = try { task() } catch (_: Exception) { null }
            if (r != null && r.reliability != "verificar") {
                result.complete(r)
            } else {
                // produto sem dados nutricionais: guarda de reserva e espera uma fonte melhor
                if (r != null && fallback.get() == null) fallback.compareAndSet(null, r)
                if (pending.decrementAndGet() == 0) result.complete(fallback.get())
            }
        }
    }
    val found = kotlinx.coroutines.withTimeoutOrNull(2200L) { result.await() } ?: fallback.get()
    raceScope.cancel()
    if (found != null && context != null && found.reliability != "verificar") BarcodeCache.put(context, digits, found)
    found
}

fun normSearch(s: String): String = s.lowercase().trim()
    .replace("ã", "a").replace("á", "a").replace("â", "a").replace("à", "a")
    .replace("é", "e").replace("ê", "e")
    .replace("í", "i")
    .replace("ó", "o").replace("ô", "o").replace("õ", "o")
    .replace("ú", "u").replace("ü", "u")
    .replace("ç", "c")
    .replace("-", " ")
    .replace(Regex("\\s+"), " ")

fun editDistance(a: String, b: String): Int {
    if (a == b) return 0
    if (a.isEmpty()) return b.length
    if (b.isEmpty()) return a.length
    if (kotlin.math.abs(a.length - b.length) > 4) return 99
    val m = a.length
    val n = b.length
    var prev = IntArray(n + 1) { it }
    var cur = IntArray(n + 1)
    for (i in 1..m) {
        cur[0] = i
        for (j in 1..n) {
            val cost = if (a[i - 1] == b[j - 1]) 0 else 1
            cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
        }
        val tmp = prev; prev = cur; cur = tmp
    }
    return prev[n]
}

private val TYPO_FIXES = mapOf(
    "oco" to "ovo",
    "arrois" to "arroz",
    "arros" to "arroz",
    "frang" to "frango",
    "frango grelhad" to "frango grelhado",
    "pao frances" to "pão francês",
    "pao parmesao" to "pão parmesão",
    "pao parmesão" to "pão parmesão",
    "parmesao" to "parmesão",
    "leite intgral" to "leite integral",
    "intgral" to "integral",
    "manteig" to "manteiga",
    "feija" to "feijão",
    "macarra" to "macarrão",
    "batata doce" to "batata-doce",
)

fun expandSmartQuery(query: String): Pair<String, List<String>> {
    val n = normSearch(query)
    val suggestions = mutableListOf<String>()
    var expanded = n
    TYPO_FIXES.forEach { (wrong, right) ->
        val wn = normSearch(wrong)
        val rn = normSearch(right)
        if (n == wn || n.startsWith("$wn ") || n.endsWith(" $wn") || " $wn " in " $n ") {
            expanded = n.replace(wn, rn)
            val tip = right.replaceFirstChar { ch -> ch.uppercase() }
            if (tip !in suggestions) suggestions.add(tip)
        }
    }
    if (n.length in 2..5 && editDistance(n, "ovo") <= 1 && n != "ovo") {
        expanded = "ovo"
        listOf("Ovo", "Ovo cozido", "Ovo frito", "Ovo mexido").forEach {
            if (it !in suggestions) suggestions.add(it)
        }
    }
    if (n.contains("parmes") || n.contains("parmesao")) {
        if ("Pão parmesão" !in suggestions) suggestions.add("Pão parmesão")
        if (!expanded.contains("parmes")) expanded = "$expanded pao parmesao".trim()
    }
    return expanded to suggestions.distinct()
}

private val SEARCH_SYNONYMS = mapOf(
    "ovo" to listOf("ovos", "egg", "egg white", "clara", "gema", "galinha"),
    "ovos" to listOf("ovo", "egg"),
    "vermelho" to listOf("ovo", "galinha"),
    "caipira" to listOf("ovo", "galinha"),
    "organico" to listOf("ovo", "orgânico"),
    "orgânico" to listOf("ovo", "organico"),
    "feijao" to listOf("feijão", "bean", "carioca", "preto"),
    "feijão" to listOf("feijao", "bean"),
    "pao" to listOf("pão", "bread", "frances", "francês"),
    "pão" to listOf("pao", "bread", "francês"),
    "frances" to listOf("pão", "pao", "francês"),
    "francês" to listOf("pão", "pao", "frances"),
    "manteiga" to listOf("butter", "margarina"),
    "mussarela" to listOf("muçarela", "mozarela", "queijo"),
    "muçarela" to listOf("mussarela", "queijo"),
    "acucar" to listOf("açúcar", "sugar"),
    "açúcar" to listOf("acucar", "sugar"),
    "oleo" to listOf("óleo", "oil"),
    "óleo" to listOf("oleo", "oil"),
    "mandioca" to listOf("aipim", "macaxeira", "cassava"),
    "aipim" to listOf("mandioca", "macaxeira"),
    "frango" to listOf("galinha", "chicken"),
    "banana" to listOf("banana-prata", "banana nanica", "banana maçã"),
    "arroz" to listOf("rice", "branco", "integral"),
)

/** Frases completas → termos extras de busca (sem remover o texto original). */
private val SEARCH_PHRASES = mapOf(
    "ovo vermelho" to listOf("ovo de galinha", "ovo cozido", "ovo"),
    "ovos vermelhos" to listOf("ovo de galinha", "ovo"),
    "ovo caipira" to listOf("ovo de galinha", "ovo"),
    "ovo organico" to listOf("ovo de galinha", "ovo"),
    "ovo orgânico" to listOf("ovo de galinha", "ovo"),
    "ovo branco" to listOf("ovo de galinha", "ovo"),
    "pao frances" to listOf("pão francês", "pão"),
    "pão francês" to listOf("pao frances", "pão"),
    "pao parmesao" to listOf("pão parmesão", "pão"),
    "pão parmesão" to listOf("pao parmesao", "pão"),
    "pao de sal" to listOf("pão francês", "pão"),
    "pão de sal" to listOf("pão francês", "pão"),
)


fun searchLocal(query: String, taco: List<FoodItem>): List<FoodItem> {
    val q = query.lowercase().trim()
        .replace("ã", "a").replace("á", "a").replace("â", "a")
        .replace("é", "e").replace("ê", "e")
        .replace("í", "i")
        .replace("ó", "o").replace("ô", "o").replace("õ", "o")
        .replace("ú", "u").replace("ç", "c")
    if (q.isBlank()) return emptyList()
    val rawParts = query.lowercase().trim().split(" ").filter { it.length > 1 }
    val phraseExtras = SEARCH_PHRASES.entries
        .filter { (phrase, _) -> q.contains(phrase.replace("ã","a").replace("á","a").replace("ç","c").replace("é","e").replace("í","i").replace("ó","o").replace("ô","o").replace("õ","o").replace("ú","u"))
            || phrase in query.lowercase() }
        .flatMap { it.value }
    val parts = (rawParts + rawParts.flatMap { SEARCH_SYNONYMS[it] ?: emptyList() } + phraseExtras)
        .flatMap { listOf(it) + (SEARCH_SYNONYMS[it] ?: emptyList()) }
        .distinct()
    fun norm(s: String) = s.lowercase()
        .replace("ã", "a").replace("á", "a").replace("â", "a")
        .replace("é", "e").replace("ê", "e")
        .replace("í", "i")
        .replace("ó", "o").replace("ô", "o").replace("õ", "o")
        .replace("ú", "u").replace("ç", "c")
    val (smartQ, _) = expandSmartQuery(query)
    val qUse = if (smartQ.isNotBlank()) smartQ else q
    fun score(f: FoodItem): Int {
        val n = norm(f.name)
        val b = norm(f.brand)
        var s = 0
        if (n == q || n == qUse || b == q) s += 100
        if (n.startsWith(q) || n.startsWith(qUse)) s += 50
        if (n.contains(q) || n.contains(qUse) || b.contains(q) || b.contains(qUse)) s += 30
        parts.forEach { p0 ->
            val pn = norm(p0)
            if (n.contains(pn) || b.contains(pn)) s += 10
            n.split(" ").forEach { w ->
                if (w.length >= 3 && pn.length >= 3 && editDistance(w, pn) <= 1) s += 8
            }
        }
        val first = n.split(" ").firstOrNull().orEmpty()
        if (first.length >= 3 && q.length >= 3 && editDistance(first, q) <= 1) s += 25
        if (first.length >= 3 && qUse.length >= 3 && editDistance(first, qUse) <= 1) s += 20
        if (f.sourceKey == "taco" || f.sourceKey == "local" || f.sourceKey == "restaurant_official" || f.sourceKey == "restaurant_estimate") s += 5
        return s
    }
    return (EXTRA_FOODS + taco)
        .map { it to score(it) }
        .filter { it.second > 0 }
        .sortedByDescending { it.second }
        .map { it.first }
        .take(80)
}

/**
 * Mesma capacidade da pesquisa de alimentos: local (TACO/extras/sinônimos) +
 * custom + Open Food Facts (BR+world) + USDA, com ranking e dedupe.
 * Usado pela busca digitada e pelo Scanner inteligente.
 */
suspend fun searchFoodsComplete(context: Context, query: String, taco: List<FoodItem>? = null): List<FoodItem> {
    val text = query.trim()
    if (text.isBlank()) return emptyList()
    val tacoList = taco ?: loadTacoFoods(context)
    val customAsFood = try {
        loadCustomFoods(context).map { c ->
            FoodItem(
                id = c.id, name = c.name, serving = c.serving, servingGrams = 100.0,
                kcal = c.kcal, carbs = c.carbs, protein = c.protein, fat = c.fat,
                source = "Meu alimento", sourceKey = "custom", isGeneric = true, reliability = "alta",
            )
        }.filter {
            val q = text.lowercase()
            it.name.lowercase().contains(q) || q.split(" ").any { p -> p.length > 1 && it.name.lowercase().contains(p) }
        }
    } catch (_: Exception) {
        emptyList()
    }
    val local = searchLocal(text, tacoList) + customAsFood
    val cachedOnline = getOnlineCached(text)
    val onlineOk = isNetworkOnline(context)
    val wifi = isWifiOnline(context)
    val offline = when {
        !onlineOk -> emptyList()
        cachedOnline != null -> cachedOnline
        // Catálogo online fresco prioriza Wi‑Fi (dados móveis: local + cache)
        !wifi -> emptyList()
        else -> {
            val (off, usda) = coroutineScope {
                val a = async(Dispatchers.IO) { searchOpenFoodFacts(text) }
                val b = async(Dispatchers.IO) { searchUsda(text) }
                a.await() to b.await()
            }
            val combined = (off + usda).distinctBy { it.id }
            putOnlineCached(text, combined)
            combined
        }
    }
    val ql = text.lowercase()
    return (local + offline)
        .distinctBy { "${it.name.lowercase()}|${it.brand.lowercase()}|${it.sourceKey}" }
        .sortedByDescending { f ->
            var s = 0
            val n = f.name.lowercase(); val b = f.brand.lowercase()
            if (n.startsWith(ql) || b.startsWith(ql)) s += 40
            if (n.contains(ql) || b.contains(ql)) s += 20
            if (f.sourceKey == "taco" || f.sourceKey == "local" || f.sourceKey == "custom" || f.sourceKey == "restaurant_official" || f.sourceKey == "restaurant_estimate") s += 15
            if (f.sourceKey == "off") {
                s += 8
                val blob = (f.name + " " + f.brand).lowercase()
                if ("brazil" in (f.category.lowercase()) || "brasil" in blob || "br:" in blob) s += 12
            }
            if (f.sourceKey == "usda") s += 5
            if (b.isNotBlank()) s += 5
            // preferência a nomes que batem a frase completa
            if (n.contains(ql) && ql.length > 3) s += 10
            s
        }
}


@Composable
fun FoodMainScreen(vm: GlucoViewModel, nav: NavHostController) {
    FoodSearchScreen(vm, nav)
}

@Composable
fun FoodSearchScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<FoodItem>>(emptyList()) }
    var suggestions by remember { mutableStateOf<List<FoodItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var onlineLoading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var mealType by remember { mutableStateOf("cafe") }
    var mealExpanded by remember { mutableStateOf(false) }
    var didYouMean by remember { mutableStateOf<List<String>>(emptyList()) }
    var topTab by remember { mutableStateOf(1) }
    var favorites by remember { mutableStateOf(loadFavorites(context)) }
    // Montagem de prato (multi-seleção)
    val plateLines by vm.plate.collectAsStateWithLifecycle()
    val plateSelected: Map<String, FoodItem> = plateLines.associate { it.food.id to it.food }
    val plateList = plateLines.map { it.food.scaled(it.qty) }
    val plateCarbs = plateList.sumOf { it.carbs }
    val plateKcal = plateList.sumOf { it.kcal }
    val plateProt = plateList.sumOf { it.protein }
    val plateFat = plateList.sumOf { it.fat }
    var recent by remember { mutableStateOf(loadRecentSearches(context)) }
    val scope = rememberCoroutineScope()
    val data by vm.data.collectAsStateWithLifecycle()
    val taco = remember { loadTacoFoods(context) }
    var searchJob by remember { mutableStateOf<Job?>(null) }

    // Busca enquanto digita: local imediato + online com debounce
    fun onQueryChange(text: String) {
        query = text
        error = null
        searchJob?.cancel()
        val (_, tips) = expandSmartQuery(text)
        didYouMean = tips
        if (text.isBlank()) {
            suggestions = emptyList()
            results = emptyList()
            didYouMean = emptyList()
            loading = false
            onlineLoading = false
            return
        }
        // Local instantâneo
        val customAsFood = loadCustomFoods(context).map { c ->
            FoodItem(
                id = c.id, name = c.name, serving = c.serving, servingGrams = 100.0,
                kcal = c.kcal, carbs = c.carbs, protein = c.protein, fat = c.fat,
                source = "Meu alimento", sourceKey = "custom", isGeneric = true, reliability = "alta",
            )
        }
        val local = (searchLocal(text, taco) + customAsFood.filter {
            val q = text.lowercase(); it.name.lowercase().contains(q) || q.isBlank()
        }).distinctBy { it.id }
        suggestions = local.take(8)
        results = local
        loading = false
        // Online após pausa na digitação
        searchJob = scope.launch {
            delay(160)
            if (query != text || text.length < 2) return@launch
            onlineLoading = true
            val cached = getOnlineCached(text)
            val merged = searchFoodsComplete(context, text, taco)
            if (query == text) {
                results = merged
                suggestions = merged.take(12)
                if (merged.isEmpty()) error = "Nenhum resultado para \"$text\"."
            }
            onlineLoading = false
        }
    }

    fun openFood(food: FoodItem) {
        pushRecentSearch(context, query.ifBlank { food.name })
        pushRecentFood(context, food.id)
        recent = loadRecentSearches(context)
        vm.setTempFood(food, mealType)
        nav.navigate(Routes.FOOD_DETAIL)
    }

    fun toggleFav(food: FoodItem) {
        val next = favorites.toMutableSet()
        if (food.favoriteKey() in next) next.remove(food.favoriteKey()) else next.add(food.favoriteKey())
        favorites = next
        saveFavorites(context, next)
    }

    Column(Modifier.fillMaxSize().background(g.bg)) {
        // Header + refeição
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Filled.Close, null, tint = g.ink) }
            Box(Modifier.weight(1f)) {
                Row(
                    Modifier.clickable { mealExpanded = true }.padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        MEAL_OPTIONS.find { it.first == mealType }?.second ?: "Café da Manhã",
                        color = g.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp,
                    )
                    Text(" ▼", color = g.muted, fontSize = 12.sp)
                }
                DropdownMenu(expanded = mealExpanded, onDismissRequest = { mealExpanded = false }) {
                    MEAL_OPTIONS.forEach { (key, label) ->
                        DropdownMenuItem(
                            text = {
                                Text(label, color = if (key == mealType) g.green else g.ink,
                                    fontWeight = if (key == mealType) FontWeight.Bold else FontWeight.Normal)
                            },
                            onClick = { mealType = key; mealExpanded = false },
                            trailingIcon = { if (key == mealType) Text("✓", color = g.green) },
                        )
                    }
                }
            }
        }

        // Campo de busca
        OutlinedTextField(
            value = query,
            onValueChange = { onQueryChange(it) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text("Digite e veja as opções…", color = g.muted) },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = g.muted) },
            trailingIcon = {
                Row {
                    if (onlineLoading) {
                        CircularProgressIndicator(Modifier.size(18.dp).padding(end = 4.dp), strokeWidth = 2.dp, color = g.violet)
                    }
                    if (query.isNotEmpty()) {
                        IconButton(onClick = { onQueryChange("") }) {
                            Icon(Icons.Filled.Close, null, tint = g.muted)
                        }
                    }
                }
            },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = {
                pushRecentSearch(context, query)
                recent = loadRecentSearches(context)
            }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = g.violet,
                unfocusedBorderColor = g.card,
                focusedContainerColor = g.card,
                unfocusedContainerColor = g.card,
            ),
        )

        // Sugestões rápidas logo abaixo do campo (enquanto digita)
        AnimatedVisibility(visible = suggestions.isNotEmpty() && query.isNotBlank() && topTab == 1) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(g.card)
            ) {
                suggestions.take(6).forEach { food ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { openFood(food) }
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.Search, null, tint = g.muted, modifier = Modifier.size(16.dp))
                        Column(Modifier.weight(1f).padding(start = 10.dp)) {
                            Text(food.name, color = g.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                            Text(
                                buildString {
                                    if (food.brand.isNotBlank()) append("${food.brand} · ")
                                    append("${food.kcal.roundToInt()} kcal · ${food.carbs} g carb")
                                },
                                color = g.muted, fontSize = 12.sp, maxLines = 1,
                            )
                        }
                        Checkbox(
                            checked = food.id in plateSelected,
                            onCheckedChange = { vm.togglePlate(food) },
                        )
                    }
                    HorizontalDivider(color = g.line, thickness = 0.5.dp)
                }
            }
        }

        TabRow(selectedTabIndex = topTab, containerColor = g.bg, contentColor = g.violet) {
            Tab(selected = topTab == 0, onClick = { topTab = 0 }, text = { Text("Histórico", fontSize = 12.sp) }, icon = { Icon(Icons.Filled.History, null, Modifier.size(18.dp)) })
            Tab(selected = topTab == 1, onClick = { topTab = 1 }, text = { Text("Pesquisa", fontSize = 12.sp) }, icon = { Icon(Icons.Filled.Restaurant, null, Modifier.size(18.dp)) })
            Tab(selected = topTab == 2, onClick = { topTab = 2 }, text = { Text("Favoritos", fontSize = 12.sp) }, icon = { Icon(Icons.Filled.Favorite, null, Modifier.size(18.dp)) })
        }

        when (topTab) {
            0 -> LazyColumn(Modifier.padding(16.dp)) {
                if (recent.isNotEmpty()) {
                    item {
                        Text("Buscas recentes", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 6.dp))
                    }
                    items(recent) { term ->
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(g.card)
                                .clickable { onQueryChange(term); topTab = 1 }
                                .padding(12.dp)
                                .padding(bottom = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Icon(Icons.Filled.History, null, tint = g.muted, modifier = Modifier.size(18.dp))
                            Text(term, color = g.ink, fontSize = 14.sp, modifier = Modifier.padding(start = 10.dp))
                        }
                        Spacer(Modifier.height(6.dp))
                    }
                }
                item {
                    Text("Refeições salvas", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp, bottom = 6.dp))
                    Text("${taco.size} alimentos TACO offline · OFF + USDA online", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp))
                }
                items(data.meals.sortedByDescending { it.at }.take(25)) { m ->
                    GCard(Modifier.padding(bottom = 6.dp)) {
                        Text(MEAL_LABEL[m.type] ?: m.type, color = g.green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text(m.description, color = g.ink, fontSize = 14.sp)
                        Text(
                            formatDate(m.at) + " · " + formatTime(m.at) + (m.carbs?.let { " · ${it} g carb." } ?: ""),
                            color = g.muted, fontSize = 12.sp,
                        )
                    }
                }
                if (data.meals.isEmpty() && recent.isEmpty()) {
                    item { Text("Digite acima para buscar. O histórico aparece aqui.", color = g.muted) }
                }
            }
            1 -> Column(Modifier.fillMaxSize().padding(horizontal = 12.dp)) {
                if (plateLines.isNotEmpty()) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 6.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(g.greenSoft)
                            .clickable {
                                vm.plateMealType = mealType
                                nav.navigate(Routes.FOOD_PLATE)
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Prato: ${plateLines.size} item(ns) selecionado(s)",
                                color = g.ink, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            )
                            Text(
                                "${plateKcal.roundToInt()} kcal · ${"%.1f".format(plateCarbs)} g carb · ${"%.1f".format(plateProt)} g prot · ${"%.1f".format(plateFat)} g gord",
                                color = g.muted, fontSize = 11.sp,
                            )
                        }
                        Text("Ver prato ›", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = { nav.navigate(Routes.FOOD_BARCODE) },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                    ) {
                        Text("Cód. barras", color = g.violet, fontSize = 11.sp, maxLines = 2)
                    }
                    OutlinedButton(
                        onClick = { nav.navigate(Routes.FOOD_SMART_SCAN) },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                    ) {
                        Text("Scanner prato", color = g.violet, fontSize = 11.sp, maxLines = 2)
                    }
                    OutlinedButton(
                        onClick = {
                            vm.plateMealType = mealType
                            nav.navigate(Routes.FOOD_PLATE)
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                    ) {
                        Text(
                            if (plateLines.isEmpty()) "Prato" else "Prato (${plateLines.size})",
                            color = if (plateLines.isEmpty()) g.violet else g.green,
                            fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 2,
                        )
                    }
                    OutlinedButton(
                        onClick = { nav.navigate(Routes.FOOD_RECIPES) },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                    ) {
                        Text("Receitas", color = g.violet, fontSize = 11.sp, maxLines = 2)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { nav.navigate(Routes.FOOD_REPORTS) }, modifier = Modifier.weight(1f)) {
                        Text("Relatórios", color = g.violet, fontSize = 13.sp)
                    }
                    OutlinedButton(onClick = { nav.navigate(Routes.FOOD_DIARY) }, modifier = Modifier.weight(1f)) {
                        Text("Diário", color = g.violet, fontSize = 13.sp)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { nav.navigate(Routes.FOOD_TOOLS) }, modifier = Modifier.weight(1f)) {
                        Text("Ferramentas", color = g.violet, fontSize = 13.sp)
                    }
                    OutlinedButton(onClick = { nav.navigate(Routes.FOOD_BOLUS) }, modifier = Modifier.weight(1f)) {
                        Text("Bolus", color = g.violet, fontSize = 13.sp)
                    }
                }
                if (didYouMean.isNotEmpty() && query.isNotBlank()) {
                    Text("Você quis dizer?", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        didYouMean.take(4).forEach { tip ->
                            Text(
                                tip,
                                color = g.violet,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .background(g.lilacSoft)
                                    .clickable { onQueryChange(tip) }
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                            )
                        }
                    }
                }
                when {
                    !isNetworkOnline(context) && query.isNotBlank() -> Text(
                        "Sem internet — usando só TACO/local e cache. Busca online indisponível.",
                        color = g.orange, fontSize = 12.sp, modifier = Modifier.padding(4.dp),
                    )
                    isNetworkOnline(context) && !isWifiOnline(context) && query.isNotBlank() -> Text(
                        "Em dados móveis: TACO/local e cache. Catálogo online completo em Wi‑Fi.",
                        color = g.orange, fontSize = 12.sp, modifier = Modifier.padding(4.dp),
                    )
                }
                error?.let { Text(it, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(4.dp)) }
                if (results.isNotEmpty()) {
                    Text(
                        "${results.size} resultados" + if (onlineLoading) " · buscando online…" else "",
                        color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 4.dp),
                    )
                }
                LazyColumn {
                    if (query.isBlank()) {
                        val recentIds = loadRecentFoodIds(context)
                        val recentFoods = recentIds.mapNotNull { id ->
                            results.find { it.id == id } ?: (EXTRA_FOODS + taco).find { it.id == id }
                        }.distinctBy { it.id }.take(8)
                        val favFoods = (EXTRA_FOODS + taco).filter { it.favoriteKey() in favorites }.take(8)
                        if (favFoods.isNotEmpty()) {
                            item {
                                Text("Favoritos", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(vertical = 6.dp))
                            }
                            items(favFoods, key = { "fav-${it.id}" }) { food ->
                                FoodResultRow(
                                    food = food,
                                    isFav = true,
                                    selected = food.id in plateSelected,
                                    onOpen = { openFood(food) },
                                    onFav = { toggleFav(food) },
                                    onToggleSelect = { vm.togglePlate(food) },
                                )
                            }
                        }
                        if (recentFoods.isNotEmpty()) {
                            item {
                                Text("Usados recentemente", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(vertical = 6.dp))
                            }
                            items(recentFoods, key = { "rec-${it.id}" }) { food ->
                                FoodResultRow(
                                    food = food,
                                    isFav = food.favoriteKey() in favorites,
                                    selected = food.id in plateSelected,
                                    onOpen = { openFood(food) },
                                    onFav = { toggleFav(food) },
                                    onToggleSelect = { vm.togglePlate(food) },
                                )
                            }
                        }
                    }
                    items(results, key = { it.id }) { food ->
                        FoodResultRow(
                            food = food,
                            isFav = food.favoriteKey() in favorites,
                            selected = food.id in plateSelected,
                            onOpen = { openFood(food) },
                            onFav = { toggleFav(food) },
                            onToggleSelect = { vm.togglePlate(food) },
                        )
                    }
                }
                // Prato + gráficos + resumo do dia (atualiza ao marcar/desmarcar)
                if (plateSelected.isNotEmpty()) {
                    val dayStart = remember {
                        java.util.Calendar.getInstance().apply {
                            set(java.util.Calendar.HOUR_OF_DAY, 0)
                            set(java.util.Calendar.MINUTE, 0)
                            set(java.util.Calendar.SECOND, 0)
                            set(java.util.Calendar.MILLISECOND, 0)
                        }.timeInMillis
                    }
                    val dayMeals = data.meals.filter { it.at >= dayStart }
                    val dayCarbsDiary = dayMeals.mapNotNull { it.carbs }.sum()
                    val dayKcalDiary = dayMeals.sumOf { m ->
                        Regex("""kcal=(\d+)""").find(m.notes)?.groupValues?.getOrNull(1)?.toDoubleOrNull() ?: 0.0
                    }
                    // Resumo = diário de hoje + prato atual (ainda não salvo)
                    val sumCarbs = dayCarbsDiary + plateCarbs
                    val sumKcal = dayKcalDiary + plateKcal
                    val sumProt = plateProt // diário não guarda prot separado de forma confiável
                    val sumFat = plateFat
                    val macroTotal = (plateCarbs * 4 + plateProt * 4 + plateFat * 9).coerceAtLeast(0.1)
                    val pctC = ((plateCarbs * 4) / macroTotal * 100).toFloat()
                    val pctP = ((plateProt * 4) / macroTotal * 100).toFloat()
                    val pctF = ((plateFat * 9) / macroTotal * 100).toFloat()

                    GCard(Modifier.padding(vertical = 8.dp)) {
                        Text(
                            "Prato atual · ${plateSelected.size} item(ns)",
                            color = g.ink, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                        )
                        Text(
                            plateList.joinToString(" · ") { it.name }.take(140),
                            color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp, bottom = 8.dp),
                        )
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            // Gráfico de pizza do prato
                            Box(Modifier.size(96.dp), contentAlignment = Alignment.Center) {
                                Canvas(Modifier.fillMaxSize()) {
                                    val stroke = size.minDimension * 0.18f
                                    val diam = size.minDimension - stroke
                                    val topLeft = Offset((size.width - diam) / 2f, (size.height - diam) / 2f)
                                    val arcSize = Size(diam, diam)
                                    var start = -90f
                                    val slices = listOf(
                                        pctC to androidx.compose.ui.graphics.Color(0xFF38BDF8),
                                        pctF to androidx.compose.ui.graphics.Color(0xFFFBBF24),
                                        pctP to androidx.compose.ui.graphics.Color(0xFFF472B6),
                                    )
                                    slices.forEach { (pct, col) ->
                                        val sweep = 360f * (pct / 100f).coerceIn(0f, 1f)
                                        if (sweep > 0.5f) {
                                            drawArc(
                                                color = col,
                                                startAngle = start,
                                                sweepAngle = sweep,
                                                useCenter = false,
                                                topLeft = topLeft,
                                                size = arcSize,
                                                style = Stroke(width = stroke, cap = androidx.compose.ui.graphics.StrokeCap.Butt),
                                            )
                                        }
                                        start += sweep
                                    }
                                }
                                Text("${plateKcal.roundToInt()}\nkcal", color = g.ink, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                Text("Macronutrientes do prato", color = g.ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                Text("Carboidratos: ${"%.1f".format(plateCarbs)} g (${pctC.roundToInt()}%)", color = g.ink, fontSize = 13.sp)
                                Text("Gorduras: ${"%.1f".format(plateFat)} g (${pctF.roundToInt()}%)", color = g.ink, fontSize = 13.sp)
                                Text("Proteínas: ${"%.1f".format(plateProt)} g (${pctP.roundToInt()}%)", color = g.ink, fontSize = 13.sp)
                            }
                        }
                        HorizontalDivider(color = g.line, modifier = Modifier.padding(vertical = 10.dp))
                        Text("Resumo do dia (diário + este prato)", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "Atualiza ao marcar ou desmarcar itens. O prato só entra no diário ao salvar.",
                            color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp),
                        )
                        Text("Calorias do prato: ${plateKcal.roundToInt()} kcal", color = g.violetDeep, fontWeight = FontWeight.SemiBold)
                        Text("Carboidratos (dia + prato): ${"%.1f".format(sumCarbs)} g", color = g.ink, fontSize = 13.sp)
                        Text("Refeições já no diário hoje: ${dayMeals.size} · ~${"%.0f".format(dayCarbsDiary)} g carb", color = g.muted, fontSize = 12.sp)
                        if (dayKcalDiary > 0) {
                            Text("Kcal estimadas no diário: ${dayKcalDiary.roundToInt()} + prato ${plateKcal.roundToInt()} ≈ ${(dayKcalDiary + plateKcal).roundToInt()}", color = g.muted, fontSize = 12.sp)
                        }
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            TextButton(onClick = { vm.clearPlate() }) {
                                Text("Desmarcar", color = g.muted)
                            }
                            TextButton(onClick = {
                                val desc = plateList.joinToString(" + ") { it.name }
                                vm.saveMeal(
                                    Meal(
                                        id = uid(),
                                        type = mealType,
                                        description = desc,
                                        carbs = plateCarbs,
                                        at = System.currentTimeMillis(),
                                        notes = "kcal=${plateKcal.roundToInt()};prot=${"%.1f".format(plateProt)};fat=${"%.1f".format(plateFat)};fonte=prato",
                                    ),
                                )
                                vm.clearPlate()
                            }) {
                                Text("Salvar no diário", color = g.green, fontWeight = FontWeight.Bold)
                            }
                        }
                        PrimaryButton("Bolus com este prato", g.violet, {
                            context.getSharedPreferences("gluco_food_tools", Context.MODE_PRIVATE)
                                .edit().putFloat("last_meal_carbs", plateCarbs.toFloat()).apply()
                            nav.navigate(Routes.FOOD_BOLUS)
                        }, Modifier.padding(top = 6.dp))
                        Text(
                            "Bolus usa o carb do prato e seus fatores. Confirme antes de aplicar insulina.",
                            color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                }
            }
            2 -> {
                val favItems = remember(favorites, taco) {
                    val all = EXTRA_FOODS + taco
                    all.filter { it.favoriteKey() in favorites }
                }
                LazyColumn(Modifier.padding(16.dp)) {
                    item {
                        Text("Favoritos", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text("Toque no coração na lista de resultados para salvar.", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                    }
                    if (favItems.isEmpty()) {
                        item { Text("Nenhum favorito ainda.", color = g.muted) }
                    }
                    items(favItems) { food ->
                        FoodResultRow(
                            food = food,
                            isFav = true,
                            onOpen = { pushRecentFood(context, food.id); openFood(food) },
                            onFav = { toggleFav(food) },
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FoodResultRow(
    food: FoodItem,
    isFav: Boolean,
    selected: Boolean = false,
    onOpen: () -> Unit,
    onFav: () -> Unit,
    onToggleSelect: (() -> Unit)? = null,
) {
    val g = glucoColors()
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onToggleSelect != null) {
            Checkbox(
                checked = selected,
                onCheckedChange = { onToggleSelect() },
            )
        }
        Column(
            Modifier
                .weight(1f)
                .clickable(onClick = onOpen),
        ) {
            Text(food.name, color = g.ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
            if (food.brand.isNotBlank()) Text(food.brand, color = g.violet, fontSize = 12.sp)
            Row {
                Text(food.serving, color = g.green, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                Text("  ·  IDR ${food.idrPercent()}%  ·  ${food.kcal.roundToInt()} kcal", color = g.muted, fontSize = 13.sp)
            }
            Text(
            buildString {
                append("${food.carbs} g carb · ${food.source}")
                when (food.sourceKey) {
                    "off", "usda" -> append(" · online")
                    "taco", "local", "custom" -> append(" · offline")
                    "gemini" -> append(" · IA")
                }
            },
            color = g.muted, fontSize = 11.sp,
        )
        }
        IconButton(onClick = onFav) {
            Icon(
                if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                contentDescription = "Favorito",
                tint = if (isFav) g.blush else g.muted,
            )
        }
        Text("›", color = g.muted, fontSize = 20.sp)
    }
    HorizontalDivider(color = g.line)
}

@Composable
fun FoodDetailScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    val food = vm.tempFood
    val mealType = vm.tempMealType
    if (food == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Nenhum alimento selecionado", color = g.muted)
        }
        return
    }
    var qty by remember { mutableStateOf(1.0) }
    var qtyText by remember { mutableStateOf("1") }
    var portionLabel by remember { mutableStateOf(food.serving) }
    var gramsText by remember { mutableStateOf("") }
    var favorites by remember { mutableStateOf(loadFavorites(context)) }
    fun parseDec(s: String): Double? = s.replace(",", ".").trim().toDoubleOrNull()
    // Peso em g/ml tem prioridade; senão quantidade de porções
    val factor = run {
        val gCustom = parseDec(gramsText)
        when {
            gCustom != null && gCustom > 0 && food.servingGrams > 0 -> gCustom / food.servingGrams
            else -> (parseDec(qtyText) ?: qty).coerceAtLeast(0.0)
        }
    }
    val s = food.scaled(factor)
    val idr = food.idrPercent(factor)
    val isFav = food.favoriteKey() in favorites

    Column(Modifier.fillMaxSize().background(g.bg)) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Filled.Close, null, tint = g.ink) }
            Column(Modifier.weight(1f)) {
                Text(food.name, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                if (food.brand.isNotBlank()) Text(food.brand, color = g.violet, fontSize = 13.sp)
            }
            IconButton(onClick = {
                val next = favorites.toMutableSet()
                if (isFav) next.remove(food.favoriteKey()) else next.add(food.favoriteKey())
                favorites = next
                saveFavorites(context, next)
            }) {
                Icon(if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = if (isFav) g.blush else g.muted)
            }
        }

        ScrollScreen {
            // Badge fonte
            Row(
                Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(g.lilacSoft)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
            ) {
                Text("${food.source} · ${food.reliability}", color = g.violetDeep, fontSize = 12.sp, fontWeight = FontWeight.Medium)
            }

            SectionTitle("Adicionar ao meu Diário Alimentar")
            GCard {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                    Text("Qtd", color = g.muted, fontSize = 13.sp, modifier = Modifier.width(36.dp))
                    OutlinedTextField(
                        value = qtyText,
                        onValueChange = { raw ->
                            val filtered = raw.filter { it.isDigit() || it == ',' || it == '.' || it == '-' }
                            qtyText = filtered
                            parseDec(filtered)?.let { if (it >= 0) { qty = it; gramsText = "" } }
                        },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = g.violet,
                            unfocusedBorderColor = g.line,
                            focusedContainerColor = g.inputBg,
                            unfocusedContainerColor = g.inputBg,
                        ),
                    )
                    IconButton(onClick = {
                        val next = ((parseDec(qtyText) ?: qty) - 0.5).coerceAtLeast(0.0)
                        qty = next
                        qtyText = if (next == next.toLong().toDouble()) next.toLong().toString() else "%.1f".format(next)
                        gramsText = ""
                    }) {
                        Text("−", fontSize = 24.sp, color = g.violet, fontWeight = FontWeight.Bold)
                    }
                    IconButton(onClick = {
                        val next = (parseDec(qtyText) ?: qty) + 0.5
                        qty = next
                        qtyText = if (next == next.toLong().toDouble()) next.toLong().toString() else "%.1f".format(next)
                        gramsText = ""
                    }) {
                        Text("+", fontSize = 24.sp, color = g.violet, fontWeight = FontWeight.Bold)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                    Text("Porção", color = g.muted, fontSize = 13.sp, modifier = Modifier.width(48.dp))
                    OutlinedTextField(
                        value = portionLabel,
                        onValueChange = { portionLabel = it },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        placeholder = { Text(food.serving, color = g.muted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = g.violet,
                            unfocusedBorderColor = g.line,
                            focusedContainerColor = g.inputBg,
                            unfocusedContainerColor = g.inputBg,
                        ),
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
                    Text("Peso", color = g.muted, fontSize = 13.sp, modifier = Modifier.width(48.dp))
                    OutlinedTextField(
                        value = gramsText,
                        onValueChange = { raw ->
                            gramsText = raw.filter { it.isDigit() || it == ',' || it == '.' }
                        },
                        modifier = Modifier.weight(1f),
                        singleLine = true,
                        placeholder = { Text("g ou ml (opcional)", color = g.muted) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal, imeAction = ImeAction.Done),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = g.violet,
                            unfocusedBorderColor = g.line,
                            focusedContainerColor = g.inputBg,
                            unfocusedContainerColor = g.inputBg,
                        ),
                    )
                }
                Text(
                    "Base da tabela: ${food.serving} (${food.servingGrams} g). Nutrientes recalculados pela quantidade ou pelo peso.",
                    color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 6.dp),
                )
                Text(
                    "Refeição: ${MEAL_OPTIONS.find { it.first == mealType }?.second}",
                    color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 10.dp),
                )
                OutlinedButton(onClick = {
                    val portionShow = portionLabel.ifBlank { food.serving }
                    val desc = buildString {
                        append(food.name)
                        if (food.brand.isNotBlank()) append(" (${food.brand})")
                        val gCustom = parseDec(gramsText)
                        if (gCustom != null && gCustom > 0) {
                            append(" · ${"%.1f".format(gCustom)} g/ml (${portionShow})")
                        } else {
                            append(" · ${"%.1f".format(factor)}× ${portionShow}")
                        }
                    }
                    vm.saveMeal(
                        Meal(
                            id = uid(),
                            type = mealType,
                            description = desc,
                            carbs = s.carbs,
                            at = System.currentTimeMillis(),
                            notes = "kcal=${s.kcal.roundToInt()};prot=${"%.1f".format(s.protein)};fat=${"%.1f".format(s.fat)};fiber=${"%.1f".format(s.fiber)};fonte=${food.source};fator=${"%.4f".format(factor)}",
                        ),
                    )
                    nav.popBackStack(Routes.FOOD, false)
                },
                    modifier = Modifier.fillMaxWidth().height(40.dp),
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, g.muted.copy(alpha = 0.35f)),
                ) {
                    Text("ADD NO DIARIO", color = g.muted, fontWeight = FontWeight.Medium, fontSize = 13.sp)
                }
                Spacer(Modifier.height(8.dp))
                PrimaryButton("Adicionar ao prato", g.violet, {
                    val gCustom = parseDec(gramsText)
                    val q = (parseDec(qtyText) ?: qty).coerceAtLeast(0.5)
                    vm.plateMealType = mealType
                    vm.addToPlate(
                        food,
                        qty = q,
                        grams = if (gCustom != null && gCustom > 0) gCustom else null,
                    )
                    nav.navigate(Routes.FOOD_PLATE)
                })
                Text(
                    "Monta o prato com a quantidade/peso desta tela e abre o prato.",
                    color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp),
                )
                Spacer(Modifier.height(8.dp))
                // Salvar no catálogo pessoal (Meus alimentos)
                var catalogMsg by remember { mutableStateOf<String?>(null) }
                PrimaryButton("➕ Salvar no catálogo Gluco Cris", g.green, {
                    val item = CustomFood(
                        id = uid(),
                        name = buildString {
                            append(food.name)
                            if (food.brand.isNotBlank()) append(" (${food.brand})")
                        },
                        serving = portionLabel.ifBlank { food.serving },
                        carbs = s.carbs,
                        protein = s.protein,
                        fat = s.fat,
                        kcal = s.kcal,
                    )
                    val list = loadCustomFoods(context)
                    // Evita duplicar pelo mesmo nome+serving recente
                    saveCustomFoods(context, listOf(item) + list.filter { it.name != item.name || it.serving != item.serving })
                    catalogMsg = "✅ Salvo no catálogo: ${item.name}"
                })
                catalogMsg?.let {
                    Text(it, color = g.green, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
                Text(
                    "Grava este item (com a quantidade atual) em Meus alimentos para reutilizar depois.",
                    color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp),
                )
            }

            // Resumo em cards
            Spacer(Modifier.height(10.dp))
            Text("Resumo para esta quantidade", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth()) {
                NutriCard("Calorias", "${s.kcal.roundToInt()}", "$idr% IDR", Modifier.weight(1f), g)
                NutriCard("Carboidratos", "%.1f g".format(s.carbs), "destaque DM", Modifier.weight(1f), g)
            }
            Row(Modifier.fillMaxWidth()) {
                NutriCard("Proteínas", "%.1f g".format(s.protein), "", Modifier.weight(1f), g)
                NutriCard("Gorduras", "%.1f g".format(s.fat), "", Modifier.weight(1f), g)
            }

            // Estimativa de bolus com os fatores já configurados (não é prescrição)
            val dataState = vm.data.collectAsStateWithLifecycle().value
            val bolusFactors = remember { loadBolusFactors(context) }
            val lastGlu = dataState.glucose.firstOrNull()?.let {
                if (it.unit.equals("mmol/L", true) || it.unit.equals("mmol", true)) it.value * 18.0 else it.value
            }
            val iobEst = remember(dataState.insulin) {
                estimateIobFromLog(dataState.insulin, bolusFactors.durationHours)
            }
            SectionTitle("Bolus estimado (seus fatores)")
            GCard {
                Text(
                    "Usa a razão carb / sensibilidade que você cadastrou na calculadora. " +
                        "É só apoio de conta — confirme com sua equipe. Não aplique cegamente.",
                    color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp),
                )
                if (bolusFactors.carbRatio <= 0) {
                    Text(
                        "Cadastre a razão de carboidrato (g por 1 U) em Ferramentas → Bolus.",
                        color = g.orange, fontSize = 13.sp,
                    )
                    PrimaryButton("Abrir calculadora de bolus", g.violet, {
                        context.getSharedPreferences("gluco_food_tools", Context.MODE_PRIVATE)
                            .edit().putFloat("last_meal_carbs", s.carbs.toFloat()).apply()
                        nav.navigate(Routes.FOOD_BOLUS)
                    }, Modifier.padding(top = 10.dp))
                } else {
                    val mealOnly = s.carbs / bolusFactors.carbRatio
                    val corrOnly = if (bolusFactors.sensitivity > 0 && lastGlu != null) {
                        ((lastGlu - bolusFactors.target) / bolusFactors.sensitivity).coerceAtLeast(0.0)
                    } else null
                    val full = computeBolus(
                        s.carbs,
                        lastGlu ?: bolusFactors.target,
                        bolusFactors,
                        iobEst,
                        includeMeal = true,
                        includeCorr = lastGlu != null && bolusFactors.sensitivity > 0,
                        roundStep = 0.5,
                    )
                    Text("Carb desta porção: ${"%.1f".format(s.carbs)} g", color = g.ink, fontWeight = FontWeight.Medium)
                    Text(
                        "Bolus de refeição (só carb): ~${"%.1f".format(mealOnly)} U",
                        color = g.violetDeep, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                    if (lastGlu != null) {
                        Text(
                            "Última glicemia no app: ${lastGlu.roundToInt()} mg/dL" +
                                (if (corrOnly != null) " · correção ~${"%.1f".format(corrOnly)} U" else ""),
                            color = g.muted, fontSize = 12.sp,
                        )
                    } else {
                        Text("Sem glicemia recente no app — só o bolus de refeição foi estimado.", color = g.muted, fontSize = 12.sp)
                    }
                    if (iobEst > 0.05) {
                        Text("IOB estimado (registros): ~${"%.1f".format(iobEst)} U", color = g.muted, fontSize = 12.sp)
                    }
                    if (full != null) {
                        Text(
                            "Sugestão total arredondada: ~${"%.1f".format(full.third)} U",
                            color = g.green, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp,
                            modifier = Modifier.padding(top = 8.dp),
                        )
                    }
                    PrimaryButton("Abrir calculadora de bolus", g.violet, {
                        context.getSharedPreferences("gluco_food_tools", Context.MODE_PRIVATE)
                            .edit().putFloat("last_meal_carbs", s.carbs.toFloat()).apply()
                        nav.navigate(Routes.FOOD_BOLUS)
                    }, Modifier.padding(top = 10.dp))
                }
            }

            SectionTitle("Informação nutricional completa")
            GCard {
                Text(
                    buildString {
                        val gCustom = parseDec(gramsText)
                        if (gCustom != null && gCustom > 0) append("${"%.1f".format(gCustom)} g/ml · ${portionLabel.ifBlank { food.serving }}")
                        else append("${"%.1f".format(factor)} × ${portionLabel.ifBlank { food.serving }}")
                    },
                    color = g.ink, fontWeight = FontWeight.Bold, fontSize = 15.sp,
                    modifier = Modifier.padding(bottom = 10.dp),
                )
                NutriTableRow("Energia", "${s.kj.roundToInt()} kJ  ·  ${s.kcal.roundToInt()} kcal", g, highlight = false)
                HorizontalDivider(color = g.line, modifier = Modifier.padding(vertical = 4.dp))
                NutriTableRow("Carboidratos totais", "%.2f g".format(s.carbs), g, highlight = true)
                NutriTableRow("  Açúcares", if (s.sugars > 0) "%.2f g".format(s.sugars) else "não informado", g)
                NutriTableRow("Fibras alimentares", if (s.fiber > 0) "%.2f g".format(s.fiber) else "não informado", g)
                HorizontalDivider(color = g.line, modifier = Modifier.padding(vertical = 4.dp))
                NutriTableRow("Proteínas", "%.2f g".format(s.protein), g)
                NutriTableRow("Gorduras totais", "%.2f g".format(s.fat), g)
                NutriTableRow("  Saturadas", if (s.satFat > 0) "%.2f g".format(s.satFat) else "não informado", g)
                HorizontalDivider(color = g.line, modifier = Modifier.padding(vertical = 4.dp))
                NutriTableRow("Sódio", if (s.sodium > 0) "${s.sodium.roundToInt()} mg" else "não informado", g)
            }
            Text(
                "Valores proporcionais à quantidade. Carboidratos em destaque para o acompanhamento da diabetes. Não substitui orientação médica.",
                color = g.muted, fontSize = 11.sp,
                modifier = Modifier.padding(top = 10.dp, bottom = 28.dp),
            )
        }
    }
}

@Composable
private fun NutriCard(title: String, value: String, subtitle: String, modifier: Modifier, g: com.agon.app.ui.theme.GlucoColors) {
    Box(
        modifier
            .padding(4.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(g.card)
            .padding(14.dp),
    ) {
        Column {
            Text(title, color = g.muted, fontSize = 12.sp)
            Text(value, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            if (subtitle.isNotBlank()) Text(subtitle, color = g.violet, fontSize = 11.sp)
        }
    }
}

@Composable
private fun NutriTableRow(label: String, value: String, g: com.agon.app.ui.theme.GlucoColors, highlight: Boolean = false) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(
            label,
            color = if (highlight) g.violetDeep else g.ink,
            fontSize = 14.sp,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.Normal,
        )
        Text(
            value,
            color = if (highlight) g.violetDeep else g.ink,
            fontSize = 14.sp,
            fontWeight = if (highlight) FontWeight.Bold else FontWeight.Medium,
        )
    }
}

@Composable
fun FoodDiaryScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    val data by vm.data.collectAsStateWithLifecycle()
    var confirmId by remember { mutableStateOf<String?>(null) }
    var editMeal by remember { mutableStateOf<Meal?>(null) }
    var editCarbs by remember { mutableStateOf("") }
    var editDesc by remember { mutableStateOf("") }
    var carbGoal by remember { mutableStateOf(loadCarbGoal(context)) }
    var goalInput by remember { mutableStateOf(carbGoal?.toInt()?.toString() ?: "") }
    var showGoal by remember { mutableStateOf(false) }

    ScrollScreen {
        BackTitle("Diário Alimentar", { nav.popBackStack() })
        PrimaryButton("Adicionar alimento", g.green, { nav.navigate(Routes.FOOD_SEARCH) })

        // Meta de carb (opcional)
        GCard(Modifier.padding(top = 8.dp).clickable { showGoal = !showGoal }) {
            Text("Meta diária de carboidratos (opcional)", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(
                if (carbGoal != null) "Atual: ${carbGoal!!.toInt()} g — toque para alterar" else "Toque para definir uma meta pessoal",
                color = g.muted, fontSize = 12.sp,
            )
            if (showGoal) {
                GField("Meta em gramas", goalInput, { goalInput = it.filter { c -> c.isDigit() } }, "Ex.: 150", numeric = true)
                Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton("Salvar meta", g.violet, {
                        val v = goalInput.toDoubleOrNull()
                        carbGoal = if (v != null && v > 0) v else null
                        saveCarbGoal(context, carbGoal)
                        showGoal = false
                    }, Modifier.weight(1f))
                    OutlinedButton(onClick = {
                        carbGoal = null; saveCarbGoal(context, null); goalInput = ""; showGoal = false
                    }, modifier = Modifier.weight(1f)) {
                        Text("Limpar", color = g.muted)
                    }
                }
            }
        }

        // Repetir última refeição
        val lastMeal = data.meals.maxByOrNull { it.at }
        if (lastMeal != null) {
            TextButton(onClick = {
                vm.saveMeal(
                    Meal(
                        id = uid(),
                        type = lastMeal.type,
                        description = lastMeal.description + " (repetido)",
                        carbs = lastMeal.carbs,
                        at = System.currentTimeMillis(),
                        notes = lastMeal.notes,
                    )
                )
            }) {
                Text("↻ Repetir último alimento registrado", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        // Exportar
        if (data.meals.isNotEmpty()) {
            TextButton(onClick = {
                val sb = StringBuilder("Diário alimentar — Gluco Cris\n\n")
                data.meals.sortedByDescending { it.at }.groupBy { formatDate(it.at) }.forEach { (date, list) ->
                    sb.appendLine(date)
                    list.forEach { m ->
                        sb.appendLine("  ${MEAL_LABEL[m.type] ?: m.type}: ${m.description}" + (m.carbs?.let { " (${it} g carb)" } ?: ""))
                    }
                    sb.appendLine()
                }
                val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                    type = "text/plain"
                    putExtra(android.content.Intent.EXTRA_SUBJECT, "Diário alimentar")
                    putExtra(android.content.Intent.EXTRA_TEXT, sb.toString())
                }
                context.startActivity(android.content.Intent.createChooser(intent, "Exportar diário"))
            }) {
                Text("Compartilhar / exportar diário", color = g.green, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
        }

        val byDate = data.meals.groupBy { formatDate(it.at) }.toSortedMap(compareByDescending { it })
        byDate.forEach { (date, meals) ->
            SectionTitle(date)
            val totalCarbs = meals.mapNotNull { it.carbs }.sum()
            val goal = carbGoal
            val over = goal != null && totalCarbs > goal
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (over) g.orangeSoft else g.lilacSoft)
                    .padding(12.dp),
            ) {
                Column {
                    Text(
                        "Total de carboidratos: ${"%.1f".format(totalCarbs)} g",
                        color = if (over) g.orange else g.violetDeep,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp,
                    )
                    if (goal != null) {
                        Text(
                            if (over) "Acima da meta de ${goal.toInt()} g (só um aviso — não é orientação médica)"
                            else "Meta: ${goal.toInt()} g · restante ${"%.0f".format((goal - totalCarbs).coerceAtLeast(0.0))} g",
                            color = g.muted, fontSize = 12.sp,
                        )
                    }
                }
            }
            // Aviso por refeição com carb alto
            meals.groupBy { it.type }.forEach { (type, list) ->
                val mealCarbs = list.mapNotNull { it.carbs }.sum()
                Text(
                    MEAL_OPTIONS.find { it.first == type }?.second ?: (MEAL_LABEL[type] ?: type),
                    color = g.ink, fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier.padding(top = 10.dp),
                )
                if (mealCarbs >= 60) {
                    Text(
                        "Esta refeição tem ${"%.0f".format(mealCarbs)} g de carb — valor alto; converse com sua equipe se precisar.",
                        color = g.orange, fontSize = 12.sp, modifier = Modifier.padding(bottom = 4.dp),
                    )
                }
                list.forEach { m ->
                    GCard(Modifier.padding(top = 4.dp)) {
                        Text(m.description, color = g.ink, fontSize = 14.sp)
                        Text(
                            (m.carbs?.let { "${it} g carb. · " } ?: "") + formatTime(m.at),
                            color = g.muted, fontSize = 12.sp,
                        )
                        if (m.notes.contains("fonte=")) {
                            Text(m.notes.substringAfter("fonte="), color = g.muted, fontSize = 11.sp)
                        }
                        Row(Modifier.padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                            Text("Editar", color = g.violet, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                                editMeal = m
                                editCarbs = m.carbs?.toString() ?: ""
                                editDesc = m.description
                            })
                            Text("Excluir", color = g.red, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { confirmId = m.id })
                        }
                    }
                }
            }
        }
        if (data.meals.isEmpty()) Text("Diário vazio. Pesquise e salve alimentos.", color = g.muted)
    }
    confirmId?.let { id ->
        ConfirmDialog("Excluir registro", "Esta ação não pode ser desfeita.", "Excluir", {
            vm.deleteMeal(id); confirmId = null
        }) { confirmId = null }
    }
    editMeal?.let { m ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { editMeal = null }) {
            GCard {
                Text("Editar registro", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                GField("Descrição", editDesc, { editDesc = it }, "Alimento")
                GField("Carboidratos (g)", editCarbs, { editCarbs = it }, "Ex.: 40", numeric = true)
                PrimaryButton("Salvar", g.green, {
                    val c = editCarbs.replace(",", ".").toDoubleOrNull()
                    vm.saveMeal(m.copy(description = editDesc.trim().ifBlank { m.description }, carbs = c ?: m.carbs))
                    editMeal = null
                }, Modifier.padding(top = 8.dp))
                TextButton(onClick = { editMeal = null }) { Text("Cancelar", color = g.muted) }
            }
        }
    }
}

@Composable
fun FoodReportsScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val data by vm.data.collectAsStateWithLifecycle()
    ScrollScreen {
        BackTitle("Relatórios nutricionais", { nav.popBackStack() })
        Text("Carboidratos em destaque para o acompanhamento da diabetes.", color = g.muted, fontSize = 13.sp)
        val byDate = data.meals.groupBy { formatDate(it.at) }.toSortedMap(compareByDescending { it })
        val last7 = byDate.entries.take(7)
        if (last7.isNotEmpty()) {
            SectionTitle("Carboidratos — últimos dias")
            val maxC = last7.maxOfOrNull { it.value.mapNotNull { m -> m.carbs }.sum() }?.coerceAtLeast(1.0) ?: 1.0
            GCard {
                last7.reversed().forEach { (date, meals) ->
                    val carbs = meals.mapNotNull { it.carbs }.sum()
                    val frac = (carbs / maxC).toFloat().coerceIn(0.02f, 1f)
                    Text(date, color = g.muted, fontSize = 11.sp)
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 8.dp)) {
                        Box(
                            Modifier
                                .weight(frac)
                                .height(14.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(g.violet),
                        )
                        if (frac < 1f) Spacer(Modifier.weight(1f - frac))
                        Text("${"%.0f".format(carbs)} g", color = g.ink, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        }
        byDate.forEach { (date, meals) ->
            val carbs = meals.mapNotNull { it.carbs }.sum()
            val kcalApprox = meals.sumOf { m ->
                m.notes.substringAfter("kcal=", "0").substringBefore(";").toDoubleOrNull() ?: 0.0
            }
            GCard(Modifier.padding(top = 8.dp)) {
                Text(date, color = g.ink, fontWeight = FontWeight.ExtraBold)
                Text("Carboidratos: ${"%.1f".format(carbs)} g", color = g.violetDeep, fontWeight = FontWeight.Bold)
                if (kcalApprox > 0) Text("Calorias (aprox.): ${kcalApprox.roundToInt()} kcal", color = g.ink)
                Text("${meals.size} registro(s)", color = g.muted, fontSize = 12.sp)
            }
        }
        if (byDate.isEmpty()) Text("Sem dados.", color = g.muted)
    }
}

@Composable

fun FoodBarcodeScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val ctx = LocalContext.current
    var code by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var useCamera by remember { mutableStateOf(true) }
    var scanKey by remember { mutableStateOf(0) }
    var showManual by remember { mutableStateOf(false) }
    var manualName by remember { mutableStateOf("") }
    var manualServing by remember { mutableStateOf("1 porção") }
    var manualCarbs by remember { mutableStateOf("") }
    var manualProtein by remember { mutableStateOf("") }
    var manualFat by remember { mutableStateOf("") }
    var manualKcal by remember { mutableStateOf("") }
    var savedMsg by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    fun parseDec(s: String): Double? = s.replace(",", ".").trim().toDoubleOrNull()

    fun consult(raw: String) {
        val digits = raw.filter { it.isDigit() }
        if (digits.length < 8) {
            error = "Código inválido."
            return
        }
        code = digits
        loading = true
        error = null
        savedMsg = null
        showManual = false
        scope.launch {
            val gem = if (com.agon.app.data.FoodVisionAi.hasGeminiKey()) {
                async(Dispatchers.IO) {
                    try { com.agon.app.data.FoodVisionAi.lookupBarcodeWithGemini(digits) } catch (_: Exception) { null }
                }
            } else null
            var item = lookupBarcode(digits, ctx)
            if (item == null) {
                item = gem?.await()
            } else {
                gem?.cancel()
            }
            loading = false
            if (item == null) {
                error = "Produto não encontrado. Você pode cadastrar manualmente abaixo."
                showManual = true
                useCamera = false
                if (manualName.isBlank()) manualName = "Produto $digits"
            } else {
                vm.setTempFood(item, "lanche")
                nav.navigate(Routes.FOOD_DETAIL)
            }
        }
    }

    ScrollScreen {
        BackTitle("Código de barras", { nav.popBackStack() })
        Text(
            "Aponte a câmera ou digite o código. Busca no Open Food Facts; se não achar, tenta Gemini (se configurado). Você também pode cadastrar o produto no catálogo.",
            color = g.muted,
            fontSize = 13.sp,
        )

        if (useCamera && !loading && !showManual) {
            key(scanKey) {
                BarcodeCameraScanner(
                    onBarcode = { consult(it) },
                    modifier = Modifier.padding(top = 12.dp),
                )
            }
            TextButton(onClick = { useCamera = false }) {
                Text("Prefiro digitar o código", color = g.violet, fontSize = 13.sp)
            }
        } else if (!loading && !showManual) {
            GField(
                "Código de barras",
                code,
                { code = it.filter { c -> c.isDigit() } },
                "Ex.: 7891000100103",
                numeric = true,
            )
            PrimaryButton("Consultar", g.green, { consult(code) }, Modifier.padding(top = 8.dp))
            TextButton(onClick = { useCamera = true; scanKey++; error = null }) {
                Text("Usar câmera", color = g.violet, fontSize = 13.sp)
            }
            TextButton(onClick = { showManual = true; error = null }) {
                Text("Cadastrar produto manualmente", color = g.violet, fontSize = 13.sp)
            }
        }

        if (loading) {
            androidx.compose.foundation.layout.Box(
                Modifier.fillMaxWidth().padding(24.dp),
                contentAlignment = Alignment.Center,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = g.violet)
                    Text("Buscando produto…", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }

        error?.let { Text(it, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) }
        savedMsg?.let { Text(it, color = g.green, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) }

        if (showManual) {
            Spacer(Modifier.height(8.dp))
            SectionTitle("Cadastrar no catálogo")
            GCard {
                if (code.isNotBlank()) {
                    Text("Código: $code", color = g.muted, fontSize = 12.sp)
                }
                GField("Nome do alimento", manualName, { manualName = it }, "Obrigatório")
                GField("Porção", manualServing, { manualServing = it }, "Ex.: 30 g / 1 unidade")
                GField("Carboidratos (g)", manualCarbs, { manualCarbs = it }, "Obrigatório", numeric = true)
                GField("Proteínas (g)", manualProtein, { manualProtein = it }, "Opcional", numeric = true)
                GField("Gorduras (g)", manualFat, { manualFat = it }, "Opcional", numeric = true)
                GField("Calorias (kcal)", manualKcal, { manualKcal = it }, "Opcional", numeric = true)

                PrimaryButton("➕ Salvar no catálogo Gluco Cris", g.green, {
                    val c = parseDec(manualCarbs)
                    if (manualName.isBlank()) {
                        error = "Informe o nome do alimento."
                        return@PrimaryButton
                    }
                    if (c == null) {
                        error = "Carboidratos são obrigatórios."
                        return@PrimaryButton
                    }
                    val item = CustomFood(
                        id = uid(),
                        name = manualName.trim(),
                        serving = manualServing.trim().ifBlank { "1 porção" },
                        carbs = c,
                        protein = parseDec(manualProtein) ?: 0.0,
                        fat = parseDec(manualFat) ?: 0.0,
                        kcal = parseDec(manualKcal) ?: 0.0,
                    )
                    val list = loadCustomFoods(ctx)
                    saveCustomFoods(ctx, listOf(item) + list)
                    savedMsg = "✅ Salvo no catálogo: ${item.name}"
                    error = null
                    // Também abre o detalhe para usar na refeição / bolus
                    val foodItem = FoodItem(
                        id = item.id,
                        name = item.name,
                        brand = "",
                        serving = item.serving,
                        servingGrams = 100.0,
                        kcal = item.kcal,
                        carbs = item.carbs,
                        protein = item.protein,
                        fat = item.fat,
                        source = "Meu alimento",
                        sourceKey = "custom",
                        isGeneric = true,
                        reliability = "alta",
                    )
                    vm.setTempFood(foodItem, "lanche")
                }, Modifier.padding(top = 8.dp))

                PrimaryButton("💉 Calculadora de Bolus", g.violet, {
                    val c = parseDec(manualCarbs) ?: 0.0
                    ctx.getSharedPreferences("gluco_food_tools", android.content.Context.MODE_PRIVATE)
                        .edit()
                        .putFloat("last_meal_carbs", c.toFloat())
                        .apply()
                    nav.navigate(Routes.FOOD_BOLUS)
                }, Modifier.padding(top = 8.dp))

                if (savedMsg != null) {
                    PrimaryButton("Ver detalhe / adicionar à refeição", g.violet, {
                        nav.navigate(Routes.FOOD_DETAIL)
                    }, Modifier.padding(top = 8.dp))
                }

                TextButton(onClick = {
                    showManual = false
                    useCamera = true
                    scanKey++
                    error = null
                }) {
                    Text("Voltar à câmera", color = g.violet, fontSize = 13.sp)
                }
            }
        }
    }
}

