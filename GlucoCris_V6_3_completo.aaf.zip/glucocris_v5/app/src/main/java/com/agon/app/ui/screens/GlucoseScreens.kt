package com.agon.app.ui.screens

import com.agon.app.ui.components.tourTarget
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.formatDate
import com.agon.app.data.formatTime
import com.agon.app.data.parseDecimal
import com.agon.app.data.parseLocalDateTime
import com.agon.app.data.rangeStatus
import com.agon.app.data.statusLabel
import com.agon.app.data.toMgDl
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.ConfirmDialog
import com.agon.app.ui.components.EmptyState
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GField
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.theme.glucoColors
import kotlin.math.roundToInt

@Composable
fun GlucoseListScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val name = data.settings.displayName
    var filter by remember { mutableStateOf("todas") }
    val cutoff7 = System.currentTimeMillis() - 7L * 86_400_000L
    val cutoff30 = System.currentTimeMillis() - 30L * 86_400_000L
    val list = data.glucose.sortedByDescending { it.at }.filter { e ->
        val mg = toMgDl(e.value, e.unit)
        when (filter) {
            "7" -> e.at >= cutoff7
            "30" -> e.at >= cutoff30
            "fora" -> rangeStatus(mg, data.settings.targetLow, data.settings.targetHigh) != "ok"
            else -> true
        }
    }
    androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth()) {
        ScrollScreen {
            Text("Glicose", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
            Text("Registre a glicose de $name pelo botão abaixo.", color = g.muted, fontSize = 13.sp)
            ChipRow(
                listOf("todas" to "Todas", "7" to "7 dias", "30" to "30 dias", "fora" to "Fora da meta"),
                filter,
            ) { filter = it }
            if (list.isEmpty()) {
                EmptyState("Nenhuma medição", "Ajuste o período ou o tipo de registro.")
            } else {
                list.forEach { e ->
                    val mg = toMgDl(e.value, e.unit)
                    val st = rangeStatus(mg, data.settings.targetLow, data.settings.targetHigh)
                    val c = when (st) { "ok" -> g.green; "low" -> g.orange; else -> g.red }
                    GCard(Modifier.padding(top = 8.dp).clickable { nav.navigate(Routes.glucoseForm(e.id)) }) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("${mg.roundToInt()} mg/dL", color = c, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                            Text("Editar", color = g.violet, fontWeight = FontWeight.Bold)
                        }
                        Text(statusLabel(st), color = c, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("${GLUCOSE_CONTEXT_LABEL[e.context] ?: e.context} · ${formatDate(e.at)} · ${formatTime(e.at)}", color = g.muted, fontSize = 12.sp)
                        if (e.notes.isNotBlank()) Text(e.notes, color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }
            }
        }
        FloatingActionButton(
            onClick = { nav.navigate(Routes.glucoseForm(null)) },
            containerColor = g.violet,
            modifier = Modifier.align(androidx.compose.ui.Alignment.BottomEnd).padding(16.dp).tourTarget("glucose_add"),
        ) { Icon(Icons.Filled.Add, "Nova medição", tint = androidx.compose.ui.graphics.Color.White) }
    }
}

@Composable
fun GlucoseFormScreen(vm: GlucoViewModel, nav: NavHostController, id: String?) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val existing = data.glucose.firstOrNull { it.id == id }
    var value by remember(existing?.id) { mutableStateOf(existing?.let { if (it.value == kotlin.math.floor(it.value)) it.value.toLong().toString() else it.value.toString() } ?: "") }
    var unit by remember(existing?.id) { mutableStateOf(existing?.unit ?: data.settings.preferredUnit) }
    var date by remember(existing?.id) { mutableStateOf(existing?.let { formatDate(it.at) } ?: formatDate(System.currentTimeMillis())) }
    var time by remember(existing?.id) { mutableStateOf(existing?.let { formatTime(it.at) } ?: formatTime(System.currentTimeMillis())) }
    var context by remember(existing?.id) { mutableStateOf(existing?.context ?: "jejum") }
    var notes by remember(existing?.id) { mutableStateOf(existing?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }

    ScrollScreen {
        Text(if (existing == null) "Nova glicose" else "Editar glicose", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
        Text("Registro para ${data.settings.displayName}. Os campos são validados antes de salvar.", color = g.muted, fontSize = 13.sp)
        GField("Valor", value, { value = it }, if (unit == "mmol/L") "Ex.: 6,5" else "Ex.: 118", numeric = true)
        Text("Unidade", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        ChipRow(listOf("mg/dL" to "mg/dL", "mmol/L" to "mmol/L"), unit) { unit = it }
        GField("Data", date, { date = it }, "dd/mm/aaaa")
        GField("Horário", time, { time = it }, "hh:mm")
        Text("Contexto da medição", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        GLUCOSE_CONTEXT_LABEL.entries.chunked(2).forEach { row ->
            ChipRow(row.map { it.key to it.value }, context) { context = it }
        }
        GField("Observações", notes, { notes = it }, "Opcional")
        error?.let { Text(it, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
        PrimaryButton(if (existing == null) "Salvar medição" else "Salvar alterações", g.violet, {
            val v = parseDecimal(value)
            val at = parseLocalDateTime(date, time)
            error = when {
                v == null -> "Informe um valor numérico de glicose."
                unit == "mg/dL" && v !in 20.0..600.0 -> "Em mg/dL, use um valor entre 20 e 600."
                unit == "mmol/L" && v !in 1.0..33.0 -> "Em mmol/L, use um valor entre 1 e 33."
                at == null -> "Data ou horário inválidos. Use dd/mm/aaaa e hh:mm."
                at > System.currentTimeMillis() + 60_000 -> "A medição não pode estar no futuro."
                else -> null
            }
            if (error == null && v != null && at != null) {
                vm.saveGlucose(existing?.id, v, unit, at, context, notes.trim())
                nav.popBackStack()
            }
        }, Modifier.padding(top = 12.dp))
        if (existing != null) {
            PrimaryButton("Excluir registro", g.red, { confirm = true }, Modifier.padding(top = 8.dp))
        }
    }
    if (confirm && existing != null) {
        ConfirmDialog("Excluir medição", "Esta ação não pode ser desfeita.", "Excluir", {
            vm.deleteGlucose(existing.id)
            confirm = false
            nav.popBackStack()
        }) { confirm = false }
    }
}

@Composable
fun InsulinListScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    var filter by remember { mutableStateOf("todas") }
    val list = data.insulin.sortedByDescending { it.at }.filter { e ->
        when (filter) {
            "aplicacao" -> e.kind == "aplicacao"
            "lembrete" -> e.kind == "lembrete"
            else -> true
        }
    }
    androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth()) {
        ScrollScreen {
            Text("Insulina", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
            Text("Diferencie aplicação realizada e lembrete anotado.", color = g.muted, fontSize = 13.sp)
            ChipRow(listOf("todas" to "Todas", "aplicacao" to "Aplicações", "lembrete" to "Lembretes registrados"), filter) { filter = it }
            if (list.isEmpty()) EmptyState("Sem registros de insulina", "Use o botão para anotar uma aplicação ou um lembrete.")
            list.forEach { e ->
                GCard(Modifier.padding(top = 8.dp).clickable { nav.navigate(Routes.insulinForm(e.id)) }) {
                    Text(e.name, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Text("${com.agon.app.data.fmtNum(e.dose)} ${e.unit} · ${if (e.kind == "aplicacao") "Aplicação realizada" else "Lembrete anotado"}", color = g.blue, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    Text("${formatDate(e.at)} · ${formatTime(e.at)}", color = g.muted, fontSize = 12.sp)
                    if (e.notes.isNotBlank()) Text(e.notes, color = g.ink, fontSize = 13.sp)
                    Text("Editar", color = g.violet, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }
        FloatingActionButton(
            onClick = { nav.navigate(Routes.insulinForm(null)) },
            containerColor = g.blue,
            modifier = Modifier.align(androidx.compose.ui.Alignment.BottomEnd).padding(16.dp).tourTarget("insulin_add"),
        ) { Icon(Icons.Filled.Add, "Nova insulina", tint = androidx.compose.ui.graphics.Color.White) }
    }
}

@Composable
fun InsulinFormScreen(vm: GlucoViewModel, nav: NavHostController, id: String?) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val existing = data.insulin.firstOrNull { it.id == id }
    var name by remember(existing?.id) { mutableStateOf(existing?.name ?: "") }
    var dose by remember(existing?.id) { mutableStateOf(existing?.let { com.agon.app.data.fmtNum(it.dose) } ?: "") }
    var kind by remember(existing?.id) { mutableStateOf(existing?.kind ?: "aplicacao") }
    var date by remember(existing?.id) { mutableStateOf(existing?.let { formatDate(it.at) } ?: formatDate(System.currentTimeMillis())) }
    var time by remember(existing?.id) { mutableStateOf(existing?.let { formatTime(it.at) } ?: formatTime(System.currentTimeMillis())) }
    var notes by remember(existing?.id) { mutableStateOf(existing?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    var confirm by remember { mutableStateOf(false) }

    ScrollScreen {
        Text(if (existing == null) "Nova insulina" else "Editar insulina", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
        Text("Aplicação é o que já foi feito. Lembrete anotado guarda um aviso no histórico, sem confundir com a dose aplicada.", color = g.muted, fontSize = 13.sp)
        GField("Nome", name, { name = it }, "Ex.: Insulina asparte")
        GField("Quantidade (UI)", dose, { dose = it }, "Ex.: 6", numeric = true)
        Text("Tipo de registro", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
        ChipRow(listOf("aplicacao" to "Aplicação realizada", "lembrete" to "Lembrete anotado"), kind) { kind = it }
        GField("Data", date, { date = it }, "dd/mm/aaaa")
        GField("Horário", time, { time = it }, "hh:mm")
        GField("Observações", notes, { notes = it }, "Local, reação ou orientação")
        error?.let { Text(it, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
        PrimaryButton(if (existing == null) "Salvar insulina" else "Salvar alterações", g.blue, {
            val d = parseDecimal(dose)
            val at = parseLocalDateTime(date, time)
            error = when {
                name.isBlank() -> "Informe o nome da insulina."
                d == null || d !in 0.1..200.0 -> "Informe uma quantidade entre 0,1 e 200 UI."
                at == null -> "Data ou horário inválidos. Use dd/mm/aaaa e hh:mm."
                else -> null
            }
            if (error == null && d != null && at != null) {
                vm.saveInsulin(existing?.id, kind, name.trim(), d, at, notes.trim())
                nav.popBackStack()
            }
        }, Modifier.padding(top = 12.dp))
        if (existing != null) {
            Text(
                "Remover esta insulina do histórico?",
                color = g.muted,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 10.dp),
            )
            PrimaryButton("Excluir registro", g.red, { confirm = true }, Modifier.padding(top = 6.dp))
        }
    }
    if (confirm && existing != null) {
        ConfirmDialog("Excluir registro", "Remover esta insulina do histórico? Esta ação não pode ser desfeita.", "Excluir", {
            vm.deleteInsulin(existing.id)
            confirm = false
            nav.popBackStack()
        }) { confirm = false }
    }
}

