package com.agon.app.ui.screens

import android.app.Activity
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.border
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.cloud.CloudState
import com.agon.app.cloud.CloudStatus
import com.agon.app.data.GlucoViewModel
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.tourTarget
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.agon.app.ui.theme.glucoColors
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException

/** ID do cliente web gerado pelo google-services.json (existe só depois de ativar o Google no Firebase Auth). */
private fun webClientId(context: Context): String? {
    val id = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
    return if (id != 0) context.getString(id) else null
}

/** Cliente de login Google (e-mail, nome e o token que o Firebase Auth troca pela sessão do backup). */
private fun googleClient(context: Context): GoogleSignInClient {
    val builder = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        .requestEmail()
        .requestProfile()
    webClientId(context)?.let { builder.requestIdToken(it) }
    return GoogleSignIn.getClient(context, builder.build())
}

private fun googleErrorText(e: ApiException): String = when (e.statusCode) {
    12501, 12502 -> "Login cancelado."
    7 -> "Sem conexão com a internet. Conecte-se e tente de novo."
    10 -> "Login Google ainda não configurado para este app (cliente OAuth do Google Cloud)."
    else -> "Não foi possível entrar com o Google (código ${e.statusCode})."
}

/**
 * Inicia o login Google. [forceChooser] = true desconecta antes para sempre
 * mostrar a lista de contas (usado em "Alterar conta").
 */
@Composable
private fun rememberGoogleSignIn(
    onSuccess: (email: String, name: String, idToken: String?) -> Unit,
    onError: (String) -> Unit,
): (forceChooser: Boolean) -> Unit {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != Activity.RESULT_OK && result.data == null) {
            onError("Login cancelado.")
            return@rememberLauncherForActivityResult
        }
        try {
            val account = GoogleSignIn.getSignedInAccountFromIntent(result.data).getResult(ApiException::class.java)
            val email = account.email.orEmpty()
            if (email.isBlank()) {
                onError("O Google não retornou um e-mail. Tente outra conta.")
            } else {
                onSuccess(email, account.displayName.orEmpty(), account.idToken)
            }
        } catch (e: ApiException) {
            onError(googleErrorText(e))
        } catch (e: Exception) {
            onError("Não foi possível entrar com o Google.")
        }
    }
    return { forceChooser ->
        val client = googleClient(context)
        if (forceChooser) {
            client.signOut().addOnCompleteListener { launcher.launch(client.signInIntent) }
        } else {
            launcher.launch(client.signInIntent)
        }
    }
}

private enum class LoginMode { HOME, SIGNIN, SIGNUP }

/** Campo de texto da tela de login (fundo claro sobre o degradê lilás). */
@Composable
private fun AuthField(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    keyboard: KeyboardType = KeyboardType.Text,
    password: Boolean = false,
) {
    var shown by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
        Text(label, color = Color.White.copy(alpha = 0.92f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 6.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color.White.copy(alpha = 0.96f))
                .padding(horizontal = 14.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            BasicTextField(
                value = value,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color(0xFF1F1F1F), fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
                keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboard),
                visualTransformation = if (password && !shown) PasswordVisualTransformation() else VisualTransformation.None,
                modifier = Modifier.weight(1f),
            )
            if (password) {
                Text(
                    if (shown) "Ocultar" else "Mostrar",
                    color = Color(0xFF6D28D9),
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(start = 8.dp).clickable { shown = !shown },
                )
            }
        }
    }
}

@Composable
private fun LoginPill(text: String, filled: Boolean, onClick: () -> Unit) {
    val g = glucoColors()
    Box(
        Modifier
            .fillMaxWidth()
            .padding(top = 12.dp)
            .height(52.dp)
            .clip(RoundedCornerShape(26.dp))
            .then(if (filled) Modifier.background(Color.White) else Modifier.border(1.5.dp, Color.White.copy(alpha = 0.85f), RoundedCornerShape(26.dp)))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = if (filled) g.violetDeep else Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
    }
}

@Composable
private fun LoginLink(text: String, onClick: () -> Unit) {
    Text(
        text,
        color = Color.White,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        textAlign = TextAlign.Center,
        modifier = Modifier.padding(top = 14.dp).clickable(onClick = onClick).padding(8.dp),
    )
}

/** Primeira abertura: Google, e-mail e senha, ou criar conta. A verificação de e-mail vem antes de liberar o app. */
@Composable
fun LoginScreen(vm: GlucoViewModel) {
    val g = glucoColors()
    val pending by vm.pendingVerify.collectAsStateWithLifecycle()
    val busy by vm.authBusy.collectAsStateWithLifecycle()
    val msg by vm.authMsg.collectAsStateWithLifecycle()
    var error by remember { mutableStateOf<String?>(null) }
    var mode by remember { mutableStateOf(LoginMode.HOME) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var pass2 by remember { mutableStateOf("") }
    val signIn = rememberGoogleSignIn(
        onSuccess = { mail, gname, token ->
            vm.linkGoogle(mail, gname)
            vm.startBackup(token)
        },
        onError = { error = it },
    )
    fun go(m: LoginMode) { mode = m; error = null; vm.clearAuthMsg() }
    Column(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(g.heroStart, g.bg)))
            .verticalScroll(rememberScrollState())
            .imePadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Gluco Cris ❤️", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp)
        if (pending != null) {
            Text(
                "Verifique seu e-mail",
                color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp,
                modifier = Modifier.padding(top = 18.dp),
            )
            Text(
                "Enviamos um link para $pending. Toque nele e volte aqui. O acesso completo e o backup só são liberados depois da verificação. Confira também o spam.",
                color = Color.White.copy(alpha = 0.92f), fontSize = 14.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 10.dp, bottom = 8.dp),
            )
            LoginPill(if (busy) "Aguarde..." else "Já verifiquei", true) { vm.checkEmailVerified() }
            LoginPill("Reenviar e-mail de verificação", false) { vm.resendVerification() }
            LoginLink("Sair / usar outra conta") { vm.cancelVerification() }
        } else {
            Text(
                when (mode) {
                    LoginMode.HOME -> "Bem-vinda! Entre ou crie sua conta para vinculá-la ao app."
                    LoginMode.SIGNIN -> "Entrar com e-mail e senha"
                    LoginMode.SIGNUP -> "Criar minha conta"
                },
                color = Color.White.copy(alpha = 0.92f), fontSize = 15.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 10.dp, bottom = 12.dp),
            )
            when (mode) {
                LoginMode.HOME -> {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .height(54.dp)
                            .clip(RoundedCornerShape(27.dp))
                            .background(Color.White)
                            .clickable { error = null; vm.clearAuthMsg(); signIn(true) }
                            .padding(horizontal = 20.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center,
                    ) {
                        Box(Modifier.size(28.dp).clip(CircleShape).background(Color(0xFFF1F3F4)), contentAlignment = Alignment.Center) {
                            Text("G", color = Color(0xFF4285F4), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        }
                        Text(
                            "Continuar com Google",
                            color = Color(0xFF1F1F1F),
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            modifier = Modifier.padding(start = 12.dp),
                        )
                    }
                    LoginPill("Entrar com e-mail e senha", false) { go(LoginMode.SIGNIN) }
                    LoginLink("Criar minha conta") { go(LoginMode.SIGNUP) }
                }
                LoginMode.SIGNIN -> {
                    AuthField("E-mail", email, { email = it }, KeyboardType.Email)
                    AuthField("Senha", pass, { pass = it }, password = true)
                    LoginPill(if (busy) "Aguarde..." else "Entrar", true) { vm.signInWithEmail(email, pass) }
                    LoginLink("Esqueci minha senha") { vm.resetPassword(email) }
                    LoginLink("Voltar") { go(LoginMode.HOME) }
                }
                LoginMode.SIGNUP -> {
                    AuthField("Nome", name, { name = it })
                    AuthField("E-mail", email, { email = it }, KeyboardType.Email)
                    AuthField("Senha (mínimo 8 caracteres)", pass, { pass = it }, password = true)
                    AuthField("Confirmar senha", pass2, { pass2 = it }, password = true)
                    LoginPill(if (busy) "Aguarde..." else "Criar minha conta", true) { vm.signUpWithEmail(name, email, pass, pass2) }
                    LoginLink("Já tenho conta") { go(LoginMode.SIGNIN) }
                }
            }
        }
        (error ?: msg?.takeIf { !it.ok }?.text)?.let {
            Text(it, color = Color(0xFFFECACA), fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 16.dp))
        }
        msg?.takeIf { it.ok }?.let {
            Text(it.text, color = Color(0xFFBBF7D0), fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 16.dp))
        }
        Text(
            "Seus registros continuam salvos neste aparelho.",
            color = Color.White.copy(alpha = 0.8f),
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 24.dp),
        )
    }
}

/** Card do Perfil: conta Google vinculada, estado do backup e ações (trocar conta, sair). */
@Composable
fun GoogleAccountCard(vm: GlucoViewModel, email: String, name: String) {
    val g = glucoColors()
    val practice by vm.practice.collectAsStateWithLifecycle()
    val cloud by vm.cloud.collectAsStateWithLifecycle()
    val providers by vm.providers.collectAsStateWithLifecycle()
    val authMsg by vm.authMsg.collectAsStateWithLifecycle()
    val authBusy by vm.authBusy.collectAsStateWithLifecycle()
    val notice by vm.accountNotice.collectAsStateWithLifecycle()
    var showPw by remember { mutableStateOf(false) }
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    val signIn = rememberGoogleSignIn(
        onSuccess = { newEmail, newName, token ->
            vm.clearAccountNotice()
            vm.linkGoogle(newEmail, newName)
            vm.startBackup(token)
            message = "Entrando com $newEmail..." to true
        },
        onError = { message = it to false },
    )
    val linkGoogleSignIn = rememberGoogleSignIn(
        onSuccess = { mail, _, token -> vm.linkGoogleToAccount(mail, token) },
        onError = { message = it to false },
    )
    val (statusText, statusColor) = cloudStatusLine(cloud, g.green, g.red, g.muted)
    GCard(Modifier.tourTarget("profile_account")) {
        // Identidade da conta: avatar, nome e e-mail (cada informação aparece uma vez só)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(46.dp).clip(CircleShape).background(g.violet),
                contentAlignment = Alignment.Center,
            ) {
                Text(
                    (name.ifBlank { email }).trim().firstOrNull()?.uppercase() ?: "?",
                    color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp,
                )
            }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                if (name.isNotBlank()) {
                    Text(
                        name, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp,
                        maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                    )
                }
                Text(
                    email, color = g.muted, fontSize = 13.sp,
                    maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                )
            }
        }
        // Estado do backup em uma linha
        Row(Modifier.fillMaxWidth().padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(8.dp).clip(CircleShape).background(statusColor))
            Text(statusText, color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp))
        }
        notice?.let {
            Text(
                it, color = g.green, fontSize = 12.sp,
                modifier = Modifier.padding(top = 8.dp).clickable { vm.clearAccountNotice() },
            )
        }
        message?.let { (text, ok) ->
            Text(text, color = if (ok) g.green else g.red, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }
        // Ações principais
        Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            AccountAction("Trocar conta", g.violet, Modifier.weight(1f)) {
                if (practice) message = "Simulação: a troca de conta não é executada." to true
                else { message = null; signIn(true) }
            }
            AccountAction("Sair", g.red, Modifier.weight(1f)) {
                if (practice) message = "Simulação: o Sair não é executado." to true
                else vm.logout()
            }
        }
        // Backup: ações secundárias discretas
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
            when (cloud.state) {
                CloudState.SIGNED_OUT -> TextAction("Ativar backup", g.violet) {
                    if (practice) message = "Simulação: o backup não é executado." to true else signIn(true)
                }
                CloudState.SYNCING -> {}
                else -> {
                    TextAction("Sincronizar agora", g.violet) { vm.syncNow() }
                    TextAction("Restaurar da nuvem", g.muted) { vm.syncNow(restore = true) }
                }
            }
        }
        // Acesso: só aparece o que falta fazer
        if (providers.isNotEmpty() && ("password" !in providers || "google.com" !in providers)) {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                if ("password" !in providers) {
                    TextAction(if (showPw) "Cancelar" else "Entrar também com senha", g.violet) {
                        if (practice) message = "Simulação: não é executado." to true else { showPw = !showPw; vm.clearAuthMsg() }
                    }
                }
                if ("google.com" !in providers) {
                    TextAction("Vincular Google", g.violet) {
                        if (practice) message = "Simulação: não é executado." to true else { vm.clearAuthMsg(); linkGoogleSignIn(false) }
                    }
                }
            }
        }
        if (showPw && "password" !in providers) {
            Text("Crie uma senha para também entrar com $email.", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
            CardPasswordField("Senha (mínimo 8 caracteres)", pw) { pw = it }
            CardPasswordField("Confirmar senha", pw2) { pw2 = it }
            Row(Modifier.padding(top = 8.dp)) {
                CloudButton(if (authBusy) "Aguarde..." else "Salvar senha", g.green) { vm.addPasswordToAccount(pw, pw2) }
            }
        }
        authMsg?.let {
            Text(it.text, color = if (it.ok) g.green else g.red, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }
    }
}

private fun cloudStatusLine(s: CloudStatus, ok: Color, bad: Color, neutral: Color): Pair<String, Color> {
    val last = if (s.lastSyncAt > 0) " · " + java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale("pt", "BR")).format(java.util.Date(s.lastSyncAt)) else ""
    return when (s.state) {
        CloudState.OK -> "Backup em dia$last" to ok
        CloudState.IDLE -> (if (s.message.isBlank() || s.message == "Backup adiado.") "Backup ativo$last" else s.message) to ok
        CloudState.SYNCING -> s.message.ifBlank { "Sincronizando..." } to neutral
        CloudState.SIGNED_OUT -> "Backup desativado" to neutral
        CloudState.ERROR -> s.message to bad
        else -> s.message to neutral
    }
}

@Composable
private fun AccountAction(text: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Text(
        text,
        color = color,
        fontWeight = FontWeight.Bold,
        fontSize = 14.sp,
        textAlign = TextAlign.Center,
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .border(1.dp, color.copy(alpha = 0.45f), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
    )
}

@Composable
private fun TextAction(text: String, color: Color, onClick: () -> Unit) {
    Text(
        text,
        color = color,
        fontWeight = FontWeight.SemiBold,
        fontSize = 13.sp,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(vertical = 4.dp),
    )
}

/** Campo de senha do Perfil: a senha nunca aparece em texto aberto. */
@Composable
private fun CardPasswordField(label: String, value: String, onChange: (String) -> Unit) {
    val g = glucoColors()
    Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Text(label, color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = g.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 6.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(g.inputBg)
                .padding(horizontal = 14.dp, vertical = 14.dp),
        )
    }
}

@Composable
private fun CloudButton(text: String, color: Color, onClick: () -> Unit) {
    Text(
        text,
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(color)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
    )
}
