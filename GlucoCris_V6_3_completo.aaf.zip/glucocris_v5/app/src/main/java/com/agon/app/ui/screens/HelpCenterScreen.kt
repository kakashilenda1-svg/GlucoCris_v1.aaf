package com.agon.app.ui.screens

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.ui.components.BackTitle
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.theme.glucoColors

@Composable
fun HelpCenterScreen(nav: NavHostController, vm: com.agon.app.data.GlucoViewModel) {
    val g = glucoColors()
    val topics = listOf(
        "Como usar esta ajuda" to "Tudo que foi acrescentado ou mudado no app é descrito aqui. Abra pelo ? no Início. Nada aqui altera dose de insulina nem substitui sua equipe de saúde.",
        "Início" to "Resumo do dia, humor, atalhos e o card azul Cris Hidrata embaixo. Puxe o card de água para cima para expandir.",
        "Glicose" to "Liste e registre medições com contexto (jejum, pós-refeição etc.).",
        "Insulina" to "Registre aplicações conforme a orientação da sua equipe.",
        "Lembretes" to "Alertas de medição, medicação e rotina.",
        "Histórico" to "Linha do tempo de registros.",
        "Alimentação · Pesquisa" to "Busca local (TACO) + online (Open Food Facts / USDA em Wi‑Fi). Digite e veja sugestões. Favoritos e usados recentemente no topo. Selo online/offline nos resultados. Sem internet ou em dados móveis: local e cache.",
        "Prato" to "Marque itens na busca ou use Adicionar ao prato. Ajuste quantidade e gramas. Gráficos e total. Alerta se cruzar com alergia do perfil. Envie carb ao bolus.",
        "Diário alimentar" to "Refeições do dia, editar e exportar.",
        "Bolus" to "Calculadora com seus fatores (razão de carb, sensibilidade, meta, IOB). Histórico de contas no aparelho. Apoio de conta, não prescrição.",
        "Código de barras" to "Câmera ou digitação. Prioridade Open Food Facts; se não achar e houver chave Gemini, tenta a IA.",
        "Scanner de prato" to "Foto da refeição. Com Gemini: IA identifica. Sem Gemini ou se falhar: ML Kit + catálogo OFF/local. Revise, troque ou remova itens antes de salvar.",
        "Receitas" to "Aba Receitas: grade com foto, tempo, macros. Filtros (café, almoço…). Favoritos. Porções predefinidas ou quantidade digitada (recalcula tabela). Foto opcional da galeria.",
        "Planos alimentares" to "Aba Planos: planos de nutricionistas, filtros, detalhe com macros, importar dia ou só café/almoço/jantar, lista de compras.",
        "Marmitas Cris DM" to "Aba Marmitas: opções para o dia a dia com diabetes. WhatsApp da Maria Cristina.",
        "Cris Hidrata" to "Contador de água no Início (card compacto). Anel de progresso, copos de vários tamanhos e favoritos (estrela) no começo. Relógio inteligente: mostra a hora, sugere quanto beber no próximo horário e deixa você editar, remover ou criar horários (ou gerar a cada 1–4 h) com lembretes que ficam em silêncio quando a meta fecha. Alerta de glicose alta: interruptor que avisa para beber água quando a glicose passa da sua meta máxima (aviso ao registrar e card dentro da tela). Desfazer último copo em 5 s. Meta manual ou sugerida pelo peso (~35 ml/kg no Perfil). Modo calor/exercício (+400 ml só no dia). Lembrete suave a cada 1–4 h se a meta não fechou. Insights (ex.: pouco de manhã). Gotinha: triste / normal / festeja a meta; toque = ela dança, sorri e dá risada (som desligável). Conquista do dia na meta. Relatório inclui água.",
        "Relatórios (Mais)" to "Texto, PDF ou planilha CSV para a equipe.",
        "Tema azul" to "O botão redondo ao lado do ? no Início troca todas as cores do app entre o tema azul com cinza discreto e as cores originais. Toque de novo para voltar.",
        "Conta Google" to "Na primeira abertura o app pede para entrar com sua conta Google, que fica vinculada ao app. Ela aparece no topo do Perfil, com o e-mail e os botões Alterar e Sair. Sair leva você de volta à tela de login com o Google. Seus registros continuam salvos neste aparelho.",
        "Humor e figurinhas" to "No Início, toque no humor para escolher como você está. Há duas opções: emojis ou figurinhas de bruxinho (feliz, triste, animado, cansado e mais). A escolha fica guardada.",
        "Perfil" to "Dados de saúde, alergias, medicamentos. Compartilhar com selecionar todos, texto, PDF ou CSV.",
        "IA Cris" to "Chat texto/voz. Não substitui médico. Você pode enviar uma pergunta e sair do app ou apagar a tela: a Cris continua e avisa com uma notificação quando terminar; toque nela para abrir a conversa. Em ⋮ > Tarefas da Cris você vê o que está em andamento, concluído ou com erro e pode tentar de novo. Com internet pesquisa na web; sem internet usa o modelo do aparelho. Não substitui médico.",
        "Modelos da IA e downloads" to "Em Mais > IA da Cris: o app recomenda o modelo mais estável para o seu aparelho (Rápida, leve, ou Precisa, mais completa e pesada) e você pode trocar quando quiser. O download continua com a tela apagada ou fora do app, com Pausar e Cancelar na notificação, e retoma sozinho se a conexão cair. O Android pode limitar se a bateria estiver muito restrita.",
        "Localizador de insulina" to "Farmácias e pontos próximos.",
        "Configurações" to "Metas de glicemia, unidade, PIN.",
    )
    ScrollScreen {
        BackTitle("Central de aprendizado", { nav.popBackStack() })
        Text(
            "Guia de como mexer no Gluco Cris. O tour inteligente fala, aponta cada ponto da tela e deixa você tocar numa simulação: nada é salvo. Novidades do app entram nesta lista.",
            color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp),
        )
        PrimaryButton("Iniciar tour inteligente (com voz)", g.violet, { startSmartTour(vm) }, Modifier.padding(bottom = 4.dp))
        SectionTitle("Tutoriais por recurso")
        Text(
            "Toque em um recurso para ver só aquela parte, na tela de verdade, em modo simulação (nada é salvo). Pode repetir quando quiser.",
            color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 4.dp),
        )
        TOUR_SECTIONS.forEach { sec ->
            PrimaryButton(sec.first, g.violet, { startTourSection(vm, sec.first) }, Modifier.padding(bottom = 4.dp))
        }
        topics.forEach { (title, body) ->
            SectionTitle(title)
            GCard {
                Text(body, color = g.ink, fontSize = 14.sp, lineHeight = 20.sp)
            }
        }
        Text("Gluco Cris · uso de apoio", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp))
    }
}
