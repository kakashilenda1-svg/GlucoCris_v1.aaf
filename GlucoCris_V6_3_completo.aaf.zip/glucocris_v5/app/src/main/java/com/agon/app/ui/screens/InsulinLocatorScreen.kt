package com.agon.app.ui.screens

import android.content.Intent
import android.net.Uri

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.agon.app.data.insulin.BrazilGeo
import com.agon.app.data.insulin.ChannelType
import com.agon.app.data.insulin.City
import com.agon.app.data.insulin.InsulinCatalog
import com.agon.app.data.insulin.LocatorResult
import com.agon.app.data.insulin.LocatorScope
import com.agon.app.data.insulin.PriceTier
import com.agon.app.data.insulin.SortMode
import com.agon.app.data.insulin.SupplyNetwork
import com.agon.app.data.insulin.SupplyPoint
import com.agon.app.ui.theme.glucoColors
import com.agon.app.viewmodel.LocatorViewModel

private const val MAX_VISIBLE = 60

@Composable
fun InsulinLocatorScreen(
    nav: NavHostController,
    lvm: LocatorViewModel = viewModel(),
) {
    val g = glucoColors()
    val focus = LocalFocusManager.current
    var selectedPoint by remember { mutableStateOf<SupplyPoint?>(null) }
    var history by remember { mutableStateOf(listOf<String>()) }
    var citySearch by remember { mutableStateOf("") }
    var showCityPicker by remember { mutableStateOf(false) }

    val reference: City? = lvm.cityId?.let { BrazilGeo.cityById(it) }
        ?: lvm.uf?.let { BrazilGeo.capitalOf(it) }

    val result: LocatorResult = remember(lvm.query, reference?.id) {
        SupplyNetwork.search(lvm.query, reference)
    }
    val visiblePoints = result.points.take(MAX_VISIBLE)


    LaunchedEffect(lvm.text) {
        val t = lvm.text.trim()
        if (t.length < 2) return@LaunchedEffect
        kotlinx.coroutines.delay(350)
        if (lvm.text.trim() != t) return@LaunchedEffect
        if (t !in history) history = (listOf(t) + history).take(12)
        val hits = InsulinCatalog.search(t)
        if (hits.size == 1) {
            lvm.productId = hits.first().id
        }
    }

    fun commitSearch() {
        val t = lvm.text.trim()
        if (t.isBlank()) {
            focus.clearFocus()
            return
        }
        if (t !in history) history = (listOf(t) + history).take(12)
        // Tenta casar com produto do catálogo (ex: "lantus", "nph", "novorapid")
        val hits = InsulinCatalog.search(t)
        if (hits.size == 1) {
            lvm.productId = hits.first().id
        } else if (hits.isNotEmpty()) {
            // mantém texto; a busca por texto no SupplyNetwork já filtra
            lvm.productId = "all"
        }
        focus.clearFocus()
        selectedPoint = null
    }

    Column(Modifier.fillMaxSize().background(g.bg)) {
        // Top bar — igual estilo original + cores v2
        Row(
            Modifier.fillMaxWidth().background(g.card).padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(
                Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = g.ink,
                modifier = Modifier.size(28.dp).clickable { nav.popBackStack() },
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Localizador de Insulinas", fontWeight = FontWeight.Bold, fontSize = 17.sp, color = g.ink)
                Text(
                    when (lvm.scope) {
                        LocatorScope.BRASIL -> "Todo o Brasil"
                        LocatorScope.UF -> BrazilGeo.ufByCode(lvm.uf ?: "")?.name ?: lvm.uf ?: ""
                        LocatorScope.CIDADE -> BrazilGeo.cityById(lvm.cityId ?: "")?.label ?: ""
                    },
                    fontSize = 12.sp, color = g.muted,
                )
            }
            Icon(
                Icons.Default.FilterList, "Filtros",
                tint = if (lvm.filtersExpanded || lvm.activeFilterCount > 0) g.violet else g.muted,
                modifier = Modifier.size(26.dp).clickable { lvm.filtersExpanded = !lvm.filtersExpanded },
            )
        }

        // Campo de busca
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(g.inputBg)
                .border(1.dp, g.line, RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Default.Search, null, tint = g.muted, modifier = Modifier.size(20.dp))
            Spacer(Modifier.width(8.dp))
            BasicTextField(
                value = lvm.text,
                onValueChange = { lvm.text = it },
                singleLine = true,
                textStyle = TextStyle(color = g.ink, fontSize = 15.sp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { commitSearch() }),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    if (lvm.text.isEmpty()) {
                        Text("Buscar insulina (NPH, Lantus, glargina, Humalog…)", color = g.muted, fontSize = 14.sp)
                    }
                    inner()
                },
            )
            if (lvm.text.isNotEmpty()) {
                Icon(
                    Icons.Default.Close, "Limpar", tint = g.muted,
                    modifier = Modifier.size(18.dp).clickable { lvm.text = "" },
                )
            }
        }

        // Histórico
        if (history.isNotEmpty()) {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                items(history) { h ->
                    MiniChip(h, selected = false, g = g) {
                        lvm.text = h
                        commitSearch()
                    }
                }
            }
            Spacer(Modifier.height(4.dp))
        }

        // Produtos (catálogo completo da v1)
        Text(
            "Insulinas",
            fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = g.muted,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            item {
                MiniChip("Todas", selected = lvm.productId == "all", g = g) {
                    lvm.productId = "all"
                }
            }
            items(InsulinCatalog.products) { p ->
                MiniChip(
                    p.brandName,
                    selected = lvm.productId == p.id,
                    g = g,
                ) {
                    lvm.productId = if (lvm.productId == p.id) "all" else p.id
                }
            }
        }

        // Categorias
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            items(InsulinCatalog.categories) { cat ->
                MiniChip(
                    cat.name.substringBefore(" ("),
                    selected = cat.id in lvm.categoryIds,
                    g = g,
                ) { lvm.toggleCategory(cat.id) }
            }
        }

        // Localização: Brasil / UF / Cidade
        Text(
            "Onde buscar",
            fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = g.muted,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
        )
        LazyRow(
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            item {
                MiniChip("Brasil", selected = lvm.scope == LocatorScope.BRASIL, g = g) {
                    lvm.selectBrazil()
                    showCityPicker = false
                }
            }
            items(BrazilGeo.ufs) { uf ->
                MiniChip(
                    uf.code,
                    selected = lvm.uf == uf.code,
                    g = g,
                ) {
                    if (lvm.uf == uf.code && lvm.scope == LocatorScope.UF) {
                        lvm.selectBrazil()
                    } else {
                        lvm.selectUf(uf.code)
                        showCityPicker = true
                        citySearch = ""
                    }
                }
            }
        }

        // Cidades do estado selecionado
        if (lvm.uf != null) {
            val cities = remember(lvm.uf, citySearch) {
                val base = BrazilGeo.citiesOf(lvm.uf!!)
                if (citySearch.isBlank()) base
                else base.filter { it.name.lowercase().contains(citySearch.lowercase()) }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                BasicTextField(
                    value = citySearch,
                    onValueChange = { citySearch = it },
                    singleLine = true,
                    textStyle = TextStyle(color = g.ink, fontSize = 13.sp),
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(g.inputBg)
                        .border(1.dp, g.line, RoundedCornerShape(10.dp))
                        .padding(horizontal = 10.dp, vertical = 8.dp),
                    decorationBox = { inner ->
                        if (citySearch.isEmpty()) Text("Filtrar município…", color = g.muted, fontSize = 13.sp)
                        inner()
                    },
                )
            }
            LazyRow(
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                item {
                    MiniChip(
                        "Todo o estado",
                        selected = lvm.scope == LocatorScope.UF && lvm.cityId == null,
                        g = g,
                    ) { lvm.selectUf(lvm.uf!!) }
                }
                items(cities) { city ->
                    MiniChip(
                        city.name,
                        selected = lvm.cityId == city.id,
                        g = g,
                    ) { lvm.selectCity(city.id, city.uf) }
                }
            }
        }

        // Painel de filtros (canais, gratuito, ordenação)
        AnimatedVisibility(lvm.filtersExpanded) {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(g.card)
                    .border(1.dp, g.line, RoundedCornerShape(14.dp))
                    .padding(12.dp),
            ) {
                Text("Canais de acesso", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = g.ink)
                Spacer(Modifier.height(6.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ChannelType.entries.forEach { ch ->
                        MiniChip(
                            ch.short,
                            selected = ch.id in lvm.channelIds,
                            g = g,
                        ) { lvm.toggleChannel(ch.id) }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MiniChip(
                        if (lvm.onlyFree) "Só gratuito" else "Todos os preços",
                        selected = lvm.onlyFree,
                        g = g,
                    ) { lvm.onlyFree = !lvm.onlyFree }
                    MiniChip(
                        "Ordenar: ${lvm.sort.label}",
                        selected = false,
                        g = g,
                    ) {
                        lvm.sort = when (lvm.sort) {
                            SortMode.PROXIMIDADE -> SortMode.CONFIABILIDADE
                            SortMode.CONFIABILIDADE -> SortMode.PRECO
                            SortMode.PRECO -> SortMode.PROXIMIDADE
                        }
                    }
                    if (lvm.activeFilterCount > 0) {
                        MiniChip("Limpar filtros", selected = false, g = g) { lvm.clearFilters() }
                    }
                }
            }
        }

        // Resumo leve + quantidade offline
        val offlineCities = remember { com.agon.app.data.insulin.BrazilGeo.cities.size }
        val offlineChannels = ChannelType.entries.size
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "${result.points.size} locais · ${result.citiesCovered} cidades · ${result.matchedProducts.size} insulinas",
                fontSize = 12.sp, color = g.muted, modifier = Modifier.weight(1f),
            )
        }
        Text(
            "Base offline: $offlineCities municípios · $offlineChannels canais",
            fontSize = 11.sp, color = g.muted,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 0.dp),
        )
        if (result.points.size > MAX_VISIBLE) {
            Text(
                "Mostrando $MAX_VISIBLE de ${result.points.size}. Refine por estado ou município.",
                fontSize = 11.sp, color = g.orange,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp),
            )
        }

        LazyColumn(
            state = rememberLazyListState(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.weight(1f),
        ) {
            if (visiblePoints.isEmpty()) {
                item {
                    Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) {
                        Text(
                            "Nenhum ponto encontrado.\nAmplie o escopo ou mude a insulina/filtros.",
                            color = g.muted, fontSize = 14.sp, lineHeight = 20.sp,
                        )
                    }
                }
            }
            items(visiblePoints, key = { it.id }) { point ->
                SupplyPointCard(
                    point = point,
                    products = result.matchedProducts.filter { it.id in point.productIds },
                    selected = selectedPoint?.id == point.id,
                    onClick = { selectedPoint = if (selectedPoint?.id == point.id) null else point },
                    g = g,
                )
            }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun MiniChip(
    label: String,
    selected: Boolean,
    g: com.agon.app.ui.theme.GlucoColors,
    onClick: () -> Unit,
) {
    Text(
        label,
        fontSize = 12.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        color = if (selected) Color.White else g.ink,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) g.violet else g.card)
            .border(1.dp, if (selected) g.violet else g.line, RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 5.dp),
    )
}

@Composable
private fun SupplyPointCard(
    point: SupplyPoint,
    products: List<com.agon.app.data.insulin.InsulinProduct>,
    selected: Boolean,
    onClick: () -> Unit,
    g: com.agon.app.ui.theme.GlucoColors,
) {
    val context = LocalContext.current
    val channel = point.channel
    val icon: ImageVector = when (channel) {
        ChannelType.FARMACIA_POPULAR -> Icons.Default.LocalPharmacy
        ChannelType.ATENCAO_BASICA -> Icons.Default.LocalHospital
        ChannelType.CEAF -> Icons.Default.MedicalServices
        ChannelType.PRIVADA -> Icons.Default.LocalPharmacy
    }
    val accent = when (channel.priceTier) {
        PriceTier.GRATUITO, PriceTier.GRATUITO_PROCESSO -> g.green
        PriceTier.PMC_CMED -> g.blue
    }
    val primaryProduct = products.firstOrNull()
    val category = primaryProduct?.let { InsulinCatalog.categoryById(it.categoryId) }

    fun openUrl(url: String) {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        }
    }
    fun dial(phone: String) {
        runCatching {
            context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone")))
        }
    }

    // Busca do estabelecimento no Google Maps (cidade + tipo), centrado nas coordenadas
    fun mapsSearchUrl(): String {
        val place = when (channel) {
            ChannelType.FARMACIA_POPULAR ->
                "Farmácia Popular Aqui Tem ${point.city.name} ${point.city.uf}"
            ChannelType.ATENCAO_BASICA ->
                "UBS farmácia ${point.city.name} ${point.city.uf}"
            ChannelType.CEAF ->
                "Farmácia CEAF ${point.city.name} ${point.city.uf}"
            ChannelType.PRIVADA ->
                "farmácia drogaria ${point.city.name} ${point.city.uf}"
        }
        val q = Uri.encode(place)
        // Abre a busca do estabelecimento centrada nas coordenadas da cidade
        return "https://www.google.com/maps/search/$q/@${point.city.lat},${point.city.lon},14z"
    }

    // Site / diretório para achar o estabelecimento (não página genérica fora do ar)
    fun establishmentFindUrl(): String {
        val cityUf = Uri.encode("${point.city.name} ${point.city.uf}")
        return when (channel) {
            ChannelType.FARMACIA_POPULAR ->
                // Busca Google do credenciado no município (painel MS costuma falhar)
                "https://www.google.com/search?q=" + Uri.encode("Aqui Tem Farmácia Popular ${point.city.name} ${point.city.uf} endereço")
            ChannelType.ATENCAO_BASICA ->
                "https://www.google.com/search?q=" + Uri.encode("UBS ${point.city.name} ${point.city.uf} farmácia endereço telefone")
            ChannelType.CEAF ->
                "https://www.google.com/search?q=" + Uri.encode("Farmácia CEAF ${point.city.uf} ${point.city.name} endereço")
            ChannelType.PRIVADA ->
                "https://www.google.com/search?q=" + Uri.encode("farmácia ${point.city.name} ${point.city.uf} insulina endereço")
        }
    }

    fun establishmentLabel(): String = when (channel) {
        ChannelType.FARMACIA_POPULAR -> "Buscar Farmácia Popular"
        ChannelType.ATENCAO_BASICA -> "Buscar UBS / farmácia"
        ChannelType.CEAF -> "Buscar farmácia CEAF"
        ChannelType.PRIVADA -> "Buscar farmácia"
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(g.card)
            .border(1.dp, if (selected) g.violet else g.line, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(12.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(36.dp).clip(CircleShape).background(accent.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center,
            ) {
                Icon(icon, null, tint = accent, modifier = Modifier.size(18.dp))
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(channel.short, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, color = g.ink)
                Text("${point.city.name} — ${point.city.uf}", fontSize = 12.sp, color = g.muted)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    channel.priceTier.label.substringBefore(" —").substringBefore(" pelo"),
                    fontSize = 11.sp, fontWeight = FontWeight.Medium, color = accent,
                )
                if (point.distanceKm > 0) {
                    Text(String.format("%.0f km", point.distanceKm), fontSize = 11.sp, color = g.muted)
                }
            }
        }

        AnimatedVisibility(selected) {
            Column(Modifier.padding(top = 12.dp)) {
                // Endereço em destaque
                Text("Endereço / como encontrar", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = g.ink)
                Spacer(Modifier.height(4.dp))
                Text(
                    point.addressHint,
                    fontSize = 14.sp,
                    color = g.ink,
                    lineHeight = 20.sp,
                    fontWeight = FontWeight.Medium,
                )
                Text(point.coverage, fontSize = 12.sp, color = g.muted, modifier = Modifier.padding(top = 4.dp))
                Spacer(Modifier.height(10.dp))

                // Bloco de produto
                if (primaryProduct != null) {
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(g.inputBg)
                            .padding(12.dp),
                    ) {
                        Text("Princípio ativo: ${primaryProduct.activeIngredient}", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        Text("Marca/fabricante: ${primaryProduct.manufacturer}", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        if (category != null) {
                            Text("Categoria oficial: ${category.name}", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        }
                        val apres = primaryProduct.presentations.joinToString(", ")
                        val conc = primaryProduct.concentrations.joinToString(", ")
                        Text("Apresentações: $apres ($conc)", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(primaryProduct.publicNote, fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                        if (category != null) {
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Início ${category.onset} · pico ${category.peak} · duração ${category.duration}",
                                fontSize = 12.sp, fontWeight = FontWeight.Medium, color = g.green,
                            )
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }

                Text("Documentos e condições para retirada", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = g.ink)
                Spacer(Modifier.height(6.dp))
                point.conditions.forEach { c ->
                    Text("• $c", fontSize = 13.sp, color = g.ink, lineHeight = 18.sp)
                }

                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("✓  ", fontSize = 14.sp, color = g.green, fontWeight = FontWeight.Bold)
                    Text("Como achar o estabelecimento", fontWeight = FontWeight.SemiBold, fontSize = 13.sp, color = g.ink)
                }
                Text(
                    "A base é offline por município/canal. Use os botões abaixo para abrir o mapa no local ou buscar o endereço/telefone do estabelecimento em ${point.city.name}/${point.city.uf}.",
                    fontSize = 12.sp, color = g.muted, lineHeight = 16.sp,
                )

                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionBtn(
                        label = establishmentLabel(),
                        filled = true,
                        g = g,
                        modifier = Modifier.weight(1f),
                    ) { openUrl(establishmentFindUrl()) }
                    ActionBtn(
                        label = "No mapa",
                        filled = false,
                        g = g,
                        modifier = Modifier.weight(1f),
                    ) { openUrl(mapsSearchUrl()) }
                }
                Spacer(Modifier.height(8.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionBtn(
                        label = "Disque Saúde 136",
                        filled = false,
                        g = g,
                        modifier = Modifier.weight(1f),
                    ) { dial("136") }
                    ActionBtn(
                        label = "Endereço no mapa",
                        filled = false,
                        g = g,
                        modifier = Modifier.weight(1f),
                    ) { openUrl(mapsSearchUrl()) }
                }

                Spacer(Modifier.height(10.dp))
                Text(
                    "Fechar",
                    fontSize = 14.sp, fontWeight = FontWeight.Medium, color = g.green,
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .clickable(onClick = onClick)
                        .padding(8.dp),
                )
            }
        }
    }
}

@Composable
private fun ActionBtn(
    label: String,
    filled: Boolean,
    g: com.agon.app.ui.theme.GlucoColors,
    modifier: Modifier = Modifier,
    onClick: () -> Unit,
) {
    Box(
        modifier
            .clip(RoundedCornerShape(24.dp))
            .background(if (filled) g.green else Color.Transparent)
            .border(1.dp, if (filled) g.green else g.line, RoundedCornerShape(24.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = if (filled) Color.White else g.ink,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}
