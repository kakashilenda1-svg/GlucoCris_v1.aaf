package com.agon.app.ui.screens

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.drawable.BitmapDrawable
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.agon.app.data.HealthPlace
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker

/** Mapa interativo (OpenStreetMap, sem chave) com os locais filtrados. */
@Composable
fun PlacesMap(
    center: Pair<Double, Double>,
    places: List<HealthPlace>,
    selectedId: String?,
    colorFor: (HealthPlace) -> Color,
    userColor: Color,
    onSelect: (HealthPlace) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val map = remember {
        Configuration.getInstance().apply {
            userAgentValue = context.packageName
            osmdroidBasePath = context.cacheDir
            osmdroidTileCache = java.io.File(context.cacheDir, "tiles")
        }
        MapView(context).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            zoomController.setVisibility(org.osmdroid.views.CustomZoomButtonsController.Visibility.NEVER)
            controller.setZoom(14.0)
            minZoomLevel = 4.0
            maxZoomLevel = 19.0
        }
    }
    val iconCache = remember { HashMap<String, BitmapDrawable>() }
    val lastFit = remember { arrayOf<String?>(null) }
    val lastSel = remember { arrayOf<String?>(null) }
    val lastSig = remember { arrayOf<String?>(null) }

    DisposableEffect(lifecycle) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> map.onResume()
                Lifecycle.Event.ON_PAUSE -> map.onPause()
                else -> {}
            }
        }
        lifecycle.addObserver(obs)
        map.onResume()
        onDispose {
            lifecycle.removeObserver(obs)
            map.onPause()
            map.onDetach()
        }
    }

    fun dot(color: Int, big: Boolean): BitmapDrawable {
        val key = "$color-$big"
        return iconCache.getOrPut(key) {
            val d = context.resources.displayMetrics.density
            val size = ((if (big) 30 else 22) * d).toInt()
            val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val p = Paint(Paint.ANTI_ALIAS_FLAG)
            p.color = android.graphics.Color.WHITE
            c.drawCircle(size / 2f, size / 2f, size / 2f, p)
            p.color = color
            c.drawCircle(size / 2f, size / 2f, size / 2f - 3 * d, p)
            BitmapDrawable(context.resources, bmp)
        }
    }

    AndroidView(
        factory = { map },
        modifier = modifier,
        update = update@{ mv ->
            // Só reconstrói os marcadores quando algo mudou de fato; limita a 150 pontos (os mais próximos)
            val sig = "${center.first},${center.second}|${places.size}|${places.firstOrNull()?.id}|${places.lastOrNull()?.id}|$selectedId"
            if (lastSig[0] == sig) return@update
            lastSig[0] = sig
            mv.overlays.clear()
            val me = Marker(mv).apply {
                position = GeoPoint(center.first, center.second)
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                icon = dot(userColor.toArgb(), true)
                title = "Você está aqui"
                setOnMarkerClickListener { _, _ -> true }
            }
            places.take(150).forEach { p ->
                val selected = p.id == selectedId
                mv.overlays.add(
                    Marker(mv).apply {
                        position = GeoPoint(p.lat, p.lon)
                        setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
                        icon = dot(colorFor(p).toArgb(), selected)
                        setOnMarkerClickListener { _, _ -> onSelect(p); true }
                    },
                )
            }
            mv.overlays.add(me)
            // Enquadra quando muda o conjunto de locais
            val key = "${center.first},${center.second},${places.size},${places.firstOrNull()?.id}"
            if (lastFit[0] != key) {
                lastFit[0] = key
                val pts = places.take(60).map { GeoPoint(it.lat, it.lon) } + GeoPoint(center.first, center.second)
                if (pts.size > 1) {
                    val box = BoundingBox.fromGeoPointsSafe(pts)
                    mv.post { mv.zoomToBoundingBox(box.increaseByScale(1.25f), false, 48) }
                } else {
                    mv.controller.setCenter(GeoPoint(center.first, center.second))
                    mv.controller.setZoom(15.0)
                }
            }
            if (selectedId != lastSel[0]) {
                lastSel[0] = selectedId
                selectedId?.let { id -> places.firstOrNull { it.id == id }?.let { mv.controller.animateTo(GeoPoint(it.lat, it.lon)) } }
            }
            mv.invalidate()
        },
    )
}
