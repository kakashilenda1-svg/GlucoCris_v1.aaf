package com.agon.app.ui.screens

import android.content.Context
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Meal
import com.agon.app.data.uid
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.glucoColors
import kotlin.math.roundToInt

/* ───────── Prato (montagem de refeição com soma dos nutrientes) ───────── */

/** Um alimento no prato e quantas porções dele (1 = a porção mostrada na busca). */
data class PlateLine(
    val food: FoodItem,
    val qty: Double = 1.0,
    /** Se definido, o peso em g/ml manda no recálculo (em vez só da quantidade de porções). */
    val grams: Double? = null,
) {
    fun factor(): Double {
        val g = grams
        if (g != null && g > 0 && food.servingGrams > 0) return g / food.servingGrams
        return qty.coerceAtLeast(0.0)
    }
}

data class PlateTotals(
    val kcal: Double,
    val carbs: Double,
    val protein: Double,
    val fat: Double,
    val fiber: Double,
    val sugars: Double,
    val satFat: Double,
    val sodium: Double,
)

fun plateTotals(lines: List<PlateLine>): PlateTotals {
    val items = lines.map { it.food.scaled(it.factor()) }
    return PlateTotals(
        kcal = items.sumOf { it.kcal },
        carbs = items.sumOf { it.carbs },
        protein = items.sumOf { it.protein },
        fat = items.sumOf { it.fat },
        fiber = items.sumOf { it.fiber },
        sugars = items.sumOf { it.sugars },
        satFat = items.sumOf { it.satFat },
        sodium = items.sumOf { it.sodium },
    )
}

private fun plateFmt(v: Double): String = String.format(java.util.Locale.US, "%.1f", v)

private fun plateQtyLabel(q: Double): String =
    if (q % 1.0 == 0.0) q.toInt().toString() else String.format(java.util.Locale.US, "%.1f", q)

/** Guarda o total do prato para a calculadora de bolus ler ao abrir. */
fun sendPlateToBolus(ctx: Context, t: PlateTotals, desc: String) {
    ctx.getSharedPreferences("gluco_food_tools", Context.MODE_PRIVATE)
        .edit()
        .putFloat("last_meal_carbs", t.carbs.toFloat())
        .putFloat("last_meal_kcal", t.kcal.toFloat())
        .putFloat("last_meal_prot", t.protein.toFloat())
        .putFloat("last_meal_fat", t.fat.toFloat())
        .putString("last_meal_desc", desc)
        .apply()
}

@Composable
private fun PlateRow(label: String, value: String, bold: Boolean = false) {
    val g = glucoColors()
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, color = g.ink, fontSize = 14.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text(value, color = g.ink, fontSize = 14.sp, fontWeight = if (bold) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable
private fun PlateLegend(color: Color, text: String) {
    val g = glucoColors()
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
        Box(Modifier.size(10.dp).clip(RoundedCornerShape(5.dp)).background(color))
        Text(text, color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp))
    }
}

@Composable
fun FoodPlateScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val ctx = LocalContext.current
    val lines by vm.plate.collectAsStateWithLifecycle()
    var mealType by remember { mutableStateOf(vm.plateMealType) }
    var savedMsg by remember { mutableStateOf<String?>(null) }
    var showWaterAsk by remember { mutableStateOf(false) }

    val data by vm.data.collectAsStateWithLifecycle()
    val allergyBlob = listOf(data.settings.allergies, data.settings.allergyNotes, data.settings.foodRestrictions)
        .joinToString(" ").lowercase()
    val allergyTokens = allergyBlob.split(Regex("[,;/]| e |\n")).map { it.trim() }.filter { it.length >= 3 }
    val allergyHits = lines.map { it.food.name }.filter { name ->
        val n = name.lowercase()
        allergyTokens.any { tok -> tok in n || n in tok }
    }.distinct()
    val t = plateTotals(lines)
    val desc = lines.joinToString(" + ") { it.food.name }
    val macroTotal = (t.carbs * 4 + t.protein * 4 + t.fat * 9).coerceAtLeast(0.1)
    val pctC = ((t.carbs * 4) / macroTotal * 100).toFloat()
    val pctP = ((t.protein * 4) / macroTotal * 100).toFloat()
    val pctF = ((t.fat * 9) / macroTotal * 100).toFloat()
    val colorCarb = Color(0xFF38BDF8)
    val colorFat = Color(0xFFFBBF24)
    val colorProt = Color(0xFFF472B6)

    ScrollScreen {
        BackTitle("Prato", { nav.popBackStack() })

        Text("Refeição", color = g.muted, fontSize = 12.sp)
        ChipRow(MEAL_OPTIONS, mealType) {
            mealType = it
            vm.plateMealType = it
        }

        savedMsg?.let {
            Text(
                it,
                color = g.green,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(vertical = 8.dp),
            )
        }

        if (lines.isEmpty()) {
            EmptyState(
                "Prato vazio",
                "Na busca, marque a caixinha ao lado dos alimentos para montar o prato.",
            )
            PrimaryButton("Buscar alimentos", g.violet, { nav.popBackStack() })
        } else {
            if (allergyHits.isNotEmpty()) {
                GCard(Modifier.padding(top = 8.dp)) {
                    Text("Atenção — possível alergia/restrição", color = g.orange, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        "No perfil há indicação que pode cruzar com: ${allergyHits.joinToString(", ")}. Confira o rótulo e sua equipe.",
                        color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }
            // Resumo + gráfico
            GCard(Modifier.padding(top = 8.dp)) {
                Text(
                    "Total do prato · ${lines.size} item(ns)",
                    color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                )
                Row(
                    Modifier.fillMaxWidth().padding(top = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(Modifier.size(110.dp), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            val stroke = size.minDimension * 0.18f
                            val diam = size.minDimension - stroke
                            val topLeft = Offset((size.width - diam) / 2f, (size.height - diam) / 2f)
                            val arcSize = Size(diam, diam)
                            var start = -90f
                            val slices = listOf(pctC to colorCarb, pctF to colorFat, pctP to colorProt)
                            slices.forEach { (pct, col) ->
                                val sweep = 360f * (pct / 100f).coerceIn(0f, 1f)
                                if (sweep > 0.5f) {
                                    drawArc(
                                        color = col,
                                        startAngle = start,
                                        sweepAngle = sweep,
                                        useCenter = false,
                                        topLeft = topLeft,
                                        size = arcSize,
                                        style = Stroke(width = stroke, cap = StrokeCap.Butt),
                                    )
                                }
                                start += sweep
                            }
                        }
                        Text(
                            "${t.kcal.roundToInt()}\nkcal",
                            color = g.ink, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                        )
                    }
                    Column(Modifier.weight(1f).padding(start = 14.dp)) {
                        PlateLegend(colorCarb, "Carboidratos ${plateFmt(t.carbs)} g (${pctC.roundToInt()}%)")
                        PlateLegend(colorFat, "Gorduras ${plateFmt(t.fat)} g (${pctF.roundToInt()}%)")
                        PlateLegend(colorProt, "Proteínas ${plateFmt(t.protein)} g (${pctP.roundToInt()}%)")
                    }
                }
                HorizontalDivider(color = g.line, modifier = Modifier.padding(vertical = 10.dp))
                PlateRow("Calorias", "${t.kcal.roundToInt()} kcal", bold = true)
                PlateRow("Carboidratos", "${plateFmt(t.carbs)} g", bold = true)
                PlateRow("   Açúcares", if (t.sugars > 0) "${plateFmt(t.sugars)} g" else "—")
                PlateRow("   Fibras", if (t.fiber > 0) "${plateFmt(t.fiber)} g" else "—")
                PlateRow("Proteínas", "${plateFmt(t.protein)} g", bold = true)
                PlateRow("Gorduras", "${plateFmt(t.fat)} g", bold = true)
                PlateRow("   Saturadas", if (t.satFat > 0) "${plateFmt(t.satFat)} g" else "—")
                PlateRow("Sódio", if (t.sodium > 0) "${t.sodium.roundToInt()} mg" else "—")
            }

            // Ingredientes
            GCard(Modifier.padding(top = 10.dp)) {
                Text("Ingredientes", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(
                    "Use −/+ para quantidade, peso em g/ml e Tabela para a ficha completa. Totais na hora.",
                    color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 4.dp),
                )
                lines.forEach { line ->
                    val f = line.food.scaled(line.factor())
                    val gramsShow = line.grams
                        ?: (if (line.food.servingGrams > 0) line.qty * line.food.servingGrams else null)
                    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                        Text(line.food.name, color = g.ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(
                            "${plateQtyLabel(line.qty)} × ${line.food.serving}" +
                                (gramsShow?.let { " · ${plateFmt(it)} g" } ?: ""),
                            color = g.green, fontSize = 13.sp,
                        )
                        Text(
                            "${f.kcal.roundToInt()} kcal · C ${plateFmt(f.carbs)} g · P ${plateFmt(f.protein)} g · G ${plateFmt(f.fat)} g",
                            color = g.muted, fontSize = 12.sp,
                        )
                        Row(
                            Modifier.fillMaxWidth().padding(top = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("Qtd", color = g.muted, fontSize = 12.sp, modifier = Modifier.width(28.dp))
                            Box(
                                Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(17.dp))
                                    .background(g.lilacSoft)
                                    .clickable { vm.setPlateQty(line.food.id, line.qty - 0.5) },
                                contentAlignment = Alignment.Center,
                            ) { Text("−", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                            Text(
                                plateQtyLabel(line.qty),
                                color = g.ink, fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp),
                            )
                            Box(
                                Modifier
                                    .size(34.dp)
                                    .clip(RoundedCornerShape(17.dp))
                                    .background(g.lilacSoft)
                                    .clickable { vm.setPlateQty(line.food.id, line.qty + 0.5) },
                                contentAlignment = Alignment.Center,
                            ) { Text("+", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
                            Spacer(Modifier.weight(1f))
                            Text(
                                "✕",
                                color = g.red, fontSize = 18.sp, fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .clickable { vm.removeFromPlate(line.food.id) }
                                    .padding(8.dp),
                            )
                        }
                        Row(
                            Modifier.fillMaxWidth().padding(top = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text("Peso", color = g.muted, fontSize = 12.sp, modifier = Modifier.width(36.dp))
                            var gText by remember(line.food.id, line.grams, line.qty) {
                                mutableStateOf(
                                    gramsShow?.let {
                                        if (it == it.toLong().toDouble()) it.toLong().toString() else plateFmt(it)
                                    } ?: "",
                                )
                            }
                            OutlinedTextField(
                                value = gText,
                                onValueChange = { raw ->
                                    gText = raw.filter { it.isDigit() || it == ',' || it == '.' }
                                    gText.replace(",", ".").toDoubleOrNull()?.let { v ->
                                        if (v > 0) vm.setPlateGrams(line.food.id, v)
                                    }
                                },
                                modifier = Modifier.width(100.dp).height(52.dp),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                                placeholder = { Text("g", color = g.muted) },
                            )
                            Text("g/ml", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp))
                            Spacer(Modifier.weight(1f))
                            Text(
                                "Tabela",
                                color = g.violet,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                modifier = Modifier
                                    .clickable {
                                        vm.setTempFood(line.food, mealType)
                                        nav.navigate(Routes.FOOD_DETAIL)
                                    }
                                    .padding(8.dp),
                            )
                        }
                    }
                    HorizontalDivider(color = g.line)
                }
                OutlinedButton(
                    onClick = { nav.popBackStack() },
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                ) { Text("+ Adicionar alimento", color = g.violet) }
            }

            // Ações
            PrimaryButton(
                "Calcular Bolus com este prato",
                g.violet,
                {
                    sendPlateToBolus(ctx, t, desc)
                    vm.plateMealType = mealType
                    nav.navigate(Routes.FOOD_BOLUS)
                },
                Modifier.padding(top = 12.dp),
            )
            Text(
                "Leva carboidratos, calorias, proteínas e gorduras do prato para a calculadora. Confirme antes de aplicar insulina.",
                color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp),
            )
            PrimaryButton(
                "Salvar no diário",
                g.green,
                {
                    val kcalTxt = t.kcal.roundToInt().toString()
                    val protTxt = plateFmt(t.protein)
                    val fatTxt = plateFmt(t.fat)
                    vm.saveMeal(
                        Meal(
                            id = uid(),
                            type = mealType,
                            description = desc,
                            carbs = t.carbs,
                            at = System.currentTimeMillis(),
                            notes = "kcal=" + kcalTxt + ";prot=" + protTxt + ";fat=" + fatTxt + ";fonte=prato",
                        ),
                    )
                    vm.clearPlate()
                    savedMsg = "Prato salvo no diário ✓"
                    if (askWaterAfterMeal(ctx)) showWaterAsk = true
                },
                Modifier.padding(top = 10.dp),
            )
            if (showWaterAsk) {
                GCard(Modifier.padding(top = 8.dp)) {
                    Text("Registrar água agora?", color = g.ink, fontWeight = FontWeight.Bold)
                    Text("Atalho pós-refeição do Cris Hidrata (desligável nas configs do contador).", color = g.muted, fontSize = 12.sp)
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        PrimaryButton("Abrir Cris Hidrata", g.blue, {
                            showWaterAsk = false
                            nav.navigate(Routes.WATER)
                        }, Modifier.weight(1f))
                    }
                    TextButton(onClick = { showWaterAsk = false }) {
                        Text("Agora não", color = g.muted)
                    }
                }
            }
            TextButton(
                onClick = {
                    vm.clearPlate()
                    savedMsg = null
                },
                modifier = Modifier.padding(top = 4.dp),
            ) { Text("Limpar prato", color = g.muted) }
        }
    }
}
