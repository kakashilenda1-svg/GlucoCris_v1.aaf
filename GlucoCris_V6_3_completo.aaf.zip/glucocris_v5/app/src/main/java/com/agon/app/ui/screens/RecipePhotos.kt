package com.agon.app.ui.screens

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.Normalizer
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject

/**
 * Foto automática das receitas: busca uma imagem representativa do prato na Wikipédia (pt),
 * guarda no aparelho e reutiliza nas próximas vezes. Foto escolhida pelo usuário tem prioridade.
 */
object RecipePhotoResolver {
    private const val PREFS = "gluco_recipe_auto_photos"
    private const val RETRY_AFTER_MS = 3L * 24 * 60 * 60 * 1000
    private val gate = Semaphore(3)
    private val mem = ConcurrentHashMap<String, String>()

    fun cached(ctx: Context, id: String): String? {
        mem[id]?.let { return it }
        val url = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("p_$id", null)
        if (!url.isNullOrBlank()) mem[id] = url
        return url?.takeIf { it.isNotBlank() }
    }

    suspend fun resolve(ctx: Context, r: RecipeItem): String? {
        cached(ctx, r.id)?.let { return it }
        val sp = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val failedAt = sp.getLong("n_${r.id}", 0L)
        if (failedAt > 0 && System.currentTimeMillis() - failedAt < RETRY_AFTER_MS) return null
        val found = gate.withPermit { withContext(Dispatchers.IO) { search(r.name) } }
        if (found != null) {
            mem[r.id] = found
            sp.edit().putString("p_${r.id}", found).remove("n_${r.id}").apply()
        } else {
            sp.edit().putLong("n_${r.id}", System.currentTimeMillis()).apply()
        }
        return found
    }

    private val noise = setOf(
        "light", "fit", "simples", "low", "carb", "lowcarb", "integral", "caseiro", "caseira",
        "rapido", "rapida", "de", "da", "do", "das", "dos", "com", "e", "na", "no", "ao", "a", "em", "para", "sem",
    )

    private fun norm(s: String): String =
        Normalizer.normalize(s, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "").lowercase()

    private fun queries(name: String): List<String> {
        val base = name.replace(Regex("\\(.*?\\)"), "").trim()
        val head = base.split(" com ", " ao ", " à ", " na ", " no ", " e ").first().trim()
        val clean = head.split(" ").filter { norm(it) !in noise || it == head.split(" ").first() }.joinToString(" ")
        val first = head.split(" ").firstOrNull { it.length >= 4 && norm(it) !in noise } ?: head
        return listOf(base, head, clean, first).filter { it.length >= 3 }.distinct()
    }

    private fun search(name: String): String? {
        for (q in queries(name)) {
            val key = q.split(" ").firstOrNull { it.length >= 4 && norm(it) !in noise }?.let { norm(it) } ?: norm(q)
            val url = try { queryWiki(q, key) } catch (_: Exception) { null }
            if (url != null) return url
        }
        return null
    }

    private fun queryWiki(q: String, key: String): String? {
        val enc = URLEncoder.encode(q, "UTF-8")
        val api = "https://pt.wikipedia.org/w/api.php?action=query&format=json&generator=search" +
            "&gsrnamespace=0&gsrlimit=6&gsrsearch=$enc&prop=pageimages&piprop=thumbnail&pithumbsize=500&origin=*"
        val conn = (URL(api).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 4000; readTimeout = 5000
            setRequestProperty("User-Agent", "GlucoCris/1.7 (app Android; receitas)")
        }
        if (conn.responseCode != 200) return null
        val pages = JSONObject(conn.inputStream.bufferedReader().readText())
            .optJSONObject("query")?.optJSONObject("pages") ?: return null
        val hits = pages.keys().asSequence().map { pages.getJSONObject(it) }.sortedBy { it.optInt("index", 99) }.toList()
        for (p in hits) {
            val src = p.optJSONObject("thumbnail")?.optString("source", "").orEmpty()
            if (src.isBlank() || src.contains(".svg", true)) continue
            if (key.isNotBlank() && !norm(p.optString("title", "")).contains(key.take(5))) continue
            return src
        }
        return null
    }
}

/** Foto da receita: do usuário > da própria receita > automática (cache/internet). */
@Composable
fun rememberRecipePhoto(r: RecipeItem, userThumb: String?): String? {
    val ctx = LocalContext.current
    var auto by remember(r.id) { mutableStateOf(RecipePhotoResolver.cached(ctx, r.id)) }
    val direct = userThumb?.takeIf { it.isNotBlank() } ?: r.thumb.takeIf { it.isNotBlank() }
    LaunchedEffect(r.id, direct) {
        if (direct == null && auto == null) auto = RecipePhotoResolver.resolve(ctx, r)
    }
    return direct ?: auto
}
