package com.agon.app.ui.screens

import com.agon.app.ui.components.tourTarget
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Reminder
import com.agon.app.data.WEEKDAYS
import com.agon.app.data.daysLabel
import com.agon.app.data.formatClock
import com.agon.app.data.uid
import com.agon.app.reminders.CustomSounds
import com.agon.app.reminders.SOUND_PRESETS
import com.agon.app.reminders.SoundPlayer
import com.agon.app.reminders.isCustomSound
import com.agon.app.ui.components.BackTitle
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.ConfirmDialog
import com.agon.app.ui.components.EmptyState
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GField
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.theme.glucoColors

// ---------- Pequenos blocos reutilizados ----------

@Composable
private fun PillButton(text: String, color: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .heightIn(min = 44.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(color.copy(alpha = 0.14f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun Badge(text: String) {
    val g = glucoColors()
    Text(
        text,
        color = g.violetDeep,
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(g.lilacSoft)
            .padding(horizontal = 8.dp, vertical = 4.dp),
    )
}

@Composable
private fun FieldLabel(text: String, topPadding: Int = 10) {
    val g = glucoColors()
    Text(text, color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = topPadding.dp))
}

private fun openSettings(context: Context, intent: Intent) {
    try {
        context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {
        try {
            context.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            )
        } catch (_: Exception) {
        }
    }
}

// ---------- Tela principal ----------

@Composable
fun RemindersScreen(vm: GlucoViewModel) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val context = LocalContext.current
    var editing by remember { mutableStateOf<Reminder?>(null) }
    var creating by remember { mutableStateOf(false) }
    var confirmId by remember { mutableStateOf<String?>(null) }
    var showTips by remember { mutableStateOf(false) }

    if (creating || editing != null) {
        ScrollScreen {
            BackTitle(if (editing == null) "Novo lembrete" else "Editar lembrete") {
                SoundPlayer.stop()
                creating = false
                editing = null
            }
            ReminderForm(
                initial = editing,
                onCancel = {
                    SoundPlayer.stop()
                    creating = false
                    editing = null
                },
                onSave = {
                    SoundPlayer.stop()
                    vm.saveReminder(it)
                    creating = false
                    editing = null
                },
            )
        }
        return
    }

    ScrollScreen {
        Text("Lembretes", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
        Text(
            "Glicose e insulina, cada horário com o seu som.",
            color = g.muted,
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 2.dp),
        )
        PrimaryButton("＋  Novo lembrete", g.violet, { creating = true; editing = null }, Modifier.padding(top = 14.dp).tourTarget("reminders_add"))

        GCard(Modifier.padding(top = 12.dp)) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .clickable { showTips = !showTips },
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("O lembrete não tocou?", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
                Text(if (showTips) "Fechar" else "Ver dicas", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            if (showTips) {
                Text(
                    "• O som toca no volume do ALARME do celular. Se ele estiver no zero, você não ouve nada.\n" +
                        "• Permita as notificações do app.\n" +
                        "• Permita alarmes exatos, para tocar no minuto certo.\n" +
                        "• Tire o app da economia de bateria.",
                    color = g.muted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 8.dp),
                )
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("Notificações", g.violet, {
                        openSettings(
                            context,
                            Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName),
                        )
                    }, Modifier.weight(1f))
                    PillButton("Alarmes", g.violet, {
                        if (Build.VERSION.SDK_INT >= 31) {
                            openSettings(
                                context,
                                Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${context.packageName}")),
                            )
                        }
                    }, Modifier.weight(1f))
                    PillButton("Bateria", g.violet, {
                        openSettings(context, Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                    }, Modifier.weight(1f))
                }
            }
        }

        if (data.reminders.isEmpty()) {
            EmptyState("Sem lembretes", "Toque em “Novo lembrete” para criar o primeiro.")
        }

        data.reminders.sortedWith(compareBy({ it.hour }, { it.minute })).forEach { r ->
            GCard(Modifier.padding(top = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(formatClock(r.hour, r.minute), color = if (r.enabled) g.ink else g.muted, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp)
                        Text(r.title, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(daysLabel(r.days), color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                    }
                    Switch(checked = r.enabled, onCheckedChange = { vm.toggleReminder(r.id) })
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Badge(if (r.kind == "glicose") "🩸 Medir glicose" else "💉 Aplicar insulina")
                    Badge("🔔 " + SoundPlayer.soundLabel(context, r.soundId))
                }
                if (r.notes.isNotBlank()) {
                    Text(r.notes, color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                }
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("Editar", g.violet, { editing = r; creating = false }, Modifier.weight(1f))
                    PillButton("▶ Ouvir", g.blue, { SoundPlayer.play(context, r.soundId) }, Modifier.weight(1f))
                    PillButton("Excluir", g.red, { confirmId = r.id }, Modifier.weight(1f))
                }
            }
        }
    }
    confirmId?.let { id ->
        ConfirmDialog("Excluir lembrete", "Esta ação não pode ser desfeita.", "Excluir", {
            vm.deleteReminder(id)
            confirmId = null
        }) { confirmId = null }
    }
}

// ---------- Formulário ----------

@Composable
private fun SoundRow(selected: Boolean, title: String, subtitle: String, onSelect: () -> Unit, onPlay: () -> Unit) {
    val g = glucoColors()
    Row(
        Modifier
            .fillMaxWidth()
            .padding(top = 6.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(if (selected) g.lilacSoft else Color.Transparent)
            .clickable(onClick = onSelect)
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(if (selected) "●" else "○", color = g.violet, fontSize = 18.sp, modifier = Modifier.padding(end = 10.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(subtitle, color = g.muted, fontSize = 12.sp)
        }
        PillButton("▶ Ouvir", g.blue, onPlay)
    }
}

@Composable
private fun ReminderForm(initial: Reminder?, onCancel: () -> Unit, onSave: (Reminder) -> Unit) {
    val g = glucoColors()
    val context = LocalContext.current
    var title by remember(initial?.id) { mutableStateOf(initial?.title ?: "") }
    var kind by remember(initial?.id) { mutableStateOf(initial?.kind ?: "glicose") }
    var hour by remember(initial?.id) { mutableStateOf(initial?.hour?.toString() ?: "8") }
    var minute by remember(initial?.id) { mutableStateOf(initial?.minute?.toString()?.padStart(2, '0') ?: "00") }
    var days by remember(initial?.id) { mutableStateOf(initial?.days?.toSet() ?: setOf(1, 2, 3, 4, 5)) }
    var sound by remember(initial?.id) { mutableStateOf(initial?.soundId ?: "suave") }
    var notes by remember(initial?.id) { mutableStateOf(initial?.notes ?: "") }
    var error by remember { mutableStateOf<String?>(null) }
    var soundError by remember { mutableStateOf<String?>(null) }

    fun useUri(uri: Uri?) {
        if (uri == null) return
        val id = CustomSounds.import(context, uri)
        if (id != null) {
            sound = id
            soundError = null
            SoundPlayer.play(context, id)
        } else {
            soundError = "Não consegui usar esse som. Escolha um áudio de até 10 MB (mp3, m4a, ogg ou wav)."
        }
    }

    // Escolher um arquivo de áudio qualquer (Downloads, WhatsApp, Músicas...)
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> useUri(uri) }

    // Escolher entre os toques e sons de notificação do próprio celular
    val ringtonePicker = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        if (res.resultCode == Activity.RESULT_OK) {
            @Suppress("DEPRECATION")
            val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) {
                res.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI, Uri::class.java)
            } else {
                res.data?.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            }
            useUri(uri)
        }
    }

    GCard {
        Text("O que lembrar", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        GField("Título", title, { title = it }, "Ex.: Glicemia em jejum")
        FieldLabel("Tipo", 4)
        ChipRow(listOf("glicose" to "Medir glicose", "insulina" to "Aplicar insulina"), kind) { kind = it }
    }

    GCard(Modifier.padding(top = 12.dp)) {
        Text("Quando", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.weight(1f)) { GField("Hora (0-23)", hour, { hour = it.filter { c -> c.isDigit() }.take(2) }, "8", numeric = true) }
            Box(Modifier.weight(1f)) { GField("Minuto (0-59)", minute, { minute = it.filter { c -> c.isDigit() }.take(2) }, "00", numeric = true) }
        }
        FieldLabel("Dias da semana", 6)
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            WEEKDAYS.forEachIndexed { index, label ->
                val on = index in days
                Box(
                    Modifier
                        .weight(1f)
                        .heightIn(min = 44.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(if (on) g.violet else g.lilacSoft)
                        .clickable { days = if (on) days - index else days + index },
                    contentAlignment = Alignment.Center,
                ) {
                    Text(label, color = if (on) Color.White else g.ink, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("Todos os dias", g.violet, { days = (0..6).toSet() }, Modifier.weight(1f))
            PillButton("Dias úteis", g.violet, { days = setOf(1, 2, 3, 4, 5) }, Modifier.weight(1f))
        }
    }

    GCard(Modifier.padding(top = 12.dp)) {
        Text("Som do alerta", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Text("Toque em “Ouvir” para testar. Toca no volume do alarme.", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
        SOUND_PRESETS.forEach { preset ->
            SoundRow(
                selected = sound == preset.id,
                title = preset.name,
                subtitle = preset.description,
                onSelect = { sound = preset.id },
                onPlay = { SoundPlayer.play(context, preset.id) },
            )
        }
        if (isCustomSound(sound)) {
            SoundRow(
                selected = true,
                title = SoundPlayer.soundLabel(context, sound),
                subtitle = "Som escolhido por você",
                onSelect = {},
                onPlay = { SoundPlayer.play(context, sound) },
            )
        }
        FieldLabel("Usar outro som", 14)
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("📱 Sons do celular", g.violet, {
                try {
                    val i = Intent(RingtoneManager.ACTION_RINGTONE_PICKER).apply {
                        putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE, RingtoneManager.TYPE_ALL)
                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true)
                        putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, false)
                        putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Som do lembrete")
                    }
                    ringtonePicker.launch(i)
                } catch (_: Exception) {
                    soundError = "Este celular não abriu a lista de sons. Use “Meu áudio”."
                }
            }, Modifier.weight(1f))
            PillButton("📁 Meu áudio", g.violet, {
                try {
                    audioPicker.launch(arrayOf("audio/*"))
                } catch (_: Exception) {
                    soundError = "Não consegui abrir os arquivos do celular."
                }
            }, Modifier.weight(1f))
        }
        soundError?.let { Text(it, color = g.red, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
    }

    GCard(Modifier.padding(top = 12.dp)) {
        GField("Observações", notes, { notes = it }, "Opcional")
        error?.let { Text(it, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp)) }
        PrimaryButton(if (initial == null) "Salvar lembrete" else "Salvar alterações", g.violet, {
            val h = hour.toIntOrNull()
            val m = minute.toIntOrNull()
            error = when {
                title.isBlank() -> "Dê um título ao lembrete."
                days.isEmpty() -> "Escolha ao menos um dia."
                h == null || h !in 0..23 -> "Hora inválida."
                m == null || m !in 0..59 -> "Minuto inválido."
                else -> null
            }
            if (error == null && h != null && m != null) {
                onSave(Reminder(initial?.id ?: uid(), kind, title.trim(), h, m, days.sorted(), initial?.enabled ?: true, sound, notes.trim()))
            }
        }, Modifier.padding(top = 10.dp))
        PrimaryButton("Cancelar", g.muted, onCancel, Modifier.padding(top = 8.dp))
    }
}
