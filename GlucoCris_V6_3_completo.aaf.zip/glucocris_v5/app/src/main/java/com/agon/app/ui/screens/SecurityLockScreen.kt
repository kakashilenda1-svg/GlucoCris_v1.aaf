package com.agon.app.ui.screens

import android.os.SystemClock
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.repeatOnLifecycle
import com.agon.app.security.Availability
import com.agon.app.security.BiometricAuth
import com.agon.app.security.BiometricPolicy
import com.agon.app.security.EnrollmentWatch
import com.agon.app.security.SecurityViewModel
import com.agon.app.ui.theme.glucoColors

/**
 * Tela única mostrada enquanto a sessão está bloqueada: NÃO mostra nenhum dado do app e só sai daqui por autenticação
 * aprovada do Android (SecurityViewModel.onAuthSuccess). Cancelar, recusar ou errar mantém tudo bloqueado.
 *
 * O PIN do app só aparece como RECUPERAÇÃO quando a biometria do aparelho deixou de existir (removida, sem hardware,
 * sem suporte); nunca por cancelar, recusar ou bloqueio temporário, e com limite de tentativas.
 *
 * @param pinEnabled existe um PIN do app (mecanismo de recuperação já existente).
 * @param verifyPin confere o PIN digitado (e, se certo, libera a camada do PIN).
 * @param onApproved chamado quando a biometria foi aprovada (a biometria também cobre a camada do PIN).
 */
@Composable
fun SecurityLockScreen(
    security: SecurityViewModel,
    pinEnabled: Boolean = false,
    verifyPin: (String) -> Boolean = { false },
    onApproved: () -> Unit = {},
) {
    val g = glucoColors()
    val context = LocalContext.current
    val message by security.message.collectAsStateWithLifecycle()
    var availability by remember { mutableStateOf(BiometricAuth.availability(context)) }
    var pinText by remember { mutableStateOf("") }
    var pinMessage by remember { mutableStateOf("") }

    fun ask(auto: Boolean) {
        availability = BiometricAuth.availability(context)
        if (EnrollmentWatch.changedSinceArm() == true) security.showNotice(BiometricPolicy.enrollmentChangedMessage())
        if (!security.beginPrompt(auto)) return
        val shown = BiometricAuth.authenticate(
            context,
            title = "Gluco Cris ❤️",
            subtitle = "Confirme sua identidade para entrar",
            onSuccess = {
                EnrollmentWatch.arm()
                security.onAuthSuccess()
                onApproved()
            },
            onFailure = { security.onAuthFailure(it) },
        )
        if (!shown) security.onPromptNotShown()
    }

    // Pede a biometria sempre que a tela fica visível e ativa (uma vez por entrada; sem laço depois de cancelar).
    val owner = LocalLifecycleOwner.current
    LaunchedEffect(owner) {
        owner.lifecycle.repeatOnLifecycle(Lifecycle.State.RESUMED) { ask(auto = true) }
    }

    fun tryRecovery() {
        val now = SystemClock.elapsedRealtime()
        if (!security.canTryRecovery(now)) {
            pinMessage = "Muitas tentativas. Aguarde ${security.recoveryTriesLeftSeconds(now)} s."
            pinText = ""
            return
        }
        val allowed = BiometricPolicy.recoveryAllowed(pinEnabled, BiometricAuth.availability(context))
        val ok = allowed && verifyPin(pinText)
        pinText = ""
        if (security.onRecoveryAttempt(now, ok)) {
            pinMessage = ""
        } else {
            pinMessage = "PIN incorreto."
        }
    }

    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(g.heroStart, g.bg))).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Gluco Cris ❤️", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
        Text("Protegido por biometria", color = Color.White.copy(alpha = 0.9f), fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
        if (message.isNotBlank()) {
            Text(message, color = Color(0xFFFECACA), fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 18.dp))
        }
        if (availability != Availability.AVAILABLE) {
            Text(
                BiometricPolicy.availabilityMessage(availability),
                color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 10.dp),
            )
        }
        Text(
            "Desbloquear",
            color = Color.White,
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            modifier = Modifier
                .padding(top = 24.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color.White.copy(alpha = 0.2f))
                .clickable { ask(auto = false) }
                .padding(horizontal = 28.dp, vertical = 12.dp),
        )
        if (availability == Availability.NONE_ENROLLED || security.needsEnroll()) {
            Text(
                "Cadastrar biometria no Android",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 14.sp,
                modifier = Modifier
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.16f))
                    .clickable {
                        try { context.startActivity(BiometricAuth.enrollIntent()) } catch (_: Exception) { }
                    }
                    .padding(horizontal = 18.dp, vertical = 10.dp),
            )
        }
        if (BiometricPolicy.recoveryAllowed(pinEnabled, availability)) {
            Text(
                "A biometria deste aparelho não está disponível. Use o PIN do app para recuperar o acesso.",
                color = Color.White.copy(alpha = 0.9f), fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 22.dp),
            )
            Box(
                Modifier
                    .padding(top = 10.dp)
                    .fillMaxWidth(0.5f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(Color.White.copy(alpha = 0.16f))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                contentAlignment = Alignment.Center,
            ) {
                BasicTextField(
                    value = pinText,
                    onValueChange = { v ->
                        if (v.length <= 4 && v.all { it.isDigit() }) {
                            pinText = v
                            pinMessage = ""
                            if (v.length == 4) tryRecovery()
                        }
                    },
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 22.sp, textAlign = TextAlign.Center),
                    cursorBrush = SolidColor(Color.White),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            if (pinMessage.isNotBlank()) {
                Text(pinMessage, color = Color(0xFFFECACA), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
}
