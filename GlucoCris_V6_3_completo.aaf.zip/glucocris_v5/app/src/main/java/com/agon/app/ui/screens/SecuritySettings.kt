package com.agon.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.agon.app.security.AuthFailure
import com.agon.app.security.BiometricAuth
import com.agon.app.security.BiometricPolicy
import com.agon.app.security.EnableDecision
import com.agon.app.security.EnrollmentWatch
import com.agon.app.security.LegacyMigration
import com.agon.app.security.Modality
import com.agon.app.security.RelockPolicy
import com.agon.app.security.SecurityPrefs
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.theme.glucoColors

/**
 * Configurações → Segurança e privacidade → Bloqueio biométrico. É a ÚNICA configuração de biometria do app
 * (a antiga "Entrar com digital ou rosto" foi migrada para cá).
 *
 * Chave geral + impressão digital + reconhecimento facial + política ao voltar do segundo plano.
 * Honestidade sobre o Android: não existe API pública para aceitar SÓ a digital ou SÓ o rosto; o texto da tela diz isso e
 * mostra o aviso específico do aparelho (BiometricPolicy.limitation) em vez de prometer uma restrição que não existe.
 *
 * Ligar algo exige provar que a biometria funciona (evita ficar trancado); com a proteção já ativa, QUALQUER alteração exige
 * autenticação aprovada. Cancelar ou recusar não muda nada. Exceção: se a biometria do aparelho foi removida e a pessoa
 * entrou pelo PIN de recuperação, ela pode desligar/ajustar sem biometria (não há como autenticar).
 */
@Composable
fun SecurityPrivacySection(practice: Boolean, pinEnabled: Boolean) {
    val g = glucoColors()
    val context = LocalContext.current
    var flags by remember { mutableStateOf(SecurityPrefs.read(context)) }
    var message by remember { mutableStateOf("") }
    var needEnroll by remember { mutableStateOf(false) }
    var tick by remember { mutableStateOf(0) }
    var legacyNote by remember { mutableStateOf(SecurityPrefs.legacyNote(context)) }

    // Ao voltar das configurações do Android (cadastro de biometria), as informações de disponibilidade são lidas de novo.
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_RESUME) {
                tick += 1
                flags = SecurityPrefs.read(context)
                legacyNote = SecurityPrefs.legacyNote(context)
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    val avail = remember(tick) { BiometricAuth.availability(context) }
    val fpStatus = remember(tick) { BiometricAuth.fingerprintStatus(context) }
    val faceStatus = remember(tick) { BiometricAuth.faceStatus(context) }

    fun saveFlags(on: Boolean, fp: Boolean, face: Boolean, relock: RelockPolicy) {
        if (SecurityPrefs.write(context, on, fp, face, relock)) {
            flags = SecurityPrefs.read(context)
            val required = BiometricPolicy.protectionRequired(on, fp, face)
            if (required) {
                EnrollmentWatch.arm()
                SecurityPrefs.markSessionUnlocked(context)   // esta sessão já está autenticada
                SecurityPrefs.setLegacyNote(context, LegacyMigration.Note.NONE)
                legacyNote = LegacyMigration.Note.NONE
            }
            message = when {
                required -> "Bloqueio biométrico ativo."
                on -> "Nenhuma modalidade ligada: o app abre sem pedir biometria."
                else -> "Bloqueio biométrico desligado."
            }
        } else {
            message = "Não foi possível salvar a configuração. Nada foi alterado."
        }
    }

    /** O aparelho consegue a modalidade pedida? Se não, explica e não liga. */
    fun canTurnOn(modality: Modality?): Boolean {
        val hasSensor = when (modality) {
            Modality.FINGERPRINT -> fpStatus.hardware
            Modality.FACE -> faceStatus.hardware
            null -> fpStatus.hardware || faceStatus.hardware
        }
        val d = BiometricPolicy.canEnable(hasSensor, BiometricAuth.availability(context))
        if (d == EnableDecision.ALLOWED) return true
        message = BiometricPolicy.enableMessage(d, modality)
        needEnroll = d == EnableDecision.NEED_ENROLL
        return false
    }

    fun change(onWanted: Boolean, fpWanted: Boolean, faceWanted: Boolean, relock: RelockPolicy) {
        if (practice) { message = "Na simulação nada é alterado."; return }
        needEnroll = false
        val current = SecurityPrefs.read(context)
        // Ligar o geral sem nenhuma modalidade escolhida: liga as que o aparelho tem.
        if (onWanted && !current.enabled && !fpStatus.hardware && !faceStatus.hardware) {
            message = BiometricPolicy.enableMessage(EnableDecision.INCOMPATIBLE_DEVICE, null)
            return
        }
        var fp = fpWanted
        var face = faceWanted
        if (onWanted && !fp && !face && !current.enabled) {
            fp = fpStatus.hardware
            face = faceStatus.hardware
        }
        val willRequire = BiometricPolicy.protectionRequired(onWanted, fp, face)
        val turningOn = willRequire && !current.required
        if (turningOn || (willRequire && (fp && !current.fingerprint || face && !current.face))) {
            if (fp && !current.fingerprint && !canTurnOn(Modality.FINGERPRINT)) return
            if (face && !current.face && !canTurnOn(Modality.FACE)) return
            if (turningOn && !canTurnOn(null)) return
        }
        val recoveryMode = BiometricPolicy.recoveryAllowed(pinEnabled, BiometricAuth.availability(context))
        val needsAuth = (current.required || turningOn) && !(recoveryMode && !turningOn)
        if (!needsAuth) {
            saveFlags(onWanted, fp, face, relock)
            return
        }
        val started = BiometricAuth.authenticate(
            context,
            title = if (current.required) "Alterar segurança" else "Ativar bloqueio biométrico",
            subtitle = "Confirme com sua biometria",
            onSuccess = { saveFlags(onWanted, fp, face, relock) },
            onFailure = { f ->
                message = when (f) {
                    AuthFailure.CANCELED -> "Autenticação cancelada. Nada foi alterado."
                    AuthFailure.LOCKED_OUT -> "Muitas tentativas. Aguarde um pouco e tente de novo. Nada foi alterado."
                    AuthFailure.NOT_ENROLLED -> "Nenhuma biometria cadastrada. Cadastre nas configurações do Android. Nada foi alterado."
                    AuthFailure.UNAVAILABLE -> "Biometria indisponível agora. Nada foi alterado."
                    AuthFailure.OTHER -> "Não foi possível autenticar. Nada foi alterado."
                }
                needEnroll = f == AuthFailure.NOT_ENROLLED
            },
        )
        if (!started) message = "Já existe uma autenticação em andamento."
    }

    val fpText = when {
        !fpStatus.hardware -> "Este aparelho não tem leitor de digital."
        fpStatus.enrolled == true -> "Leitor presente e digital cadastrada."
        fpStatus.enrolled == false -> "Leitor presente, mas nenhuma digital cadastrada no Android."
        else -> "Leitor presente (o Android não informou se há digital cadastrada)."
    }
    val faceText = if (!faceStatus.hardware) {
        "Este aparelho não declara reconhecimento facial."
    } else {
        "Sensor de rosto presente. O Android não informa se há rosto cadastrado nem se ele é forte; só vale se for classificado como biometria forte."
    }
    val limitation = BiometricPolicy.limitation(fpStatus.hardware, faceStatus.hardware, flags.fingerprint, flags.face)

    SectionTitle("Segurança e privacidade")
    GCard {
        Text("Bloqueio biométrico", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Text(
            "Pede a biometria forte do Android em TODA nova abertura do Gluco Cris: app aberto de novo depois de fechado, " +
                "celular reiniciado ou app recriado pelo Android. Nenhuma imagem, impressão ou dado biométrico fica no app.",
            color = g.muted, fontSize = 12.sp,
        )
        ToggleRow(
            "Bloqueio biométrico",
            if (flags.required) "Ativo." else if (flags.enabled) "Ligado, mas sem modalidade escolhida: o app abre sem biometria." else "Desligado: o app abre sem pedir biometria.",
            flags.enabled,
        ) { change(it, flags.fingerprint, flags.face, flags.relock) }
        ToggleRow("Impressão digital", fpText, flags.fingerprint) { on ->
            change(flags.enabled || on, on, flags.face, flags.relock)
        }
        ToggleRow("Reconhecimento facial", faceText, flags.face) { on ->
            change(flags.enabled || on, flags.fingerprint, on, flags.relock)
        }

        Text("Disponibilidade no aparelho", color = g.ink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Text(BiometricPolicy.availabilityMessage(avail), color = g.muted, fontSize = 12.sp)
        Text(
            "Limitação do Android: não existe forma oficial de aceitar SÓ a digital ou SÓ o rosto. O sistema aceita qualquer " +
                "biometria FORTE cadastrada; as chaves acima dizem o que você quer usar e conferem se o aparelho oferece a modalidade, " +
                "mas só equivalem a uma restrição exata quando o aparelho tem apenas aquele sensor. Rosto classificado como fraco nunca é aceito.",
            color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
        )
        if (limitation != com.agon.app.security.Limitation.NONE) {
            Text(BiometricPolicy.limitationMessage(limitation), color = g.red, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }

        Text("Ao voltar do segundo plano", color = g.ink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        ChipRow(
            RelockPolicy.values().map { it.seconds.toString() to it.label },
            flags.relock.seconds.toString(),
        ) { id -> change(flags.enabled, flags.fingerprint, flags.face, RelockPolicy.fromSeconds(id.toIntOrNull())) }
        Text(
            "Só vale para minimizar e voltar. Abrir o app de novo (fechado, reiniciado ou recriado pelo Android) sempre pede biometria, " +
                "qualquer que seja esta escolha. Ao escolher 'Imediatamente', trocar para a câmera ou a galeria e voltar também pede.",
            color = g.muted, fontSize = 12.sp,
        )

        Text("Cadastrar ou trocar biometria", color = g.ink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
        Text(
            "Digital e rosto são cadastrados no Android (Configurações do aparelho → Segurança → Biometria). Se você remover ou trocar " +
                "as biometrias do aparelho, o Gluco Cris continua bloqueado até haver uma biometria forte (ou, se existir, o PIN do app como recuperação).",
            color = g.muted, fontSize = 12.sp,
        )
        Text(
            "Abrir as configurações de biometria do Android",
            color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            modifier = Modifier.padding(top = 6.dp).clickable {
                try { context.startActivity(BiometricAuth.enrollIntent()) } catch (_: Exception) { }
            },
        )

        when (legacyNote) {
            LegacyMigration.Note.MIGRATED ->
                Text("A antiga opção \"Entrar com digital ou rosto\" foi migrada para este Bloqueio biométrico.", color = g.violet, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            LegacyMigration.Note.NOT_MIGRATED_WEAK_OR_MISSING ->
                Text(
                    "A antiga opção \"Entrar com digital ou rosto\" foi desligada porque o aparelho não tem biometria forte cadastrada " +
                        "(ela aceitava biometria fraca). O PIN continua protegendo. Cadastre uma biometria forte e ligue o Bloqueio biométrico acima.",
                    color = g.red, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp),
                )
            else -> Unit
        }
        if (flags.tampered) {
            Text("A configuração de segurança não pôde ser verificada; a proteção foi mantida ligada por precaução.", color = g.red, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
        if (message.isNotBlank()) Text(message, color = g.violet, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        if (needEnroll) {
            Text(
                "Abrir configurações do Android para cadastrar biometria",
                color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.padding(top = 6.dp).clickable {
                    try { context.startActivity(BiometricAuth.enrollIntent()) } catch (_: Exception) { }
                },
            )
        }
    }
}

@Composable
private fun ToggleRow(title: String, desc: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val g = glucoColors()
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 10.dp)) {
            Text(title, color = g.ink, fontWeight = FontWeight.Bold)
            Text(desc, color = g.muted, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}
