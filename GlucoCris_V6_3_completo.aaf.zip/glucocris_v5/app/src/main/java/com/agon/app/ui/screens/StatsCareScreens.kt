package com.agon.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.INTENSITY_LABEL
import com.agon.app.data.MEAL_LABEL
import com.agon.app.data.Meal
import com.agon.app.data.Symptom
import com.agon.app.data.formatDate
import com.agon.app.data.formatDateTime
import com.agon.app.data.formatTime
import com.agon.app.data.fmtNum
import com.agon.app.data.parseDecimal
import com.agon.app.data.parseLocalDateTime
import com.agon.app.data.rangeStatus
import com.agon.app.data.toMgDl
import com.agon.app.data.uid
import com.agon.app.ui.components.BackTitle
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.ConfirmDialog
import com.agon.app.ui.components.EmptyState
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GField
import com.agon.app.ui.components.GlucoseChart
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.components.StatBar
import com.agon.app.ui.theme.glucoColors
import kotlin.math.roundToInt

@Composable
fun StatsScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    var days by remember { mutableIntStateOf(7) }
    val cutoff = System.currentTimeMillis() - days.toLong() * 86_400_000L
    val readings = data.glucose.filter { it.at >= cutoff }
    val mgs = readings.map { toMgDl(it.value, it.unit) }
    val low = data.settings.targetLow
    val high = data.settings.targetHigh
    val inRange = mgs.count { rangeStatus(it, low, high) == "ok" }
    val above = mgs.count { rangeStatus(it, low, high) == "high" }
    val below = mgs.count { rangeStatus(it, low, high) == "low" }
    val insulin = data.insulin.filter { it.at >= cutoff && it.kind == "aplicacao" }

    ScrollScreen {
        BackTitle("Estatísticas", { nav.popBackStack() })
        Text("Gráficos e estatísticas", color = g.muted, fontSize = 13.sp)
        ChipRow(listOf("7" to "7 dias", "14" to "14 dias", "30" to "30 dias", "90" to "90 dias"), days.toString()) { days = it.toInt() }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
            StatTile("Média", if (mgs.isEmpty()) "—" else mgs.average().roundToInt().toString(), "mg/dL", Modifier.weight(1f))
            StatTile("Na meta", if (mgs.isEmpty()) "—" else "${(inRange * 100.0 / mgs.size).roundToInt()}%", "do período", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth()) {
            StatTile("Mínima", if (mgs.isEmpty()) "—" else mgs.min().roundToInt().toString(), "mg/dL", Modifier.weight(1f))
            StatTile("Máxima", if (mgs.isEmpty()) "—" else mgs.max().roundToInt().toString(), "mg/dL", Modifier.weight(1f))
        }
        Text(
            "Leituras convertidas para mg/dL. A meta de $low–$high está em mg/dL.",
            color = g.muted,
            fontSize = 12.sp,
            modifier = Modifier.padding(top = 6.dp),
        )
        SectionTitle("Evolução")
        GCard { GlucoseChart(data.glucose, low, high, days) }
        SectionTitle("Tempo nas faixas")
        GCard {
            if (mgs.isEmpty()) Text("Sem dados neste período.", color = g.muted)
            else {
                StatBar("Dentro da meta", inRange.toFloat() / mgs.size, g.green, "$inRange")
                StatBar("Acima da meta", above.toFloat() / mgs.size, g.red, "$above")
                StatBar("Abaixo da meta", below.toFloat() / mgs.size, g.orange, "$below")
                Text("${mgs.size} medições no período", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
        SectionTitle("Média por contexto")
        GCard {
            val grouped = readings.groupBy { it.context }
            if (grouped.isEmpty()) Text("Sem dados neste período.", color = g.muted)
            grouped.forEach { (ctx, list) ->
                val avg = list.map { toMgDl(it.value, it.unit) }.average().roundToInt()
                Text("${GLUCOSE_CONTEXT_LABEL[ctx] ?: ctx}: $avg mg/dL · ${list.size}", color = g.ink, fontSize = 14.sp, modifier = Modifier.padding(vertical = 3.dp))
            }
        }
        SectionTitle("Insulina no período")
        GCard {
            if (insulin.isEmpty()) Text("Sem registros de insulina", color = g.muted)
            else {
                Text("${insulin.size} aplicações", color = g.ink, fontWeight = FontWeight.Bold)
                Text("Soma registrada: ${fmtNum(insulin.sumOf { it.dose })} UI", color = g.muted, fontSize = 13.sp)
            }
            Text("Período a partir de ${formatDate(cutoff)}", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
fun StatTile(label: String, value: String, unit: String, modifier: Modifier) {
    val g = glucoColors()
    GCard(modifier.padding(4.dp)) {
        Text(label, color = g.muted, fontSize = 12.sp)
        Text(value, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        Text(unit, color = g.muted, fontSize = 11.sp)
    }
}

@Composable
fun CareScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    var mealType by remember { mutableStateOf("almoco") }
    var mealDesc by remember { mutableStateOf("") }
    var mealCarbs by remember { mutableStateOf("") }
    var mealDate by remember { mutableStateOf(formatDate(System.currentTimeMillis())) }
    var mealTime by remember { mutableStateOf(formatTime(System.currentTimeMillis())) }
    var mealError by remember { mutableStateOf<String?>(null) }
    var symptomName by remember { mutableStateOf("") }
    var intensity by remember { mutableStateOf("leve") }
    var symptomNotes by remember { mutableStateOf("") }
    var symptomError by remember { mutableStateOf<String?>(null) }
    var confirmMeal by remember { mutableStateOf<String?>(null) }
    var confirmSymptom by remember { mutableStateOf<String?>(null) }

    ScrollScreen {
        BackTitle("Alimentação e sintomas", { nav.popBackStack() })
        Text("Registros opcionais para conversar com a equipe de saúde. Não substituem o diário de glicose.", color = g.muted, fontSize = 13.sp)
        SectionTitle("Refeição")
        GCard {
            ChipRow(MEAL_LABEL.entries.map { it.key to it.value }.take(3), mealType) { mealType = it }
            ChipRow(MEAL_LABEL.entries.map { it.key to it.value }.drop(3), mealType) { mealType = it }
            GField("O que comeu", mealDesc, { mealDesc = it }, "Ex.: sopa e torrada")
            GField("Carboidratos (g, opcional)", mealCarbs, { mealCarbs = it }, "Ex.: 40", numeric = true)
            GField("Data", mealDate, { mealDate = it }, "dd/mm/aaaa")
            GField("Horário", mealTime, { mealTime = it }, "hh:mm")
            mealError?.let { Text(it, color = g.red, fontSize = 13.sp) }
            PrimaryButton("Salvar refeição", g.orange, {
                val at = parseLocalDateTime(mealDate, mealTime)
                val carbs = if (mealCarbs.isBlank()) null else parseDecimal(mealCarbs)
                mealError = when {
                    mealDesc.isBlank() -> "Descreva a refeição em poucas palavras."
                    at == null -> "Data ou horário da refeição inválidos."
                    mealCarbs.isNotBlank() && (carbs == null || carbs !in 0.0..400.0) -> "Carboidratos devem ficar entre 0 e 400 g."
                    else -> null
                }
                if (mealError == null && at != null) {
                    vm.saveMeal(Meal(uid(), mealType, mealDesc.trim(), carbs, at, ""))
                    mealDesc = ""
                    mealCarbs = ""
                }
            }, Modifier.padding(top = 8.dp))
        }
        data.meals.sortedByDescending { it.at }.forEach { m ->
            GCard(Modifier.padding(top = 8.dp)) {
                Text(MEAL_LABEL[m.type] ?: m.type, color = g.ink, fontWeight = FontWeight.ExtraBold)
                Text(m.description, color = g.ink, fontSize = 14.sp)
                Text(formatDateTime(m.at) + (m.carbs?.let { " · ${fmtNum(it)} g carb." } ?: ""), color = g.muted, fontSize = 12.sp)
                Text("Excluir", color = g.red, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { confirmMeal = m.id }.padding(top = 4.dp))
            }
        }
        SectionTitle("Sintoma")
        GCard {
            GField("Sintoma", symptomName, { symptomName = it }, "Ex.: tontura, sede, tremor")
            ChipRow(INTENSITY_LABEL.entries.map { it.key to it.value }, intensity) { intensity = it }
            GField("Observação", symptomNotes, { symptomNotes = it }, "Opcional")
            symptomError?.let { Text(it, color = g.red, fontSize = 13.sp) }
            PrimaryButton("Salvar", g.violet, {
                symptomError = if (symptomName.isBlank()) "Informe o sintoma." else null
                if (symptomError == null) {
                    vm.saveSymptom(Symptom(uid(), symptomName.trim(), intensity, System.currentTimeMillis(), symptomNotes.trim()))
                    symptomName = ""
                    symptomNotes = ""
                }
            }, Modifier.padding(top = 8.dp))
        }
        data.symptoms.sortedByDescending { it.at }.forEach { s ->
            GCard(Modifier.padding(top = 8.dp)) {
                Text(s.name, color = g.ink, fontWeight = FontWeight.ExtraBold)
                Text("${INTENSITY_LABEL[s.intensity] ?: s.intensity} · ${formatDateTime(s.at)}", color = g.muted, fontSize = 12.sp)
                if (s.notes.isNotBlank()) Text(s.notes, color = g.ink, fontSize = 13.sp)
                Text("Excluir", color = g.red, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { confirmSymptom = s.id }.padding(top = 4.dp))
            }
        }
    }
    confirmMeal?.let { id ->
        ConfirmDialog("Excluir refeição", "Esta ação não pode ser desfeita.", "Excluir", { vm.deleteMeal(id); confirmMeal = null }) { confirmMeal = null }
    }
    confirmSymptom?.let { id ->
        ConfirmDialog("Excluir", "Esta ação não pode ser desfeita.", "Excluir", { vm.deleteSymptom(id); confirmSymptom = null }) { confirmSymptom = null }
    }
}
