package com.agon.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.agon.app.localai.ServiceProbe
import com.agon.app.localai.ServiceState
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * Diagnóstico do sistema (V6.1) — executa verificações reais e independentes via [ServiceProbe].
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SystemDiagnosisScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var checking by remember { mutableStateOf(false) }
    var results by remember { mutableStateOf(ServiceProbe.lastResults) }
    var errorNote by remember { mutableStateOf<String?>(null) }

    fun label(s: ServiceState): String = when (s) {
        ServiceState.OK -> "Funcionando"
        ServiceState.QUOTA -> "Limite de utilização atingido"
        ServiceState.NOT_CONFIGURED -> "Sem configuração"
        ServiceState.UNAVAILABLE -> "Indisponível"
        ServiceState.UNKNOWN -> "Estado desconhecido"
    }

    fun timeLabel(at: Long?): String {
        if (at == null || at <= 0L) return "—"
        return SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale("pt", "BR")).format(Date(at))
    }

    fun runCheck(force: Boolean = true) {
        if (checking) return
        checking = true
        errorNote = null
        scope.launch {
            try {
                results = ServiceProbe.runAll(ctx, force = force)
            } catch (e: Exception) {
                errorNote = "Falha ao verificar: ${e.message?.take(80) ?: "erro"}"
            } finally {
                checking = false
            }
        }
    }

    LaunchedEffect(Unit) {
        if (results.isEmpty()) runCheck(force = true)
        else results = ServiceProbe.lastResults
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Diagnóstico do sistema") },
                navigationIcon = { TextButton(onClick = onBack) { Text("←") } },
            )
        },
    ) { padding ->
        Column(
            Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            Text(
                "Estados baseados em verificações reais. Um serviço só aparece como “funcionando” " +
                    "quando há evidência recente de resposta.",
                style = MaterialTheme.typography.bodyMedium,
            )

            val order = listOf(
                ServiceProbe.Kind.INTERNET to "Conectividade com a internet",
                ServiceProbe.Kind.WORKER to "Cloudflare Worker",
                ServiceProbe.Kind.GEMINI to "Gemini (IA online)",
                ServiceProbe.Kind.TAVILY to "Tavily (pesquisa web)",
                ServiceProbe.Kind.LOCAL_AI to "IA local",
                ServiceProbe.Kind.BACKUP to "Backup e sincronização",
            )
            for ((kind, title) in order) {
                val r = results[kind]
                ServiceCard(
                    title = title,
                    status = if (r == null) (if (checking) "Conectando…" else "Estado desconhecido") else label(r.state),
                    message = r?.message ?: "Aguardando verificação",
                    lastCheck = timeLabel(r?.checkedAt),
                    lastOk = timeLabel(r?.lastOkAt),
                    lastError = r?.lastError,
                    latency = r?.latencyMs?.let { "${it} ms" },
                )
            }

            errorNote?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }

            Button(
                onClick = { runCheck(force = true) },
                enabled = !checking,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Text(if (checking) "Verificando serviços…" else "Verificar serviços agora")
            }

            Text(
                "As verificações usam timeout individual, não bloqueiam a tela e evitam chamadas repetidas em poucos segundos. " +
                    "Gemini usa um ping leve; a pesquisa Tavily não dispara consulta completa só para diagnóstico (poupa cota). " +
                    "Nenhuma chave ou dado de saúde é exibido.",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

@Composable
private fun ServiceCard(
    title: String,
    status: String,
    message: String,
    lastCheck: String,
    lastOk: String,
    lastError: String?,
    latency: String?,
) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text("Status: $status")
            Text(message, style = MaterialTheme.typography.bodySmall)
            Text("Última verificação: $lastCheck", style = MaterialTheme.typography.bodySmall)
            Text("Último funcionamento: $lastOk", style = MaterialTheme.typography.bodySmall)
            if (latency != null) Text("Tempo de resposta: $latency", style = MaterialTheme.typography.bodySmall)
            if (!lastError.isNullOrBlank()) Text("Último erro: $lastError", style = MaterialTheme.typography.bodySmall)
        }
    }
}
