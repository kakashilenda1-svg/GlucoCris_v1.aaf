package com.agon.app.ui.screens

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GlucoViewModel
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.animation.core.FastOutLinearInEasing
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.ui.graphics.graphicsLayer
import com.agon.app.data.PracticeMode
import com.agon.app.data.toMgDl
import com.agon.app.reminders.ReminderScheduler
import com.agon.app.reminders.WaterAlert
import com.agon.app.ui.components.tourTarget
import kotlinx.coroutines.Job
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.sin
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.Switch
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.StrokeCap
import com.agon.app.ui.components.GCard
import com.agon.app.ui.theme.GlucoColors

private val WaterBlue = Color(0xFF0EA5E9)
private val WaterBlueDeep = Color(0xFF0284C7)
private val WaterBlueSoft = Color(0xFFBAE6FD)
private val WaterBlueBg = Color(0xFF0C4A6E)
private val WaterSurface = Color(0xFFE0F2FE)

data class WaterCupPreset(val ml: Int, val label: String, val kind: String)
data class WaterEntry(val id: String, val ml: Int, val at: Long, val kind: String)

private val CUP_PRESETS = listOf(
    WaterCupPreset(150, "150 ml", "tea"),
    WaterCupPreset(200, "200 ml", "glass"),
    WaterCupPreset(250, "250 ml", "glass"),
    WaterCupPreset(300, "300 ml", "glass"),
    WaterCupPreset(400, "400 ml", "cup"),
    WaterCupPreset(500, "500 ml", "bottle"),
    WaterCupPreset(600, "600 ml", "bottle"),
    WaterCupPreset(700, "700 ml", "bottle"),
    WaterCupPreset(800, "800 ml", "bottle"),
    WaterCupPreset(1000, "1 L", "bottle"),
)

private const val WATER_PREFS = "gluco_water_v1"
private const val KEY_GOAL = "goal_ml"
private const val KEY_ENTRIES = "entries_json"

private const val KEY_FAV_CUPS = "fav_cups"
private const val KEY_SOUNDS = "sounds_on"
private const val KEY_HEAT_DAY = "heat_day"
private const val KEY_HEAT_ON = "heat_on"
private const val KEY_LAST_REMIND = "last_remind_at"
private const val KEY_ASK_MEAL = "ask_after_meal"
private const val KEY_REMIND_HOURS = "remind_hours"
private const val HEAT_BONUS_ML = 400

fun waterSoundsOn(ctx: Context): Boolean =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SOUNDS, true)

fun setWaterSoundsOn(ctx: Context, on: Boolean) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_SOUNDS, on).apply()
}

fun loadFavCups(ctx: Context): List<Int> {
    val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE)
        .getString(KEY_FAV_CUPS, "250,300,500") ?: "250,300,500"
    return raw.split(",").mapNotNull { it.trim().toIntOrNull() }.filter { it in 50..2000 }.distinct().take(4)
}

fun saveFavCups(ctx: Context, list: List<Int>) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putString(KEY_FAV_CUPS, list.distinct().take(4).joinToString(",")).apply()
}

fun toggleFavCup(ctx: Context, ml: Int) {
    val cur = loadFavCups(ctx).toMutableList()
    if (ml in cur) cur.remove(ml) else {
        if (cur.size >= 4) cur.removeAt(0)
        cur.add(ml)
    }
    saveFavCups(ctx, cur)
}

fun isHeatModeToday(ctx: Context): Boolean {
    val p = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE)
    return p.getBoolean(KEY_HEAT_ON, false) && p.getString(KEY_HEAT_DAY, "") == dayKey()
}

fun setHeatModeToday(ctx: Context, on: Boolean) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putBoolean(KEY_HEAT_ON, on).putString(KEY_HEAT_DAY, dayKey()).apply()
}

fun effectiveWaterGoal(ctx: Context): Int {
    val base = loadWaterGoal(ctx)
    return if (isHeatModeToday(ctx)) base + HEAT_BONUS_ML else base
}

fun suggestedWaterGoalMl(weightKg: String?): Int? {
    val w = weightKg?.replace(",", ".")?.toDoubleOrNull() ?: return null
    if (w < 30 || w > 250) return null
    return (w * 35.0).toInt().coerceIn(1500, 4500)
}

fun waterMorningLow(ctx: Context): Boolean {
    val entries = loadWaterEntries(ctx)
    val morning = entries.filter {
        val c = Calendar.getInstance().apply { timeInMillis = it.at }
        c.get(Calendar.HOUR_OF_DAY) < 12
    }.sumOf { it.ml }
    val goal = effectiveWaterGoal(ctx)
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return hour >= 12 && morning < (goal * 0.25)
}

fun waterRemindHours(ctx: Context): Int =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getInt(KEY_REMIND_HOURS, 2).coerceIn(1, 6)

fun setWaterRemindHours(ctx: Context, h: Int) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_REMIND_HOURS, h.coerceIn(1, 6)).apply()
}

fun shouldSoftWaterRemind(ctx: Context): Boolean {
    val total = waterTodayTotal(ctx)
    val goal = effectiveWaterGoal(ctx)
    if (total >= goal) return false
    val last = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getLong(KEY_LAST_REMIND, 0L)
    val gap = waterRemindHours(ctx) * 60L * 60L * 1000L
    return System.currentTimeMillis() - last > gap
}

fun markWaterReminded(ctx: Context) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putLong(KEY_LAST_REMIND, System.currentTimeMillis()).apply()
}

fun askWaterAfterMeal(ctx: Context): Boolean =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ASK_MEAL, true)

fun setAskWaterAfterMeal(ctx: Context, on: Boolean) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ASK_MEAL, on).apply()
}

fun waterInsightLine(ctx: Context): String? {
    val total = waterTodayTotal(ctx)
    val goal = effectiveWaterGoal(ctx)
    if (total >= goal) return "Meta batida hoje — lembretes suaves em silêncio."
    if (waterMorningLow(ctx)) return "Pouco de manhã no histórico de hoje. Que tal um copo agora?"
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    if (hour in 14..17 && total < goal * 0.5) return "Tarde: ainda abaixo da metade da meta."
    if (shouldSoftWaterRemind(ctx)) return "Lembrete suave: ainda falta água para a meta."
    return null
}

fun waterMood(progress: Float): Int = when {
    progress >= 1f -> 2
    progress >= 0.5f -> 1
    else -> 0
}

fun waterWeekTotal(ctx: Context): Int {
    return try {
        val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getString(KEY_ENTRIES, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val cutoff = System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000
        (0 until arr.length()).sumOf { i ->
            val o = arr.getJSONObject(i)
            val at = o.optLong("at")
            if (at >= cutoff) o.optInt("ml") else 0
        }
    } catch (_: Exception) { 0 }
}


private fun dayKey(ts: Long = System.currentTimeMillis()): String {
    val c = Calendar.getInstance().apply { timeInMillis = ts }
    return "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
}

fun loadWaterGoal(ctx: Context): Int =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getInt(KEY_GOAL, 2000)

fun saveWaterGoal(ctx: Context, ml: Int) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putInt(KEY_GOAL, ml.coerceIn(500, 8000)).apply()
}

fun loadWaterEntries(ctx: Context): List<WaterEntry> {
    return try {
        val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getString(KEY_ENTRIES, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val today = dayKey()
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val at = o.optLong("at")
            if (dayKey(at) != today) return@mapNotNull null
            WaterEntry(o.optString("id"), o.optInt("ml"), at, o.optString("kind", "glass"))
        }.sortedByDescending { it.at }
    } catch (_: Exception) {
        emptyList()
    }
}

fun saveWaterEntries(ctx: Context, list: List<WaterEntry>) {
    // keep today + last 7 days
    val cutoff = System.currentTimeMillis() - 8L * 24 * 60 * 60 * 1000
    val allRaw = try {
        val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getString(KEY_ENTRIES, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val old = (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val at = o.optLong("at")
            if (at < cutoff) null else WaterEntry(o.optString("id"), o.optInt("ml"), at, o.optString("kind", "glass"))
        }
        val today = dayKey()
        old.filter { dayKey(it.at) != today } + list
    } catch (_: Exception) {
        list
    }
    val arr = JSONArray()
    allRaw.forEach { e ->
        arr.put(JSONObject().put("id", e.id).put("ml", e.ml).put("at", e.at).put("kind", e.kind))
    }
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ENTRIES, arr.toString()).apply()
}

fun waterTodayTotal(ctx: Context): Int = loadWaterEntries(ctx).sumOf { it.ml }


// ───────── Relógio inteligente da água (horários editáveis + lembretes) ─────────

private const val KEY_CLOCK_TIMES = "clock_times"
private const val KEY_CLOCK_ON = "clock_on"
private const val KEY_CLOCK_IDS = "clock_scheduled_ids"

fun waterGoalMet(ctx: Context): Boolean = waterTodayTotal(ctx) >= effectiveWaterGoal(ctx)

fun waterClockOn(ctx: Context): Boolean =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getBoolean(KEY_CLOCK_ON, false)

private fun parseClock(t: String): Pair<Int, Int>? {
    val p = t.split(":")
    if (p.size != 2) return null
    val h = p[0].toIntOrNull() ?: return null
    val m = p[1].toIntOrNull() ?: return null
    return if (h in 0..23 && m in 0..59) h to m else null
}

fun defaultWaterClockTimes(hours: Int): List<String> {
    val step = hours.coerceIn(1, 6)
    return generateSequence(8) { it + step }.takeWhile { it <= 20 }.map { "%02d:00".format(it) }.toList()
}

fun loadWaterClockTimes(ctx: Context): List<String> {
    val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getString(KEY_CLOCK_TIMES, null)
    return if (raw == null) defaultWaterClockTimes(waterRemindHours(ctx))
    else raw.split(",").filter { parseClock(it) != null }
}

fun saveWaterClockTimes(ctx: Context, list: List<String>) {
    val clean = list.filter { parseClock(it) != null }.distinct().sorted().take(24)
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putString(KEY_CLOCK_TIMES, clean.joinToString(",")).apply()
    syncWaterClock(ctx)
}

fun setWaterClockOn(ctx: Context, on: Boolean) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_CLOCK_ON, on).apply()
    syncWaterClock(ctx)
}

/** Agenda (ou cancela) os alarmes do relógio de água. Não faz nada durante a simulação do tour. */
fun syncWaterClock(ctx: Context) {
    if (PracticeMode.active) return
    val app = ctx.applicationContext
    val p = app.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE)
    p.getString(KEY_CLOCK_IDS, "")?.split(",")?.filter { it.isNotBlank() }?.forEach { ReminderScheduler.cancel(app, it) }
    val ids = mutableListOf<String>()
    if (p.getBoolean(KEY_CLOCK_ON, false)) {
        loadWaterClockTimes(app).forEach { t ->
            val hm = parseClock(t) ?: return@forEach
            val id = "agua_" + t.replace(":", "")
            ReminderScheduler.schedule(
                app, id, "agua", "Hora de beber água 💧", hm.first, hm.second,
                listOf(0, 1, 2, 3, 4, 5, 6), "claro", "Beba um copo de água.",
            )
            ids.add(id)
        }
    }
    p.edit().putString(KEY_CLOCK_IDS, ids.joinToString(",")).apply()
}

// ───────── Cris Hidrata · visual leve, moderno e que acompanha o tema ─────────

/** Risadinha sintetizada (sem arquivo de áudio): "hi-hi-hi" com variação a cada toque. */
private fun playDropGiggle(ctx: Context) {
    if (!waterSoundsOn(ctx)) return
    Thread {
        try {
            val sr = 22050
            val variant = (Math.abs(System.nanoTime()) % 3).toInt()
            val bursts = 4 + variant
            val base = doubleArrayOf(620.0, 700.0, 780.0)[variant]
            val burstN = sr * 85 / 1000
            val gapN = sr * 45 / 1000
            val samples = ShortArray(bursts * (burstN + gapN) + 1)
            var idx = 0
            var phase = 0.0
            for (b in 0 until bursts) {
                val f0 = base * (1.0 + 0.06 * b) * (if (b % 2 == 0) 1.0 else 0.92)
                for (i in 0 until burstN) {
                    val tt = i / burstN.toDouble()
                    val f = f0 * (1.0 + 0.35 * (1.0 - tt))
                    phase += 2.0 * Math.PI * f / sr
                    val env = Math.pow(Math.sin(Math.PI * tt), 0.6)
                    val v = (Math.sin(phase) + 0.35 * Math.sin(2.0 * phase)) * env * 0.5
                    samples[idx++] = (v * Short.MAX_VALUE).toInt().toShort()
                }
                idx += gapN
            }
            val track = android.media.AudioTrack.Builder()
                .setAudioAttributes(
                    android.media.AudioAttributes.Builder()
                        .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                        .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build(),
                )
                .setAudioFormat(
                    android.media.AudioFormat.Builder()
                        .setEncoding(android.media.AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sr)
                        .setChannelMask(android.media.AudioFormat.CHANNEL_OUT_MONO)
                        .build(),
                )
                .setBufferSizeInBytes(samples.size * 2)
                .setTransferMode(android.media.AudioTrack.MODE_STATIC)
                .build()
            track.write(samples, 0, samples.size)
            track.play()
            Thread.sleep((samples.size * 1000L / sr) + 150L)
            track.release()
        } catch (_: Exception) {
        }
    }.start()
}

/** Gotinha: ao tocar, dança, ri e sorri (squash/stretch, pulinhos, giro e brilhos). mood: 0 triste, 1 normal, 2 festa. */
@Composable
private fun CrisDrop(mood: Int, modifier: Modifier = Modifier) {
    val g = glucoColors()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val rot = remember { Animatable(0f) }
    val hop = remember { Animatable(0f) }
    val squash = remember { Animatable(1f) }
    val sparkle = remember { Animatable(1f) }
    val arms = remember { Animatable(0f) }      // 0 = bracinhos baixos/escondidos, 1 = levantados
    val redness = remember { Animatable(0f) }   // 0 = cor normal, 1 = bem vermelha
    var redTarget by remember { mutableFloatStateOf(0f) }
    var coolJob by remember { mutableStateOf<Job?>(null) }
    var happy by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }
    val body = g.blue
    Box(
        modifier
            .graphicsLayer {
                rotationZ = rot.value
                translationY = hop.value * size.height
                scaleY = squash.value
                scaleX = 2f - squash.value
            }
            .clip(CircleShape)
            .clickable {
                playDropGiggle(ctx)
                val target = (maxOf(redTarget, redness.value) + 0.1f).coerceAtMost(1f)
                redTarget = target
                coolJob?.cancel()
                job?.cancel()
                job = scope.launch {
                    happy = true
                    launch {
                        redness.animateTo(target, tween(1600, easing = LinearEasing))
                    }
                    launch { arms.animateTo(1f, tween(220, easing = FastOutSlowInEasing)) }
                    launch {
                        sparkle.snapTo(0f)
                        sparkle.animateTo(1f, tween(1400, easing = LinearEasing))
                    }
                    launch {
                        squash.animateTo(0.8f, tween(70))
                        squash.animateTo(1.15f, spring(dampingRatio = 0.3f, stiffness = Spring.StiffnessMedium))
                        squash.animateTo(1f, spring(dampingRatio = 0.5f))
                    }
                    launch {
                        repeat(4) {
                            hop.animateTo(-0.18f, tween(110, easing = FastOutSlowInEasing))
                            hop.animateTo(0f, tween(110, easing = FastOutLinearInEasing))
                        }
                    }
                    repeat(4) {
                        rot.animateTo(15f, tween(120))
                        rot.animateTo(-15f, tween(120))
                    }
                    rot.animateTo(0f, spring(dampingRatio = 0.5f))
                    delay(300)
                    happy = false
                    arms.animateTo(0f, tween(350))
                }
                // parou de clicar: depois de um instante, o vermelho some devagar até voltar ao azul
                coolJob = scope.launch {
                    delay(2500)
                    redTarget = 0f
                    redness.animateTo(
                        0f,
                        tween((6000 * redness.value).toInt().coerceAtLeast(800), easing = LinearEasing),
                    )
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val ink = Color(0xFF0F172A)
            val drop = Path().apply {
                moveTo(w * 0.5f, h * 0.04f)
                cubicTo(w * 0.5f, h * 0.04f, w * 0.92f, h * 0.46f, w * 0.92f, h * 0.64f)
                cubicTo(w * 0.92f, h * 0.84f, w * 0.74f, h * 0.96f, w * 0.5f, h * 0.96f)
                cubicTo(w * 0.26f, h * 0.96f, w * 0.08f, h * 0.84f, w * 0.08f, h * 0.64f)
                cubicTo(w * 0.08f, h * 0.46f, w * 0.5f, h * 0.04f, w * 0.5f, h * 0.04f)
                close()
            }
            val bodyNow = androidx.compose.ui.graphics.lerp(body, Color(0xFFD32F2F), redness.value)
            // bracinhos levantados (só aparecem durante o toque)
            if (arms.value > 0.01f) {
                val ang = Math.toRadians((160.0 * arms.value))
                val armLen = w * 0.22f
                for (side in floatArrayOf(-1f, 1f)) {
                    val sx = w * (0.5f + side * 0.36f)
                    val sy = h * 0.64f
                    val ex = sx + side * Math.sin(ang).toFloat() * armLen
                    val ey = sy + Math.cos(ang).toFloat() * armLen
                    drawLine(bodyNow, Offset(sx, sy), Offset(ex, ey), strokeWidth = w * 0.07f, cap = StrokeCap.Round)
                    drawCircle(bodyNow, w * 0.05f, Offset(ex, ey))
                }
            }
            drawPath(drop, Brush.verticalGradient(listOf(bodyNow.copy(alpha = 0.75f), bodyNow)))
            val eyeR = w * 0.055f
            if (happy) {
                // olhinhos felizes ^ ^
                for (ex in floatArrayOf(0.38f, 0.62f)) {
                    val eye = Path().apply {
                        moveTo(w * ex - eyeR * 1.3f, h * 0.62f)
                        quadraticTo(w * ex, h * 0.62f - eyeR * 2.6f, w * ex + eyeR * 1.3f, h * 0.62f)
                    }
                    drawPath(eye, Color.White, style = Stroke(width = w * 0.04f, cap = StrokeCap.Round))
                }
                drawCircle(Color(0xFFFF8FB1).copy(alpha = 0.55f), w * 0.05f, Offset(w * 0.27f, h * 0.7f))
                drawCircle(Color(0xFFFF8FB1).copy(alpha = 0.55f), w * 0.05f, Offset(w * 0.73f, h * 0.7f))
                val mouth = Path().apply {
                    moveTo(w * 0.36f, h * 0.72f)
                    quadraticTo(w * 0.5f, h * 1.0f, w * 0.64f, h * 0.72f)
                    close()
                }
                drawPath(mouth, ink)
                drawCircle(Color(0xFFFF8FB1), w * 0.045f, Offset(w * 0.5f, h * 0.83f))
                val t = sparkle.value
                if (t < 1f) {
                    for (i in 0 until 4) {
                        val ang = i * 1.5708f + 0.6f
                        val rad = w * (0.30f + 0.14f * t)
                        val cx = w * 0.5f + Math.cos(ang.toDouble()).toFloat() * rad
                        val cy = h * 0.45f + Math.sin(ang.toDouble()).toFloat() * rad - t * h * 0.12f
                        drawCircle(Color(0xFFFFD54F).copy(alpha = 1f - t), w * 0.05f, Offset(cx, cy))
                    }
                }
            } else {
                drawCircle(Color.White, eyeR, Offset(w * 0.38f, h * 0.6f))
                drawCircle(Color.White, eyeR, Offset(w * 0.62f, h * 0.6f))
                drawCircle(ink, eyeR * 0.5f, Offset(w * 0.38f, h * 0.61f))
                drawCircle(ink, eyeR * 0.5f, Offset(w * 0.62f, h * 0.61f))
                val d = when (mood) { 2 -> 0.11f; 1 -> 0.06f; else -> -0.05f }
                val mouth = Path().apply {
                    moveTo(w * 0.4f, h * 0.76f)
                    quadraticTo(w * 0.5f, h * (0.76f + d), w * 0.6f, h * 0.76f)
                }
                drawPath(mouth, ink, style = Stroke(width = w * 0.035f, cap = StrokeCap.Round))
            }
        }
    }
}

@Composable
private fun WaterRing(progress: Float, total: Int, goal: Int, done: Boolean, g: GlucoColors) {
    val anim by animateFloatAsState(progress.coerceIn(0f, 1f), tween(500), label = "ring")
    val ringColor = if (done) g.green else g.blue
    val track = g.blueSoft
    Box(Modifier.size(148.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = 16.dp.toPx()
            val inset = stroke / 2f
            val arc = Size(size.width - stroke, size.height - stroke)
            drawArc(
                color = track, startAngle = -90f, sweepAngle = 360f, useCenter = false,
                topLeft = Offset(inset, inset), size = arc, style = Stroke(stroke, cap = StrokeCap.Round),
            )
            if (anim > 0.001f) {
                drawArc(
                    color = ringColor, startAngle = -90f, sweepAngle = 360f * anim, useCenter = false,
                    topLeft = Offset(inset, inset), size = arc, style = Stroke(stroke, cap = StrokeCap.Round),
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$total", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp)
            Text("de $goal ml", color = g.muted, fontSize = 12.sp)
            Text("${(progress * 100).toInt().coerceAtMost(999)}%", color = ringColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val g = glucoColors()
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = g.ink, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun CupPill(
    preset: WaterCupPreset,
    fav: Boolean,
    onAdd: () -> Unit,
    onToggleFav: () -> Unit,
) {
    val g = glucoColors()
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .width(86.dp)
            .clip(shape)
            .background(if (fav) g.blueSoft else g.card)
            .border(1.dp, if (fav) g.blue.copy(alpha = 0.5f) else g.line, shape)
            .clickable(onClick = onAdd)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Icon(
                if (fav) Icons.Filled.Star else Icons.Outlined.StarBorder,
                contentDescription = if (fav) "Tirar dos favoritos" else "Favoritar",
                tint = if (fav) g.orange else g.muted,
                modifier = Modifier.size(20.dp).clip(CircleShape).clickable(onClick = onToggleFav),
            )
        }
        Box(Modifier.height(56.dp), contentAlignment = Alignment.BottomCenter) {
            Box(
                Modifier
                    .size(width = (20f + preset.ml * 0.012f).dp, height = (22f + preset.ml * 0.03f).dp)
                    .clip(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp, bottomStart = 11.dp, bottomEnd = 11.dp))
                    .background(Brush.verticalGradient(listOf(g.blue.copy(alpha = 0.3f), g.blue))),
            )
        }
        Text(preset.label, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        Text("＋ adicionar", color = g.blue, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun WaterMiniBar(visible: Boolean, onOpenFull: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val g = glucoColors()
    var goal by remember { mutableIntStateOf(effectiveWaterGoal(ctx)) }
    var entries by remember { mutableStateOf(loadWaterEntries(ctx)) }
    var flash by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val total = entries.sumOf { it.ml }
    val done = total >= goal
    val progress = (total.toFloat() / goal.coerceAtLeast(1)).coerceIn(0f, 1f)
    val accent = if (done) g.green else g.blue

    fun addQuick() {
        val e = WaterEntry(SystemClock.uptimeMillis().toString(), 250, System.currentTimeMillis(), "glass")
        entries = listOf(e) + entries
        saveWaterEntries(ctx, entries)
        goal = effectiveWaterGoal(ctx)
        if (entries.sumOf { it.ml } >= goal) markWaterReminded(ctx)
        flash = true
        scope.launch {
            delay(1200)
            flash = false
        }
    }

    AnimatedVisibility(
        visible = visible,
        enter = slideInVertically { it } + fadeIn(),
        exit = slideOutVertically { it } + fadeOut(),
    ) {
        val shape = RoundedCornerShape(20.dp)
        Row(
            modifier
                .fillMaxWidth()
                .clip(shape)
                .background(g.card)
                .border(1.dp, g.line, shape)
                .clickable { onOpenFull() }
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(Modifier.size(34.dp).clip(CircleShape).background(g.blueSoft), contentAlignment = Alignment.Center) {
                Icon(Icons.Filled.WaterDrop, contentDescription = null, tint = accent, modifier = Modifier.size(18.dp))
            }
            Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Cris Hidrata", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Text(
                        if (flash) "+250 ml" else if (done) "$total ml ✓" else "$total / $goal ml",
                        color = g.muted, fontSize = 11.sp,
                    )
                }
                Box(Modifier.padding(top = 5.dp).fillMaxWidth().height(4.dp).clip(RoundedCornerShape(2.dp)).background(g.blueSoft)) {
                    Box(Modifier.fillMaxWidth(progress).fillMaxHeight().background(accent))
                }
            }
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(accent).clickable { addQuick() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Filled.Add, contentDescription = "Adicionar 250 ml", tint = Color.White, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
private fun WaterClockCard(total: Int, goal: Int, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    val g = glucoColors()
    var now by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var times by remember { mutableStateOf(loadWaterClockTimes(ctx)) }
    var on by remember { mutableStateOf(waterClockOn(ctx)) }
    var hours by remember { mutableIntStateOf(waterRemindHours(ctx)) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(15_000)
        }
    }
    val clockFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val cal = Calendar.getInstance().apply { timeInMillis = now }
    val nowMin = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
    val mins = times.mapNotNull { t -> parseClock(t)?.let { it.first * 60 + it.second } }
    val left = mins.count { it > nowMin }
    val nextMin = mins.firstOrNull { it > nowMin } ?: mins.firstOrNull()
    val remaining = (goal - total).coerceAtLeast(0)
    val suggest = if (remaining <= 0) 0 else (((remaining / left.coerceAtLeast(1)) + 25) / 50 * 50).coerceIn(100, 500)

    fun commitTimes(list: List<String>) {
        times = list.distinct().sorted()
        saveWaterClockTimes(ctx, times)
    }

    fun pick(initial: String?, onPicked: (String) -> Unit) {
        val hm = initial?.let { parseClock(it) } ?: (cal.get(Calendar.HOUR_OF_DAY) to 0)
        android.app.TimePickerDialog(
            ctx,
            { _, h, m -> onPicked("%02d:%02d".format(h, m)) },
            hm.first, hm.second, true,
        ).show()
    }

    GCard(modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Relógio inteligente", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(clockFmt.format(Date(now)), color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 34.sp)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Switch(checked = on, onCheckedChange = {
                    on = it
                    setWaterClockOn(ctx, it)
                })
                Text(if (on) "Lembretes ligados" else "Lembretes desligados", color = g.muted, fontSize = 10.sp)
            }
        }
        Text(
            when {
                remaining <= 0 -> "Meta batida: o relógio fica em silêncio hoje. 🎉"
                nextMin != null -> "Próximo: %02d:%02d · beba cerca de %d ml".format(nextMin / 60, nextMin % 60, suggest)
                else -> "Adicione um horário para o relógio te avisar."
            },
            color = g.ink, fontSize = 13.sp,
            modifier = Modifier.padding(top = 8.dp).fillMaxWidth()
                .clip(RoundedCornerShape(12.dp)).background(g.blueSoft).padding(10.dp),
        )
        Text("Horários (toque para editar)", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(times, key = { it }) { t ->
                Row(
                    Modifier.clip(RoundedCornerShape(14.dp)).background(g.blueSoft)
                        .clickable { pick(t) { n -> commitTimes(times.filter { it != t } + n) } }
                        .padding(start = 12.dp, top = 6.dp, bottom = 6.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(t, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Icon(
                        Icons.Filled.Close, "Remover $t", tint = g.muted,
                        modifier = Modifier.padding(start = 4.dp).size(24.dp).clip(CircleShape)
                            .clickable { commitTimes(times.filter { it != t }) }.padding(4.dp),
                    )
                }
            }
            item {
                Text(
                    "＋ Horário", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(g.blue)
                        .clickable { pick(null) { n -> commitTimes(times + n) } }
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                )
            }
        }
        Text("Gerar horários automáticos a cada", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(1, 2, 3, 4).forEach { h ->
                val sel = hours == h
                Text(
                    "${h}h",
                    color = if (sel) Color.White else g.muted,
                    fontWeight = if (sel) FontWeight.Bold else FontWeight.Normal,
                    modifier = Modifier.clip(RoundedCornerShape(12.dp))
                        .background(if (sel) g.blue else g.blueSoft)
                        .clickable {
                            hours = h
                            setWaterRemindHours(ctx, h)
                            commitTimes(defaultWaterClockTimes(h))
                        }
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                )
            }
        }
    }
}

@Composable
fun WaterTrackerScreen(vm: GlucoViewModel, nav: NavHostController) {
    val ctx = LocalContext.current
    val g = glucoColors()
    val data by vm.data.collectAsStateWithLifecycle()
    var goal by remember { mutableIntStateOf(loadWaterGoal(ctx)) }
    var goalText by remember { mutableStateOf(goal.toString()) }
    var effective by remember { mutableIntStateOf(effectiveWaterGoal(ctx)) }
    var entries by remember { mutableStateOf(loadWaterEntries(ctx)) }
    var customMl by remember { mutableStateOf("") }
    var undoEntry by remember { mutableStateOf<WaterEntry?>(null) }
    var sounds by remember { mutableStateOf(waterSoundsOn(ctx)) }
    var heat by remember { mutableStateOf(isHeatModeToday(ctx)) }
    var askMeal by remember { mutableStateOf(askWaterAfterMeal(ctx)) }
    var favs by remember { mutableStateOf(loadFavCups(ctx)) }
    var remindH by remember { mutableIntStateOf(waterRemindHours(ctx)) }
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    var highAlert by remember { mutableStateOf(WaterAlert.isOn(ctx)) }
    val latestGlucose = remember(data.glucose) { data.glucose.maxByOrNull { it.at } }
    val latestMg = latestGlucose?.let { toMgDl(it.value, it.unit) }
    val glucoseHigh = highAlert && latestGlucose != null && latestMg != null &&
        latestMg > data.settings.targetHigh &&
        System.currentTimeMillis() - latestGlucose.at < 6L * 60L * 60L * 1000L
    val total = entries.sumOf { it.ml }
    val progress = total.toFloat() / effective.coerceAtLeast(1)
    val done = progress >= 1f
    val mood = waterMood(progress.coerceAtMost(1f))
    val insight = remember(entries.size, effective) { waterInsightLine(ctx) }
    val suggested = suggestedWaterGoalMl(data.settings.weightKg)
    val cups = remember(favs) {
        CUP_PRESETS.sortedWith(compareByDescending<WaterCupPreset> { it.ml in favs }.thenBy { it.ml })
    }

    fun refreshGoal() {
        goal = loadWaterGoal(ctx)
        effective = effectiveWaterGoal(ctx)
        goalText = goal.toString()
    }

    fun addEntry(ml: Int, kind: String) {
        val e = WaterEntry(SystemClock.uptimeMillis().toString(), ml, System.currentTimeMillis(), kind)
        entries = listOf(e) + entries
        saveWaterEntries(ctx, entries)
        undoEntry = e
        if (entries.sumOf { it.ml } >= effective) markWaterReminded(ctx)
    }

    fun removeEntry(id: String) {
        entries = entries.filter { it.id != id }
        saveWaterEntries(ctx, entries)
    }

    LaunchedEffect(undoEntry) {
        if (undoEntry != null) {
            delay(5000)
            undoEntry = null
        }
    }

    Box(Modifier.fillMaxSize().background(g.bg)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { nav.popBackStack() }) {
                    Icon(Icons.Filled.Close, "Fechar", tint = g.ink)
                }
                Text("Cris Hidrata", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp, modifier = Modifier.weight(1f))
                CrisDrop(mood, Modifier.size(56.dp).tourTarget("water_drop"))
            }
            Column(
                Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 16.dp)
                    .padding(bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                // Resumo do dia
                GCard(Modifier.tourTarget("water_ring")) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        WaterRing(progress, total, effective, done, g)
                        Column(Modifier.weight(1f).padding(start = 16.dp)) {
                            Text("Hoje", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(
                                if (done) "Meta batida! 🎉" else "Faltam ${(effective - total).coerceAtLeast(0)} ml",
                                color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp,
                            )
                            Text("Meta de hoje: $effective ml", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                            if (heat) {
                                Text("Modo calor/exercício: +$HEAT_BONUS_ML ml só hoje", color = g.blue, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                            }
                            if (done) {
                                Text("★ Conquista do dia", color = g.orange, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                            }
                        }
                    }
                    insight?.let {
                        Text(
                            "💡 $it",
                            color = g.ink, fontSize = 13.sp,
                            modifier = Modifier.padding(top = 12.dp).fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp)).background(g.blueSoft).padding(10.dp),
                        )
                    }
                }

                // Alerta: glicose alta -> beber água (liga/desliga)
                GCard(Modifier.tourTarget("water_alert")) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Alerta de glicose alta", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                            Text(
                                "Avisa para beber água quando a glicose passar da sua meta máxima.",
                                color = g.muted, fontSize = 12.sp,
                            )
                        }
                        Switch(checked = highAlert, onCheckedChange = {
                            highAlert = it
                            WaterAlert.setOn(ctx, it)
                        })
                    }
                    if (glucoseHigh && latestGlucose != null && latestMg != null) {
                        Column(
                            Modifier.padding(top = 10.dp).fillMaxWidth()
                                .clip(RoundedCornerShape(14.dp)).background(g.red.copy(alpha = 0.14f)).padding(12.dp),
                        ) {
                            Text(
                                "⚠ Glicose alta: ${latestMg.toInt()} mg/dL às ${timeFmt.format(Date(latestGlucose.at))}. Beba um copo de água agora e siga a orientação da sua equipe de saúde.",
                                color = g.ink, fontSize = 13.sp,
                            )
                            Text(
                                "Beber 250 ml", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                                modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(12.dp))
                                    .background(g.blue).clickable { addEntry(250, "glass") }
                                    .padding(horizontal = 16.dp, vertical = 8.dp),
                            )
                        }
                    }
                }

                // Relógio inteligente (editável)
                WaterClockCard(total, effective, Modifier.tourTarget("water_clock"))

                // Adicionar água
                Column(Modifier.tourTarget("water_cups")) {
                    Text("Adicionar água", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                    Text("Toque no copo para somar. A estrela fixa seus favoritos no começo.", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(cups, key = { it.ml }) { pr ->
                            CupPill(
                                preset = pr,
                                fav = pr.ml in favs,
                                onAdd = { addEntry(pr.ml, pr.kind) },
                                onToggleFav = {
                                    toggleFavCup(ctx, pr.ml)
                                    favs = loadFavCups(ctx)
                                },
                            )
                        }
                    }
                }

                // Quantidade personalizada
                GCard {
                    Text("Quantidade personalizada", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = customMl,
                            onValueChange = { customMl = it.filter { ch -> ch.isDigit() }.take(4) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            label = { Text("ml") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        )
                        Box(
                            Modifier
                                .padding(start = 10.dp)
                                .size(52.dp)
                                .clip(CircleShape)
                                .background(g.blue)
                                .clickable {
                                    val ml = customMl.toIntOrNull() ?: return@clickable
                                    if (ml in 1..2000) {
                                        addEntry(ml, "custom")
                                        customMl = ""
                                    }
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(Icons.Filled.Add, "Adicionar", tint = Color.White)
                        }
                    }
                }

                // Registros de hoje
                GCard {
                    Text("Registros de hoje", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    if (entries.isEmpty()) {
                        Text("Nenhum copo ainda. Toque em um copo acima.", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    } else {
                        entries.forEach { e ->
                            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(38.dp).clip(CircleShape).background(g.blueSoft), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Filled.WaterDrop, null, tint = g.blue, modifier = Modifier.size(20.dp))
                                }
                                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                    Text("${e.ml} ml", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    Text(timeFmt.format(Date(e.at)), color = g.muted, fontSize = 12.sp)
                                }
                                IconButton(onClick = { removeEntry(e.id) }) {
                                    Icon(Icons.Filled.Delete, "Excluir", tint = g.muted)
                                }
                            }
                        }
                    }
                }

                // Ajustes do contador
                GCard {
                    Text("Ajustes do contador", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Text("Meta base (ml)", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = goalText,
                            onValueChange = { goalText = it.filter { ch -> ch.isDigit() }.take(4) },
                            modifier = Modifier.weight(1f),
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        )
                        TextButton(onClick = {
                            val v = goalText.toIntOrNull() ?: return@TextButton
                            saveWaterGoal(ctx, v)
                            refreshGoal()
                        }) { Text("Salvar", color = g.blue, fontWeight = FontWeight.Bold) }
                    }
                    if (suggested != null) {
                        TextButton(onClick = {
                            saveWaterGoal(ctx, suggested)
                            refreshGoal()
                        }) {
                            Text("Usar meta sugerida (~35 ml/kg): $suggested ml", color = g.blue)
                        }
                    } else {
                        Text("Preencha o peso no Perfil para sugerir meta automática.", color = g.muted, fontSize = 12.sp)
                    }
                    SwitchRow("Modo calor / exercício (+$HEAT_BONUS_ML ml hoje)", heat) {
                        heat = it
                        setHeatModeToday(ctx, it)
                        effective = effectiveWaterGoal(ctx)
                    }
                    SwitchRow("Sons (gota e cócegas)", sounds) {
                        sounds = it
                        setWaterSoundsOn(ctx, it)
                    }
                    SwitchRow("Perguntar água ao salvar refeição", askMeal) {
                        askMeal = it
                        setAskWaterAfterMeal(ctx, it)
                    }
                }

                Text(
                    "Hidratação de apoio. Não substitui orientação médica.",
                    color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 8.dp),
                )
            }
        }

        AnimatedVisibility(
            visible = undoEntry != null,
            modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
            enter = slideInVertically { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut(),
        ) {
            val last = undoEntry
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(g.blue)
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("+${last?.ml ?: 0} ml adicionados", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                Text(
                    "Desfazer",
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            last?.let { removeEntry(it.id) }
                            undoEntry = null
                        }
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                )
            }
        }
    }
}
