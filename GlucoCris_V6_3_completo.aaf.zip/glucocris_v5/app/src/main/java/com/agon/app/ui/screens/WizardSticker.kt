package com.agon.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke

/**
 * Figurinha de bruxinho (personagem original do Gluco Cris) para cada humor.
 * Desenhada no próprio app, sem imagens e sem personagens de terceiros.
 */
@Composable
fun WizardSticker(moodId: String, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val s = size.minDimension
        fun u(v: Float) = v / 100f * s
        fun o(x: Float, y: Float) = Offset(u(x), u(y))
        val ink = Color(0xFF2B1B4E)
        val skin = Color(0xFFFFDDB8)
        val pink = Color(0xFFFF8FB1)
        val gold = Color(0xFFFBBF24)
        val blue = Color(0xFF38BDF8)
        val line = Stroke(width = u(2.6f), cap = StrokeCap.Round)

        fun curve(x1: Float, y1: Float, cx: Float, cy: Float, x2: Float, y2: Float): Path =
            Path().apply {
                moveTo(u(x1), u(y1))
                quadraticTo(u(cx), u(cy), u(x2), u(y2))
            }

        // adesivo (fundo + contorno branco)
        drawCircle(Color(0xFFF3EEFF), u(49f), o(50f, 50f))
        drawCircle(Color.White, u(49f), o(50f, 50f), style = Stroke(u(3f)))

        // chapéu
        val hat = Path().apply {
            moveTo(u(24f), u(50f))
            quadraticTo(u(44f), u(30f), u(58f), u(6f))
            quadraticTo(u(62f), u(26f), u(76f), u(50f))
            close()
        }
        drawPath(hat, Color(0xFF5B21B6))
        drawRoundRect(Color(0xFF3B0F7A), o(16f, 46f), Size(u(68f), u(10f)), CornerRadius(u(5f)))
        drawRect(gold, o(32f, 41f), Size(u(36f), u(4f)))
        drawCircle(gold, u(3f), o(52f, 26f))

        // rosto
        drawCircle(skin, u(23f), o(50f, 68f))
        if (moodId == "irritado") drawCircle(Color(0xFFEF4444).copy(alpha = 0.2f), u(23f), o(50f, 68f))

        val ex1 = 41f
        val ex2 = 59f
        val ey = 64f
        fun dotEyes() {
            drawCircle(ink, u(2.8f), o(ex1, ey))
            drawCircle(ink, u(2.8f), o(ex2, ey))
        }
        fun cheeks() {
            drawCircle(pink.copy(alpha = 0.55f), u(3.6f), o(34f, 72f))
            drawCircle(pink.copy(alpha = 0.55f), u(3.6f), o(66f, 72f))
        }

        when (moodId) {
            "muito_feliz" -> {
                drawPath(curve(ex1 - 4f, 65f, ex1, 58f, ex1 + 4f, 65f), ink, style = line)
                drawPath(curve(ex2 - 4f, 65f, ex2, 58f, ex2 + 4f, 65f), ink, style = line)
                cheeks()
                val mouth = Path().apply {
                    moveTo(u(40f), u(74f))
                    quadraticTo(u(50f), u(90f), u(60f), u(74f))
                    close()
                }
                drawPath(mouth, ink)
                drawCircle(pink, u(3.2f), o(50f, 81f))
                drawCircle(gold, u(2f), o(82f, 30f))
                drawCircle(gold, u(1.6f), o(18f, 34f))
            }
            "feliz" -> {
                dotEyes()
                cheeks()
                drawPath(curve(42f, 75f, 50f, 84f, 58f, 75f), ink, style = line)
            }
            "tranquilo" -> {
                drawPath(curve(ex1 - 4f, 63f, ex1, 68f, ex1 + 4f, 63f), ink, style = line)
                drawPath(curve(ex2 - 4f, 63f, ex2, 68f, ex2 + 4f, 63f), ink, style = line)
                drawPath(curve(44f, 76f, 50f, 80f, 56f, 76f), ink, style = line)
            }
            "neutro" -> {
                dotEyes()
                drawLine(ink, o(43f, 77f), o(57f, 77f), strokeWidth = u(2.6f), cap = StrokeCap.Round)
            }
            "cansado" -> {
                drawLine(ink, o(ex1 - 4f, 64f), o(ex1 + 4f, 64f), strokeWidth = u(2.6f), cap = StrokeCap.Round)
                drawLine(ink, o(ex2 - 4f, 64f), o(ex2 + 4f, 64f), strokeWidth = u(2.6f), cap = StrokeCap.Round)
                drawPath(curve(ex1 - 4f, 68f, ex1, 71f, ex1 + 4f, 68f), ink.copy(alpha = 0.35f), style = Stroke(u(1.6f), cap = StrokeCap.Round))
                drawPath(curve(ex2 - 4f, 68f, ex2, 71f, ex2 + 4f, 68f), ink.copy(alpha = 0.35f), style = Stroke(u(1.6f), cap = StrokeCap.Round))
                drawOval(ink, o(46f, 76f), Size(u(8f), u(6f)))
                val z = Path().apply {
                    moveTo(u(72f), u(34f)); lineTo(u(80f), u(34f)); lineTo(u(72f), u(44f)); lineTo(u(80f), u(44f))
                }
                drawPath(z, Color(0xFF7C3AED), style = Stroke(u(2.2f), cap = StrokeCap.Round))
            }
            "ansioso" -> {
                dotEyes()
                drawLine(ink, o(37f, 58f), o(45f, 55f), strokeWidth = u(2.2f), cap = StrokeCap.Round)
                drawLine(ink, o(63f, 58f), o(55f, 55f), strokeWidth = u(2.2f), cap = StrokeCap.Round)
                val wave = Path().apply {
                    moveTo(u(42f), u(77f))
                    quadraticTo(u(46f), u(73f), u(50f), u(77f))
                    quadraticTo(u(54f), u(81f), u(58f), u(77f))
                }
                drawPath(wave, ink, style = line)
                drawCircle(blue, u(2.6f), o(70f, 60f))
            }
            "triste" -> {
                dotEyes()
                drawLine(ink, o(37f, 58f), o(45f, 55f), strokeWidth = u(2.2f), cap = StrokeCap.Round)
                drawLine(ink, o(63f, 58f), o(55f, 55f), strokeWidth = u(2.2f), cap = StrokeCap.Round)
                drawPath(curve(42f, 81f, 50f, 73f, 58f, 81f), ink, style = line)
                drawCircle(blue, u(2.6f), o(40f, 72f))
            }
            "irritado" -> {
                dotEyes()
                drawLine(ink, o(37f, 55f), o(45f, 59f), strokeWidth = u(2.8f), cap = StrokeCap.Round)
                drawLine(ink, o(63f, 55f), o(55f, 59f), strokeWidth = u(2.8f), cap = StrokeCap.Round)
                drawPath(curve(43f, 80f, 50f, 75f, 57f, 80f), ink, style = line)
            }
            else -> {
                dotEyes()
                drawPath(curve(42f, 75f, 50f, 82f, 58f, 75f), ink, style = line)
            }
        }
    }
}
