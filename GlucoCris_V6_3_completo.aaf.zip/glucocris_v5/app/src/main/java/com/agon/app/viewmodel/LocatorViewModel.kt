package com.agon.app.viewmodel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.agon.app.data.insulin.LocatorQuery
import com.agon.app.data.insulin.LocatorScope
import com.agon.app.data.insulin.SortMode

/**
 * ViewModel do Localizador de Insulina — igual à versão original.
 */
class LocatorViewModel : ViewModel() {
    var text by mutableStateOf("")
    var productId by mutableStateOf("all")
    var categoryIds by mutableStateOf<Set<String>>(emptySet())
    var channelIds by mutableStateOf<Set<String>>(emptySet())
    var scope by mutableStateOf(LocatorScope.BRASIL)
    var uf by mutableStateOf<String?>(null)
    var cityId by mutableStateOf<String?>(null)
    var onlyFree by mutableStateOf(false)
    var sort by mutableStateOf(SortMode.PROXIMIDADE)
    var showMap by mutableStateOf(true)
    var filtersExpanded by mutableStateOf(false)

    val query: LocatorQuery
        get() = LocatorQuery(
            text = text,
            productId = productId,
            categoryIds = categoryIds,
            channelIds = channelIds,
            scope = scope,
            uf = uf,
            cityId = cityId,
            onlyFree = onlyFree,
            sort = sort,
        )

    fun toggleCategory(id: String) {
        categoryIds = if (id in categoryIds) categoryIds - id else categoryIds + id
    }

    fun toggleChannel(id: String) {
        channelIds = if (id in channelIds) channelIds - id else channelIds + id
    }

    fun selectBrazil() {
        scope = LocatorScope.BRASIL
        uf = null
        cityId = null
    }

    fun selectUf(code: String) {
        scope = LocatorScope.UF
        uf = code
        cityId = null
    }

    fun selectCity(id: String, ufCode: String) {
        scope = LocatorScope.CIDADE
        uf = ufCode
        cityId = id
    }

    fun clearFilters() {
        text = ""
        productId = "all"
        categoryIds = emptySet()
        channelIds = emptySet()
        onlyFree = false
        sort = SortMode.PROXIMIDADE
        selectBrazil()
    }

    val activeFilterCount: Int
        get() {
            var n = 0
            if (productId != "all") n++
            if (categoryIds.isNotEmpty()) n++
            if (channelIds.isNotEmpty()) n++
            if (onlyFree) n++
            if (scope != LocatorScope.BRASIL) n++
            if (sort != SortMode.PROXIMIDADE) n++
            return n
        }
}
