package com.agon.app.cloud

import com.agon.app.data.AppData
import com.agon.app.data.GlucoseEntry
import com.agon.app.data.Settings
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import java.io.ByteArrayOutputStream
import java.util.zip.GZIPOutputStream

class LocalEncryptedBackupTest {
    private fun sample(): AppData = AppData(
        glucose = listOf(
            GlucoseEntry(id = "g1", value = 120.0, unit = "mg/dL", at = 1000L, context = "jejum", updatedAt = 1000L),
            GlucoseEntry(id = "g2", value = 140.0, unit = "mg/dL", at = 2000L, context = "outro", updatedAt = 2000L),
        ),
        settings = Settings(displayName = "Teste"),
    )

    @Test fun exportAndDecrypt_roundTrip() = runBlocking {
        val pwd = "senha-forte-123".toCharArray()
        val exp = LocalEncryptedBackup.export(sample(), pwd)
        // password should be cleared by export
        assertTrue(pwd.all { it == '\u0000' })
        assertTrue(exp.message, exp.ok)
        val pwd2 = "senha-forte-123".toCharArray()
        val (decoded, msg) = LocalEncryptedBackup.decrypt(exp.bytes!!, pwd2)
        assertTrue(pwd2.all { it == '\u0000' })
        assertNotNull(msg, decoded)
        assertEquals(2, decoded!!.glucose.size)
    }

    @Test fun wrongPassword_fails() = runBlocking {
        val exp = LocalEncryptedBackup.export(sample(), "certa".toCharArray())
        val (decoded, msg) = LocalEncryptedBackup.decrypt(exp.bytes!!, "errada".toCharArray())
        assertNull(decoded)
        assertTrue(msg.contains("Senha") || msg.contains("adulterado"))
        assertFalse(msg.lowercase().contains("errada"))
    }

    @Test fun tamperedFile_fails() = runBlocking {
        val exp = LocalEncryptedBackup.export(sample(), "x".toCharArray())
        val bytes = exp.bytes!!.clone()
        bytes[bytes.size / 2] = (bytes[bytes.size / 2].toInt() xor 0xFF).toByte()
        val (decoded, _) = LocalEncryptedBackup.decrypt(bytes, "x".toCharArray())
        assertNull(decoded)
    }

    @Test fun invalidMagic_fails() = runBlocking {
        val (decoded, msg) = LocalEncryptedBackup.decrypt("NAOEHBACKUP".toByteArray(), "x".toCharArray())
        assertNull(decoded)
        assertTrue(msg.isNotBlank())
    }

    @Test fun truncatedFile_fails() = runBlocking {
        val exp = LocalEncryptedBackup.export(sample(), "x".toCharArray())
        val trunc = exp.bytes!!.copyOf(20)
        val (decoded, msg) = LocalEncryptedBackup.decrypt(trunc, "x".toCharArray())
        assertNull(decoded)
        assertTrue(msg.isNotBlank())
    }

    @Test fun oversizedCipher_rejected() = runBlocking {
        val huge = ByteArray(LocalEncryptedBackup.MAX_CIPHER_BYTES + 10) { 1 }
        val (decoded, msg) = LocalEncryptedBackup.decrypt(huge, "x".toCharArray())
        assertNull(decoded)
        assertTrue(msg.isNotBlank())
    }

    @Test fun safeGunzip_limitsExpansion() {
        val plain = ByteArray(2 * 1024 * 1024) { 0 }
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(plain) }
        try {
            LocalEncryptedBackup.safeGunzip(bos.toByteArray(), 1024 * 1024)
            fail("should have thrown")
        } catch (e: Exception) {
            assertTrue(e.message!!.contains("limite") || e.message!!.contains("malicioso"))
        }
    }

    @Test fun merge_prefersNewer() {
        val cur = sample()
        val incoming = AppData(
            glucose = listOf(
                GlucoseEntry(id = "g1", value = 999.0, unit = "mg/dL", at = 1000L, context = "jejum", updatedAt = 5000L),
                GlucoseEntry(id = "g3", value = 90.0, unit = "mg/dL", at = 3000L, context = "outro", updatedAt = 3000L),
            ),
        )
        val merged = LocalEncryptedBackup.merge(cur, incoming)
        assertEquals(3, merged.glucose.size)
        assertEquals(999.0, merged.glucose.first { it.id == "g1" }.value, 0.01)
    }

    @Test fun merge_doesNotDestroyCurrentOnEmptyIncoming() {
        val cur = sample()
        val merged = LocalEncryptedBackup.merge(cur, AppData())
        assertEquals(2, merged.glucose.size)
    }

    @Test fun v62Format_stillReadable() = runBlocking {
        // Same MAGIC/VERSION as V6.2 — round-trip proves compatibility
        val exp = LocalEncryptedBackup.export(sample(), "compat".toCharArray())
        assertTrue(exp.ok)
        val magic = String(exp.bytes!!, 0, 8, Charsets.US_ASCII)
        assertEquals("GLUCOCR6", magic)
        val (decoded, _) = LocalEncryptedBackup.decrypt(exp.bytes!!, "compat".toCharArray())
        assertNotNull(decoded)
    }
}
