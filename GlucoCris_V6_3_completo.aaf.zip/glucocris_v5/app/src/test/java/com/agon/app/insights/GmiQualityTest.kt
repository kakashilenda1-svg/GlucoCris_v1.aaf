package com.agon.app.insights

import org.junit.Assert.*
import org.junit.Test

class GmiQualityTest {
    private fun meter(mg: Double, daysAgo: Int): Reading {
        val at = System.currentTimeMillis() - daysAgo * Insights.DAY_MS - (daysAgo * 3_600_000L)
        return Reading(at, mg, fromCgm = false)
    }

    /** CGM samples every [intervalMin] minutes, going back [count] samples. */
    private fun cgmSeries(count: Int, intervalMin: Int = 5, baseMg: Double = 120.0): List<Reading> {
        val now = System.currentTimeMillis()
        return (0 until count).map { i ->
            Reading(now - i.toLong() * intervalMin * 60_000L, baseMg + (i % 7), fromCgm = true)
        }
    }

    @Test fun empty_notReliable() {
        val a = GmiQuality.assess(emptyList())
        assertFalse(a.reliable)
        assertFalse(a.timeInRangeMeaningful)
    }

    @Test fun notesContainingSensor_isNotCgm() {
        assertFalse(GmiQuality.isCgmEntry("manual-1", "Sensor da farmácia"))
        assertTrue(GmiQuality.isCgmEntry("sensor-dexcom-12345"))
    }

    @Test fun singleMeter_notReliable() {
        assertFalse(GmiQuality.assess(listOf(meter(120.0, 0))).reliable)
    }

    @Test fun enoughMeter_reliableButNotTimeInRange() {
        val list = (0 until 20).map { meter(130.0, it) }
        val a = GmiQuality.assess(list)
        assertTrue(a.reliable)
        assertEquals(DataOrigin.METER, a.origin)
        assertFalse(a.timeInRangeMeaningful)
        assertTrue(a.note.contains("estimativa", ignoreCase = true) || a.note.contains("GMI"))
        assertTrue(a.note.contains("HbA1c") || a.note.contains("laboratorial"))
    }

    @Test fun formula_mgdl() {
        val list = (0 until 20).map { meter(154.0, it) }
        val st = Insights.stats(list, 70, 180)!!
        assertEquals(3.31 + 0.02392 * 154.0, st.gmi, 0.001)
        assertTrue(st.gmiReliable)
        assertFalse(st.timeInRangeMeaningful)
    }

    @Test fun mmolConversion_inStats() {
        // 10 mmol/L * 18.0182 = 180.182 mg/dL
        val entries = (0 until 20).map { i ->
            com.agon.app.data.GlucoseEntry(
                id = "g$i", value = 10.0, unit = "mmol/L",
                at = System.currentTimeMillis() - i * Insights.DAY_MS,
                context = "jejum", updatedAt = 1L,
            )
        }
        val data = com.agon.app.data.AppData(glucose = entries)
        val readings = Insights.readings(data, 30)
        assertEquals(20, readings.size)
        assertEquals(180.182, readings[0].mg, 0.01)
        val st = Insights.stats(readings, 70, 180)!!
        assertEquals(3.31 + 0.02392 * 180.182, st.gmi, 0.02)
    }

    @Test fun cgmLowCoverage_notReliable() {
        // 30 samples over ~14 days at daily interval → low coverage
        val list = cgmSeries(30, intervalMin = 24 * 60)
        val a = GmiQuality.assess(list)
        assertEquals(DataOrigin.CGM, a.origin)
        assertFalse(a.timeInRangeMeaningful)
        assertFalse(a.reliable)
    }

    @Test fun cgmConcentratedHours_notFullCoverage() {
        // many samples but only over 6 hours
        val now = System.currentTimeMillis()
        val list = (0 until 80).map { i ->
            Reading(now - i * 5 * 60_000L, 120.0, fromCgm = true)
        }
        val a = GmiQuality.assess(list)
        assertEquals(DataOrigin.CGM, a.origin)
        assertFalse(a.reliable) // span << 14 days
        assertFalse(a.timeInRangeMeaningful)
    }

    @Test fun cgmAdequateCoverage_reliable() {
        // 5-min samples for 14 days: 14*24*12 = 4032
        val list = cgmSeries(14 * 24 * 12, intervalMin = 5)
        val a = GmiQuality.assess(list)
        assertEquals(DataOrigin.CGM, a.origin)
        assertTrue("cov=${a.coveragePct} note=${a.note}", a.coveragePct >= 70.0 || a.reliable)
        if (a.reliable) assertTrue(a.timeInRangeMeaningful)
    }

    @Test fun coverageUnknown_weirdInterval() {
        // intervals of 1 second — not a real CGM sampling rate
        val now = System.currentTimeMillis()
        val list = (0 until 100).map { i ->
            Reading(now - i * 1000L, 110.0, fromCgm = true)
        }
        val cov = GmiQuality.computeCoverage(list, 14)
        assertFalse(cov.known)
    }
}
