package com.agon.app.localai

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.async
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Testes com serviços SIMULADOS e tempo virtual (nenhuma chamada real, nenhum crédito gasto).
 * Cobrem a lógica de concorrência/fallback; NÃO validam Gemini/Tavily/Worker reais.
 */
class CrisCloudOrchestratorTest {

    private fun hit(title: String, snippet: String, url: String, score: Int = 10, source: String = "fonte") =
        WebHit(title, snippet, url, source, "", false, score)

    private val goodHits = listOf(
        hit("Presidente Lula sancionou lei do Orçamento Federal", "Presidente Lula sancionou o Orçamento Federal em Brasília.", "https://gov.example.gov.br/a", 40),
        hit("Orçamento Federal sancionado", "Lei do Orçamento Federal foi sancionada pelo Presidente Lula.", "https://news.example.com/b", 12),
    )
    private fun web(hits: List<WebHit> = goodHits) = WebPrep(SearchIntent.CURRENT, promptBlock = "BLOCO ${hits.size}", hits = hits)

    private val CONSISTENT_ANSWER = "O Presidente Lula sancionou o Orçamento Federal em Brasília."
    private class Calls { val gemini = mutableListOf<Pair<Long, String>>(); var search = 0L; var searchStarted = -1L; var geminiStarted = -1L }

    // 1 + 2 ---------------------------------------------------------------------------------------------
    @Test fun both_start_at_the_same_instant_and_total_time_is_the_max_not_the_sum() = runTest {
        val c = Calls()
        val deps = CloudDeps(
            gemini = { ctx -> if (ctx.isEmpty()) { c.geminiStarted = currentTime; delay(5_000) }; GemResult(CONSISTENT_ANSWER, searched = true) },
            search = { c.searchStarted = currentTime; delay(4_000); web() },
            canSynthesize = { true },
        )
        val out = CrisCloudOrchestrator.run(deps, needsWeb = true, geminiOn = true)
        assertEquals(0L, c.geminiStarted)          // Gemini não esperou o Tavily
        assertEquals(0L, c.searchStarted)          // Tavily não esperou o Gemini
        assertTrue(currentTime in 5_000L..5_000L)  // 5 s (concorrente), não 9 s (sequencial)
        assertTrue(out is CloudOutcome.GeminiAnswer)
    }

    @Test fun slow_search_never_delays_the_gemini_start() = runTest {
        val c = Calls()
        val deps = CloudDeps(
            gemini = { ctx -> c.geminiStarted = currentTime; GemResult(CONSISTENT_ANSWER, searched = true) },
            search = { delay(14_000); web() },
            canSynthesize = { true },
        )
        CrisCloudOrchestrator.run(deps, true, true)
        assertEquals(0L, c.geminiStarted)
    }

    // 3 -------------------------------------------------------------------------------------------------
    @Test fun gemini_grounded_answers_first_search_gets_a_moderate_grace() = runTest {
        val deps = CloudDeps(
            gemini = { GemResult("Resposta fundamentada", searched = true, sources = listOf("g1" to "https://g1.globo.com/x")) },
            search = { delay(8_000); web() },
            canSynthesize = { true },
        )
        val out = CrisCloudOrchestrator.run(deps, true, true)
        assertTrue(out is CloudOutcome.GeminiAnswer)
        assertNull((out as CloudOutcome.GeminiAnswer).web)
        assertEquals(4_000L, currentTime)          // janela moderada (4 s), não os 8 s da pesquisa
    }

    // 4 + 21 --------------------------------------------------------------------------------------------
    @Test fun tavily_first_and_gemini_not_grounded_triggers_exactly_one_synthesis() = runTest {
        val seen = mutableListOf<String>()
        val deps = CloudDeps(
            gemini = { ctx -> seen += ctx; delay(3_000); if (ctx.isEmpty()) GemResult("Não sei informar.", searched = false) else GemResult("Síntese com fontes", searched = false) },
            search = { delay(500); web() },
            canSynthesize = { true },
        )
        val out = CrisCloudOrchestrator.run(deps, true, true)
        assertTrue(out is CloudOutcome.Synthesized)
        assertEquals(listOf("", "BLOCO 2"), seen)   // 1ª sem resultados (honesto), 2ª com resultados
    }

    @Test fun no_second_gemini_call_when_answer_is_grounded_and_consistent() = runTest {
        var calls = 0
        val deps = CloudDeps(
            gemini = { calls++; GemResult("O Presidente Lula sancionou o Orçamento Federal em Brasília.", searched = true) },
            search = { web() },
            canSynthesize = { true },
        )
        val out = CrisCloudOrchestrator.run(deps, true, true)
        assertEquals(1, calls)
        assertTrue(out is CloudOutcome.GeminiAnswer)
    }

    @Test fun no_second_call_and_no_search_for_simple_questions() = runTest {
        var calls = 0; var searches = 0
        val deps = CloudDeps(
            gemini = { calls++; GemResult("42") },
            search = { searches++; web() },
            canSynthesize = { true },
        )
        val out = CrisCloudOrchestrator.run(deps, needsWeb = false, geminiOn = true)
        assertEquals(1, calls); assertEquals(0, searches)
        assertTrue(out is CloudOutcome.GeminiAnswer && !(out as CloudOutcome.GeminiAnswer).unverified)
    }

    @Test fun without_quota_for_synthesis_uses_local_ai_or_shows_results() = runTest {
        var calls = 0
        val base = CloudDeps(
            gemini = { calls++; GemResult("Não sei informar.", searched = false) },
            search = { web() },
            canSynthesize = { false },
            localSummarize = { "Resumo local" },
        )
        val withLocal = CrisCloudOrchestrator.run(base, true, true) as CloudOutcome.AnswerPlusResults
        assertEquals("Resumo local", withLocal.localSummary)
        assertEquals(1, calls)                      // cota não permitiu 2ª chamada
        val noLocal = CrisCloudOrchestrator.run(CloudDeps(base.gemini, base.search, base.canSynthesize, null), true, true) as CloudOutcome.AnswerPlusResults
        assertNull(noLocal.localSummary)            // sem IA local: resultados transparentes, sem erro
    }

    // 5 + 6 ---------------------------------------------------------------------------------------------
    @Test fun tavily_beyond_timeout_does_not_block_gemini_and_is_not_claimed_as_verification() = runTest {
        val deps = CloudDeps(
            gemini = { GemResult("Resposta de memória", searched = false) },
            search = { delay(60_000); web() },
            canSynthesize = { true },
        )
        val out = CrisCloudOrchestrator.run(deps, true, true, CloudTimeouts(searchMs = 2_000)) as CloudOutcome.GeminiAnswer
        assertTrue(out.unverified)                  // honesto: não confirmou na internet
        assertEquals(2_000L, currentTime)
    }

    @Test fun gemini_beyond_timeout_falls_back_to_independent_search_results() = runTest {
        val deps = CloudDeps(
            gemini = { delay(100_000); GemResult("tarde demais") },
            search = { delay(1_000); web() },
            canSynthesize = { true },
        )
        val out = CrisCloudOrchestrator.run(deps, true, true, CloudTimeouts(geminiMs = 3_000))
        assertTrue(out is CloudOutcome.SearchOnly)
        assertEquals(3_000L, currentTime)
    }

    // 7 + 8 ---------------------------------------------------------------------------------------------
    @Test fun gemini_429_and_503_do_not_stop_the_search() = runTest {
        for (err in listOf("cota do Gemini esgotada no modelo x (HTTP 429)", "servidor instável (HTTP 503)")) {
            val deps = CloudDeps(
                gemini = { GemResult(null, error = err) },
                search = { delay(2_000); web() },
                canSynthesize = { true },
            )
            val out = CrisCloudOrchestrator.run(deps, true, true) as CloudOutcome.SearchOnly
            assertEquals(err, out.geminiError)
            assertEquals(2, out.web.hits.size)
        }
    }

    // 9 a 12 --------------------------------------------------------------------------------------------
    @Test fun search_failures_leave_gemini_working() = runTest {
        val failing = listOf<suspend () -> WebPrep?>(
            { null },                                            // Tavily 429 / chave inválida / Worker fora → sem resultados
            { WebPrep(SearchIntent.CURRENT, limitation = "x") }, // vazio
            { throw RuntimeException("rede") },                   // exceção inesperada
        )
        for (s in failing) {
            val deps = CloudDeps(gemini = { GemResult("Gemini ok") }, search = s, canSynthesize = { true })
            val out = CrisCloudOrchestrator.run(deps, true, true)
            assertTrue(out is CloudOutcome.GeminiAnswer)
        }
    }

    @Test fun gemini_exception_does_not_cancel_the_search() = runTest {
        val deps = CloudDeps(
            gemini = { throw IllegalStateException("boom") },
            search = { delay(1_000); web() },
            canSynthesize = { true },
        )
        assertTrue(CrisCloudOrchestrator.run(deps, true, true) is CloudOutcome.SearchOnly)
    }

    @Test fun no_internet_means_nothing_online_without_calling_anyone() = runTest {
        var calls = 0
        val deps = CloudDeps(gemini = { calls++; GemResult("x") }, search = { calls++; web() }, canSynthesize = { true })
        val out = CrisCloudOrchestrator.run(deps, needsWeb = false, geminiOn = false)
        assertEquals(0, calls)
        assertTrue(out is CloudOutcome.NothingOnline && !(out as CloudOutcome.NothingOnline).geminiTried)
    }

    // 15 ------------------------------------------------------------------------------------------------
    @Test fun everything_down_reports_nothing_online() = runTest {
        val deps = CloudDeps(gemini = { GemResult(null, error = "HTTP 503") }, search = { null }, canSynthesize = { true })
        val out = CrisCloudOrchestrator.run(deps, true, true) as CloudOutcome.NothingOnline
        assertTrue(out.geminiTried)
        assertEquals("HTTP 503", out.geminiError)
    }

    // 19 + 20 -------------------------------------------------------------------------------------------
    @Test fun two_simultaneous_questions_keep_their_own_answers() = runTest {
        fun depsFor(q: String, d: Long) = CloudDeps(
            gemini = { delay(d); GemResult("resp-$q", searched = true) },
            search = { delay(d / 2); web(listOf(hit("t-$q", "s-$q", "https://x.gov.br/$q", 30))) },
            canSynthesize = { true },
        )
        val a = async { CrisCloudOrchestrator.run(depsFor("A", 3_000), true, true) }
        val b = async { CrisCloudOrchestrator.run(depsFor("B", 1_000), true, true) }
        assertEquals("resp-A", ((a.await()) as CloudOutcome.GeminiAnswer).gem.text)
        assertEquals("resp-B", ((b.await()) as CloudOutcome.GeminiAnswer).gem.text)
    }

    @Test fun cancelling_one_question_does_not_affect_the_other() = runTest {
        val gate = CompletableDeferred<Unit>()
        var other: CloudOutcome? = null
        val first = launch { CrisCloudOrchestrator.run(CloudDeps({ gate.await(); GemResult("nunca") }, { gate.await(); web() }, { true }), true, true) }
        val second = launch { other = CrisCloudOrchestrator.run(CloudDeps({ delay(500); GemResult("segunda") }, { null }, { true }), false, true) }
        delay(100)
        first.cancel()
        second.join()
        assertTrue(first.isCancelled)
        assertEquals("segunda", ((other) as CloudOutcome.GeminiAnswer).gem.text)
    }

    // 16 + 17 + 18 --------------------------------------------------------------------------------------
    @Test fun duplicate_and_irrelevant_results_are_removed() {
        val hits = listOf(
            hit("Orçamento sancionado", "texto", "https://www.site.com/a/?utm_source=x", 10),
            hit("Orçamento sancionado", "texto", "https://site.com/a", 12),
            hit("Outra página", "texto", "https://outro.com/z", 5),
            hit("", "", "https://vazio.com/", 99),
            hit("Sem https", "t", "http://inseguro.com/", 99),
        )
        val c = CrisSourceQuality.curate(hits)
        assertEquals(2, c.size)
        assertEquals(12, c.first().score)
    }

    @Test fun divergent_sources_are_detected_and_consistent_ones_are_not() {
        assertTrue(CrisAnswerCheck.mismatch("Não tenho essa informação.", goodHits))
        assertFalse(CrisAnswerCheck.mismatch("O Presidente Lula sancionou o Orçamento Federal em Brasília.", goodHits))
    }

    @Test fun health_data_is_never_a_search_candidate() {
        assertTrue(CrisSearchPolicy.hasPersonalData("minha glicemia está 250 mg/dl, o que faço?", ""))
        assertTrue(CrisSearchPolicy.hasPersonalData("tomei 10 unidades de insulina", ""))
        assertFalse(CrisSearchPolicy.hasPersonalData("quais as notícias de hoje", ""))
    }

    @Test fun local_ai_cannot_invent_numbers() {
        assertTrue(CrisFactGuard.numbersSupported("O dólar fechou a 5,42.", "Dólar fecha a 5,42 hoje", "cotação"))
        assertFalse(CrisFactGuard.numbersSupported("O dólar fechou a 6,10.", "Dólar fecha a 5,42 hoje", "cotação"))
    }

    // ---- Novos: latência, janela do Tavily, cancelamento, erro por chamada ---------------------------------
    @Test fun slow_gemini_with_fast_search_answers_after_short_patience_not_60s() = runTest {
        var geminiCalls = 0
        val deps = CloudDeps(
            gemini = { geminiCalls++; delay(50_000); GemResult("tarde", searched = true) },
            search = { delay(1_000); web() },
            canSynthesize = { true },
        )
        val out = CrisCloudOrchestrator.run(deps, true, true)
        assertTrue(out is CloudOutcome.SearchOnly && (out as CloudOutcome.SearchOnly).geminiSlow)
        assertEquals(9_000L, currentTime)           // 1 s (pesquisa) + 8 s de paciência
        assertEquals(1, geminiCalls)                // nenhuma 2ª chamada ao Gemini
    }

    @Test fun strong_structured_result_shortens_the_patience() = runTest {
        val strong = web(listOf(hit("Presidente do Brasil", "Lula é o presidente do Brasil.", "https://wikidata.org/x", 120, "Wikidata")))
        val deps = CloudDeps({ delay(50_000); GemResult("tarde") }, { delay(500); strong }, { true })
        CrisCloudOrchestrator.run(deps, true, true)
        assertEquals(3_500L, currentTime)
    }

    @Test fun gemini_arriving_within_patience_is_used() = runTest {
        val deps = CloudDeps({ delay(5_000); GemResult(CONSISTENT_ANSWER, searched = true) }, { delay(1_000); web() }, { true })
        val out = CrisCloudOrchestrator.run(deps, true, true)
        assertTrue(out is CloudOutcome.GeminiAnswer)
        assertEquals(5_000L, currentTime)
    }

    @Test fun search_finishing_inside_the_grace_is_not_discarded() = runTest {
        val deps = CloudDeps(
            { GemResult("Resposta fundamentada", searched = true, sources = listOf("g1" to "https://g1.globo.com/x")) },
            { delay(3_000); web() },
            { true },
        )
        val out = CrisCloudOrchestrator.run(deps, true, true) as CloudOutcome.GeminiAnswer
        assertTrue(out.web != null)
        assertEquals(3_000L, currentTime)
    }

    @Test fun not_grounded_answer_waits_for_search_then_synthesizes_once() = runTest {
        var calls = 0
        val deps = CloudDeps({ ctx -> calls++; GemResult(if (ctx.isEmpty()) "Não sei informar." else "Síntese") }, { delay(10_000); web() }, { true })
        val out = CrisCloudOrchestrator.run(deps, true, true)
        assertTrue(out is CloudOutcome.Synthesized)
        assertEquals(2, calls)
    }

    @Test fun consistent_answer_not_grounded_needs_no_second_gemini_call() = runTest {
        var calls = 0
        val deps = CloudDeps({ calls++; GemResult(CONSISTENT_ANSWER, searched = false) }, { web() }, { true })
        val out = CrisCloudOrchestrator.run(deps, true, true)
        assertEquals(1, calls)
        assertTrue(out is CloudOutcome.GeminiAnswer && !(out as CloudOutcome.GeminiAnswer).unverified)
    }

    @Test fun early_return_cancels_leftover_work_without_waiting() = runTest {
        var searchCancelled = false
        val deps = CloudDeps(
            { GemResult("fundamentada", searched = true, sources = listOf("g" to "https://g.com/x")) },
            { try { delay(60_000); web() } catch (e: CancellationException) { searchCancelled = true; throw e } },
            { true },
        )
        CrisCloudOrchestrator.run(deps, true, true)
        advanceUntilIdle()
        assertTrue(searchCancelled)
    }

    @Test fun cancelling_a_question_cancels_its_own_services_only() = runTest {
        var aGeminiCancelled = false
        var other: CloudOutcome? = null
        val a = launch {
            CrisCloudOrchestrator.run(CloudDeps({ try { delay(60_000); GemResult("x") } catch (e: CancellationException) { aGeminiCancelled = true; throw e } }, { delay(60_000); web() }, { true }), true, true)
        }
        val b = launch { other = CrisCloudOrchestrator.run(CloudDeps({ delay(2_000); GemResult("B ok") }, { null }, { true }), false, true) }
        delay(500)
        a.cancel()
        b.join()
        advanceUntilIdle()
        assertTrue(aGeminiCancelled)
        assertEquals("B ok", (other as CloudOutcome.GeminiAnswer).gem.text)
    }

    @Test fun concurrent_questions_keep_their_own_errors_and_results() = runTest {
        val a = async { CrisCloudOrchestrator.run(CloudDeps({ delay(300); GemResult(null, error = "HTTP 429 A") }, { null }, { true }), false, true) }
        val b = async { CrisCloudOrchestrator.run(CloudDeps({ delay(100); GemResult(null, error = "HTTP 503 B") }, { null }, { true }), false, true) }
        assertEquals("HTTP 429 A", (a.await() as CloudOutcome.NothingOnline).geminiError)
        assertEquals("HTTP 503 B", (b.await() as CloudOutcome.NothingOnline).geminiError)
    }

    @Test fun concurrent_syntheses_do_not_mix_results() = runTest {
        fun depsFor(q: String, d: Long) = CloudDeps(
            { ctx -> delay(d); if (ctx.isEmpty()) GemResult("Não sei $q.") else GemResult("síntese-$q") },
            { delay(d / 2); web(listOf(hit("Presidente Lula sancionou lei do Orçamento Federal", "Presidente Lula sancionou o Orçamento Federal em Brasília.", "https://x.gov.br/$q", 30))) },
            { true },
        )
        val a = async { CrisCloudOrchestrator.run(depsFor("A", 2_000), true, true) }
        val b = async { CrisCloudOrchestrator.run(depsFor("B", 500), true, true) }
        assertEquals("síntese-A", (a.await() as CloudOutcome.Synthesized).gem.text)
        assertEquals("síntese-B", (b.await() as CloudOutcome.Synthesized).gem.text)
    }

    // ---- Novos: divergências e revisão local ---------------------------------------------------------------
    private val dollarHits = listOf(hit("Dólar fecha a R$ 5,42 nesta quinta", "O dólar comercial fechou a R$ 5,42 nesta quinta-feira.", "https://news.example.com/d", 20))

    @Test fun number_conflict_is_a_suspicion_and_formatting_differences_are_not_conflicts() {
        assertEquals(Verdict.CONFLICT, CrisAnswerCheck.assess("O dólar comercial fechou a R$ 5,10 nesta quinta.", dollarHits).verdict)
        assertEquals(Verdict.CONSISTENT, CrisAnswerCheck.assess("O dólar comercial fechou a 5.42 nesta quinta.", dollarHits).verdict)
    }

    @Test fun unrelated_answer_is_weak_not_conflict_and_no_answer_is_detected() {
        assertEquals(Verdict.WEAK, CrisAnswerCheck.assess("A capital da França fica às margens do rio Sena.", dollarHits).verdict)
        assertEquals(Verdict.NO_ANSWER, CrisAnswerCheck.assess("Não sei informar isso.", dollarHits).verdict)
        assertEquals(Verdict.INCONCLUSIVE, CrisAnswerCheck.assess("qualquer", emptyList()).verdict)
    }

    @Test fun sources_that_disagree_between_themselves_are_flagged() {
        val hits = listOf(
            hit("Dólar fecha a R$ 5,42 nesta quinta", "O dólar comercial fechou a R$ 5,42 nesta quinta-feira.", "https://a.com/1", 20),
            hit("Dólar fecha a R$ 5,10 nesta quinta", "O dólar comercial fechou a R$ 5,10 nesta quinta-feira.", "https://b.com/2", 15),
        )
        assertTrue(CrisAnswerCheck.sourcesDisagree(hits))
        assertFalse(CrisAnswerCheck.sourcesDisagree(dollarHits))
    }

    @Test fun conflict_without_quota_reports_a_suspicion_with_sources_kept() = runTest {
        val deps = CloudDeps({ GemResult("O dólar comercial fechou a R$ 5,10 nesta quinta.", searched = false) }, { web(dollarHits) }, { false })
        val out = CrisCloudOrchestrator.run(deps, true, true) as CloudOutcome.AnswerPlusResults
        assertEquals(Verdict.CONFLICT, out.assessment.verdict)
        assertTrue(out.divergent)
        assertEquals(1, out.web.hits.size)
    }

    @Test fun local_review_plan_translates_summarizes_and_flags_contradictions_only_when_useful() {
        val foreign = listOf(hit("Central bank raises rates", "The central bank said that the rates are going to rise in the next quarter for the economy.", "https://x.com/1", 10))
        assertTrue(LocalTask.TRANSLATE in CrisLocalReview.plan(web(foreign), null, null).tasks)
        assertTrue(CrisLocalReview.plan(web(emptyList()), null, null).tasks.isEmpty())
        assertFalse(CrisLocalReview.plan(web(listOf(hit("Oi", "ok", "https://x.com/z", 1))), null, null).worthIt)   // curto: sem chamada local
        val conflict = CrisLocalReview.plan(web(dollarHits), "resposta", AnswerAssessment(Verdict.CONFLICT))
        assertTrue(LocalTask.CONTRADICTIONS in conflict.tasks)
        val clarityAlone = LocalReviewPlan(setOf(LocalTask.CLARIFY))
        assertFalse(clarityAlone.worthIt)           // clareza sozinha nunca justifica uma chamada
    }

    @Test fun local_review_runs_once_and_only_when_worth_it() = runTest {
        var reviews = 0
        var seenPlan: LocalReviewPlan? = null
        val deps = CloudDeps(
            gemini = { GemResult("Não sei informar.", searched = false) },
            search = { web() },
            canSynthesize = { false },
            localReview = { r -> reviews++; seenPlan = r.plan; "Resumo local" },
        )
        val out = CrisCloudOrchestrator.run(deps, true, true) as CloudOutcome.AnswerPlusResults
        assertEquals(1, reviews)
        assertTrue(LocalTask.SUMMARIZE in seenPlan!!.tasks)
        assertEquals("Resumo local", out.localSummary)
        // resposta consistente: nenhuma chamada local
        reviews = 0
        val ok = CloudDeps({ GemResult(CONSISTENT_ANSWER, searched = true) }, { web() }, { false }, localReview = { reviews++; "x" })
        CrisCloudOrchestrator.run(ok, true, true)
        assertEquals(0, reviews)
    }

    @Test fun local_output_with_invented_number_is_rejected_by_the_review_guard() {
        val w = web(dollarHits).copy(promptBlock = "Dólar fechou a R$ 5,42 nesta quinta")
        assertTrue(CrisLocalReview.isSafe("O dólar fechou a 5.42.", w, null, "dólar hoje"))
        assertFalse(CrisLocalReview.isSafe("O dólar fechou a 6,10.", w, null, "dólar hoje"))
    }

    // ---- Novos: privacidade --------------------------------------------------------------------------------
    @Test fun history_with_personal_data_is_scrubbed_before_google_search_requests() {
        val h = listOf(true to "minha glicemia está 250 mg/dl", false to "Sua glicemia de 250 mg/dl está alta.", true to "quais as notícias de hoje")
        val s = CrisSearchPolicy.scrubHistory(h, "Maria")
        assertFalse(s[0].second.contains("250"))
        assertFalse(s[1].second.contains("250"))
        assertEquals("quais as notícias de hoje", s[2].second)
    }

    @Test fun redact_removes_personal_data_and_health_context_rule() {
        val r = CrisSearchPolicy.redact("quem é o presidente do Brasil, Maria, tomei 10 unidades e minha glicemia 250 mg/dl", "Maria")
        assertFalse(r.contains("Maria")); assertFalse(r.contains("250")); assertFalse(r.contains("10 unidades"))
        assertTrue(CrisSearchPolicy.needsPersonalContext("o que posso comer no jantar?"))
        assertTrue(CrisSearchPolicy.needsPersonalContext("e agora?", "minha glicemia está alta"))
        assertFalse(CrisSearchPolicy.needsPersonalContext("quais as notícias de hoje"))
    }
}
