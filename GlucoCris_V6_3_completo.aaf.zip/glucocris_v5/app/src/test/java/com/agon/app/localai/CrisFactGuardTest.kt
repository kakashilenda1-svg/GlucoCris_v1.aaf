package com.agon.app.localai

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Lógica pura: formatação numérica equivalente é aceita; número, data ou dose inventados são rejeitados. */
class CrisFactGuardTest {
    private fun ok(out: String, src: String, q: String = "") = CrisFactGuard.verify(out, listOf(src), q).ok

    @Test fun numeric_formatting_differences_are_accepted() {
        assertTrue(ok("O dólar fechou a 5,42.", "Dólar fecha a 5.42"))
        assertTrue(ok("Fechou a R$ 5,42.", "cotação 5,42"))
        assertTrue(ok("São 1.000 casos.", "foram 1000 casos"))
        assertTrue(ok("São 1000 casos.", "foram 1.000 casos"))
        assertTrue(ok("Cerca de 1,5 milhão de pessoas.", "1.500.000 pessoas"))
        assertTrue(ok("A taxa subiu 12%.", "alta de 12 por cento"))
        assertTrue(ok("Valor de 5,40.", "valor de 5,4"))
    }

    @Test fun invented_numbers_are_rejected() {
        assertFalse(ok("O dólar fechou a 6,10.", "Dólar fecha a 5,42"))
        assertFalse(ok("Foram 2.300 casos.", "foram 1.000 casos"))
        assertFalse(ok("Subiu 15%.", "subiu 12%"))
    }

    @Test fun small_loose_integers_are_not_charged() {
        assertTrue(ok("Há 2 estudos sobre o tema.", "estudos sobre o tema"))
    }

    @Test fun dates_match_across_formats_and_invented_dates_fail() {
        assertTrue(ok("Sancionada em 12 de novembro de 2026.", "sancionada em 12/11/2026"))
        assertTrue(ok("Sancionada em 12/11/2026.", "sancionada em 12 de novembro de 2026"))
        assertTrue(ok("Em 12/11.", "dia 12/11/2026"))
        assertFalse(ok("Sancionada em 13/11/2026.", "sancionada em 12/11/2026"))
        assertFalse(ok("Sancionada em 12/11/2025.", "sancionada em 12/11/2026"))
    }

    @Test fun doses_must_come_from_the_sources_with_the_same_unit() {
        assertTrue(ok("A bula cita 10 mg por dia.", "dose de 10 mg por dia"))
        assertTrue(ok("A bula cita 10 miligramas.", "dose de 10mg"))
        assertFalse(ok("A bula cita 20 mg.", "dose de 10 mg"))
        assertFalse(ok("Use 10 UI.", "dose de 10 mg"))
        assertTrue(ok("Entre 5 e 10 mg.", "de 5 a 10 mg"))
        assertFalse(ok("Use 10 UI.", "texto sem dose", q = "posso tomar 10 UI?"))   // a pergunta não vale como fonte de dose
    }
}
