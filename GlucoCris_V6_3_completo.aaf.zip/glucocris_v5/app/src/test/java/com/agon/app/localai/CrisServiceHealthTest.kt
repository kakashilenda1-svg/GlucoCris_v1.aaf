package com.agon.app.localai

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Lógica pura do status e das mensagens de fallback da Cris (nenhuma chamada de rede). */
class CrisServiceHealthTest {
    private val now = 1_000_000_000L
    private val fresh = now - 60_000L

    @Test fun gemini429_is_quota() {
        assertEquals(ServiceState.QUOTA, CrisServiceHealth.classifyGeminiError("cota do Gemini esgotada no modelo x (HTTP 429)"))
        assertEquals(ServiceState.QUOTA, CrisServiceHealth.classifyGeminiError("limite diário do Worker atingido (gemini_quota)"))
    }

    @Test fun gemini503_and_timeout_are_unavailable_not_quota() {
        assertEquals(ServiceState.UNAVAILABLE, CrisServiceHealth.classifyGeminiError("servidor instável (HTTP 503)"))
        assertEquals(ServiceState.UNAVAILABLE, CrisServiceHealth.classifyGeminiError("timeout"))
        assertEquals(ServiceState.UNAVAILABLE, CrisServiceHealth.classifyGeminiError("resposta vazia (STOP)"))
    }

    @Test fun offline_headline_does_not_blame_services() {
        val h = CrisHealth(gemini = ServiceState.QUOTA, geminiAt = fresh)
        assertEquals("sem internet · sem IA local", CrisServiceHealth.headline(false, false, h, now))
        assertEquals("IA no aparelho · sem internet", CrisServiceHealth.headline(false, true, h, now))
    }

    @Test fun online_with_only_gemini_out_is_not_called_offline() {
        val h = CrisHealth(gemini = ServiceState.QUOTA, geminiAt = fresh)
        val s = CrisServiceHealth.headline(true, false, h, now)
        assertEquals("online · Gemini sem cota", s)
        assertFalse("offline" in s || "sem internet" in s)
    }

    @Test fun each_service_has_its_own_message() {
        val h = CrisHealth(gemini = ServiceState.UNAVAILABLE, geminiAt = fresh, tavily = ServiceState.QUOTA, tavilyAt = fresh)
        assertEquals("online · Gemini indisponível · busca sem cota", CrisServiceHealth.headline(true, false, h, now))
        val t = CrisHealth(tavily = ServiceState.UNAVAILABLE, tavilyAt = fresh)
        assertEquals("IA no aparelho · online · busca indisponível", CrisServiceHealth.headline(true, true, t, now))
    }

    @Test fun stale_failures_are_ignored() {
        val old = now - CrisServiceHealth.FRESH_MS - 1
        val h = CrisHealth(gemini = ServiceState.QUOTA, geminiAt = old)
        assertEquals("online · IA local não instalada", CrisServiceHealth.headline(true, false, h, now))
        assertEquals("IA no aparelho · online", CrisServiceHealth.headline(true, true, h, now))
    }

    @Test fun local_not_installed_is_a_status_not_an_error() {
        val s = CrisServiceHealth.headline(true, false, CrisHealth(), now)
        assertTrue("IA local" in s)
        assertFalse("erro" in s.lowercase())
    }

    @Test fun all_down_message_is_honest_and_never_promises_an_answer() {
        val offline = CrisServiceHealth.allDownMessage(false, false, "")
        assertTrue("sem internet" in offline && "Não vou inventar" in offline)
        val online = CrisServiceHealth.allDownMessage(true, false, "servidor instável (HTTP 503)")
        assertTrue("não respondeu" in online && "Não vou inventar" in online)
        val quota = CrisServiceHealth.allDownMessage(true, true, "HTTP 429")
        assertTrue("sem cota" in quota && "modelo local também não respondeu" in quota)
    }

    @Test fun failure_note_has_no_internal_details() {
        val n = CrisServiceHealth.geminiFailureNote("proxy HTTP 503 raw={...} model=gemini-3.8-flash")
        assertFalse("gemini-3.8" in n || "HTTP" in n)
    }

    @Test fun state_flow_records_real_results() {
        CrisServiceHealth.gemini(ServiceState.OK, now)
        CrisServiceHealth.tavily(ServiceState.QUOTA, now)
        val s = CrisServiceHealth.state.value
        assertEquals(ServiceState.OK, s.gemini)
        assertEquals(ServiceState.QUOTA, s.tavily)
    }

    @Test fun worker_down_is_one_message_not_two_blamed_services() {
        val h = CrisHealth(
            gemini = ServiceState.UNAVAILABLE, geminiAt = fresh,
            tavily = ServiceState.UNAVAILABLE, tavilyAt = fresh,
            worker = ServiceState.UNAVAILABLE, workerAt = fresh,
        )
        assertEquals("online · servidor da Cris indisponível", CrisServiceHealth.headline(true, false, h, now))
    }

    @Test fun tavily_not_configured_and_local_error_have_own_messages() {
        val h = CrisHealth(tavily = ServiceState.NOT_CONFIGURED, tavilyAt = fresh, localError = true, localAt = fresh)
        assertEquals("IA no aparelho · online · busca não configurada · IA local com erro", CrisServiceHealth.headline(true, true, h, now, localInstalled = true))
    }

    @Test fun local_error_is_hidden_when_model_not_installed() {
        val h = CrisHealth(localError = true, localAt = fresh)
        assertEquals("online · IA local não instalada", CrisServiceHealth.headline(true, false, h, now, localInstalled = false))
    }

    @Test fun concurrent_updates_do_not_overwrite_each_other() {
        CrisServiceHealth.gemini(ServiceState.QUOTA, now)
        CrisServiceHealth.tavily(ServiceState.OK, now)
        CrisServiceHealth.worker(ServiceState.OK, now)
        val s = CrisServiceHealth.state.value
        assertEquals(ServiceState.QUOTA, s.gemini)
        assertEquals(ServiceState.OK, s.tavily)
        assertEquals(ServiceState.OK, s.worker)
    }
}
