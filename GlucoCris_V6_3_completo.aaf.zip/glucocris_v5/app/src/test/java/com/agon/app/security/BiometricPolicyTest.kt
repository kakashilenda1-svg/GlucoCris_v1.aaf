package com.agon.app.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BiometricPolicyTest {
    // códigos de BiometricManager: 0 ok, 1 indisponível, 11 sem cadastro, 12 sem hardware, 15 atualização, -2 não suportado, -1 desconhecido
    @Test fun availability_mapping_never_presumes_support() {
        assertEquals(Availability.AVAILABLE, BiometricPolicy.availability(0))
        assertEquals(Availability.NONE_ENROLLED, BiometricPolicy.availability(11))
        assertEquals(Availability.NO_HARDWARE, BiometricPolicy.availability(12))
        assertEquals(Availability.TEMPORARILY_UNAVAILABLE, BiometricPolicy.availability(1))
        assertEquals(Availability.UPDATE_REQUIRED, BiometricPolicy.availability(15))
        assertEquals(Availability.UNSUPPORTED, BiometricPolicy.availability(-2))
        assertEquals(Availability.UNSUPPORTED, BiometricPolicy.availability(-1))
        assertEquals(Availability.UNSUPPORTED, BiometricPolicy.availability(999))
    }

    @Test fun protection_is_required_only_with_the_master_switch_and_at_least_one_modality() {
        assertFalse(BiometricPolicy.protectionRequired(true, false, false))    // ambas desativadas: abre normalmente
        assertTrue(BiometricPolicy.protectionRequired(true, true, false))      // só digital
        assertTrue(BiometricPolicy.protectionRequired(true, false, true))      // só rosto
        assertTrue(BiometricPolicy.protectionRequired(true, true, true))       // ambas
        assertFalse(BiometricPolicy.protectionRequired(false, true, true))     // chave geral desligada
    }

    @Test fun fingerprint_and_face_can_be_enabled_when_strong_biometric_is_enrolled() {
        assertEquals(EnableDecision.ALLOWED, BiometricPolicy.canEnable(true, Availability.AVAILABLE))
    }

    @Test fun not_enrolled_asks_the_user_to_enroll_in_android_settings() {
        val d = BiometricPolicy.canEnable(true, Availability.NONE_ENROLLED)
        assertEquals(EnableDecision.NEED_ENROLL, d)
        assertTrue(BiometricPolicy.enableMessage(d, Modality.FINGERPRINT).contains("configurações do Android"))
    }

    @Test fun incompatible_device_cannot_enable_the_modality() {
        assertEquals(EnableDecision.INCOMPATIBLE_DEVICE, BiometricPolicy.canEnable(false, Availability.AVAILABLE))   // sem o sensor
        assertEquals(EnableDecision.INCOMPATIBLE_DEVICE, BiometricPolicy.canEnable(true, Availability.NO_HARDWARE))
        assertEquals(EnableDecision.INCOMPATIBLE_DEVICE, BiometricPolicy.canEnable(true, Availability.UNSUPPORTED))   // ex.: rosto só "fraco"
        assertTrue(BiometricPolicy.enableMessage(EnableDecision.INCOMPATIBLE_DEVICE, Modality.FACE).contains("biometria forte"))
    }

    @Test fun cancel_lockout_and_errors_are_classified_and_never_success() {
        assertEquals(AuthFailure.CANCELED, BiometricPolicy.classifyError(10))   // USER_CANCELED
        assertEquals(AuthFailure.CANCELED, BiometricPolicy.classifyError(13))   // NEGATIVE_BUTTON
        assertEquals(AuthFailure.CANCELED, BiometricPolicy.classifyError(5))    // CANCELED
        assertEquals(AuthFailure.LOCKED_OUT, BiometricPolicy.classifyError(7))
        assertEquals(AuthFailure.LOCKED_OUT, BiometricPolicy.classifyError(9))
        assertEquals(AuthFailure.NOT_ENROLLED, BiometricPolicy.classifyError(11))
        assertEquals(AuthFailure.UNAVAILABLE, BiometricPolicy.classifyError(12))
        assertEquals(AuthFailure.OTHER, BiometricPolicy.classifyError(8))
        AuthFailure.values().forEach { assertTrue(BiometricPolicy.lockMessage(it).isNotBlank()) }
    }

    // item 13: modalidade não suportada / limitação do Android (sem prometer restrição que não existe)
    @Test fun exclusive_choice_is_flagged_when_the_other_sensor_could_also_unlock() {
        assertEquals(Limitation.FACE_COULD_ALSO_UNLOCK, BiometricPolicy.limitation(true, true, true, false))
        assertEquals(Limitation.FINGERPRINT_COULD_ALSO_UNLOCK, BiometricPolicy.limitation(true, true, false, true))
        assertEquals(Limitation.NONE, BiometricPolicy.limitation(true, true, true, true))      // ambas permitidas
        assertEquals(Limitation.NONE, BiometricPolicy.limitation(true, false, true, false))    // aparelho só tem digital
        assertEquals(Limitation.NONE, BiometricPolicy.limitation(false, true, false, true))    // aparelho só tem rosto
        assertTrue(BiometricPolicy.limitationMessage(Limitation.FACE_COULD_ALSO_UNLOCK).contains("SÓ a digital"))
        assertTrue(BiometricPolicy.limitationMessage(Limitation.FINGERPRINT_COULD_ALSO_UNLOCK).contains("SÓ o rosto"))
        assertEquals("", BiometricPolicy.limitationMessage(Limitation.NONE))
    }

    @Test fun enable_messages_name_the_modality_or_just_biometrics() {
        assertTrue(BiometricPolicy.enableMessage(EnableDecision.INCOMPATIBLE_DEVICE, null).contains("biometria"))
        assertTrue(BiometricPolicy.enableMessage(EnableDecision.INCOMPATIBLE_DEVICE, Modality.FACE).contains("reconhecimento facial"))
        assertTrue(BiometricPolicy.enableMessage(EnableDecision.TEMPORARILY_UNAVAILABLE, Modality.FINGERPRINT).contains("indisponível"))
        assertTrue(BiometricPolicy.enableMessage(EnableDecision.UPDATE_REQUIRED, null).contains("atualização"))
    }

    // item 12 e situações especiais: nunca desativa em silêncio e todas as situações têm mensagem
    @Test fun every_availability_and_failure_has_a_clear_message() {
        Availability.values().forEach { assertTrue(BiometricPolicy.availabilityMessage(it).isNotBlank()) }
        assertTrue(BiometricPolicy.lockMessage(AuthFailure.CANCELED).contains("continua bloqueado"))
        assertTrue(BiometricPolicy.lockMessage(AuthFailure.NOT_ENROLLED).contains("Nenhuma biometria"))
        assertTrue(BiometricPolicy.lockMessage(AuthFailure.LOCKED_OUT).contains("tentativas"))
        assertTrue(BiometricPolicy.enrollmentChangedMessage().contains("mudaram"))
    }

    @Test fun pin_recovery_is_offered_only_when_the_device_biometrics_are_gone() {
        assertTrue(BiometricPolicy.recoveryAllowed(true, Availability.NONE_ENROLLED))
        assertTrue(BiometricPolicy.recoveryAllowed(true, Availability.NO_HARDWARE))
        assertTrue(BiometricPolicy.recoveryAllowed(true, Availability.UNSUPPORTED))
        assertTrue(BiometricPolicy.recoveryAllowed(true, Availability.UPDATE_REQUIRED))
        assertFalse(BiometricPolicy.recoveryAllowed(true, Availability.AVAILABLE))               // cancelar/recusar não abre o app
        assertFalse(BiometricPolicy.recoveryAllowed(true, Availability.TEMPORARILY_UNAVAILABLE)) // bloqueio temporário também não
        Availability.values().forEach { assertFalse(BiometricPolicy.recoveryAllowed(false, it)) } // sem PIN não há recuperação
    }
}
