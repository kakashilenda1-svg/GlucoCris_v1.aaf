package com.agon.app.security

import java.io.File
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Prova ESTRUTURAL (lê o código-fonte): confere a LIGAÇÃO no código. Não substitui o teste no aparelho.
 *  - a única composição do app (MainApp e as telas de carregamento, login, PIN e escolha da IA) fica no ramo "else" de
 *    `if (secLocked)`, e o único ramo bloqueado é a SecurityLockScreen (item 15);
 *  - entradas por notificação/atalho só gravam um pedido, que o MainApp consome depois do desbloqueio (item 16);
 *  - uma única janela de biometria por vez (item 17);
 *  - a configuração antiga de biometria não existe mais em paralelo (item 14 / seção 4).
 */
class GateWiringTest {
    private fun read(rel: String): String {
        val candidates = listOf(File(rel), File("app/$rel"))
        return candidates.first { it.exists() }.readText()
    }

    private fun exists(rel: String): Boolean = listOf(File(rel), File("app/$rel")).any { it.exists() }

    private val main = "src/main/java/com/agon/app/MainActivity.kt"

    @Test fun main_app_is_only_reachable_inside_the_unlocked_branch() {
        val s = read(main)
        val gate = s.indexOf("if (secLocked) {")
        val lockScreen = s.indexOf("SecurityLockScreen(")
        val elseBranch = s.indexOf("} else {", lockScreen)
        val mainApp = s.indexOf("else -> MainApp(")
        val loading = s.indexOf("LoadingState()")
        val pin = s.indexOf("LockScreen(vm, data.settings.displayName)")
        val login = s.indexOf("LoginScreen(vm)")
        assertTrue(gate > 0 && lockScreen > gate && elseBranch > lockScreen)
        listOf(mainApp, loading, pin, login).forEach { assertTrue("composição fora do ramo desbloqueado", it > elseBranch) }
        val calls = Regex("MainApp\\(").findAll(s).count() - Regex("fun MainApp\\(").findAll(s).count()
        assertEquals(1, calls)
    }

    @Test fun session_starts_locked_and_reads_the_preference_before_the_first_screen() {
        val s = read(main)
        assertTrue(s.indexOf("security.init(securityRequired())") in 1 until s.indexOf("setContent {"))
        assertTrue(s.contains("clearSession(applicationContext)"))   // marca de sessão antiga é descartada em sessão nova
        val vm = read("src/main/java/com/agon/app/security/SecurityViewModel.kt")
        assertTrue(vm.contains("MutableStateFlow(true)"))
    }

    @Test fun background_policy_uses_the_saved_setting_the_stamp_and_ignores_rotation() {
        val s = read(main)
        assertTrue(s.contains("flags.relock.millis"))
        assertTrue(s.contains("sessionStampValid(applicationContext)"))
        assertTrue(s.contains("if (!isChangingConfigurations) security.onBackground"))
        assertFalse("sem tolerância fixa de 30 s", read("src/main/java/com/agon/app/security/SessionLock.kt").contains("RELOCK_AFTER_MS"))
    }

    @Test fun window_is_secure_while_locked_and_recents_screenshots_are_off() {
        val s = read(main)
        assertTrue(s.contains("FLAG_SECURE"))
        assertTrue(s.contains("if (locked) window.setFlags"))
        assertTrue(s.contains("setRecentsScreenshotEnabled(false)"))
    }

    @Test fun only_strong_biometrics_and_no_device_credential_fallback() {
        val s = read("src/main/java/com/agon/app/security/BiometricAuth.kt")
        assertTrue(s.contains("BIOMETRIC_STRONG"))
        assertTrue(!s.contains("BIOMETRIC_WEAK") && !s.contains("DEVICE_CREDENTIAL"))
    }

    @Test fun a_single_biometric_window_at_a_time() {
        val s = read("src/main/java/com/agon/app/security/BiometricAuth.kt")
        assertTrue(s.contains("compareAndSet(false, true)"))
        val screen = read("src/main/java/com/agon/app/ui/screens/SecurityLockScreen.kt")
        assertTrue(screen.contains("security.beginPrompt(auto)"))
    }

    // item 16: notificações, atalhos e navegação interna
    @Test fun notification_and_shortcut_requests_are_only_consumed_after_unlock() {
        val s = read(main)
        val mainAppFun = s.indexOf("private fun MainApp(")
        assertTrue(mainAppFun > 0)
        assertTrue("OpenRoute só é consumido dentro do MainApp", s.indexOf("OpenRoute.route.value = null") > mainAppFun)
        assertTrue("navegação só dentro do MainApp", s.indexOf("nav.navigate(r)") > mainAppFun)
        val handler = s.substring(s.indexOf("private fun handleCrisIntent"), s.indexOf("override fun onNewIntent"))
        assertFalse("o tratamento da intent não navega nem abre telas", handler.contains("navigate") || handler.contains("startActivity"))
    }

    @Test fun only_the_launcher_activity_is_exported() {
        val m = read("src/main/AndroidManifest.xml")
        val activities = Regex("<activity[^>]*?>", RegexOption.DOT_MATCHES_ALL).findAll(m).map { it.value }.toList()
        val exported = activities.filter { it.contains("android:exported=\"true\"") }
        assertEquals(1, exported.size)
        assertTrue(exported[0].contains("MainActivity"))
    }

    // seção 4: configurações duplicadas
    @Test fun the_old_biometric_control_no_longer_runs_in_parallel() {
        assertFalse("BiometricHelper (fraca) foi removido", exists("src/main/java/com/agon/app/ui/screens/BiometricHelper.kt"))
        val settings = read("src/main/java/com/agon/app/ui/screens/MedsReportSettingsScreens.kt")
        assertFalse(settings.contains("BiometricHelper") || settings.contains("biometricEnabled = true"))
        assertFalse(settings.contains("\"Entrar com digital ou rosto\""))
        val pinScreen = read("src/main/java/com/agon/app/ui/screens/LockScreen.kt")
        assertFalse(pinScreen.contains("BiometricHelper") || pinScreen.contains("Entrar com digital ou rosto"))
        val vm = read("src/main/java/com/agon/app/data/GlucoViewModel.kt")
        assertFalse(vm.contains("fun unlockWithBiometric"))
    }

    @Test fun there_is_exactly_one_biometric_settings_section_in_the_settings_screen() {
        val settings = read("src/main/java/com/agon/app/ui/screens/MedsReportSettingsScreens.kt")
        assertEquals(1, Regex("SecurityPrivacySection\\(").findAll(settings).count())
        val sec = read("src/main/java/com/agon/app/ui/screens/SecuritySettings.kt")
        assertTrue(sec.contains("SectionTitle(\"Segurança e privacidade\")"))
        assertTrue(sec.contains("\"Bloqueio biométrico\""))
        assertTrue(sec.contains("\"Impressão digital\"") && sec.contains("\"Reconhecimento facial\""))
    }

    @Test fun no_biometric_image_or_template_is_ever_stored() {
        val prefs = read("src/main/java/com/agon/app/security/SecurityPrefs.kt")
        assertTrue(prefs.contains("AndroidKeyStore"))
        listOf("Bitmap", "ImageFormat", "FileOutputStream").forEach { assertFalse(prefs.contains(it)) }
    }
}
