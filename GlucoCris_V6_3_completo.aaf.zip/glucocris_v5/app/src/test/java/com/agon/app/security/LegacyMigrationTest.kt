package com.agon.app.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** Item 14: migração da antiga opção "Entrar com digital ou rosto". */
class LegacyMigrationTest {
    @Test fun legacy_off_means_nothing_to_migrate() {
        val p = LegacyMigration.plan(false, false, Availability.AVAILABLE, true, true)
        assertFalse(p.enableNew); assertFalse(p.clearLegacy); assertEquals(LegacyMigration.Note.NONE, p.note)
    }

    @Test fun legacy_on_with_strong_biometrics_turns_the_new_lock_on_with_the_sensors_the_device_has() {
        val both = LegacyMigration.plan(true, false, Availability.AVAILABLE, hasFingerprint = true, hasFace = true)
        assertTrue(both.enableNew); assertTrue(both.fingerprint); assertTrue(both.face); assertTrue(both.clearLegacy)
        assertEquals(LegacyMigration.Note.MIGRATED, both.note)
        val fpOnly = LegacyMigration.plan(true, false, Availability.AVAILABLE, hasFingerprint = true, hasFace = false)
        assertTrue(fpOnly.fingerprint); assertFalse(fpOnly.face)
    }

    @Test fun legacy_on_without_strong_biometrics_does_not_lock_the_user_out_and_says_why() {
        for (a in listOf(Availability.NONE_ENROLLED, Availability.NO_HARDWARE, Availability.UNSUPPORTED, Availability.TEMPORARILY_UNAVAILABLE)) {
            val p = LegacyMigration.plan(true, false, a, true, true)
            assertFalse(p.enableNew)
            assertTrue(p.clearLegacy)   // o controle antigo não continua em paralelo
            assertEquals(LegacyMigration.Note.NOT_MIGRATED_WEAK_OR_MISSING, p.note)
        }
        // sem nenhum sensor declarado também não liga
        assertFalse(LegacyMigration.plan(true, false, Availability.AVAILABLE, false, false).enableNew)
    }

    @Test fun an_existing_new_configuration_is_never_overwritten() {
        val p = LegacyMigration.plan(true, newConfigured = true, strong = Availability.AVAILABLE, hasFingerprint = true, hasFace = true)
        assertFalse(p.enableNew); assertTrue(p.clearLegacy); assertEquals(LegacyMigration.Note.ALREADY_CONFIGURED, p.note)
    }
}
