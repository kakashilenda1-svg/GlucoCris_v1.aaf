package com.agon.app.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SecurityCodecTest {
    private val macOf: (String) -> String = { "sig:" + it.reversed() }

    private fun roundTrip(on: Boolean, fp: Boolean, face: Boolean, rl: RelockPolicy = RelockPolicy.DEFAULT): SecurityCodec.Flags {
        val payload = SecurityCodec.encode(on, fp, face, rl)
        return SecurityCodec.decode(payload, macOf(payload), macOf)
    }

    @Test fun round_trip_for_every_combination_and_policy() {
        for (on in listOf(false, true)) for (fp in listOf(false, true)) for (face in listOf(false, true)) for (rl in RelockPolicy.values()) {
            val f = roundTrip(on, fp, face, rl)
            assertEquals(on, f.enabled); assertEquals(fp, f.fingerprint); assertEquals(face, f.face); assertEquals(rl, f.relock)
            assertFalse(f.tampered); assertTrue(f.configured)
            assertEquals(on && (fp || face), f.required)
        }
    }

    // itens 1 a 4 do prompt: digital, rosto, ambas, nenhuma
    @Test fun fingerprint_only_face_only_both_and_none() {
        assertTrue(roundTrip(true, true, false).required)    // só digital
        assertTrue(roundTrip(true, false, true).required)    // só rosto
        assertTrue(roundTrip(true, true, true).required)     // ambas
        assertFalse(roundTrip(true, false, false).required)  // ambas desativadas: abre normalmente
        assertFalse(roundTrip(false, true, true).required)   // chave geral desligada: abre normalmente, escolhas lembradas
    }

    @Test fun never_configured_means_off_and_is_reported_as_not_configured() {
        val f = SecurityCodec.decode(null, null, macOf)
        assertFalse(f.required); assertFalse(f.tampered); assertFalse(f.configured)
    }

    @Test fun altered_or_unsigned_data_fails_closed_with_everything_on_and_immediate_relock() {
        val payload = SecurityCodec.encode(true, true, false, RelockPolicy.AFTER_5MIN)
        val flipped = SecurityCodec.decode(SecurityCodec.encode(false, false, false, RelockPolicy.AFTER_5MIN), macOf(payload), macOf)
        assertTrue(flipped.tampered); assertTrue(flipped.enabled); assertTrue(flipped.fingerprint); assertTrue(flipped.face)
        assertEquals(RelockPolicy.IMMEDIATE, flipped.relock); assertTrue(flipped.required)
        assertTrue(SecurityCodec.decode(payload, null, macOf).tampered)
        assertTrue(SecurityCodec.decode("lixo", macOf("lixo"), macOf).tampered)
        assertTrue(SecurityCodec.decode("v2;on=1;fp=2;face=0;rl=60", macOf("v2;on=1;fp=2;face=0;rl=60"), macOf).tampered)
        assertTrue(SecurityCodec.decode("v2;on=1;fp=1;face=0;rl=7", macOf("v2;on=1;fp=1;face=0;rl=7"), macOf).tampered)
        assertTrue(SecurityCodec.decode("v3;on=1", macOf("v3;on=1"), macOf).tampered)
    }

    // item 14: migração das configurações da versão anterior (v1 só tinha digital/rosto)
    @Test fun previous_version_v1_preferences_are_still_read_and_keep_their_protection() {
        val v1 = "v1;fp=1;face=0"
        val f = SecurityCodec.decode(v1, macOf(v1), macOf)
        assertTrue(f.required); assertTrue(f.fingerprint); assertFalse(f.face); assertTrue(f.enabled)
        assertEquals(RelockPolicy.DEFAULT, f.relock); assertFalse(f.tampered)
        val off = "v1;fp=0;face=0"
        assertFalse(SecurityCodec.decode(off, macOf(off), macOf).required)
    }

    @Test fun stored_text_contains_only_preferences_no_biometric_data() {
        val p = SecurityCodec.encode(true, true, true, RelockPolicy.AFTER_30S)
        assertEquals("v2;on=1;fp=1;face=1;rl=30", p)
        assertNotEquals("", p)
    }

    @Test fun relock_policy_lookup_defaults_safely() {
        assertEquals(RelockPolicy.IMMEDIATE, RelockPolicy.fromSeconds(0))
        assertEquals(RelockPolicy.AFTER_5MIN, RelockPolicy.fromSeconds(300))
        assertEquals(RelockPolicy.DEFAULT, RelockPolicy.fromSeconds(null))
        assertEquals(RelockPolicy.DEFAULT, RelockPolicy.fromSeconds(42))
    }
}
