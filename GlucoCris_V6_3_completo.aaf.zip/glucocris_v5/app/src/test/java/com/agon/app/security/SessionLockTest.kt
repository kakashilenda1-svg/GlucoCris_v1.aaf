package com.agon.app.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class SessionLockTest {
    private fun lock(required: Boolean = true) = SessionLock().also { it.start(required) }
    private fun unlocked(): SessionLock = lock().also { it.beginPrompt(true); it.onSuccess() }

    // itens 5, 6, 7, 8: nova abertura / processo encerrado / processo recriado / celular reiniciado
    @Test fun every_new_session_with_protection_starts_locked_and_without_it_starts_open() {
        assertTrue(lock(true).locked)
        assertFalse(lock(false).locked)
    }

    @Test fun a_new_session_is_locked_even_if_the_previous_session_had_just_been_unlocked() {
        val old = unlocked()
        assertFalse(old.locked)
        // processo encerrado e aberto de novo / Android recriou o processo / reinício: objeto novo, sem herdar nada
        val reopened = SessionLock().also { it.start(true) }
        assertTrue(reopened.locked)
        assertTrue(reopened.beginPrompt(auto = true))
    }

    @Test fun there_is_no_fixed_grace_period_for_a_new_opening() {
        // mesmo 1 ms depois de uma sessão anterior desbloqueada, a nova sessão pede biometria
        val old = unlocked(); old.onBackground(1_000)
        val fresh = lock(true)
        fresh.onForeground(1_001, required = true, relockMs = 5 * 60_000L, stampValid = true)
        assertTrue(fresh.locked)
    }

    @Test fun only_success_unlocks_cancel_and_refusal_keep_it_locked() {
        val l = lock()
        assertTrue(l.beginPrompt(auto = true))
        l.onFailure()                           // item 10/11: cancelada ou recusada
        assertTrue(l.locked)
        assertTrue(l.beginPrompt(auto = false)) // botão "Desbloquear"
        l.onFailure()
        assertTrue(l.locked)
        assertTrue(l.beginPrompt(auto = false))
        l.onSuccess()
        assertFalse(l.locked)
    }

    // item 17: sem solicitações duplicadas
    @Test fun never_two_prompts_at_the_same_time() {
        val l = lock()
        assertTrue(l.beginPrompt(auto = true))
        assertFalse(l.beginPrompt(auto = true))
        assertFalse(l.beginPrompt(auto = false))
        l.onFailure()
        assertFalse(l.promptInFlight)
    }

    @Test fun no_automatic_prompt_loop_after_cancel_until_the_app_goes_to_background_again() {
        val l = lock()
        l.beginPrompt(auto = true); l.onFailure()
        assertFalse(l.beginPrompt(auto = true))     // recriar a tela sem sair do app: não repete sozinho
        assertTrue(l.beginPrompt(auto = false))     // mas o botão funciona
        l.onFailure()
        l.onBackground(1_000); l.onForeground(2_000, true, 0L, true)
        assertTrue(l.beginPrompt(auto = true))      // nova ida ao segundo plano: pede de novo
    }

    // item 9: minimizado e restaurado, conforme a política escolhida
    @Test fun immediate_policy_locks_on_every_return_from_background() {
        val l = unlocked(); l.onBackground(10_000)
        assertTrue(l.onForeground(10_001, true, RelockPolicy.IMMEDIATE.millis, true))
        assertTrue(l.locked)
    }

    @Test fun timed_policies_lock_only_after_the_chosen_time() {
        for (p in listOf(RelockPolicy.AFTER_30S, RelockPolicy.AFTER_1MIN, RelockPolicy.AFTER_5MIN)) {
            val quick = unlocked(); quick.onBackground(0)
            assertFalse(quick.onForeground(p.millis, true, p.millis, true)); assertFalse(quick.locked)
            val slow = unlocked(); slow.onBackground(0)
            assertTrue(slow.onForeground(p.millis + 1, true, p.millis, true)); assertTrue(slow.locked)
        }
    }

    @Test fun rotation_is_not_a_trip_to_the_background_so_it_never_relocks() {
        // MainActivity.onStop não chama onBackground quando isChangingConfigurations; sem onBackground não há "ausência"
        val l = unlocked()
        assertFalse(l.onForeground(5_000, true, RelockPolicy.IMMEDIATE.millis, true))
        assertFalse(l.locked)
    }

    @Test fun a_stamp_from_another_process_or_boot_locks_even_without_a_long_absence() {
        val l = unlocked()
        assertTrue(l.onForeground(1, true, RelockPolicy.AFTER_5MIN.millis, stampValid = false))
        assertTrue(l.locked)
    }

    @Test fun turning_protection_off_is_respected_and_turning_on_keeps_the_authenticated_session() {
        val l = lock(false)
        l.onBackground(0); l.onForeground(10_000, true, 60_000L, true)     // ligada nas configurações (autenticada): segue aberta
        assertFalse(l.locked)
        l.onBackground(20_000); assertTrue(l.onForeground(90_000, true, 60_000L, true))   // ficou fora além do prazo
        assertTrue(l.locked)
        val l2 = unlocked()
        l2.onBackground(0); l2.onForeground(999_999, false, 0L, false)
        assertFalse(l2.locked)
    }

    @Test fun a_locked_session_cannot_be_opened_by_foreground_transitions() {
        val l = lock()
        l.onBackground(0); l.onForeground(1, true, 0L, true)
        assertTrue(l.locked)
        l.onBackground(5); l.onForeground(10_000_000, true, RelockPolicy.AFTER_5MIN.millis, true)
        assertTrue(l.locked)
    }

    @Test fun nothing_to_prompt_when_not_locked() {
        assertFalse(lock(false).beginPrompt(auto = false))
        assertEquals(false, lock(false).promptInFlight)
    }
}
