package com.agon.app.security

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/**
 * Cenários SIMULADOS na JVM (sem Android). Provam as regras de decisão; NÃO provam o comportamento em aparelho real.
 */
class SessionScenariosTest {
    // item 7 e 8: processo recriado / celular reiniciado
    @Test fun stamp_from_another_process_or_another_boot_is_never_valid() {
        val current = SessionStamp.make("proc-B", 12)
        assertTrue(SessionStamp.isValid(SessionStamp.make("proc-B", 12), current))
        assertFalse(SessionStamp.isValid(SessionStamp.make("proc-A", 12), current))   // processo recriado
        assertFalse(SessionStamp.isValid(SessionStamp.make("proc-B", 11), current))   // celular reiniciado
        assertFalse(SessionStamp.isValid(null, current))
        assertFalse(SessionStamp.isValid("", current))
    }

    @Test fun android_recreating_the_process_with_a_stale_stamp_still_starts_locked_and_stays_locked() {
        val stale = SessionStamp.make("proc-A", 12)
        val now = SessionStamp.make("proc-B", 12)
        val l = SessionLock().also { it.start(true) }
        l.onBackground(0)
        l.onForeground(1, true, RelockPolicy.AFTER_5MIN.millis, SessionStamp.isValid(stale, now))
        assertTrue(l.locked)
    }

    // item 9 + 10 + 11 de ponta a ponta
    @Test fun full_flow_open_cancel_retry_success_minimize_return_prompt_again() {
        val l = SessionLock().also { it.start(true) }
        assertTrue(l.locked)
        assertTrue(l.beginPrompt(true)); l.onFailure()           // cancelou
        assertTrue(l.locked)
        assertTrue(l.beginPrompt(false)); l.onFailure()          // recusada
        assertTrue(l.locked)
        assertTrue(l.beginPrompt(false)); l.onSuccess()          // aprovada
        assertFalse(l.locked)
        l.onBackground(100)
        assertTrue(l.onForeground(200, true, RelockPolicy.IMMEDIATE.millis, true))
        assertTrue(l.beginPrompt(true))
    }

    @Test fun recovery_throttle_blocks_after_five_wrong_pins_and_recovers_after_the_wait() {
        val t = RecoveryThrottle(maxAttempts = 5, lockMs = 60_000L)
        assertTrue(t.canTry(0))
        repeat(5) { t.onFail(1_000L) }
        assertFalse(t.canTry(1_001L))
        assertEquals(60, t.secondsLeft(1_000L))
        assertTrue(t.canTry(61_000L))
        t.onSuccess()
        assertEquals(0, t.secondsLeft(61_001L))
    }

    @Test fun view_model_recovery_only_opens_with_the_right_pin() {
        val vm = SecurityViewModel()
        vm.init(true)
        assertTrue(vm.locked.value)
        assertFalse(vm.onRecoveryAttempt(1_000L, pinOk = false))
        assertTrue(vm.locked.value)
        assertTrue(vm.onRecoveryAttempt(2_000L, pinOk = true))
        assertFalse(vm.locked.value)
    }

    @Test fun view_model_init_reports_a_new_session_only_once() {
        val vm = SecurityViewModel()
        assertTrue(vm.init(true))
        assertFalse(vm.init(false))        // tela recriada (girou): não vira sessão nova nem destrava
        assertTrue(vm.locked.value)
    }

    @Test fun view_model_failures_keep_the_app_locked_with_a_message() {
        val vm = SecurityViewModel(); vm.init(true)
        for (f in AuthFailure.values()) {
            vm.beginPrompt(false)
            vm.onAuthFailure(f)
            assertTrue(vm.locked.value)
            assertTrue(vm.message.value.isNotBlank())
        }
        vm.beginPrompt(false); vm.onAuthSuccess()
        assertFalse(vm.locked.value)
    }
}
