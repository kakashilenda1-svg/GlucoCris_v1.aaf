# Proxy Tavily + Gemini do Gluco Cris

Guarda as chaves da **Tavily** e do **Google Gemini** no servidor (Cloudflare Workers).
O app só conhece o endereço deste proxy. **Nenhuma chave vai no APK.**

## Rotas

| Método | Caminho   | Função                                      |
|--------|-----------|---------------------------------------------|
| POST   | `/` ou `/tavily` | Pesquisa Tavily (contrato original)    |
| POST   | `/gemini` | Proxy para `generateContent` do Gemini      |
| OPTIONS| qualquer  | CORS preflight                              |

## Publicar (Cloudflare Workers, plano gratuito)

```bash
cd backend/tavily-proxy
npx wrangler login
npx wrangler secret put TAVILY_API_KEY     # chave de https://www.tavily.com/
npx wrangler secret put GEMINI_API_KEY    # chave da Google AI Studio / Gemini API
# (opcional) token do app:
npx wrangler secret put APP_TOKEN
# (recomendado) contador global:
npx wrangler kv namespace create USAGE
# cole o id em wrangler.toml e descomente o bloco [[kv_namespaces]]
npx wrangler deploy
# imprime https://gluco-cris-tavily-proxy.<conta>.workers.dev
```

### Ação manual obrigatória na Cloudflare

1. Entre no diretório `backend/tavily-proxy`.
2. Execute `npx wrangler secret put GEMINI_API_KEY` e cole a chave da Google AI Studio
   (formato `AIza...` ou o novo formato suportado pela API).
3. Mantenha o segredo `TAVILY_API_KEY` já existente (não remova).
4. Faça o deploy: `npx wrangler deploy`.
5. Confirme que a URL pública continua a mesma usada em `tavily.proxy.url` no app
   (ou atualize `local.properties` / CI se o nome do worker mudar).

**Não** coloque `GEMINI_API_KEY` nem `TAVILY_API_KEY` em `local.properties`, BuildConfig,
código-fonte ou logs.

## No app

`local.properties` (não versionado):

```
tavily.proxy.url=https://gluco-cris-tavily-proxy.<conta>.workers.dev
tavily.app.token=SEU_TOKEN_OPCIONAL
# gemini.api.key NÃO É MAIS USADO — a chave fica só no Worker
gemini.model=gemini-3.8-flash
```

Depois gere o APK. Em Cris IA > configurações:

- **Testar pesquisa** valida o proxy Tavily (1 crédito).
- **Testar Gemini** (se existir na UI) valida a rota `/gemini`.

## Gemini — contrato

O app envia `POST {proxy}/gemini` com:

- Body: JSON idêntico ao de `models/{model}:generateContent` (contents, systemInstruction, etc.).
- Header opcional `x-gemini-model`: um dos modelos da lista branca (padrão `gemini-3.8-flash`).
- Header `x-app-token` se `APP_TOKEN` estiver definido no Worker.

O Worker:

- Valida tamanho do corpo (máx. 8 MB).
- Só permite modelos da lista branca.
- Anexa a chave e encaminha para a API Google.
- Aplica cota diária global opcional (`GEMINI_DAILY_LIMIT`, padrão 2000).
- Não registra o conteúdo das consultas em log.

## Cota e custos

- **Tavily:** Basic = 1 crédito, Advanced = 2. `MONTHLY_LIMIT` / `MONTHLY_RESERVE` no `wrangler.toml`.
- **Gemini:** limite diário global no Worker + limite diário por aparelho no app (40).
- Com KV `USAGE`, o proxy bloqueia (HTTP 429) ao atingir os tetos.

## Teste local

```bash
node test.mjs          # Tavily (simulado)
node test-gemini.mjs   # Gemini (requer GEMINI_API_KEY no ambiente se quiser live)
```
