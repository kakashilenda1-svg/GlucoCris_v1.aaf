// Teste unitário da rota /gemini (sem chamar Google de verdade).
import worker from "./worker.js";

function assert(cond, msg) {
  if (!cond) throw new Error(msg);
}

const env = {
  GEMINI_API_KEY: "test-key-AQ-fake",
  APP_TOKEN: "tok",
};

const originalFetch = globalThis.fetch;
let lastUrl = "";
globalThis.fetch = async (url, init) => {
  lastUrl = String(url);
  return new Response(JSON.stringify({
    candidates: [{ content: { parts: [{ text: "ok" }] }, finishReason: "STOP" }],
  }), { status: 200, headers: { "content-type": "application/json" } });
};

try {
  let r = await worker.fetch(new Request("https://x/gemini", {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ contents: [{ parts: [{ text: "hi" }] }] }),
  }), env);
  assert(r.status === 401, "expected 401 without token, got " + r.status);

  r = await worker.fetch(new Request("https://x/gemini", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      "x-app-token": "tok",
      "x-gemini-model": "gemini-3.8-flash",
    },
    body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: "hi" }] }] }),
  }), env);
  assert(r.status === 200, "expected 200, got " + r.status);
  assert(lastUrl.includes("generativelanguage.googleapis.com"), "should call Google: " + lastUrl);
  assert(lastUrl.includes("key=test-key-AQ-fake"), "key in query");
  assert(lastUrl.includes("gemini-3.8-flash"), "model in path");
  const j = await r.json();
  assert(j.candidates?.[0]?.content?.parts?.[0]?.text === "ok", "passthrough body");

  r = await worker.fetch(new Request("https://x/gemini", {
    method: "POST",
    headers: { "content-type": "application/json", "x-app-token": "tok", "x-gemini-model": "evil-model" },
    body: JSON.stringify({ contents: [{ parts: [{ text: "x" }] }] }),
  }), env);
  assert(r.status === 200, "bad model still 200 with default");
  assert(lastUrl.includes("gemini-3.8-flash"), "fallback model");

  r = await worker.fetch(new Request("https://x/gemini", {
    method: "POST",
    headers: { "content-type": "application/json", "x-app-token": "tok" },
    body: JSON.stringify({ foo: 1 }),
  }), env);
  assert(r.status === 400, "invalid payload 400");

  const envT = { ...env, TAVILY_API_KEY: "tvly-x" };
  globalThis.fetch = async () => new Response(JSON.stringify({ results: [], usage: { credits: 1 } }), { status: 200 });
  r = await worker.fetch(new Request("https://x/", {
    method: "POST",
    headers: { "content-type": "application/json", "x-app-token": "tok" },
    body: JSON.stringify({ query: "diabetes" }),
  }), envT);
  assert(r.status === 200, "tavily root still works");

  console.log("gemini-proxy: todos os testes passaram");
} finally {
  globalThis.fetch = originalFetch;
}
