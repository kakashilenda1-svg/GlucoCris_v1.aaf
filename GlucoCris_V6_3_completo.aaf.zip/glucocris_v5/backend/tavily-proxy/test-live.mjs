// TESTE REAL do proxy Tavily do Gluco Cris. Faz requisições HTTP verdadeiras (não usa fetch simulado).
//
// Uso:   node test-live.mjs [URL_DO_PROXY]
// Opcional (só se o Worker tiver APP_TOKEN):   TAVILY_APP_TOKEN=xxxx node test-live.mjs
// Requer Node 18+ e internet. O passo 4 consome 1 crédito Tavily (busca "basic").
// A chave da Tavily NÃO é usada aqui: ela fica só no Worker. Este script nunca imprime o token.

const URL_PROXY = (process.argv[2] || process.env.PROXY_URL || "https://gluco-cris-tavily-proxy.alanholivier.workers.dev").trim();
const TOKEN = (process.env.TAVILY_APP_TOKEN || "").trim();
let falhas = 0;

const ok = (m) => console.log("  OK   " + m);
const no = (m) => { falhas++; console.log("  FALHA " + m); };
const check = (cond, m) => (cond ? ok(m) : no(m));

async function req(method, body, extraHeaders = {}) {
  const t0 = Date.now();
  const headers = { Accept: "application/json", ...extraHeaders };
  if (method === "POST") headers["Content-Type"] = "application/json; charset=utf-8";
  if (TOKEN) headers["X-App-Token"] = TOKEN;
  try {
    const r = await fetch(URL_PROXY, { method, headers, body, signal: AbortSignal.timeout(25000) });
    const text = await r.text();
    let json = null; try { json = JSON.parse(text); } catch {}
    return { status: r.status, ctype: r.headers.get("content-type") || "", text, json, ms: Date.now() - t0 };
  } catch (e) {
    return { erro: `${e.name}: ${e.message}`, cause: e.cause?.code || "" };
  }
}

const DICA = {
  400: "o Worker recusou o corpo (JSON inválido ou query curta).",
  401: "APP_TOKEN do Worker não bate com o token do app (ou chave Tavily recusada, se error=upstream).",
  405: "o Worker publicado não aceitou POST: o código no ar é diferente do worker.js do projeto.",
  429: "limite de créditos do Worker (MONTHLY_LIMIT) ou da Tavily atingido.",
  500: "TAVILY_API_KEY não está definida como secret no Worker (error=not_configured). Rode: npx wrangler secret put TAVILY_API_KEY",
  502: "a Tavily respondeu erro ao Worker (veja o campo status no corpo).",
  504: "o Worker não alcançou a Tavily (upstream_unreachable).",
};

console.log("Proxy:", URL_PROXY, TOKEN ? "(com X-App-Token)" : "(sem token)");

// 1) GET: o endereço precisa estar acessível e recusar GET.
console.log("\n1) GET (esperado: 405)");
let r = await req("GET");
if (r.erro) { no(`sem conexão com o proxy: ${r.erro} ${r.cause}`); console.log("\nSem conexão: nada mais pode ser testado."); process.exit(2); }
check(r.status === 405, `status ${r.status}`);

// 2) JSON inválido: deve dar 400 sem gastar crédito.
console.log("\n2) POST com JSON inválido (esperado: 400)");
r = await req("POST", "{isto nao e json");
check(r.status === 400, `status ${r.status} ${r.json?.error ? "error=" + r.json.error : ""}`);

// 3) Query curta: deve dar 400 sem gastar crédito.
console.log("\n3) POST com query vazia (esperado: 400)");
r = await req("POST", JSON.stringify({ query: "", depth: "basic", maxResults: 3, topic: "general", health: false }));
check(r.status === 400, `status ${r.status} ${r.json?.error ? "error=" + r.json.error : ""}`);

// 4) Pesquisa REAL: mesmo formato que o TavilySearch.kt envia. Gasta 1 crédito.
console.log("\n4) POST de pesquisa REAL (esperado: 200 + resultados da Tavily; gasta 1 crédito)");
const corpo = { query: "diabetes tipo 2 Sociedade Brasileira de Diabetes", depth: "basic", maxResults: 3, topic: "general", health: true };
r = await req("POST", JSON.stringify(corpo));
if (r.erro) {
  no(`falha de rede no POST: ${r.erro} ${r.cause}`);
} else {
  console.log(`  (HTTP ${r.status} em ${r.ms} ms)`);
  if (r.status !== 200) {
    no(`status ${r.status} error=${r.json?.error ?? "?"}${r.json?.status ? " upstream=" + r.json.status : ""}`);
    if (DICA[r.status]) console.log("  Dica: " + DICA[r.status]);
  } else {
    check(r.ctype.includes("application/json"), `content-type: ${r.ctype}`);
    const res = r.json?.results;
    check(Array.isArray(res) && res.length > 0, `results: ${Array.isArray(res) ? res.length : "ausente"} item(ns)`);
    if (Array.isArray(res)) {
      for (const x of res) {
        const bom = typeof x.url === "string" && x.url.startsWith("https://") && (x.title || x.content);
        check(bom, `${(x.title || "(sem título)").slice(0, 60)} <${x.url}> score=${x.score}`);
      }
    }
    check(Number.isInteger(r.json?.usage?.credits), `usage.credits = ${r.json?.usage?.credits}`);
  }
}

console.log(falhas === 0 ? "\nRESULTADO: todos os testes reais passaram — o proxy e a Tavily respondem." : `\nRESULTADO: ${falhas} falha(s).`);
process.exit(falhas === 0 ? 0 : 1);
