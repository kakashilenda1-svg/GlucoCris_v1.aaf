// Teste local do proxy com fetch simulado (não chama a Tavily de verdade).
import worker from "./worker.js";
import assert from "node:assert/strict";

const realFetch = globalThis.fetch;
let last, mode = "ok";
globalThis.fetch = async (url, init) => {
  last = { url, init, body: JSON.parse(init.body) };
  if (mode === "401") return new Response("{}", { status: 401 });
  if (mode === "432") return new Response("{}", { status: 432 });
  if (mode === "empty") return new Response(JSON.stringify({ results: [], usage: { credits: 1 } }));
  return new Response(JSON.stringify({ results: [{ title: "T", url: "https://x.gov.br/a", content: "c", score: 0.9, raw_content: "NAO", published_date: null }], usage: { credits: last.body.search_depth === "advanced" ? 2 : 1 } }));
};
const kv = { m: new Map(), get: async (k) => kv.m.get(k) ?? null, put: async (k, v) => void kv.m.set(k, v) };
const call = (body, env = {}, headers = {}) => worker.fetch(new Request("https://p/", { method: "POST", headers, body: JSON.stringify(body) }), { TAVILY_API_KEY: "tvly-TEST", ...env });

let r = await call({ query: "diabetes tipo 1", depth: "basic", maxResults: 99, topic: "general", health: true });
let j = await r.json();
assert.equal(r.status, 200); assert.equal(j.results.length, 1); assert.equal(j.results[0].raw_content, undefined);
assert.equal(last.init.headers.authorization, "Bearer tvly-TEST");
assert.equal(last.body.search_depth, "basic"); assert.equal(last.body.max_results, 6);
assert.equal(last.body.include_answer, false); assert.equal(last.body.include_raw_content, false); assert.equal(last.body.include_images, false);
assert.equal(last.body.include_domains_mode, "prefer"); assert.equal(last.body.country, "brazil"); assert.equal(last.body.language, "pt");

r = await call({ query: "x", depth: "advanced" }); assert.equal(r.status, 400);
r = await call({ query: "estudos insulina", depth: "ultra", topic: "weird", timeRange: "decade" }); await r.json();
assert.equal(last.body.search_depth, "basic"); assert.equal(last.body.topic, "general"); assert.equal(last.body.time_range, undefined);
r = await call({ query: "noticias diabetes", topic: "news", timeRange: "week" }); await r.json();
assert.equal(last.body.country, undefined); assert.equal(last.body.time_range, "week");

assert.equal((await call({ query: "abc" }, { APP_TOKEN: "t" })).status, 401);
assert.equal((await call({ query: "abc" }, { APP_TOKEN: "t" }, { "x-app-token": "t" })).status, 200);
assert.equal((await worker.fetch(new Request("https://p/"), { TAVILY_API_KEY: "k" })).status, 405);
assert.equal((await worker.fetch(new Request("https://p/", { method: "POST", body: "{}" }), {})).status, 500);

mode = "401"; assert.equal((await call({ query: "abc" })).status, 401);
mode = "432"; assert.equal((await call({ query: "abc" })).status, 429);
mode = "empty"; j = await (await call({ query: "abc" })).json(); assert.deepEqual(j.results, []);

// cota global: limite 4, reserva 1 => teto 3 créditos
mode = "ok"; kv.m.clear();
const env = { USAGE: kv, MONTHLY_LIMIT: "4", MONTHLY_RESERVE: "1" };
assert.equal((await call({ query: "abc", depth: "advanced" }, env)).status, 200); // 2
assert.equal((await call({ query: "abc" }, env)).status, 200);                    // 3
assert.equal((await call({ query: "abc" }, env)).status, 429);                    // bloqueado
console.log("proxy: todos os testes passaram");
globalThis.fetch = realFetch;
