// Proxy do Gluco Cris para Tavily Search API + Google Gemini API (Cloudflare Workers).
// Chaves ficam SOMENTE aqui como segredos. O app nunca as recebe.
//
// Rotas:
//   POST /          ou POST /tavily  → Tavily Search (contrato original, inalterado)
//   POST /gemini                     → proxy Gemini generateContent
//
// Tavily contrato (app -> proxy):
//   { query, depth: "basic"|"advanced", maxResults, topic: "general"|"news",
//     timeRange?: "day"|"week"|"month", health?: boolean }
//   Resposta: { results: [{title,url,content,score,published_date}], usage: { credits } }
//
// Gemini contrato (app -> proxy):
//   Body = exatamente o JSON que iria para generativelanguage.googleapis.com
//   (.../models/{model}:generateContent), SEM a chave.
//   Header opcional: x-gemini-model (padrão: gemini-3.8-flash)
//   Header: x-app-token (se APP_TOKEN configurado)
//   Resposta: o JSON bruto do Google (candidates, etc.) ou { error, status }
//
// Segredos/vars:
//   TAVILY_API_KEY (obrigatório para /tavily) · GEMINI_API_KEY (obrigatório para /gemini)
//   APP_TOKEN (opcional) · MONTHLY_LIMIT · MONTHLY_RESERVE · USAGE (KV)
//   GEMINI_DAILY_LIMIT (padrão 2000 requisições/dia no worker, global)

const HEALTH_DOMAINS = [
  "*.gov.br", "who.int", "paho.org", "nih.gov", "pubmed.ncbi.nlm.nih.gov", "diabetes.org.br",
  "fiocruz.br", "cdc.gov", "diabetes.org", "idf.org", "scielo.br",
];
const COST = { basic: 1, advanced: 2 };

/** Modelos oficialmente permitidos (evitar abuso / modelos inexistentes). */
const ALLOWED_GEMINI_MODELS = new Set([
  "gemini-3.8-flash",
  "gemini-3.6-flash",
  "gemini-3.5-flash-lite",
  "gemini-3.1-flash-lite",
  "gemini-2.5-flash",
  "gemini-2.0-flash",
  "gemini-1.5-flash",
  "gemini-1.5-flash-8b",
]);

const MAX_GEMINI_BODY_BYTES = 8 * 1024 * 1024; // 8 MB (imagens/PDF base64)
const DEFAULT_GEMINI_MODEL = "gemini-3.8-flash";

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: {
      "content-type": "application/json; charset=utf-8",
      "cache-control": "no-store",
    },
  });

const monthKey = () => "credits:" + new Date().toISOString().slice(0, 7);
const dayKey = () => "gemini:" + new Date().toISOString().slice(0, 10);

function pathOf(request) {
  try {
    const u = new URL(request.url);
    return (u.pathname || "/").replace(/\/+$/, "") || "/";
  } catch {
    return "/";
  }
}

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") {
      return new Response(null, {
        status: 204,
        headers: {
          "access-control-allow-origin": "*",
          "access-control-allow-methods": "POST, OPTIONS",
          "access-control-allow-headers": "content-type, x-app-token, x-gemini-model",
          "access-control-max-age": "86400",
        },
      });
    }
    if (request.method !== "POST") return json({ error: "method" }, 405);

    if (env.APP_TOKEN && request.headers.get("x-app-token") !== env.APP_TOKEN) {
      return json({ error: "unauthorized" }, 401);
    }

    const path = pathOf(request);

    if (path === "/gemini") {
      return handleGemini(request, env);
    }
    // Tavily: raiz ou /tavily (compatível com o app atual que posta na raiz)
    if (path === "/" || path === "/tavily") {
      return handleTavily(request, env);
    }
    return json({ error: "not_found", path }, 404);
  },
};

// ─── Tavily (comportamento original, sem alterações de contrato) ─────────────

async function handleTavily(request, env) {
  if (!env.TAVILY_API_KEY) return json({ error: "not_configured" }, 500);

  let b;
  try {
    b = await request.json();
  } catch {
    return json({ error: "bad_json" }, 400);
  }
  const query = typeof b.query === "string" ? b.query.trim().slice(0, 200) : "";
  if (query.length < 2) return json({ error: "bad_query" }, 400);

  const depth = b.depth === "advanced" ? "advanced" : "basic";
  const topic = b.topic === "news" ? "news" : "general";
  const maxResults = Math.min(Math.max(parseInt(b.maxResults, 10) || 5, 1), 6);
  const timeRange = ["day", "week", "month"].includes(b.timeRange) ? b.timeRange : null;
  const cost = COST[depth];

  const limit = parseInt(env.MONTHLY_LIMIT || "1000", 10) - parseInt(env.MONTHLY_RESERVE || "50", 10);
  let used = 0;
  if (env.USAGE) {
    used = parseInt((await env.USAGE.get(monthKey())) || "0", 10);
    if (used + cost > limit) return json({ error: "quota" }, 429);
  }

  const payload = {
    query,
    search_depth: depth,
    max_results: maxResults,
    topic,
    language: "pt",
    include_answer: false,
    include_raw_content: false,
    include_images: false,
    include_favicon: false,
    include_usage: true,
    chunks_per_source: 1,
  };
  if (topic === "general") payload.country = "brazil";
  if (timeRange) payload.time_range = timeRange;
  if (b.health === true) {
    payload.include_domains = HEALTH_DOMAINS;
    payload.include_domains_mode = "prefer";
  }

  let r;
  try {
    r = await fetch("https://api.tavily.com/search", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: "Bearer " + env.TAVILY_API_KEY,
      },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(20000),
    });
  } catch {
    return json({ error: "upstream_unreachable" }, 504);
  }

  if (!r.ok) {
    return json(
      { error: "upstream", status: r.status },
      r.status === 401 ? 401 : r.status === 429 || r.status === 432 || r.status === 433 ? 429 : 502,
    );
  }

  const data = await r.json().catch(() => ({}));
  const credits = Number.isInteger(data?.usage?.credits) ? data.usage.credits : cost;
  if (env.USAGE) {
    await env.USAGE.put(monthKey(), String(used + credits), { expirationTtl: 60 * 60 * 24 * 62 });
  }

  const results = (Array.isArray(data.results) ? data.results : []).slice(0, maxResults).map((x) => ({
    title: x.title,
    url: x.url,
    content: x.content,
    score: x.score,
    published_date: x.published_date ?? null,
  }));
  return json({ results, usage: { credits } });
}

// ─── Gemini ──────────────────────────────────────────────────────────────────

async function handleGemini(request, env) {
  if (!env.GEMINI_API_KEY) return json({ error: "gemini_not_configured" }, 500);

  // Limite de tamanho do corpo (proteção contra abuso / OOM)
  const cl = request.headers.get("content-length");
  if (cl && parseInt(cl, 10) > MAX_GEMINI_BODY_BYTES) {
    return json({ error: "body_too_large", max: MAX_GEMINI_BODY_BYTES }, 413);
  }

  let bodyText;
  try {
    bodyText = await request.text();
  } catch {
    return json({ error: "bad_body" }, 400);
  }
  if (!bodyText || bodyText.length < 2) return json({ error: "empty_body" }, 400);
  if (bodyText.length > MAX_GEMINI_BODY_BYTES) {
    return json({ error: "body_too_large", max: MAX_GEMINI_BODY_BYTES }, 413);
  }

  let parsed;
  try {
    parsed = JSON.parse(bodyText);
  } catch {
    return json({ error: "bad_json" }, 400);
  }
  if (!parsed || typeof parsed !== "object" || !Array.isArray(parsed.contents)) {
    return json({ error: "invalid_gemini_payload" }, 400);
  }

  // Modelo: header x-gemini-model ou padrão; só lista branca
  let model = (request.headers.get("x-gemini-model") || DEFAULT_GEMINI_MODEL).trim();
  if (!ALLOWED_GEMINI_MODELS.has(model)) {
    model = DEFAULT_GEMINI_MODEL;
  }

  // Cota diária global opcional (KV)
  const dailyLimit = parseInt(env.GEMINI_DAILY_LIMIT || "2000", 10);
  if (env.USAGE && dailyLimit > 0) {
    const used = parseInt((await env.USAGE.get(dayKey())) || "0", 10);
    if (used >= dailyLimit) return json({ error: "gemini_quota" }, 429);
  }

  const url =
    "https://generativelanguage.googleapis.com/v1beta/models/" +
    encodeURIComponent(model) +
    ":generateContent";

  // Autenticação: chave como query (compatível com chaves AIza... e formatos novos AQ...)
  const target = url + "?key=" + encodeURIComponent(env.GEMINI_API_KEY);

  let r;
  try {
    r = await fetch(target, {
      method: "POST",
      headers: {
        "content-type": "application/json; charset=utf-8",
      },
      body: bodyText,
      signal: AbortSignal.timeout(90000),
    });
  } catch {
    return json({ error: "upstream_unreachable" }, 504);
  }

  // Contabiliza só respostas bem-sucedidas ou 429 (já consumiu cota do Google)
  if (env.USAGE && (r.ok || r.status === 429)) {
    const used = parseInt((await env.USAGE.get(dayKey())) || "0", 10);
    await env.USAGE.put(dayKey(), String(used + 1), { expirationTtl: 60 * 60 * 48 });
  }

  const raw = await r.text();
  // Repassa status e corpo do Google (app faz o parse). Não loga conteúdo.
  return new Response(raw, {
    status: r.status,
    headers: {
      "content-type": r.headers.get("content-type") || "application/json; charset=utf-8",
      "cache-control": "no-store",
      "x-gemini-model-used": model,
    },
  });
}
