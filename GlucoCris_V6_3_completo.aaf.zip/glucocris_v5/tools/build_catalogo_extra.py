#!/usr/bin/env python3
"""
Gera app/src/main/assets/catalogo_extra.json (base offline do Gluco Cris) a partir do
dump do Open Food Facts. Rode no PC, com internet:

  1) baixe https://static.openfoodfacts.org/data/openfoodfacts-products.jsonl.gz
  2) python3 tools/build_catalogo_extra.py openfoodfacts-products.jsonl.gz app/src/main/assets/catalogo_extra.json

Só entram produtos do Brasil com nome, calorias e carboidratos presentes e coerentes
(mesma checagem do app). Valores por 100 g. Cada item tem id "bc-<código>", então o
leitor de código de barras acha o produto sem internet.
"""
import gzip, json, sys

def warn(kcal, carbs, prot, fat):
    if kcal <= 0 and carbs <= 0 and prot <= 0 and fat <= 0: return True
    if carbs + prot + fat > 105: return True
    if kcal > 0 and abs(kcal - (4 * carbs + 4 * prot + 9 * fat)) > 0.35 * kcal + 30: return True
    return False

def num(n, k):
    v = n.get(k)
    try: return float(v)
    except (TypeError, ValueError): return None

def main(src, dst, limit=None):
    op = gzip.open if src.endswith(".gz") else open
    out, seen = [], set()
    with op(src, "rt", encoding="utf-8") as f:
        for line in f:
            try: p = json.loads(line)
            except ValueError: continue
            if "en:brazil" not in (p.get("countries_tags") or []): continue
            code = str(p.get("code", "")).strip()
            name = (p.get("product_name_pt") or p.get("product_name") or "").strip()
            n = p.get("nutriments") or {}
            kcal, carbs = num(n, "energy-kcal_100g"), num(n, "carbohydrates_100g")
            if not code.isdigit() or len(code) < 8 or not name or kcal is None or carbs is None or code in seen: continue
            prot, fat = num(n, "proteins_100g") or 0.0, num(n, "fat_100g") or 0.0
            if warn(kcal, carbs, prot, fat): continue
            seen.add(code)
            sodium = num(n, "sodium_100g")
            out.append({
                "id": "bc-" + code, "name": name, "brand": (p.get("brands") or "").split(",")[0].strip(),
                "kcal": round(kcal, 1), "carbs": round(carbs, 2), "protein": round(prot, 2), "fat": round(fat, 2),
                "fiber": round(num(n, "fiber_100g") or 0.0, 2), "sugars": round(num(n, "sugars_100g") or 0.0, 2),
                "satFat": round(num(n, "saturated-fat_100g") or 0.0, 2),
                "sodium": round((sodium or 0.0) * 1000, 1),
                "serving": "100 g", "servingGrams": 100,
                "source": "Open Food Facts (base offline)", "sourceKey": "off", "reliability": "media",
                "category": (p.get("categories") or "")[:60],
            })
            if limit and len(out) >= limit: break
    with open(dst, "w", encoding="utf-8") as f:
        json.dump(out, f, ensure_ascii=False, separators=(",", ":"))
    print(f"{len(out)} produtos gravados em {dst}")

if __name__ == "__main__":
    if len(sys.argv) < 3: sys.exit(__doc__)
    main(sys.argv[1], sys.argv[2], int(sys.argv[3]) if len(sys.argv) > 3 else None)
