package com.agon.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.json.JSONObject

private val Context.crisStore by preferencesDataStore(name = "cris_ia_prefs")

@Serializable
data class CrisChatLine(val fromUser: Boolean, val text: String, val source: String = "")

@Serializable
data class CrisMemory(
    val shortAnswers: Boolean = true,
    val speakReplies: Boolean = true,
    val memoryEnabled: Boolean = true,
    val noteToSelf: String = "",
    val lastLocatorCity: String = "",
    val lastLocatorState: String = "Todos",
    val lastLocatorRadius: Int = 5,
    val lastLocatorInsulinId: String = "",
)

object CrisPrefs {
    private val KEY_MEMORY = stringPreferencesKey("cris.memory.v1")
    private val KEY_CHAT = stringPreferencesKey("cris.chat.v1")
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    suspend fun loadMemory(context: Context): CrisMemory {
        val prefs = context.crisStore.data.first()
        val raw = prefs[KEY_MEMORY] ?: return CrisMemory()
        return try {
            json.decodeFromString<CrisMemory>(raw)
        } catch (_: Exception) {
            CrisMemory()
        }
    }

    suspend fun saveMemory(context: Context, memory: CrisMemory) {
        context.crisStore.edit {
            it[KEY_MEMORY] = json.encodeToString(memory)
        }
    }

    suspend fun loadChat(context: Context): List<CrisChatLine> {
        val prefs = context.crisStore.data.first()
        val raw = prefs[KEY_CHAT] ?: return emptyList()
        return try {
            json.decodeFromString<List<CrisChatLine>>(raw)
        } catch (_: Exception) {
            emptyList()
        }
    }

    suspend fun saveChat(context: Context, lines: List<CrisChatLine>) {
        // Limita tamanho para não crescer demais
        val trimmed = lines.takeLast(80)
        context.crisStore.edit {
            it[KEY_CHAT] = json.encodeToString(trimmed)
        }
    }

    suspend fun clearChat(context: Context) {
        context.crisStore.edit { it.remove(KEY_CHAT) }
    }

    // ---- Portabilidade de dados por conta (backup completo / troca de conta) ----

    /** Tudo que este armazenamento guarda (memória da Cris e chat), em JSON. */
    suspend fun dumpAll(context: Context): String = PrefsJson.fromPreferences(context.crisStore.data.first()).toString()

    suspend fun restoreAll(context: Context, text: String) {
        val o = try { JSONObject(text) } catch (_: Exception) { return }
        context.crisStore.edit { PrefsJson.applyPreferences(it, o) }
    }

    suspend fun wipeAll(context: Context) {
        context.crisStore.edit { it.clear() }
    }
}
