package com.agon.app.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.R
import com.agon.app.Routes
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.formatDateTime
import com.agon.app.data.formatLongDate
import com.agon.app.data.greeting
import com.agon.app.data.rangeStatus
import com.agon.app.data.statusLabel
import com.agon.app.data.toMgDl
import com.agon.app.data.weekdayLong
import com.agon.app.love.LOVE_PHONE_DISPLAY
import com.agon.app.love.LOVE_PHONE_TEL
import com.agon.app.love.MAIN_LOVE_MESSAGE
import com.agon.app.love.SAMU_TEL
import com.agon.app.love.openDialer
import com.agon.app.love.openWhatsApp
import com.agon.app.love.phraseForToday
import com.agon.app.ui.components.ActionButton
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GlucoseChart
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.components.tourTarget
import com.agon.app.ui.theme.glucoColors
import kotlin.math.roundToInt

@Composable
fun HomeScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val context = LocalContext.current
    val settings = data.settings
    var phrase by remember { mutableStateOf("") }
    var showMood by remember { mutableStateOf(false) }
    var waterBarVisible by remember { mutableStateOf(true) }
    val scrollWatcher = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -6f) waterBarVisible = false
                else if (available.y > 6f) waterBarVisible = true
                return Offset.Zero
            }
        }
    }
    LaunchedEffect(Unit) { phrase = phraseForToday(context) }
    if (showMood) {
        MoodSheet(settings.mood, settings.moodStyle, { st -> vm.updateSettings { it.copy(moodStyle = st) } }, onDismiss = { showMood = false }) { id ->
            vm.updateSettings { it.copy(mood = id, moodAt = System.currentTimeMillis()) }
            showMood = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val latest = data.glucose.maxByOrNull { it.at }
    val mg = latest?.let { toMgDl(it.value, it.unit) }
    val status = mg?.let { rangeStatus(it, settings.targetLow, settings.targetHigh) }
    val statusColor = when (status) {
        "ok" -> g.green
        "low" -> g.orange
        "high" -> g.red
        else -> g.muted
    }

    val weekMsTop = 7L * 24 * 60 * 60 * 1000
    val sinceTop = System.currentTimeMillis() - weekMsTop
    val weekGCount = data.glucose.count { it.at >= sinceTop }
    val weekICount = data.insulin.count { it.at >= sinceTop }
    val firstName = com.agon.app.data.firstName(settings.displayName).ifBlank { "Maria" }
    val greetText = "${greeting()}, $firstName!"
    val isBlue = settings.blueTheme

    // Cores profissionais — visual premium mantendo identidade rosa/azul
    val bgDeep = if (isBlue) Color(0xFF0A1628) else Color(0xFF120C1C)
    val cardBg1 = if (isBlue) Color(0xFF122B4A) else Color(0xFF352448)
    val cardBg2 = if (isBlue) Color(0xFF0D2038) else Color(0xFF261A36)
    val cardBorder = if (isBlue) Color(0xFF1E3A5F) else Color(0xFF4A3A62)
    val msgBg = if (isBlue) Color(0xFFD6E0EC) else Color(0xFFE8D4E0)
    val msgBgEnd = if (isBlue) Color(0xFFE8EEF5) else Color(0xFFF3E6EE)
    val msgTitle = if (isBlue) Color(0xFF1A2F4A) else Color(0xFF5C3A52)
    val msgBody = if (isBlue) Color(0xFF243447) else Color(0xFF2E2438)
    val msgHint = if (isBlue) Color(0xFF5A6B80) else Color(0xFF7A5F72)
    val crisGrad = if (isBlue) listOf(Color(0xFF1B3A7A), Color(0xFF2563EB)) else listOf(Color(0xFF5B3F8A), Color(0xFF9B6B9A))
    val themeBtnGrad = if (isBlue) listOf(Color(0xFF7C3AED), Color(0xFFDB2777)) else listOf(Color(0xFF3B82F6), Color(0xFF64748B))
    val valueGreen = Color(0xFF22C55E)
    val feelBtnBg = if (isBlue) Color(0xFF14304A) else Color(0xFF322644)
    val feelBtnBorder = if (isBlue) Color(0xFF3B82F6).copy(alpha = 0.4f) else Color(0xFFC4A0B8).copy(alpha = 0.45f)

    Box(Modifier.fillMaxSize().nestedScroll(scrollWatcher).background(bgDeep)) {
    ScrollScreen {
        Column(Modifier.fillMaxWidth()) {
            // Header
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Text("Gluco Cris", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    if (!isBlue) {
                        Spacer(Modifier.width(6.dp))
                        Text("❤️", fontSize = 15.sp)
                    }
                }
                // Perfil: usa a tela existente, agora acessível diretamente pelo cabeçalho.
                Box(
                    Modifier
                        .padding(end = 8.dp)
                        .size(34.dp)
                        .tourTarget("home_profile")
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.14f))
                        .border(1.5.dp, Color.White.copy(alpha = 0.85f), CircleShape)
                        .clickable { nav.navigate(Routes.PROFILE) },
                    contentAlignment = Alignment.Center,
                ) {
                    Icon(Icons.Filled.AccountCircle, contentDescription = "Perfil", tint = Color.White, modifier = Modifier.size(25.dp))
                }
                // Alternância real entre os dois temas já existentes.
                Box(
                    Modifier
                        .padding(end = 8.dp)
                        .size(34.dp)
                        .tourTarget("home_theme")
                        .clip(CircleShape)
                        .background(Brush.linearGradient(themeBtnGrad))
                        .border(1.5.dp, Color.White.copy(alpha = 0.9f), CircleShape)
                        .clickable { vm.updateSettings { it.copy(blueTheme = !it.blueTheme) } },
                )
                // Central de ajuda existente.
                Box(
                    Modifier
                        .size(34.dp)
                        .tourTarget("home_help")
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.16f))
                        .clickable { nav.navigate(Routes.HELP_CENTER) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text("?", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            }

            Spacer(Modifier.height(16.dp))

            // Saudação + robôzinho (layout compacto igual ao print)
            if (isBlue) {
                // Tema azul — layout médico com robô ao lado
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Image(
                        painter = painterResource(R.drawable.robot_blue),
                        contentDescription = "Cris",
                        modifier = Modifier
                            .size(88.dp)
                            .clip(RoundedCornerShape(18.dp)),
                        contentScale = ContentScale.Fit,
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            greetText,
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 21.sp,
                            lineHeight = 25.sp,
                        )
                        Spacer(Modifier.height(10.dp))
                        Row(
                            Modifier
                                .clip(RoundedCornerShape(24.dp))
                                .background(feelBtnBg)
                                .border(1.dp, feelBtnBorder, RoundedCornerShape(24.dp))
                                .clickable { showMood = true }
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            val mood = com.agon.app.data.moodOf(settings.mood)
                            if (mood != null) {
                                Text("${mood.emoji} ${mood.label}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            } else {
                                Text(
                                    "Como você está se sentindo?",
                                    color = Color.White.copy(alpha = 0.95f),
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp,
                                )
                            }
                        }
                    }
                }
            } else {
                // Tema rosa — layout do novo print: saudação + robôzinho pequeno ao lado
                Row(
                    Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                ) {
                    Image(
                        painter = painterResource(R.drawable.robot_pink),
                        contentDescription = "Cris",
                        modifier = Modifier
                            .size(56.dp)
                            .clip(RoundedCornerShape(14.dp)),
                        contentScale = ContentScale.Fit,
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(
                        greetText,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 22.sp,
                        lineHeight = 26.sp,
                    )
                    Spacer(Modifier.width(6.dp))
                    Text("🥰", fontSize = 18.sp)
                }
                Spacer(Modifier.height(12.dp))
                // Botão de humor centralizado
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Center,
                ) {
                    Row(
                        Modifier
                            .clip(RoundedCornerShape(24.dp))
                            .background(feelBtnBg)
                            .border(1.dp, feelBtnBorder, RoundedCornerShape(24.dp))
                            .clickable { showMood = true }
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        val mood = com.agon.app.data.moodOf(settings.mood)
                        if (mood != null) {
                            Text("${mood.emoji} ${mood.label}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        } else {
                            Text(
                                "😊  Como você está se sentindo?",
                                color = Color.White.copy(alpha = 0.95f),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            // Cards 2x2 — layout do print (Última medição | Seu humor / Glicemias | Insulinas)
            // Linha 1
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // Última medição
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.verticalGradient(listOf(cardBg1, cardBg2)))
                        .border(1.dp, cardBorder, RoundedCornerShape(18.dp))
                        .clickable { nav.navigate(Routes.glucoseForm(null)) }
                        .padding(14.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("💧", fontSize = 13.sp)
                        Spacer(Modifier.width(5.dp))
                        Text(
                            "Última medição",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                    Spacer(Modifier.height(6.dp))
                    if (mg != null) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                mg.roundToInt().toString(),
                                color = valueGreen,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 34.sp,
                            )
                            Text(
                                " mg/dL",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 12.sp,
                                modifier = Modifier.padding(bottom = 6.dp, start = 2.dp),
                            )
                        }
                        Text(
                            statusLabel(status ?: ""),
                            color = valueGreen,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                        )
                        if (latest != null) {
                            Text(
                                formatDateTime(latest.at),
                                color = Color.White.copy(alpha = 0.45f),
                                fontSize = 10.sp,
                                modifier = Modifier.padding(top = 4.dp),
                            )
                        }
                    } else {
                        Text("Sem medição", color = Color.White.copy(alpha = 0.75f), fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text("Toque para registrar", color = Color.White.copy(alpha = 0.45f), fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                }

                // Seu humor
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.verticalGradient(listOf(cardBg1, cardBg2)))
                        .border(1.dp, cardBorder, RoundedCornerShape(18.dp))
                        .clickable { showMood = true }
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("💜", fontSize = 13.sp)
                        Spacer(Modifier.width(5.dp))
                        Text(
                            "Seu humor",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    val mood = com.agon.app.data.moodOf(settings.mood)
                    if (mood != null) {
                        Text(mood.emoji, fontSize = 36.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            mood.label,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp,
                        )
                    } else {
                        Text("😊", fontSize = 36.sp)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Toque aqui",
                            color = Color.White.copy(alpha = 0.7f),
                            fontWeight = FontWeight.Medium,
                            fontSize = 13.sp,
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Linha 2
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                // Glicemias
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.verticalGradient(listOf(cardBg1, cardBg2)))
                        .border(1.dp, cardBorder, RoundedCornerShape(18.dp))
                        .padding(14.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("📊", fontSize = 13.sp)
                        Spacer(Modifier.width(5.dp))
                        Text(
                            "Glicemias (7 dias)",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "$weekGCount",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 32.sp,
                    )
                }

                // Insulinas
                Column(
                    Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.verticalGradient(listOf(cardBg1, cardBg2)))
                        .border(1.dp, cardBorder, RoundedCornerShape(18.dp))
                        .padding(14.dp),
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("💉", fontSize = 13.sp)
                        Spacer(Modifier.width(5.dp))
                        Text(
                            "Insulinas (7 dias)",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                        )
                    }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "$weekICount",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 32.sp,
                    )
                }
            }

            Spacer(Modifier.height(14.dp))

            // Cris IA
            Row(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(18.dp))
                    .background(Brush.horizontalGradient(crisGrad))
                    .clickable { nav.navigate(Routes.CRIS_IA) }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center,
                ) {
                    Image(
                        painter = painterResource(if (isBlue) R.drawable.robot_blue else R.drawable.robot_pink),
                        contentDescription = null,
                        modifier = Modifier.size(30.dp).clip(CircleShape),
                        contentScale = ContentScale.Fit,
                    )
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        "Conversar com a Cris IA",
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 16.sp,
                    )
                    Text(
                        "Sua assistente de cuidado",
                        color = Color.White.copy(alpha = 0.88f),
                        fontSize = 12.sp,
                    )
                }
                Text("›", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }

            // Mensagem
            Column(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .background(Brush.verticalGradient(listOf(msgBg, msgBgEnd)))
                    .padding(18.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (isBlue) "💬  " else "❤️  ", fontSize = 15.sp)
                    Text(
                        "Uma mensagem para você",
                        color = msgTitle,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 15.sp,
                    )
                    if (!isBlue) Text("  ❤️", fontSize = 15.sp)
                }
                Text(
                    MAIN_LOVE_MESSAGE,
                    color = msgBody,
                    fontSize = 14.sp,
                    lineHeight = 21.sp,
                    modifier = Modifier.padding(top = 12.dp),
                )
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(top = 12.dp),
                ) {
                    Text("♡  ", color = msgHint, fontSize = 12.sp)
                    Text("Frase carinhosa de hoje", color = msgHint, fontSize = 12.sp)
                }
            }

            Spacer(Modifier.height(14.dp))


        }

        Spacer(Modifier.height(10.dp))

        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton(
                " Ligar para meu amor ❤️",
                Icons.Filled.Call,
                g.violet,
                { openDialer(context, LOVE_PHONE_TEL) },
                Modifier.weight(1f),
            )
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton(
                "falar com amor por WhatsApp ",
                Icons.Filled.Favorite,
                g.blush,
                { openWhatsApp(context) },
                Modifier.weight(1f),
            )
        }
        Text(
            "A ligação não começa sozinha: o discador abre com $LOVE_PHONE_DISPLAY para você confirmar. O WhatsApp só abre a conversa, sem enviar mensagem.",
            color = g.muted,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 6.dp, start = 4.dp, end = 4.dp),
        )

        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 14.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(g.red)
                .clickable { openDialer(context, SAMU_TEL) }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.LocalHospital, null, tint = Color.White)
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text(" Emergência — SAMU 192", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text(
                    "Abre o discador com 192. Não aciona o atendimento sozinho e não garante que a chamada seja completada.",
                    color = Color.White.copy(alpha = 0.92f),
                    fontSize = 12.sp,
                )
            }
        }

        GCard(Modifier.padding(top = 14.dp)) {
            Text("Última medição", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (latest == null || mg == null || status == null) {
                Text("Nenhuma medição ainda.", color = g.ink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
            } else {
                Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(top = 4.dp)) {
                    Text(mg.roundToInt().toString(), color = statusColor, fontWeight = FontWeight.ExtraBold, fontSize = 40.sp)
                    Text(" mg/dL", color = g.muted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp, start = 4.dp))
                }
                Text(statusLabel(status), color = statusColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(
                    "${GLUCOSE_CONTEXT_LABEL[latest.context] ?: latest.context} · ${formatDateTime(latest.at)}",
                    color = g.muted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton("Registrar glicose", Icons.Filled.WaterDrop, g.violet, { nav.navigate(Routes.glucoseForm(null)) }, Modifier.weight(1f))
                ActionButton("Registrar insulina", Icons.Filled.WaterDrop, g.blue, { nav.navigate(Routes.insulinForm(null)) }, Modifier.weight(1f))
            }
        }


        // Resumo semanal rápido
        run {
            val weekMs = 7L * 24 * 60 * 60 * 1000
            val since = System.currentTimeMillis() - weekMs
            val weekG = data.glucose.filter { it.at >= since }
            val weekI = data.insulin.filter { it.at >= since }
            val low = settings.targetLow
            val high = settings.targetHigh
            val inRange = weekG.count {
                val mgv = toMgDl(it.value, it.unit)
                mgv >= low && mgv <= high
            }
            val pct = if (weekG.isNotEmpty()) inRange * 100 / weekG.size else null
            GCard(Modifier.padding(top = 12.dp).clickable { nav.navigate(Routes.CRIS_IA) }) {
                Text("Resumo dos últimos 7 dias", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                Text(
                    if (weekG.isEmpty() && weekI.isEmpty()) "Sem registros nesta semana. Toque para falar com a Cris IA."
                    else "Glicemias: ${weekG.size}" + (pct?.let { " · $it% na meta do app" } ?: "") + " · Insulinas: ${weekI.size}",
                    color = g.muted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 4.dp),
                )
                Text("Abrir Cris IA para consulta em 1 minuto →", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }

        SectionTitle("Evolução", "Ver estatísticas") { nav.navigate(Routes.STATS) }
        GCard { GlucoseChart(data.glucose, settings.targetLow, settings.targetHigh) }

        val active = data.reminders.filter { it.enabled }.sortedWith(compareBy({ it.hour }, { it.minute }))
        SectionTitle("Próximo lembrete", "Ver todos") { Routes.goTab(nav, Routes.REMINDERS) }
        GCard {
            if (active.isEmpty()) {
                Text("Nenhum lembrete ativo.", color = g.muted, fontSize = 14.sp)
            } else {
                active.take(3).forEach { r ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(r.title, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Text(
                            "${com.agon.app.data.formatClock(r.hour, r.minute)} · ${com.agon.app.data.daysLabel(r.days)}",
                            color = g.muted,
                            fontSize = 12.sp,
                        )
                        Text(
                            (if (r.kind == "glicose") "Medição de glicose" else "Aplicação de insulina") +
                                if (r.notes.isNotEmpty()) " · ${r.notes}" else "",
                            color = g.violetDeep,
                            fontSize = 12.sp,
                        )
                    }
                }
            }
        }

        SectionTitle("Histórico resumido", "Ver todos") { Routes.goTab(nav, Routes.HISTORY) }
        GCard {
            val recent = data.glucose.sortedByDescending { it.at }.take(4)
            if (recent.isEmpty()) {
                Text("Sem registros.", color = g.muted, modifier = Modifier.padding(12.dp))
            } else {
                recent.forEach { e ->
                    val v = toMgDl(e.value, e.unit)
                    val st = rangeStatus(v, settings.targetLow, settings.targetHigh)
                    val c = when (st) { "ok" -> g.green; "low" -> g.orange; else -> g.red }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { nav.navigate(Routes.glucoseForm(e.id)) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(v.roundToInt().toString(), color = c, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.padding(end = 10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(GLUCOSE_CONTEXT_LABEL[e.context] ?: e.context, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${com.agon.app.data.formatDate(e.at)} · ${com.agon.app.data.formatTime(e.at)}", color = g.muted, fontSize = 12.sp)
                        }
                        Text(statusLabel(st), color = c, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(64.dp))
    }
    Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        WaterMiniBar(
            visible = waterBarVisible,
            onOpenFull = { nav.navigate(Routes.WATER) },
            modifier = Modifier.tourTarget("home_water"),
        )
    }
    }
}
