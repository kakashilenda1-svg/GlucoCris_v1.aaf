package com.agon.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.selection.SelectionContainer
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withLink
import androidx.compose.ui.unit.TextUnit

private val URL_REGEX = Regex("""https?://[^\s<>"']+""")

/** Transforma links (https://...) do texto em trechos clicáveis que abrem no navegador. */
internal fun linkify(text: String, linkColor: Color): AnnotatedString = buildAnnotatedString {
    var last = 0
    for (m in URL_REGEX.findAll(text)) {
        // Tira pontuação/parêntese final que não faz parte do link, ex.: "(https://site.com/a)".
        var url = m.value
        while (url.isNotEmpty() && url.last() in ")].,;:!?") url = url.dropLast(1)
        if (url.length < 8) continue
        val start = m.range.first
        append(text.substring(last, start))
        withLink(
            LinkAnnotation.Url(
                url,
                TextLinkStyles(SpanStyle(color = linkColor, textDecoration = TextDecoration.Underline)),
            ),
        ) { append(url) }
        last = start + url.length
    }
    append(text.substring(last))
}

/**
 * Texto da mensagem: links clicáveis e seleção pressionando e segurando
 * (copia só o trecho escolhido).
 */
@Composable
internal fun CrisMessageText(
    text: String,
    color: Color,
    linkColor: Color,
    fontSize: TextUnit,
    lineHeight: TextUnit,
    modifier: Modifier = Modifier,
) {
    val annotated = remember(text, linkColor) { linkify(text, linkColor) }
    SelectionContainer(modifier) {
        Column { Text(annotated, color = color, fontSize = fontSize, lineHeight = lineHeight) }
    }
}

/** Copia o texto inteiro da mensagem para a área de transferência. */
internal fun copyMessageText(context: Context, text: String) {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    cm.setPrimaryClip(ClipData.newPlainText("Mensagem da Cris", text))
    Toast.makeText(context, "Texto copiado", Toast.LENGTH_SHORT).show()
}
