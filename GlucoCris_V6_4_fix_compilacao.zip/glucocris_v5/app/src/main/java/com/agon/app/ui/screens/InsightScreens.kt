package com.agon.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import androidx.core.content.FileProvider
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.formatDate
import com.agon.app.data.formatDateTime
import com.agon.app.insights.FoodResponse
import com.agon.app.insights.Insights
import com.agon.app.insights.MedicalPdf
import com.agon.app.insights.RangeStats
import com.agon.app.insights.WeeklyPrefs
import com.agon.app.insights.WeeklySummary
import com.agon.app.reminders.Caregiver
import com.agon.app.sensors.SensorClient
import com.agon.app.sensors.SensorConfig
import com.agon.app.sensors.SensorImporter
import com.agon.app.sensors.SensorSyncScheduler
import com.agon.app.ui.components.BackTitle
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.EmptyState
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GField
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val VERY_LOW_COLOR = Color(0xFFC2410C)
private val VERY_HIGH_COLOR = Color(0xFF991B1B)

@Composable
private fun TirBar(s: RangeStats) {
    val g = glucoColors()
    val parts = listOf(s.veryLowPct to VERY_LOW_COLOR, s.lowPct to g.orange, s.inRangePct to g.green, s.highPct to g.red, s.veryHighPct to VERY_HIGH_COLOR)
    Row(Modifier.fillMaxWidth().height(24.dp).clip(RoundedCornerShape(12.dp))) {
        parts.forEach { (p, c) -> if (p > 0.0) Box(Modifier.weight(p.toFloat()).fillMaxHeight().background(c)) }
    }
}

@Composable
private fun LegendLine(color: Color, label: String, pct: Double) {
    val g = glucoColors()
    Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.height(10.dp).padding(end = 0.dp).clip(RoundedCornerShape(3.dp)).background(color).padding(horizontal = 5.dp))
        Text("  $label: ${pct.roundToInt()}%", color = g.ink, fontSize = 13.sp)
    }
}

@Composable
private fun InsightSwitchRow(title: String, text: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val g = glucoColors()
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
            if (text.isNotBlank()) Text(text, color = g.muted, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

private fun shareFile(ctx: android.content.Context, f: java.io.File, mime: String, subject: String, chooser: String) {
    val uri = try {
        FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
    } catch (_: Exception) {
        android.net.Uri.fromFile(f)
    }
    val send = Intent(Intent.ACTION_SEND).apply {
        type = mime
        putExtra(Intent.EXTRA_STREAM, uri)
        putExtra(Intent.EXTRA_SUBJECT, subject)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(send, chooser))
}

// ───────────────────────── 1. Painel de padrões ─────────────────────────

@Composable
fun PatternsScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    var days by remember { mutableIntStateOf(14) }
    val low = data.settings.targetLow
    val high = data.settings.targetHigh
    val reads = remember(data.glucose, days) { Insights.readings(data, days) }
    val st = remember(reads, low, high) { Insights.stats(reads, low, high) }
    val buckets = remember(reads, low, high) { Insights.byHour(reads, low, high) }
    val daily = remember(reads, days) { Insights.dailyMeans(reads, days) }

    ScrollScreen {
        BackTitle("Painel de padrões", { nav.popBackStack() })
        Text(
            if (st?.timeInRangeMeaningful == true) "Tempo na meta ($low–$high mg/dL) com base em dados de sensor, médias por horário e horários críticos."
            else "Distribuição das medições na meta ($low–$high mg/dL), médias por horário e horários críticos. Não representa tempo real do dia.",
            color = g.muted, fontSize = 13.sp,
        )
        ChipRow(listOf("7" to "7 dias", "14" to "14 dias", "30" to "30 dias"), days.toString()) { days = it.toInt() }
        if (st == null) {
            EmptyState("Sem medições", "Registre glicemias para ver seus padrões. Os registros de exemplo do app não entram aqui.")
            return@ScrollScreen
        }
        GCard(Modifier.padding(top = 8.dp)) {
            Text(if (st.timeInRangeMeaningful) "Tempo no alvo" else "Medições na meta", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text("${st.inRangePct.roundToInt()}%", color = g.green, fontWeight = FontWeight.ExtraBold, fontSize = 34.sp)
            Text("das ${st.count} medições ficaram entre $low e $high mg/dL", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
            TirBar(st)
            LegendLine(VERY_LOW_COLOR, "Muito baixa", st.veryLowPct)
            LegendLine(g.orange, "Baixa", st.lowPct)
            LegendLine(g.green, "Na meta", st.inRangePct)
            LegendLine(g.red, "Alta", st.highPct)
            LegendLine(VERY_HIGH_COLOR, "Muito alta", st.veryHighPct)
        }
        Row(Modifier.fillMaxWidth()) {
            StatTile("Média", "${st.mean.roundToInt()}", "mg/dL", Modifier.weight(1f))
            StatTile("Variabilidade", "${st.cv.roundToInt()}%", if (st.cv <= 36) "estável (CV)" else "alta (CV)", Modifier.weight(1f))
        }
        Row(Modifier.fillMaxWidth()) {
            StatTile("Desvio padrão", "${st.sd.roundToInt()}", "mg/dL", Modifier.weight(1f))
            StatTile(
                if (st.gmiReliable) "GMI (estimativa)" else "GMI (estimativa)",
                if (st.gmiReliable) Insights.f1(st.gmi) + "%" else "—",
                if (st.gmiReliable) "Não é HbA1c de laboratório" else "Dados insuficientes",
                Modifier.weight(1f),
            )
        }

        SectionTitle("Média por horário do dia")
        GCard {
            Canvas(Modifier.fillMaxWidth().height(150.dp)) {
                val maxV = maxOf(250.0, buckets.maxOf { it.mean }).toFloat()
                val bw = size.width / 24f
                val yHigh = size.height * (1f - high / maxV)
                val yLow = size.height * (1f - low / maxV)
                drawRect(g.greenSoft, Offset(0f, yHigh), Size(size.width, yLow - yHigh))
                buckets.forEach { b ->
                    if (b.count > 0) {
                        val h = size.height * (b.mean.toFloat() / maxV)
                        val c = when { b.mean < low -> g.orange; b.mean > high -> g.red; else -> g.green }
                        drawRect(c, Offset(b.hour * bw + 2f, size.height - h), Size(bw - 4f, h))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                listOf(0, 6, 12, 18, 23).forEach { h -> Text(Insights.hourLabel(h), color = g.muted, fontSize = 11.sp, modifier = Modifier.weight(1f)) }
            }
            Text("Barras = média das medições de cada hora. Faixa clara = sua meta.", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        }

        SectionTitle("Períodos do dia")
        GCard {
            Insights.dayParts(reads).forEach { dp ->
                Text(
                    "${dp.label}: " + (dp.mean?.let { "${it.roundToInt()} mg/dL · ${dp.count} medições" } ?: "sem medições"),
                    color = g.ink, fontSize = 14.sp, modifier = Modifier.padding(vertical = 3.dp),
                )
            }
        }

        SectionTitle("Horários críticos")
        GCard {
            val lows = Insights.criticalLowHours(buckets)
            val highs = Insights.criticalHighHours(buckets)
            Text("Hipoglicemia (abaixo de $low)", color = g.orange, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            if (lows.isEmpty()) Text("Nenhum padrão de queda neste período.", color = g.muted, fontSize = 13.sp)
            lows.forEach { Text("${Insights.hourLabel(it.hour)} · ${it.lows} de ${it.count} medições baixas", color = g.ink, fontSize = 14.sp) }
            Text("Hiperglicemia (acima de $high)", color = g.red, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
            if (highs.isEmpty()) Text("Nenhum padrão de alta neste período.", color = g.muted, fontSize = 13.sp)
            highs.forEach { Text("${Insights.hourLabel(it.hour)} · ${it.highs} de ${it.count} medições altas", color = g.ink, fontSize = 14.sp) }
            Text("Só entram horários com pelo menos 2 medições.", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        }

        SectionTitle("Média diária")
        GCard {
            Canvas(Modifier.fillMaxWidth().height(120.dp)) {
                val vals = daily.mapNotNull { it.second }
                val maxV = maxOf(250.0, vals.maxOrNull() ?: 250.0).toFloat()
                val minV = 40f
                fun yOf(v: Double) = size.height * (1f - ((v.toFloat() - minV) / (maxV - minV)))
                drawRect(g.greenSoft, Offset(0f, yOf(high.toDouble())), Size(size.width, yOf(low.toDouble()) - yOf(high.toDouble())))
                val step = if (daily.size > 1) size.width / (daily.size - 1) else 0f
                val path = Path()
                var started = false
                daily.forEachIndexed { i, (_, v) ->
                    if (v != null) {
                        val p = Offset(i * step, yOf(v))
                        if (!started) { path.moveTo(p.x, p.y); started = true } else path.lineTo(p.x, p.y)
                        drawCircle(g.violet, 4f, p)
                    }
                }
                drawPath(path, g.violet, style = Stroke(width = 3f))
            }
            Text("${formatDate(daily.first().first)} → ${formatDate(daily.last().first)}", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
        }
        PrimaryButton("Gerar relatório médico em PDF", g.green, { nav.navigate(com.agon.app.Routes.MEDICAL_REPORT) }, Modifier.padding(top = 12.dp))
        PrimaryButton("Ver resumo semanal da Cris", g.violet, { nav.navigate(com.agon.app.Routes.WEEKLY) }, Modifier.padding(top = 8.dp))
    }
}

// ───────────────────────── 2. Relatório médico (PDF) ─────────────────────────

@Composable
fun MedicalReportScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val ctx = LocalContext.current
    var days by remember { mutableIntStateOf(30) }
    var busy by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val st = remember(data.glucose, days) { Insights.stats(Insights.readings(data, days), data.settings.targetLow, data.settings.targetHigh) }

    ScrollScreen {
        BackTitle("Relatório médico", { nav.popBackStack() })
        Text("PDF para levar à consulta: resumo do período, GMI estimado (quando houver dados), padrões, insulinas, medicamentos e refeições com mais carboidratos.", color = g.muted, fontSize = 13.sp)
        ChipRow(listOf("7" to "7 dias", "14" to "14 dias", "30" to "30 dias", "90" to "90 dias"), days.toString()) { days = it.toInt() }
        GCard(Modifier.padding(top = 8.dp)) {
            Text("Prévia do período", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (st == null) Text("Sem medições próprias neste período.", color = g.ink, modifier = Modifier.padding(top = 6.dp))
            else {
                Text("${st.count} medições · média ${st.mean.roundToInt()} mg/dL", color = g.ink, fontSize = 15.sp, modifier = Modifier.padding(top = 6.dp))
                Text("${st.inRangePct.roundToInt()}% na meta · variabilidade ${st.cv.roundToInt()}%", color = g.ink, fontSize = 15.sp)
                Text(
                    if (st.gmiReliable) "GMI (estimativa): ${Insights.f1(st.gmi)}% — não é HbA1c laboratorial"
                    else "GMI: dados insuficientes para estimar com confiança",
                    color = g.violet, fontWeight = FontWeight.Bold, fontSize = 16.sp,
                )
                if (st.gmiNote.isNotBlank()) {
                    Text(st.gmiNote, color = g.muted, fontSize = 12.sp)
                }
                Text("Estimativa a partir das medições registradas; não substitui o exame de laboratório.", color = g.muted, fontSize = 11.sp)
            }
        }
        PrimaryButton(if (busy) "Gerando…" else "Gerar e compartilhar PDF", g.green, {
            if (!busy) {
                busy = true; msg = ""
                scope.launch {
                    try {
                        val f = withContext(Dispatchers.Default) { MedicalPdf.build(ctx, data, days) }
                        shareFile(ctx, f, "application/pdf", "Relatório médico Gluco Cris — ${data.settings.displayName}", "Compartilhar relatório médico")
                    } catch (e: Exception) {
                        msg = "Não foi possível gerar o PDF agora."
                    }
                    busy = false
                }
            }
        }, Modifier.padding(top = 12.dp))
        if (msg.isNotBlank()) Text(msg, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        Text("Os registros de exemplo do app ficam de fora do relatório. Ele não calcula nem indica dose de insulina.", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

// ───────────────────────── 4. Resposta glicêmica por alimento ─────────────────────────

@Composable
fun FoodResponseScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val rows = remember(data.meals, data.glucose) { FoodResponse.compute(data) }
    ScrollScreen {
        BackTitle("Resposta por alimento", { nav.popBackStack() })
        Text("O app cruza o que você comeu (diário, scanner ou pesquisa) com a glicemia 1 h e 2 h depois e mostra quais alimentos mais sobem a SUA glicose.", color = g.muted, fontSize = 13.sp)
        if (rows.isEmpty()) {
            EmptyState(
                "Ainda sem dados suficientes",
                "Registre a refeição no diário e meça a glicemia cerca de 1 h e 2 h depois. Com o tempo esta lista se completa sozinha.",
            )
            return@ScrollScreen
        }
        rows.forEach { r ->
            val rise = r.rise2h ?: r.rise1h
            val color = when {
                rise == null -> g.muted
                rise >= 60 -> g.red
                rise >= 30 -> g.orange
                else -> g.green
            }
            GCard(Modifier.padding(top = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(r.name, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Text(
                            "${r.meals} refeição(ões)" + (r.avgCarbs?.let { " · ~${it.roundToInt()} g de carboidrato" } ?: "") + if (r.meals < 3) " · poucos dados" else "",
                            color = g.muted, fontSize = 12.sp,
                        )
                    }
                    Text(rise?.let { (if (it >= 0) "+" else "") + it.roundToInt() } ?: "—", color = color, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
                }
                Text(
                    "1 h depois: " + (r.avg1h?.let { "${it.roundToInt()} mg/dL" } ?: "sem medição") + (r.rise1h?.let { " (${if (it >= 0) "+" else ""}${it.roundToInt()})" } ?: ""),
                    color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp),
                )
                Text(
                    "2 h depois: " + (r.avg2h?.let { "${it.roundToInt()} mg/dL" } ?: "sem medição") + (r.rise2h?.let { " (${if (it >= 0) "+" else ""}${it.roundToInt()})" } ?: ""),
                    color = g.ink, fontSize = 13.sp,
                )
            }
        }
        Text(
            "O número grande é a subida média em mg/dL em relação à glicemia de antes da refeição (quando você mediu até 1 h antes). " +
                "Numa refeição com vários alimentos, a resposta é da refeição inteira. Serve para conversar com a equipe de saúde, não para calcular insulina.",
            color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp),
        )
    }
}

// ───────────────────────── 5. Resumo semanal da Cris ─────────────────────────

@Composable
fun WeeklySummaryScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val w = remember(data.glucose, data.meals, data.insulin) { WeeklySummary.build(data) }
    val plain = remember(w) { WeeklySummary.plainText(w, data.settings.targetLow, data.settings.targetHigh) }
    var aiText by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var notifyOn by remember { mutableStateOf(WeeklyPrefs.notifyOn(ctx)) }
    var note by remember { mutableStateOf("") }
    val shown = aiText.ifBlank { plain }

    ScrollScreen {
        BackTitle("Resumo semanal da Cris", { nav.popBackStack() })
        Text("Os últimos 7 dias, comparados com a semana anterior. A Cris só informa: ela nunca calcula nem recomenda dose de insulina.", color = g.muted, fontSize = 13.sp)
        w.cur?.let { c ->
            Row(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                StatTile("Na meta", "${c.inRangePct.roundToInt()}%", w.prev?.let { "antes ${it.inRangePct.roundToInt()}%" } ?: "semana atual", Modifier.weight(1f))
                StatTile("Média", "${c.mean.roundToInt()}", w.prev?.let { "antes ${it.mean.roundToInt()}" } ?: "mg/dL", Modifier.weight(1f))
            }
        }
        GCard(Modifier.padding(top = 4.dp)) {
            Text(shown, color = g.ink, fontSize = 14.sp, lineHeight = 20.sp)
        }
        PrimaryButton(if (busy) "A Cris está escrevendo…" else "Pedir à Cris um resumo em texto amigável", g.violet, {
            if (!busy && w.cur != null) {
                busy = true; note = ""
                scope.launch {
                    val r = try {
                        com.agon.app.data.CrisGemini.chatAsCris(
                            ctx, WeeklySummary.promptFor(w, plain), emptyList(),
                            "Resumo semanal pedido na tela do app (apenas números agregados da semana).", data.settings.displayName,
                        )
                    } catch (_: Exception) { null }
                    if (r.isNullOrBlank()) note = "A Cris não conseguiu responder agora (sem internet?). O resumo acima foi montado pelo app."
                    else { aiText = r.trim(); WeeklyPrefs.cache(ctx, aiText) }
                    busy = false
                }
            }
        }, Modifier.padding(top = 10.dp))
        if (note.isNotBlank()) Text(note, color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        PrimaryButton("Compartilhar resumo", g.green, {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_SUBJECT, "Resumo semanal — ${data.settings.displayName}")
                putExtra(Intent.EXTRA_TEXT, shown)
            }
            ctx.startActivity(Intent.createChooser(send, "Compartilhar resumo"))
        }, Modifier.padding(top = 8.dp))
        GCard(Modifier.padding(top = 10.dp)) {
            InsightSwitchRow("Aviso todo domingo à noite", "A Cris avisa quando o resumo da semana estiver pronto.", notifyOn) {
                notifyOn = it; WeeklyPrefs.setNotifyOn(ctx, it)
            }
        }
    }
}

// ───────────────────────── 3. Modo cuidador / família ─────────────────────────

@Composable
fun CaregiverScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val ctx = LocalContext.current
    var consent by remember { mutableStateOf(Caregiver.consent(ctx)) }
    var askConsent by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(Caregiver.name(ctx)) }
    var phone by remember { mutableStateOf(Caregiver.phone(ctx)) }
    var channel by remember { mutableStateOf(Caregiver.channel(ctx)) }
    var alerts by remember { mutableStateOf(Caregiver.alertsOn(ctx)) }
    var summary by remember { mutableStateOf(Caregiver.summaryAllowed(ctx)) }
    var sLow by remember { mutableStateOf(Caregiver.severeLow(ctx).toString()) }
    var sHigh by remember { mutableStateOf(Caregiver.severeHigh(ctx).toString()) }
    var err by remember { mutableStateOf("") }

    fun sendMsg(body: String) {
        try { ctx.startActivity(Caregiver.sendIntent(ctx, body)) } catch (_: Exception) { err = "Não encontrei o app de ${if (channel == "whatsapp") "WhatsApp" else "SMS"} neste aparelho." }
    }

    ScrollScreen {
        BackTitle("Modo cuidador", { nav.popBackStack() })
        Text("Um contato de confiança pode receber o aviso de glicemia muito baixa ou muito alta e o resumo do dia — sempre com a sua permissão.", color = g.muted, fontSize = 13.sp)
        GCard(Modifier.padding(top = 8.dp)) {
            InsightSwitchRow("Permito avisar meu cuidador", "Desligado, nada é preparado nem sugerido.", consent) {
                if (it) askConsent = true else { consent = false; Caregiver.setConsent(ctx, false) }
            }
        }
        if (consent) {
            GCard(Modifier.padding(top = 4.dp)) {
                GField("Nome do contato", name, { name = it; Caregiver.setName(ctx, it) }, "Ex.: Ana (filha)")
                GField("Telefone com DDI e DDD (só números)", phone, { phone = it.filter { c -> c.isDigit() }; Caregiver.setPhone(ctx, phone) }, "5511999998888", numeric = true)
                Text("Enviar por", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                ChipRow(listOf("sms" to "SMS", "whatsapp" to "WhatsApp"), channel) { channel = it; Caregiver.setChannel(ctx, it) }
            }
            GCard(Modifier.padding(top = 4.dp)) {
                InsightSwitchRow("Avisar glicemia grave", "Quando a glicemia passar dos limites abaixo, o app mostra uma notificação com a mensagem pronta.", alerts) { alerts = it; Caregiver.setAlertsOn(ctx, it) }
                Text("Muito baixa abaixo de (mg/dL)", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                ChipRow(listOf("45" to "45", "54" to "54", "60" to "60", "70" to "70"), sLow) { sLow = it; Caregiver.setSevereLow(ctx, it.toInt()) }
                Text("Muito alta acima de (mg/dL)", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                ChipRow(listOf("250" to "250", "300" to "300", "350" to "350", "400" to "400"), sHigh) { sHigh = it; Caregiver.setSevereHigh(ctx, it.toInt()) }
            }
            GCard(Modifier.padding(top = 4.dp)) {
                InsightSwitchRow("Compartilhar resumo do dia", "Mostra o botão de enviar o resumo (medições, média, tempo na meta).", summary) { summary = it; Caregiver.setSummaryAllowed(ctx, it) }
            }
            if (summary) {
                PrimaryButton("Enviar resumo do dia agora", g.violet, {
                    if (!Caregiver.ready(ctx)) err = "Informe o telefone do contato."
                    else { err = ""; sendMsg(Caregiver.dailySummaryText(ctx, data)) }
                }, Modifier.padding(top = 8.dp))
            }
            PrimaryButton("Ver mensagem de aviso (exemplo)", g.blue, {
                if (!Caregiver.ready(ctx)) err = "Informe o telefone do contato."
                else { err = ""; sendMsg(Caregiver.alertText(data.settings.displayName, 48.0, System.currentTimeMillis(), true) + " (TESTE)") }
            }, Modifier.padding(top = 8.dp))
            if (err.isNotBlank()) Text(err, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
        }
        GCard(Modifier.padding(top = 10.dp)) {
            Text("Como funciona", color = g.ink, fontWeight = FontWeight.Bold)
            Text(
                "O app prepara a mensagem e abre o SMS ou o WhatsApp do seu aparelho; você toca em enviar. Nada é enviado escondido e nenhum servidor recebe esses dados. " +
                    "Por isso o aviso só sai com o app/notificação ativa neste aparelho e com o celular com sinal. Não substitui socorro: em emergência, ligue 192 (SAMU).",
                color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
    if (askConsent) {
        AlertDialog(
            onDismissRequest = { askConsent = false },
            title = { Text("Permitir aviso ao cuidador?") },
            text = { Text("Você escolhe um contato de confiança. Quando a glicemia ficar muito baixa ou muito alta, o app deixa pronta uma mensagem com o valor e o horário para você enviar. Você pode desligar quando quiser.") },
            confirmButton = { TextButton(onClick = { consent = true; Caregiver.setConsent(ctx, true); askConsent = false }) { Text("Permitir") } },
            dismissButton = { TextButton(onClick = { askConsent = false }) { Text("Agora não") } },
        )
    }
}

// ───────────────────────── 6. Sensores ─────────────────────────

@Composable
private fun SecretField(label: String, value: String, onChange: (String) -> Unit, placeholder: String = "") {
    val g = glucoColors()
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            textStyle = androidx.compose.ui.text.TextStyle(color = g.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(12.dp)).background(g.inputBg).padding(horizontal = 14.dp, vertical = 14.dp),
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) Text(placeholder, color = g.muted, fontSize = 15.sp)
                    inner()
                }
            },
        )
    }
}

@Composable
fun SensorsScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var provider by remember { mutableStateOf(SensorConfig.provider(ctx)) }
    var url by remember { mutableStateOf(SensorConfig.url(ctx)) }
    var token by remember { mutableStateOf(SensorConfig.token(ctx)) }
    var dexUser by remember { mutableStateOf(SensorConfig.user(ctx, SensorConfig.DEXCOM)) }
    var dexPass by remember { mutableStateOf(SensorConfig.pass(ctx, SensorConfig.DEXCOM)) }
    var dexRegion by remember { mutableStateOf(SensorConfig.dexRegion(ctx)) }
    var libUser by remember { mutableStateOf(SensorConfig.user(ctx, SensorConfig.LIBRE)) }
    var libPass by remember { mutableStateOf(SensorConfig.pass(ctx, SensorConfig.LIBRE)) }
    var auto by remember { mutableStateOf(SensorConfig.autoOn(ctx)) }
    var busy by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }

    fun save() {
        SensorConfig.setProvider(ctx, provider)
        SensorConfig.setUrl(ctx, url); SensorConfig.setToken(ctx, token)
        SensorConfig.setUser(ctx, SensorConfig.DEXCOM, dexUser); SensorConfig.setPass(ctx, SensorConfig.DEXCOM, dexPass); SensorConfig.setDexRegion(ctx, dexRegion)
        SensorConfig.setUser(ctx, SensorConfig.LIBRE, libUser); SensorConfig.setPass(ctx, SensorConfig.LIBRE, libPass)
        SensorConfig.setAutoOn(ctx, auto)
        SensorSyncScheduler.refresh(ctx)
    }

    val lastAt = remember(tick) { SensorConfig.lastReadingAt(ctx) }
    val lastVal = remember(tick) { SensorConfig.lastValue(ctx) }
    val lastTrend = remember(tick) { SensorConfig.lastTrend(ctx) }
    val lastMsg = remember(tick) { SensorConfig.lastMsg(ctx) }
    val lastSync = remember(tick) { SensorConfig.lastSync(ctx) }

    ScrollScreen {
        BackTitle("Sensores", { nav.popBackStack() })
        Text("Leitura automática da glicose do FreeStyle Libre e do Dexcom. As leituras entram no histórico (uma a cada 15 min) e valem para painel, relatório e alertas.", color = g.muted, fontSize = 13.sp)
        if (lastAt > 0L) {
            GCard(Modifier.padding(top = 8.dp)) {
                Text("Última leitura do sensor", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text("${lastVal.roundToInt()} mg/dL ${SensorClient.trendArrow(lastTrend)}", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp)
                Text(formatDateTime(lastAt), color = g.muted, fontSize = 12.sp)
            }
        }
        ChipRow(
            listOf(SensorConfig.NONE to "Nenhum", SensorConfig.LIBRE to "Libre", SensorConfig.DEXCOM to "Dexcom", SensorConfig.NIGHTSCOUT to "Nightscout"),
            provider,
        ) { provider = it }
        when (provider) {
            SensorConfig.LIBRE -> GCard(Modifier.padding(top = 4.dp)) {
                Text("FreeStyle Libre (via LibreLinkUp)", color = g.ink, fontWeight = FontWeight.Bold)
                Text("No app FreeStyle Libre, compartilhe seus dados com o LibreLinkUp (convite por e-mail) e aceite no app LibreLinkUp. Aqui entre com essa conta de SEGUIDOR.", color = g.muted, fontSize = 12.sp)
                GField("E-mail do LibreLinkUp", libUser, { libUser = it }, "voce@email.com")
                SecretField("Senha", libPass, { libPass = it })
            }
            SensorConfig.DEXCOM -> GCard(Modifier.padding(top = 4.dp)) {
                Text("Dexcom (Share)", color = g.ink, fontWeight = FontWeight.Bold)
                Text("No app Dexcom, ligue o compartilhamento (Share). Use o usuário e a senha da conta Dexcom.", color = g.muted, fontSize = 12.sp)
                GField("Usuário Dexcom", dexUser, { dexUser = it }, "usuário ou e-mail")
                SecretField("Senha", dexPass, { dexPass = it })
                Text("Região da conta", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                ChipRow(listOf("ous" to "Fora dos EUA (Brasil)", "us" to "EUA"), dexRegion) { dexRegion = it }
            }
            SensorConfig.NIGHTSCOUT -> GCard(Modifier.padding(top = 4.dp)) {
                Text("Nightscout", color = g.ink, fontWeight = FontWeight.Bold)
                Text("Serve para Libre (com xDrip+, Juggluco ou Nightscout) e para Dexcom. É o caminho mais estável.", color = g.muted, fontSize = 12.sp)
                GField("Endereço do Nightscout", url, { url = it }, "https://meu-site.herokuapp.com")
                SecretField("Token de acesso ou API secret (se houver)", token, { token = it })
            }
            else -> Text("Escolha o seu sensor acima.", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        }
        if (provider != SensorConfig.NONE) {
            GCard(Modifier.padding(top = 4.dp)) {
                InsightSwitchRow("Ler automaticamente", "A cada 15 minutos, com internet (e sempre que abrir o app).", auto) { auto = it }
            }
            PrimaryButton(if (busy) "Conectando…" else "Salvar e ler agora", g.violet, {
                if (!busy) {
                    save(); busy = true
                    scope.launch {
                        SensorImporter.syncOnce(ctx)
                        tick++; busy = false
                    }
                }
            }, Modifier.padding(top = 8.dp))
            if (lastSync > 0L) {
                Text("Última tentativa: ${formatDateTime(lastSync)} — $lastMsg", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        } else {
            PrimaryButton("Salvar (sensor desligado)", g.violet, { save(); tick++ }, Modifier.padding(top = 8.dp))
        }
        GCard(Modifier.padding(top = 10.dp)) {
            Text("Importante", color = g.ink, fontWeight = FontWeight.Bold)
            Text(
                "• Libre e Dexcom Share usam serviços não oficiais dos fabricantes; eles podem mudar sem aviso e a leitura pode parar até o app ser atualizado.\n" +
                    "• Senhas ficam só neste aparelho, cifradas.\n" +
                    "• Leituras de sensor podem diferir da glicemia no sangue. Para decidir dose de insulina ou tratar hipoglicemia, confirme com o glicosímetro e siga a orientação da sua equipe de saúde.",
                color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
            )
        }
    }
}
