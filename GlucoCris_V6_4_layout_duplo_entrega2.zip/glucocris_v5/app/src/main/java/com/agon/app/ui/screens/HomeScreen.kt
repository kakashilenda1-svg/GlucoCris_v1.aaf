package com.agon.app.ui.screens

import android.Manifest
import android.content.Context
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.formatDateTime
import com.agon.app.data.formatLongDate
import com.agon.app.data.greeting
import com.agon.app.data.rangeStatus
import com.agon.app.data.statusLabel
import com.agon.app.data.toMgDl
import com.agon.app.data.weekdayLong
import com.agon.app.love.LOVE_PHONE_DISPLAY
import com.agon.app.love.LOVE_PHONE_TEL
import com.agon.app.love.MAIN_LOVE_MESSAGE
import com.agon.app.love.SAMU_TEL
import com.agon.app.love.openDialer
import com.agon.app.love.openWhatsApp
import com.agon.app.love.phraseForToday
import com.agon.app.ui.components.ActionButton
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GlucoseChart
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.components.tourTarget
import com.agon.app.ui.theme.glucoColors
import kotlin.math.roundToInt

@Composable
fun HomeScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val settings = data.settings
    val appearancePrefs = remember { context.getSharedPreferences("glucocris_home_appearance", Context.MODE_PRIVATE) }
    var pinkTheme by remember { mutableStateOf(appearancePrefs.getBoolean("pink_theme", false)) }
    val baseColors = glucoColors()
    val g = if (pinkTheme) {
        baseColors.copy(
            bg = Color(0xFF10051F), card = Color(0xFF28104B), ink = Color(0xFFFFE8FA),
            muted = Color(0xFFD9B9E9), line = Color(0xFF8B4CC2), violet = Color(0xFF8B2BE2),
            violetDeep = Color(0xFFE6B8FF), blue = Color(0xFFB65CFF), blueSoft = Color(0xFF35145B),
            heroStart = Color(0xFF270044), heroEnd = Color(0xFF6B12D8),
            blush = Color(0xFFFF55B8), blushSoft = Color(0xFFFFD0EA),
        )
    } else {
        baseColors.copy(
            bg = Color(0xFF061A3B), card = Color(0xFF102F60), ink = Color(0xFFF4F8FF),
            muted = Color(0xFFC2D3EA), line = Color(0xFF327BCB), violet = Color(0xFF1558C8),
            violetDeep = Color(0xFF75B8FF), blue = Color(0xFF1689F8), blueSoft = Color(0xFF123A75),
            heroStart = Color(0xFF0A2D5C), heroEnd = Color(0xFF06142F),
            blush = Color(0xFFB9DFFF), blushSoft = Color(0xFFDCEBFF),
        )
    }
    var phrase by remember { mutableStateOf("") }
    var showMood by remember { mutableStateOf(false) }
    var waterBarVisible by remember { mutableStateOf(true) }
    val scrollWatcher = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -6f) waterBarVisible = false
                else if (available.y > 6f) waterBarVisible = true
                return Offset.Zero
            }
        }
    }
    LaunchedEffect(Unit) { phrase = phraseForToday(context) }
    if (showMood) {
        MoodSheet(settings.mood, settings.moodStyle, { st -> vm.updateSettings { it.copy(moodStyle = st) } }, onDismiss = { showMood = false }) { id ->
            vm.updateSettings { it.copy(mood = id, moodAt = System.currentTimeMillis()) }
            showMood = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val latest = data.glucose.maxByOrNull { it.at }
    val mg = latest?.let { toMgDl(it.value, it.unit) }
    val status = mg?.let { rangeStatus(it, settings.targetLow, settings.targetHigh) }
    val statusColor = when (status) {
        "ok" -> g.green
        "low" -> g.orange
        "high" -> g.red
        else -> g.muted
    }

    Box(Modifier.fillMaxSize().background(g.bg).nestedScroll(scrollWatcher)) {
        ScrollScreen {
            // Cabeçalho e alternância de aparência: preferência salva apenas neste dispositivo.
            Column(
                Modifier.fillMaxWidth()
                    .clip(RoundedCornerShape(28.dp))
                    .background(Brush.verticalGradient(listOf(g.heroStart, g.bg)))
                    .padding(horizontal = 16.dp, vertical = 14.dp)
            ) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("Gluco Cris", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.weight(1f))
                    Box(
                        Modifier.size(42.dp).clip(CircleShape)
                            .background(Brush.radialGradient(listOf(Color(0xFF42A5FF), Color(0xFF073A91))))
                            .border(2.dp, Color(0xFF73C5FF), CircleShape)
                            .tourTarget("home_theme")
                            .clickable {
                                pinkTheme = !pinkTheme
                                appearancePrefs.edit().putBoolean("pink_theme", pinkTheme).apply()
                            }
                    )
                    Spacer(Modifier.width(10.dp))
                    Box(
                        Modifier.size(42.dp).clip(CircleShape)
                            .background(if (pinkTheme) Color(0xFF54118B) else Color(0xFF123D78))
                            .border(1.5.dp, if (pinkTheme) Color(0xFFB86CFF) else Color(0xFF4A9BEA), CircleShape)
                            .tourTarget("home_help")
                            .clickable { nav.navigate(Routes.HELP_CENTER) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text("?", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    }
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    RobotMascot(pinkTheme, Modifier.width(132.dp).height(154.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            com.agon.app.data.firstName(settings.displayName).let { first ->
                                if (first.isNotBlank()) "${greeting()}, $first!" else "${greeting()}!"
                            },
                            color = Color.White, fontSize = 25.sp, lineHeight = 29.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Box(
                            Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(30.dp))
                                .background(Color.White.copy(alpha = 0.14f))
                                .clickable { showMood = true }
                                .padding(horizontal = 12.dp, vertical = 12.dp)
                        ) {
                            Text("Como você está se sentindo?", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        }
                        Text(
                            "${weekdayLong().replaceFirstChar { it.uppercase() }}, ${formatLongDate()}",
                            color = Color.White.copy(alpha = 0.82f), fontSize = 12.sp,
                            modifier = Modifier.padding(top = 12.dp)
                        )
                    }
                }
            }

            // Painel 2x2: usa os mesmos registros e cálculos já existentes no aplicativo.
            val weekMs = 7L * 24 * 60 * 60 * 1000
            val since = System.currentTimeMillis() - weekMs
            val weekG = data.glucose.filter { it.at >= since }
            val weekI = data.insulin.filter { it.at >= since }
            val inRange = weekG.count {
                val v = toMgDl(it.value, it.unit)
                v >= settings.targetLow && v <= settings.targetHigh
            }
            val pct = if (weekG.isNotEmpty()) inRange * 100 / weekG.size else null

            Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(
                    Modifier.weight(1.35f).height(222.dp)
                        .clip(RoundedCornerShape(25.dp))
                        .background(Brush.verticalGradient(listOf(if (pinkTheme) Color(0xFF451078) else Color(0xFF164B91), g.bg)))
                        .border(1.5.dp, g.line, RoundedCornerShape(25.dp))
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.WaterDrop, null, tint = Color.White, modifier = Modifier.size(26.dp))
                        Text("Última medição", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 12.dp))
                    }
                    if (latest == null || mg == null || status == null) {
                        Text("Nenhuma medição ainda.", color = g.muted, modifier = Modifier.padding(top = 22.dp))
                    } else {
                        Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(top = 12.dp)) {
                            Text(mg.roundToInt().toString(), color = statusColor, fontWeight = FontWeight.ExtraBold, fontSize = 48.sp)
                            Text(" mg/dL", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(bottom = 9.dp, start = 4.dp))
                        }
                        Text(statusLabel(status), color = statusColor, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Text(
                            "${GLUCOSE_CONTEXT_LABEL[latest.context] ?: latest.context} · ${formatDateTime(latest.at)}",
                            color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp,
                            modifier = Modifier.padding(top = 8.dp)
                        )
                    }
                }
                Column(
                    Modifier.weight(0.9f).height(222.dp)
                        .clip(RoundedCornerShape(25.dp))
                        .background(Brush.verticalGradient(listOf(if (pinkTheme) Color(0xFF35105F) else Color(0xFF12396F), g.bg)))
                        .border(1.5.dp, g.line, RoundedCornerShape(25.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.SpaceEvenly
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.BarChart, null, tint = Color.White, modifier = Modifier.size(22.dp))
                            Text("Glicemias", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
                        }
                        Text("(7 dias)", color = Color.White.copy(alpha = .85f), fontSize = 12.sp, modifier = Modifier.padding(start = 30.dp))
                        Text(weekG.size.toString(), color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 30.dp))
                    }
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.WaterDrop, null, tint = Color.White, modifier = Modifier.size(22.dp))
                            Text("Insulinas", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 8.dp))
                        }
                        Text("(7 dias)", color = Color.White.copy(alpha = .85f), fontSize = 12.sp, modifier = Modifier.padding(start = 30.dp))
                        Text(weekI.size.toString(), color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 30.dp))
                    }
                    if (pct != null) Text("$pct% na meta", color = Color.White.copy(alpha = .82f), fontSize = 11.sp)
                }
            }

            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton("Registrar glicose", Icons.Filled.WaterDrop, g.violet, { nav.navigate(Routes.glucoseForm(null)) }, Modifier.weight(1f))
                ActionButton("Registrar insulina", Icons.Filled.WaterDrop, g.blue, { nav.navigate(Routes.insulinForm(null)) }, Modifier.weight(1f))
            }

            Column(
                Modifier.fillMaxWidth().padding(top = 14.dp)
                    .clip(RoundedCornerShape(25.dp))
                    .background(if (pinkTheme) Color(0xFFFFD4EC) else Color(0xFFE1EDFF))
                    .padding(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Chat, null, tint = if (pinkTheme) Color(0xFFB51665) else Color(0xFF0C2D5D), modifier = Modifier.size(25.dp))
                    Text("Uma mensagem para você", color = if (pinkTheme) Color(0xFF6E124B) else Color(0xFF0B2853), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(start = 12.dp))
                }
                Text(MAIN_LOVE_MESSAGE, color = if (pinkTheme) Color(0xFF4C123C) else Color(0xFF10264B), fontSize = 15.sp, lineHeight = 22.sp, modifier = Modifier.padding(top = 10.dp))
                if (phrase.isNotEmpty()) {
                    Text(phrase, color = if (pinkTheme) Color(0xFF7D1758) else Color(0xFF183C72), fontSize = 13.sp, fontStyle = FontStyle.Italic, modifier = Modifier.padding(top = 10.dp))
                    Text("♡  Frase carinhosa de hoje", color = if (pinkTheme) Color(0xFF7D1758) else Color(0xFF183C72), fontSize = 12.sp)
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(top = 14.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Brush.horizontalGradient(if (pinkTheme) listOf(Color(0xFF7B16E8), Color(0xFFCE28B7)) else listOf(Color(0xFF0879D8), Color(0xFF063A86))))
                    .clickable { nav.navigate(Routes.CRIS_IA) }
                    .padding(horizontal = 18.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RobotMascot(pinkTheme, Modifier.size(70.dp))
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("Conversar com a Cris IA", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                    Text("Sua assistente de cuidado", color = Color.White.copy(alpha = .9f), fontSize = 13.sp)
                }
                Icon(Icons.Filled.ArrowForward, null, tint = Color.White, modifier = Modifier.size(28.dp))
            }

            // Ações que já existiam continuam disponíveis na tela inicial.
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton("Ligar para meu amor", Icons.Filled.Call, g.violet, { openDialer(context, LOVE_PHONE_TEL) }, Modifier.weight(1f))
                ActionButton("WhatsApp", Icons.Filled.Favorite, g.blush, { openWhatsApp(context) }, Modifier.weight(1f))
            }
            Text(
                "A ligação abre o discador para confirmação. O WhatsApp abre a conversa sem enviar mensagem.",
                color = g.muted, fontSize = 10.sp, modifier = Modifier.padding(top = 5.dp, start = 4.dp, end = 4.dp)
            )
            Row(
                Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(16.dp))
                    .background(g.red).clickable { openDialer(context, SAMU_TEL) }
                    .padding(horizontal = 16.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.LocalHospital, null, tint = Color.White)
                Text("Emergência — SAMU 192", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 10.dp))
            }

            // Mantém o seletor de humor e os demais dados do perfil funcionando.
            MoodButton(settings.mood, settings.moodStyle == "bruxo") { showMood = true }
            Text("Seu espaço de cuidado, organizado com calma e clareza.", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        SectionTitle("Evolução", "Ver estatísticas") { nav.navigate(Routes.STATS) }
        GCard { GlucoseChart(data.glucose, settings.targetLow, settings.targetHigh) }

        val active = data.reminders.filter { it.enabled }.sortedWith(compareBy({ it.hour }, { it.minute }))
        SectionTitle("Próximo lembrete", "Ver todos") { Routes.goTab(nav, Routes.REMINDERS) }
        GCard {
            if (active.isEmpty()) {
                Text("Nenhum lembrete ativo.", color = g.muted, fontSize = 14.sp)
            } else {
                active.take(3).forEach { r ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(r.title, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Text(
                            "${com.agon.app.data.formatClock(r.hour, r.minute)} · ${com.agon.app.data.daysLabel(r.days)}",
                            color = g.muted,
                            fontSize = 12.sp,
                        )
                        Text(
                            (if (r.kind == "glicose") "Medição de glicose" else "Aplicação de insulina") +
                                if (r.notes.isNotEmpty()) " · ${r.notes}" else "",
                            color = g.violetDeep,
                            fontSize = 12.sp,
                        )
                    }
                }
            }
        }

        SectionTitle("Histórico resumido", "Ver todos") { Routes.goTab(nav, Routes.HISTORY) }
        GCard {
            val recent = data.glucose.sortedByDescending { it.at }.take(4)
            if (recent.isEmpty()) {
                Text("Sem registros.", color = g.muted, modifier = Modifier.padding(12.dp))
            } else {
                recent.forEach { e ->
                    val v = toMgDl(e.value, e.unit)
                    val st = rangeStatus(v, settings.targetLow, settings.targetHigh)
                    val c = when (st) { "ok" -> g.green; "low" -> g.orange; else -> g.red }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { nav.navigate(Routes.glucoseForm(e.id)) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(v.roundToInt().toString(), color = c, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.padding(end = 10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(GLUCOSE_CONTEXT_LABEL[e.context] ?: e.context, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${com.agon.app.data.formatDate(e.at)} · ${com.agon.app.data.formatTime(e.at)}", color = g.muted, fontSize = 12.sp)
                        }
                        Text(statusLabel(st), color = c, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(64.dp))
    }
    Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        WaterMiniBar(
            visible = waterBarVisible,
            onOpenFull = { nav.navigate(Routes.WATER) },
            modifier = Modifier.tourTarget("home_water"),
        )
    }
    }
}


@Composable
private fun RobotMascot(pink: Boolean, modifier: Modifier = Modifier) {
    val accent = if (pink) Color(0xFFFF55B8) else Color(0xFF26A7FF)
    val darkFace = Color(0xFF07152D)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Box(
            Modifier.fillMaxWidth(0.82f).weight(1f).clip(RoundedCornerShape(30.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFFFFFFFF), Color(0xFFD9E5F7))))
                .border(2.dp, accent.copy(alpha = .8f), RoundedCornerShape(30.dp)),
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier.fillMaxWidth(.78f).fillMaxSize(.62f).clip(RoundedCornerShape(18.dp))
                    .background(darkFace),
                contentAlignment = Alignment.Center
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(if (pink) 13.dp else 15.dp, if (pink) 23.dp else 9.dp).clip(CircleShape).background(accent))
                    Box(Modifier.size(if (pink) 13.dp else 15.dp, if (pink) 23.dp else 9.dp).clip(CircleShape).background(accent))
                }
                if (pink) {
                    Text("⌣", color = accent, fontSize = 22.sp, modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 3.dp))
                }
            }
        }
        Box(
            Modifier.fillMaxWidth(.9f).height(48.dp).padding(top = 4.dp)
                .clip(RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp, bottomStart = 10.dp, bottomEnd = 10.dp))
                .background(Brush.verticalGradient(listOf(Color(0xFFEAF1FC), Color(0xFFB9CBE5)))),
            contentAlignment = Alignment.Center
        ) {
            if (pink) {
                Text("♥", color = accent, fontSize = 34.sp, fontWeight = FontWeight.Bold)
            } else {
                Box(Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(accent))
            }
        }
    }
}
