# Gluco Cris V6.4 — Dois layouts da tela inicial (azul / rosa-roxo)

## Arquivos alterados
- `ui/screens/HomeScreen.kt` — tela inicial reescrita só na apresentação; mesmos dados (GlucoViewModel), mesmas ações, mesmos botões.
- `MainActivity.kt` — carrega a preferência no início e aplica as cores da barra inferior SOMENTE na rota Início.
- `ui/screens/TourGuide.kt` — texto do tour do botão redondo (agora troca o layout da tela Início).

## Arquivos novos
- `data/HomeLayoutStore.kt` — guarda a escolha localmente (SharedPreferences `home_layout_prefs`), sem rede/Firebase.
- `ui/screens/HomeLayouts.kt` — paletas dos dois layouts, fundo neon e os dois robôs desenhados em vetor (Canvas).

## Comportamento
- Primeira abertura: layout azul. Cada toque no botão redondo alterna azul <-> rosa/roxo (Crossfade de 260 ms), sem abrir telas.
- A escolha persiste ao fechar o app. Botão (?) inalterado (abre a Central de ajuda).
- O botão redondo não altera mais `settings.blueTheme` (campo mantido no modelo/backup, sem uso na UI).
- Demais telas não foram tocadas.

## Status
Código escrito e revisado, NÃO compilado neste ambiente (sem Android SDK / sem rede). Compile com `./gradlew assembleDebug`.
