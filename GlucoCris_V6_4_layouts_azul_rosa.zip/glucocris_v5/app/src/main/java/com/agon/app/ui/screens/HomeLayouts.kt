package com.agon.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

/** Paleta dos dois layouts da tela inicial. Só visual. */
data class HomePalette(
    val pink: Boolean,
    val bgTop: Color,
    val bgBottom: Color,
    val glow: Color,
    val panelA: Color,
    val panelB: Color,
    val panelBorder: Color,
    val accent: Color,
    val msgBg: Color,
    val msgInk: Color,
    val msgTitle: Color,
    val ctaA: Color,
    val ctaB: Color,
    val navBg: Color,
    val navSelected: Color,
    val navIndicator: Color,
    val navUnselected: Color,
)

val HomeBluePalette = HomePalette(
    pink = false,
    bgTop = Color(0xFF040B1E), bgBottom = Color(0xFF0A2250), glow = Color(0xFF1E90FF),
    panelA = Color(0xFF123A78), panelB = Color(0xFF081A3E), panelBorder = Color(0xFF3B9BFF),
    accent = Color(0xFF3FA2FF),
    msgBg = Color(0xFFDCE8F8), msgInk = Color(0xFF14213D), msgTitle = Color(0xFF0B1B3A),
    ctaA = Color(0xFF1565D8), ctaB = Color(0xFF0A3C9A),
    navBg = Color(0xFF071634), navSelected = Color(0xFF3FA2FF), navIndicator = Color(0xFF123A78), navUnselected = Color(0xFFE2ECFA),
)

val HomePinkPalette = HomePalette(
    pink = true,
    bgTop = Color(0xFF05010D), bgBottom = Color(0xFF1B0640), glow = Color(0xFFA855F7),
    panelA = Color(0xFF3A1673), panelB = Color(0xFF14062E), panelBorder = Color(0xFFB77BFF),
    accent = Color(0xFFC084FC),
    msgBg = Color(0xFFFFD6EA), msgInk = Color(0xFF4A0F3A), msgTitle = Color(0xFF8A0F5C),
    ctaA = Color(0xFFA03BFF), ctaB = Color(0xFF6D28D9),
    navBg = Color(0xFF12052B), navSelected = Color(0xFFD8A8FF), navIndicator = Color(0xFF3A1673), navUnselected = Color(0xFFE9D8FF),
)

fun homePalette(pink: Boolean) = if (pink) HomePinkPalette else HomeBluePalette

/** Fundo da tela inicial: degradê escuro + brilho neon nos cantos. */
@Composable
fun HomeBackdrop(p: HomePalette, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.bgTop, p.bgBottom)))) {
        Canvas(Modifier.fillMaxSize()) {
            drawCircle(
                Brush.radialGradient(listOf(p.glow.copy(alpha = 0.40f), Color.Transparent), center = Offset(size.width * 0.15f, size.height * 0.12f), radius = size.width * 0.75f),
                radius = size.width * 0.75f, center = Offset(size.width * 0.15f, size.height * 0.12f),
            )
            drawCircle(
                Brush.radialGradient(listOf(p.glow.copy(alpha = 0.22f), Color.Transparent), center = Offset(size.width * 0.95f, size.height * 0.85f), radius = size.width * 0.7f),
                radius = size.width * 0.7f, center = Offset(size.width * 0.95f, size.height * 0.85f),
            )
        }
        content()
    }
}

/**
 * Robô da Cris desenhado em vetor (sem emoji e sem arquivo de imagem).
 * pink=false: robô branco e azul com cruz. pink=true: olhos expressivos, bochechas rosadas e coração nas mãos.
 */
@Composable
fun CrisRobot(pink: Boolean, modifier: Modifier = Modifier, headOnly: Boolean = false) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val shell = Brush.verticalGradient(listOf(Color.White, Color(0xFFC9D3E6)))
        val dark = Color(0xFF070F24)
        val neon = if (pink) Color(0xFFFF7AD9) else Color(0xFF38B6FF)
        val ear = if (pink) Color(0xFF8B3DFF) else Color(0xFF1E7BFF)

        if (!headOnly) {
            // corpo
            val body = Path().apply {
                moveTo(w * 0.18f, h)
                lineTo(w * 0.24f, h * 0.70f)
                quadraticBezierTo(w * 0.50f, h * 0.60f, w * 0.76f, h * 0.70f)
                lineTo(w * 0.82f, h)
                close()
            }
            drawPath(body, shell)
            // ombros
            drawCircle(Color(0xFF1B2A4A), w * 0.075f, Offset(w * 0.17f, h * 0.76f))
            drawCircle(Color(0xFF1B2A4A), w * 0.075f, Offset(w * 0.83f, h * 0.76f))
            if (pink) {
                drawHeart(Offset(w * 0.50f, h * 0.86f), w * 0.15f, Color(0xFFFF4FA8))
            } else {
                // cruz médica
                val cx = w * 0.50f
                val cy = h * 0.84f
                val t = w * 0.045f
                val l = w * 0.12f
                drawRoundRect(Color(0xFF1E7BFF), Offset(cx - t, cy - l), Size(t * 2, l * 2), CornerRadius(t * 0.6f))
                drawRoundRect(Color(0xFF1E7BFF), Offset(cx - l, cy - t), Size(l * 2, t * 2), CornerRadius(t * 0.6f))
            }
        }

        val headTop = if (headOnly) h * 0.06f else h * 0.02f
        val headH = if (headOnly) h * 0.88f else h * 0.60f
        val headL = w * 0.20f
        val headW = w * 0.60f
        if (pink) {
            // antena
            drawLine(Color(0xFFE8E0F5), Offset(w * 0.50f, headTop), Offset(w * 0.50f, headTop - h * 0.05f), strokeWidth = w * 0.014f)
            drawCircle(Color(0xFFFF7AD9), w * 0.022f, Offset(w * 0.50f, headTop - h * 0.055f))
        }
        // orelhas
        drawRoundRect(ear, Offset(headL - w * 0.07f, headTop + headH * 0.28f), Size(w * 0.09f, headH * 0.42f), CornerRadius(w * 0.04f))
        drawRoundRect(ear, Offset(headL + headW - w * 0.02f, headTop + headH * 0.28f), Size(w * 0.09f, headH * 0.42f), CornerRadius(w * 0.04f))
        // cabeça
        drawRoundRect(shell, Offset(headL, headTop), Size(headW, headH), CornerRadius(w * 0.14f))
        // visor
        val vL = headL + headW * 0.09f
        val vT = headTop + headH * 0.18f
        val vW = headW * 0.82f
        val vH = headH * 0.60f
        drawRoundRect(dark, Offset(vL, vT), Size(vW, vH), CornerRadius(w * 0.09f))
        drawRoundRect(neon.copy(alpha = 0.55f), Offset(vL, vT), Size(vW, vH), CornerRadius(w * 0.09f), style = Stroke(width = w * 0.006f))
        val eyeY = vT + vH * 0.42f
        val eyeDx = vW * 0.24f
        val cx = vL + vW / 2f
        if (pink) {
            // olhos grandes e expressivos com brilho
            listOf(cx - eyeDx, cx + eyeDx).forEach { ex ->
                drawOval(neon, Offset(ex - vW * 0.11f, eyeY - vH * 0.22f), Size(vW * 0.22f, vH * 0.44f))
                drawCircle(Color.White, vW * 0.045f, Offset(ex - vW * 0.03f, eyeY - vH * 0.09f))
                drawCircle(Color.White.copy(alpha = 0.8f), vW * 0.02f, Offset(ex + vW * 0.04f, eyeY + vH * 0.07f))
            }
            // bochechas rosadas
            drawOval(Color(0xFFFF5FB4).copy(alpha = 0.75f), Offset(cx - eyeDx - vW * 0.12f, vT + vH * 0.72f), Size(vW * 0.17f, vH * 0.14f))
            drawOval(Color(0xFFFF5FB4).copy(alpha = 0.75f), Offset(cx + eyeDx - vW * 0.05f, vT + vH * 0.72f), Size(vW * 0.17f, vH * 0.14f))
            // sorriso
            val smile = Path().apply {
                moveTo(cx - vW * 0.07f, vT + vH * 0.78f)
                quadraticBezierTo(cx, vT + vH * 0.90f, cx + vW * 0.07f, vT + vH * 0.78f)
            }
            drawPath(smile, neon, style = Stroke(width = w * 0.012f))
        } else {
            // olhos em barra neon
            listOf(cx - eyeDx, cx + eyeDx).forEach { ex ->
                drawRoundRect(neon, Offset(ex - vW * 0.10f, eyeY - vH * 0.07f), Size(vW * 0.20f, vH * 0.14f), CornerRadius(vH * 0.07f))
            }
        }
        if (pink && !headOnly) {
            // corações decorativos ao redor
            drawHeart(Offset(w * 0.07f, h * 0.30f), w * 0.045f, Color(0xFFFF7AD9).copy(alpha = 0.85f))
            drawHeart(Offset(w * 0.93f, h * 0.18f), w * 0.04f, Color(0xFFFF7AD9).copy(alpha = 0.85f))
            drawHeart(Offset(w * 0.95f, h * 0.50f), w * 0.03f, Color(0xFFC084FC).copy(alpha = 0.9f))
            drawHeart(Offset(w * 0.05f, h * 0.62f), w * 0.035f, Color(0xFFC084FC).copy(alpha = 0.9f))
            // mãos segurando o coração
            drawCircle(Color(0xFFE8E0F5), w * 0.055f, Offset(w * 0.36f, h * 0.88f))
            drawCircle(Color(0xFFE8E0F5), w * 0.055f, Offset(w * 0.64f, h * 0.88f))
        }
    }
}

private fun DrawScope.drawHeart(c: Offset, s: Float, color: Color) {
    val p = Path().apply {
        moveTo(c.x, c.y + s * 0.9f)
        cubicTo(c.x - s * 1.6f, c.y - s * 0.1f, c.x - s * 0.9f, c.y - s * 1.1f, c.x, c.y - s * 0.35f)
        cubicTo(c.x + s * 0.9f, c.y - s * 1.1f, c.x + s * 1.6f, c.y - s * 0.1f, c.x, c.y + s * 0.9f)
        close()
    }
    drawPath(p, color)
}
