# Portabilidade de dados por conta

Cada conta leva os próprios dados. Ao entrar numa conta, o app traz tudo que é dela; ao trocar de conta, os dados da anterior
ficam com a anterior e **nunca** são misturados com os da nova.

## Como funciona

1. **Primeira vez** (aparelho que ainda não tinha backup): os dados do aparelho passam a ser da primeira conta que entrar
   e sobem para ela. Continuam também no aparelho.
2. **Sair e entrar com outra conta, ou "Trocar conta"**:
   - o app envia para a conta atual o que ainda não subiu;
   - se não deu para enviar (sem internet), guarda uma **cópia completa e local dessa conta** (`files/account_vault/<uid>/`);
   - limpa do aparelho tudo que pertence à conta que estava aqui;
   - se a conta que entrou tem cópia local guardada (porque saiu daqui com algo sem subir), restaura essa cópia;
   - baixa da nuvem o restante dos dados da conta que entrou;
   - conta nova e vazia = app limpo.
3. **Entrar de novo na mesma conta**: nada é apagado.

A cópia local de uma conta é apagada sozinha assim que tudo dela estiver na nuvem.
Também continua a cópia `troca_conta_*.json` (últimas 3) feita a cada troca.

## O que viaja com a conta

| Dado | Onde vai |
|---|---|
| Glicemia, insulina, lembretes, refeições, sintomas, medicamentos, HbA1c, perfil/ajustes | registros de sempre |
| Água, favoritos, fatores e histórico de bolus, conversas da Cris IA | `ExtraSync` (como antes) |
| Alertas de glicemia, cuidador, lembrete de HbA1c, resumo semanal, atalho rápido, sensor (URL/usuário), preferências de alimentos e receitas, leitor de rótulos, fotos de receitas, memória da Cris, ajustes da Cris IA (voz online, busca na web, estilo, avisos), preferências internas da Cris, frase do dia | novos documentos `favorites__app_*` e `favorites__app_ds_*` |
| Sons personalizados de lembrete (até ~450 KB cada) | `favorites__snd_*` |

Não foi preciso mudar o `firestore.rules`: os documentos novos usam o tipo `favorites`, que as regras atuais já aceitam
(até 800.000 caracteres por documento).

## O que NÃO viaja (é do aparelho, não da pessoa)

PIN e biometria; chaves de segurança; sessão de login; cotas de uso (Gemini/Tavily); modelos de IA baixados e as chaves que
indicam qual está instalado; caches (mapas, código de barras); senha/token do sensor (cifrados com a chave deste aparelho;
ficam só na cópia local da conta).

## Arquivos

- `cloud/AccountData.kt` — tudo acima: documentos de nuvem, limpeza e cofre local por conta.
- `data/PrefsJson.kt` — SharedPreferences/DataStore de/para JSON.
- `cloud/ExtraSync.kt`, `cloud/CloudBackup.kt` — envio/aplicação dos novos documentos; na restauração e na primeira entrada em um aparelho, o que a nuvem já tem vence.
- `data/GlucoViewModel.kt` — `prepareAccountSwitch()` (troca de conta).
