# GlucoCris — Entrega 1 (V6.4): HbA1c + limites personalizados + WhatsApp/SMS

**Versão:** 1.29.0-v6.4-entrega1 (versionCode local 81) · **Base:** V6.3 (1.28.3)

## ⚠️ Estado real de validação (leia primeiro)

| Item | Estado |
|---|---|
| `./gradlew clean / compileDebugKotlin / assembleDebug / test / lint` | **NÃO EXECUTADOS.** O ambiente de trabalho não tem Android SDK nem acesso à rede (Gradle não baixa dependências). |
| **APK** | **NÃO GERADO.** Nenhum APK foi compilado ou validado. |
| Testes unitários novos | **Escritos, não executados.** Conferi à mão os resultados esperados, mas "compila" e "passa" estão sem prova. |
| Verificação sintática | Só uma checagem grosseira de parênteses/chaves (sem diferença nova em relação ao original). Não substitui o compilador Kotlin. |
| Testes em aparelho (notificação, WhatsApp, SMS, atualização sobre versão antiga) | **Não realizados.** |

Para validar (no GitHub Actions existente ou com SDK local):
```
bash ./gradlew clean testDebugUnitTest --no-daemon
bash ./gradlew lintDebug --no-daemon
bash ./gradlew assembleDebug --no-daemon
```
Se o compilador reclamar de algo, o mais provável está em `Hba1cScreen.kt` (Compose/Canvas), `InsightScreens.kt` (CaregiverScreen) ou `Caregiver.kt`. Envie o log que eu corrijo.

## Auditoria (Parte 1) — achados

- **Arquitetura:** Kotlin + Compose + MVVM leve; um `GlucoViewModel` com `AppData` único serializado (kotlinx) no DataStore; sincronização opcional com Firestore (`SyncMerge`, tombstones, `updatedAt`); backup local criptografado (`LocalEncryptedBackup`).
- **GMI:** `Insights.stats` usa `3,31 + 0,02392 × média` — **correto**, preservado sem alteração. Qualidade em `GmiQuality` (glicosímetro ≥14 medições/≥7 dias/≥5 dias; CGM por id `sensor-*`, 14 dias, ≥70% cobertura).
- **eA1c:** existia **apenas** no relatório em texto (`MedsReportSettingsScreens.kt`), fórmula ADAG `(média + 46,7) / 28,7`, rotulada "A1c estimada", **sem filtro de qualidade além de aviso de poucos dados**. Mantive o cálculo; mudei o rótulo para "eA1c (estimativa ADAG)", expliquei origem/limitação e que difere do GMI e do exame. Não aparece no PDF.
- **Limites 45/54/60/70 e 250/300/350/400:** estão na tela *Modo cuidador* (limites de aviso ao cuidador, `Caregiver.severeLow/High`). Os alertas de meta (`GlucoseAlerts`, `targetLow/High`) são outro mecanismo e não foram alterados.
- **WhatsApp (defeito encontrado):** usava `https://wa.me/...` sem checar se o WhatsApp existe (sem WhatsApp, abria o navegador "com sucesso"); telefone salvo a cada tecla sem validação (aceitava ≥8 dígitos, sem DDI); notificação reutilizava o mesmo intent; sem cadastro/remoção estruturado; 30 min fixos entre avisos, compartilhados entre baixa e alta.
- **SMS:** `smsto:` + `sms_body` funcionava; preservado (agora com número validado e fallback).
- **CGM:** import em `sensors/SensorSync.kt` (ids `sensor-*`); a auditoria profunda de fontes é da Parte 5/Entrega 2 — **não feita nesta entrega**.
- Gemini, Tavily, IA local, biometria, backup, navegação: **não tocados** (exceto backup/sync, que ganharam a coleção `hba1c`).

## Funcionalidades preservadas (checklist) — por inspeção, não por execução
GMI e cobertura CGM · gráficos · PDF médico (seções antigas intactas) · histórico · lembretes · alertas de glicemia · modo cuidador (consentimento, resumo do dia, teste) · SMS · Gemini/Tavily/IA local · biometria · backup local criptografado e na nuvem · sensores.

## O que foi implementado

**HbA1c laboratorial**
- Modelo `Hba1cEntry` (`AppData.hba1c`, padrão vazio → dados antigos carregam normalmente).
- Tela **Hemoglobina glicada (HbA1c)** (menu *Organização*): cadastro, edição, exclusão com confirmação, validação (3,0–20,0%, até 2 casas, data não futura), histórico com variação em p.p. e ▲▼● (texto, não só cor), gráfico só de exames (com meta tracejada, 6/12/todos), comparação **HbA1c REAL × GMI lado a lado** (diferença, média usada, origem, cobertura CGM, aviso de não equivalência, aviso de períodos diferentes), texto educativo, meta de referência configurável (neutra, sem prescrição) e lembrete (a cada N meses ou data; WorkManager; sem intervalo médico imposto).
- Persistência: DataStore + backup local criptografado + sincronização Firestore (tipo `hba1c`).
- PDF: seções novas "Exames laboratoriais de HbA1c" (tabela + gráfico só de laudos) e "HbA1c laboratorial × GMI" (valores separados). GMI/eA1c nunca entram na área de exames.

**Limites e cuidador**
- "Personalizar limite" (baixo e alto): campo numérico, Salvar/Cancelar, validação (faixas 30–100 e 150–600; baixo ≤ meta mínima; alto ≥ meta máxima; baixo < alto), persistência local, efeito imediato (lidos a cada leitura).
- Intervalo de repetição configurável (15 min/30 min/1 h/2 h), **independente para baixa e alta**; padrão 30 min = comportamento anterior.
- Cadastro do cuidador: nome, telefone com DDI validado (E.164; Brasil: 55 + DDD + 8/9 dígitos; número BR sem 55 é recusado com orientação), editar, remover (com confirmação).
- WhatsApp: detecta WhatsApp/Business instalado (`<queries>` no manifesto), abre a conversa do cuidador com o texto pronto; sem WhatsApp → compartilhamento do Android; mensagem vazia/telefone inválido bloqueados; falhas tratadas. **A tela diz que a mensagem foi "preparada" e que o app não sabe se foi enviada** (o Android não informa envio/cancelamento). Sem automação, sem acessibilidade, sem envio silencioso.
- Notificação de alerta: se o telefone salvo for inválido (ex.: número antigo sem DDI), avisa para corrigir em vez de falhar em silêncio.
- Os limites **não** alteram alarmes do CGM/medidor (dito na tela).

## ⚠️ Pontos de atenção
1. **Firestore:** `firestore.rules` agora aceita o tipo `hba1c`. **É preciso reimplantar as regras** (`firebase deploy --only firestore:rules`); sem isso a nuvem recusa os documentos `hba1c` (o app mantém tudo local e o backup local funciona).
2. **Números salvos antes** sem DDI (ex.: `11999998888`) passam a ser considerados inválidos até serem corrigidos na tela do cuidador.
3. HbA1c **não** é enviada a IA nenhuma (Gemini/Tavily/IA local não recebem exames).
4. Lembrete de exame: horário aproximado (WorkManager/economia de bateria); exige permissão de notificações.
5. `Icons.Filled.Bloodtype` (ícone do menu) vem de `material-icons-extended` (já é dependência); se o compilador não achar, troque por `Icons.Filled.Insights`.
6. `SyncMerge`/`LocalEncryptedBackup` com `hba1c`: sem teste automatizado próprio (o objeto `GlucoStorage` pode tocar classes Android em teste JVM; evitei para não quebrar o `gradlew test`).

## Arquivos
**Novos:** `insights/Hba1c.kt`, `reminders/Hba1cReminders.kt`, `reminders/CaregiverRules.kt`, `ui/screens/Hba1cScreen.kt`, `test/.../insights/Hba1cTest.kt`, `test/.../reminders/CaregiverRulesTest.kt`, este relatório.
**Alterados:** `data/Models.kt`, `data/GlucoViewModel.kt`, `cloud/SyncMerge.kt`, `cloud/LocalEncryptedBackup.kt`, `firestore.rules`, `insights/MedicalPdf.kt`, `reminders/Caregiver.kt`, `ui/screens/InsightScreens.kt` (CaregiverScreen), `ui/screens/HistoryMoreScreens.kt`, `ui/screens/MedsReportSettingsScreens.kt`, `ui/screens/BackupRecoveryScreen.kt`, `Routes.kt`, `MainActivity.kt`, `AndroidManifest.xml`, `app/build.gradle.kts` (versão).

## Testes escritos (não executados)
`Hba1cTest` (24 casos): parsing/validação, datas, histórico/variação, tendência, pontos do gráfico, GMI inalterado, comparação REAL×GMI (separados, dados insuficientes, sem dados, demo ignorado, nota de período), meta neutra, planejamento de lembretes, serialização e leitura de dados antigos.
`CaregiverRulesTest` (16 casos): padrões preservados, limites baixo/alto (válidos/inválidos/incoerentes/independentes), efeito imediato, repetição, telefone (BR, sem DDI, inválidos, internacional, exibição).

## Não feito nesta entrega
Entrega 2 (backend, vinculação por QR, app Cuidador, push), auditoria profunda de CGM (Parte 5), APK, execução de testes, testes em aparelho.
