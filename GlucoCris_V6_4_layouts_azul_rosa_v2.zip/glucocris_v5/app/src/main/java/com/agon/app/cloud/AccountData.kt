package com.agon.app.cloud

import android.content.Context
import android.util.Base64
import com.agon.app.data.CrisPrefs
import com.agon.app.data.PrefsJson
import com.agon.app.love.loveDumpAll
import com.agon.app.love.loveRestoreAll
import com.agon.app.love.loveWipeAll
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/**
 * Portabilidade de dados por conta: tudo que o app guarda no aparelho e que pertence à PESSOA (e não ao aparelho)
 * viaja com a conta que está logada.
 *
 * O que já ia à nuvem por [SyncMerge] / [ExtraSync]: glicemia, insulina, lembretes, refeições, sintomas, medicamentos, HbA1c,
 * perfil, água, favoritos, bolus e conversas da Cris IA.
 * Este arquivo cobre o RESTO: configurações de alertas, cuidador, lembretes de HbA1c, resumo semanal, atalho rápido,
 * preferências de alimentos e receitas, histórico do leitor de rótulos, sensor, memória e ajustes da Cris IA,
 * sons personalizados e as preferências internas da Cris/frase do dia.
 *
 * Fica de fora, de propósito, o que é do APARELHO: PIN e biometria, chaves de segurança, cotas de uso, modelos de IA baixados
 * (e as chaves que dizem qual modelo está instalado), caches e a sessão de login.
 *
 * Dois usos:
 *  - nuvem: documentos do tipo "favorites" com id "app_..." (prefs), "app_ds_..." (DataStore) e "snd_..." (sons);
 *  - cópia local de segurança por conta ("cofre"): guarda TUDO da conta anterior quando a pessoa troca de conta e ainda havia
 *    algo sem subir (sem internet, por exemplo). Ela volta sozinha quando a pessoa entrar de novo naquela conta.
 */
object AccountData {
    private class Spec(
        val file: String,
        /** Chaves que pertencem ao aparelho: nunca são enviadas, apagadas nem restauradas. */
        val device: (String) -> Boolean = { false },
        /** Chaves que só ficam na cópia local (ex.: senhas cifradas com a chave do aparelho): não vão à nuvem. */
        val noCloud: (String) -> Boolean = { false },
    )

    private val AI_DEVICE_KEYS = setOf(
        "enabled", "active_model", "target_model", "selected_model", "download_error", "download_wanted",
        "download_offer_answered", "bg_download", "allow_metered", "last_run_version", "chooser_dismissed",
        "keep_or_change_seen", "consent_model",
    )

    private val SPECS: List<Spec> = listOf(
        Spec("gluco_water_v1"),
        Spec("gluco_food_tools"),
        Spec("gluco_food_prefs"),
        Spec("gluco_recipe_prefs"),
        Spec("gluco_vision_prefs"),
        Spec("gluco_label_scan_history"),
        Spec("gluco_recipe_auto_photos"),
        Spec("gluco_alerts_v1"),
        Spec("gluco_caregiver_v1"),
        Spec("gluco_hba1c_v1"),
        Spec("gluco_quick_v1"),
        Spec("gluco_weekly_v1"),
        Spec("cris_localai_memory"),
        Spec("cris_conv_state"),
        Spec("gluco_sensor_v1", noCloud = { it == "ns_token" || it.startsWith("pass_") }),
        Spec("cris_localai_settings", device = { it in AI_DEVICE_KEYS || it.startsWith("model_ver_") }),
    )

    private val DATASTORES = listOf("cris_ia_prefs", "gluco_love")

    private const val ID_PREFS = "app_"
    private const val ID_STORE = "app_ds_"
    private const val ID_SOUND = "snd_"
    private const val MAX_CLOUD_CHARS = 700_000
    private const val MAX_SOUND_BYTES = 450_000
    private const val SOUNDS = "sounds"
    private const val CONVERSATIONS = "cris_conversations"

    private fun sp(ctx: Context, file: String) = ctx.applicationContext.getSharedPreferences(file, Context.MODE_PRIVATE)

    private fun hash(s: String): String =
        MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }.take(24)

    private fun soundsDir(ctx: Context) = File(ctx.applicationContext.filesDir, SOUNDS)

    /** É um documento desta portabilidade (e não o instantâneo "main" de favoritos)? */
    fun isGenericId(id: String) = id.startsWith(ID_PREFS) || id.startsWith(ID_SOUND)

    // ------------------------------------------------------------------------------------------
    // Nuvem
    // ------------------------------------------------------------------------------------------

    private fun cloudKeep(s: Spec): (String) -> Boolean = { k -> !s.device(k) && !s.noCloud(k) && !ExtraSync.isSnapshotKey(s.file, k) }

    private fun soundIds(ctx: Context): List<String> =
        (soundsDir(ctx).listFiles() ?: emptyArray()).filter { it.isFile }.map { ID_SOUND + hash(it.name) }

    /** Ids de todos os documentos que este aparelho pode enviar (alguns podem estar vazios). */
    fun cloudIds(ctx: Context): List<String> =
        SPECS.map { ID_PREFS + it.file } + DATASTORES.map { ID_STORE + it } + soundIds(ctx)

    /** Conteúdo atual do documento [id] neste aparelho; null se não há nada a enviar. */
    suspend fun payloadFor(ctx: Context, id: String): String? = withContext(Dispatchers.IO) {
        try {
            when {
                id.startsWith(ID_STORE) -> {
                    val text = when (id.removePrefix(ID_STORE)) {
                        "cris_ia_prefs" -> CrisPrefs.dumpAll(ctx)
                        "gluco_love" -> loveDumpAll(ctx)
                        else -> return@withContext null
                    }
                    if (text.length <= 2 || text.length > MAX_CLOUD_CHARS) null else text
                }
                id.startsWith(ID_PREFS) -> {
                    val file = id.removePrefix(ID_PREFS)
                    val spec = SPECS.firstOrNull { it.file == file } ?: return@withContext null
                    val j = PrefsJson.fromShared(sp(ctx, file), cloudKeep(spec))
                    if (j.length() == 0) return@withContext null
                    val text = j.toString()
                    if (text.length > MAX_CLOUD_CHARS) null else text
                }
                id.startsWith(ID_SOUND) -> {
                    val f = (soundsDir(ctx).listFiles() ?: emptyArray()).firstOrNull { it.isFile && ID_SOUND + hash(it.name) == id }
                        ?: return@withContext null
                    if (f.length() > MAX_SOUND_BYTES) return@withContext null
                    JSONObject().put("n", f.name).put("b", Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)).toString()
                }
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    /** Aplica ao aparelho um documento vindo da nuvem. Só toca em arquivos e chaves conhecidos. */
    suspend fun applyCloud(ctx: Context, id: String, payload: String) = withContext(Dispatchers.IO) {
        try {
            when {
                id.startsWith(ID_STORE) -> when (id.removePrefix(ID_STORE)) {
                    "cris_ia_prefs" -> CrisPrefs.restoreAll(ctx, payload)
                    "gluco_love" -> loveRestoreAll(ctx, payload)
                    else -> {}
                }
                id.startsWith(ID_PREFS) -> {
                    val file = id.removePrefix(ID_PREFS)
                    val spec = SPECS.firstOrNull { it.file == file } ?: return@withContext
                    PrefsJson.applyShared(sp(ctx, file), JSONObject(payload), cloudKeep(spec))
                }
                id.startsWith(ID_SOUND) -> {
                    val o = JSONObject(payload)
                    val name = o.optString("n")
                    // Só o nome do arquivo, nunca um caminho
                    if (name.isBlank() || name != File(name).name || name.startsWith(".")) return@withContext
                    val dir = soundsDir(ctx).apply { mkdirs() }
                    val f = File(dir, name)
                    if (!f.exists()) f.writeBytes(Base64.decode(o.optString("b"), Base64.NO_WRAP))
                }
                else -> {}
            }
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------------------------------
    // Cópia completa do aparelho (cofre local por conta) e limpeza na troca de conta
    // ------------------------------------------------------------------------------------------

    private suspend fun dumpAll(ctx: Context): JSONObject {
        val prefs = JSONObject()
        for (s in SPECS) {
            val j = PrefsJson.fromShared(sp(ctx, s.file)) { !s.device(it) }
            if (j.length() > 0) prefs.put(s.file, j)
        }
        val stores = JSONObject()
            .put("cris_ia_prefs", CrisPrefs.dumpAll(ctx))
            .put("gluco_love", loveDumpAll(ctx))
        return JSONObject().put("prefs", prefs).put("stores", stores)
    }

    private suspend fun restoreAll(ctx: Context, data: JSONObject) {
        val prefs = data.optJSONObject("prefs")
        if (prefs != null) {
            for (s in SPECS) {
                val j = prefs.optJSONObject(s.file) ?: continue
                PrefsJson.applyShared(sp(ctx, s.file), j) { !s.device(it) }
            }
        }
        val stores = data.optJSONObject("stores")
        if (stores != null) {
            stores.optString("cris_ia_prefs").takeIf { it.isNotBlank() }?.let { CrisPrefs.restoreAll(ctx, it) }
            stores.optString("gluco_love").takeIf { it.isNotBlank() }?.let { loveRestoreAll(ctx, it) }
        }
    }

    /** Apaga do aparelho os dados da conta que estava aqui (menos o que é do aparelho). Conversas: quem chama usa o CrisConversationStore. */
    suspend fun wipeLocal(ctx: Context) = withContext(Dispatchers.IO) {
        for (s in SPECS) PrefsJson.removeShared(sp(ctx, s.file)) { !s.device(it) }
        try { CrisPrefs.wipeAll(ctx) } catch (_: Exception) {}
        try { loveWipeAll(ctx) } catch (_: Exception) {}
        try { soundsDir(ctx).deleteRecursively() } catch (_: Exception) {}
        Unit
    }

    private fun vaultRoot(ctx: Context) = File(ctx.applicationContext.filesDir, "account_vault")
    private fun safeUid(uid: String) = uid.filter { it.isLetterOrDigit() }.ifBlank { "x" }
    private fun vaultDir(ctx: Context, uid: String) = File(vaultRoot(ctx), safeUid(uid))

    fun hasStash(ctx: Context, uid: String): Boolean = File(vaultDir(ctx, uid), "app.json").exists()

    fun deleteStash(ctx: Context, uid: String) {
        try { vaultDir(ctx, uid).deleteRecursively() } catch (_: Exception) {}
    }

    /** Guarda no aparelho TUDO da conta [uid] (dados do app em [appJson] + o restante). Substitui a cópia anterior. */
    suspend fun saveStash(ctx: Context, uid: String, appJson: String) = withContext(Dispatchers.IO) {
        val root = vaultRoot(ctx).apply { mkdirs() }
        val tmp = File(root, safeUid(uid) + ".tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        File(tmp, "app.json").writeText(appJson, Charsets.UTF_8)
        File(tmp, "data.json").writeText(dumpAll(ctx).toString(), Charsets.UTF_8)
        val app = ctx.applicationContext
        File(app.filesDir, CONVERSATIONS).takeIf { it.exists() }?.copyRecursively(File(tmp, "conversations"), true)
        soundsDir(app).takeIf { it.exists() }?.copyRecursively(File(tmp, SOUNDS), true)
        val dst = vaultDir(ctx, uid)
        dst.deleteRecursively()
        if (!tmp.renameTo(dst)) {
            tmp.copyRecursively(dst, true)
            tmp.deleteRecursively()
        }
        Unit
    }

    /**
     * Devolve ao aparelho o que foi guardado da conta [uid] (preferências, sons e conversas) e entrega o texto dos dados do app
     * (AppData) para quem chama aplicar. null se não há cópia. Chame DEPOIS de [wipeLocal] e de limpar as conversas.
     */
    suspend fun restoreStash(ctx: Context, uid: String): String? = withContext(Dispatchers.IO) {
        val dir = vaultDir(ctx, uid)
        val appFile = File(dir, "app.json")
        if (!appFile.exists()) return@withContext null
        val app = ctx.applicationContext
        try {
            val data = JSONObject(File(dir, "data.json").readText(Charsets.UTF_8))
            restoreAll(ctx, data)
        } catch (_: Exception) {
        }
        try {
            File(dir, "conversations").takeIf { it.exists() }?.copyRecursively(File(app.filesDir, CONVERSATIONS), true)
            File(dir, SOUNDS).takeIf { it.exists() }?.copyRecursively(soundsDir(app), true)
        } catch (_: Exception) {
        }
        try { appFile.readText(Charsets.UTF_8) } catch (_: Exception) { null }
    }
}
