package com.agon.app.cloud

import com.agon.app.data.AppData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.SecureRandom
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream
import javax.crypto.Cipher
import javax.crypto.Mac
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

/**
 * Backup local exportável e restaurável, protegido por senha escolhida pelo usuário.
 *
 * Formato (v1):
 *  magic (8) | version (1) | salt (16) | iv (12) | ciphertext+tag (GCM) | hmac (32)
 *
 * Limites de segurança (V6.2):
 *  - arquivo cifrado: até [MAX_CIPHER_BYTES] (40 MB)
 *  - payload descompactado: até [MAX_PLAIN_BYTES] (32 MB)
 *  - registros por coleção: até [MAX_RECORDS_PER_COLLECTION]
 * Proteção contra ZIP bomb: leitura limitada do GZIP; não usa readBytes() sem teto.
 */
object LocalEncryptedBackup {
    private const val MAGIC = "GLUCOCR6"
    private const val VERSION: Byte = 1
    private const val SALT_LEN = 16
    private const val IV_LEN = 12
    private const val HMAC_LEN = 32
    private const val KEY_LEN = 32
    private const val PBKDF2_ITERS = 120_000
    private const val GCM_TAG_BITS = 128

    /** Tamanho máximo do arquivo de backup cifrado (bytes). */
    const val MAX_CIPHER_BYTES = 40 * 1024 * 1024
    /** Tamanho máximo do JSON descompactado (bytes). */
    const val MAX_PLAIN_BYTES = 32 * 1024 * 1024
    /** Máximo de registros por coleção aceito na importação. */
    const val MAX_RECORDS_PER_COLLECTION = 200_000
    private const val MIN_FILE = 8 + 1 + SALT_LEN + IV_LEN + 16 + HMAC_LEN

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    data class ExportResult(val ok: Boolean, val message: String, val bytes: ByteArray? = null)
    data class Preview(
        val version: Int,
        val glucoseCount: Int,
        val insulinCount: Int,
        val mealsCount: Int,
        val medsCount: Int,
        val remindersCount: Int,
        val symptomsCount: Int,
        val hasSettings: Boolean,
        val hba1cCount: Int = 0,
    )
    data class RestorePlan(
        val preview: Preview,
        val toAdd: Int,
        val toUpdate: Int,
        val toSkip: Int,
        val summary: String,
    )

    suspend fun export(data: AppData, password: CharArray): ExportResult = withContext(Dispatchers.Default) {
        if (password.isEmpty()) return@withContext ExportResult(false, "Informe uma senha para proteger o backup.")
        var keys: DerivedKeys? = null
        try {
            val plain = json.encodeToString(data).toByteArray(Charsets.UTF_8)
            if (plain.size > MAX_PLAIN_BYTES) {
                return@withContext ExportResult(false, "Os dados locais excedem o tamanho máximo suportado para exportação.")
            }
            val compressed = gzip(plain)
            val salt = ByteArray(SALT_LEN).also { SecureRandom().nextBytes(it) }
            val iv = ByteArray(IV_LEN).also { SecureRandom().nextBytes(it) }
            keys = deriveKeys(password, salt)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, SecretKeySpec(keys!!.enc, "AES"), GCMParameterSpec(GCM_TAG_BITS, iv))
            val ct = cipher.doFinal(compressed)
            val header = ByteArrayOutputStream().apply {
                write(MAGIC.toByteArray(Charsets.US_ASCII))
                write(byteArrayOf(VERSION))
                write(salt)
                write(iv)
            }.toByteArray()
            val mac = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(keys!!.mac, "HmacSHA256")) }
            mac.update(header)
            mac.update(ct)
            val hmac = mac.doFinal()
            val out = header + ct + hmac
            if (out.size > MAX_CIPHER_BYTES) {
                return@withContext ExportResult(false, "Backup gerado excedeu o tamanho máximo permitido.")
            }
            ExportResult(true, "Backup criado com sucesso.", out)
        } catch (e: Exception) {
            ExportResult(false, "Falha ao criar o backup: ${safeMsg(e)}")
        } finally {
            keys?.clear()
            password.fill('\u0000')
        }
    }

    /**
     * Valida formato, senha e integridade; devolve o AppData se tudo estiver ok.
     * Aplica limites de tamanho cifrado, descompactado e quantidade de registros.
     */
    suspend fun decrypt(bytes: ByteArray, password: CharArray): Pair<AppData?, String> = withContext(Dispatchers.Default) {
        if (password.isEmpty()) return@withContext null to "Informe a senha do backup."
        if (bytes.size < MIN_FILE) return@withContext null to "Arquivo de backup inválido ou incompleto."
        if (bytes.size > MAX_CIPHER_BYTES) return@withContext null to "Arquivo de backup muito grande (máximo ${MAX_CIPHER_BYTES / (1024 * 1024)} MB)."
        var keys: DerivedKeys? = null
        try {
            val magic = String(bytes, 0, 8, Charsets.US_ASCII)
            if (magic != MAGIC) return@withContext null to "Arquivo não é um backup do GlucoCris."
            val version = bytes[8].toInt() and 0xFF
            if (version != VERSION.toInt()) return@withContext null to "Versão de backup não suportada ($version)."
            val salt = bytes.copyOfRange(9, 9 + SALT_LEN)
            val iv = bytes.copyOfRange(9 + SALT_LEN, 9 + SALT_LEN + IV_LEN)
            val ctEnd = bytes.size - HMAC_LEN
            if (ctEnd <= 9 + SALT_LEN + IV_LEN) return@withContext null to "Arquivo de backup truncado ou corrompido."
            val ct = bytes.copyOfRange(9 + SALT_LEN + IV_LEN, ctEnd)
            val expectedHmac = bytes.copyOfRange(ctEnd, bytes.size)
            keys = deriveKeys(password, salt)
            val mac = Mac.getInstance("HmacSHA256").apply { init(SecretKeySpec(keys!!.mac, "HmacSHA256")) }
            mac.update(bytes, 0, 9 + SALT_LEN + IV_LEN)
            mac.update(ct)
            val actual = mac.doFinal()
            if (!actual.contentEquals(expectedHmac)) {
                return@withContext null to "Senha incorreta ou arquivo adulterado."
            }
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keys!!.enc, "AES"), GCMParameterSpec(GCM_TAG_BITS, iv))
            val compressed = try {
                cipher.doFinal(ct)
            } catch (_: Exception) {
                return@withContext null to "Senha incorreta ou arquivo adulterado."
            }
            val plain = try {
                safeGunzip(compressed, MAX_PLAIN_BYTES)
            } catch (e: Exception) {
                return@withContext null to (e.message ?: "Falha ao descompactar o backup.")
            }
            val data = try {
                json.decodeFromString<AppData>(String(plain, Charsets.UTF_8))
            } catch (_: Exception) {
                return@withContext null to "Estrutura do backup inválida ou corrompida."
            }
            val limitErr = validateRecordLimits(data)
            if (limitErr != null) return@withContext null to limitErr
            data to "OK"
        } catch (e: Exception) {
            null to "Não foi possível ler o backup: ${safeMsg(e)}"
        } finally {
            keys?.clear()
            password.fill('\u0000')
        }
    }

    fun previewOf(data: AppData): Preview = Preview(
        version = VERSION.toInt(),
        glucoseCount = data.glucose.size,
        insulinCount = data.insulin.size,
        mealsCount = data.meals.size,
        medsCount = data.medications.size,
        remindersCount = data.reminders.size,
        symptomsCount = data.symptoms.size,
        hasSettings = true,
        hba1cCount = data.hba1c.size,
    )

    fun planRestore(current: AppData, incoming: AppData): RestorePlan {
        var add = 0
        var update = 0
        var skip = 0
        fun reconcile(curIds: Map<String, Long>, inc: List<Pair<String, Long>>) {
            for ((id, at) in inc) {
                val existing = curIds[id]
                when {
                    existing == null -> add++
                    at > existing -> update++
                    else -> skip++
                }
            }
        }
        reconcile(current.glucose.associate { it.id to it.updatedAt }, incoming.glucose.map { it.id to it.updatedAt })
        reconcile(current.insulin.associate { it.id to it.updatedAt }, incoming.insulin.map { it.id to it.updatedAt })
        reconcile(current.meals.associate { it.id to it.updatedAt }, incoming.meals.map { it.id to it.updatedAt })
        reconcile(current.medications.associate { it.id to it.updatedAt }, incoming.medications.map { it.id to it.updatedAt })
        reconcile(current.reminders.associate { it.id to it.updatedAt }, incoming.reminders.map { it.id to it.updatedAt })
        reconcile(current.symptoms.associate { it.id to it.updatedAt }, incoming.symptoms.map { it.id to it.updatedAt })
        reconcile(current.hba1c.associate { it.id to it.updatedAt }, incoming.hba1c.map { it.id to it.updatedAt })
        val p = previewOf(incoming)
        val summary = "Serão adicionados $add, atualizados $update e ignorados $skip registros. Os dados atuais não serão apagados."
        return RestorePlan(p, add, update, skip, summary)
    }

    /** Merge puro (sem efeitos colaterais). O chamador deve persistir atomicamente. */
    fun merge(current: AppData, incoming: AppData): AppData {
        fun <T> mergeList(cur: List<T>, inc: List<T>, idOf: (T) -> String, atOf: (T) -> Long): List<T> {
            val map = LinkedHashMap<String, T>()
            for (item in cur) map[idOf(item)] = item
            for (item in inc) {
                val id = idOf(item)
                val existing = map[id]
                if (existing == null || atOf(item) > atOf(existing)) map[id] = item
            }
            return map.values.toList()
        }
        return current.copy(
            glucose = mergeList(current.glucose, incoming.glucose, { it.id }, { it.updatedAt }),
            insulin = mergeList(current.insulin, incoming.insulin, { it.id }, { it.updatedAt }),
            meals = mergeList(current.meals, incoming.meals, { it.id }, { it.updatedAt }),
            medications = mergeList(current.medications, incoming.medications, { it.id }, { it.updatedAt }),
            reminders = mergeList(current.reminders, incoming.reminders, { it.id }, { it.updatedAt }),
            symptoms = mergeList(current.symptoms, incoming.symptoms, { it.id }, { it.updatedAt }),
            hba1c = mergeList(current.hba1c, incoming.hba1c, { it.id }, { it.updatedAt }),
            settings = if (incoming.settings.settingsUpdatedAt >= current.settings.settingsUpdatedAt) incoming.settings else current.settings,
            tombstones = (current.tombstones + incoming.tombstones).distinctBy { it.col to it.id },
        )
    }

    private fun validateRecordLimits(data: AppData): String? {
        fun check(name: String, n: Int): String? =
            if (n > MAX_RECORDS_PER_COLLECTION) "Backup contém demasiados registros de $name ($n; máximo $MAX_RECORDS_PER_COLLECTION)." else null
        return check("glicemia", data.glucose.size)
            ?: check("insulina", data.insulin.size)
            ?: check("refeições", data.meals.size)
            ?: check("medicamentos", data.medications.size)
            ?: check("lembretes", data.reminders.size)
            ?: check("sintomas", data.symptoms.size)
            ?: check("HbA1c", data.hba1c.size)
    }

    private data class DerivedKeys(val enc: ByteArray, val mac: ByteArray) {
        fun clear() { enc.fill(0); mac.fill(0) }
    }

    private fun deriveKeys(password: CharArray, salt: ByteArray): DerivedKeys {
        val factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        val spec = PBEKeySpec(password, salt, PBKDF2_ITERS, (KEY_LEN * 2) * 8)
        val full = factory.generateSecret(spec).encoded
        val enc = full.copyOfRange(0, KEY_LEN)
        val mac = full.copyOfRange(KEY_LEN, KEY_LEN * 2)
        full.fill(0)
        return DerivedKeys(enc, mac)
    }

    private fun gzip(input: ByteArray): ByteArray {
        val bos = ByteArrayOutputStream()
        GZIPOutputStream(bos).use { it.write(input) }
        return bos.toByteArray()
    }

    /** Descompacta com teto de bytes para mitigar ZIP bomb. */
    internal fun safeGunzip(input: ByteArray, maxPlain: Int): ByteArray {
        val bos = ByteArrayOutputStream()
        GZIPInputStream(ByteArrayInputStream(input)).use { gis ->
            val buf = ByteArray(8 * 1024)
            var total = 0
            while (true) {
                val n = gis.read(buf)
                if (n < 0) break
                total += n
                if (total > maxPlain) {
                    throw IllegalStateException("Dados descompactados excedem o limite de ${maxPlain / (1024 * 1024)} MB (possível arquivo malicioso).")
                }
                bos.write(buf, 0, n)
            }
        }
        return bos.toByteArray()
    }

    private fun safeMsg(e: Exception): String = (e.message ?: "erro").take(120).replace(Regex("password|senha|key|token"), "***")
}
