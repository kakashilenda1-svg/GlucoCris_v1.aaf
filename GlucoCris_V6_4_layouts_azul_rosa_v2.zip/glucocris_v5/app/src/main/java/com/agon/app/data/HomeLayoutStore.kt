package com.agon.app.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/**
 * Escolha do layout visual da tela inicial (azul ou rosa/roxo).
 * Guardada apenas localmente (SharedPreferences), sem rede e sem servidor.
 * Só muda a apresentação: os dados continuam vindo do mesmo GlucoViewModel.
 */
object HomeLayoutStore {
    private const val PREFS = "home_layout_prefs"
    private const val KEY_PINK = "home_layout_pink"

    /** false = layout azul (padrão); true = layout rosa/roxo. */
    var pink by mutableStateOf(false)
        private set

    private var loaded = false

    fun load(ctx: Context) {
        if (loaded) return
        pink = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_PINK, false)
        loaded = true
    }

    fun toggle(ctx: Context) {
        load(ctx)
        pink = !pink
        ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_PINK, pink).apply()
    }
}
