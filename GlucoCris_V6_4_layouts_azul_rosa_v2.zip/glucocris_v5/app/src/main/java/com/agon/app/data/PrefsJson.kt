package com.agon.app.data

import android.content.SharedPreferences
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import org.json.JSONArray
import org.json.JSONObject

/**
 * Converte SharedPreferences e DataStore (Preferences) de/para JSON, com o tipo de cada valor.
 * Usado pela portabilidade de dados entre contas (cópia na nuvem e cópia local de segurança).
 * Formato de cada chave: {"t": tipo, "v": valor}. Tipos: s=texto, i=int, l=long, b=boolean, f=float, d=double, S=conjunto de textos.
 */
object PrefsJson {

    private fun item(type: String, value: Any): JSONObject = JSONObject().put("t", type).put("v", value)

    /** Lê as chaves de um SharedPreferences que passam no filtro [keep]. */
    fun fromShared(sp: SharedPreferences, keep: (String) -> Boolean): JSONObject {
        val out = JSONObject()
        for ((k, v) in sp.all) {
            if (!keep(k) || v == null) continue
            try {
                when (v) {
                    is String -> out.put(k, item("s", v))
                    is Int -> out.put(k, item("i", v))
                    is Long -> out.put(k, item("l", v))
                    is Boolean -> out.put(k, item("b", v))
                    is Float -> out.put(k, item("f", v.toDouble()))
                    is Set<*> -> out.put(k, item("S", JSONArray(v.filterIsInstance<String>().sorted())))
                    else -> {}
                }
            } catch (_: Exception) {
            }
        }
        return out
    }

    /** Grava no SharedPreferences as chaves do JSON que passam no filtro [keep]. Não apaga as que não vieram. */
    fun applyShared(sp: SharedPreferences, json: JSONObject, keep: (String) -> Boolean) {
        val ed = sp.edit()
        for (k in json.keys()) {
            if (!keep(k)) continue
            val o = json.optJSONObject(k) ?: continue
            try {
                when (o.optString("t")) {
                    "s" -> ed.putString(k, o.optString("v", ""))
                    "i" -> ed.putInt(k, o.optInt("v", 0))
                    "l" -> ed.putLong(k, o.optLong("v", 0L))
                    "b" -> ed.putBoolean(k, o.optBoolean("v", false))
                    "f" -> ed.putFloat(k, o.optDouble("v", 0.0).toFloat())
                    "S" -> {
                        val a = o.optJSONArray("v") ?: continue
                        val set = HashSet<String>()
                        for (i in 0 until a.length()) set.add(a.optString(i))
                        ed.putStringSet(k, set)
                    }
                    else -> {}
                }
            } catch (_: Exception) {
            }
        }
        ed.apply()
    }

    /** Remove do SharedPreferences as chaves que passam no filtro [which]. */
    fun removeShared(sp: SharedPreferences, which: (String) -> Boolean) {
        val ed = sp.edit()
        sp.all.keys.filter(which).forEach { ed.remove(it) }
        ed.apply()
    }

    fun fromPreferences(p: Preferences): JSONObject {
        val out = JSONObject()
        for ((k, v) in p.asMap()) {
            try {
                when (v) {
                    is String -> out.put(k.name, item("s", v))
                    is Int -> out.put(k.name, item("i", v))
                    is Long -> out.put(k.name, item("l", v))
                    is Boolean -> out.put(k.name, item("b", v))
                    is Float -> out.put(k.name, item("f", v.toDouble()))
                    is Double -> out.put(k.name, item("d", v))
                    is Set<*> -> out.put(k.name, item("S", JSONArray(v.filterIsInstance<String>().sorted())))
                    else -> {}
                }
            } catch (_: Exception) {
            }
        }
        return out
    }

    fun applyPreferences(target: MutablePreferences, json: JSONObject) {
        for (k in json.keys()) {
            val o = json.optJSONObject(k) ?: continue
            try {
                when (o.optString("t")) {
                    "s" -> target[stringPreferencesKey(k)] = o.optString("v", "")
                    "i" -> target[intPreferencesKey(k)] = o.optInt("v", 0)
                    "l" -> target[longPreferencesKey(k)] = o.optLong("v", 0L)
                    "b" -> target[booleanPreferencesKey(k)] = o.optBoolean("v", false)
                    "f" -> target[floatPreferencesKey(k)] = o.optDouble("v", 0.0).toFloat()
                    "d" -> target[doublePreferencesKey(k)] = o.optDouble("v", 0.0)
                    "S" -> {
                        val a = o.optJSONArray("v") ?: continue
                        val set = HashSet<String>()
                        for (i in 0 until a.length()) set.add(a.optString(i))
                        target[stringSetPreferencesKey(k)] = set
                    }
                    else -> {}
                }
            } catch (_: Exception) {
            }
        }
    }
}
