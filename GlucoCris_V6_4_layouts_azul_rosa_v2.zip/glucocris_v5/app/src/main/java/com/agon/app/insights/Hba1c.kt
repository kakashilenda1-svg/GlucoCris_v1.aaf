package com.agon.app.insights

import com.agon.app.data.AppData
import com.agon.app.data.Hba1cEntry
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * HbA1c LABORATORIAL (exame de sangue) — somente o que a pessoa digitou do laudo.
 * Este arquivo não calcula HbA1c: GMI vem de [Insights.stats] e nunca entra na série laboratorial.
 *
 * Lógica pura (sem Android) para ser testada em JVM.
 */
object Hba1cRules {
    /** Faixa de entrada aceita (%). Valores fora disso quase certamente são erro de digitação. */
    const val MIN_PERCENT = 3.0
    const val MAX_PERCENT = 20.0
    const val MAX_TEXT = 120

    private val BR = Locale("pt", "BR")

    /** Aceita "7,2", "7.2", " 7,2 %". Retorna null se não for um número válido. */
    fun parsePercent(text: String): Double? {
        val t = text.trim().removeSuffix("%").trim().replace(',', '.')
        if (t.isEmpty()) return null
        if (!Regex("""\d{1,2}(\.\d{1,2})?""").matches(t)) return null
        return t.toDoubleOrNull()
    }

    /** Mensagem de erro ou null se o valor é aceitável. */
    fun validatePercent(text: String): String? {
        if (text.isBlank()) return "Informe o resultado do exame em %."
        val v = parsePercent(text) ?: return "Use apenas números, por exemplo 7,2."
        if (v < MIN_PERCENT || v > MAX_PERCENT) return "O resultado deve estar entre ${f1(MIN_PERCENT)}% e ${f1(MAX_PERCENT)}%."
        return null
    }

    fun validateValue(v: Double): String? =
        if (v.isNaN() || v < MIN_PERCENT || v > MAX_PERCENT) "O resultado deve estar entre ${f1(MIN_PERCENT)}% e ${f1(MAX_PERCENT)}%." else null

    /** A data da coleta não pode estar no futuro nem ser anterior a 1990. */
    fun validateDate(at: Long, now: Long = System.currentTimeMillis()): String? {
        val endOfToday = Calendar.getInstance().apply {
            timeInMillis = now
            set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
        }.timeInMillis
        if (at > endOfToday) return "A data da coleta não pode ser no futuro."
        val min = Calendar.getInstance().apply { clear(); set(1990, Calendar.JANUARY, 1) }.timeInMillis
        if (at < min) return "Data da coleta inválida."
        return null
    }

    fun validateTexts(lab: String, notes: String): String? = when {
        lab.length > MAX_TEXT -> "O nome do laboratório é longo demais (máximo $MAX_TEXT caracteres)."
        notes.length > 500 -> "As observações são longas demais (máximo 500 caracteres)."
        else -> null
    }

    /** Meio-dia local da data escolhida: evita que mudança de fuso/horário de verão troque o dia. */
    fun noonOf(year: Int, month0: Int, day: Int): Long =
        Calendar.getInstance().apply {
            clear()
            set(year, month0, day, 12, 0, 0)
        }.timeInMillis

    fun f1(d: Double): String = String.format(BR, "%.1f", d)
    fun f2(d: Double): String = String.format(BR, "%.2f", d)

    /** Exibe o resultado como digitado em 1 casa (7,2) ou 2 casas se necessário (7,25). */
    fun showPercent(p: Double): String {
        val twoDec = (p * 100).roundToInt()
        return if (twoDec % 10 == 0) f1(p) else f2(p)
    }
}

enum class Hba1cDirection { FIRST, UP, DOWN, SAME }

data class Hba1cRow(
    val entry: Hba1cEntry,
    /** Exame imediatamente anterior (mais antigo), se houver. */
    val previous: Hba1cEntry?,
    /** Variação em pontos percentuais (atual − anterior). Null no primeiro exame. */
    val deltaPp: Double?,
    val direction: Hba1cDirection,
)

object Hba1cHistory {
    /** Variações menores que isto (em pontos percentuais) são tratadas como "estável". */
    const val SAME_EPS = 0.05

    /** Mais recente primeiro. Cada linha compara com o exame laboratorial anterior (por data de coleta). */
    fun rows(list: List<Hba1cEntry>): List<Hba1cRow> {
        val asc = list.sortedWith(compareBy<Hba1cEntry> { it.at }.thenBy { it.createdAt })
        val out = ArrayList<Hba1cRow>(asc.size)
        for (i in asc.indices) {
            val cur = asc[i]
            val prev = if (i > 0) asc[i - 1] else null
            if (prev == null) {
                out += Hba1cRow(cur, null, null, Hba1cDirection.FIRST)
            } else {
                val d = cur.percent - prev.percent
                val dir = when {
                    abs(d) < SAME_EPS -> Hba1cDirection.SAME
                    d > 0 -> Hba1cDirection.UP
                    else -> Hba1cDirection.DOWN
                }
                out += Hba1cRow(cur, prev, d, dir)
            }
        }
        return out.reversed()
    }

    fun latest(list: List<Hba1cEntry>): Hba1cEntry? =
        list.maxWithOrNull(compareBy<Hba1cEntry> { it.at }.thenBy { it.createdAt })

    /** "+0,4 p.p.", "−0,6 p.p." ou "sem variação". */
    fun deltaText(d: Double?): String {
        if (d == null) return "primeiro exame"
        if (abs(d) < SAME_EPS) return "sem variação"
        val sign = if (d > 0) "+" else "−"
        return "$sign${Hba1cRules.f1(abs(d))} p.p."
    }

    /** Tendência geral a partir dos últimos [n] exames (compara o mais recente com o mais antigo do trecho). */
    fun trend(list: List<Hba1cEntry>, n: Int = 4): Hba1cDirection? {
        val asc = list.sortedBy { it.at }.takeLast(n)
        if (asc.size < 2) return null
        val d = asc.last().percent - asc.first().percent
        return when {
            abs(d) < SAME_EPS -> Hba1cDirection.SAME
            d > 0 -> Hba1cDirection.UP
            else -> Hba1cDirection.DOWN
        }
    }

    /** Pontos do gráfico: SOMENTE exames laboratoriais, em ordem cronológica. */
    fun chartPoints(list: List<Hba1cEntry>, lastN: Int? = null): List<Hba1cEntry> {
        val asc = list.sortedBy { it.at }
        return if (lastN == null) asc else asc.takeLast(lastN)
    }
}

/** Comparação lado a lado: HbA1c REAL (laudo) × GMI (estimativa). Nunca funde os dois. */
data class Hba1cVsGmi(
    val lab: Hba1cEntry?,
    val gmi: Double?,
    val gmiAvailable: Boolean,
    val meanMg: Double?,
    val readings: Int,
    val periodDays: Int,
    val spanDays: Int,
    val origin: DataOrigin?,
    /** Cobertura CGM em % — só quando a origem é CGM e a cobertura foi confirmada. */
    val coveragePct: Double?,
    /** GMI − HbA1c laboratorial, em p.p. Só existe quando há exame e GMI confiável. */
    val diffPp: Double?,
    /** Por que o GMI não é apresentado (vazio quando disponível). */
    val gmiUnavailableReason: String,
    /** Aviso fixo: não são equivalentes. */
    val disclaimer: String,
    /** Aviso adicional quando o período do GMI não coincide com a data do exame. */
    val periodNote: String,
)

object Hba1cCompare {
    const val DEFAULT_PERIOD_DAYS = 90

    const val DISCLAIMER =
        "HbA1c laboratorial e GMI não são equivalentes: o exame mede a hemoglobina glicada no sangue; " +
            "o GMI é uma estimativa calculada a partir das medições de glicose registradas no app. " +
            "É normal haver diferença entre eles. O exame laboratorial continua sendo a referência."

    fun compute(
        data: AppData,
        now: Long = System.currentTimeMillis(),
        periodDays: Int = DEFAULT_PERIOD_DAYS,
    ): Hba1cVsGmi {
        val lab = Hba1cHistory.latest(data.hba1c)
        val list = Insights.readings(data, periodDays, now)
        val st = Insights.stats(list, data.settings.targetLow, data.settings.targetHigh)
        if (st == null) {
            return Hba1cVsGmi(
                lab = lab, gmi = null, gmiAvailable = false, meanMg = null, readings = 0,
                periodDays = periodDays, spanDays = 0, origin = null, coveragePct = null, diffPp = null,
                gmiUnavailableReason = "Sem medições de glicose nos últimos $periodDays dias para estimar o GMI.",
                disclaimer = DISCLAIMER, periodNote = "",
            )
        }
        val gmi = if (st.gmiReliable) st.gmi else null
        val cov = if (st.dataOrigin == DataOrigin.CGM && st.coveragePct > 0.0) st.coveragePct else null
        val diff = if (lab != null && gmi != null) gmi - lab.percent else null
        val note = if (lab != null) {
            val ageDays = ((now - lab.at) / Insights.DAY_MS).toInt()
            if (ageDays > periodDays) {
                "O exame é de há $ageDays dias e o GMI usa os últimos $periodDays dias: os períodos não coincidem."
            } else ""
        } else ""
        return Hba1cVsGmi(
            lab = lab,
            gmi = gmi,
            gmiAvailable = gmi != null,
            meanMg = st.mean,
            readings = st.count,
            periodDays = periodDays,
            spanDays = st.spanDays,
            origin = st.dataOrigin,
            coveragePct = cov,
            diffPp = diff,
            gmiUnavailableReason = if (gmi == null) st.gmiNote else "",
            disclaimer = DISCLAIMER,
            periodNote = note,
        )
    }
}

/**
 * Faixa de referência configurável pela pessoa. É só uma ORIENTAÇÃO visual (acima/abaixo da meta que ela definiu),
 * nunca diagnóstico e nunca sugestão de mudança de tratamento.
 */
object Hba1cGoal {
    const val DEFAULT_GOAL = 7.0
    const val MIN_GOAL = 4.0
    const val MAX_GOAL = 12.0

    fun validate(text: String): String? {
        val v = Hba1cRules.parsePercent(text) ?: return "Informe a meta em %, por exemplo 7,0."
        if (v < MIN_GOAL || v > MAX_GOAL) return "A meta deve estar entre ${Hba1cRules.f1(MIN_GOAL)}% e ${Hba1cRules.f1(MAX_GOAL)}%."
        return null
    }

    /** Texto neutro. Não prescreve nada. */
    fun describe(percent: Double, goal: Double): String =
        if (percent <= goal) "Resultado igual ou abaixo da meta de referência que você definiu (${Hba1cRules.f1(goal)}%)."
        else "Resultado acima da meta de referência que você definiu (${Hba1cRules.f1(goal)}%). Converse sobre o resultado com sua equipe de saúde."
}

/** Planejamento puro do próximo lembrete de exame (o agendamento real fica em Hba1cReminders). */
object Hba1cReminderPlan {
    const val MODE_INTERVAL = "interval"
    const val MODE_DATE = "date"
    const val HOUR = 9

    /**
     * @param months intervalo escolhido pela pessoa (modo intervalo)
     * @param fixedDate data escolhida (modo data), epoch ms
     * @param lastExamAt coleta mais recente; se não houver, o intervalo conta a partir de [now]
     * @return instante do próximo aviso, ou null se não há o que agendar
     */
    fun nextTrigger(mode: String, months: Int, fixedDate: Long, lastExamAt: Long?, now: Long): Long? {
        return when (mode) {
            MODE_DATE -> {
                if (fixedDate <= 0L) return null
                val t = atHour(fixedDate)
                if (t <= now) null else t
            }
            MODE_INTERVAL -> {
                if (months !in 1..24) return null
                val base = lastExamAt ?: now
                val t = atHour(addMonths(base, months))
                // Já passou da data: avisa em breve, uma vez (1 minuto depois), em vez de ficar sem aviso.
                if (t <= now) now + 60_000L else t
            }
            else -> null
        }
    }

    fun addMonths(ms: Long, months: Int): Long =
        Calendar.getInstance().apply { timeInMillis = ms; add(Calendar.MONTH, months) }.timeInMillis

    private fun atHour(ms: Long): Long = Calendar.getInstance().apply {
        timeInMillis = ms
        set(Calendar.HOUR_OF_DAY, HOUR); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}
