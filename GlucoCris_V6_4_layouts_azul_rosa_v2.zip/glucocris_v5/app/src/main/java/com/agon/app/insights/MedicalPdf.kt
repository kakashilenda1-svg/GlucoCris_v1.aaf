package com.agon.app.insights

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import com.agon.app.data.AppData
import com.agon.app.data.formatDate
import com.agon.app.data.formatDateTime
import com.agon.app.data.formatTime
import java.io.File
import kotlin.math.roundToInt

/** Relatório médico em PDF (A4, várias páginas), feito só com os dados que a pessoa registrou. */
object MedicalPdf {
    private const val W = 595
    private const val H = 842
    private const val M = 40f

    private class Writer(val doc: PdfDocument, val footer: String) {
        var pageNo = 0
        lateinit var page: PdfDocument.Page
        lateinit var c: Canvas
        var y = 0f
        val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10.5f; color = 0xFF1F2937.toInt() }
        val small = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 8.5f; color = 0xFF6B7280.toInt() }
        val bold = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 10.5f; color = 0xFF111827.toInt(); typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val h1 = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 20f; color = 0xFF5B21B6.toInt(); typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val h2 = Paint(Paint.ANTI_ALIAS_FLAG).apply { textSize = 13f; color = 0xFF5B21B6.toInt(); typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
        val line = Paint().apply { color = 0xFFE5E7EB.toInt(); strokeWidth = 1f }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG)

        init { newPage() }

        fun newPage() {
            if (pageNo > 0) finishPage()
            pageNo++
            page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, pageNo).create())
            c = page.canvas
            y = M + 8f
        }

        private fun finishPage() {
            c.drawLine(M, H - 34f, W - M, H - 34f, line)
            c.drawText(footer, M, H - 20f, small)
            val t = "Página $pageNo"
            c.drawText(t, W - M - small.measureText(t), H - 20f, small)
            doc.finishPage(page)
        }

        fun finish() = finishPage()

        fun ensure(h: Float) { if (y + h > H - 46f) newPage() }
        fun gap(h: Float = 8f) { y += h }

        fun title(t: String) { ensure(30f); c.drawText(t, M, y + 16f, h1); y += 28f }
        fun section(t: String) { ensure(40f); y += 8f; c.drawText(t, M, y + 12f, h2); y += 17f; c.drawLine(M, y, W - M, y, line); y += 8f }

        fun wrap(text: String, p: Paint, maxW: Float): List<String> {
            val out = mutableListOf<String>()
            for (raw in text.split("\n")) {
                var cur = ""
                for (word in raw.split(" ")) {
                    val test = if (cur.isEmpty()) word else "$cur $word"
                    if (p.measureText(test) <= maxW) cur = test
                    else { if (cur.isNotEmpty()) out.add(cur); cur = word }
                }
                out.add(cur)
            }
            return out
        }

        fun para(text: String, p: Paint = body, indent: Float = 0f) {
            val lh = p.textSize + 4f
            for (l in wrap(text, p, W - 2 * M - indent)) {
                ensure(lh); c.drawText(l, M + indent, y + p.textSize, p); y += lh
            }
        }

        /** Linha de tabela com colunas de larguras fixas. */
        fun row(cols: List<String>, widths: List<Float>, p: Paint = body, shade: Boolean = false) {
            ensure(16f)
            if (shade) { fill.color = 0xFFF5F3FF.toInt(); c.drawRect(M, y - 1f, W - M, y + 14f, fill) }
            var x = M + 4f
            cols.forEachIndexed { i, t ->
                var s = t
                while (s.length > 1 && p.measureText(s) > widths[i] - 6f) s = s.dropLast(1)
                c.drawText(s, x, y + 10f, p)
                x += widths[i]
            }
            y += 15f
        }
    }

    /** Gráfico de linha só com HbA1c laboratorial (eixo x proporcional às datas de coleta). */
    private fun drawHba1cChart(w: Writer, pts: List<com.agon.app.data.Hba1cEntry>) {
        if (pts.isEmpty()) return
        w.gap(6f); w.ensure(130f)
        val left = M + 28f; val right = W - M - 10f
        val top = w.y + 8f; val h = 90f
        val minV = (pts.minOf { it.percent } - 0.5).coerceAtLeast(0.0)
        val maxV = pts.maxOf { it.percent } + 0.5
        val span = (maxV - minV).coerceAtLeast(0.1)
        fun yOf(v: Double) = top + h * (1f - ((v - minV) / span).toFloat())
        val t0 = pts.first().at; val t1 = pts.last().at
        fun xOf(t: Long) = if (t1 == t0) (left + right) / 2f else left + (right - left) * ((t - t0).toFloat() / (t1 - t0).toFloat())
        w.fill.color = 0xFFF5F3FF.toInt(); w.c.drawRect(left, top, right, top + h, w.fill)
        w.c.drawText(Hba1cRules.f1(maxV), M, top + 8f, w.small)
        w.c.drawText(Hba1cRules.f1(minV), M, top + h, w.small)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF5B21B6.toInt(); strokeWidth = 1.8f; style = Paint.Style.STROKE }
        val path = android.graphics.Path()
        pts.forEachIndexed { i, e -> val x = xOf(e.at); val y = yOf(e.percent); if (i == 0) path.moveTo(x, y) else path.lineTo(x, y) }
        if (pts.size > 1) w.c.drawPath(path, line)
        pts.forEach { e ->
            val x = xOf(e.at); val y = yOf(e.percent)
            w.fill.color = 0xFF5B21B6.toInt(); w.c.drawCircle(x, y, 3.2f, w.fill)
            val label = Hba1cRules.showPercent(e.percent)
            w.c.drawText(label, x - w.small.measureText(label) / 2f, y - 6f, w.small)
        }
        val a = formatDate(pts.first().at); val b = formatDate(pts.last().at)
        w.c.drawText(a, left, top + h + 12f, w.small)
        if (pts.size > 1) w.c.drawText(b, right - w.small.measureText(b), top + h + 12f, w.small)
        w.y = top + h + 20f
    }

    fun build(ctx: Context, data: AppData, days: Int, now: Long = System.currentTimeMillis()): File {
        val s = data.settings
        val from = now - days * Insights.DAY_MS
        val reads = Insights.readingsBetween(data, from, now)
        val st = Insights.stats(reads, s.targetLow, s.targetHigh)
        val buckets = Insights.byHour(reads, s.targetLow, s.targetHigh)

        val doc = PdfDocument()
        val w = Writer(doc, "Gluco Cris · relatório gerado em ${formatDateTime(now)} · não substitui avaliação médica")

        w.title("Relatório de glicemia")
        w.para("Paciente: ${s.displayName}", w.bold)
        val info = listOfNotNull(
            s.birthDate.takeIf { it.isNotBlank() }?.let { "Nascimento: $it" },
            s.diabetesType.takeIf { it.isNotBlank() }?.let { "Tipo de diabetes: $it" },
            s.insulinKind.takeIf { it.isNotBlank() }?.let { "Insulina: $it" },
            s.weightKg.takeIf { it.isNotBlank() }?.let { "Peso: $it kg" },
        )
        if (info.isNotEmpty()) w.para(info.joinToString("  ·  "))
        w.para("Período: ${formatDate(from)} a ${formatDate(now)} ($days dias)  ·  Meta: ${s.targetLow}–${s.targetHigh} mg/dL")

        w.section("Resumo do período")
        if (st == null) {
            w.para("Não há medições próprias registradas neste período.")
        } else {
            val cw = listOf(250f, 250f)
            w.row(listOf("Medições", "${st.count} (${"%.1f".format(st.count / days.toDouble())} por dia)"), cw, shade = true)
            w.row(listOf("Glicemia média", "${st.mean.roundToInt()} mg/dL"), cw)
            w.row(listOf("Desvio padrão", "${st.sd.roundToInt()} mg/dL"), cw, shade = true)
            w.row(listOf("Variabilidade (CV)", "${st.cv.roundToInt()}%  ${if (st.cv <= 36) "(estável, até 36%)" else "(alta, acima de 36%)"}"), cw)
            w.row(listOf("Mínima / máxima", "${st.min.roundToInt()} / ${st.max.roundToInt()} mg/dL"), cw, shade = true)
            if (st.gmiReliable) {
                w.row(listOf("GMI (estimativa)", "${"%.1f".format(java.util.Locale("pt", "BR"), st.gmi)}%"), cw)
            } else {
                w.row(listOf("GMI (estimativa)", "Dados insuficientes"), cw)
            }
            w.gap(2f)
            w.para(
                if (st.gmiReliable) {
                    "GMI (Indicador de Gerenciamento da Glicose) = 3,31 + 0,02392 × glicemia média (mg/dL). " +
                        "É uma ESTIMATIVA calculada a partir das medições disponíveis e não substitui o exame laboratorial de hemoglobina glicada (HbA1c). ${st.gmiNote}"
                } else {
                    "Dados insuficientes para estimar o GMI com confiança. ${st.gmiNote} " +
                        "A média glicêmica acima continua válida com base nas medições disponíveis."
                },
                w.small,
            )

            w.section(
                if (st.timeInRangeMeaningful) "Tempo nas faixas (dados de sensor)"
                else "Distribuição das medições por faixa"
            )
            val parts = listOf(
                Triple("Muito baixa (< ${minOf(54, s.targetLow)})", st.veryLowPct, 0xFFC2410C.toInt()),
                Triple("Baixa (< ${s.targetLow})", st.lowPct, 0xFFF59E0B.toInt()),
                Triple("Na meta (${s.targetLow}–${s.targetHigh})", st.inRangePct, 0xFF16A34A.toInt()),
                Triple("Alta (> ${s.targetHigh})", st.highPct, 0xFFEF4444.toInt()),
                Triple("Muito alta (> ${maxOf(250, s.targetHigh)})", st.veryHighPct, 0xFF991B1B.toInt()),
            )
            w.ensure(30f)
            var x = M
            val total = W - 2 * M
            parts.forEach { (_, pct, col) ->
                val wd = (total * (pct / 100.0)).toFloat()
                if (wd > 0f) { w.fill.color = col; w.c.drawRect(x, w.y, x + wd, w.y + 16f, w.fill); x += wd }
            }
            w.y += 24f
            parts.forEach { (label, pct, col) ->
                w.ensure(14f)
                w.fill.color = col; w.c.drawRect(M, w.y + 1f, M + 9f, w.y + 10f, w.fill)
                w.c.drawText("$label: ${pct.roundToInt()}%", M + 15f, w.y + 9f, w.body)
                w.y += 14f
            }

            w.section("Padrões por horário do dia")
            Insights.dayParts(reads).forEach { dp ->
                w.para("• ${dp.label}: ${dp.mean?.let { "${it.roundToInt()} mg/dL em média (${dp.count} medições)" } ?: "sem medições"}")
            }
            // Gráfico de barras: média por hora
            w.gap(6f); w.ensure(110f)
            val chartTop = w.y; val chartH = 80f; val bw = (W - 2 * M) / 24f
            val maxV = maxOf(250.0, buckets.maxOf { it.mean })
            w.fill.color = 0xFFDCFCE7.toInt()
            val yHigh = chartTop + chartH * (1f - (s.targetHigh / maxV).toFloat())
            val yLow = chartTop + chartH * (1f - (s.targetLow / maxV).toFloat())
            w.c.drawRect(M, yHigh, W - M, yLow, w.fill)
            buckets.forEach { b ->
                if (b.count > 0) {
                    val hgt = chartH * (b.mean / maxV).toFloat()
                    w.fill.color = when { b.mean < s.targetLow -> 0xFFF59E0B.toInt(); b.mean > s.targetHigh -> 0xFFEF4444.toInt(); else -> 0xFF16A34A.toInt() }
                    w.c.drawRect(M + b.hour * bw + 1.5f, chartTop + chartH - hgt, M + (b.hour + 1) * bw - 1.5f, chartTop + chartH, w.fill)
                }
            }
            listOf(0, 6, 12, 18, 23).forEach { h -> w.c.drawText(Insights.hourLabel(h), M + h * bw, chartTop + chartH + 11f, w.small) }
            w.y = chartTop + chartH + 18f
            w.para("Faixa verde clara = meta. Barras = média das medições feitas em cada hora.", w.small)

            val lows = Insights.criticalLowHours(buckets)
            val highs = Insights.criticalHighHours(buckets)
            w.gap(2f)
            w.para("Horários críticos de hipoglicemia: " + (if (lows.isEmpty()) "nenhum padrão identificado." else lows.joinToString("; ") { "${Insights.hourLabel(it.hour)} (${it.lows} de ${it.count} medições baixas)" }))
            w.para("Horários críticos de hiperglicemia: " + (if (highs.isEmpty()) "nenhum padrão identificado." else highs.joinToString("; ") { "${Insights.hourLabel(it.hour)} (${it.highs} de ${it.count} medições altas)" }))
        }

        // HbA1c LABORATORIAL: só resultados de laudo digitados pela pessoa. Nada estimado entra nesta seção.
        w.section("Exames laboratoriais de HbA1c (resultados do laudo)")
        val labs = Hba1cHistory.rows(data.hba1c)
        if (labs.isEmpty()) {
            w.para("Nenhum resultado de HbA1c laboratorial registrado no aplicativo.")
        } else {
            val last = labs.first().entry
            w.para("Resultado laboratorial mais recente: ${Hba1cRules.showPercent(last.percent)}%  ·  coleta em ${formatDate(last.at)}" +
                (if (last.lab.isNotBlank()) "  ·  ${last.lab}" else ""), w.bold)
            w.gap(2f)
            val cw = listOf(80f, 70f, 215f, 150f)
            w.row(listOf("Coleta", "Resultado", "Laboratório", "Variação vs. exame anterior"), cw, w.bold)
            labs.take(12).forEachIndexed { i, r ->
                w.row(
                    listOf(formatDate(r.entry.at), "${Hba1cRules.showPercent(r.entry.percent)}%", r.entry.lab.ifBlank { "—" }, Hba1cHistory.deltaText(r.deltaPp)),
                    cw, shade = i % 2 == 0,
                )
            }
            if (labs.size > 12) w.para("Mostrando os 12 exames mais recentes de ${labs.size} registrados.", w.small)
            drawHba1cChart(w, Hba1cHistory.chartPoints(data.hba1c, 12))
            w.para("Gráfico com exclusivamente os resultados laboratoriais registrados (não inclui GMI nem outras estimativas).", w.small)
        }

        // Comparação: valores SEPARADOS, nunca somados nem confundidos.
        w.section("Comparação: HbA1c laboratorial × GMI estimado")
        val cmp = Hba1cCompare.compute(data, now, days)
        val cw2 = listOf(200f, 300f)
        w.row(
            listOf("HbA1c laboratorial (exame)", cmp.lab?.let { "${Hba1cRules.showPercent(it.percent)}%  (coleta em ${formatDate(it.at)})" } ?: "Sem exame registrado"),
            cw2, shade = true,
        )
        w.row(
            listOf("GMI (estimativa, últimos $days dias)", if (cmp.gmiAvailable) "${Hba1cRules.f1(cmp.gmi!!)}%" else "Não disponível (dados insuficientes)"),
            cw2,
        )
        w.row(listOf("Glicemia média usada no cálculo", cmp.meanMg?.let { "${it.roundToInt()} mg/dL (${cmp.readings} medições)" } ?: "Sem medições no período"), cw2, shade = true)
        val origin = when (cmp.origin) {
            DataOrigin.CGM -> "Sensor (CGM)"
            DataOrigin.MIXED -> "Misto (glicosímetro e sensor)"
            DataOrigin.METER -> "Glicosímetro"
            null -> "—"
        }
        w.row(listOf("Origem dos dados do GMI", origin), cw2)
        if (cmp.origin == DataOrigin.CGM) {
            w.row(listOf("Cobertura CGM", cmp.coveragePct?.let { "≈ ${it.roundToInt()}%" } ?: "Não foi possível confirmar"), cw2, shade = true)
        }
        w.row(
            listOf("Diferença (GMI − HbA1c)", cmp.diffPp?.let { (if (it >= 0) "+" else "−") + Hba1cRules.f1(kotlin.math.abs(it)) + " p.p." } ?: "Não calculada"),
            cw2, shade = cmp.origin != DataOrigin.CGM,
        )
        w.gap(2f)
        if (!cmp.gmiAvailable && cmp.gmiUnavailableReason.isNotBlank()) w.para(cmp.gmiUnavailableReason, w.small)
        if (cmp.periodNote.isNotBlank()) w.para(cmp.periodNote, w.small)
        w.para(cmp.disclaimer, w.small)

        // Insulinas
        w.section("Insulinas aplicadas no período")
        val ins = data.insulin.filter { !it.id.startsWith("demo-") && it.kind == "aplicacao" && it.at in from..now }
        if (ins.isEmpty()) w.para("Nenhuma aplicação registrada.")
        else {
            val cw = listOf(230f, 80f, 90f, 100f)
            w.row(listOf("Insulina", "Aplicações", "Dose média", "Total"), cw, w.bold)
            ins.groupBy { it.name }.entries.sortedByDescending { it.value.size }.forEachIndexed { i, (name, list) ->
                w.row(listOf(name, "${list.size}", "${"%.1f".format(list.map { it.dose }.average())} UI", "${"%.1f".format(list.sumOf { it.dose })} UI"), cw, shade = i % 2 == 0)
            }
        }

        // Medicamentos
        w.section("Medicamentos em uso")
        val meds = data.medications.filter { it.active && !it.id.startsWith("demo-") }
        val profMeds = s.profileMedications.filter { it.name.isNotBlank() }
        if (meds.isEmpty() && profMeds.isEmpty()) w.para("Nenhum medicamento cadastrado.")
        meds.forEach { w.para("• ${it.name} — ${it.dose}${if (it.schedule.isNotBlank()) " — ${it.schedule}" else ""}") }
        profMeds.forEach { w.para("• ${it.name}${if (it.dose.isNotBlank()) " — ${it.dose}" else ""}${if (it.frequency.isNotBlank()) " — ${it.frequency}" else ""}") }

        // Refeições com mais carboidratos
        w.section("Refeições com mais carboidratos")
        val meals = data.meals.filter { !it.id.startsWith("demo-") && it.carbs != null && it.at in from..now }.sortedByDescending { it.carbs }.take(8)
        if (meals.isEmpty()) w.para("Nenhuma refeição com carboidratos registrada neste período.")
        meals.forEach { w.para("• ${formatDate(it.at)} ${formatTime(it.at)} · ${it.description.take(70)} · ${"%.0f".format(it.carbs)} g") }

        // Alimentos que mais elevam a glicose
        val resp = FoodResponse.compute(data, now).filter { ((it.rise2h ?: it.rise1h) ?: 0.0) > 0.0 }.take(5)
        if (resp.isNotEmpty()) {
            w.section("Alimentos com maior subida da glicose (pessoal)")
            resp.forEach { r ->
                w.para("• ${r.name}: +${(r.rise1h ?: 0.0).roundToInt()} mg/dL após 1 h, +${(r.rise2h ?: 0.0).roundToInt()} mg/dL após 2 h (${r.meals} refeição(ões))")
            }
            w.para("Resposta da refeição inteira; com poucas refeições o resultado é só um indício.", w.small)
        }

        // Resumo diário
        if (reads.isNotEmpty()) {
            w.section("Resumo por dia")
            val cw = listOf(90f, 70f, 80f, 80f, 80f, 100f)
            w.row(listOf("Dia", "Medições", "Média", "Mínima", "Máxima", "Na meta"), cw, w.bold)
            reads.groupBy { formatDate(it.at) }.entries.toList().takeLast(31).forEachIndexed { i, (day, list) ->
                val v = list.map { it.mg }
                val inR = v.count { it >= s.targetLow && it <= s.targetHigh } * 100 / v.size
                w.row(listOf(day, "${v.size}", "${v.average().roundToInt()}", "${v.min().roundToInt()}", "${v.max().roundToInt()}", "$inR%"), cw, shade = i % 2 == 0)
            }
        }

        w.gap(10f)
        w.para("Este relatório resume o que foi registrado no aplicativo e serve de apoio à consulta. Ele não faz diagnóstico nem indica doses de insulina; condutas devem ser definidas pela equipe de saúde.", w.small)
        w.finish()

        val dir = File(ctx.cacheDir, "share").apply { mkdirs() }
        val f = File(dir, "relatorio_medico_gluco_cris.pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        return f
    }
}
