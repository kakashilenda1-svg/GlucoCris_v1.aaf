package com.agon.app.localai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.util.Base64
import android.util.Log
import com.agon.app.data.CrisGemini
import com.agon.app.data.CrisGemini.GPart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipInputStream

enum class AttKind { IMAGE, PDF, DOC, TEXT, AUDIO, VIDEO }

/** Arquivo anexado pela pessoa, já copiado para o cache do app (nada fica na memória até a hora de enviar). */
class CrisAttachment(
    val name: String,
    val mime: String,
    val kind: AttKind,
    val file: File,
)

/** Erro com mensagem pronta para mostrar à pessoa. */
class AttachException(message: String) : Exception(message)

/** Resultado da análise. [source] = CrisLocalAi.SRC_ONLINE / SRC_LOCAL / SRC_BASIC. */
data class AttachResult(val text: String, val source: String, val needsReview: Boolean = false)

/**
 * Leitura de anexos da Cris IA: fotos, PDFs, Word (.docx), texto/CSV, áudio e vídeo.
 *
 * Caminho principal (online): envia o arquivo ORIGINAL em alta qualidade para a IA multimodal (Gemini),
 * com instruções para explicar documentos médicos (receitas, pedidos de exame, laudos) com precisão.
 * Caminho de reserva (sem internet / sem chave / cota): OCR no aparelho (fotos e PDFs) + glossário de exames
 * e abreviações — nunca cai no chat de texto dizendo "não tenho acesso a imagens".
 */
object CrisAttachments {
    private const val TAG = "CrisAttachments"

    /** Limite do arquivo copiado (acima disso, recusa). */
    private const val MAX_COPY_BYTES = 120L * 1024 * 1024
    /** Limite total de bytes "crus" enviados em linha à IA online (o pedido inteiro aceita ~20 MB em base64). */
    private const val INLINE_BUDGET = 14L * 1024 * 1024
    const val MAX_ATTACHMENTS = 4

    private val IMG_EXT = setOf("jpg", "jpeg", "png", "webp", "heic", "heif", "gif", "bmp", "jfif")
    private val TXT_EXT = setOf("txt", "csv", "tsv", "md", "json", "log", "xml", "html", "htm", "rtf")
    private val AUD_EXT = setOf("mp3", "wav", "m4a", "aac", "ogg", "oga", "opus", "flac", "amr", "3ga", "wma", "aiff")
    private val VID_EXT = setOf("mp4", "mov", "3gp", "3gpp", "webm", "mkv", "avi", "mpeg", "mpg", "m4v", "wmv", "flv")

    // ------------------------------------------------------------------------------------------
    // 1) Receber o arquivo
    // ------------------------------------------------------------------------------------------

    suspend fun prepare(context: Context, uri: Uri): CrisAttachment = withContext(Dispatchers.IO) {
        val cr = context.contentResolver
        var name = "anexo"
        try {
            cr.query(uri, null, null, null, null)?.use { c ->
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
            }
        } catch (_: Exception) { }
        val dir = File(context.cacheDir, "cris_att").apply { mkdirs() }
        cleanOld(dir)
        val safe = name.replace(Regex("[^A-Za-z0-9._-]"), "_").takeLast(60).ifBlank { "anexo" }
        val out = File(dir, "${System.currentTimeMillis()}_$safe")
        var total = 0L
        try {
            val input = cr.openInputStream(uri) ?: throw AttachException("Não consegui ler o arquivo. Tente anexar de novo.")
            input.use { inp ->
                out.outputStream().use { o ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = inp.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > MAX_COPY_BYTES) throw AttachException("Arquivo grande demais (máx. ~120 MB).")
                        o.write(buf, 0, n)
                    }
                }
            }
        } catch (e: AttachException) {
            out.delete(); throw e
        } catch (e: Exception) {
            out.delete(); throw AttachException("Não consegui ler o arquivo (${e.message ?: "erro"}).")
        }
        if (total == 0L) { out.delete(); throw AttachException("O arquivo está vazio.") }

        val declared = cr.getType(uri) ?: "application/octet-stream"
        val kind = detectKind(declared, name) ?: sniffKind(out)
        if (kind == null) {
            out.delete()
            throw AttachException(
                "Ainda não sei ler esse tipo de arquivo ($declared). Posso ler fotos, PDF, Word (.docx), texto, CSV, áudio e vídeo.",
            )
        }
        CrisAttachment(name, normalizeMime(declared, name, kind, out), kind, out)
    }

    fun cleanup(atts: List<CrisAttachment>) {
        atts.forEach { try { it.file.delete() } catch (_: Exception) { } }
    }

    private fun cleanOld(dir: File) {
        val limit = System.currentTimeMillis() - 24L * 3600 * 1000
        dir.listFiles()?.forEach { if (it.lastModified() < limit) it.delete() }
    }

    private fun detectKind(mime: String, name: String): AttKind? {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when {
            mime.startsWith("image/") || ext in IMG_EXT -> AttKind.IMAGE
            mime == "application/pdf" || ext == "pdf" -> AttKind.PDF
            ext == "docx" || mime == "application/vnd.openxmlformats-officedocument.wordprocessingml.document" -> AttKind.DOC
            mime.startsWith("text/") || mime == "application/json" || ext in TXT_EXT -> AttKind.TEXT
            mime.startsWith("audio/") || mime == "application/ogg" || ext in AUD_EXT -> AttKind.AUDIO
            mime.startsWith("video/") || ext in VID_EXT -> AttKind.VIDEO
            else -> null
        }
    }

    /** Arquivo sem extensão/tipo (comum em WhatsApp/Drive): olha os primeiros bytes. */
    private fun sniffKind(f: File): AttKind? {
        val h = ByteArray(16)
        val n = try { f.inputStream().use { it.read(h) } } catch (_: Exception) { return null }
        if (n < 4) return null
        fun starts(vararg b: Int) = b.indices.all { h[it] == b[it].toByte() }
        return when {
            starts(0x25, 0x50, 0x44, 0x46) -> AttKind.PDF // %PDF
            starts(0xFF, 0xD8, 0xFF) || starts(0x89, 0x50, 0x4E, 0x47) -> AttKind.IMAGE
            starts(0x47, 0x49, 0x46) -> AttKind.IMAGE
            starts(0x52, 0x49, 0x46, 0x46) -> AttKind.IMAGE // RIFF (webp) — o decodificador confirma depois
            starts(0x4F, 0x67, 0x67, 0x53) || starts(0x49, 0x44, 0x33) -> AttKind.AUDIO // OggS / ID3
            else -> null
        }
    }

    private fun normalizeMime(declared: String, name: String, kind: AttKind, f: File): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (kind) {
            AttKind.IMAGE -> "image/jpeg"
            AttKind.PDF -> "application/pdf"
            AttKind.DOC -> "text/plain"
            AttKind.TEXT -> "text/plain"
            AttKind.AUDIO -> when {
                ext == "mp3" || declared.contains("mpeg") || declared.contains("mp3") -> "audio/mp3"
                ext == "wav" || declared.contains("wav") -> "audio/wav"
                ext == "m4a" || ext == "mp4" || declared.contains("m4a") || declared.contains("mp4") -> "audio/mp4"
                ext == "aac" || declared.contains("aac") -> "audio/aac"
                ext in setOf("ogg", "oga", "opus") || declared.contains("ogg") || declared.contains("opus") -> "audio/ogg"
                ext == "flac" || declared.contains("flac") -> "audio/flac"
                ext in setOf("aiff", "aif") || declared.contains("aiff") -> "audio/aiff"
                declared.startsWith("audio/") && declared != "audio/*" -> declared
                else -> "audio/mp3"
            }
            AttKind.VIDEO -> when {
                ext == "mov" -> "video/quicktime"
                ext in setOf("3gp", "3gpp") -> "video/3gpp"
                ext == "webm" -> "video/webm"
                ext in setOf("mpeg", "mpg") -> "video/mpeg"
                ext == "avi" -> "video/x-msvideo"
                ext == "wmv" -> "video/x-ms-wmv"
                ext == "flv" -> "video/x-flv"
                declared.startsWith("video/") -> declared
                else -> "video/mp4"
            }
        }
    }

    // ------------------------------------------------------------------------------------------
    // 2) Imagens: decodificar com a rotação certa (EXIF) e sem estourar a memória
    // ------------------------------------------------------------------------------------------

    fun decodeBitmap(file: File, maxSide: Int): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.path, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxSide) sample *= 2
            var bmp = BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: return null
            // Orientação da câmera: sem isso, foto "deitada" e a leitura erra.
            val m = Matrix()
            try {
                when (ExifInterface(file.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                    ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                    ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                    ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                    ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                    ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
                    ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
                    ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(270f); m.postScale(-1f, 1f) }
                }
            } catch (_: Exception) { }
            val longest = maxOf(bmp.width, bmp.height)
            if (longest > maxSide) {
                val k = maxSide.toFloat() / longest
                m.postScale(k, k)
            }
            if (!m.isIdentity) {
                val t = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
                if (t !== bmp) { bmp.recycle(); bmp = t }
            }
            flattenOnWhite(bmp)
        } catch (_: OutOfMemoryError) {
            null
        } catch (_: Exception) {
            null
        }
    }

    /** PNG com transparência viraria fundo preto no JPEG e o texto sumiria. */
    private fun flattenOnWhite(bmp: Bitmap): Bitmap {
        if (!bmp.hasAlpha()) return bmp
        val out = Bitmap.createBitmap(bmp.width, bmp.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(Color.WHITE)
        c.drawBitmap(bmp, 0f, 0f, null)
        bmp.recycle()
        return out
    }

    private fun jpegB64(bmp: Bitmap, quality: Int): String {
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, baos)
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }

    // ------------------------------------------------------------------------------------------
    // 3) PDF, Word, texto, vídeo
    // ------------------------------------------------------------------------------------------

    /** Renderiza páginas do PDF como imagens (fundo branco). */
    private fun renderPdfPages(file: File, maxPages: Int, widthPx: Int): List<Bitmap> {
        val pages = ArrayList<Bitmap>()
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        try {
            pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            val count = minOf(renderer.pageCount, maxPages)
            for (i in 0 until count) {
                val page = renderer.openPage(i)
                try {
                    val w = widthPx
                    val h = (page.height.toFloat() * w / page.width.coerceAtLeast(1)).toInt().coerceIn(1, 6000)
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    pages.add(bmp)
                } finally {
                    page.close()
                }
            }
        } catch (e: SecurityException) {
            throw AttachException("Esse PDF tem senha. Abra no leitor de PDF, salve sem senha e envie de novo.")
        } catch (e: OutOfMemoryError) {
            throw AttachException("PDF pesado demais para abrir no aparelho. Tente enviar menos páginas.")
        } catch (e: Exception) {
            Log.w(TAG, "pdf render", e)
            if (pages.isEmpty()) throw AttachException("Não consegui abrir esse PDF (pode estar corrompido).")
        } finally {
            try { renderer?.close() } catch (_: Exception) { }
            try { pfd?.close() } catch (_: Exception) { }
        }
        return pages
    }

    private fun readText(file: File): String {
        val bytes = file.readBytes()
        val utf8 = String(bytes, Charsets.UTF_8)
        return if (utf8.contains('\uFFFD')) String(bytes, Charsets.ISO_8859_1) else utf8
    }

    private fun readDocx(file: File): String {
        try {
            ZipInputStream(file.inputStream().buffered()).use { zin ->
                while (true) {
                    val e = zin.nextEntry ?: break
                    if (e.name == "word/document.xml") {
                        val xml = String(zin.readBytes(), Charsets.UTF_8)
                        return xml
                            .replace("</w:p>", "\n")
                            .replace(Regex("<w:tab\\s*/>"), "\t")
                            .replace(Regex("<w:br\\s*/>"), "\n")
                            .replace(Regex("<[^>]+>"), "")
                            .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
                            .replace("&quot;", "\"").replace("&apos;", "'")
                            .replace(Regex("\n{3,}"), "\n\n")
                            .trim()
                    }
                }
            }
        } catch (_: Exception) { }
        throw AttachException("Não consegui ler esse documento Word. Salve como PDF e envie de novo.")
    }

    private fun videoFrames(file: File, n: Int, maxSide: Int): List<Bitmap> {
        val r = MediaMetadataRetriever()
        val out = ArrayList<Bitmap>()
        try {
            r.setDataSource(file.path)
            val durMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            for (i in 1..n) {
                val at = if (durMs > 0) durMs * i / (n + 1) else 0L
                val f = r.getFrameAtTime(at * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                val k = maxSide.toFloat() / maxOf(f.width, f.height)
                out.add(if (k < 1f) Bitmap.createScaledBitmap(f, (f.width * k).toInt().coerceAtLeast(1), (f.height * k).toInt().coerceAtLeast(1), true) else f)
            }
        } catch (e: Exception) {
            Log.w(TAG, "video frames", e)
        } finally {
            try { r.release() } catch (_: Exception) { }
        }
        return out
    }

    // ------------------------------------------------------------------------------------------
    // 4) Montar as partes para a IA online
    // ------------------------------------------------------------------------------------------

    private fun fileB64(file: File): String = Base64.encodeToString(file.readBytes(), Base64.NO_WRAP)

    private suspend fun toGeminiParts(atts: List<CrisAttachment>): List<GPart> = withContext(Dispatchers.IO) {
        val parts = ArrayList<GPart>()
        var budget = INLINE_BUDGET
        val multi = atts.size > 1
        atts.forEachIndexed { idx, a ->
            val label = if (multi) "Anexo ${idx + 1}: ${a.name}" else "Anexo: ${a.name}"
            when (a.kind) {
                AttKind.IMAGE -> {
                    // 1280 px e qualidade 80: o envio fica ~40% menor (mais rápido no 4G/5G) e continua legível para o Gemini.
                    val bmp = decodeBitmap(a.file, 1280)
                        ?: throw AttachException("Não consegui abrir a imagem \"${a.name}\". Tente outra foto ou um print.")
                    val b64 = jpegB64(bmp, 80)
                    bmp.recycle()
                    budget -= b64.length * 3L / 4
                    parts.add(GPart.Text("$label (imagem)"))
                    parts.add(GPart.Inline("image/jpeg", b64))
                }
                AttKind.PDF -> {
                    if (a.file.length() <= budget) {
                        budget -= a.file.length()
                        parts.add(GPart.Text("$label (PDF)"))
                        parts.add(GPart.Inline("application/pdf", fileB64(a.file)))
                    } else {
                        // PDF muito pesado: manda as páginas como imagens
                        val pages = renderPdfPages(a.file, 20, 1400)
                        parts.add(GPart.Text("$label (PDF grande, páginas 1 a ${pages.size} como imagens)"))
                        for (p in pages) {
                            val b64 = jpegB64(p, 82); p.recycle()
                            budget -= b64.length * 3L / 4
                            parts.add(GPart.Inline("image/jpeg", b64))
                        }
                    }
                }
                AttKind.TEXT -> parts.add(GPart.Text("$label (texto):\n" + readText(a.file).take(150_000)))
                AttKind.DOC -> parts.add(GPart.Text("$label (documento Word):\n" + readDocx(a.file).take(150_000)))
                AttKind.AUDIO -> {
                    if (a.mime == "audio/mp3" && a.name.substringAfterLast('.', "").lowercase() == "amr") {
                        throw AttachException("Áudio .amr não é aceito. Envie em mp3, m4a, wav ou ogg.")
                    }
                    if (a.file.length() > budget) {
                        throw AttachException("Áudio grande demais (máx. ~14 MB, uns 10 a 15 minutos). Envie um trecho menor.")
                    }
                    budget -= a.file.length()
                    parts.add(GPart.Text("$label (áudio)"))
                    parts.add(GPart.Inline(a.mime, fileB64(a.file)))
                }
                AttKind.VIDEO -> {
                    if (a.file.length() <= budget) {
                        budget -= a.file.length()
                        parts.add(GPart.Text("$label (vídeo)"))
                        parts.add(GPart.Inline(a.mime, fileB64(a.file)))
                    } else {
                        val frames = videoFrames(a.file, 10, 1280)
                        if (frames.isEmpty()) throw AttachException("Vídeo grande demais e não consegui extrair imagens dele. Envie um trecho menor (até ~14 MB).")
                        parts.add(GPart.Text("$label (vídeo grande: só ${frames.size} imagens tiradas ao longo do vídeo, sem o som)"))
                        for (f in frames) {
                            val b64 = jpegB64(f, 82); f.recycle()
                            budget -= b64.length * 3L / 4
                            parts.add(GPart.Inline("image/jpeg", b64))
                        }
                    }
                }
            }
        }
        parts
    }

    // ------------------------------------------------------------------------------------------
    // 5) Leitura no aparelho (reserva sem internet)
    // ------------------------------------------------------------------------------------------

    private suspend fun readOnDevice(a: CrisAttachment): String = withContext(Dispatchers.Default) {
        when (a.kind) {
            AttKind.IMAGE -> {
                val bmp = decodeBitmap(a.file, 2560) ?: return@withContext ""
                try { LocalVisionManager.ocr(bmp) } finally { bmp.recycle() }
            }
            AttKind.PDF -> {
                val pages = renderPdfPages(a.file, 10, 1600)
                val sb = StringBuilder()
                pages.forEachIndexed { i, p ->
                    val t = try { LocalVisionManager.ocr(p) } finally { p.recycle() }
                    if (t.isNotBlank()) sb.append("— Página ${i + 1} —\n").append(t).append("\n\n")
                }
                sb.toString().trim()
            }
            AttKind.TEXT -> readText(a.file)
            AttKind.DOC -> readDocx(a.file)
            AttKind.VIDEO -> {
                val sb = StringBuilder()
                for (f in videoFrames(a.file, 3, 1280)) {
                    val t = try { LocalVisionManager.ocr(f) } finally { f.recycle() }
                    if (t.isNotBlank()) sb.append(t).append("\n")
                }
                sb.toString().trim()
            }
            AttKind.AUDIO -> ""
        }
    }

    // ------------------------------------------------------------------------------------------
    // 6) Orquestração
    // ------------------------------------------------------------------------------------------

    /**
     * Analisa os anexos. SEMPRE devolve um texto útil (nunca null e nunca "não tenho acesso a imagens").
     * [localSystem] = prompt da Cris local (usado só para fotos sem texto, se a IA local estiver instalada).
     */
    suspend fun analyze(
        context: Context,
        atts: List<CrisAttachment>,
        question: String,
        appContext: String,
        userName: String,
        history: List<Pair<Boolean, String>>,
        localSystem: String,
    ): AttachResult {
        var onlineProblem: String? = null

        // A) IA online multimodal — leitura precisa do arquivo original
        if (CrisGemini.isConfigured()) {
            if (CrisConnectivityManager.isOnline(context)) {
                try {
                    val parts = toGeminiParts(atts)
                    val out = CrisGemini.analyzeParts(context, question, appContext, userName, history, parts)
                    if (!out.text.isNullOrBlank()) {
                        // Sem CrisSafetyGuard.postcheck de propósito: numa receita, "tomar 1 comprimido" ou "10 unidades" é
                        // o que o médico escreveu e a pessoa quer entender. O prompt proíbe a Cris de mudar/sugerir dose.
                        return AttachResult(out.text, CrisLocalAi.SRC_ONLINE)
                    }
                    onlineProblem = out.error
                } catch (e: AttachException) {
                    onlineProblem = e.message
                } catch (e: OutOfMemoryError) {
                    onlineProblem = "memória insuficiente para enviar esse arquivo"
                } catch (e: Exception) {
                    Log.w(TAG, "online analyze", e)
                    onlineProblem = e.message ?: "erro"
                }
            } else {
                onlineProblem = "sem internet"
            }
        } else {
            onlineProblem = "leitura avançada indisponível neste aparelho"
        }

        // B) Reserva: leitura no aparelho (OCR) + glossário
        return offlineFallback(context, atts, question, userName, history, localSystem, onlineProblem)
    }

    /**
     * Sem a IA online (sem chave, sem internet ou sem cota): o texto lido no aparelho vai para a IA LOCAL junto com a mensagem da pessoa
     * e a conversa anterior, e a Cris responde em linguagem natural (sem explicar "como leu"). Só se a IA local não existir ou falhar
     * é que sobra o texto lido, em tom simples.
     */
    private suspend fun offlineFallback(
        context: Context,
        atts: List<CrisAttachment>,
        question: String,
        userName: String,
        history: List<Pair<Boolean, String>>,
        localSystem: String,
        problem: String?,
    ): AttachResult {
        val texts = ArrayList<Pair<String, String>>()
        var firstError: String? = null
        for (a in atts) {
            try {
                texts.add(a.name to readOnDevice(a).trim())
            } catch (e: AttachException) {
                if (firstError == null) firstError = e.message
                texts.add(a.name to "")
            } catch (e: Exception) {
                texts.add(a.name to "")
            }
        }
        val any = texts.filter { it.second.isNotBlank() }
        val totalChars = any.sumOf { it.second.length }
        val img = atts.singleOrNull { it.kind == AttKind.IMAGE }
        val shortImageText = img != null && totalChars < 80
        val localReady = CrisLocalAi.isReady(context)
        Log.i(TAG, "anexo sem IA online (${problem ?: "-"}); texto lido: $totalChars caracteres; IA local: $localReady")

        // 1) Há texto: a IA local lê esse texto, entende a conversa e responde natural (inclusive corrigindo a si mesma)
        if (any.isNotEmpty() && !shortImageText && localReady) {
            answerWithLocalAi(context, any, question, userName, history)?.let {
                return AttachResult(it, CrisLocalAi.SRC_LOCAL, needsReview = true)
            }
        }

        // 2) Foto sem texto (prato, objeto…) ou com pouquíssimo texto: visão da IA local
        if (img != null && (any.isEmpty() || shortImageText) && localReady) {
            try {
                val bmp = decodeBitmap(img.file, 1280)
                if (bmp != null) {
                    val res = LocalVisionManager.analyze(context, bmp, question, localSystem, history)
                    val t = CrisSafetyGuard.postcheck(res.text)
                    if (t.isNotBlank()) return AttachResult(t, CrisLocalAi.SRC_LOCAL, needsReview = true)
                }
            } catch (e: Exception) {
                Log.w(TAG, "local vision", e)
            }
        }

        // 3) Sem IA local (ou ela não respondeu): devolve o que foi lido, em tom simples
        if (any.isEmpty()) {
            val extra = firstError?.let { "\n\n$it" } ?: ""
            val what = when {
                atts.any { it.kind == AttKind.AUDIO } -> "Para ouvir áudios eu preciso de internet. Tenta de novo quando conectar?"
                atts.any { it.kind == AttKind.VIDEO } -> "Para assistir vídeos eu preciso de internet. Tenta de novo quando conectar?"
                else -> "Não consegui ler nada nesse arquivo. Pode mandar outra foto, mais de perto e com boa luz?"
            }
            return AttachResult(what + extra, CrisLocalAi.SRC_BASIC, needsReview = true)
        }

        val sb = StringBuilder()
        sb.append("Aqui está o que consegui ler:\n")
        for ((name, t) in any) {
            sb.append("\n").append(if (any.size > 1) "📄 $name:\n" else "").append(t.take(3500))
            if (t.length > 3500) sb.append("\n[…texto cortado]")
            sb.append("\n")
        }
        val gl = glossaryFor(any.joinToString("\n") { it.second })
        if (gl.isNotEmpty()) {
            sb.append("\nO que significa, em geral:\n")
            gl.forEach { sb.append("• ").append(it).append("\n") }
        }
        if (!localReady) sb.append("\nSe quiser que eu explique e converse sobre isso, instale a IA local: toque no status sob meu nome, no chat.")
        return AttachResult(sb.toString().trim(), CrisLocalAi.SRC_LOCAL, needsReview = true)
    }

    /**
     * A IA local responde sobre o anexo. O motor corta o prompt de sistema em 3.400 caracteres e a mensagem em 700, por isso aqui o prompt
     * é enxuto e o texto do anexo entra no sistema, dentro do orçamento (as instruções vêm primeiro). Devolve null se a IA local falhar.
     */
    private suspend fun answerWithLocalAi(
        context: Context,
        docs: List<Pair<String, String>>,
        question: String,
        userName: String,
        history: List<Pair<Boolean, String>>,
    ): String? {
        val head = buildString {
            append("Você é a Cris ❤️, assistente do aplicativo Gluco Cris. Fale em português do Brasil, de forma natural, simpática e correta, como numa conversa.\n")
            if (userName.isNotBlank()) append("Nome da pessoa: $userName\n")
            append("A pessoa acabou de enviar um anexo. Abaixo está o texto extraído dele; pode ter pequenos erros e ruído de tela (relógio, bateria, barra do navegador): ignore o ruído.\n")
            append("COMO RESPONDER:\n")
            append("- Responda direto ao que a pessoa escreveu e use a conversa anterior para entender a que ela se refere.\n")
            append("- Se o anexo mostra algo diferente do que você disse antes, reconheça em uma frase curta (\"Você tem razão...\"), corrija com o dado do anexo e siga a conversa.\n")
            append("- Sobre o anexo, use só o que está nele. Se um trecho estiver ilegível, diga qual. Não invente.\n")
            append("- NÃO explique como o arquivo foi lido: nada de leitura automática, OCR, limitações do aparelho ou avisos técnicos.\n")
            append("- Receita ou exame: explique cada item em linguagem simples. Nunca indique nem altere dose de insulina ou de remédio.\n")
            append("TEXTO DO ANEXO:\n")
        }
        val raw = docs.joinToString("\n\n") { (name, t) -> (if (docs.size > 1) "📄 $name:\n" else "") + t }
        val budget = (3400 - head.length - 40).coerceAtLeast(500)
        val body = if (raw.length > budget) raw.take(budget) + "…" else raw
        val q = question.ifBlank { "Explique o que está neste anexo." }
        return try {
            LocalAiEngine.get(context).generate(head + body, history.takeLast(6), q).trim().ifBlank { null }
        } catch (t: Throwable) {
            Log.w(TAG, "IA local nos anexos: ${t.javaClass.simpleName}")
            null
        }
    }

    // ------------------------------------------------------------------------------------------
    // 7) Glossário (offline): exames e abreviações de receita mais comuns
    // ------------------------------------------------------------------------------------------

    private val GLOSSARY: List<Pair<Regex, String>> = listOf(
        "hba1c|hemoglobina glic|glicada|a1c" to "Hemoglobina glicada (HbA1c): mostra a média da glicose dos últimos ~3 meses.",
        "glicemia( de)? jejum|glicose( de)? jejum|glicemia" to "Glicemia: açúcar no sangue naquele momento (jejum = após ~8 a 12 h sem comer).",
        "totg|curva glic" to "Curva glicêmica (TOTG): mede a glicose antes e depois de tomar uma bebida com açúcar.",
        "hemograma" to "Hemograma: conta as células do sangue (vermelhas, brancas e plaquetas); avalia anemia e infecções.",
        "colesterol total|hdl|ldl|vldl|triglic" to "Colesterol e triglicerídeos (perfil lipídico): gorduras no sangue; importam para o coração e as artérias.",
        "creatinina|ureia|ur[eé]ia|tfg|taxa de filtra" to "Creatinina/ureia/TFG: avaliam como os rins estão filtrando o sangue.",
        "microalbumin|albumina/creatinina|\\brac\\b" to "Microalbuminúria / relação albumina-creatinina: procura perda de proteína na urina, sinal precoce de problema nos rins (importante no diabetes).",
        "tgo|tgp|\\bast\\b|\\balt\\b|gama ?gt|ggt" to "TGO/TGP (AST/ALT) e GGT: enzimas do fígado.",
        "tsh|t4 livre|\\bt3\\b" to "TSH/T4/T3: avaliam o funcionamento da tireoide.",
        "\\beas\\b|urina tipo 1|urina rotina|urin[aá]lise" to "EAS / urina tipo 1: exame de urina que avalia rins, infecção e presença de açúcar.",
        "fundo de olho|mapeamento de retina|retinografia|oftalmo" to "Fundo de olho / mapeamento de retina: examina a retina; no diabetes, procura lesões nos vasos do olho.",
        "pe[ií]ptideo ?c|peptideo ?c" to "Peptídeo C: indica quanto de insulina o próprio pâncreas ainda produz.",
        "insulina( basal| de jejum)?\\s*(s[eé]rica)?" to "Insulina no sangue (exame): quantidade de insulina produzida pelo corpo.",
        "[aá]cido [uú]rico" to "Ácido úrico: relacionado a gota e pedras nos rins.",
        "vitamina d|25-?oh|vitamina b12|\\bb12\\b" to "Vitaminas D e B12: avaliam se há falta dessas vitaminas (B12 pode cair com alguns remédios, como a metformina).",
        "ferritina|ferro s[eé]rico" to "Ferritina/ferro: avaliam as reservas de ferro (anemia).",
        "\\bpcr\\b|prote[ií]na c reativa" to "PCR: marca inflamação no corpo.",
        "ecg|eletrocardiograma" to "Eletrocardiograma (ECG): registra a atividade elétrica do coração.",
        "ecocardiograma" to "Ecocardiograma: ultrassom do coração.",
        "ultrassom|ultrassonografia|\\busg\\b" to "Ultrassonografia: exame de imagem por ultrassom, sem radiação.",
        "pot[aá]ssio|s[oó]dio" to "Potássio/sódio: sais minerais do sangue; importantes para coração, músculos e rins.",
        "monofilamento|p[eé] diab[eé]tico|neuropatia" to "Avaliação dos pés/monofilamento: testa a sensibilidade dos pés; faz parte do cuidado no diabetes.",
        "\\bv\\.?o\\.?\\b|via oral" to "VO: tomar pela boca.",
        "\\bs\\.?c\\.?\\b|subcut" to "SC: injeção sob a pele (subcutânea), como a insulina.",
        "12/12 ?h" to "12/12h: a cada 12 horas.",
        "8/8 ?h" to "8/8h: a cada 8 horas.",
        "6/6 ?h" to "6/6h: a cada 6 horas.",
        "\\bcp\\b|\\bcpr\\b|comprimido" to "cp/cpr: comprimido.",
        "\\bgts?\\b|gotas" to "gts: gotas.",
        "\\bui\\b" to "UI: unidades internacionais (medida usada, por exemplo, para insulina).",
        "\\bsos\\b|s/n\\b|se necess" to "SOS / se necessário: só tomar quando precisar.",
        "uso cont[ií]nuo" to "Uso contínuo: remédio para tomar todos os dias, sem data para parar.",
    ).map { (re, txt) -> Regex(re, RegexOption.IGNORE_CASE) to txt }

    private fun glossaryFor(text: String): List<String> =
        GLOSSARY.filter { it.first.containsMatchIn(text) }.map { it.second }.distinct().take(14)
}
