package com.agon.app.love

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import com.agon.app.data.PrefsJson
import org.json.JSONObject
import java.time.LocalDate

/**
 * Frases prontas, guardadas no aplicativo. Funcionam sem internet.
 * A ordem é fixa: uma por dia, avançando sem repetir até o fim da coleção.
 */
val LOVE_PHRASES = listOf(
    "O seu cuidado com você também é um cuidado com a gente.",
    "Estou ao seu lado nos dias bons e nos dias que pedem mais paciência.",
    "Parceiros de verdade se escolhem de novo a cada manhã.",
    "Que hoje você se lembre: não precisa dar conta de tudo sozinha.",
    "Meu amor por você não depende do dia ser fácil.",
    "Conta comigo para o café, para o silêncio e para o que vier.",
    "Cuidar de você é a parte mais bonita do meu dia.",
    "Mesmo longe um instante, meu carinho fica com você.",
    "Você não está sozinha em nenhum número, em nenhuma hora.",
    "Amor também é perguntar como você está e esperar a resposta.",
    "Que o dia de hoje seja leve, e que eu possa ser o seu descanso.",
    "Somos time: quando um cansa, o outro segura a mão.",
    "Obrigado por existir na minha vida com tanta doçura.",
    "Seu sorriso ainda é o meu lugar favorito.",
    "Pode apoiar o seu dia no meu ombro. Ele é seu.",
    "Eu escolho você com calma, com pressa e com toda a certeza.",
    "Parceria é isso: estar perto mesmo quando o dia não colabora.",
    "Que cada medição lembre só uma coisa: você é amada.",
    "Não existe rotina que apague o carinho que eu tenho por você.",
    "Hoje eu te desejo paz, água fresca e o meu abraço.",
    "Amor da minha vida, vá no seu tempo. Eu espero com você.",
    "Ser seu companheiro é o privilégio mais bonito que eu tenho.",
    "Se o dia pesar, divide comigo. A gente carrega junto.",
    "Você é a minha casa, em qualquer horário.",
    "Meu cuidado não faz barulho, mas não sai do seu lado.",
    "Que a gente continue simples, próximo e inteiro.",
    "Te amar é a minha forma preferida de começar o dia.",
    "Pode contar com a minha mão, a minha voz e a minha paciência.",
    "Nada do que você sente precisa ser enfrentado em silêncio.",
    "Eu te admiro por cuidar de você com tanta coragem.",
    "O nosso amor cabe no dia comum, e é nele que ele brilha.",
    "Se precisar de um colo hoje, ele já está reservado.",
    "Parceiros, amigos, amantes: a gente é tudo isso, todo dia.",
    "Que esta frase encontre você sorrindo, mesmo que só um pouco.",
    "Meu coração aprendeu o seu nome e não quer saber de outro.",
    "Estou aqui. Nem sempre perto, sempre seu.",
    "O carinho de hoje é o mesmo de ontem, só com um beijo a mais.",
    "Você torna o ordinário em algo que eu quero guardar.",
    "Descansa quando precisar. Eu continuo aqui, do seu lado.",
    "Amar você é o plano inteiro. O resto a gente resolve junto.",
)

const val MAIN_LOVE_MESSAGE =
    "Amor lembre-se que nem todos os dias são iguais, temos dias bons e dias ruins mas somos amigos, amantes, companheiros e parceiros todos os dias. Eu te amo mais que a minha própria vida."

const val LOVE_PHONE_DISPLAY = "+55 11 93208-9685"
const val LOVE_PHONE_TEL = "+5511932089685"
const val LOVE_WHATSAPP = "https://wa.me/5511932089685"
const val SAMU_TEL = "192"

private val Context.loveStore by preferencesDataStore(name = "gluco_love")
private val DATE_KEY = stringPreferencesKey("phrase_date")
private val INDEX_KEY = intPreferencesKey("phrase_index")

// ---- Portabilidade de dados por conta (backup completo / troca de conta) ----

suspend fun loveDumpAll(context: Context): String = PrefsJson.fromPreferences(context.loveStore.data.first()).toString()

suspend fun loveRestoreAll(context: Context, text: String) {
    val o = try { JSONObject(text) } catch (_: Exception) { return }
    context.loveStore.edit { PrefsJson.applyPreferences(it, o) }
}

suspend fun loveWipeAll(context: Context) {
    context.loveStore.edit { it.clear() }
}

/** Mesma frase o dia inteiro; no dia seguinte, a próxima da coleção. Sem rede. */
suspend fun phraseForToday(context: Context): String {
    val today = LocalDate.now().toString()
    val prefs = context.loveStore.data.first()
    val savedDate = prefs[DATE_KEY]
    val savedIndex = prefs[INDEX_KEY] ?: -1
    if (savedDate == today && savedIndex in LOVE_PHRASES.indices) return LOVE_PHRASES[savedIndex]
    val next = if (savedIndex < 0) 0 else (savedIndex + 1) % LOVE_PHRASES.size
    context.loveStore.edit {
        it[DATE_KEY] = today
        it[INDEX_KEY] = next
    }
    return LOVE_PHRASES[next]
}

/**
 * Não liga sozinho. Abre o discador com o número preenchido para a pessoa confirmar.
 * Chamada direta não foi implementada: o Android exige confirmação no discador.
 */
fun openDialer(context: Context, tel: String) {
    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$tel")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "Não foi possível abrir o discador neste aparelho.", Toast.LENGTH_LONG).show()
    }
}

/** Abre a conversa no WhatsApp, ou a página do link, sem enviar nenhuma mensagem. */
fun openWhatsApp(context: Context) {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(LOVE_WHATSAPP)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        Toast.makeText(context, "Não foi possível abrir o WhatsApp neste aparelho.", Toast.LENGTH_LONG).show()
    }
}
