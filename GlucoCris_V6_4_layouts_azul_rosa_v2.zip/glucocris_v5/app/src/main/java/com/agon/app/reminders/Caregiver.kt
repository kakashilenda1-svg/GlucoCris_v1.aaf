package com.agon.app.reminders

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.agon.app.MainActivity
import com.agon.app.R
import com.agon.app.data.AppData
import com.agon.app.data.formatDateTime
import com.agon.app.data.formatTime
import com.agon.app.insights.Insights
import kotlin.math.roundToInt

/**
 * Modo cuidador / família.
 * Um contato de confiança pode receber, COM A PERMISSÃO da pessoa, o aviso de glicemia muito baixa ou muito alta
 * e o resumo do dia. O envio é feito pelo SMS ou WhatsApp do próprio aparelho: o app prepara a mensagem
 * e a pessoa toca em enviar. Nada é enviado escondido e nenhum servidor recebe esses dados.
 */
object Caregiver {
    private const val PREFS = "gluco_caregiver_v1"
    const val CHANNEL = "gluco_cuidador_v1"
    private const val NOTIF_ID = 7731

    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun consent(ctx: Context) = sp(ctx).getBoolean("consent", false)
    fun setConsent(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("consent", v).apply()

    fun name(ctx: Context) = sp(ctx).getString("name", "") ?: ""
    fun setName(ctx: Context, v: String) = sp(ctx).edit().putString("name", v.trim()).apply()

    /** Telefone só com dígitos, com DDI (ex.: 5511999998888). */
    fun phone(ctx: Context) = sp(ctx).getString("phone", "") ?: ""
    fun setPhone(ctx: Context, v: String) = sp(ctx).edit().putString("phone", v.filter { it.isDigit() }).apply()

    fun alertsOn(ctx: Context) = sp(ctx).getBoolean("alerts_on", true)
    fun setAlertsOn(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("alerts_on", v).apply()

    fun summaryAllowed(ctx: Context) = sp(ctx).getBoolean("summary_on", true)
    fun setSummaryAllowed(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("summary_on", v).apply()

    /** Limite de glicemia grave baixa (mg/dL). */
    fun severeLow(ctx: Context) = sp(ctx).getInt("severe_low", CaregiverRules.DEFAULT_LOW).coerceIn(CaregiverRules.LOW_MIN, CaregiverRules.LOW_MAX)
    fun setSevereLow(ctx: Context, v: Int) = sp(ctx).edit().putInt("severe_low", v.coerceIn(CaregiverRules.LOW_MIN, CaregiverRules.LOW_MAX)).apply()

    /** Limite de glicemia grave alta (mg/dL). */
    fun severeHigh(ctx: Context) = sp(ctx).getInt("severe_high", CaregiverRules.DEFAULT_HIGH).coerceIn(CaregiverRules.HIGH_MIN, CaregiverRules.HIGH_MAX)
    fun setSevereHigh(ctx: Context, v: Int) = sp(ctx).edit().putInt("severe_high", v.coerceIn(CaregiverRules.HIGH_MIN, CaregiverRules.HIGH_MAX)).apply()

    /** Intervalo mínimo (min) entre dois avisos do mesmo tipo. Padrão 30 = comportamento anterior. */
    fun repeatMin(ctx: Context) = sp(ctx).getInt("repeat_min", CaregiverRules.DEFAULT_REPEAT_MIN).coerceIn(5, 720)
    fun setRepeatMin(ctx: Context, v: Int) = sp(ctx).edit().putInt("repeat_min", v.coerceIn(5, 720)).apply()

    /** Remove nome e telefone do cuidador (os demais ajustes ficam). */
    fun removeContact(ctx: Context) = sp(ctx).edit().remove("name").remove("phone").apply()

    /** Canal preferido: "sms" ou "whatsapp". */
    fun channel(ctx: Context) = sp(ctx).getString("channel", "sms") ?: "sms"
    fun setChannel(ctx: Context, v: String) = sp(ctx).edit().putString("channel", v).apply()

    fun phoneValid(ctx: Context) = CaregiverRules.checkPhone(phone(ctx)).ok

    fun ready(ctx: Context) = consent(ctx) && phoneValid(ctx)

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Aviso ao cuidador", NotificationManager.IMPORTANCE_HIGH)
        ch.description = "Quando a glicemia fica muito baixa ou muito alta, deixa pronta a mensagem para seu contato de confiança."
        nm.createNotificationChannel(ch)
    }

    const val WA_PKG = "com.whatsapp"
    const val WA_BUSINESS_PKG = "com.whatsapp.w4b"

    /** Pacote do WhatsApp instalado (comum ou Business), ou null. Precisa do bloco <queries> no manifesto. */
    @Suppress("DEPRECATION")
    fun whatsappPackage(ctx: Context): String? {
        val pm = ctx.packageManager
        for (pkg in listOf(WA_PKG, WA_BUSINESS_PKG)) {
            try {
                pm.getPackageInfo(pkg, 0)
                return pkg
            } catch (_: Exception) {
            }
        }
        return null
    }

    fun smsIntent(phone: String, body: String): Intent =
        Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:$phone")).putExtra("sms_body", body).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Abre a conversa com o número já preenchido e o texto pronto. O envio continua dependendo do toque da pessoa. */
    fun whatsappIntent(phone: String, body: String, pkg: String? = null): Intent =
        Intent(Intent.ACTION_VIEW, Uri.parse("https://api.whatsapp.com/send?phone=$phone&text=" + Uri.encode(body)))
            .apply { if (pkg != null) setPackage(pkg) }
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Alternativa: folha de compartilhamento do Android (qualquer app). */
    fun shareIntent(body: String): Intent =
        Intent.createChooser(
            Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, body) },
            "Compartilhar mensagem",
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

    /** Resultado de preparar a mensagem. NENHUM valor significa "mensagem enviada": o app só abre outro app. */
    enum class Prepared { WHATSAPP_OPENED, SMS_OPENED, SHARE_OPENED_NO_WHATSAPP, SHARE_OPENED_NO_SMS, NO_RECIPIENT, EMPTY_MESSAGE, FAILED }

    /** Intent usado pelas notificações (não lança). Sem WhatsApp instalado, cai para o compartilhamento do Android. */
    fun sendIntent(ctx: Context, body: String): Intent {
        val phone = CaregiverRules.checkPhone(phone(ctx)).digits
        if (channel(ctx) == "whatsapp") {
            val pkg = whatsappPackage(ctx)
            return if (pkg != null) whatsappIntent(phone, body, pkg) else shareIntent(body)
        }
        return smsIntent(phone, body)
    }

    /**
     * Prepara a mensagem no canal escolhido. Confere destinatário e texto antes, trata WhatsApp ausente
     * e falha ao abrir. Não detecta se a pessoa enviou ou cancelou dentro do outro app (o Android não informa).
     */
    fun prepare(ctx: Context, body: String): Prepared {
        if (body.isBlank()) return Prepared.EMPTY_MESSAGE
        val check = CaregiverRules.checkPhone(phone(ctx))
        if (!check.ok) return Prepared.NO_RECIPIENT
        return try {
            if (channel(ctx) == "whatsapp") {
                val pkg = whatsappPackage(ctx)
                if (pkg == null) {
                    ctx.startActivity(shareIntent(body))
                    Prepared.SHARE_OPENED_NO_WHATSAPP
                } else {
                    try {
                        ctx.startActivity(whatsappIntent(check.digits, body, pkg))
                        Prepared.WHATSAPP_OPENED
                    } catch (_: android.content.ActivityNotFoundException) {
                        ctx.startActivity(shareIntent(body))
                        Prepared.SHARE_OPENED_NO_WHATSAPP
                    }
                }
            } else {
                try {
                    ctx.startActivity(smsIntent(check.digits, body))
                    Prepared.SMS_OPENED
                } catch (_: android.content.ActivityNotFoundException) {
                    ctx.startActivity(shareIntent(body))
                    Prepared.SHARE_OPENED_NO_SMS
                }
            }
        } catch (_: Exception) {
            Prepared.FAILED
        }
    }

    /** Texto neutro para a tela (sem afirmar que foi enviado). */
    fun preparedMessage(r: Prepared): String = when (r) {
        Prepared.WHATSAPP_OPENED -> "Mensagem preparada no WhatsApp. Toque em enviar lá para concluir: o Gluco Cris não envia sozinho e não sabe se você enviou."
        Prepared.SMS_OPENED -> "Mensagem preparada no app de SMS. Toque em enviar lá para concluir: o Gluco Cris não envia sozinho e não sabe se você enviou."
        Prepared.SHARE_OPENED_NO_WHATSAPP -> "WhatsApp não encontrado neste aparelho. Abri o compartilhamento do Android para você escolher outro app."
        Prepared.SHARE_OPENED_NO_SMS -> "Não encontrei app de SMS. Abri o compartilhamento do Android para você escolher outro app."
        Prepared.NO_RECIPIENT -> "Cadastre um telefone válido do cuidador (com código do país) antes de enviar."
        Prepared.EMPTY_MESSAGE -> "Não há mensagem para enviar."
        Prepared.FAILED -> "Não consegui abrir um app para enviar a mensagem. Tente o botão de compartilhar."
    }

    fun alertText(person: String, mg: Double, at: Long, low: Boolean): String =
        "Aviso do Gluco Cris: a glicemia de $person está ${if (low) "MUITO BAIXA" else "MUITO ALTA"} (${mg.roundToInt()} mg/dL, em ${formatDateTime(at)}). " +
            "Por favor, entre em contato e ajude a seguir o plano indicado pela equipe de saúde. Em emergência, ligue 192 (SAMU)."

    fun dailySummaryText(ctx: Context, data: AppData, now: Long = System.currentTimeMillis()): String {
        val s = data.settings
        val dayStart = java.util.Calendar.getInstance().apply {
            timeInMillis = now
            set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis
        val today = Insights.readingsBetween(data, dayStart, now)
        val st = Insights.stats(today, s.targetLow, s.targetHigh)
        val last = today.lastOrNull()
        val meals = data.meals.count { !it.id.startsWith("demo-") && it.at >= dayStart }
        val sb = StringBuilder("Resumo do dia de ${s.displayName} (Gluco Cris):\n")
        if (st == null) sb.append("• Nenhuma glicemia registrada hoje.\n")
        else {
            sb.append("• ${st.count} medições, média ${st.mean.roundToInt()} mg/dL (mín ${st.min.roundToInt()}, máx ${st.max.roundToInt()}).\n")
            sb.append("• ${st.inRangePct.roundToInt()}% na meta (${s.targetLow}–${s.targetHigh}).\n")
            last?.let { sb.append("• Última: ${it.mg.roundToInt()} mg/dL às ${formatTime(it.at)}.\n") }
        }
        if (meals > 0) sb.append("• $meals refeição(ões) registrada(s).\n")
        sb.append("Enviado com a permissão de ${s.displayName}.")
        return sb.toString()
    }

    /**
     * Chamado a cada nova glicemia (digitada, atalho ou sensor). Se passar do limite grave, mostra uma notificação
     * que abre a mensagem pronta para o contato. Cada leitura grave avisa uma vez e há um intervalo mínimo de 30 min.
     */
    fun onNewGlucose(ctx: Context, mg: Double, at: Long, person: String = "") {
        val app = ctx.applicationContext
        if (!consent(app) || !alertsOn(app) || phone(app).isBlank()) return
        val now = System.currentTimeMillis()
        if (now - at > 20 * 60_000L) return // leitura antiga (importação): não avisa
        // Limites lidos a cada leitura: o que foi salvo nos ajustes vale imediatamente.
        val kind = CaregiverRules.kindOf(mg, severeLow(app), severeHigh(app)) ?: return
        val low = kind == CaregiverRules.Kind.LOW
        val state = sp(app)
        val key = if (low) "last_alert_low_at" else "last_alert_high_at"
        // Baixa e alta têm intervalos independentes; leituras seguidas dentro do intervalo não geram novo aviso.
        if (!CaregiverRules.repeatAllowed(now, state.getLong(key, 0L), repeatMin(app))) return
        state.edit().putLong(key, now).apply()
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(app, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) return
        try {
            ensureChannel(app)
            val open = PendingIntent.getActivity(
                app, NOTIF_ID + 1,
                Intent(app, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP },
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
            )
            val what = if (low) "muito baixa" else "muito alta"
            val b = NotificationCompat.Builder(app, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_drop)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .setColor(0xFFDC2626.toInt())
                .setAutoCancel(true)
            if (!phoneValid(app)) {
                // Contato sem número válido: avisa a pessoa em vez de falhar em silêncio.
                val t = "Glicemia $what: ${mg.roundToInt()} mg/dL. O telefone do cuidador está incompleto: toque para corrigir."
                b.setContentTitle("Corrigir telefone do cuidador").setContentText(t)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(t)).setContentIntent(open)
            } else {
                val who = person.ifBlank { "quem usa o app" }
                val body = alertText(who, mg, at, low)
                val send = PendingIntent.getActivity(app, NOTIF_ID, sendIntent(app, body), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
                val contact = name(app).ifBlank { "seu contato" }
                val text = "Glicemia $what: ${mg.roundToInt()} mg/dL. Toque para preparar a mensagem para $contact (você confirma o envio)."
                b.setContentTitle("Avisar o cuidador?").setContentText(text)
                    .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                    .setContentIntent(send)
                    .addAction(0, "Avisar $contact", send)
                    .addAction(0, "Abrir app", open)
            }
            NotificationManagerCompat.from(app).notify(NOTIF_ID, b.build())
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }
}
