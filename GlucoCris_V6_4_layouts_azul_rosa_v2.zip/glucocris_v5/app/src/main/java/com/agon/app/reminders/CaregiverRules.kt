package com.agon.app.reminders

/**
 * Regras puras (sem Android) do aviso ao cuidador: limites, telefone e frequência de repetição.
 * Ficam separadas para serem testadas em JVM.
 */
object CaregiverRules {
    const val LOW_MIN = 30
    const val LOW_MAX = 100
    const val HIGH_MIN = 150
    const val HIGH_MAX = 600

    val LOW_DEFAULTS = listOf(45, 54, 60, 70)
    val HIGH_DEFAULTS = listOf(250, 300, 350, 400)

    const val DEFAULT_LOW = 54
    const val DEFAULT_HIGH = 300

    /** Intervalos de repetição oferecidos (minutos). 30 = comportamento anterior. */
    val REPEAT_OPTIONS = listOf(15, 30, 60, 120)
    const val DEFAULT_REPEAT_MIN = 30

    /** Só dígitos, até 3 (limites são inteiros). Retorna null se vazio ou inválido. */
    fun parseLimit(text: String): Int? {
        val t = text.trim()
        if (t.isEmpty() || t.length > 3 || !t.all { it.isDigit() }) return null
        return t.toIntOrNull()
    }

    /**
     * Valida o limite BAIXO personalizado (mg/dL).
     * @param targetLow meta mínima do app: o limite grave não pode ficar acima dela.
     * @param severeHigh limite alto atual: o baixo precisa ser menor.
     */
    fun validateLow(text: String, targetLow: Int, severeHigh: Int): String? {
        val v = parseLimit(text) ?: return "Digite apenas números inteiros, por exemplo 50."
        if (v < LOW_MIN || v > LOW_MAX) return "O limite baixo deve ficar entre $LOW_MIN e $LOW_MAX mg/dL."
        if (v > targetLow) return "O limite de glicemia muito baixa não pode ser maior que a sua meta mínima ($targetLow mg/dL)."
        if (v >= severeHigh) return "O limite baixo precisa ser menor que o limite alto ($severeHigh mg/dL)."
        return null
    }

    fun validateHigh(text: String, targetHigh: Int, severeLow: Int): String? {
        val v = parseLimit(text) ?: return "Digite apenas números inteiros, por exemplo 280."
        if (v < HIGH_MIN || v > HIGH_MAX) return "O limite alto deve ficar entre $HIGH_MIN e $HIGH_MAX mg/dL."
        if (v < targetHigh) return "O limite de glicemia muito alta não pode ser menor que a sua meta máxima ($targetHigh mg/dL)."
        if (v <= severeLow) return "O limite alto precisa ser maior que o limite baixo ($severeLow mg/dL)."
        return null
    }

    enum class Kind { LOW, HIGH }

    /** Qual limite foi ultrapassado (ou nenhum). Comparações estritas: igual ao limite não alerta (comportamento original). */
    fun kindOf(mg: Double, severeLow: Int, severeHigh: Int): Kind? = when {
        mg < severeLow -> Kind.LOW
        mg > severeHigh -> Kind.HIGH
        else -> null
    }

    /**
     * true se já passou o intervalo de repetição desde o último aviso DO MESMO TIPO.
     * Baixa e alta são independentes: uma alta logo depois de uma baixa não fica bloqueada.
     */
    fun repeatAllowed(now: Long, lastAlertAt: Long, repeatMin: Int): Boolean =
        lastAlertAt <= 0L || now - lastAlertAt >= repeatMin * 60_000L || now < lastAlertAt

    // ── Telefone ─────────────────────────────────────────────────────────

    data class PhoneCheck(val digits: String, val error: String?) {
        val ok: Boolean get() = error == null
    }

    /**
     * Valida um telefone internacional (E.164, só dígitos, SEM o "+"). Exige código do país.
     * Brasil (55): DDD 11–99 + 8 dígitos (fixo) ou 9 + 8 dígitos (celular).
     * Número brasileiro digitado sem 55 (ex.: 11999998888) é recusado com orientação, em vez de adivinhar.
     */
    fun checkPhone(raw: String): PhoneCheck {
        var d = raw.filter { it.isDigit() }
        if (d.isEmpty()) return PhoneCheck("", "Informe o telefone do cuidador.")
        if (d.startsWith("00")) d = d.removePrefix("00")
        if (d.length < 10) return PhoneCheck(d, "Número curto demais. Inclua código do país e DDD (Brasil: 55 + DDD + número).")
        if (d.length > 15) return PhoneCheck(d, "Número longo demais (máximo de 15 dígitos com o código do país).")
        if (looksLikeBrazilLocal(d)) {
            return PhoneCheck(d, "Inclua o código do país antes do DDD. Para o Brasil, comece com 55 (ex.: 55$d).")
        }
        if (d.startsWith("55")) {
            val national = d.substring(2)
            if (national.length != 10 && national.length != 11) return PhoneCheck(d, "Número do Brasil inválido: use 55 + DDD (2 dígitos) + número (8 ou 9 dígitos).")
            val ddd = national.substring(0, 2).toInt()
            if (ddd < 11 || ddd > 99) return PhoneCheck(d, "DDD inválido.")
            if (national.length == 11 && national[2] != '9') return PhoneCheck(d, "Celular do Brasil com 9 dígitos deve começar com 9 depois do DDD.")
        }
        return PhoneCheck(d, null)
    }

    /** 10–11 dígitos que parecem DDD + número brasileiro, sem o 55 na frente. */
    private fun looksLikeBrazilLocal(d: String): Boolean {
        if (d.startsWith("55")) return false
        if (d.length != 10 && d.length != 11) return false
        val ddd = d.substring(0, 2).toIntOrNull() ?: return false
        if (ddd < 11 || ddd > 99) return false
        return if (d.length == 11) d[2] == '9' else d[2] in '2'..'5'
    }

    /** Formata para exibição: +55 11 99999-8888 (cai para +dígitos se não for do Brasil). */
    fun display(digits: String): String {
        if (digits.startsWith("55") && (digits.length == 12 || digits.length == 13)) {
            val n = digits.substring(2)
            val ddd = n.substring(0, 2)
            val rest = n.substring(2)
            val cut = rest.length - 4
            return "+55 $ddd ${rest.substring(0, cut)}-${rest.substring(cut)}"
        }
        return "+$digits"
    }
}
