package com.agon.app.reminders

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.agon.app.MainActivity
import com.agon.app.R
import com.agon.app.insights.Hba1cGoal
import com.agon.app.insights.Hba1cReminderPlan
import java.util.concurrent.TimeUnit

/**
 * Preferências da área HbA1c (só neste aparelho): meta de referência e lembrete de novo exame.
 * Nada aqui impõe intervalo médico: a pessoa escolhe o intervalo ou a data.
 */
object Hba1cPrefs {
    private const val PREFS = "gluco_hba1c_v1"
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun goal(ctx: Context): Double = Double.fromBits(sp(ctx).getLong("goal_bits", Hba1cGoal.DEFAULT_GOAL.toRawBits()))
        .let { if (it.isNaN() || it < Hba1cGoal.MIN_GOAL || it > Hba1cGoal.MAX_GOAL) Hba1cGoal.DEFAULT_GOAL else it }

    fun setGoal(ctx: Context, v: Double) = sp(ctx).edit().putLong("goal_bits", v.toRawBits()).apply()

    fun reminderOn(ctx: Context) = sp(ctx).getBoolean("rem_on", false)
    fun setReminderOn(ctx: Context, v: Boolean) = sp(ctx).edit().putBoolean("rem_on", v).apply()

    /** "interval" (a cada N meses desde o último exame) ou "date" (data escolhida). */
    fun mode(ctx: Context) = sp(ctx).getString("rem_mode", Hba1cReminderPlan.MODE_INTERVAL) ?: Hba1cReminderPlan.MODE_INTERVAL
    fun setMode(ctx: Context, v: String) = sp(ctx).edit().putString("rem_mode", v).apply()

    fun months(ctx: Context) = sp(ctx).getInt("rem_months", 3).coerceIn(1, 24)
    fun setMonths(ctx: Context, v: Int) = sp(ctx).edit().putInt("rem_months", v.coerceIn(1, 24)).apply()

    fun fixedDate(ctx: Context) = sp(ctx).getLong("rem_date", 0L)
    fun setFixedDate(ctx: Context, v: Long) = sp(ctx).edit().putLong("rem_date", v).apply()
}

object Hba1cReminders {
    private const val WORK = "gluco_hba1c_reminder"
    const val CHANNEL = "gluco_hba1c_v1"
    private const val NOTIF_ID = 7741

    /**
     * (Re)agenda o próximo lembrete conforme as preferências. Chame ao ligar/desligar, ao mudar a programação
     * e ao salvar/excluir um exame. Se estiver desligado, cancela. Usa WorkManager (sobrevive a reinício).
     * O horário é aproximado: o Android pode atrasar tarefas em segundo plano (economia de bateria).
     */
    fun reschedule(ctx: Context, lastExamAt: Long?, now: Long = System.currentTimeMillis()) {
        val app = ctx.applicationContext
        try {
            val wm = WorkManager.getInstance(app)
            if (!Hba1cPrefs.reminderOn(app)) {
                wm.cancelUniqueWork(WORK)
                return
            }
            val at = Hba1cReminderPlan.nextTrigger(
                Hba1cPrefs.mode(app), Hba1cPrefs.months(app), Hba1cPrefs.fixedDate(app), lastExamAt, now,
            )
            if (at == null) {
                wm.cancelUniqueWork(WORK)
                return
            }
            val req = OneTimeWorkRequestBuilder<Hba1cReminderWorker>()
                .setInitialDelay((at - now).coerceAtLeast(0L), TimeUnit.MILLISECONDS)
                .build()
            wm.enqueueUniqueWork(WORK, ExistingWorkPolicy.REPLACE, req)
        } catch (_: Exception) {
        }
    }

    private fun ensureChannel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch = NotificationChannel(CHANNEL, "Lembrete de exame de HbA1c", NotificationManager.IMPORTANCE_DEFAULT)
        ch.description = "Aviso, na data que você escolheu, para fazer um novo exame de hemoglobina glicada."
        nm.createNotificationChannel(ch)
    }

    fun notifyNow(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) return
        try {
            ensureChannel(ctx)
            val open = Intent(ctx, MainActivity::class.java).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP }
            val text = "Chegou a data que você escolheu para lembrar do exame de hemoglobina glicada (HbA1c). Quando tiver o resultado, registre no app."
            val n = NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_drop)
                .setContentTitle("Lembrete: exame de HbA1c")
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setCategory(NotificationCompat.CATEGORY_REMINDER)
                .setColor(0xFF6D28D9.toInt())
                .setAutoCancel(true)
                .setContentIntent(PendingIntent.getActivity(ctx, NOTIF_ID, open, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT))
                .build()
            NotificationManagerCompat.from(ctx).notify(NOTIF_ID, n)
        } catch (_: SecurityException) {
        } catch (_: Exception) {
        }
    }
}

class Hba1cReminderWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext
        return try {
            if (!Hba1cPrefs.reminderOn(app)) return Result.success()
            Hba1cReminders.notifyNow(app)
            if (Hba1cPrefs.mode(app) == Hba1cReminderPlan.MODE_DATE) {
                // Aviso por data é único: depois de avisar, o lembrete se desliga.
                Hba1cPrefs.setReminderOn(app, false)
            } else {
                // Modo intervalo: se nenhum exame novo for registrado, avisa de novo depois de mais um intervalo,
                // contado a partir de agora. Ao salvar um exame, a UI reagenda a partir da data da coleta.
                Hba1cReminders.reschedule(app, lastExamAt = System.currentTimeMillis())
            }
            Result.success()
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (_: Exception) {
            Result.success()
        }
    }
}
