package com.agon.app.ui.screens

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import com.agon.app.Routes
import com.agon.app.data.AppData
import com.agon.app.data.CrisCloud
import com.agon.app.data.CrisGemini
import com.agon.app.data.CrisMemory
import com.agon.app.data.CrisPrefs
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Reminder
import com.agon.app.data.formatClock
import com.agon.app.data.formatDateTime
import com.agon.app.data.toMgDl
import com.agon.app.data.uid
import com.agon.app.localai.CrisConnectivityManager
import com.agon.app.localai.CrisLocalAi
import com.agon.app.localai.CrisSafetyGuard
import com.agon.app.localai.CrisSearchPolicy
import com.agon.app.localai.CrisMath
import com.agon.app.localai.CrisToolRegistry
import com.agon.app.localai.CrisWebSearch
import com.agon.app.localai.SearchIntent
import com.agon.app.localai.WebPrep
import com.agon.app.localai.LocalAiSettings
import com.agon.app.localai.LocalMemoryManager
import com.agon.app.localai.LocalSpeech
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import android.util.Log
import com.agon.app.localai.CloudDeps
import com.agon.app.localai.CloudOutcome
import com.agon.app.localai.CrisCloudOrchestrator
import com.agon.app.localai.CrisFactGuard
import com.agon.app.localai.CrisLocalReview
import com.agon.app.localai.LocalReviewRequest
import com.agon.app.localai.LocalTask
import com.agon.app.localai.Verdict
import com.agon.app.localai.CrisServiceHealth
import com.agon.app.localai.CrisSourceQuality
import com.agon.app.localai.GemResult
import com.agon.app.localai.CrisTypo
import kotlin.math.roundToInt

internal data class CrisTurnResult(
    val reply: String,
    val pending: PendingAction?,
    val memory: CrisMemory,
    val navigateTo: String? = null,
    /** Origem da resposta (ver CrisLocalAi.SRC_*), usada para rotular a conversa. */
    val source: String = "",
    /** Foto e fontes da resposta (ver CrisWebSearch.mediaOf). */
    val media: String = "",
)

/** Remove marcações técnicas para a conversa ficar natural. */
internal fun cleanCrisText(t: String): String = t
    .replace("\\n", "\n")
    .replace(Regex("```[\\s\\S]*?```"), "")
    .replace(Regex("\\*\\*?([^*]+)\\*\\*?"), "$1")
    .replace(Regex("(?m)^\\s*#+\\s*"), "")
    .replace(Regex("\n{3,}"), "\n\n")
    .trim()

/** Resumo curto dos registros, enviado para a IA entender o contexto. */
internal fun buildCrisContext(data: AppData): String {
    val s = data.settings
    val g = data.glucose.sortedByDescending { it.at }
    val i = data.insulin.sortedByDescending { it.at }
    return buildString {
        append("Meta de glicose no app: ${s.targetLow}-${s.targetHigh} mg/dL.\n")
        if (g.isEmpty()) append("Sem glicemias registradas.\n") else {
            append("Últimas glicemias: ")
            append(g.take(6).joinToString("; ") {
                "${toMgDl(it.value, it.unit).roundToInt()} mg/dL (${GLUCOSE_CONTEXT_LABEL[it.context] ?: it.context}, ${formatDateTime(it.at)})"
            })
            append(".\n")
            val week = g.filter { it.at >= System.currentTimeMillis() - 7L * 86_400_000 }
            if (week.isNotEmpty()) {
                val avg = week.map { toMgDl(it.value, it.unit) }.average().roundToInt()
                append("Média dos últimos 7 dias: $avg mg/dL em ${week.size} medições.\n")
            }
        }
        if (i.isNotEmpty()) {
            append("Últimas insulinas: ")
            append(i.take(4).joinToString("; ") { "${it.name} ${it.dose} ${it.unit} (${formatDateTime(it.at)})" })
            append(".\n")
        }
        val r = data.reminders.filter { it.enabled }
        if (r.isNotEmpty()) append("Lembretes ativos: " + r.joinToString("; ") { "${it.title} ${formatClock(it.hour, it.minute)}" } + ".\n")
        if (data.medications.isNotEmpty()) append("Medicamentos cadastrados: " + data.medications.filter { it.active }.joinToString(", ") { it.name } + ".\n")
        
        val ps = data.settings
        if (ps.diabetesType.isNotBlank()) append("Tipo de diabetes (perfil): ${ps.diabetesType}.\n")
        if (ps.insulinBasalName.isNotBlank() || ps.insulinMealName.isNotBlank() || ps.insulinKind.isNotBlank()) {
            append("Insulinas no perfil: ")
            append(listOfNotNull(
                ps.insulinKind.takeIf { it.isNotBlank() },
                ps.insulinBasalName.takeIf { it.isNotBlank() }?.let { "basal=$it" },
                ps.insulinMealName.takeIf { it.isNotBlank() }?.let { "refeição=$it" },
            ).joinToString("; "))
            append(".\n")
        }
        if (ps.allergies.isNotBlank()) append("Alergias do perfil (informadas pelo usuário): ${ps.allergies}.\n")
        if (ps.foodRestrictions.isNotBlank()) append("Restrições alimentares do perfil: ${ps.foodRestrictions}.\n")
        if (ps.profileMedications.isNotEmpty()) {
            append("Medicamentos de uso contínuo (perfil): " + ps.profileMedications.joinToString(", ") { it.name } + ".\n")
        }
        if (ps.heightCm.isNotBlank() || ps.weightKg.isNotBlank()) {
            append("Altura/peso (perfil): ${ps.heightCm.ifBlank { "?" }} cm / ${ps.weightKg.ifBlank { "?" }} kg.\n")
        }

        val meals = data.meals.sortedByDescending { it.at }
        if (meals.isNotEmpty()) {
            val todayStart = java.util.Calendar.getInstance().apply {
                set(java.util.Calendar.HOUR_OF_DAY, 0); set(java.util.Calendar.MINUTE, 0)
                set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
            }.timeInMillis
            val todayMeals = meals.filter { it.at >= todayStart }
            val carbToday = todayMeals.mapNotNull { it.carbs }.sum()
            append("Diário alimentar hoje: ${todayMeals.size} refeição(ões), ~${"%.0f".format(carbToday)} g de carboidrato.\n")
            val lastM = meals.first()
            append("Última refeição: ${lastM.description}" + (lastM.carbs?.let { " (~${it} g carb)" } ?: "") + " (${formatDateTime(lastM.at)}).\n")
        } else append("Sem refeições no diário alimentar.\n")
        val lastGlu = g.firstOrNull()?.let { toMgDl(it.value, it.unit) }
        if (lastGlu != null && lastGlu < 70) {
            append("ATENÇÃO: última glicemia baixa (${lastGlu.roundToInt()} mg/dL). Priorize segurança; não sugira exercício nem redução de alimentação sem cuidado.\n")
        }
    }
}

/**
 * Processa uma fala/mensagem: ações do app são locais e seguras (com confirmação);
 * conversa vai para a IA natural; sem internet, cai na Cris local.
 */
internal suspend fun crisRespond(
    context: Context,
    vm: GlucoViewModel,
    text: String,
    memory: CrisMemory,
    pending: PendingAction?,
    history: List<CrisMsg>,
    voice: Boolean,
    summary: String = "",
    onPartial: ((String) -> Unit)? = null,
): CrisTurnResult {
    val data = vm.data.value
    val low = text.lowercase()
    // Segurança: emergências e autoagressão não passam pela IA generativa
    CrisSafetyGuard.precheck(text)?.let { return CrisTurnResult(it, null, memory, source = CrisLocalAi.SRC_SAFETY) }
    // Atalhos locais rápidos (não passam pela nuvem)
    when {
        listOf("localizador", "achar insulina", "onde achar insulina", "farmácia perto", "farmacia perto").any { it in low } ->
            return CrisTurnResult("Abrindo o localizador de insulina.", null, memory, Routes.LOCATOR)
        listOf("calculadora de bolus", "calcular bolus", "bolus").any { it in low } && "não" !in low ->
            return CrisTurnResult("Abrindo a calculadora de bolus (só com os seus fatores).", null, memory, Routes.FOOD_BOLUS)
        listOf("abrir alimentos", "diário alimentar", "contar carb", "contagem de carb").any { it in low } ->
            return CrisTurnResult("Abrindo a alimentação.", null, memory, Routes.FOOD)
        listOf("registrar glicemia", "abrir glicose", "lançar glicemia").any { it in low } ->
            return CrisTurnResult("Abrindo a glicose pra você registrar.", null, memory, Routes.GLUCOSE)
        listOf("resumo da semana", "como está minha glicose").any { it in low } -> {
            val week = data.glucose.filter { it.at >= System.currentTimeMillis() - 7L * 86_400_000 }
            val msg = if (week.isEmpty()) "Ainda não há glicemias nesta semana no app."
            else {
                val avg = week.map { toMgDl(it.value, it.unit) }.average().roundToInt()
                "Nesta semana: ${week.size} medições, média cerca de $avg mg/dL. Quer que eu abra o relatório?"
            }
            return CrisTurnResult(msg, null, memory)
        }
    }
    // Memória de longo prazo (só por pedido explícito) e ferramentas internas (dados reais do app)
    if (pending == null) {
        LocalMemoryManager.handleCommand(context, text)?.let { return CrisTurnResult(it, null, memory, source = CrisLocalAi.SRC_APP) }
        CrisToolRegistry.tryAnswer(text, data)?.let { return CrisTurnResult(it.text, null, memory, source = CrisLocalAi.SRC_APP) }
        // Contas simples ("quanto é 25 vezes 48?") saem exatas, mesmo sem modelo e sem internet
        CrisMath.tryAnswer(text)?.let { return CrisTurnResult(it, null, memory, source = CrisLocalAi.SRC_CALC) }
    }
    // Autorização de pesquisa pedida na mensagem anterior (consulta com dados pessoais)
    if (pending == null) {
        CrisWebSearch.consumeConsent(text)?.let { original ->
            val un = com.agon.app.data.firstName(data.settings.displayName)
            val web = CrisWebSearch.prepare(context, original, un, consented = true, modelReady = CrisLocalAi.isReady(context))
            val ctxConsent = if (LocalAiSettings.onlineHealthContextAllowed(context)) {
                buildCrisContext(data)
            } else "Dados de saúde do app não foram compartilhados (privacidade).\n"
            val geminiConsent = try {
                if (CrisGemini.isConfigured() && com.agon.app.localai.CrisConnectivityManager.isOnline(context)) {
                    CrisGemini.chatAsCris(
                        context, original,
                        history.takeLast(16).map { it.fromUser to it.text },
                        ctxConsent, un, webContext = web.promptBlock,
                    )
                } else null
            } catch (_: Exception) { null }
            if (!geminiConsent.isNullOrBlank()) {
                val body = CrisSafetyGuard.postcheck(cleanCrisText(geminiConsent))
                val refused = body == CrisSafetyGuard.DOSE_REFUSAL
                val foot = if (refused || web.hits.isEmpty()) "" else CrisWebSearch.footer(web, voice, CrisWebSearch.userAskedSources(original))
                return CrisTurnResult(body + foot, null, memory, source = CrisLocalAi.SRC_ONLINE, media = if (refused) "" else CrisWebSearch.mediaOf(web))
            }
            crisLocalWithWeb(context, original, history, data, memory, un, voice, web, summary, onPartial)?.let { return it }
        }
    }
    val (answer, newPending) = CrisBrain.reply(text, data, memory, pending, localOnly = true)
    return when {
        answer == "CONFIRM_CREATE_REMINDER" && pending is PendingAction.CreateReminder -> {
            vm.saveReminder(
                Reminder(
                    id = uid(), kind = pending.kind, title = pending.title, hour = pending.hour, minute = pending.minute,
                    days = pending.days, enabled = true, soundId = "suave", notes = "Criado com a Cris IA",
                ),
            )
            CrisTurnResult("Prontinho! Salvei o lembrete ${pending.title.lowercase()} às ${formatClock(pending.hour, pending.minute)}. Se quiser mudar, é só ir na aba Lembretes.", null, memory)
        }
        answer == "PAUSE_REMINDER" -> {
            val active = data.reminders.filter { it.enabled }
            active.forEach { vm.toggleReminder(it.id) }
            CrisTurnResult(if (active.isEmpty()) "Você não tem nenhum lembrete ativo agora." else "Pausei ${active.size} lembrete(s). Quando quiser, é só me pedir pra ativar de novo.", null, memory)
        }
        answer == "ENABLE_REMINDER" -> {
            val paused = data.reminders.filter { !it.enabled }
            paused.forEach { vm.toggleReminder(it.id) }
            CrisTurnResult(if (paused.isEmpty()) "Todos os seus lembretes já estão ligados." else "Reativei ${paused.size} lembrete(s) pra você.", null, memory)
        }
        answer == "NAV_GLUCOSE" -> CrisTurnResult("Abrindo a glicose pra você.", null, memory, Routes.GLUCOSE)
        answer == "NAV_INSULIN" -> CrisTurnResult("Abrindo a insulina.", null, memory, Routes.INSULIN)
        answer == "NAV_REMINDERS" -> CrisTurnResult("Abrindo seus lembretes.", null, memory, Routes.REMINDERS)
        answer == "NAV_LOCATOR" -> CrisTurnResult("Claro! Abrindo o localizador pra achar insulina perto de você.", null, memory, Routes.LOCATOR)
        answer == "NAV_FOOD" -> CrisTurnResult("Abrindo a alimentação.", null, memory, Routes.FOOD)
        answer == "NAV_BOLUS" -> CrisTurnResult("Abrindo a calculadora de bolus.", null, memory, Routes.FOOD_BOLUS)
        answer == "NAV_REPORT" -> CrisTurnResult("Abrindo o relatório.", null, memory, Routes.REPORT)
        answer == "PREF_SHORT_ON" -> {
            val m = memory.copy(shortAnswers = true); CrisPrefs.saveMemory(context, m)
            CrisTurnResult("Combinado, vou ser mais direta.", null, m)
        }
        answer == "PREF_SHORT_OFF" -> {
            val m = memory.copy(shortAnswers = false); CrisPrefs.saveMemory(context, m)
            CrisTurnResult("Tá bom, explico com mais calma quando precisar.", null, m)
        }
        answer == "PREF_CLEAR" -> {
            val m = CrisMemory(speakReplies = memory.speakReplies); CrisPrefs.saveMemory(context, m)
            CrisTurnResult("Pronto, apaguei suas preferências deste aparelho.", null, m)
        }
        answer.startsWith("PREF_NOTE:") -> {
            val note = answer.removePrefix("PREF_NOTE:")
            val m = memory.copy(noteToSelf = note, memoryEnabled = true); CrisPrefs.saveMemory(context, m)
            CrisTurnResult("Anotado! Vou lembrar que $note.", null, m)
        }
        answer == CrisBrain.CLOUD -> crisCloudTurn(context, data, text, memory, pending, history, voice, summary, onPartial)
        else -> CrisTurnResult(cleanCrisText(answer), newPending, memory)
    }
}

/** Fontes (nome, link https) da pesquisa independente e do Google do Gemini, sem repetir. */
private fun collectSources(web: WebPrep?, gem: GemResult?): List<Pair<String, String>> {
    val out = ArrayList<Pair<String, String>>()
    web?.hits?.forEach { if (it.url.startsWith("https://")) out += it.source to it.url }
    gem?.sources?.forEach { if (it.second.startsWith("https://")) out += it }
    return out.distinctBy { CrisSourceQuality.normalizeUrl(it.second) }.take(3)
}

private fun sourcesFooter(sources: List<Pair<String, String>>): String =
    if (sources.isEmpty()) "" else "\n\n🌐 Fontes consultadas: " + sources.joinToString(" · ") { it.first.take(30) }

private fun sourcesMedia(sources: List<Pair<String, String>>): String =
    sources.joinToString("\n") { "SRC\t" + it.first.replace('\t', ' ').replace('\n', ' ').take(30) + "\t" + it.second }

/** Lista curta de resultados reais, claramente rotulada como pesquisa (não é resposta elaborada por IA). */
private fun resultsList(web: WebPrep): String =
    web.hits.take(3).joinToString("\n") { h ->
        "• ${h.title.take(110)} (${h.source}${if (h.date.isNotBlank()) ", ${h.date}" else ""})" +
            (if (h.snippet.isNotBlank()) "\n  ${h.snippet.take(180)}" else "")
    }

/**
 * Conversa geral (online). Gemini e pesquisa independente rodam de forma CONCORRENTE (ver CrisCloudOrchestrator):
 * a 1ª geração do Gemini começa sem esperar o Tavily; a 2ª chamada (síntese com os resultados) só acontece se agregar valor
 * e se a cota permitir. Dados pessoais/de saúde nunca vão para a pesquisa; a pergunta atual é a única enviada ao Tavily.
 */
private suspend fun crisCloudTurn(
    context: Context,
    data: AppData,
    text: String,
    memory: CrisMemory,
    pending: PendingAction?,
    history: List<CrisMsg>,
    voice: Boolean,
    summary: String,
    onPartial: ((String) -> Unit)?,
): CrisTurnResult {
    val userName = com.agon.app.data.firstName(data.settings.displayName)
    val online = CrisConnectivityManager.isOnline(context)
    val geminiOn = CrisGemini.isConfigured() && online
    val localReady = CrisLocalAi.isReady(context)
    // Pergunta com dado pessoal (glicemia, dose, nome...) vai sem pesquisa nenhuma
    val canSearch = LocalAiSettings.webSearchEnabled(context) && !CrisSearchPolicy.hasPersonalData(text, userName)
    // PRIVACIDADE: o resumo de saúde só vai se a usuária autorizou E a pergunta precisa dele; nesse caso a ferramenta de
    // pesquisa do Google do Gemini fica DESLIGADA no mesmo pedido (o Gemini escolhe sozinho o que pesquisar, então contexto
    // de saúde e consulta ao Google nunca viajam juntos). A pesquisa independente segue com a pergunta já neutralizada.
    val lastUserText = history.lastOrNull { it.fromUser }?.text.orEmpty()
    val sendHealth = LocalAiSettings.onlineHealthContextAllowed(context) && CrisSearchPolicy.needsPersonalContext(text, lastUserText)
    val geminiSearch = canSearch && !sendHealth
    val ctx = if (sendHealth) {
        buildCrisContext(data) + if (memory.noteToSelf.isNotBlank()) "Preferência da pessoa: ${memory.noteToSelf}\n" else ""
    } else "Dados de saúde do app não foram compartilhados nesta pergunta (privacidade). Responda de forma geral e não invente registros.\n"
    val fixed = CrisSearchPolicy.assumeBrazil(CrisTypo.fix(text), userName)
    // Só pesquisa quando há necessidade real de informação externa (não em toda mensagem)
    val needsWeb = canSearch && online && CrisSearchPolicy.classify(fixed) != SearchIntent.NONE
    // Com a pesquisa do Google ligada no pedido, o histórico enviado não leva dados pessoais (viram um marcador)
    val fullHistory = history.takeLast(16).map { it.fromUser to it.text }.let { if (geminiSearch) CrisSearchPolicy.scrubHistory(it, userName) else it }
    val shortHistory = history.takeLast(4).map { it.fromUser to it.text }   // síntese: só o contexto mais recente
    val shortHistoryGemini = if (geminiSearch) CrisSearchPolicy.scrubHistory(shortHistory, userName) else shortHistory

    // IA local colaboradora (opcional, UMA chamada, só quando o plano indica valor): traduz, resume, destaca contradições e
    // melhora a clareza. Número, data ou dose fora das fontes derruba o texto local (CrisFactGuard).
    val localFn: suspend (LocalReviewRequest) -> String? = { req ->
        val extra = req.web.promptBlock + CrisLocalReview.instruction(req.plan, req.geminiAnswer)
        val out = CrisLocalAi.chat(context, text, shortHistory, data, memory, userName, extraBlock = extra, summary = summary)
        out?.takeIf { CrisLocalReview.isSafe(it, req.web, req.geminiAnswer, text) }
    }

    val deps = CloudDeps(
        gemini = { webCtx ->
            val synth = webCtx.isNotBlank()
            // O erro vem DESTA chamada (GeminiReply), não do estado global: perguntas simultâneas não trocam de erro.
            val reply = try {
                CrisGemini.chatAsCrisReply(context, text, if (synth) shortHistoryGemini else fullHistory, ctx, userName, webContext = webCtx, allowSearch = geminiSearch)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CrisGemini.GeminiReply(null, "erro inesperado na IA online")
            }
            val g = reply.chat
            if (g == null || g.text.isBlank()) GemResult(null, error = reply.error)
            else GemResult(g.text, g.searched, g.sources)
        },
        search = { CrisWebSearch.prepare(context, text, userName, modelReady = true) },
        canSynthesize = { CrisGemini.remainingToday(context) >= 10 },
        localReview = if (localReady) localFn else null,
    )

    val outcome = CrisCloudOrchestrator.run(deps, needsWeb, geminiOn)

    when (outcome) {
        is CloudOutcome.GeminiAnswer -> {
            val body = CrisSafetyGuard.postcheck(cleanCrisText(outcome.gem.text.orEmpty()))
            val refused = body == CrisSafetyGuard.DOSE_REFUSAL
            val sources = if (refused) emptyList() else collectSources(outcome.web, outcome.gem)
            val searched = outcome.gem.searched || (outcome.web?.hits?.isNotEmpty() == true)
            val show = sources.isNotEmpty() && (searched || CrisWebSearch.userAskedSources(text))
            // Pergunta pedia dado atual e nada foi confirmado na internet: não finge verificação
            val note = if (outcome.unverified && !refused) "\n\nℹ️ Não consegui confirmar isso na internet agora, então esta resposta pode estar desatualizada." else ""
            return CrisTurnResult(body + note + (if (show) sourcesFooter(sources) else ""), null, memory, source = CrisLocalAi.SRC_ONLINE, media = if (show) sourcesMedia(sources) else "")
        }
        is CloudOutcome.Synthesized -> {
            val body = CrisSafetyGuard.postcheck(cleanCrisText(outcome.gem.text.orEmpty()))
            val refused = body == CrisSafetyGuard.DOSE_REFUSAL
            val sources = if (refused) emptyList() else collectSources(outcome.web, outcome.gem)
            return CrisTurnResult(body + sourcesFooter(sources), null, memory, source = CrisLocalAi.SRC_ONLINE, media = sourcesMedia(sources))
        }
        is CloudOutcome.AnswerPlusResults -> {
            val body = CrisSafetyGuard.postcheck(cleanCrisText(outcome.gem.text.orEmpty()))
            val refused = body == CrisSafetyGuard.DOSE_REFUSAL
            if (refused) return CrisTurnResult(body, null, memory, source = CrisLocalAi.SRC_ONLINE)
            val sources = collectSources(outcome.web, outcome.gem)
            val extra = buildString {
                // Tudo aqui é SUSPEITA calculada no aparelho: nunca se afirma que a resposta está errada.
                when (outcome.assessment.verdict) {
                    Verdict.CONFLICT -> append("\n\n⚠️ Possível divergência: os valores ou datas da resposta acima parecem diferentes dos das fontes pesquisadas. Não consegui confirmar qual está certo; confira nas fontes.")
                    Verdict.WEAK, Verdict.NO_ANSWER -> append("\n\nℹ️ Não consegui confirmar esta resposta nas fontes pesquisadas. Confira nelas antes de confiar.")
                    else -> Unit
                }
                if (LocalTask.CONTRADICTIONS in outcome.localTasks && outcome.localSummary != null) {
                    append("\n\nO que a IA no aparelho observou nas fontes (pode conter imprecisões): ")
                } else {
                    append("\n\n")
                }
                val label = if (LocalTask.TRANSLATE in outcome.localTasks) "Resumo da pesquisa, traduzido (IA no aparelho): " else "Resumo da pesquisa (IA no aparelho): "
                if (outcome.localSummary != null) {
                    if (LocalTask.CONTRADICTIONS !in outcome.localTasks) append(label)
                    append(cleanCrisText(outcome.localSummary))
                } else {
                    append("Resultados da pesquisa (ainda não conferidos por uma IA):\n").append(resultsList(outcome.web))
                }
            }
            return CrisTurnResult(body + extra + sourcesFooter(sources), null, memory, source = CrisLocalAi.SRC_ONLINE, media = sourcesMedia(sources))
        }
        is CloudOutcome.SearchOnly -> {
            // Sem avisos de "IA online não respondeu": mostra só a resposta.
            val geminiNote = ""
            crisLocalWithWeb(context, text, history, data, memory, userName, voice, outcome.web, summary, onPartial, geminiDown = geminiOn)?.let {
                return if (geminiNote.isNotEmpty()) it.copy(reply = it.reply + geminiNote) else it
            }
        }
        is CloudOutcome.NothingOnline -> Unit
    }

    // Sem Gemini e sem resultados de pesquisa: IA local (informando a limitação para fatos atuais), servidor Cris, respostas básicas
    val nothing = outcome as? CloudOutcome.NothingOnline
    val geminiNote = ""
    // Reaproveita o que a pesquisa já devolveu (sem chamada duplicada); só pesquisa agora se nenhuma foi tentada
    val webFinal = nothing?.web ?: CrisWebSearch.prepare(context, text, userName, modelReady = localReady && !geminiOn)
    webFinal.askConsent?.let { return CrisTurnResult(it, null, memory, source = CrisLocalAi.SRC_APP) }
    crisLocalWithWeb(context, text, history, data, memory, userName, voice, webFinal, summary, onPartial, geminiDown = geminiOn)?.let {
        return if (geminiNote.isNotEmpty()) it.copy(reply = it.reply + geminiNote) else it
    }
    val cloud = CrisCloud.chat(
        text,
        history.takeLast(16).map { CrisCloud.Turn(it.fromUser, it.text) },
        ctx,
        voice,
        userName,
    )
    if (cloud != null) {
        return CrisTurnResult(CrisSafetyGuard.postcheck(cleanCrisText(cloud)), null, memory, source = CrisLocalAi.SRC_ONLINE)
    }
    val (fb, p2) = CrisBrain.reply(text, data, memory, pending, localOnly = false)
    val honest = if (fb.startsWith("Estou sem internet agora")) {
        CrisServiceHealth.allDownMessage(online, com.agon.app.localai.LocalModelManager.get(context).isInstalled(), nothing?.geminiError.orEmpty())
    } else fb
    return CrisTurnResult(cleanCrisText(honest), p2, memory, source = CrisLocalAi.SRC_BASIC)
}

/** IA local responde; se houve pesquisa, os fatos entram no prompt e as fontes reais são anexadas. */
private suspend fun crisLocalWithWeb(
    context: Context,
    text: String,
    history: List<CrisMsg>,
    data: AppData,
    memory: CrisMemory,
    userName: String,
    voice: Boolean,
    web: WebPrep,
    summary: String = "",
    onPartial: ((String) -> Unit)? = null,
    geminiDown: Boolean = false,
): CrisTurnResult? {
    // Com o Gemini fora do ar e pesquisa disponível, as fontes sempre aparecem (a pessoa precisa conferir)
    val showSources = CrisWebSearch.userAskedSources(text) || (geminiDown && web.hits.isNotEmpty())
    // Fatos atuais: prioriza resposta direta das fontes (Wikidata/Wikipédia) — evita alucinação
    if (web.intent == SearchIntent.CURRENT && web.hits.isNotEmpty()) {
        val direct = CrisWebSearch.composeDirectFact(web, voice, showSources)
        if (direct != null) {
            return CrisTurnResult(direct, null, memory, source = CrisLocalAi.SRC_LOCAL_WEB, media = CrisWebSearch.mediaOf(web))
        }
    }
    // Também para GENERAL com fato de cargo bem pontuado (score alto = Wikidata)
    if (web.intent == SearchIntent.GENERAL && web.hits.any { it.score >= 100 }) {
        val direct = CrisWebSearch.composeDirectFact(web, voice, showSources)
        if (direct != null) {
            return CrisTurnResult(direct, null, memory, source = CrisLocalAi.SRC_LOCAL_WEB, media = CrisWebSearch.mediaOf(web))
        }
    }
    // ONLINE PRIMEIRO: com internet e pesquisa com resultado, a resposta sai das fontes consultadas e o modelo local nem é chamado
    // (evita espera e o aviso de falha do modelo). O modelo local fica para quando estiver sem internet ou sem resultado da pesquisa.
    // Exceção: Gemini caiu e a IA local está instalada, então ela organiza/resume os resultados da pesquisa.
    if (web.hits.isNotEmpty() && com.agon.app.localai.CrisConnectivityManager.isOnline(context) && !(geminiDown && CrisLocalAi.isReady(context))) {
        val online = CrisSafetyGuard.postcheck(CrisWebSearch.composeWithoutModel(web, voice, CrisLocalAi.isReady(context), showSources, onlineFirst = !geminiDown, searchOnlyNotice = geminiDown))
        val refused = online == CrisSafetyGuard.DOSE_REFUSAL
        return CrisTurnResult(online, null, memory, source = CrisLocalAi.SRC_ONLINE, media = if (refused) "" else CrisWebSearch.mediaOf(web))
    }
    val partialCb: (String) -> Unit = { p: String ->
        onPartial?.invoke(CrisSafetyGuard.postcheck(cleanCrisText(p)))
    }
    // Com resultados de pesquisa, a IA local também traduz/resume/aponta contradições conforme o plano (uma única chamada)
    val plan = CrisLocalReview.plan(web, null, null)
    val local = CrisLocalAi.chat(
        context, text, history.takeLast(8).map { it.fromUser to it.text }, data, memory, userName,
        extraBlock = web.promptBlock + CrisLocalReview.instruction(plan, null), summary = summary, onPartial = partialCb,
    )
    // A IA local não pode inventar números/datas/doses ao resumir pesquisa: se aparecer algum que não está nas fontes, descarta
    val localSafe = local?.takeIf { web.hits.isEmpty() || CrisFactGuard.verify(it, listOf(web.promptBlock), text).ok }
    if (!localSafe.isNullOrBlank()) {
        val body = CrisSafetyGuard.postcheck(cleanCrisText(localSafe))
        val refused = body == CrisSafetyGuard.DOSE_REFUSAL
        val foot = if (refused) "" else CrisWebSearch.footer(web, voice, showSources)
        val note = if (web.limitation.isNotBlank()) "\n\nℹ️ ${web.limitation}" else ""
        val src = if (web.hits.isNotEmpty() && !refused) CrisLocalAi.SRC_LOCAL_WEB else CrisLocalAi.SRC_LOCAL
        return CrisTurnResult(body + foot + note, null, memory, source = src, media = if (refused) "" else CrisWebSearch.mediaOf(web))
    }
    if (web.hits.isNotEmpty()) return CrisTurnResult(CrisWebSearch.composeWithoutModel(web, voice, CrisLocalAi.isReady(context), showSources, searchOnlyNotice = geminiDown), null, memory, source = CrisLocalAi.SRC_ONLINE, media = CrisWebSearch.mediaOf(web))
    return null
}

internal fun Context.findActivity(): Activity? {
    var c: Context? = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}

/** Reconhecimento de voz em pt-BR com nível do microfone em tempo real. */
internal class CrisListener(
    private val context: Context,
    private val onLevel: (Float) -> Unit,
    private val onPartial: (String) -> Unit,
    private val onResult: (String) -> Unit,
    private val onFail: (String) -> Unit,
) {
    private var recognizer: SpeechRecognizer? = null

    /** Tenta primeiro o reconhecedor no aparelho (offline, Android 13+); se o pacote pt-BR faltar, cai no padrão. */
    fun start() = startInternal(preferOnDevice = true)

    private fun startInternal(preferOnDevice: Boolean) {
        stop()
        val onDevice = if (preferOnDevice) LocalSpeech.createOnDevice(context) else null
        if (onDevice == null && !SpeechRecognizer.isRecognitionAvailable(context)) {
            onFail("O reconhecimento de voz não está disponível neste aparelho.")
            return
        }
        val usingOnDevice = onDevice != null
        val r = onDevice ?: SpeechRecognizer.createSpeechRecognizer(context)
        recognizer = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { onLevel(0f) }
            override fun onError(error: Int) {
                onLevel(0f)
                if (usingOnDevice && LocalSpeech.isLanguageError(error)) {
                    // Pacote de voz pt-BR offline não instalado: tenta o reconhecedor padrão do sistema
                    startInternal(preferOnDevice = false)
                    return
                }
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Não te ouvi. Toque na esfera e fale de novo."
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Preciso da permissão do microfone."
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
                        if (CrisConnectivityManager.isOnline(context)) "Não consegui entender a voz agora. Tente de novo."
                        else "Sem internet e sem pacote de voz offline em português. Instale o pacote de pt-BR em Configurações > Idioma > Voz do Android, ou digite."
                    else -> "Não consegui ouvir. Toque e tente de novo."
                }
                stop()
                onFail(msg)
            }
            override fun onResults(results: Bundle?) {
                val said = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                stop()
                if (said.isNotBlank()) onResult(said) else onFail("Não te ouvi. Toque e fale de novo.")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val p = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (p.isNotBlank()) onPartial(p)
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500L)
        }
        r.startListening(intent)
    }

    fun stop() {
        val r = recognizer ?: return
        recognizer = null
        try { r.cancel() } catch (_: Exception) {}
        try { r.destroy() } catch (_: Exception) {}
    }
}
