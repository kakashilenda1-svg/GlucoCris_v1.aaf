package com.agon.app.ui.screens

import android.app.DatePickerDialog
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Hba1cEntry
import com.agon.app.data.formatDate
import com.agon.app.insights.DataOrigin
import com.agon.app.insights.Hba1cCompare
import com.agon.app.insights.Hba1cDirection
import com.agon.app.insights.Hba1cGoal
import com.agon.app.insights.Hba1cHistory
import com.agon.app.insights.Hba1cReminderPlan
import com.agon.app.insights.Hba1cRules
import com.agon.app.reminders.Hba1cPrefs
import com.agon.app.reminders.Hba1cReminders
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.ConfirmDialog
import com.agon.app.ui.components.EmptyState
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GField
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.BackTitle
import com.agon.app.ui.theme.glucoColors
import java.util.Calendar
import kotlin.math.abs
import kotlin.math.roundToInt

private fun pickDate(ctx: android.content.Context, initial: Long, minToday: Boolean, onPick: (Long) -> Unit) {
    val c = Calendar.getInstance().apply { timeInMillis = if (initial > 0) initial else System.currentTimeMillis() }
    val d = DatePickerDialog(ctx, { _, y, m, day -> onPick(Hba1cRules.noonOf(y, m, day)) }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
    if (minToday) d.datePicker.minDate = System.currentTimeMillis() - 1000L
    else d.datePicker.maxDate = System.currentTimeMillis()
    d.show()
}

private fun dirSymbol(d: Hba1cDirection) = when (d) {
    Hba1cDirection.UP -> "▲ aumento"
    Hba1cDirection.DOWN -> "▼ redução"
    Hba1cDirection.SAME -> "● estável"
    Hba1cDirection.FIRST -> "primeiro exame"
}

@Composable
fun Hba1cScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val ctx = LocalContext.current

    var showForm by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Hba1cEntry?>(null) }
    var toDelete by remember { mutableStateOf<Hba1cEntry?>(null) }
    var chartN by remember { mutableStateOf("6") }
    var showInfo by remember { mutableStateOf(false) }

    val rows = remember(data.hba1c) { Hba1cHistory.rows(data.hba1c) }
    val latest = rows.firstOrNull()?.entry
    var goal by remember { mutableStateOf(Hba1cPrefs.goal(ctx)) }
    var goalText by remember { mutableStateOf(Hba1cRules.f1(Hba1cPrefs.goal(ctx))) }
    var goalErr by remember { mutableStateOf("") }

    var remOn by remember { mutableStateOf(Hba1cPrefs.reminderOn(ctx)) }
    var remMode by remember { mutableStateOf(Hba1cPrefs.mode(ctx)) }
    var remMonths by remember { mutableStateOf(Hba1cPrefs.months(ctx)) }
    var remDate by remember { mutableStateOf(Hba1cPrefs.fixedDate(ctx)) }
    fun resched() = Hba1cReminders.reschedule(ctx, Hba1cHistory.latest(data.hba1c)?.at)

    ScrollScreen {
        BackTitle("Hemoglobina glicada (HbA1c)", { nav.popBackStack() })
        Text(
            "Registre os resultados dos seus exames de laboratório e acompanhe a evolução. Aqui só entram resultados de laudo que você digitar — o app nunca cria nem estima valores de exame.",
            color = g.muted, fontSize = 13.sp,
        )
        PrimaryButton("Adicionar resultado de exame", g.violet, { editing = null; showForm = true }, Modifier.padding(top = 10.dp))

        // ── Último resultado laboratorial
        GCard(Modifier.padding(top = 10.dp)) {
            Text("HbA1c REAL (exame de laboratório)", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (latest == null) {
                EmptyState("Nenhum exame registrado", "Toque em “Adicionar resultado de exame” quando tiver o laudo em mãos.")
            } else {
                Text("${Hba1cRules.showPercent(latest.percent)}%", color = g.ink, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
                Text(
                    "Coleta em ${formatDate(latest.at)}" + if (latest.lab.isNotBlank()) " · ${latest.lab}" else "",
                    color = g.ink, fontSize = 14.sp,
                )
                Text(Hba1cGoal.describe(latest.percent, goal), color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                Text("Orientação de referência, não é diagnóstico.", color = g.muted, fontSize = 11.sp)
            }
        }

        // ── Comparação HbA1c REAL x GMI (lado a lado, nunca fundidos)
        val cmp = remember(data.glucose, data.hba1c, data.settings.targetLow, data.settings.targetHigh) { Hba1cCompare.compute(data) }
        GCard(Modifier.padding(top = 10.dp)) {
            Text("Comparação: HbA1c REAL × GMI", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(g.lilacSoft).padding(12.dp),
                ) {
                    Text("HbA1c REAL", color = g.muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(cmp.lab?.let { "${Hba1cRules.showPercent(it.percent)}%" } ?: "—", color = g.ink, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                    Text(cmp.lab?.let { "Exame de ${formatDate(it.at)}" } ?: "Sem exame registrado", color = g.muted, fontSize = 11.sp)
                }
                Column(
                    Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(g.blueSoft).padding(12.dp),
                ) {
                    Text("GMI (estimativa)", color = g.muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Text(cmp.gmi?.let { "${Hba1cRules.f1(it)}%" } ?: "—", color = g.ink, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        if (cmp.gmiAvailable) "Últimos ${cmp.periodDays} dias (${cmp.readings} medições)" else "Dados insuficientes",
                        color = g.muted, fontSize = 11.sp,
                    )
                }
            }
            val diff = cmp.diffPp
            Text(
                if (diff != null) "Diferença (GMI − HbA1c): ${if (diff >= 0) "+" else "−"}${Hba1cRules.f1(abs(diff))} ponto(s) percentual(is)." else "Diferença: não calculada (precisa de exame registrado e de GMI com dados suficientes).",
                color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp),
            )
            cmp.meanMg?.let {
                Text("Glicemia média usada no GMI: ${it.roundToInt()} mg/dL.", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
            }
            val originText = when (cmp.origin) {
                DataOrigin.CGM -> "sensor (CGM)"
                DataOrigin.MIXED -> "glicosímetro e sensor"
                DataOrigin.METER -> "glicosímetro"
                null -> null
            }
            if (originText != null) Text("Origem dos dados: $originText.", color = g.muted, fontSize = 12.sp)
            if (cmp.origin == DataOrigin.CGM) {
                Text(
                    cmp.coveragePct?.let { "Cobertura do sensor: ≈ ${it.roundToInt()}%." } ?: "Cobertura do sensor: não foi possível confirmar.",
                    color = g.muted, fontSize = 12.sp,
                )
            }
            if (!cmp.gmiAvailable && cmp.gmiUnavailableReason.isNotBlank()) {
                Text(cmp.gmiUnavailableReason, color = g.orange, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            }
            if (cmp.periodNote.isNotBlank()) Text(cmp.periodNote, color = g.orange, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            Text(cmp.disclaimer, color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }

        // ── Gráfico (somente exames laboratoriais)
        GCard(Modifier.padding(top = 10.dp)) {
            Text("Evolução dos exames", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Text("Somente resultados laboratoriais. O GMI não aparece neste gráfico.", color = g.muted, fontSize = 12.sp)
            if (rows.size < 2) {
                EmptyState("Gráfico indisponível", "São necessários pelo menos 2 exames registrados para mostrar a evolução.")
            } else {
                ChipRow(listOf("6" to "Últimos 6", "12" to "Últimos 12", "all" to "Todos"), chartN) { chartN = it }
                val pts = Hba1cHistory.chartPoints(data.hba1c, if (chartN == "all") null else chartN.toInt())
                Hba1cChart(pts, goal)
                val tr = Hba1cHistory.trend(pts, pts.size)
                if (tr != null) {
                    Text(
                        "Tendência no período mostrado: " + when (tr) {
                            Hba1cDirection.UP -> "aumento"
                            Hba1cDirection.DOWN -> "redução"
                            else -> "estável"
                        } + " (de ${Hba1cRules.showPercent(pts.first().percent)}% em ${formatDate(pts.first().at)} para ${Hba1cRules.showPercent(pts.last().percent)}% em ${formatDate(pts.last().at)}).",
                        color = g.ink, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }
        }

        // ── Histórico
        GCard(Modifier.padding(top = 10.dp)) {
            Text("Histórico de exames", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            if (rows.isEmpty()) {
                EmptyState("Sem exames", "Os resultados que você registrar aparecem aqui, do mais recente ao mais antigo.")
            }
            rows.forEach { r ->
                Column(Modifier.fillMaxWidth().padding(top = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("${Hba1cRules.showPercent(r.entry.percent)}%", color = g.ink, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                        Text("  ${formatDate(r.entry.at)}", color = g.ink, fontSize = 14.sp)
                    }
                    if (r.entry.lab.isNotBlank()) Text("Laboratório: ${r.entry.lab}", color = g.muted, fontSize = 12.sp)
                    Text(
                        "${dirSymbol(r.direction)} · ${Hba1cHistory.deltaText(r.deltaPp)}" + (r.previous?.let { " (anterior ${Hba1cRules.showPercent(it.percent)}% em ${formatDate(it.at)})" } ?: ""),
                        color = g.ink, fontSize = 12.sp,
                    )
                    if (r.entry.notes.isNotBlank()) Text(r.entry.notes, color = g.muted, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        TextButton(onClick = { editing = r.entry; showForm = true }) { Text("Editar") }
                        TextButton(onClick = { toDelete = r.entry }) { Text("Excluir", color = g.red) }
                    }
                }
            }
        }

        // ── Meta de referência (configurável)
        GCard(Modifier.padding(top = 10.dp)) {
            Text("Meta de referência", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Text(
                "Valor que você (ou sua equipe de saúde) definiu como referência. Serve só para destacar o resultado; não é diagnóstico nem indica mudança de tratamento.",
                color = g.muted, fontSize = 12.sp,
            )
            GField("Meta (%)", goalText, { goalText = it; goalErr = "" }, "7,0", numeric = true)
            if (goalErr.isNotBlank()) Text(goalErr, color = g.red, fontSize = 12.sp)
            PrimaryButton("Salvar meta", g.violet, {
                val e = Hba1cGoal.validate(goalText)
                if (e != null) goalErr = e
                else { Hba1cRules.parsePercent(goalText)?.let { Hba1cPrefs.setGoal(ctx, it); goal = it; goalErr = "" } }
            }, Modifier.padding(top = 6.dp))
        }

        // ── Lembrete de novo exame
        GCard(Modifier.padding(top = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Lembrete de novo exame", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Text("Você escolhe o intervalo ou a data. O app não define quando fazer o exame.", color = g.muted, fontSize = 12.sp)
                }
                Switch(checked = remOn, onCheckedChange = { remOn = it; Hba1cPrefs.setReminderOn(ctx, it); resched() })
            }
            if (remOn) {
                ChipRow(listOf(Hba1cReminderPlan.MODE_INTERVAL to "A cada N meses", Hba1cReminderPlan.MODE_DATE to "Em uma data"), remMode) {
                    remMode = it; Hba1cPrefs.setMode(ctx, it); resched()
                }
                if (remMode == Hba1cReminderPlan.MODE_INTERVAL) {
                    ChipRow(listOf(1, 2, 3, 4, 6, 12).map { it.toString() to "$it ${if (it == 1) "mês" else "meses"}" }, remMonths.toString()) {
                        remMonths = it.toInt(); Hba1cPrefs.setMonths(ctx, remMonths); resched()
                    }
                } else {
                    PrimaryButton(if (remDate > 0) "Data: ${formatDate(remDate)} (alterar)" else "Escolher data", g.blue, {
                        pickDate(ctx, remDate, true) { remDate = it; Hba1cPrefs.setFixedDate(ctx, it); resched() }
                    }, Modifier.padding(top = 6.dp))
                }
                val next = Hba1cReminderPlan.nextTrigger(remMode, remMonths, remDate, latest?.at, System.currentTimeMillis())
                Text(
                    if (next != null) "Próximo aviso: por volta de ${formatDate(next)}, às 9h." else "Nenhum aviso programado — escolha uma data futura.",
                    color = g.ink, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
                )
                Text("O horário é aproximado: o Android pode atrasar avisos para economizar bateria. Confirme que as notificações do app estão permitidas.", color = g.muted, fontSize = 11.sp)
            }
        }

        // ── Educação
        GCard(Modifier.padding(top = 10.dp)) {
            Row(Modifier.fillMaxWidth().clickable { showInfo = !showInfo }, verticalAlignment = Alignment.CenterVertically) {
                Text("Entenda a HbA1c e o GMI", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Text(if (showInfo) "Ocultar" else "Ler", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            if (showInfo) {
                Text(
                    "O que é: a hemoglobina glicada (HbA1c) mostra quanto de glicose ficou ligada à hemoglobina dos glóbulos vermelhos.\n\n" +
                        "O que o exame mede: reflete, em média, os últimos 2 a 3 meses, com maior peso para as semanas mais recentes.\n\n" +
                        "Por que é diferente do GMI: o GMI é uma estimativa calculada pelo app a partir das glicemias que você registrou (3,31 + 0,02392 × glicemia média em mg/dL). " +
                        "Ele depende de quantas medições existem e de quando foram feitas. A HbA1c vem de uma análise de sangue.\n\n" +
                        "Por que podem divergir: tempo de vida das hemácias, anemias e outras condições de saúde, variações entre laboratórios, períodos diferentes e poucas medições podem fazer os dois valores se afastarem.\n\n" +
                        "Por que o exame continua importante: só o exame de laboratório mede a HbA1c de fato. O GMI não o substitui.\n\n" +
                        "Este app não faz diagnóstico nem indica mudança de tratamento. Converse sobre seus resultados com sua equipe de saúde.",
                    color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
                )
            }
        }
    }

    if (showForm) {
        Hba1cFormDialog(
            initial = editing,
            onDismiss = { showForm = false },
            onSave = { pct, at, lab, notes ->
                vm.saveHba1c(editing?.id, pct, at, lab, notes).also { err -> if (err == null) showForm = false }
            },
        )
    }
    toDelete?.let { e ->
        ConfirmDialog(
            "Excluir este exame?",
            "O resultado de ${Hba1cRules.showPercent(e.percent)}% (coleta em ${formatDate(e.at)}) será removido do histórico. Esta ação não pode ser desfeita.",
            "Excluir",
            { vm.deleteHba1c(e.id); toDelete = null },
            { toDelete = null },
        )
    }
}

@Composable
private fun Hba1cFormDialog(
    initial: Hba1cEntry?,
    onDismiss: () -> Unit,
    onSave: (Double, Long, String, String) -> String?,
) {
    val g = glucoColors()
    val ctx = LocalContext.current
    var pct by remember { mutableStateOf(initial?.let { Hba1cRules.showPercent(it.percent) } ?: "") }
    var at by remember { mutableStateOf(initial?.at ?: Calendar.getInstance().let { Hba1cRules.noonOf(it.get(Calendar.YEAR), it.get(Calendar.MONTH), it.get(Calendar.DAY_OF_MONTH)) }) }
    var lab by remember { mutableStateOf(initial?.lab ?: "") }
    var notes by remember { mutableStateOf(initial?.notes ?: "") }
    var err by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Novo exame de HbA1c" else "Editar exame", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text("Digite exatamente o resultado que consta no laudo.", color = g.muted, fontSize = 12.sp)
                GField("Resultado (%)", pct, { pct = it; err = "" }, "Ex.: 7,2", numeric = true)
                Text("Data da coleta", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
                TextButton(onClick = { pickDate(ctx, at, false) { at = it; err = "" } }) { Text(formatDate(at) + "  (alterar)") }
                GField("Laboratório (opcional)", lab, { lab = it; err = "" }, "Nome do laboratório")
                GField("Observações (opcional)", notes, { notes = it; err = "" }, "Ex.: jejum de 8 h")
                if (err.isNotBlank()) Text(err, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val e = Hba1cRules.validatePercent(pct) ?: Hba1cRules.validateDate(at) ?: Hba1cRules.validateTexts(lab, notes)
                if (e != null) { err = e; return@TextButton }
                val v = Hba1cRules.parsePercent(pct) ?: run { err = "Resultado inválido."; return@TextButton }
                val r = onSave(v, at, lab, notes)
                if (r != null) err = r
            }) { Text("Salvar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } },
    )
}

/** Linha com os exames laboratoriais (eixo x proporcional às datas). Linha tracejada = meta de referência definida pela pessoa. */
@Composable
private fun Hba1cChart(pts: List<Hba1cEntry>, goal: Double) {
    val g = glucoColors()
    if (pts.isEmpty()) return
    val desc = "Gráfico de linha da HbA1c laboratorial: " + pts.joinToString("; ") { "${formatDate(it.at)}: ${Hba1cRules.showPercent(it.percent)}%" }
    val minV = minOf(pts.minOf { it.percent }, goal) - 0.5
    val maxV = maxOf(pts.maxOf { it.percent }, goal) + 0.5
    val span = (maxV - minV).coerceAtLeast(0.1)
    val violet = g.violet
    val ink = g.ink
    val muted = g.muted
    val band = g.lilacSoft
    Canvas(
        Modifier.fillMaxWidth().height(200.dp).padding(top = 8.dp).semantics { contentDescription = desc },
    ) {
        val padL = 36.dp.toPx(); val padR = 14.dp.toPx(); val padT = 16.dp.toPx(); val padB = 24.dp.toPx()
        val w = size.width - padL - padR
        val h = size.height - padT - padB
        fun yOf(v: Double) = padT + h * (1f - ((v - minV) / span).toFloat())
        val t0 = pts.first().at; val t1 = pts.last().at
        fun xOf(t: Long) = if (t1 == t0) padL + w / 2f else padL + w * ((t - t0).toFloat() / (t1 - t0).toFloat())

        drawRect(band, Offset(padL, padT), androidx.compose.ui.geometry.Size(w, h), alpha = 0.35f)
        val tp = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textSize = 11.sp.toPx(); color = muted.toArgb() }
        val vp = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply { textSize = 12.sp.toPx(); color = ink.toArgb(); isFakeBoldText = true }
        drawContext.canvas.nativeCanvas.drawText(Hba1cRules.f1(maxV), 0f, padT + 10.dp.toPx(), tp)
        drawContext.canvas.nativeCanvas.drawText(Hba1cRules.f1(minV), 0f, padT + h, tp)

        // meta de referência
        val gy = yOf(goal)
        var x = padL
        while (x < padL + w) {
            drawLine(muted, Offset(x, gy), Offset(minOf(x + 8.dp.toPx(), padL + w), gy), strokeWidth = 1.dp.toPx())
            x += 14.dp.toPx()
        }

        val path = Path()
        pts.forEachIndexed { i, e ->
            val px = xOf(e.at); val py = yOf(e.percent)
            if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
        }
        if (pts.size > 1) drawPath(path, violet, style = Stroke(width = 2.5.dp.toPx()))
        pts.forEach { e ->
            val px = xOf(e.at); val py = yOf(e.percent)
            drawCircle(violet, 5.dp.toPx(), Offset(px, py))
            val label = Hba1cRules.showPercent(e.percent)
            drawContext.canvas.nativeCanvas.drawText(label, (px - vp.measureText(label) / 2f).coerceIn(0f, size.width - vp.measureText(label)), py - 9.dp.toPx(), vp)
        }
        val a = formatDate(pts.first().at); val b = formatDate(pts.last().at)
        drawContext.canvas.nativeCanvas.drawText(a, padL, size.height - 4.dp.toPx(), tp)
        if (pts.size > 1) drawContext.canvas.nativeCanvas.drawText(b, size.width - padR - tp.measureText(b), size.height - 4.dp.toPx(), tp)
    }
    Text("Linha tracejada: meta de referência (${Hba1cRules.f1(goal)}%).", color = muted, fontSize = 11.sp)
}
