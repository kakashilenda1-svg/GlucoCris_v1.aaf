package com.agon.app.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import com.agon.app.R
import com.agon.app.data.moodOf

/** Paleta dos dois layouts da tela inicial. Só visual. */
data class HomePalette(
    val pink: Boolean,
    val bgTop: Color,
    val bgBottom: Color,
    val glow: Color,
    val panelA: Color,
    val panelB: Color,
    val panelBorder: Color,
    val bubble: Color,
    val pillA: Color,
    val pillB: Color,
    val msgA: Color,
    val msgB: Color,
    val msgInk: Color,
    val msgTitle: Color,
    val ctaA: Color,
    val ctaB: Color,
    val ctaBorder: Color,
    val navBg: Color,
    val navBorder: Color,
    val navSelected: Color,
    val navIndicator: Color,
    val navUnselected: Color,
)

val HomeBluePalette = HomePalette(
    pink = false,
    bgTop = Color(0xFF030A1E), bgBottom = Color(0xFF0A2A5E), glow = Color(0xFF1E90FF),
    panelA = Color(0xFF16509E), panelB = Color(0xFF0A2252), panelBorder = Color(0xFF3B8FEA), bubble = Color(0xFF0F3A7C),
    pillA = Color(0xFF123F86), pillB = Color(0xFF0B2A5E),
    msgA = Color(0xFFE3EDFA), msgB = Color(0xFFC7DAF3), msgInk = Color(0xFF1D2B4A), msgTitle = Color(0xFF0B1B3A),
    ctaA = Color(0xFF1C74E8), ctaB = Color(0xFF0B3FA0), ctaBorder = Color(0xFF4DA3FF),
    navBg = Color(0xFF071634), navBorder = Color(0xFF2F6FC4),
    navSelected = Color(0xFF3FA2FF), navIndicator = Color(0xFF123A78), navUnselected = Color(0xFFE2ECFA),
)

val HomePinkPalette = HomePalette(
    pink = true,
    bgTop = Color(0xFF05010D), bgBottom = Color(0xFF14052E), glow = Color(0xFFA855F7),
    panelA = Color(0xFF3F1A86), panelB = Color(0xFF1B0A45), panelBorder = Color(0xFF8B4DFF), bubble = Color(0xFF4B22A0),
    pillA = Color(0xFF6D28D9), pillB = Color(0xFF8B3DFF),
    msgA = Color(0xFFFFC9EE), msgB = Color(0xFFFBA6E6), msgInk = Color(0xFF3A1281), msgTitle = Color(0xFF3A1281),
    ctaA = Color(0xFF9B40FF), ctaB = Color(0xFF5B21D6), ctaBorder = Color(0xFFC08BFF),
    navBg = Color(0xFF120828), navBorder = Color(0xFF3A1F78),
    navSelected = Color(0xFFD8A8FF), navIndicator = Color(0xFF34196F), navUnselected = Color(0xFFE9D8FF),
)

fun homePalette(pink: Boolean) = if (pink) HomePinkPalette else HomeBluePalette

/** Fundo da tela inicial: degradê escuro + brilho neon. */
@Composable
fun HomeBackdrop(p: HomePalette, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier.fillMaxSize().background(Brush.verticalGradient(listOf(p.bgTop, p.bgBottom)))) {
        Canvas(Modifier.fillMaxSize()) {
            val c1 = Offset(size.width * 0.15f, size.height * 0.12f)
            drawCircle(Brush.radialGradient(listOf(p.glow.copy(alpha = 0.38f), Color.Transparent), center = c1, radius = size.width * 0.8f), radius = size.width * 0.8f, center = c1)
            val c2 = Offset(size.width * 0.95f, size.height * 0.88f)
            drawCircle(Brush.radialGradient(listOf(p.glow.copy(alpha = 0.20f), Color.Transparent), center = c2, radius = size.width * 0.7f), radius = size.width * 0.7f, center = c2)
        }
        content()
    }
}

/** Robô da Cris — arte das imagens de referência (res/drawable-nodpi). */
@Composable
fun CrisRobotArt(pink: Boolean, modifier: Modifier = Modifier, head: Boolean = false) {
    val id = when {
        head && pink -> R.drawable.cris_head_pink
        head -> R.drawable.cris_head_blue
        pink -> R.drawable.cris_robot_pink
        else -> R.drawable.cris_robot_blue
    }
    Image(painterResource(id), contentDescription = null, modifier = modifier, contentScale = ContentScale.FillBounds)
}

/** Botão "Como você está se sentindo?" (abre a mesma escolha de humor de antes). */
@Composable
fun HomeMoodPill(p: HomePalette, moodId: String, sticker: Boolean, u: Float, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val mood = moodOf(moodId)
    val shape = RoundedCornerShape((44f * u).dp)
    Row(
        modifier
            .fillMaxWidth()
            .height((82f * u).dp)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(p.pillA, p.pillB)))
            .border(1.dp, p.panelBorder.copy(alpha = 0.55f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = (20f * u).dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        if (mood != null) {
            if (sticker) WizardSticker(mood.id, Modifier.size((46f * u).dp)) else Text(mood.emoji, fontSize = (44f * u).sp)
        } else if (p.pink) {
            Text("\uD83D\uDE42", fontSize = (44f * u).sp)
        }
        Text(
            if (mood != null) "${mood.label} · trocar" else "Como você está se sentindo?",
            color = Color.White, fontWeight = FontWeight.Medium,
            fontSize = (30f * u).sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
            modifier = Modifier.padding(start = if (mood != null || p.pink) (12f * u).dp else 0.dp),
        )
    }
}
