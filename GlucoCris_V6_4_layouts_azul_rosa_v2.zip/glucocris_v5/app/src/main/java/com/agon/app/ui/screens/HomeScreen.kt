package com.agon.app.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.formatDateTime
import com.agon.app.data.formatLongDate
import com.agon.app.data.greeting
import com.agon.app.data.rangeStatus
import com.agon.app.data.statusLabel
import com.agon.app.data.toMgDl
import com.agon.app.data.weekdayLong
import com.agon.app.love.LOVE_PHONE_DISPLAY
import com.agon.app.love.LOVE_PHONE_TEL
import com.agon.app.love.MAIN_LOVE_MESSAGE
import com.agon.app.love.SAMU_TEL
import com.agon.app.love.openDialer
import com.agon.app.love.openWhatsApp
import com.agon.app.love.phraseForToday
import com.agon.app.ui.components.ActionButton
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GlucoseChart
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.components.tourTarget
import com.agon.app.ui.theme.glucoColors
import kotlin.math.roundToInt
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.core.view.WindowCompat
import com.agon.app.data.HomeLayoutStore
import com.agon.app.ui.theme.BlueDarkGlucoColors
import com.agon.app.ui.theme.DarkGlucoColors
import com.agon.app.ui.theme.LocalGluco

@Composable
fun HomeScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val context = LocalContext.current
    val settings = data.settings
    var phrase by remember { mutableStateOf("") }
    var showMood by remember { mutableStateOf(false) }
    var waterBarVisible by remember { mutableStateOf(true) }
    val scrollWatcher = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -6f) waterBarVisible = false
                else if (available.y > 6f) waterBarVisible = true
                return Offset.Zero
            }
        }
    }
    LaunchedEffect(Unit) { phrase = phraseForToday(context) }
    if (showMood) {
        MoodSheet(settings.mood, settings.moodStyle, { st -> vm.updateSettings { it.copy(moodStyle = st) } }, onDismiss = { showMood = false }) { id ->
            vm.updateSettings { it.copy(mood = id, moodAt = System.currentTimeMillis()) }
            showMood = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val latest = data.glucose.maxByOrNull { it.at }
    val mg = latest?.let { toMgDl(it.value, it.unit) }
    val status = mg?.let { rangeStatus(it, settings.targetLow, settings.targetHigh) }
    val pinkLayout = HomeLayoutStore.pink

    // A tela inicial é escura nos dois layouts: ícones claros na barra de status enquanto estiver aqui.
    val view = LocalView.current
    if (!view.isInEditMode) {
        DisposableEffect(Unit) {
            val ctrl = (view.context as? android.app.Activity)?.window?.let { WindowCompat.getInsetsController(it, view) }
            val previous = ctrl?.isAppearanceLightStatusBars
            onDispose { if (ctrl != null && previous != null) ctrl.isAppearanceLightStatusBars = previous }
        }
        SideEffect {
            (view.context as? android.app.Activity)?.window?.let { WindowCompat.getInsetsController(it, view).isAppearanceLightStatusBars = false }
        }
    }
    val baseDensity = LocalDensity.current
    val fixedDensity = Density(baseDensity.density, minOf(baseDensity.fontScale, 1f))

    Crossfade(targetState = pinkLayout, animationSpec = tween(260), label = "homeLayout") { isPink ->
        val p = homePalette(isPink)
        val gd = if (isPink) DarkGlucoColors else BlueDarkGlucoColors
        val statusColor = when (status) {
            "ok" -> Color(0xFF22E58B)
            "low" -> gd.orange
            "high" -> Color(0xFFF87171)
            else -> gd.muted
        }
        CompositionLocalProvider(LocalGluco provides gd, LocalDensity provides fixedDensity) {
        HomeBackdrop(p) {
        BoxWithConstraints(Modifier.fillMaxSize().nestedScroll(scrollWatcher)) {
            // Tudo é proporcional à largura da tela (mesmas proporções das imagens de referência, 988 px de largura).
            val u = maxWidth.value / 988f
            fun d(n: Float): Dp = (n * u).dp
            fun s(n: Float) = (n * u).sp

            Column(Modifier.fillMaxSize()) {
                // ── Cabeçalho fixo: título, botão redondo (troca de layout) e ajuda ──
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = d(24f)).padding(top = d(8f)).height(d(84f)),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                        Text("Gluco Cris", color = Color.White, fontSize = s(46f), fontWeight = FontWeight.SemiBold)
                        if (isPink) Icon(Icons.Filled.Favorite, null, tint = Color(0xFFFF4FA8), modifier = Modifier.padding(start = d(12f)).size(d(46f)))
                    }
                    // Botão circular: alterna layout azul <-> rosa/roxo. Somente visual, salvo no aparelho.
                    Box(
                        Modifier
                            .padding(end = d(24f))
                            .size(maxOf(d(66f), 34.dp))
                            .tourTarget("home_theme")
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(Color(0xFF3B7BFF), Color(0xFF0B2A8F))))
                            .border(2.dp, Color(0xFF7CC4FF), CircleShape)
                            .clickable { HomeLayoutStore.toggle(context) },
                    )
                    Box(
                        Modifier
                            .tourTarget("home_help")
                            .size(maxOf(d(76f), 38.dp))
                            .clip(if (isPink) CircleShape else RoundedCornerShape(d(26f)))
                            .background(if (isPink) Color(0xFF8B3DFF) else Color(0xFF123A78))
                            .border(1.dp, p.panelBorder.copy(alpha = 0.7f), if (isPink) CircleShape else RoundedCornerShape(d(26f)))
                            .clickable { nav.navigate(Routes.HELP_CENTER) },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("?", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = maxOf(46f * u, 16f).sp)
                    }
                }

                Column(
                    Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .imePadding()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = d(20f)),
                ) {
                    // ── Robô + saudação + humor ──
                    Row(Modifier.fillMaxWidth()) {
                        Box(Modifier.width(d(384f)).height(if (isPink) d(252f) else d(287f))) {
                            CrisRobotArt(
                                isPink,
                                Modifier.offset(x = d(-8f), y = if (isPink) d(24f) else 0.dp)
                                    .size(width = if (isPink) d(370f) else d(350f), height = if (isPink) d(252f) else d(287f)),
                            )
                        }
                        Column(Modifier.weight(1f)) {
                            Spacer(Modifier.height(d(if (isPink) 52f else 70f)))
                            Text(
                                com.agon.app.data.firstName(settings.displayName).let { first ->
                                    if (first.isNotBlank()) "${greeting()}, $first!" else "${greeting()}!"
                                },
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontSize = s(58f),
                                lineHeight = s(64f),
                            )
                            Spacer(Modifier.height(d(14f)))
                            HomeMoodPill(p, settings.mood, settings.moodStyle == "bruxo", u) { showMood = true }
                        }
                    }

                    // ── Última medição + estatísticas de 7 dias ──
                    val weekMs = 7L * 24 * 60 * 60 * 1000
                    val since = System.currentTimeMillis() - weekMs
                    val weekG = data.glucose.filter { it.at >= since }
                    val weekI = data.insulin.filter { it.at >= since }

                    Row(Modifier.fillMaxWidth().padding(top = d(if (isPink) 24f else 0f)).height(d(348f)), horizontalArrangement = Arrangement.spacedBy(d(20f))) {
                        HomePanel(p, u, Modifier.weight(538f).fillMaxHeight(), PaddingValues(start = d(30f), end = d(14f), top = d(16f))) {
                            Row(Modifier.height(d(64f)), verticalAlignment = Alignment.CenterVertically) {
                                HomeIconBubble(p, Icons.Filled.WaterDrop, d(64f))
                                Text("Última medição", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = s(36f), maxLines = 1, modifier = Modifier.padding(start = d(40f)))
                            }
                            if (latest == null || mg == null || status == null) {
                                Text("Nenhuma medição ainda.", color = Color.White, fontWeight = FontWeight.Bold, fontSize = s(36f), modifier = Modifier.padding(top = d(30f)))
                            } else {
                                Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(top = d(4f))) {
                                    Text(mg.roundToInt().toString(), color = statusColor, fontWeight = FontWeight.ExtraBold, fontSize = s(140f), lineHeight = s(146f), maxLines = 1)
                                    Text(" mg/dL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = s(44f), maxLines = 1, modifier = Modifier.padding(bottom = d(20f), start = d(8f)))
                                }
                                Row(Modifier.height(d(60f)), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(if (status == "ok") Icons.Filled.CheckCircle else Icons.Filled.Warning, null, tint = statusColor, modifier = Modifier.size(d(58f)))
                                    Text(statusLabel(status), color = statusColor, fontWeight = FontWeight.ExtraBold, fontSize = s(42f), maxLines = 1, modifier = Modifier.padding(start = d(18f)))
                                }
                                Text(
                                    "${GLUCOSE_CONTEXT_LABEL[latest.context] ?: latest.context} · ${formatDateTime(latest.at)}",
                                    color = Color.White,
                                    fontSize = s(27f),
                                    lineHeight = s(33f),
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(top = d(8f)),
                                )
                            }
                        }
                        HomePanel(p, u, Modifier.weight(395f).fillMaxHeight().clickable { nav.navigate(Routes.CRIS_IA) }, PaddingValues(start = d(22f), end = d(10f), top = d(14f))) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                HomeIconBubble(p, Icons.Filled.BarChart, d(64f))
                                Column(Modifier.padding(start = d(28f))) {
                                    Text("Glicemias", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = s(32f), lineHeight = s(38f), maxLines = 1)
                                    Text("(7 dias)", color = Color.White, fontSize = s(32f), lineHeight = s(38f), maxLines = 1)
                                }
                            }
                            Text(weekG.size.toString(), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = s(76f), lineHeight = s(86f), modifier = Modifier.padding(start = d(92f)))
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = d(6f))) {
                                HomeIconBubble(p, Icons.Filled.Vaccines, d(64f))
                                Column(Modifier.padding(start = d(28f))) {
                                    Text("Insulinas", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = s(32f), lineHeight = s(38f), maxLines = 1)
                                    Text("(7 dias)", color = Color.White, fontSize = s(32f), lineHeight = s(38f), maxLines = 1)
                                }
                            }
                            Text(weekI.size.toString(), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = s(76f), lineHeight = s(86f), modifier = Modifier.padding(start = d(92f)))
                        }
                    }

                    // ── Uma mensagem para você ──
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = d(24f))
                            .clip(RoundedCornerShape(d(40f)))
                            .background(Brush.verticalGradient(listOf(p.msgA, p.msgB)))
                            .padding(start = d(40f), end = d(34f), top = d(26f), bottom = d(22f)),
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isPink) Icon(Icons.Filled.Favorite, null, tint = Color(0xFFE11D2E), modifier = Modifier.size(d(66f)))
                            else Icon(Icons.Filled.ChatBubble, null, tint = p.msgTitle, modifier = Modifier.size(d(62f)))
                            Text("Uma mensagem para você", color = p.msgTitle, fontWeight = FontWeight.ExtraBold, fontSize = s(40f), maxLines = 1, modifier = Modifier.padding(start = d(26f)))
                            if (isPink) Icon(Icons.Filled.Favorite, null, tint = Color(0xFFE11D2E), modifier = Modifier.padding(start = d(14f)).size(d(66f)))
                        }
                        Text(
                            MAIN_LOVE_MESSAGE,
                            color = p.msgInk,
                            fontSize = s(36f),
                            lineHeight = s(47f),
                            fontWeight = if (isPink) FontWeight.SemiBold else FontWeight.Normal,
                            modifier = Modifier.padding(top = d(10f)),
                        )
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = d(8f))) {
                            Icon(Icons.Outlined.FavoriteBorder, null, tint = p.msgInk, modifier = Modifier.size(d(54f)))
                            Text("Frase carinhosa de hoje", color = p.msgInk, fontSize = s(33f), maxLines = 1, modifier = Modifier.padding(start = d(22f)))
                        }
                        if (phrase.isNotEmpty()) {
                            Text(phrase, color = p.msgTitle, fontSize = s(31f), fontStyle = FontStyle.Italic, lineHeight = s(40f), modifier = Modifier.padding(top = d(6f)))
                        }
                    }

                    // ── Conversar com a Cris IA ──
                    val ctaShape = RoundedCornerShape(d(if (isPink) 66f else 46f))
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = d(24f))
                            .height(d(136f))
                            .clip(ctaShape)
                            .background(Brush.horizontalGradient(listOf(p.ctaA, p.ctaB)))
                            .border(1.dp, p.ctaBorder.copy(alpha = 0.6f), ctaShape)
                            .clickable { nav.navigate(Routes.CRIS_IA) },
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        CrisRobotArt(isPink, Modifier.padding(start = d(88f)).size(width = if (isPink) d(184f) else d(164f), height = if (isPink) d(130f) else d(126f)), head = true)
                        Column(Modifier.padding(start = d(if (isPink) 40f else 68f)).weight(1f)) {
                            Text("Conversar com a Cris IA", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = s(40f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Sua assistente de cuidado", color = Color.White.copy(alpha = 0.95f), fontSize = s(31f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        Icon(Icons.Filled.ChevronRight, null, tint = Color.White, modifier = Modifier.padding(end = d(30f)).size(d(70f)))
                    }

                    // ── Demais recursos da tela inicial (mantidos) ──
                    Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ActionButton("Registrar glicose", Icons.Filled.WaterDrop, p.ctaB, { nav.navigate(Routes.glucoseForm(null)) }, Modifier.weight(1f))
                        ActionButton("Registrar insulina", Icons.Filled.WaterDrop, p.ctaA, { nav.navigate(Routes.insulinForm(null)) }, Modifier.weight(1f))
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ActionButton(
                            " Ligar para meu amor ❤️",
                            Icons.Filled.Call,
                            p.ctaB,
                            { openDialer(context, LOVE_PHONE_TEL) },
                            Modifier.weight(1f),
                        )
                    }
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ActionButton(
                            "falar com amor por WhatsApp ",
                            Icons.Filled.Favorite,
                            if (isPink) Color(0xFFDB2777) else p.ctaA,
                            { openWhatsApp(context) },
                            Modifier.weight(1f),
                        )
                    }
                    Text(
                        "A ligação não começa sozinha: o discador abre com $LOVE_PHONE_DISPLAY para você confirmar. O WhatsApp só abre a conversa, sem enviar mensagem.",
                        color = Color.White.copy(alpha = 0.7f),
                        fontSize = 11.sp,
                        modifier = Modifier.padding(top = 6.dp, start = 4.dp, end = 4.dp),
                    )

                    Row(
                        Modifier
                            .fillMaxWidth()
                            .padding(top = 14.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .background(gd.red)
                            .clickable { openDialer(context, SAMU_TEL) }
                            .padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.LocalHospital, null, tint = Color.White)
                        Column(Modifier.padding(start = 12.dp).weight(1f)) {
                            Text(" Emergência — SAMU 192", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                            Text(
                                "Abre o discador com 192. Não aciona o atendimento sozinho e não garante que a chamada seja completada.",
                                color = Color.White.copy(alpha = 0.92f),
                                fontSize = 12.sp,
                            )
                        }
                    }

                    SectionTitle("Evolução", "Ver estatísticas") { nav.navigate(Routes.STATS) }
                    GCard { GlucoseChart(data.glucose, settings.targetLow, settings.targetHigh) }

                    val active = data.reminders.filter { it.enabled }.sortedWith(compareBy({ it.hour }, { it.minute }))
                    SectionTitle("Próximo lembrete", "Ver todos") { Routes.goTab(nav, Routes.REMINDERS) }
                    GCard {
                        if (active.isEmpty()) {
                            Text("Nenhum lembrete ativo.", color = gd.muted, fontSize = 14.sp)
                        } else {
                            active.take(3).forEach { r ->
                                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                                    Text(r.title, color = gd.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                    Text(
                                        "${com.agon.app.data.formatClock(r.hour, r.minute)} · ${com.agon.app.data.daysLabel(r.days)}",
                                        color = gd.muted,
                                        fontSize = 12.sp,
                                    )
                                    Text(
                                        (if (r.kind == "glicose") "Medição de glicose" else "Aplicação de insulina") +
                                            if (r.notes.isNotEmpty()) " · ${r.notes}" else "",
                                        color = gd.violetDeep,
                                        fontSize = 12.sp,
                                    )
                                }
                            }
                        }
                    }

                    SectionTitle("Histórico resumido", "Ver todos") { Routes.goTab(nav, Routes.HISTORY) }
                    GCard {
                        val recent = data.glucose.sortedByDescending { it.at }.take(4)
                        if (recent.isEmpty()) {
                            Text("Sem registros.", color = gd.muted, modifier = Modifier.padding(12.dp))
                        } else {
                            recent.forEach { e ->
                                val v = toMgDl(e.value, e.unit)
                                val st = rangeStatus(v, settings.targetLow, settings.targetHigh)
                                val c = when (st) { "ok" -> gd.green; "low" -> gd.orange; else -> gd.red }
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .clickable { nav.navigate(Routes.glucoseForm(e.id)) }
                                        .padding(vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                ) {
                                    Text(v.roundToInt().toString(), color = c, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.padding(end = 10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(GLUCOSE_CONTEXT_LABEL[e.context] ?: e.context, color = gd.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        Text("${com.agon.app.data.formatDate(e.at)} · ${com.agon.app.data.formatTime(e.at)}", color = gd.muted, fontSize = 12.sp)
                                    }
                                    Text(statusLabel(st), color = c, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                    Spacer(Modifier.height(96.dp))
                }
            }
            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                WaterMiniBar(
                    visible = waterBarVisible,
                    onOpenFull = { nav.navigate(Routes.WATER) },
                    modifier = Modifier.tourTarget("home_water"),
                )
            }
        }
        }
        }
    }
}

/** Painel dos cartões "Última medição" e "Estatísticas". */
@Composable
private fun HomePanel(p: HomePalette, u: Float, modifier: Modifier = Modifier, padding: PaddingValues, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape((40f * u).dp)
    Column(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(p.panelA, p.panelB)))
            .border(1.5.dp, p.panelBorder.copy(alpha = 0.75f), shape)
            .padding(padding),
        content = content,
    )
}

@Composable
private fun HomeIconBubble(p: HomePalette, icon: androidx.compose.ui.graphics.vector.ImageVector, size: Dp) {
    Box(Modifier.size(size).clip(CircleShape).background(p.bubble), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(size * 0.58f))
    }
}
