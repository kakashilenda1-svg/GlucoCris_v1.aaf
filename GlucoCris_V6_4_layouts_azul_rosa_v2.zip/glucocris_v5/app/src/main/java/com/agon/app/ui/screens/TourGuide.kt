package com.agon.app.ui.screens

import android.content.Context
import android.speech.tts.TextToSpeech
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.agon.app.Routes
import com.agon.app.data.GlucoViewModel
import com.agon.app.ui.components.TourRegistry
import com.agon.app.ui.theme.glucoColors
import java.util.Locale

/**
 * Passo do tour inteligente.
 * [route]: tela onde o passo acontece (o tour leva você até lá).
 * [target]: elemento destacado na tela (o resto fica escurecido e bloqueado).
 * [tapHint]: o que o usuário pode tocar no elemento destacado (a simulação não salva nada).
 * [nextRoute]: quando o usuário toca no elemento e chega nesta tela, o tour avança sozinho.
 */
private data class TourStep(
    val route: String,
    val target: String?,
    val emoji: String,
    val title: String,
    val speak: String,
    val tips: List<String> = emptyList(),
    val tapHint: String? = null,
    val nextRoute: String? = null,
)

private val TOUR_STEPS = listOf(
    TourStep(
        Routes.HOME, "home_help", "❓", "Botão de ajuda",
        "Este é o botão de ajuda. Ele abre a Central de aprendizado, onde você pode refazer este tour quando quiser.",
        listOf("Fica no topo da tela Início.", "Na Central há um texto para cada parte do app."),
    ),
    TourStep(
        Routes.HOME, "home_theme", "🎨", "Troca de cores",
        "Este botão redondo troca o visual da tela Início: layout azul ou layout rosa e roxo.",
        listOf("Toque de novo para voltar.", "A sua escolha fica guardada no aparelho."),
        tapHint = "Toque no botão redondo para testar",
    ),
    TourStep(
        Routes.HOME, "home_water", "💧", "Cris Hidrata",
        "Aqui embaixo fica o contador de água. O botão de mais soma um copo de duzentos e cinquenta mililitros. Toque no card para abrir o Cris Hidrata completo.",
        listOf("A barra mostra quanto da meta você já bebeu.", "O card abre a tela completa."),
        tapHint = "Toque no card para abrir",
        nextRoute = Routes.WATER,
    ),
    TourStep(
        Routes.WATER, "water_ring", "🎯", "Meta do dia",
        "O anel mostra quanto você já bebeu hoje em relação à meta. Quando fecha, aparece a conquista do dia.",
        listOf("A meta pode ser manual ou sugerida pelo seu peso.", "O modo calor soma quatrocentos mililitros só naquele dia."),
    ),
    TourStep(
        Routes.WATER, "water_alert", "⚠️", "Alerta de glicose alta",
        "Este interruptor liga ou desliga o aviso para beber água quando a sua glicose passa da meta máxima.",
        listOf("Ao registrar uma glicose alta, o app te avisa.", "Dentro desta tela aparece um lembrete com botão para beber água."),
        tapHint = "Toque no interruptor para testar",
    ),
    TourStep(
        Routes.WATER, "water_clock", "⏰", "Relógio inteligente",
        "O relógio sugere quanto beber no próximo horário. Toque em um horário para editar, no x para remover, ou em mais horário para criar.",
        listOf("Ligue os lembretes no interruptor.", "Se a meta já foi batida, o relógio fica em silêncio.", "Dá para gerar horários automáticos a cada uma, duas, três ou quatro horas."),
    ),
    TourStep(
        Routes.WATER, "water_cups", "🥤", "Copos",
        "Toque em um copo para somar a água. A estrelinha fixa seus copos favoritos no começo da lista.",
        listOf("Na simulação, nada é salvo de verdade.", "Se errar, use desfazer, que aparece por cinco segundos."),
        tapHint = "Toque em um copo para testar",
    ),
    TourStep(
        Routes.WATER, "water_drop", "😄", "A gotinha",
        "Esta é a gotinha da Cris. Toque nela para ver ela dançar e dar risada. O humor dela muda conforme você bebe.",
        listOf("Triste abaixo da metade, normal acima, e festa quando bate a meta.", "Os sons podem ser desligados nos ajustes do contador."),
        tapHint = "Toque na gotinha",
    ),
    TourStep(
        Routes.HOME, "tab_glicose", "🩸", "Aba Glicose",
        "Agora vamos registrar uma glicose. Toque na aba Glicose, aqui embaixo.",
        listOf("Cada medição guarda valor, horário e contexto."),
        tapHint = "Toque em Glicose",
        nextRoute = Routes.GLUCOSE,
    ),
    TourStep(
        Routes.GLUCOSE, "glucose_add", "➕", "Nova medição",
        "O botão de mais abre o formulário de uma nova medição. Toque nele.",
        listOf("Para editar ou excluir, toque em um registro da lista."),
        tapHint = "Toque no botão de mais",
        nextRoute = Routes.GLUCOSE_FORM,
    ),
    TourStep(
        Routes.GLUCOSE_FORM, null, "📝", "Preenchendo a glicose",
        "Digite o valor, escolha o contexto, como jejum ou depois da refeição, e toque em salvar. Aqui é uma simulação, então pode testar à vontade.",
        listOf("O horário já vem preenchido, mas pode mudar.", "Se a glicose passar da meta, o aviso de beber água dispara."),
    ),
    TourStep(
        Routes.HOME, "tab_insulina", "💉", "Aba Insulina",
        "Na aba Insulina você registra as aplicações, conforme a orientação da sua equipe de saúde. Toque nela.",
        listOf("O app não calcula nem altera dose de insulina."),
        tapHint = "Toque em Insulina",
        nextRoute = Routes.INSULIN,
    ),
    TourStep(
        Routes.INSULIN, "insulin_add", "➕", "Nova aplicação",
        "Use o botão de mais para registrar uma aplicação: tipo, nome, dose e horário.",
        listOf("Aplicação realizada e lembrete anotado ficam separados."),
    ),
    TourStep(
        Routes.HOME, "tab_lembretes", "⏰", "Aba Lembretes",
        "Em Lembretes você cria alertas de medição, medicação e rotina. Toque na aba.",
        tapHint = "Toque em Lembretes",
        nextRoute = Routes.REMINDERS,
    ),
    TourStep(
        Routes.REMINDERS, "reminders_add", "🔔", "Novo lembrete",
        "Toque aqui para criar um lembrete. Escolha o tipo, o horário, os dias da semana e o som.",
        listOf("Cada lembrete tem um interruptor para ligar ou desligar."),
    ),
    TourStep(
        Routes.HOME, "tab_historico", "📋", "Aba Histórico",
        "O Histórico mostra a linha do tempo de tudo o que você registrou, em um só lugar.",
        tapHint = "Toque em Histórico",
        nextRoute = Routes.HISTORY,
    ),
    TourStep(
        Routes.HOME, "tab_alimentacao", "🍽️", "Aba Alimentação",
        "Em Alimentação você pesquisa alimentos, monta o prato, usa o diário, o bolus, o código de barras, o scanner de prato, receitas e planos.",
        listOf("A calculadora de bolus é só apoio de conta.", "Revise sempre os itens antes de salvar uma refeição."),
        tapHint = "Toque em Alimentação",
        nextRoute = Routes.FOOD,
    ),
    TourStep(
        Routes.HOME, "tab_mais", "➕", "Aba Mais",
        "Na aba Mais ficam o Perfil, a Cris IA, o localizador de insulinas, estatísticas, medicamentos, relatório e ajustes. Toque nela.",
        tapHint = "Toque em Mais",
        nextRoute = Routes.MORE,
    ),
    TourStep(
        Routes.MORE, "more_perfil", "👤", "Perfil",
        "No Perfil ficam seus dados pessoais e de saúde. Toque para abrir.",
        tapHint = "Toque em Perfil",
        nextRoute = Routes.PROFILE,
    ),
    TourStep(
        Routes.PROFILE, "profile_account", "🔐", "Sua conta",
        "Aqui aparece a conta Google ligada ao app, com o e-mail. O botão Alterar troca de conta, e o botão Sair leva você de volta para a tela de login.",
        listOf("Na simulação, o Sair não é executado.", "Seus registros continuam salvos neste aparelho."),
    ),
    TourStep(
        Routes.MORE, "more_cris", "❤️", "Cris IA",
        "A Cris IA conversa por texto ou por voz para tirar dúvidas do dia a dia. Ela não substitui o seu médico.",
    ),
    TourStep(
        Routes.MORE, "more_locator", "📍", "Localizador de insulinas",
        "Encontre farmácias e pontos de atendimento perto de você.",
    ),
    TourStep(
        Routes.MORE, "more_stats", "📊", "Estatísticas",
        "Veja médias, faixas de glicemia e a evolução dos seus registros.",
    ),
    TourStep(
        Routes.MORE, "more_report", "📄", "Relatório",
        "Gere um relatório em texto, PDF ou planilha para compartilhar com a sua equipe de saúde. A água também entra no relatório.",
    ),
    TourStep(
        Routes.MORE, "more_settings", "⚙️", "Ajustes",
        "Nos Ajustes ficam o tema, as metas de glicemia, a unidade, o PIN e os sons.",
    ),
    TourStep(
        Routes.CRIS_IA, "cris_input", "💬", "Conversar com a Cris",
        "Escreva sua pergunta aqui embaixo e toque em enviar. O clipe anexa foto, PDF ou arquivo, e o microfone deixa você falar. Depois de enviar, pode sair da conversa ou apagar a tela: a Cris continua e avisa quando terminar.",
        listOf("Com internet ela pesquisa na web quando a pergunta pede dados atuais.", "Sem internet ela responde com o modelo instalado no aparelho.", "Na simulação, nada é salvo."),
    ),
    TourStep(
        Routes.CRIS_IA, "cris_menu", "📋", "Menu da conversa",
        "Neste menu ficam o histórico de conversas, as tarefas da Cris, nova conversa e excluir conversa. Em Tarefas você vê o que está em andamento, o que terminou e o que deu erro, com a opção de tentar de novo.",
        listOf("Tocar na notificação abre a conversa certa com a resposta."),
        tapHint = "Toque nos três pontinhos para ver",
    ),
    TourStep(
        Routes.CRIS_AI_SETTINGS, "cris_model", "🧠", "Modelos da Cris",
        "Aqui você baixa a IA que roda no aparelho. O app recomenda a opção mais estável para o seu celular, mas você pode escolher a Rápida, que é leve, ou a Precisa, que responde melhor e é mais pesada.",
        listOf("O download continua com a tela apagada ou com o app fechado, com botões Pausar e Cancelar na notificação.", "Se a conexão cair, ele tenta de novo sozinho."),
    ),
    TourStep(
        Routes.HOME, null, "🎉", "Tudo pronto!",
        "Pronto! Agora você já sabe usar o Gluco Cris. Para rever este passo a passo, toque no ponto de interrogação do Início e depois em iniciar tour guiado.",
    ),
)

/** Último passo permitido e primeiro passo da execução atual (tutorial completo ou de uma seção). */
@Volatile private var tourEnd: Int = TOUR_STEPS.lastIndex
@Volatile private var tourStart: Int = 0

/** Tutoriais individuais: nome, título do primeiro passo e título do último passo da seção. */
val TOUR_SECTIONS: List<Triple<String, String, String>> = listOf(
    Triple("Cris Hidrata (água)", "Cris Hidrata", "A gotinha"),
    Triple("Glicose", "Aba Glicose", "Preenchendo a glicose"),
    Triple("Insulina", "Aba Insulina", "Nova aplicação"),
    Triple("Lembretes", "Aba Lembretes", "Novo lembrete"),
    Triple("Histórico", "Aba Histórico", "Aba Histórico"),
    Triple("Alimentação", "Aba Alimentação", "Aba Alimentação"),
    Triple("Perfil e conta Google", "Aba Mais", "Sua conta"),
    Triple("Cris IA, modelos e downloads", "Conversar com a Cris", "Modelos da Cris"),
    Triple("Localizador, estatísticas, relatório e ajustes", "Localizador de insulinas", "Ajustes"),
)

/** Inicia só uma seção do tour (em simulação). Pode ser repetida quantas vezes quiser. */
fun startTourSection(vm: GlucoViewModel, name: String) {
    val sec = TOUR_SECTIONS.firstOrNull { it.first == name } ?: return
    val a = TOUR_STEPS.indexOfFirst { it.title == sec.second }
    val b = TOUR_STEPS.indexOfFirst { it.title == sec.third }
    if (a < 0 || b < a) return
    tourStart = a
    tourEnd = b
    vm.startPractice()
    vm.setTourStep(a)
}

private fun goToStep(nav: NavHostController, route: String) {
    if (route in Routes.tabs) {
        Routes.goTab(nav, route)
    } else {
        nav.navigate(route) {
            popUpTo(nav.graph.findStartDestination().id)
            launchSingleTop = true
        }
    }
}

/** Voz do tour (Android TextToSpeech, em português). */
private class TourVoice(context: Context) {
    private var ready = false
    private var pending: String? = null
    private lateinit var tts: TextToSpeech

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val r = tts.setLanguage(Locale("pt", "BR"))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                    tts.setLanguage(Locale.getDefault())
                }
                tts.setSpeechRate(0.95f)
                ready = true
                pending?.let { speak(it) }
                pending = null
            }
        }
    }

    fun speak(text: String) {
        if (!ready) {
            pending = text
            return
        }
        try {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "tour")
        } catch (_: Exception) {
        }
    }

    fun stop() {
        pending = null
        try {
            if (ready) tts.stop()
        } catch (_: Exception) {
        }
    }

    fun shutdown() {
        try {
            tts.stop()
            tts.shutdown()
        } catch (_: Exception) {
        }
    }
}

/** Inicia o tour em modo simulação (nada é salvo). */
fun startSmartTour(vm: GlucoViewModel) {
    tourStart = 0
    tourEnd = TOUR_STEPS.lastIndex
    vm.startPractice()
    vm.setTourStep(0)
}

/** Tour inteligente: destaca o ponto explicado, fala em voz alta e deixa você interagir numa simulação. */
@Composable
fun TourOverlay(vm: GlucoViewModel, nav: NavHostController) {
    val step by vm.tourStep.collectAsStateWithLifecycle()
    val voiceOn by vm.tourVoice.collectAsStateWithLifecycle()
    val current = step ?: return
    val g = glucoColors()
    val context = LocalContext.current
    val voice = remember { TourVoice(context) }
    DisposableEffect(Unit) { onDispose { voice.shutdown() } }

    val backEntry by nav.currentBackStackEntryAsState()
    val route = backEntry?.destination?.route?.substringBefore('?')

    fun close() {
        voice.stop()
        val wasInside = current >= 0
        vm.endPractice()
        vm.closeTour()
        if (wasInside) Routes.goTab(nav, Routes.HOME)
    }

    BackHandler { close() }

    val s = TOUR_STEPS.getOrNull(current)

    // leva até a tela do passo
    LaunchedEffect(current) {
        if (s != null && route != s.route) goToStep(nav, s.route)
    }
    // avança sozinho quando o usuário toca no ponto destacado e chega na tela esperada
    LaunchedEffect(route, current) {
        val n = s?.nextRoute
        if (n != null && route == n && current < tourEnd) vm.setTourStep(current + 1)
    }
    // fala o passo
    LaunchedEffect(current, voiceOn) {
        if (!voiceOn) {
            voice.stop()
        } else if (s != null) {
            voice.speak(buildString {
                append(s.title).append(". ").append(s.speak)
                s.tapHint?.let { append(" ").append(it).append(".") }
            })
        } else {
            voice.speak("Quer aprender tudo do Gluco Cris? Eu te mostro cada parte, falando e apontando. Nada do que você tocar será salvo.")
        }
    }

    var origin by remember { mutableStateOf(Offset.Zero) }
    val density = LocalDensity.current
    val pulse by rememberInfiniteTransition(label = "tour").animateFloat(
        initialValue = 0.35f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse), label = "pulse",
    )

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .onGloballyPositioned { origin = it.positionInRoot() },
    ) {
        val screenW = constraints.maxWidth.toFloat()
        val screenH = constraints.maxHeight.toFloat()
        val raw = if (s?.target != null) TourRegistry.rects[s.target] else null
        val pad = with(density) { 6.dp.toPx() }
        val hole: Rect? = raw?.let {
            Rect(
                (it.left - origin.x - pad).coerceAtLeast(0f),
                (it.top - origin.y - pad).coerceAtLeast(0f),
                (it.right - origin.x + pad).coerceAtMost(screenW),
                (it.bottom - origin.y + pad).coerceAtMost(screenH),
            )
        }

        // escurece tudo, deixando um buraco no ponto explicado
        Canvas(
            Modifier
                .fillMaxSize()
                .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen },
        ) {
            drawRect(Color.Black.copy(alpha = if (current < 0) 0.6f else 0.62f))
            if (hole != null) {
                val corner = CornerRadius(16.dp.toPx())
                drawRoundRect(
                    color = Color.Black, topLeft = Offset(hole.left, hole.top),
                    size = Size(hole.width, hole.height), cornerRadius = corner, blendMode = BlendMode.Clear,
                )
                drawRoundRect(
                    color = Color.White.copy(alpha = pulse), topLeft = Offset(hole.left, hole.top),
                    size = Size(hole.width, hole.height), cornerRadius = corner,
                    style = Stroke(width = 3.dp.toPx()),
                )
            }
        }

        // bloqueia os toques fora do buraco (dentro dele o toque passa para o app, em simulação)
        if (hole == null) {
            Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } })
        } else {
            Blocker(0f, 0f, screenW, hole.top)
            Blocker(0f, hole.bottom, screenW, screenH - hole.bottom)
            Blocker(0f, hole.top, hole.left, hole.height)
            Blocker(hole.right, hole.top, screenW - hole.right, hole.height)
        }

        // faixa de simulação
        Text(
            "🧪 Simulação · nada é salvo",
            color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier
                .align(Alignment.TopCenter)
                .statusBarsPadding()
                .padding(top = 4.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF334155))
                .padding(horizontal = 10.dp, vertical = 3.dp),
        )

        if (current < 0 || s == null) {
            // convite inicial
            Column(
                Modifier
                    .align(Alignment.Center)
                    .padding(24.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(g.card)
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    CloseButton { close() }
                }
                Text("🙋‍♀️", fontSize = 40.sp)
                Text(
                    "Quer aprender tudo do Gluco Cris?",
                    color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp,
                    textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp),
                )
                Text(
                    "Eu falo, aponto cada ponto da tela e você pode tocar para testar. É uma simulação: nada do que você fizer será salvo.",
                    color = g.muted, fontSize = 14.sp, lineHeight = 20.sp,
                    textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp, bottom = 16.dp),
                )
                TourButton("Sim, me ensine", filled = true, modifier = Modifier.fillMaxWidth()) { startSmartTour(vm) }
                TourButton("Agora não", filled = false, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) { close() }
            }
        } else {
            val targetCenterY = hole?.let { (it.top + it.bottom) / 2f } ?: (screenH * 0.8f)
            val cardAtTop = hole != null && targetCenterY > screenH * 0.5f
            val last = current >= tourEnd
            Column(
                Modifier
                    .align(if (cardAtTop) Alignment.TopCenter else Alignment.BottomCenter)
                    .then(if (cardAtTop) Modifier.statusBarsPadding().padding(top = 30.dp) else Modifier.navigationBarsPadding().padding(bottom = 92.dp))
                    .padding(horizontal = 16.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(22.dp))
                    .background(g.card)
                    .padding(16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(g.lilacSoft), contentAlignment = Alignment.Center) {
                        Text(s.emoji, fontSize = 22.sp)
                    }
                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                        Text(s.title, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                        Text("Passo ${current - tourStart + 1} de ${tourEnd - tourStart + 1}", color = g.muted, fontSize = 11.sp)
                    }
                    Box(
                        Modifier.size(34.dp).clip(CircleShape).background(g.lilacSoft)
                            .clickable { vm.setTourVoice(!voiceOn) },
                        contentAlignment = Alignment.Center,
                    ) { Text(if (voiceOn) "🔊" else "🔇", fontSize = 16.sp) }
                    Box(Modifier.padding(start = 8.dp)) { CloseButton { close() } }
                }
                Column(Modifier.padding(top = 10.dp).verticalScroll(rememberScrollState())) {
                    Text(s.speak, color = g.ink, fontSize = 14.sp, lineHeight = 20.sp)
                    s.tips.forEach { tip ->
                        Text("• $tip", color = g.muted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 4.dp))
                    }
                    s.tapHint?.let {
                        Text(
                            "👆 $it",
                            color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                            modifier = Modifier.padding(top = 10.dp).clip(RoundedCornerShape(10.dp))
                                .background(g.lilacSoft).padding(horizontal = 10.dp, vertical = 6.dp),
                        )
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (current > tourStart) {
                        TourButton("Voltar", filled = false, modifier = Modifier.weight(1f)) { vm.setTourStep(current - 1) }
                    }
                    TourButton(if (last) "Concluir" else "Próximo", filled = true, modifier = Modifier.weight(1f)) {
                        if (last) close() else vm.setTourStep(current + 1)
                    }
                }
            }
        }
    }
}

@Composable
private fun Blocker(x: Float, y: Float, w: Float, h: Float) {
    if (w <= 0f || h <= 0f) return
    val density = LocalDensity.current
    Box(
        Modifier
            .offset { IntOffset(x.toInt(), y.toInt()) }
            .size(with(density) { w.toDp() }, with(density) { h.toDp() })
            .pointerInput(Unit) { detectTapGestures { } },
    )
}

@Composable
private fun CloseButton(onClick: () -> Unit) {
    val g = glucoColors()
    Box(
        Modifier.size(34.dp).clip(CircleShape).background(g.lilacSoft).clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Filled.Close, "Cancelar ajuda", tint = g.violet, modifier = Modifier.size(20.dp))
    }
}

@Composable
private fun TourButton(text: String, filled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val g = glucoColors()
    Box(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .background(if (filled) g.violet else g.lilacSoft)
            .clickable(onClick = onClick)
            .padding(vertical = 13.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            text,
            color = if (filled) Color.White else g.violet,
            fontWeight = FontWeight.ExtraBold,
            fontSize = 14.sp,
        )
    }
}
