package com.agon.app.insights

import com.agon.app.data.AppData
import com.agon.app.data.GlucoseEntry
import com.agon.app.data.Hba1cEntry
import com.agon.app.data.Settings
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.junit.Assert.*
import org.junit.Test
import java.util.Calendar

class Hba1cTest {
    private val DAY = Insights.DAY_MS
    private val now = Calendar.getInstance().apply { set(2026, Calendar.NOVEMBER, 13, 15, 0, 0) }.timeInMillis
    private fun lab(id: String, pct: Double, daysAgo: Int, lab: String = "") =
        Hba1cEntry(id, pct, now - daysAgo * DAY, lab, "", now, now)

    // ── Entrada e validação ───────────────────────────────────────────
    @Test fun parse_acceptsCommaAndDotAndPercentSign() {
        assertEquals(7.2, Hba1cRules.parsePercent("7,2")!!, 1e-9)
        assertEquals(7.2, Hba1cRules.parsePercent(" 7.2 % ")!!, 1e-9)
        assertEquals(10.0, Hba1cRules.parsePercent("10")!!, 1e-9)
    }

    @Test fun parse_rejectsGarbage() {
        assertNull(Hba1cRules.parsePercent(""))
        assertNull(Hba1cRules.parsePercent("abc"))
        assertNull(Hba1cRules.parsePercent("7,2,1"))
        assertNull(Hba1cRules.parsePercent("-7"))
        assertNull(Hba1cRules.parsePercent("7,234"))
        assertNull(Hba1cRules.parsePercent("1e1"))
    }

    @Test fun validatePercent_range() {
        assertNull(Hba1cRules.validatePercent("5,7"))
        assertNotNull(Hba1cRules.validatePercent("2,9"))
        assertNotNull(Hba1cRules.validatePercent("20,1"))
        assertNotNull(Hba1cRules.validatePercent(""))
        assertNull(Hba1cRules.validatePercent("3"))
        assertNull(Hba1cRules.validatePercent("20"))
        assertNotNull(Hba1cRules.validateValue(Double.NaN))
    }

    @Test fun validateDate_noFutureNoAncient() {
        assertNull(Hba1cRules.validateDate(now, now))
        assertNotNull(Hba1cRules.validateDate(now + 2 * DAY, now))
        assertNotNull(Hba1cRules.validateDate(0L, now))
        // Mais tarde no mesmo dia ainda é "hoje"
        assertNull(Hba1cRules.validateDate(Hba1cRules.noonOf(2026, Calendar.NOVEMBER, 13), now))
    }

    @Test fun showPercent_keepsEnteredPrecision() {
        assertEquals("7,2", Hba1cRules.showPercent(7.2))
        assertEquals("7,25", Hba1cRules.showPercent(7.25))
        assertEquals("6,0", Hba1cRules.showPercent(6.0))
    }

    // ── Histórico ─────────────────────────────────────────────────────
    @Test fun history_deltasComparedWithPreviousExam() {
        val list = listOf(lab("c", 7.0, 10), lab("a", 8.0, 200), lab("b", 7.4, 100))
        val rows = Hba1cHistory.rows(list)
        assertEquals(listOf("c", "b", "a"), rows.map { it.entry.id }) // mais recente primeiro
        assertEquals(Hba1cDirection.FIRST, rows[2].direction)
        assertNull(rows[2].deltaPp)
        assertEquals(Hba1cDirection.DOWN, rows[1].direction)
        assertEquals(-0.6, rows[1].deltaPp!!, 1e-9)
        assertEquals(Hba1cDirection.DOWN, rows[0].direction)
        assertEquals(-0.4, rows[0].deltaPp!!, 1e-9)
        assertEquals("b", rows[0].previous!!.id)
    }

    @Test fun history_upAndSame() {
        val rows = Hba1cHistory.rows(listOf(lab("a", 6.0, 200), lab("b", 6.8, 100), lab("c", 6.82, 10)))
        assertEquals(Hba1cDirection.UP, rows[1].direction)
        assertEquals(Hba1cDirection.SAME, rows[0].direction)
        assertEquals("sem variação", Hba1cHistory.deltaText(rows[0].deltaPp))
        assertEquals("+0,8 p.p.", Hba1cHistory.deltaText(rows[1].deltaPp))
        assertEquals("primeiro exame", Hba1cHistory.deltaText(null))
    }

    @Test fun history_empty() {
        assertTrue(Hba1cHistory.rows(emptyList()).isEmpty())
        assertNull(Hba1cHistory.latest(emptyList()))
        assertNull(Hba1cHistory.trend(emptyList()))
    }

    @Test fun trend_needsTwoExams() {
        assertNull(Hba1cHistory.trend(listOf(lab("a", 7.0, 1))))
        assertEquals(Hba1cDirection.UP, Hba1cHistory.trend(listOf(lab("a", 6.0, 100), lab("b", 7.0, 1))))
    }

    @Test fun chartPoints_onlyLabEntriesInOrder_lastN() {
        val l = listOf(lab("c", 7.0, 10), lab("a", 8.0, 300), lab("b", 7.4, 100))
        assertEquals(listOf("a", "b", "c"), Hba1cHistory.chartPoints(l).map { it.id })
        assertEquals(listOf("b", "c"), Hba1cHistory.chartPoints(l, 2).map { it.id })
    }

    // ── GMI x HbA1c: nunca misturados ─────────────────────────────────
    private fun glucose(n: Int, mg: Double, spanDays: Int): List<GlucoseEntry> = (0 until n).map { i ->
        val at = now - (i * spanDays / n.coerceAtLeast(1)) * DAY - (i % 5) * 3_600_000L
        GlucoseEntry("m$i", mg, "mg/dL", at, "outro", updatedAt = at)
    }

    @Test fun gmiFormula_isUnchanged() {
        val st = Insights.stats(Insights.readings(AppData(glucose = glucose(40, 150.0, 20), settings = Settings()), 90, now), 70, 180)!!
        assertEquals(3.31 + 0.02392 * 150.0, st.gmi, 1e-9)
    }

    @Test fun compare_labAndGmiAreSeparateValues() {
        val data = AppData(glucose = glucose(40, 150.0, 20), hba1c = listOf(lab("x", 7.0, 5)), settings = Settings())
        val c = Hba1cCompare.compute(data, now)
        assertEquals(7.0, c.lab!!.percent, 1e-9)
        assertTrue(c.gmiAvailable)
        assertEquals(3.31 + 0.02392 * 150.0, c.gmi!!, 1e-9)
        assertEquals(c.gmi!! - 7.0, c.diffPp!!, 1e-9)
        assertEquals(150.0, c.meanMg!!, 1e-9)
        assertTrue(c.disclaimer.contains("não são equivalentes"))
        // O GMI não vira exame: a lista de exames continua só com o laudo.
        assertEquals(1, data.hba1c.size)
    }

    @Test fun compare_insufficientData_noGmiNoDiff() {
        val data = AppData(glucose = glucose(3, 150.0, 2), hba1c = listOf(lab("x", 7.0, 5)), settings = Settings())
        val c = Hba1cCompare.compute(data, now)
        assertFalse(c.gmiAvailable)
        assertNull(c.gmi)
        assertNull(c.diffPp)
        assertTrue(c.gmiUnavailableReason.isNotBlank())
        assertNotNull(c.lab)
    }

    @Test fun compare_noGlucose_noLab() {
        val c = Hba1cCompare.compute(AppData(settings = Settings()), now)
        assertNull(c.lab); assertNull(c.gmi); assertNull(c.meanMg); assertNull(c.diffPp)
        assertEquals(0, c.readings)
    }

    @Test fun compare_demoReadingsIgnored() {
        val demo = (0 until 30).map { GlucoseEntry("demo-$it", 300.0, "mg/dL", now - it * DAY / 2, "outro", updatedAt = now) }
        val c = Hba1cCompare.compute(AppData(glucose = demo, settings = Settings()), now)
        assertNull(c.gmi); assertEquals(0, c.readings)
    }

    @Test fun compare_oldExamGetsPeriodNote() {
        val data = AppData(glucose = glucose(40, 150.0, 20), hba1c = listOf(lab("x", 7.0, 200)), settings = Settings())
        assertTrue(Hba1cCompare.compute(data, now).periodNote.isNotBlank())
        val recent = AppData(glucose = glucose(40, 150.0, 20), hba1c = listOf(lab("x", 7.0, 10)), settings = Settings())
        assertTrue(Hba1cCompare.compute(recent, now).periodNote.isBlank())
    }

    // ── Meta configurável ─────────────────────────────────────────────
    @Test fun goal_validationAndNeutralText() {
        assertNull(Hba1cGoal.validate("7,0"))
        assertNotNull(Hba1cGoal.validate("3"))
        assertNotNull(Hba1cGoal.validate("abc"))
        val above = Hba1cGoal.describe(8.0, 7.0).lowercase()
        assertFalse(above.contains("dose")); assertFalse(above.contains("insulina")); assertFalse(above.contains("diagnóstico de"))
    }

    // ── Lembretes ─────────────────────────────────────────────────────
    @Test fun reminder_intervalFromLastExam() {
        val last = Hba1cRules.noonOf(2026, Calendar.OCTOBER, 1)
        val t = Hba1cReminderPlan.nextTrigger(Hba1cReminderPlan.MODE_INTERVAL, 3, 0L, last, now)!!
        val c = Calendar.getInstance().apply { timeInMillis = t }
        assertEquals(2027, c.get(Calendar.YEAR)) // 2026-10-01 + 3 meses = 2027-01-01
        assertEquals(Calendar.JANUARY, c.get(Calendar.MONTH))
        assertEquals(9, c.get(Calendar.HOUR_OF_DAY))
        assertTrue(t > now)
    }

    @Test fun reminder_overdueInterval_firesSoonNotNever() {
        val t = Hba1cReminderPlan.nextTrigger(Hba1cReminderPlan.MODE_INTERVAL, 1, 0L, now - 400 * DAY, now)!!
        assertTrue(t > now && t - now <= 120_000L)
    }

    @Test fun reminder_noExamStartsFromNow() {
        val t = Hba1cReminderPlan.nextTrigger(Hba1cReminderPlan.MODE_INTERVAL, 2, 0L, null, now)!!
        assertTrue(t > now + 50 * DAY)
    }

    @Test fun reminder_dateModePastIsNull_futureOk() {
        assertNull(Hba1cReminderPlan.nextTrigger(Hba1cReminderPlan.MODE_DATE, 3, now - DAY, null, now))
        assertNull(Hba1cReminderPlan.nextTrigger(Hba1cReminderPlan.MODE_DATE, 3, 0L, null, now))
        assertNotNull(Hba1cReminderPlan.nextTrigger(Hba1cReminderPlan.MODE_DATE, 3, now + 10 * DAY, null, now))
    }

    @Test fun reminder_invalidInputsGiveNull() {
        assertNull(Hba1cReminderPlan.nextTrigger("x", 3, 0L, null, now))
        assertNull(Hba1cReminderPlan.nextTrigger(Hba1cReminderPlan.MODE_INTERVAL, 0, 0L, null, now))
        assertNull(Hba1cReminderPlan.nextTrigger(Hba1cReminderPlan.MODE_INTERVAL, 25, 0L, null, now))
    }

    // ── Persistência (serialização) ───────────────────────────────────
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true; coerceInputValues = true }

    @Test fun serialization_roundTripKeepsExams() {
        val d = AppData(hba1c = listOf(lab("x", 7.25, 5, "Lab Central")), settings = Settings())
        val back = json.decodeFromString<AppData>(json.encodeToString(d))
        assertEquals(1, back.hba1c.size)
        assertEquals(7.25, back.hba1c[0].percent, 1e-9)
        assertEquals("Lab Central", back.hba1c[0].lab)
    }

    @Test fun serialization_oldDataWithoutHba1cStillLoads() {
        val old = """{"glucose":[],"insulin":[],"reminders":[],"meals":[],"symptoms":[],"medications":[],"tombstones":[]}"""
        val d = json.decodeFromString<AppData>(old)
        assertTrue(d.hba1c.isEmpty())
    }
}
