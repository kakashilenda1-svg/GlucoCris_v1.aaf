package com.agon.app.reminders

import org.junit.Assert.*
import org.junit.Test

class CaregiverRulesTest {
    // ── Valores padrão preservados ────────────────────────────────────
    @Test fun defaults_arePreserved() {
        assertEquals(listOf(45, 54, 60, 70), CaregiverRules.LOW_DEFAULTS)
        assertEquals(listOf(250, 300, 350, 400), CaregiverRules.HIGH_DEFAULTS)
        assertEquals(54, CaregiverRules.DEFAULT_LOW)
        assertEquals(300, CaregiverRules.DEFAULT_HIGH)
        assertEquals(30, CaregiverRules.DEFAULT_REPEAT_MIN) // comportamento anterior
        // Todo padrão antigo continua dentro das faixas aceitas
        assertTrue(CaregiverRules.LOW_DEFAULTS.all { it in CaregiverRules.LOW_MIN..CaregiverRules.LOW_MAX })
        assertTrue(CaregiverRules.HIGH_DEFAULTS.all { it in CaregiverRules.HIGH_MIN..CaregiverRules.HIGH_MAX })
    }

    // ── Limite baixo personalizado ────────────────────────────────────
    @Test fun low_validCustom() {
        assertNull(CaregiverRules.validateLow("52", targetLow = 70, severeHigh = 300))
        assertNull(CaregiverRules.validateLow("70", targetLow = 70, severeHigh = 300))
    }

    @Test fun low_invalidInputs() {
        assertNotNull(CaregiverRules.validateLow("", 70, 300))
        assertNotNull(CaregiverRules.validateLow("abc", 70, 300))
        assertNotNull(CaregiverRules.validateLow("5,5", 70, 300))
        assertNotNull(CaregiverRules.validateLow("-10", 70, 300))
        assertNotNull(CaregiverRules.validateLow("1000", 70, 300))
        assertNotNull(CaregiverRules.validateLow("29", 70, 300))
        assertNotNull(CaregiverRules.validateLow("101", 120, 300))
    }

    @Test fun low_cannotExceedTargetOrHigh() {
        assertNotNull(CaregiverRules.validateLow("80", targetLow = 70, severeHigh = 300))
        assertNotNull(CaregiverRules.validateLow("60", targetLow = 70, severeHigh = 60))
    }

    // ── Limite alto personalizado ─────────────────────────────────────
    @Test fun high_validCustom() {
        assertNull(CaregiverRules.validateHigh("280", targetHigh = 180, severeLow = 54))
        assertNull(CaregiverRules.validateHigh("180", targetHigh = 180, severeLow = 54))
    }

    @Test fun high_invalidInputs() {
        assertNotNull(CaregiverRules.validateHigh("", 180, 54))
        assertNotNull(CaregiverRules.validateHigh("x", 180, 54))
        assertNotNull(CaregiverRules.validateHigh("149", 140, 54))
        assertNotNull(CaregiverRules.validateHigh("601", 180, 54))
        assertNotNull(CaregiverRules.validateHigh("170", targetHigh = 180, severeLow = 54))
    }

    @Test fun lowAndHigh_areIndependent() {
        // Mudar um limite não invalida o outro: cada um só depende do valor atual do outro
        assertNull(CaregiverRules.validateLow("50", 70, 250))
        assertNull(CaregiverRules.validateHigh("350", 180, 50))
    }

    // ── Quando alertar ────────────────────────────────────────────────
    @Test fun kindOf_strictComparisons() {
        assertEquals(CaregiverRules.Kind.LOW, CaregiverRules.kindOf(53.9, 54, 300))
        assertNull(CaregiverRules.kindOf(54.0, 54, 300)) // igual ao limite: não alerta (comportamento original)
        assertNull(CaregiverRules.kindOf(300.0, 54, 300))
        assertEquals(CaregiverRules.Kind.HIGH, CaregiverRules.kindOf(300.1, 54, 300))
        assertNull(CaregiverRules.kindOf(120.0, 54, 300))
    }

    @Test fun customLimitAppliesImmediately() {
        assertNull(CaregiverRules.kindOf(58.0, 54, 300))
        assertEquals(CaregiverRules.Kind.LOW, CaregiverRules.kindOf(58.0, 60, 300)) // limite novo = 60
    }

    // ── Repetição / duplicados ────────────────────────────────────────
    @Test fun repeat_blocksConsecutiveReadingsInsideInterval() {
        val t0 = 1_000_000_000L
        assertTrue(CaregiverRules.repeatAllowed(t0, 0L, 30))
        assertFalse(CaregiverRules.repeatAllowed(t0 + 5 * 60_000L, t0, 30))
        assertFalse(CaregiverRules.repeatAllowed(t0 + 29 * 60_000L, t0, 30))
        assertTrue(CaregiverRules.repeatAllowed(t0 + 30 * 60_000L, t0, 30))
        assertFalse(CaregiverRules.repeatAllowed(t0 + 59 * 60_000L, t0, 60))
        assertTrue(CaregiverRules.repeatAllowed(t0 + 60 * 60_000L, t0, 60))
    }

    @Test fun repeat_clockGoingBackwardsDoesNotMuteForever() {
        assertTrue(CaregiverRules.repeatAllowed(1_000L, 9_999_999_999L, 30))
    }

    // ── Telefone ──────────────────────────────────────────────────────
    @Test fun phone_validBrazil() {
        assertEquals("5511999998888", CaregiverRules.checkPhone("+55 (11) 99999-8888").digits)
        assertTrue(CaregiverRules.checkPhone("5511999998888").ok)
        assertTrue(CaregiverRules.checkPhone("551133334444").ok) // fixo
    }

    @Test fun phone_brazilWithoutCountryCodeIsRejectedWithHint() {
        val r = CaregiverRules.checkPhone("11999998888")
        assertFalse(r.ok)
        assertTrue(r.error!!.contains("55"))
        assertFalse(CaregiverRules.checkPhone("1133334444").ok)
    }

    @Test fun phone_invalid() {
        assertFalse(CaregiverRules.checkPhone("").ok)
        assertFalse(CaregiverRules.checkPhone("abc").ok)
        assertFalse(CaregiverRules.checkPhone("123").ok)
        assertFalse(CaregiverRules.checkPhone("1".repeat(16)).ok)
        assertFalse(CaregiverRules.checkPhone("5500999998888").ok) // DDD 00
        assertFalse(CaregiverRules.checkPhone("5511899998888").ok) // celular de 9 dígitos sem iniciar em 9
        assertFalse(CaregiverRules.checkPhone("55119999988").ok)   // curto demais para o Brasil
    }

    @Test fun phone_internationalAccepted() {
        assertTrue(CaregiverRules.checkPhone("+1 555 123 4567").ok)
        assertTrue(CaregiverRules.checkPhone("351912345678").ok)
        assertEquals("351912345678", CaregiverRules.checkPhone("00351912345678").digits)
    }

    @Test fun phone_display() {
        assertEquals("+55 11 99999-8888", CaregiverRules.display("5511999998888"))
        assertEquals("+55 11 3333-4444", CaregiverRules.display("551133334444"))
        assertEquals("+351912345678", CaregiverRules.display("351912345678"))
    }
}
