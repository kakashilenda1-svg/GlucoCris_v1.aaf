package com.agon.app.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.formatDateTime
import com.agon.app.data.formatLongDate
import com.agon.app.data.greeting
import com.agon.app.data.rangeStatus
import com.agon.app.data.statusLabel
import com.agon.app.data.toMgDl
import com.agon.app.data.weekdayLong
import com.agon.app.love.LOVE_PHONE_DISPLAY
import com.agon.app.love.LOVE_PHONE_TEL
import com.agon.app.love.MAIN_LOVE_MESSAGE
import com.agon.app.love.SAMU_TEL
import com.agon.app.love.openDialer
import com.agon.app.love.openWhatsApp
import com.agon.app.love.phraseForToday
import com.agon.app.ui.components.ActionButton
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GlucoseChart
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.components.tourTarget
import com.agon.app.ui.theme.glucoColors
import kotlin.math.roundToInt
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.ChatBubble
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.style.TextOverflow
import androidx.core.view.WindowCompat
import com.agon.app.data.HomeLayoutStore
import com.agon.app.ui.theme.BlueDarkGlucoColors
import com.agon.app.ui.theme.DarkGlucoColors
import com.agon.app.ui.theme.LocalGluco

@Composable
fun HomeScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val context = LocalContext.current
    val settings = data.settings
    var phrase by remember { mutableStateOf("") }
    var showMood by remember { mutableStateOf(false) }
    var waterBarVisible by remember { mutableStateOf(true) }
    val scrollWatcher = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -6f) waterBarVisible = false
                else if (available.y > 6f) waterBarVisible = true
                return Offset.Zero
            }
        }
    }
    LaunchedEffect(Unit) { phrase = phraseForToday(context) }
    if (showMood) {
        MoodSheet(settings.mood, settings.moodStyle, { st -> vm.updateSettings { it.copy(moodStyle = st) } }, onDismiss = { showMood = false }) { id ->
            vm.updateSettings { it.copy(mood = id, moodAt = System.currentTimeMillis()) }
            showMood = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val latest = data.glucose.maxByOrNull { it.at }
    val mg = latest?.let { toMgDl(it.value, it.unit) }
    val status = mg?.let { rangeStatus(it, settings.targetLow, settings.targetHigh) }
    val pinkLayout = HomeLayoutStore.pink

    // A tela inicial é sempre escura nos dois layouts: ícones claros na barra de status enquanto estiver aqui.
    val view = LocalView.current
    if (!view.isInEditMode) {
        DisposableEffect(Unit) {
            val ctrl = (view.context as? android.app.Activity)?.window?.let { WindowCompat.getInsetsController(it, view) }
            val previous = ctrl?.isAppearanceLightStatusBars
            onDispose { if (ctrl != null && previous != null) ctrl.isAppearanceLightStatusBars = previous }
        }
        SideEffect {
            (view.context as? android.app.Activity)?.window?.let { WindowCompat.getInsetsController(it, view).isAppearanceLightStatusBars = false }
        }
    }

    Crossfade(targetState = pinkLayout, animationSpec = tween(260), label = "homeLayout") { isPink ->
        val p = homePalette(isPink)
        val gd = if (isPink) DarkGlucoColors else BlueDarkGlucoColors
        val statusColor = when (status) {
            "ok" -> Color(0xFF22E58B)
            "low" -> gd.orange
            "high" -> gd.red
            else -> gd.muted
        }
        CompositionLocalProvider(LocalGluco provides gd) {
        HomeBackdrop(p) {
        Box(Modifier.fillMaxSize().nestedScroll(scrollWatcher)) {
        ScrollScreen {
            // ── Topo: título, botão de troca de layout, ajuda ──
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                    Text("Gluco Cris", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
                    if (isPink) Icon(Icons.Filled.Favorite, null, tint = Color(0xFFFF4FA8), modifier = Modifier.padding(start = 6.dp).size(18.dp))
                }
                // Botão circular: alterna entre o layout azul e o rosa/roxo (somente visual, salvo no aparelho).
                Box(
                    Modifier
                        .padding(end = 10.dp)
                        .size(40.dp)
                        .tourTarget("home_theme")
                        .clip(CircleShape)
                        .background(Brush.radialGradient(listOf(Color(0xFF2F6BFF), Color(0xFF0B1F5C))))
                        .border(2.dp, Color(0xFF6CC4FF), CircleShape)
                        .clickable { HomeLayoutStore.toggle(context) },
                )
                Box(
                    Modifier
                        .size(40.dp)
                        .tourTarget("home_help")
                        .clip(CircleShape)
                        .background(Brush.radialGradient(listOf(p.accent.copy(alpha = 0.65f), p.panelA)))
                        .border(1.5.dp, p.panelBorder.copy(alpha = 0.9f), CircleShape)
                        .clickable { nav.navigate(Routes.HELP_CENTER) },
                    contentAlignment = Alignment.Center,
                ) {
                    Text("?", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                }
            }

            // ── Robô + saudação + humor ──
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                CrisRobot(isPink, Modifier.width(158.dp).height(182.dp))
                Column(Modifier.weight(1f).padding(start = 6.dp)) {
                    Text(
                        com.agon.app.data.firstName(settings.displayName).let { first ->
                            if (first.isNotBlank()) "${greeting()}, $first!" else "${greeting()}!"
                        },
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 26.sp,
                        lineHeight = 30.sp,
                    )
                    MoodButton(settings.mood, settings.moodStyle == "bruxo") { showMood = true }
                    Text(
                        "${weekdayLong().replaceFirstChar { it.uppercase() }}, ${formatLongDate()}",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 6.dp),
                    )
                }
            }

            // ── Última medição + estatísticas de 7 dias ──
            val weekMs = 7L * 24 * 60 * 60 * 1000
            val since = System.currentTimeMillis() - weekMs
            val weekG = data.glucose.filter { it.at >= since }
            val weekI = data.insulin.filter { it.at >= since }
            val inRange = weekG.count {
                val mgv = toMgDl(it.value, it.unit)
                mgv >= settings.targetLow && mgv <= settings.targetHigh
            }
            val pct = if (weekG.isNotEmpty()) inRange * 100 / weekG.size else null

            Row(Modifier.fillMaxWidth().padding(top = 8.dp).height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomePanel(p, Modifier.weight(1.2f).fillMaxHeight()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        HomeIconBubble(p, Icons.Filled.WaterDrop)
                        Text("Última medição", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(start = 8.dp))
                    }
                    if (latest == null || mg == null || status == null) {
                        Text("Nenhuma medição ainda.", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                    } else {
                        Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(top = 4.dp)) {
                            Text(mg.roundToInt().toString(), color = statusColor, fontWeight = FontWeight.ExtraBold, fontSize = 46.sp)
                            Text(" mg/dL", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(bottom = 10.dp, start = 4.dp))
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(if (status == "ok") Icons.Filled.CheckCircle else Icons.Filled.Warning, null, tint = statusColor, modifier = Modifier.size(22.dp))
                            Text(statusLabel(status), color = statusColor, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.padding(start = 6.dp))
                        }
                        Text(
                            "${GLUCOSE_CONTEXT_LABEL[latest.context] ?: latest.context} · ${formatDateTime(latest.at)}",
                            color = Color.White.copy(alpha = 0.92f),
                            fontSize = 11.sp,
                            lineHeight = 14.sp,
                            modifier = Modifier.padding(top = 6.dp),
                        )
                    }
                }
                HomePanel(p, Modifier.weight(0.8f).fillMaxHeight().clickable { nav.navigate(Routes.CRIS_IA) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        HomeIconBubble(p, Icons.Filled.BarChart)
                        Column(Modifier.padding(start = 8.dp)) {
                            Text("Glicemias", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("(7 dias)", color = Color.White, fontSize = 12.sp)
                        }
                    }
                    Text(weekG.size.toString(), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp, modifier = Modifier.padding(start = 42.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                        HomeIconBubble(p, Icons.Filled.Vaccines)
                        Column(Modifier.padding(start = 8.dp)) {
                            Text("Insulinas", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("(7 dias)", color = Color.White, fontSize = 12.sp)
                        }
                    }
                    Text(weekI.size.toString(), color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp, modifier = Modifier.padding(start = 42.dp))
                    if (pct != null) Text("$pct% na meta", color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                }
            }

            // ── Uma mensagem para você ──
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(p.msgBg)
                    .padding(16.dp),
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isPink) Icon(Icons.Filled.Favorite, null, tint = Color(0xFFE11D2E), modifier = Modifier.size(26.dp))
                    else Icon(Icons.Filled.ChatBubble, null, tint = p.msgTitle, modifier = Modifier.size(26.dp))
                    Text("Uma mensagem para você", color = p.msgTitle, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, modifier = Modifier.padding(start = 10.dp))
                    if (isPink) Icon(Icons.Filled.Favorite, null, tint = Color(0xFFE11D2E), modifier = Modifier.padding(start = 10.dp).size(26.dp))
                }
                Text(MAIN_LOVE_MESSAGE, color = p.msgInk, fontSize = 15.sp, lineHeight = 22.sp, fontWeight = if (isPink) FontWeight.SemiBold else FontWeight.Normal, modifier = Modifier.padding(top = 8.dp))
                if (phrase.isNotEmpty()) {
                    Text(phrase, color = p.msgTitle, fontSize = 13.sp, fontStyle = FontStyle.Italic, lineHeight = 19.sp, modifier = Modifier.padding(top = 10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                        Icon(Icons.Outlined.FavoriteBorder, null, tint = p.msgInk, modifier = Modifier.size(20.dp))
                        Text("Frase carinhosa de hoje", color = p.msgInk, fontSize = 13.sp, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }

            // ── Conversar com a Cris IA ──
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp)
                    .clip(RoundedCornerShape(22.dp))
                    .background(Brush.horizontalGradient(listOf(p.ctaA, p.ctaB)))
                    .border(1.dp, p.panelBorder.copy(alpha = 0.6f), RoundedCornerShape(22.dp))
                    .clickable { nav.navigate(Routes.CRIS_IA) }
                    .padding(horizontal = 16.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                CrisRobot(isPink, Modifier.size(64.dp), headOnly = true)
                Column(Modifier.padding(start = 14.dp).weight(1f)) {
                    Text("Conversar com a Cris IA", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 17.sp)
                    Text("Sua assistente de cuidado", color = Color.White.copy(alpha = 0.92f), fontSize = 13.sp)
                }
                Icon(Icons.Filled.ChevronRight, null, tint = Color.White, modifier = Modifier.size(32.dp))
            }

            // Atalhos de registro mantidos, posicionados depois dos cartões de destaque.
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton("Registrar glicose", Icons.Filled.WaterDrop, p.ctaB, { nav.navigate(Routes.glucoseForm(null)) }, Modifier.weight(1f))
                ActionButton("Registrar insulina", Icons.Filled.WaterDrop, p.ctaA, { nav.navigate(Routes.insulinForm(null)) }, Modifier.weight(1f))
            }

            // ── Demais recursos da tela inicial (inalterados) ──
            Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(
                    " Ligar para meu amor ❤️",
                    Icons.Filled.Call,
                    p.ctaB,
                    { openDialer(context, LOVE_PHONE_TEL) },
                    Modifier.weight(1f),
                )
            }
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton(
                    "falar com amor por WhatsApp ",
                    Icons.Filled.Favorite,
                    if (isPink) Color(0xFFDB2777) else p.ctaA,
                    { openWhatsApp(context) },
                    Modifier.weight(1f),
                )
            }
            Text(
                "A ligação não começa sozinha: o discador abre com $LOVE_PHONE_DISPLAY para você confirmar. O WhatsApp só abre a conversa, sem enviar mensagem.",
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 6.dp, start = 4.dp, end = 4.dp),
            )

            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(top = 14.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(gd.red)
                    .clickable { openDialer(context, SAMU_TEL) }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.LocalHospital, null, tint = Color.White)
                Column(Modifier.padding(start = 12.dp).weight(1f)) {
                    Text(" Emergência — SAMU 192", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                    Text(
                        "Abre o discador com 192. Não aciona o atendimento sozinho e não garante que a chamada seja completada.",
                        color = Color.White.copy(alpha = 0.92f),
                        fontSize = 12.sp,
                    )
                }
            }

            SectionTitle("Evolução", "Ver estatísticas") { nav.navigate(Routes.STATS) }
            GCard { GlucoseChart(data.glucose, settings.targetLow, settings.targetHigh) }

            val active = data.reminders.filter { it.enabled }.sortedWith(compareBy({ it.hour }, { it.minute }))
            SectionTitle("Próximo lembrete", "Ver todos") { Routes.goTab(nav, Routes.REMINDERS) }
            GCard {
                if (active.isEmpty()) {
                    Text("Nenhum lembrete ativo.", color = gd.muted, fontSize = 14.sp)
                } else {
                    active.take(3).forEach { r ->
                        Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                            Text(r.title, color = gd.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                            Text(
                                "${com.agon.app.data.formatClock(r.hour, r.minute)} · ${com.agon.app.data.daysLabel(r.days)}",
                                color = gd.muted,
                                fontSize = 12.sp,
                            )
                            Text(
                                (if (r.kind == "glicose") "Medição de glicose" else "Aplicação de insulina") +
                                    if (r.notes.isNotEmpty()) " · ${r.notes}" else "",
                                color = gd.violetDeep,
                                fontSize = 12.sp,
                            )
                        }
                    }
                }
            }

            SectionTitle("Histórico resumido", "Ver todos") { Routes.goTab(nav, Routes.HISTORY) }
            GCard {
                val recent = data.glucose.sortedByDescending { it.at }.take(4)
                if (recent.isEmpty()) {
                    Text("Sem registros.", color = gd.muted, modifier = Modifier.padding(12.dp))
                } else {
                    recent.forEach { e ->
                        val v = toMgDl(e.value, e.unit)
                        val st = rangeStatus(v, settings.targetLow, settings.targetHigh)
                        val c = when (st) { "ok" -> gd.green; "low" -> gd.orange; else -> gd.red }
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clickable { nav.navigate(Routes.glucoseForm(e.id)) }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(v.roundToInt().toString(), color = c, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.padding(end = 10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(GLUCOSE_CONTEXT_LABEL[e.context] ?: e.context, color = gd.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("${com.agon.app.data.formatDate(e.at)} · ${com.agon.app.data.formatTime(e.at)}", color = gd.muted, fontSize = 12.sp)
                            }
                            Text(statusLabel(st), color = c, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Spacer(Modifier.height(64.dp))
        }
        Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
            WaterMiniBar(
                visible = waterBarVisible,
                onOpenFull = { nav.navigate(Routes.WATER) },
                modifier = Modifier.tourTarget("home_water"),
            )
        }
        }
        }
        }
    }
}

/** Painel translúcido dos cartões "Última medição" e "Estatísticas". */
@Composable
private fun HomePanel(p: HomePalette, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .clip(shape)
            .background(Brush.verticalGradient(listOf(p.panelA, p.panelB)))
            .border(1.dp, p.panelBorder.copy(alpha = 0.7f), shape)
            .padding(14.dp),
        content = content,
    )
}

@Composable
private fun HomeIconBubble(p: HomePalette, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Box(Modifier.size(34.dp).clip(CircleShape).background(p.panelA.copy(alpha = 0.9f)), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
    }
}
