package com.agon.app.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Message
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.outlined.AccessTime
import androidx.compose.material.icons.outlined.FavoriteBorder
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.layout
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.R
import com.agon.app.Routes
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.formatDateTime
import com.agon.app.data.formatLongDate
import com.agon.app.data.greeting
import com.agon.app.data.rangeStatus
import com.agon.app.data.statusLabel
import com.agon.app.data.toMgDl
import com.agon.app.data.weekdayLong
import com.agon.app.love.LOVE_PHONE_DISPLAY
import com.agon.app.love.LOVE_PHONE_TEL
import com.agon.app.love.MAIN_LOVE_MESSAGE
import com.agon.app.love.SAMU_TEL
import com.agon.app.love.openDialer
import com.agon.app.love.openWhatsApp
import com.agon.app.love.phraseForToday
import com.agon.app.ui.components.ActionButton
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GlucoseChart
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.components.tourTarget
import com.agon.app.ui.theme.glucoColors
import kotlin.math.roundToInt

@Composable
fun HomeScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val context = LocalContext.current
    val settings = data.settings
    var phrase by remember { mutableStateOf("") }
    var showMood by remember { mutableStateOf(false) }
    var waterBarVisible by remember { mutableStateOf(true) }
    val scrollWatcher = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                if (available.y < -6f) waterBarVisible = false
                else if (available.y > 6f) waterBarVisible = true
                return Offset.Zero
            }
        }
    }
    LaunchedEffect(Unit) { phrase = phraseForToday(context) }
    if (showMood) {
        MoodSheet(settings.mood, settings.moodStyle, { st -> vm.updateSettings { it.copy(moodStyle = st) } }, onDismiss = { showMood = false }) { id ->
            vm.updateSettings { it.copy(mood = id, moodAt = System.currentTimeMillis()) }
            showMood = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val latest = data.glucose.maxByOrNull { it.at }
    val mg = latest?.let { toMgDl(it.value, it.unit) }
    val status = mg?.let { rangeStatus(it, settings.targetLow, settings.targetHigh) }
    val statusColor = when (status) {
        "ok" -> g.green
        "low" -> g.orange
        "high" -> g.red
        else -> g.muted
    }

    val weekMsTop = 7L * 24 * 60 * 60 * 1000
    val sinceTop = System.currentTimeMillis() - weekMsTop
    val weekGCount = data.glucose.count { it.at >= sinceTop }
    val weekICount = data.insulin.count { it.at >= sinceTop }
    val firstName = com.agon.app.data.firstName(settings.displayName).ifBlank { "Maria" }
    val greetText = "${greeting()}, $firstName!"
    val isBlue = settings.blueTheme
    val mood = com.agon.app.data.moodOf(settings.mood)
    val latestLine = latest?.let { "${GLUCOSE_CONTEXT_LABEL[it.context] ?: it.context} - ${formatDateTime(it.at)}" } ?: ""

    val bgBrush = if (isBlue) {
        Brush.verticalGradient(listOf(Color(0xFF031636), Color(0xFF04132C), Color(0xFF020B1E)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFF0B0126), Color(0xFF070018), Color(0xFF050014)))
    }

    BoxWithConstraints(Modifier.fillMaxSize().nestedScroll(scrollWatcher).background(bgBrush)) {
        val viewportH = maxHeight
        Column(
            Modifier
                .fillMaxSize()
                .imePadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp),
        ) {
            if (isBlue) {
                BlueHomeTop(
                    viewportH = viewportH,
                    greetText = greetText,
                    mg = mg?.roundToInt(),
                    statusText = status?.let { statusLabel(it) } ?: "",
                    latestLine = latestLine,
                    weekG = weekGCount,
                    weekI = weekICount,
                    onSwitch = { vm.updateSettings { it.copy(blueTheme = !it.blueTheme) } },
                    onHelp = { nav.navigate(Routes.HELP_CENTER) },
                    onMood = { showMood = true },
                    onLast = { nav.navigate(Routes.glucoseForm(null)) },
                    onCris = { nav.navigate(Routes.CRIS_IA) },
                )
            } else {
                PurpleHomeTop(
                    viewportH = viewportH,
                    greetText = greetText,
                    mg = mg?.roundToInt(),
                    statusText = status?.let { statusLabel(it) } ?: "",
                    dateText = latest?.let { formatDateTime(it.at) } ?: "",
                    weekG = weekGCount,
                    weekI = weekICount,
                    moodEmoji = mood?.emoji,
                    moodLabel = mood?.label,
                    onProfile = { nav.navigate(Routes.PROFILE) },
                    onSwitch = { vm.updateSettings { it.copy(blueTheme = !it.blueTheme) } },
                    onHelp = { nav.navigate(Routes.HELP_CENTER) },
                    onMood = { showMood = true },
                    onLast = { nav.navigate(Routes.glucoseForm(null)) },
                    onGlucose = { Routes.goTab(nav, Routes.GLUCOSE) },
                    onInsulin = { Routes.goTab(nav, Routes.INSULIN) },
                )
            }

            // ---- Abaixo da dobra (rolável): o conteúdo anterior do app, sem alterações ----
            if (isBlue) {
                // No layout azul a barra de hidratação não aparece sobre a tela; ela fica aqui, acessível ao rolar.
                Spacer(Modifier.height(12.dp))
                WaterMiniBar(
                    visible = true,
                    onOpenFull = { nav.navigate(Routes.WATER) },
                    modifier = Modifier.tourTarget("home_water"),
                )
            } else {
                // No layout roxo o atalho da Cris IA não aparece na primeira tela; ele fica aqui, acessível ao rolar.
                Spacer(Modifier.height(12.dp))
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(Brush.horizontalGradient(listOf(Color(0xFF5D12B9), Color(0xFFB51BFF))))
                        .clickable { nav.navigate(Routes.CRIS_IA) }
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Image(
                            painter = painterResource(R.drawable.robot_pink),
                            contentDescription = null,
                            modifier = Modifier.size(30.dp).clip(CircleShape),
                            contentScale = ContentScale.Fit,
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Conversar com a Cris IA", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Text("Sua assistente de cuidado", color = Color.White.copy(alpha = 0.88f), fontSize = 12.sp)
                    }
                    Text("›", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(10.dp))

        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton(
                " Ligar para meu amor ❤️",
                Icons.Filled.Call,
                g.violet,
                { openDialer(context, LOVE_PHONE_TEL) },
                Modifier.weight(1f),
            )
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton(
                "falar com amor por WhatsApp ",
                Icons.Filled.Favorite,
                g.blush,
                { openWhatsApp(context) },
                Modifier.weight(1f),
            )
        }
        Text(
            "A ligação não começa sozinha: o discador abre com $LOVE_PHONE_DISPLAY para você confirmar. O WhatsApp só abre a conversa, sem enviar mensagem.",
            color = g.muted,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 6.dp, start = 4.dp, end = 4.dp),
        )

        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 14.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(g.red)
                .clickable { openDialer(context, SAMU_TEL) }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.LocalHospital, null, tint = Color.White)
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text(" Emergência — SAMU 192", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text(
                    "Abre o discador com 192. Não aciona o atendimento sozinho e não garante que a chamada seja completada.",
                    color = Color.White.copy(alpha = 0.92f),
                    fontSize = 12.sp,
                )
            }
        }

        GCard(Modifier.padding(top = 14.dp)) {
            Text("Última medição", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (latest == null || mg == null || status == null) {
                Text("Nenhuma medição ainda.", color = g.ink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
            } else {
                Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(top = 4.dp)) {
                    Text(mg.roundToInt().toString(), color = statusColor, fontWeight = FontWeight.ExtraBold, fontSize = 40.sp)
                    Text(" mg/dL", color = g.muted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp, start = 4.dp))
                }
                Text(statusLabel(status), color = statusColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(
                    "${GLUCOSE_CONTEXT_LABEL[latest.context] ?: latest.context} · ${formatDateTime(latest.at)}",
                    color = g.muted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton("Registrar glicose", Icons.Filled.WaterDrop, g.violet, { nav.navigate(Routes.glucoseForm(null)) }, Modifier.weight(1f))
                ActionButton("Registrar insulina", Icons.Filled.WaterDrop, g.blue, { nav.navigate(Routes.insulinForm(null)) }, Modifier.weight(1f))
            }
        }


        // Resumo semanal rápido
        run {
            val weekMs = 7L * 24 * 60 * 60 * 1000
            val since = System.currentTimeMillis() - weekMs
            val weekG = data.glucose.filter { it.at >= since }
            val weekI = data.insulin.filter { it.at >= since }
            val low = settings.targetLow
            val high = settings.targetHigh
            val inRange = weekG.count {
                val mgv = toMgDl(it.value, it.unit)
                mgv >= low && mgv <= high
            }
            val pct = if (weekG.isNotEmpty()) inRange * 100 / weekG.size else null
            GCard(Modifier.padding(top = 12.dp).clickable { nav.navigate(Routes.CRIS_IA) }) {
                Text("Resumo dos últimos 7 dias", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                Text(
                    if (weekG.isEmpty() && weekI.isEmpty()) "Sem registros nesta semana. Toque para falar com a Cris IA."
                    else "Glicemias: ${weekG.size}" + (pct?.let { " · $it% na meta do app" } ?: "") + " · Insulinas: ${weekI.size}",
                    color = g.muted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 4.dp),
                )
                Text("Abrir Cris IA para consulta em 1 minuto →", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }

        SectionTitle("Evolução", "Ver estatísticas") { nav.navigate(Routes.STATS) }
        GCard { GlucoseChart(data.glucose, settings.targetLow, settings.targetHigh) }

        val active = data.reminders.filter { it.enabled }.sortedWith(compareBy({ it.hour }, { it.minute }))
        SectionTitle("Próximo lembrete", "Ver todos") { Routes.goTab(nav, Routes.REMINDERS) }
        GCard {
            if (active.isEmpty()) {
                Text("Nenhum lembrete ativo.", color = g.muted, fontSize = 14.sp)
            } else {
                active.take(3).forEach { r ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(r.title, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Text(
                            "${com.agon.app.data.formatClock(r.hour, r.minute)} · ${com.agon.app.data.daysLabel(r.days)}",
                            color = g.muted,
                            fontSize = 12.sp,
                        )
                        Text(
                            (if (r.kind == "glicose") "Medição de glicose" else "Aplicação de insulina") +
                                if (r.notes.isNotEmpty()) " · ${r.notes}" else "",
                            color = g.violetDeep,
                            fontSize = 12.sp,
                        )
                    }
                }
            }
        }

        SectionTitle("Histórico resumido", "Ver todos") { Routes.goTab(nav, Routes.HISTORY) }
        GCard {
            val recent = data.glucose.sortedByDescending { it.at }.take(4)
            if (recent.isEmpty()) {
                Text("Sem registros.", color = g.muted, modifier = Modifier.padding(12.dp))
            } else {
                recent.forEach { e ->
                    val v = toMgDl(e.value, e.unit)
                    val st = rangeStatus(v, settings.targetLow, settings.targetHigh)
                    val c = when (st) { "ok" -> g.green; "low" -> g.orange; else -> g.red }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { nav.navigate(Routes.glucoseForm(e.id)) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(v.roundToInt().toString(), color = c, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.padding(end = 10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(GLUCOSE_CONTEXT_LABEL[e.context] ?: e.context, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${com.agon.app.data.formatDate(e.at)} · ${com.agon.app.data.formatTime(e.at)}", color = g.muted, fontSize = 12.sp)
                        }
                        Text(statusLabel(st), color = c, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        Spacer(Modifier.height(64.dp))
        }

        if (!isBlue) {
            // Barra de hidratação fixa sobre a tela (layout roxo).
            Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 10.dp, end = 10.dp, bottom = 12.dp)) {
                WaterMiniBar(
                    visible = waterBarVisible,
                    onOpenFull = { nav.navigate(Routes.WATER) },
                    modifier = Modifier.tourTarget("home_water"),
                )
            }
        }
    }
}

// ───────────────────────── Auxiliares visuais da tela inicial ─────────────────────────

/** Deixa o conteúdo [extra] dp mais largo de cada lado do padding da tela (os cartões da referência encostam mais na borda). */
private fun Modifier.bleed(extra: Dp): Modifier = this.layout { measurable, constraints ->
    val e = extra.roundToPx()
    val w = constraints.maxWidth + 2 * e
    val p = measurable.measure(constraints.copy(minWidth = w, maxWidth = w))
    layout(constraints.maxWidth, p.height) { p.place(-e, 0) }
}

/** Texto de uma linha que diminui a fonte até caber na largura disponível. */
@Composable
private fun FitOneLine(
    text: String,
    color: Color,
    maxSp: Float,
    minSp: Float,
    modifier: Modifier = Modifier,
    weight: FontWeight? = null,
    textAlign: TextAlign? = null,
) {
    val measurer = rememberTextMeasurer()
    BoxWithConstraints(modifier) {
        val maxW = constraints.maxWidth
        var sp = maxSp
        while (sp > minSp) {
            val w = measurer.measure(text = text, style = TextStyle(fontSize = sp.sp, fontWeight = weight), softWrap = false, maxLines = 1).size.width
            if (w <= maxW) break
            sp -= 0.5f
        }
        Text(text, color = color, fontSize = sp.sp, fontWeight = weight, maxLines = 1, softWrap = false, textAlign = textAlign)
    }
}

private fun DrawScope.glowStroke(p: Path, c: Color, scale: Float = 1f) {
    val u = 1.dp.toPx() * scale
    drawPath(p, c.copy(alpha = 0.10f), style = Stroke(width = 14f * u, cap = StrokeCap.Round))
    drawPath(p, c.copy(alpha = 0.26f), style = Stroke(width = 7f * u, cap = StrokeCap.Round))
    drawPath(p, c.copy(alpha = 0.95f), style = Stroke(width = 1.6f * u, cap = StrokeCap.Round))
}

/** Ondas neon do cabeçalho roxo. */
private fun DrawScope.purpleWaves() {
    val w = size.width
    val u = 1.dp.toPx()
    val c = Offset(w * 0.82f, 150f * u)
    drawCircle(Brush.radialGradient(listOf(Color(0x66B040FF), Color.Transparent), center = c, radius = 230f * u), radius = 230f * u, center = c)
    val p1 = Path().apply {
        moveTo(w * 0.50f, -40f * u)
        cubicTo(w * 0.58f, 20f * u, w * 0.74f, 60f * u, w * 1.04f, 92f * u)
    }
    glowStroke(p1, Color(0xFFB65CFF))
    val p2 = Path().apply {
        moveTo(-10f * u, 176f * u)
        cubicTo(w * 0.18f, 196f * u, w * 0.40f, 166f * u, w * 0.62f, 200f * u)
        cubicTo(w * 0.80f, 224f * u, w * 0.92f, 206f * u, w * 1.04f, 168f * u)
    }
    glowStroke(p2, Color(0xFFD18CFF))
}

/** Onda decorativa dentro de um cartão (parte de baixo). */
private fun DrawScope.cardWave(color: Color, fromLeft: Float, y0: Float, y1: Float) {
    val w = size.width
    val h = size.height
    val p = Path().apply {
        moveTo(w * fromLeft, h * y0)
        cubicTo(w * (fromLeft + 0.25f), h * (y0 - 0.22f), w * 0.72f, h * (y1 + 0.16f), w * 1.02f, h * y1)
    }
    glowStroke(p, color, 0.55f)
}

@Composable
private fun PurpleCircleButton(onClick: () -> Unit, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier
            .size(34.dp)
            .shadow(6.dp, CircleShape, clip = false, ambientColor = Color(0xFFB51BFF), spotColor = Color(0xFFB51BFF))
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(Color(0xFF6A2BE0), Color(0xFF3A0F9E))))
            .border(2.dp, Brush.linearGradient(listOf(Color(0xFFD7A8FF), Color(0xFF8A4BFF))), CircleShape)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) { content() }
}

@Composable
private fun PurpleChevron(modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(20.dp)
            .clip(CircleShape)
            .background(Color(0x33200A6A))
            .border(1.dp, Color(0xFFB070FF), CircleShape),
        contentAlignment = Alignment.Center,
    ) { Text("›", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.offset(y = (-1).dp)) }
}

@Composable
private fun SparkArrow(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(width = 30.dp, height = 24.dp)) {
        val u = 0.8.dp.toPx()
        val line = Path().apply {
            moveTo(1f * u, 27f * u); lineTo(11f * u, 16f * u); lineTo(18f * u, 21f * u); lineTo(32f * u, 5f * u)
        }
        drawPath(line, color, style = Stroke(width = 3f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
        val head = Path().apply { moveTo(24f * u, 4f * u); lineTo(33f * u, 4f * u); lineTo(33f * u, 13f * u) }
        drawPath(head, color, style = Stroke(width = 3f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
private fun PurpleHomeTop(
    viewportH: Dp,
    greetText: String,
    mg: Int?,
    statusText: String,
    dateText: String,
    weekG: Int,
    weekI: Int,
    moodEmoji: String?,
    moodLabel: String?,
    onProfile: () -> Unit,
    onSwitch: () -> Unit,
    onHelp: () -> Unit,
    onMood: () -> Unit,
    onLast: () -> Unit,
    onGlucose: () -> Unit,
    onInsulin: () -> Unit,
) {
    // Medidas tiradas da imagem de referência (411 dp de largura); em telas mais baixas a altura é reduzida proporcionalmente.
    val k = (viewportH.value / 780f).coerceIn(0.80f, 1f)
    fun h(v: Float) = (v * k).dp
    val violetBorder = Brush.linearGradient(listOf(Color(0xFFB03BFF), Color(0xFF7A2BFF)))
    val cardShape = RoundedCornerShape(18.dp)
    val white90 = Color.White.copy(alpha = 0.92f)

    Column(Modifier.fillMaxWidth().height(viewportH).drawBehind { purpleWaves() }) {
        Spacer(Modifier.height(h(4f)))
        // Cabeçalho
        Row(Modifier.fillMaxWidth().height(34.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Text("GlucoCris", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.width(6.dp))
                Text("❤️", fontSize = 19.sp)
            }
            Row(Modifier.offset(x = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                PurpleCircleButton(onProfile, Modifier.tourTarget("home_profile")) {
                    Icon(Icons.Filled.Person, contentDescription = "Perfil", tint = Color.White, modifier = Modifier.size(20.dp))
                }
                Spacer(Modifier.width(10.dp))
                PurpleCircleButton(onSwitch, Modifier.tourTarget("home_theme")) {
                    Text("⇄", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                }
                Spacer(Modifier.width(12.dp))
                PurpleCircleButton(onHelp, Modifier.tourTarget("home_help")) {
                    Text("?", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                }
            }
        }

        // Cabeçalho ilustrado
        Row(Modifier.fillMaxWidth().height(h(112f)), verticalAlignment = Alignment.CenterVertically) {
            Image(
                painter = painterResource(R.drawable.neon_app_robot),
                contentDescription = "Ícone GlucoCris",
                modifier = Modifier
                    .size(64.dp)
                    .shadow(6.dp, RoundedCornerShape(16.dp), clip = false, ambientColor = Color(0xFFB51BFF), spotColor = Color(0xFFB51BFF))
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFFC77CFF), RoundedCornerShape(16.dp)),
                contentScale = ContentScale.Crop,
            )
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text("$greetText 🥰", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 19.sp, lineHeight = 25.sp)
                Text("Você está indo muito bem!", color = Color.White.copy(alpha = 0.92f), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
            Image(
                painter = painterResource(R.drawable.neon_hero_robot),
                contentDescription = "Cris segurando um coração",
                modifier = Modifier.size(h(112f)).offset(x = 6.dp, y = 4.dp),
                contentScale = ContentScale.Crop,
            )
        }

        Spacer(Modifier.height(h(12f)))

        // Linha 1: Última medição | Seu humor
        Row(Modifier.fillMaxWidth().height(h(138f)).bleed(0.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier
                    .weight(1.04f)
                    .fillMaxHeight()
                    .shadow(5.dp, cardShape, clip = false, ambientColor = Color(0xFF4A63FF), spotColor = Color(0xFF4A63FF))
                    .clip(cardShape)
                    .background(Brush.linearGradient(listOf(Color(0xFF2A3FA8), Color(0xFF18227A), Color(0xFF11185E))))
                    .drawBehind { cardWave(Color(0xFF7B5CFF), 0.45f, 0.95f, 0.78f) }
                    .border(2.dp, Brush.linearGradient(listOf(Color(0xFF4F83FF), Color(0xFF7D3BFF))), cardShape)
                    .clickable(onClick = onLast),
            ) {
            Column(Modifier.fillMaxSize().padding(start = 12.dp, end = 10.dp, top = 10.dp)) {
                Row(Modifier.height(22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("💧", fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    FitOneLine("Última medição", white90, 13f, 10f, Modifier.weight(1f), FontWeight.SemiBold)
                }
                if (mg != null) {
                    Row(Modifier.padding(start = 6.dp, top = 2.dp), verticalAlignment = Alignment.Bottom) {
                        Text(mg.toString(), color = Color(0xFF2BE36F), fontWeight = FontWeight.ExtraBold, fontSize = 36.sp, lineHeight = 40.sp)
                        Text("mg/dL", color = Color.White.copy(alpha = 0.78f), fontSize = 14.sp, modifier = Modifier.padding(start = 5.dp, bottom = 6.dp))
                    }
                    Row(Modifier.padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(18.dp).clip(CircleShape).background(Color(0xFF2BE36F)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Check, null, tint = Color(0xFF0B1A2E), modifier = Modifier.size(13.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        Text(statusText, color = Color(0xFF2BE36F), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Outlined.AccessTime, null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(13.dp))
                        Spacer(Modifier.width(7.dp))
                        FitOneLine(dateText, Color.White.copy(alpha = 0.85f), 10f, 7f, Modifier.weight(1f))
                    }
                } else {
                    Spacer(Modifier.height(18.dp))
                    Text("Sem medição", color = Color.White.copy(alpha = 0.85f), fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text("Toque para registrar", color = Color.White.copy(alpha = 0.55f), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
            if (mg != null) SparkArrow(Color(0xFF2BE36F), Modifier.align(Alignment.BottomEnd).padding(end = 12.dp, bottom = 26.dp))
            }

            Column(
                Modifier
                    .weight(1f)
                    .fillMaxHeight()
                    .shadow(5.dp, cardShape, clip = false, ambientColor = Color(0xFFB51BFF), spotColor = Color(0xFFB51BFF))
                    .clip(cardShape)
                    .background(Brush.linearGradient(listOf(Color(0xFF5B24D6), Color(0xFF3A14A8), Color(0xFF2A0C7A))))
                    .drawBehind { cardWave(Color(0xFFE08CFF), 0.0f, 0.93f, 0.80f) }
                    .border(2.dp, Brush.linearGradient(listOf(Color(0xFFC04BFF), Color(0xFF8A2BFF))), cardShape)
                    .clickable(onClick = onMood)
                    .padding(horizontal = 10.dp, vertical = 12.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Row(Modifier.height(22.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("💜", fontSize = 16.sp)
                    Spacer(Modifier.width(7.dp))
                    Text("Seu humor", color = white90, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                }
                Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                    Text(moodEmoji ?: "😊", fontSize = 40.sp)
                }
                Text(
                    moodLabel ?: "Toque aqui",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(bottom = 4.dp),
                )
            }
        }

        Spacer(Modifier.height(h(10f)))

        // Linha 2: Glicemias | Insulinas
        Row(Modifier.fillMaxWidth().height(h(96f)).bleed(0.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            @Composable
            fun SmallCard(emoji: String, title: String, value: Int, modifier: Modifier, onClick: () -> Unit) {
                Box(
                    modifier
                        .fillMaxHeight()
                        .shadow(5.dp, cardShape, clip = false, ambientColor = Color(0xFF7A2BFF), spotColor = Color(0xFF7A2BFF))
                        .clip(cardShape)
                        .background(Brush.linearGradient(listOf(Color(0xFF2332A0), Color(0xFF18228A), Color(0xFF111A66))))
                        .drawBehind { cardWave(Color(0xFF9B5BFF), 0.30f, 0.98f, 0.55f) }
                        .border(2.dp, Brush.linearGradient(listOf(Color(0xFF5F6BFF), Color(0xFF9B2BFF))), cardShape)
                        .clickable(onClick = onClick),
                ) {
                    Column(Modifier.padding(start = 12.dp, end = 8.dp, top = 10.dp)) {
                        Row(Modifier.height(20.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(emoji, fontSize = 15.sp)
                            Spacer(Modifier.width(7.dp))
                            FitOneLine(title, white90, 12f, 9f, Modifier.weight(1f), FontWeight.SemiBold)
                        }
                        Text(
                            value.toString(),
                            color = Color.White,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 30.sp,
                            lineHeight = 34.sp,
                            modifier = Modifier.padding(start = 5.dp, top = 8.dp),
                        )
                    }
                    PurpleChevron(Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = 10.dp))
                }
            }
            SmallCard("📊", "Glicemias (7 dias)", weekG, Modifier.weight(1f), onGlucose)
            SmallCard("💉", "Insulinas (7 dias)", weekI, Modifier.weight(1f), onInsulin)
        }

        Spacer(Modifier.height(h(10f)))

        // Mensagem fixa — cabe inteira na tela, sem rolar (sem a linha extra "Frase carinhosa de hoje").
        val msgShape = RoundedCornerShape(18.dp)
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(min = 120.dp)
                .shadow(5.dp, msgShape, clip = false, ambientColor = Color(0xFFFF8BFF), spotColor = Color(0xFFFF8BFF))
                .clip(msgShape)
                .background(Brush.linearGradient(listOf(Color(0xFFF4CCFF), Color(0xFFE6B6FF), Color(0xFFDDA7FF))))
                .border(1.5.dp, Brush.linearGradient(listOf(Color(0xFFFFFFFF), Color(0xFFE79BFF))), msgShape)
                .padding(top = 10.dp, bottom = 8.dp, end = 12.dp),
        ) {
            Row(Modifier.fillMaxWidth().height(22.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                Text("❤️", fontSize = 15.sp)
                Spacer(Modifier.width(8.dp))
                Text("Uma mensagem para você", color = Color(0xFF481078), fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                Spacer(Modifier.width(8.dp))
                Text("❤️", fontSize = 15.sp)
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.Top) {
                Image(
                    painterResource(R.drawable.neon_love_hearts),
                    contentDescription = "Corações",
                    modifier = Modifier.size(72.dp).offset(x = 4.dp, y = 2.dp),
                    contentScale = ContentScale.Crop,
                )
                Text(
                    MAIN_LOVE_MESSAGE,
                    color = Color(0xFF2B1055),
                    fontSize = 13.sp,
                    lineHeight = 17.sp,
                    modifier = Modifier.weight(1f).padding(start = 6.dp, top = 4.dp),
                )
            }
        }
    }
}

@Composable
private fun BlueHomeTop(
    viewportH: Dp,
    greetText: String,
    mg: Int?,
    statusText: String,
    latestLine: String,
    weekG: Int,
    weekI: Int,
    onSwitch: () -> Unit,
    onHelp: () -> Unit,
    onMood: () -> Unit,
    onLast: () -> Unit,
    onCris: () -> Unit,
) {
    // Medidas tiradas da imagem do layout azul (1024 px → 411 dp). Os blocos dividem a altura da tela na mesma proporção da imagem.
    val blueEdge = Brush.linearGradient(listOf(Color(0xFF5FA8FF), Color(0xFF1F5FC0)))
    val cardShape = RoundedCornerShape(18.dp)
    val mint = Color(0xFF1FE08C)
    val ink = Color(0xFF12243F)

    Column(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 470.dp)
            .height(viewportH)
            .drawBehind {
                val u = 1.dp.toPx()
                val c = Offset(size.width * 0.28f, 70f * u)
                drawCircle(Brush.radialGradient(listOf(Color(0x551E6BE0), Color.Transparent), center = c, radius = 190f * u), radius = 190f * u, center = c)
            },
    ) {
        // Topo: título, botões, robô, saudação e botão de humor
        BoxWithConstraints(Modifier.fillMaxWidth().weight(120f)) {
            val hh = maxHeight
            Image(
                painter = painterResource(R.drawable.blue_hero_robot),
                contentDescription = "Cris",
                modifier = Modifier.align(Alignment.BottomStart).offset(x = (-1.5).dp).size(width = 108.dp, height = 91.dp),
                contentScale = ContentScale.Fit,
                alignment = Alignment.BottomStart,
            )
            Row(Modifier.fillMaxWidth().padding(top = 4.dp).height(34.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Gluco Cris", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp).weight(1f))
                Box(
                    Modifier
                        .tourTarget("home_theme")
                        .size(32.dp)
                        .clickable(onClick = onSwitch),
                    contentAlignment = Alignment.Center,
                ) {
                    Box(
                        Modifier
                            .size(22.dp)
                            .shadow(6.dp, CircleShape, clip = false, ambientColor = Color(0xFF2E8BFF), spotColor = Color(0xFF2E8BFF))
                            .clip(CircleShape)
                            .background(Brush.radialGradient(listOf(Color(0xFF1B63D6), Color(0xFF0B2A66))))
                            .border(2.dp, Color(0xFF5CB3FF), CircleShape),
                    )
                }
                Spacer(Modifier.width(4.dp))
                Box(
                    Modifier
                        .tourTarget("home_help")
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0E2A5C))
                        .border(1.dp, Color(0xFF1F4F9A), CircleShape)
                        .clickable(onClick = onHelp),
                    contentAlignment = Alignment.Center,
                ) { Text("?", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp) }
            }
            Text(
                greetText,
                color = Color.White,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 19.sp,
                maxLines = 1,
                modifier = Modifier.align(Alignment.TopStart).padding(start = 140.dp, top = hh * 0.50f).clickable(onClick = onMood),
            )
        }

        // Cartões 2x2 inteligentes
        Row(Modifier.fillMaxWidth().weight(116f).bleed(1.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Column(
                Modifier
                    .weight(216f)
                    .fillMaxHeight()
                    .clip(cardShape)
                    .background(Brush.verticalGradient(listOf(Color(0xFF1D5CB8), Color(0xFF0C2D68))))
                    .border(1.5.dp, blueEdge, cardShape)
                    .clickable(onClick = onLast)
                    .padding(start = 14.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
                verticalArrangement = Arrangement.SpaceBetween,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(22.dp).clip(CircleShape).background(Color(0xFF0B2A66)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.WaterDrop, null, tint = Color.White, modifier = Modifier.size(14.dp))
                    }
                    Spacer(Modifier.width(10.dp))
                    FitOneLine("Última medição", Color.White, 13f, 10f, Modifier.weight(1f), FontWeight.Medium)
                }
                if (mg != null) {
                    Row(Modifier.padding(start = 6.dp), verticalAlignment = Alignment.Bottom) {
                        Text(mg.toString(), color = mint, fontWeight = FontWeight.ExtraBold, fontSize = 38.sp, lineHeight = 42.sp)
                        Text("mg/dL", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 6.dp, bottom = 6.dp))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(19.dp).clip(CircleShape).background(mint), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Check, null, tint = Color(0xFF062B2B), modifier = Modifier.size(14.dp))
                        }
                        Spacer(Modifier.width(9.dp))
                        Text(statusText, color = mint, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                    FitOneLine(latestLine, Color.White, 10f, 7f, Modifier.fillMaxWidth())
                } else {
                    Text("Sem medição", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Toque para registrar", color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
                    Spacer(Modifier.height(1.dp))
                }
            }
            Column(
                Modifier
                    .weight(158f)
                    .fillMaxHeight()
                    .clip(cardShape)
                    .background(Brush.verticalGradient(listOf(Color(0xFF16457F), Color(0xFF0B2A5E))))
                    .border(1.5.dp, Brush.linearGradient(listOf(Color(0xFF3F8DE8), Color(0xFF1A4F9C))), cardShape)
                    .padding(start = 10.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
                verticalArrangement = Arrangement.SpaceEvenly,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(30.dp), contentAlignment = Alignment.Center) {
                        BlueChartIcon(Modifier.size(18.dp))
                    }
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("Glicemias\n(7 dias)", color = Color.White, fontSize = 12.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium)
                        Text(weekG.toString(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.padding(start = 2.dp))
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(30.dp).clip(CircleShape).background(Color(0xFF0E2D6B)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Vaccines, null, tint = Color.White, modifier = Modifier.size(18.dp))
                    }
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("Insulinas\n(7 dias)", color = Color.White, fontSize = 12.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium)
                        Text(weekI.toString(), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp, modifier = Modifier.padding(start = 2.dp))
                    }
                }
            }
        }

        Spacer(Modifier.weight(8f))

        // Mensagem fixa
        val msgShape = RoundedCornerShape(16.dp)
        Column(
            Modifier
                .fillMaxWidth()
                .weight(124f)
                .bleed(1.dp)
                .clip(msgShape)
                .background(Brush.verticalGradient(listOf(Color(0xFFD3E3F8), Color(0xFFE4EEFB))))
                .border(1.dp, Color(0xFFB9D2F2), msgShape)
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.SpaceBetween,
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.AutoMirrored.Filled.Message, null, tint = ink, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(10.dp))
                Text("Uma mensagem para você", color = ink, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
            }
            Text(MAIN_LOVE_MESSAGE, color = ink, fontSize = 13.sp, lineHeight = 17.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Outlined.FavoriteBorder, null, tint = ink, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Frase carinhosa de hoje", color = ink, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.weight(9f))
        BlueCrisBar(Modifier.weight(46f).bleed(1.dp), onCris)
        Spacer(Modifier.weight(7f))
    }
}

@Composable
private fun BlueChartIcon(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val u = size.width / 24f
        val c = Color.White
        drawRect(c, Offset(2f * u, 15f * u), androidx.compose.ui.geometry.Size(4f * u, 6f * u))
        drawRect(c, Offset(9f * u, 11f * u), androidx.compose.ui.geometry.Size(4f * u, 10f * u))
        drawRect(c, Offset(16f * u, 7f * u), androidx.compose.ui.geometry.Size(4f * u, 14f * u))
        val line = Path().apply { moveTo(2f * u, 10f * u); lineTo(9f * u, 5f * u); lineTo(13f * u, 7f * u); lineTo(21f * u, 1.5f * u) }
        drawPath(line, c, style = Stroke(width = 2f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
        val head = Path().apply { moveTo(16f * u, 1.5f * u); lineTo(21f * u, 1.5f * u); lineTo(21f * u, 6.5f * u) }
        drawPath(head, c, style = Stroke(width = 2f * u, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}

@Composable
private fun BlueCrisBar(modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Color(0xFF0A47A6), Color(0xFF1A86F5))))
            .border(1.dp, Color(0x664FA3FF), shape)
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Spacer(Modifier.width(24.dp))
        Image(
            painter = painterResource(R.drawable.blue_cris_head),
            contentDescription = null,
            modifier = Modifier.size(width = 46.dp, height = 31.dp),
            contentScale = ContentScale.Fit,
        )
        Spacer(Modifier.width(18.dp))
        Column(Modifier.weight(1f)) {
            Text("Conversar com a Cris IA", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
            Text("Sua assistente de cuidado", color = Color.White, fontSize = 11.sp, maxLines = 1)
        }
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = Color.White, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(10.dp))
    }
}
