package com.agon.app

import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController

object Routes {
    const val HOME = "inicio"
    const val GLUCOSE = "glicose"
    const val INSULIN = "insulina"
    const val REMINDERS = "lembretes"
    const val HISTORY = "historico"
    const val MORE = "mais"
    const val PROFILE = "perfil"
    const val STATS = "estatisticas"
    const val CARE = "cuidados"
    const val MEDS = "medicamentos"
    const val REPORT = "relatorio"
    const val SETTINGS = "ajustes"
    const val LOCATOR = "localizador"
    const val CRIS_IA = "cris_ia"
    const val CRIS_VOICE = "cris_voz"
    const val GLUCOSE_FORM = "glicose_form"
    const val INSULIN_FORM = "insulina_form"
    const val FOOD = "alimentacao"
    const val FOOD_SEARCH = "alimentacao_busca"
    const val FOOD_DETAIL = "alimentacao_detalhe"
    const val FOOD_DIARY = "alimentacao_diario"
    const val FOOD_REPORTS = "alimentacao_relatorios"
    const val FOOD_BARCODE = "alimentacao_barcode"
    const val FOOD_SMART_SCAN = "alimentacao_scanner_inteligente"
    const val FOOD_RECIPES = "alimentacao_receitas"
    const val FOOD_RECIPE_DETAIL = "alimentacao_receita_detalhe"
    const val FOOD_TOOLS = "alimentacao_ferramentas"
    const val FOOD_CUSTOM = "alimentacao_meus_alimentos"
    const val FOOD_MEAL_BUILDER = "alimentacao_montar"
    const val FOOD_FAV_MEALS = "alimentacao_favoritas"
    const val FOOD_BOLUS = "alimentacao_bolus"
    const val FOOD_GLUCOSE_LINK = "alimentacao_glicemia_link"

    val tabs = listOf(HOME, GLUCOSE, INSULIN, REMINDERS, HISTORY, FOOD, MORE)

    fun glucoseForm(id: String?) = if (id == null) GLUCOSE_FORM else "glicose_form?id=$id"
    fun insulinForm(id: String?) = if (id == null) INSULIN_FORM else "insulina_form?id=$id"

    fun goTab(nav: NavHostController, route: String) {
        nav.navigate(route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun tabOf(route: String?): String = when {
        route == null -> HOME
        route.startsWith(GLUCOSE_FORM) || route == GLUCOSE -> GLUCOSE
        route.startsWith(INSULIN_FORM) || route == INSULIN -> INSULIN
        route == REMINDERS -> REMINDERS
        route == HISTORY -> HISTORY
        route == HOME -> HOME
        route == FOOD || route.startsWith("alimentacao") -> FOOD
        route == PROFILE -> MORE
        else -> MORE
    }

    fun titleOf(route: String?, id: String? = null): String = when {
        route == null -> ""
        route.startsWith(GLUCOSE_FORM) -> if (id != null) "Editar glicose" else "Nova glicose"
        route.startsWith(INSULIN_FORM) -> if (id != null) "Editar insulina" else "Nova insulina"
        route == GLUCOSE -> "Glicose"
        route == INSULIN -> "Insulina"
        route == REMINDERS -> "Lembretes"
        route == HISTORY -> "Histórico"
        route == MORE -> "Organização"
        route == PROFILE -> "Perfil"
        route == STATS -> "Estatísticas"
        route == CARE -> "Alimentação e sintomas"
        route == MEDS -> "Medicamentos"
        route == REPORT -> "Relatório"
        route == SETTINGS -> "Ajustes"
        route == LOCATOR -> "Localizador de Insulinas"
        route == CRIS_IA -> "Cris IA ❤️"
        route == CRIS_VOICE -> "Cris · voz"
        route == FOOD || route.startsWith("alimentacao") -> "Alimentação e Nutrição"
        else -> ""
    }
}
