package com.agon.app.data

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.agon.app.BuildConfig
import com.agon.app.ui.screens.FoodItem
import com.agon.app.ui.screens.loadTacoFoods
import com.agon.app.ui.screens.searchFoodsComplete
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/** Item identificado pela IA (ainda sem nutrientes do catálogo). */
data class VisionDetectedFood(
    val name: String,
    val quantityGrams: Double?,
    val householdMeasure: String?,
    val confidence: Double?,
    val notes: String? = null,
)

data class VisionAnalysisResult(
    val items: List<VisionDetectedFood>,
    val provider: String,
    val rawNotes: String? = null,
)

/** Item já casado com o banco nutricional do Gluco Cris. */
data class VisionMealLine(
    val id: String,
    val detectedName: String,
    var displayName: String,
    var grams: Double,
    var household: String,
    var confidence: Double?,
    var food: FoodItem?,
    val alternatives: List<FoodItem> = emptyList(),
) {
    fun factor(): Double {
        val base = food?.servingGrams?.takeIf { it > 0 } ?: 100.0
        return grams / base
    }

    fun carbs(): Double = food?.let { it.carbs * factor() } ?: 0.0
    fun kcal(): Double = food?.let { it.kcal * factor() } ?: 0.0
    fun protein(): Double = food?.let { it.protein * factor() } ?: 0.0
    fun fat(): Double = food?.let { it.fat * factor() } ?: 0.0
    fun fiber(): Double = food?.let { it.fiber * factor() } ?: 0.0
    fun sugars(): Double = food?.let { it.sugars * factor() } ?: 0.0
    fun sodium(): Double = food?.let { it.sodium * factor() } ?: 0.0
}

object FoodVisionAi {
    private const val TAG = "FoodVisionAi"

    fun hasGeminiKey(): Boolean = BuildConfig.GEMINI_API_KEY.isNotBlank()

    fun providerLabel(): String =
        if (hasGeminiKey()) "Gemini (${BuildConfig.GEMINI_MODEL})" else "Indisponível (configure a chave)"

    /**
     * Comprime e redimensiona a imagem antes do envio (economia de cota/custo).
     */
    fun prepareImageBase64(bitmap: Bitmap, maxSide: Int = 768, quality: Int = 82): String {
        var bmp = bitmap
        val max = maxOf(bmp.width, bmp.height)
        if (max > maxSide) {
            val scale = maxSide.toFloat() / max
            bmp = Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * scale).toInt().coerceAtLeast(1),
                (bmp.height * scale).toInt().coerceAtLeast(1),
                true,
            )
        }
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, baos)
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun analyzeWithGemini(bitmap: Bitmap): VisionAnalysisResult = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY
        if (key.isBlank()) error("Chave Gemini não configurada. Defina gemini.api.key em local.properties.")

        val b64 = prepareImageBase64(bitmap)
        val model = BuildConfig.GEMINI_MODEL.ifBlank { "gemini-3.8-flash" }
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key",
        )

        val prompt = """
Você é um assistente nutricional para o app brasileiro Gluco Cris (diabetes / contagem de carboidratos).
Analise a foto da refeição e identifique CADA alimento visível separadamente (comida brasileira quando possível).

Responda APENAS com JSON válido (sem markdown), neste formato:
{
  "items": [
    {
      "name": "nome do alimento em português",
      "grams": 120,
      "household": "1 concha",
      "confidence": 0.0 a 1.0,
      "notes": "opcional"
    }
  ],
  "notes": "observação geral opcional"
}

Regras:
- Separe itens misturados (arroz, feijão, carne, salada, etc.).
- grams é ESTIMATIVA; se incerto use null e explique em notes.
- Não invente alimentos que não aparecem na foto.
- Prefira nomes comuns no Brasil (arroz branco cozido, feijão carioca, frango grelhado...).
- Se a imagem não for comida, items: [].
""".trimIndent()

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray()
                            .put(JSONObject().put("text", prompt))
                            .put(
                                JSONObject().put(
                                    "inline_data",
                                    JSONObject()
                                        .put("mime_type", "image/jpeg")
                                        .put("data", b64),
                                ),
                            ),
                    ),
                ),
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.2)
                    .put("maxOutputTokens", 2048),
            )

        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 25000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val resp = stream?.bufferedReader()?.readText().orEmpty()
        if (code !in 200..299) {
            Log.w(TAG, "Gemini HTTP $code: ${resp.take(400)}")
            error(parseGeminiError(resp, code))
        }

        val text = extractGeminiText(resp)
        parseVisionJson(text, "Gemini")
    }

    private fun parseGeminiError(resp: String, code: Int): String {
        return try {
            val msg = JSONObject(resp).optJSONObject("error")?.optString("message")
            when {
                code == 429 -> "Limite de uso da API atingido. Tente mais tarde."
                code == 403 -> "Chave Gemini inválida ou sem permissão."
                !msg.isNullOrBlank() -> "Erro da IA: $msg"
                else -> "Erro HTTP $code na API Gemini."
            }
        } catch (_: Exception) {
            "Erro HTTP $code na API Gemini."
        }
    }

    private fun extractGeminiText(resp: String): String {
        val root = JSONObject(resp)
        val candidates = root.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            sb.append(parts.getJSONObject(i).optString("text"))
        }
        return sb.toString().trim()
    }

    private fun parseVisionJson(text: String, provider: String): VisionAnalysisResult {
        var cleaned = text.trim()
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.removePrefix("```json").removePrefix("```JSON").removePrefix("```").trim()
            if (cleaned.endsWith("```")) cleaned = cleaned.dropLast(3).trim()
        }
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        if (start < 0 || end <= start) return VisionAnalysisResult(emptyList(), provider, "Resposta sem JSON")
        val obj = JSONObject(cleaned.substring(start, end + 1))
        val arr = obj.optJSONArray("items") ?: JSONArray()
        val items = mutableListOf<VisionDetectedFood>()
        for (i in 0 until arr.length()) {
            val it = arr.getJSONObject(i)
            val name = it.optString("name", "").trim()
            if (name.isBlank()) continue
            val grams = if (it.has("grams") && !it.isNull("grams")) it.optDouble("grams") else null
            items.add(
                VisionDetectedFood(
                    name = name,
                    quantityGrams = grams?.takeIf { it > 0 },
                    householdMeasure = it.optString("household", "").ifBlank { null },
                    confidence = if (it.has("confidence")) it.optDouble("confidence") else null,
                    notes = it.optString("notes", "").ifBlank { null },
                ),
            )
        }
        return VisionAnalysisResult(
            items = items,
            provider = provider,
            rawNotes = obj.optString("notes", "").ifBlank { null },
        )
    }

    /**
     * Casa cada item detectado com o catálogo do app (searchFoodsComplete).
     * Não inventa nutrientes: se não achar, food fica null.
     */
    suspend fun matchToCatalog(
        context: Context,
        analysis: VisionAnalysisResult,
    ): List<VisionMealLine> = withContext(Dispatchers.IO) {
        val taco = loadTacoFoods(context)
        analysis.items.mapIndexed { index, det ->
            val results = try {
                searchFoodsComplete(context, det.name, taco).take(8)
            } catch (_: Exception) {
                emptyList()
            }
            val best = results.firstOrNull()
            val grams = det.quantityGrams
                ?: best?.servingGrams?.takeIf { it > 0 }
                ?: 100.0
            VisionMealLine(
                id = "vision-$index-${det.name.hashCode()}",
                detectedName = det.name,
                displayName = best?.name ?: det.name,
                grams = grams,
                household = det.householdMeasure
                    ?: best?.serving
                    ?: "${grams.roundToInt()} g",
                confidence = det.confidence,
                food = best,
                alternatives = results.drop(1).take(5),
            )
        }
    }
}
