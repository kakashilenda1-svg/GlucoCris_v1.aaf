package com.agon.app.data

import android.app.Application
import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.reminders.ReminderScheduler
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.glucoDataStore by preferencesDataStore(name = "gluco_store")

object GlucoStorage {
    val KEY = stringPreferencesKey("gluco.maria-cristina.v1")
    val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        coerceInputValues = true
    }

    suspend fun read(context: Context): AppData? {
        val prefs = context.glucoDataStore.data.first()
        val text = prefs[KEY] ?: return null
        return try {
            json.decodeFromString<AppData>(text)
        } catch (e: Exception) {
            null
        }
    }
}

class GlucoViewModel(app: Application) : AndroidViewModel(app) {
    private val _data = MutableStateFlow(defaultData())
    val data: StateFlow<AppData> = _data.asStateFlow()

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _unlocked = MutableStateFlow(false)
    val unlocked: StateFlow<Boolean> = _unlocked.asStateFlow()

    var tempFood: com.agon.app.ui.screens.FoodItem? = null
    var tempMealType: String = "cafe"
    var tempRecipe: com.agon.app.ui.screens.RecipeItem? = null
    fun setTempRecipe(r: com.agon.app.ui.screens.RecipeItem) { tempRecipe = r }
    fun setTempFood(food: com.agon.app.ui.screens.FoodItem, meal: String) {
        tempFood = food
        tempMealType = meal
    }

    private val saveQueue = Channel<AppData>(Channel.UNLIMITED)

    init {
        viewModelScope.launch {
            saveQueue.receiveAsFlow().collect { snapshot ->
                val text = GlucoStorage.json.encodeToString(snapshot)
                getApplication<Application>().glucoDataStore.edit { it[GlucoStorage.KEY] = text }
            }
        }
        viewModelScope.launch {
            val loaded = try {
                GlucoStorage.read(getApplication())
            } catch (e: Exception) {
                null
            }
            val initial = loaded ?: defaultData()
            _data.value = initial
            _unlocked.value = !initial.settings.pinEnabled
            _ready.value = true
            ReminderScheduler.ensureChannels(getApplication())
            ReminderScheduler.sync(getApplication(), emptyList(), initial.reminders)
            if (loaded == null) saveQueue.trySend(initial)
        }
    }

    private fun update(block: (AppData) -> AppData) {
        if (!_ready.value) return
        val old = _data.value
        val next = block(old)
        _data.value = next
        saveQueue.trySend(next)
        if (old.reminders != next.reminders) {
            ReminderScheduler.sync(getApplication(), old.reminders, next.reminders)
        }
    }

    fun unlock(pin: String): Boolean {
        val s = _data.value.settings
        if (s.pinEnabled && pin != s.pin) return false
        _unlocked.value = true
        return true
    }

    fun lock() {
        if (_data.value.settings.pinEnabled) _unlocked.value = false
    }

    fun updateSettings(block: (Settings) -> Settings) {
        update { it.copy(settings = block(it.settings)) }
    }

    fun saveGlucose(id: String?, value: Double, unit: String, at: Long, context: String, notes: String) {
        update { d ->
            val now = System.currentTimeMillis()
            if (id == null) {
                d.copy(glucose = listOf(GlucoseEntry(uid(), value, unit, at, context, notes, now, now)) + d.glucose)
            } else {
                d.copy(glucose = d.glucose.map { e ->
                    if (e.id == id) e.copy(value = value, unit = unit, at = at, context = context, notes = notes, updatedAt = now) else e
                })
            }
        }
    }

    fun deleteGlucose(id: String) = update { it.copy(glucose = it.glucose.filter { e -> e.id != id }) }

    fun saveInsulin(id: String?, kind: String, name: String, dose: Double, at: Long, notes: String) {
        update { d ->
            val now = System.currentTimeMillis()
            if (id == null) {
                d.copy(insulin = listOf(InsulinEntry(uid(), kind, name, dose, "UI", at, notes, now, now)) + d.insulin)
            } else {
                d.copy(insulin = d.insulin.map { e ->
                    if (e.id == id) e.copy(kind = kind, name = name, dose = dose, at = at, notes = notes, updatedAt = now) else e
                })
            }
        }
    }

    fun deleteInsulin(id: String) = update { it.copy(insulin = it.insulin.filter { e -> e.id != id }) }

    fun saveReminder(r: Reminder) = update { d ->
        if (d.reminders.none { it.id == r.id }) d.copy(reminders = listOf(r) + d.reminders)
        else d.copy(reminders = d.reminders.map { if (it.id == r.id) r else it })
    }

    fun deleteReminder(id: String) = update { it.copy(reminders = it.reminders.filter { r -> r.id != id }) }

    fun toggleReminder(id: String) = update { d ->
        d.copy(reminders = d.reminders.map { if (it.id == id) it.copy(enabled = !it.enabled) else it })
    }

    fun saveMeal(m: Meal) = update { d ->
        if (d.meals.none { it.id == m.id }) d.copy(meals = listOf(m) + d.meals)
        else d.copy(meals = d.meals.map { if (it.id == m.id) m else it })
    }

    fun deleteMeal(id: String) = update { it.copy(meals = it.meals.filter { m -> m.id != id }) }

    fun saveSymptom(s: Symptom) = update { d ->
        if (d.symptoms.none { it.id == s.id }) d.copy(symptoms = listOf(s) + d.symptoms)
        else d.copy(symptoms = d.symptoms.map { if (it.id == s.id) s else it })
    }

    fun deleteSymptom(id: String) = update { it.copy(symptoms = it.symptoms.filter { s -> s.id != id }) }

    fun saveMedication(m: Medication) = update { d ->
        if (d.medications.none { it.id == m.id }) d.copy(medications = listOf(m) + d.medications)
        else d.copy(medications = d.medications.map { if (it.id == m.id) m else it })
    }

    fun deleteMedication(id: String) = update { it.copy(medications = it.medications.filter { m -> m.id != id }) }

    fun resetAll() {
        val fresh = defaultData()
        val old = _data.value
        _data.value = fresh
        saveQueue.trySend(fresh)
        _unlocked.value = true
        ReminderScheduler.sync(getApplication(), old.reminders, fresh.reminders)
    }
}
