package com.agon.app.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Meal
import com.agon.app.data.formatDateTime
import com.agon.app.data.toMgDl
import com.agon.app.data.uid
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.glucoColors
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.round
import kotlin.math.roundToInt

/* ───────── Preferências só da aba Alimentação ───────── */

private const val FOOD_PREFS = "gluco_food_tools"
private const val KEY_CUSTOM = "custom_foods_json"
private const val KEY_FAV_MEALS = "fav_meals_json"
private const val KEY_BOLUS = "bolus_factors_json"

data class CustomFood(
    val id: String,
    val name: String,
    val serving: String,
    val carbs: Double,
    val protein: Double = 0.0,
    val fat: Double = 0.0,
    val kcal: Double = 0.0,
)

data class FavMeal(
    val id: String,
    val name: String,
    val type: String,
    val description: String,
    val carbs: Double,
    val protein: Double = 0.0,
    val fat: Double = 0.0,
)

/** Fatores cadastrados pela usuária (orientação da equipe de saúde). */
data class BolusFactors(
    val carbRatio: Double = 0.0,       // g de carb cobertos por 1 U
    val sensitivity: Double = 0.0,     // mg/dL que 1 U reduz
    val target: Double = 100.0,        // meta mg/dL
    val durationHours: Double = 4.0,   // duração aprox. da insulina rápida (IOB)
)

data class MealBuilderLine(
    val id: String,
    val name: String,
    val qty: Double,
    val carbs: Double,
    val protein: Double,
    val fat: Double,
    val kcal: Double,
)

fun loadCustomFoods(ctx: Context): List<CustomFood> {
    val raw = ctx.getSharedPreferences(FOOD_PREFS, Context.MODE_PRIVATE).getString(KEY_CUSTOM, "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            CustomFood(
                o.optString("id"),
                o.optString("name"),
                o.optString("serving", "1 porção"),
                o.optDouble("carbs"),
                o.optDouble("protein"),
                o.optDouble("fat"),
                o.optDouble("kcal"),
            ).takeIf { it.id.isNotBlank() && it.name.isNotBlank() }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

fun saveCustomFoods(ctx: Context, list: List<CustomFood>) {
    val arr = JSONArray()
    list.forEach { f ->
        arr.put(
            JSONObject()
                .put("id", f.id)
                .put("name", f.name)
                .put("serving", f.serving)
                .put("carbs", f.carbs)
                .put("protein", f.protein)
                .put("fat", f.fat)
                .put("kcal", f.kcal),
        )
    }
    ctx.getSharedPreferences(FOOD_PREFS, Context.MODE_PRIVATE).edit().putString(KEY_CUSTOM, arr.toString()).apply()
}

fun loadFavMeals(ctx: Context): List<FavMeal> {
    val raw = ctx.getSharedPreferences(FOOD_PREFS, Context.MODE_PRIVATE).getString(KEY_FAV_MEALS, "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            FavMeal(
                o.optString("id"),
                o.optString("name"),
                o.optString("type", "almoco"),
                o.optString("description"),
                o.optDouble("carbs"),
                o.optDouble("protein"),
                o.optDouble("fat"),
            ).takeIf { it.id.isNotBlank() }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

fun saveFavMeals(ctx: Context, list: List<FavMeal>) {
    val arr = JSONArray()
    list.forEach { m ->
        arr.put(
            JSONObject()
                .put("id", m.id)
                .put("name", m.name)
                .put("type", m.type)
                .put("description", m.description)
                .put("carbs", m.carbs)
                .put("protein", m.protein)
                .put("fat", m.fat),
        )
    }
    ctx.getSharedPreferences(FOOD_PREFS, Context.MODE_PRIVATE).edit().putString(KEY_FAV_MEALS, arr.toString()).apply()
}

fun loadBolusFactors(ctx: Context): BolusFactors {
    val raw = ctx.getSharedPreferences(FOOD_PREFS, Context.MODE_PRIVATE).getString(KEY_BOLUS, null) ?: return BolusFactors()
    return try {
        val o = JSONObject(raw)
        BolusFactors(
            o.optDouble("carbRatio", 0.0),
            o.optDouble("sensitivity", 0.0),
            o.optDouble("target", 100.0),
            o.optDouble("durationHours", 4.0),
        )
    } catch (_: Exception) {
        BolusFactors()
    }
}

fun saveBolusFactors(ctx: Context, f: BolusFactors) {
    val o = JSONObject()
        .put("carbRatio", f.carbRatio)
        .put("sensitivity", f.sensitivity)
        .put("target", f.target)
        .put("durationHours", f.durationHours)
    ctx.getSharedPreferences(FOOD_PREFS, Context.MODE_PRIVATE).edit().putString(KEY_BOLUS, o.toString()).apply()
}

/**
 * Cálculo de bolus (fórmula padrão de contagem de carb + correção).
 * Todos os fatores devem vir do tratamento da pessoa (equipe de saúde).
 * half-up em 0,5 U para leitura prática em caneta.
 */
fun computeBolus(
    carbsG: Double,
    glucoseMgDl: Double,
    factors: BolusFactors,
    iob: Double = 0.0,
    includeMeal: Boolean = true,
    includeCorr: Boolean = true,
    roundStep: Double = 0.5,
): Triple<Double, Double, Double>? {
    if (includeMeal && factors.carbRatio <= 0) return null
    if (includeCorr && factors.sensitivity <= 0) return null
    if (!includeMeal && !includeCorr) return null
    val meal = if (includeMeal && factors.carbRatio > 0) carbsG / factors.carbRatio else 0.0
    val corr = if (includeCorr && factors.sensitivity > 0) (glucoseMgDl - factors.target) / factors.sensitivity else 0.0
    val raw = meal + corr - iob.coerceAtLeast(0.0)
    val total = max(0.0, raw)
    val step = if (roundStep <= 0) 0.5 else roundStep
    val rounded = round(total / step) * step
    return Triple(meal, corr, rounded)
}

/** IOB linear simples a partir de insulinas rápidas registradas no app. */
fun estimateIobFromLog(entries: List<com.agon.app.data.InsulinEntry>, durationHours: Double): Double {
    if (durationHours <= 0) return 0.0
    val now = System.currentTimeMillis()
    val window = (durationHours * 3600_000L).toLong()
    val rapid = listOf(
        "lispro", "asparte", "aspart", "glulisina", "glulisine", "regular", "humalog",
        "novorapid", "novo rapid", "fiasp", "apidra", "humulin r", "novolin r", "rápida", "rapida", "bolus",
    )
    var iob = 0.0
    for (e in entries) {
        val age = now - e.at
        if (age < 0 || age > window) continue
        val n = e.name.lowercase()
        val isRapid = rapid.any { it in n } || e.kind.lowercase().let { "bolus" in it || "rapida" in it || "rápida" in it || "aplicacao" in it && rapid.any { r -> r in n } }
        // se o nome não indica basal, conta como possível rápida quando marcado aplicacao
        val basal = listOf("glargina", "lantus", "tresiba", "degludeca", "detemir", "levemir", "nph", "basal", "toujeo", "basaglar")
        if (basal.any { it in n }) continue
        if (!isRapid && !basal.any { it in n }) {
            // aplicação genérica recente: inclui no IOB com cautela
        } else if (!isRapid) continue
        val remain = 1.0 - (age.toDouble() / window)
        if (remain > 0) iob += e.dose * remain
    }
    return (round(iob * 10.0) / 10.0).coerceAtLeast(0.0)
}

private const val KEY_BOLUS_HIST = "bolus_hist_json"
private const val KEY_ROUND_STEP = "bolus_round_step"

fun loadBolusHistory(ctx: Context): List<String> {
    val raw = ctx.getSharedPreferences(FOOD_PREFS, Context.MODE_PRIVATE).getString(KEY_BOLUS_HIST, "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { arr.getString(it) }
    } catch (_: Exception) { emptyList() }
}

fun pushBolusHistory(ctx: Context, line: String) {
    val cur = loadBolusHistory(ctx).toMutableList()
    cur.add(0, line)
    val arr = JSONArray()
    cur.take(20).forEach { arr.put(it) }
    ctx.getSharedPreferences(FOOD_PREFS, Context.MODE_PRIVATE).edit().putString(KEY_BOLUS_HIST, arr.toString()).apply()
}


/* ───────── Hub de ferramentas ───────── */

@Composable
fun FoodToolsHubScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    ScrollScreen {
        BackTitle("Ferramentas de alimentação", { nav.popBackStack() })
        Text("Recursos extras só desta aba. Não alteram lembretes nem alertas do app.", color = g.muted, fontSize = 13.sp)
        ToolRow("Montar refeição", "Some vários alimentos e veja o total de carb") {
            nav.navigate(Routes.FOOD_MEAL_BUILDER)
        }
        ToolRow("Meus alimentos", "Cadastre receitas/itens que não estão na tabela") {
            nav.navigate(Routes.FOOD_CUSTOM)
        }
        ToolRow("Refeições favoritas", "Salve e repita o almoço de sempre") {
            nav.navigate(Routes.FOOD_FAV_MEALS)
        }
        ToolRow("Calculadora de bolus", "Só com os fatores da sua equipe de saúde") {
            nav.navigate(Routes.FOOD_BOLUS)
        }
        ToolRow("Refeição × glicemia", "Veja glicemias próximas às refeições") {
            nav.navigate(Routes.FOOD_GLUCOSE_LINK)
        }
    }
}

@Composable
private fun ToolRow(title: String, subtitle: String, onClick: () -> Unit) {
    val g = glucoColors()
    GCard(Modifier.padding(top = 8.dp).clickable(onClick = onClick)) {
        Text(title, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        Text(subtitle, color = g.muted, fontSize = 12.sp)
    }
}

/* ───────── Alimentos customizados ───────── */

@Composable
fun FoodCustomScreen(nav: NavHostController) {
    val g = glucoColors()
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(loadCustomFoods(ctx)) }
    var name by remember { mutableStateOf("") }
    var serving by remember { mutableStateOf("1 porção") }
    var carbs by remember { mutableStateOf("") }
    var protein by remember { mutableStateOf("") }
    var fat by remember { mutableStateOf("") }
    var kcal by remember { mutableStateOf("") }

    ScrollScreen {
        BackTitle("Meus alimentos", { nav.popBackStack() })
        GCard {
            Text("Novo alimento", color = g.ink, fontWeight = FontWeight.Bold)
            GField("Nome", name, { name = it }, "Ex.: Torta da vovó")
            GField("Porção", serving, { serving = it }, "Ex.: 1 fatia")
            GField("Carboidratos (g)", carbs, { carbs = it }, "Obrigatório", numeric = true)
            GField("Proteínas (g)", protein, { protein = it }, "Opcional", numeric = true)
            GField("Gorduras (g)", fat, { fat = it }, "Opcional", numeric = true)
            GField("Calorias (kcal)", kcal, { kcal = it }, "Opcional", numeric = true)
            PrimaryButton("Salvar alimento", g.green, {
                val c = carbs.replace(",", ".").toDoubleOrNull() ?: return@PrimaryButton
                if (name.isBlank()) return@PrimaryButton
                val item = CustomFood(
                    id = uid(),
                    name = name.trim(),
                    serving = serving.trim().ifBlank { "1 porção" },
                    carbs = c,
                    protein = protein.replace(",", ".").toDoubleOrNull() ?: 0.0,
                    fat = fat.replace(",", ".").toDoubleOrNull() ?: 0.0,
                    kcal = kcal.replace(",", ".").toDoubleOrNull() ?: 0.0,
                )
                list = listOf(item) + list
                saveCustomFoods(ctx, list)
                name = ""; carbs = ""; protein = ""; fat = ""; kcal = ""
            }, Modifier.padding(top = 8.dp))
        }
        SectionTitle("Cadastrados (${list.size})")
        list.forEach { f ->
            GCard(Modifier.padding(top = 6.dp)) {
                Text(f.name, color = g.ink, fontWeight = FontWeight.Bold)
                Text("${f.serving} · ${f.carbs} g carb · ${f.protein} g prot · ${f.fat} g gord", color = g.muted, fontSize = 12.sp)
                Text("Excluir", color = g.red, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                    list = list.filter { it.id != f.id }
                    saveCustomFoods(ctx, list)
                }.padding(top = 4.dp))
            }
        }
        if (list.isEmpty()) Text("Nenhum alimento próprio ainda.", color = g.muted)
    }
}

/* ───────── Montar refeição ───────── */

@Composable
fun FoodMealBuilderScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val ctx = LocalContext.current
    val custom = remember { loadCustomFoods(ctx) }
    var lines by remember { mutableStateOf<List<MealBuilderLine>>(emptyList()) }
    var mealType by remember { mutableStateOf("almoco") }
    var mealExpanded by remember { mutableStateOf(false) }
    var pickName by remember { mutableStateOf("") }
    var pickCarbs by remember { mutableStateOf("") }
    var pickProt by remember { mutableStateOf("") }
    var pickFat by remember { mutableStateOf("") }
    var pickKcal by remember { mutableStateOf("") }
    var pickQty by remember { mutableStateOf("1") }
    var saveAsFav by remember { mutableStateOf(false) }
    var favName by remember { mutableStateOf("") }

    val totalC = lines.sumOf { it.carbs * it.qty }
    val totalP = lines.sumOf { it.protein * it.qty }
    val totalF = lines.sumOf { it.fat * it.qty }
    val totalK = lines.sumOf { it.kcal * it.qty }

    ScrollScreen {
        BackTitle("Montar refeição", { nav.popBackStack() })
        Box {
            Text(
                MEAL_OPTIONS.find { it.first == mealType }?.second ?: "Almoço",
                color = g.ink, fontWeight = FontWeight.Bold,
                modifier = Modifier.clickable { mealExpanded = true }.padding(8.dp),
            )
            DropdownMenu(expanded = mealExpanded, onDismissRequest = { mealExpanded = false }) {
                MEAL_OPTIONS.forEach { (k, l) ->
                    DropdownMenuItem(text = { Text(l) }, onClick = { mealType = k; mealExpanded = false })
                }
            }
        }

        GCard {
            Text("Adicionar item", color = g.ink, fontWeight = FontWeight.Bold)
            if (custom.isNotEmpty()) {
                Text("Toque num alimento seu:", color = g.muted, fontSize = 12.sp)
                custom.take(8).forEach { f ->
                    Text("＋ ${f.name} (${f.carbs} g carb)", color = g.violet, fontSize = 13.sp, modifier = Modifier.clickable {
                        lines = lines + MealBuilderLine(uid(), f.name, 1.0, f.carbs, f.protein, f.fat, f.kcal)
                    }.padding(vertical = 2.dp))
                }
            }
            GField("Nome do item", pickName, { pickName = it }, "Ex.: Arroz")
            GField("Quantidade (vezes a porção)", pickQty, { pickQty = it }, "1", numeric = true)
            GField("Carb (g) por porção", pickCarbs, { pickCarbs = it }, "Obrigatório", numeric = true)
            GField("Prot (g)", pickProt, { pickProt = it }, "0", numeric = true)
            GField("Gord (g)", pickFat, { pickFat = it }, "0", numeric = true)
            GField("Kcal", pickKcal, { pickKcal = it }, "0", numeric = true)
            PrimaryButton("Incluir na refeição", g.violet, {
                val c = pickCarbs.replace(",", ".").toDoubleOrNull() ?: return@PrimaryButton
                val q = pickQty.replace(",", ".").toDoubleOrNull() ?: 1.0
                if (pickName.isBlank()) return@PrimaryButton
                lines = lines + MealBuilderLine(
                    uid(), pickName.trim(), q, c,
                    pickProt.replace(",", ".").toDoubleOrNull() ?: 0.0,
                    pickFat.replace(",", ".").toDoubleOrNull() ?: 0.0,
                    pickKcal.replace(",", ".").toDoubleOrNull() ?: 0.0,
                )
                pickName = ""; pickCarbs = ""; pickProt = ""; pickFat = ""; pickKcal = ""; pickQty = "1"
            }, Modifier.padding(top = 6.dp))
        }

        SectionTitle("Itens (${lines.size})")
        lines.forEach { line ->
            GCard(Modifier.padding(top = 4.dp)) {
                Text("${line.name} × ${line.qty}", color = g.ink, fontWeight = FontWeight.Medium)
                Text(
                    "${"%.1f".format(line.carbs * line.qty)} g carb · " +
                        "${"%.1f".format(line.protein * line.qty)} g prot · " +
                        "${"%.1f".format(line.fat * line.qty)} g gord",
                    color = g.muted, fontSize = 12.sp,
                )
                Text("Remover", color = g.red, fontSize = 12.sp, modifier = Modifier.clickable {
                    lines = lines.filter { it.id != line.id }
                })
            }
        }

        GCard(Modifier.padding(top = 10.dp)) {
            Text("Total da refeição", color = g.ink, fontWeight = FontWeight.ExtraBold)
            Text("Carboidratos: ${"%.1f".format(totalC)} g", color = g.violetDeep, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text("Proteínas: ${"%.1f".format(totalP)} g", color = g.ink)
            Text("Gorduras: ${"%.1f".format(totalF)} g", color = g.ink)
            if (totalK > 0) Text("Calorias: ${totalK.roundToInt()} kcal", color = g.ink)
            PrimaryButton("Salvar no diário", g.green, {
                if (lines.isEmpty()) return@PrimaryButton
                val desc = lines.joinToString(" + ") { "${it.name}×${it.qty}" }
                vm.saveMeal(
                    Meal(
                        id = uid(),
                        type = mealType,
                        description = desc,
                        carbs = totalC,
                        at = System.currentTimeMillis(),
                        notes = "prot=${"%.1f".format(totalP)};fat=${"%.1f".format(totalF)};kcal=${totalK.roundToInt()};fonte=montar-refeicao",
                    ),
                )
                if (saveAsFav && favName.isNotBlank()) {
                    val favs = loadFavMeals(ctx) + FavMeal(uid(), favName.trim(), mealType, desc, totalC, totalP, totalF)
                    saveFavMeals(ctx, favs)
                }
                nav.popBackStack()
            }, Modifier.padding(top = 8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = saveAsFav, onCheckedChange = { saveAsFav = it })
                Text("Salvar também como favorita", color = g.ink, fontSize = 13.sp)
            }
            if (saveAsFav) GField("Nome da favorita", favName, { favName = it }, "Ex.: Almoço trabalho")
            TextButton(onClick = {
                // leva total de carb para a calculadora via SharedPreferences rápido
                ctx.getSharedPreferences(FOOD_PREFS, Context.MODE_PRIVATE).edit()
                    .putFloat("last_meal_carbs", totalC.toFloat()).apply()
                nav.navigate(Routes.FOOD_BOLUS)
            }) {
                Text("Usar este total na calculadora de bolus", color = g.violet, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/* ───────── Refeições favoritas ───────── */

@Composable
fun FoodFavMealsScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val ctx = LocalContext.current
    var list by remember { mutableStateOf(loadFavMeals(ctx)) }

    ScrollScreen {
        BackTitle("Refeições favoritas", { nav.popBackStack() })
        if (list.isEmpty()) Text("Nenhuma favorita. Monte uma refeição e marque para salvar.", color = g.muted)
        list.forEach { m ->
            GCard(Modifier.padding(top = 8.dp)) {
                Text(m.name, color = g.ink, fontWeight = FontWeight.Bold)
                Text(m.description, color = g.muted, fontSize = 13.sp)
                Text(
                    "${MEAL_OPTIONS.find { it.first == m.type }?.second ?: m.type} · ${"%.1f".format(m.carbs)} g carb",
                    color = g.violetDeep, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                )
                Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Registrar agora", color = g.green, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                        vm.saveMeal(
                            Meal(
                                id = uid(),
                                type = m.type,
                                description = m.name + " — " + m.description,
                                carbs = m.carbs,
                                at = System.currentTimeMillis(),
                                notes = "prot=${m.protein};fat=${m.fat};fonte=favorita",
                            ),
                        )
                    })
                    Text("Excluir", color = g.red, fontWeight = FontWeight.Bold, modifier = Modifier.clickable {
                        list = list.filter { it.id != m.id }
                        saveFavMeals(ctx, list)
                    })
                }
            }
        }
    }
}

/* ───────── Calculadora de bolus ───────── */

@Composable
fun FoodBolusScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val ctx = LocalContext.current
    val data by vm.data.collectAsStateWithLifecycle()
    var factors by remember { mutableStateOf(loadBolusFactors(ctx)) }
    var editFactors by remember { mutableStateOf(factors.carbRatio <= 0 || factors.sensitivity <= 0) }
    var ratioTxt by remember { mutableStateOf(if (factors.carbRatio > 0) factors.carbRatio.toString() else "") }
    var sensTxt by remember { mutableStateOf(if (factors.sensitivity > 0) factors.sensitivity.toString() else "") }
    var targetTxt by remember { mutableStateOf(factors.target.toString()) }
    var durTxt by remember { mutableStateOf(factors.durationHours.toString()) }

    val lastCarbsPref = ctx.getSharedPreferences(FOOD_PREFS, Context.MODE_PRIVATE).getFloat("last_meal_carbs", -1f)
    val lastMealCarbs = data.meals.maxByOrNull { it.at }?.carbs
    var carbsTxt by remember {
        mutableStateOf(
            when {
                lastCarbsPref > 0 -> lastCarbsPref.toString()
                lastMealCarbs != null -> lastMealCarbs.toString()
                else -> ""
            },
        )
    }
    val lastG = data.glucose.maxByOrNull { it.at }
    val lastMg = lastG?.let { toMgDl(it.value, it.unit) }
    var glucoseTxt by remember { mutableStateOf(lastMg?.roundToInt()?.toString() ?: "") }
    val autoIob = remember(data.insulin, factors.durationHours) {
        estimateIobFromLog(data.insulin, factors.durationHours)
    }
    var iobTxt by remember { mutableStateOf(if (autoIob > 0) autoIob.toString() else "0") }
    var useAutoIob by remember { mutableStateOf(true) }
    var includeMeal by remember { mutableStateOf(true) }
    var includeCorr by remember { mutableStateOf(true) }
    var roundStep by remember {
        mutableStateOf(
            ctx.getSharedPreferences(FOOD_PREFS, Context.MODE_PRIVATE).getFloat(KEY_ROUND_STEP, 0.5f).toDouble(),
        )
    }
    var result by remember { mutableStateOf<Triple<Double, Double, Double>?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var warn by remember { mutableStateOf<String?>(null) }
    var hist by remember { mutableStateOf(loadBolusHistory(ctx)) }

    fun recalculate() {
        err = null
        warn = null
        val c = carbsTxt.replace(",", ".").toDoubleOrNull() ?: 0.0
        val glu = glucoseTxt.replace(",", ".").toDoubleOrNull()
        val iob = if (useAutoIob) autoIob else (iobTxt.replace(",", ".").toDoubleOrNull() ?: 0.0)
        if (glu == null) {
            err = "Informe a glicemia atual."
            result = null
            return
        }
        if (glu < 70) {
            warn = "Glicemia baixa (< 70 mg/dL). Correção para cima não é adequada — trate a hipoglicemia conforme sua equipe orientou. Cálculo de refeição só se fizer sentido com orientação."
            includeCorr = false
        }
        if (includeMeal && c <= 0) {
            err = "Informe os carboidratos ou desligue o bolus de refeição."
            result = null
            return
        }
        val f = factors
        if (includeMeal && f.carbRatio <= 0) {
            err = "Cadastre a razão de carb (g cobertos por 1 U) — valor da sua equipe de saúde."
            result = null
            return
        }
        if (includeCorr && f.sensitivity <= 0) {
            err = "Cadastre o fator de sensibilidade (mg/dL por 1 U)."
            result = null
            return
        }
        val r = computeBolus(c, glu, f, iob, includeMeal, includeCorr, roundStep)
        result = r
        if (r != null) {
            val line = "${formatDateTime(System.currentTimeMillis())}: carb=${"%.0f".format(c)} g, glic=${glu.roundToInt()}, IOB=${"%.1f".format(iob)} → ${"%.1f".format(r.third)} U"
            pushBolusHistory(ctx, line)
            hist = loadBolusHistory(ctx)
        }
    }

    ScrollScreen {
        BackTitle("Calculadora de bolus", { nav.popBackStack() })
        Box(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(g.orangeSoft).padding(12.dp),
        ) {
            Text(
                "Apoio de conta com os fatores que você cadastrar (equipe de saúde). Não é prescrição. " +
                    "Não aplique se estiver em dúvida, doente, hipoglicemia ou sem orientação atualizada.",
                color = g.ink, fontSize = 12.sp,
            )
        }

        GCard(Modifier.padding(top = 10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Meus fatores", color = g.ink, fontWeight = FontWeight.Bold)
                Text(if (editFactors) "Ocultar" else "Editar", color = g.violet, fontWeight = FontWeight.Bold, modifier = Modifier.clickable { editFactors = !editFactors })
            }
            if (!editFactors && factors.carbRatio > 0) {
                Text("1 U cobre ${factors.carbRatio} g de carb", color = g.muted, fontSize = 13.sp)
                Text("1 U reduz ~${factors.sensitivity} mg/dL", color = g.muted, fontSize = 13.sp)
                Text("Meta: ${factors.target.roundToInt()} mg/dL · duração IOB ~${factors.durationHours} h", color = g.muted, fontSize = 13.sp)
            }
            if (editFactors) {
                GField("Razão carb (g por 1 U)", ratioTxt, { ratioTxt = it }, "Ex.: 10", numeric = true)
                GField("Sensibilidade (mg/dL por 1 U)", sensTxt, { sensTxt = it }, "Ex.: 40", numeric = true)
                GField("Meta (mg/dL)", targetTxt, { targetTxt = it }, "100", numeric = true)
                GField("Duração insulina rápida (h)", durTxt, { durTxt = it }, "4", numeric = true)
                PrimaryButton("Salvar fatores", g.violet, {
                    factors = BolusFactors(
                        ratioTxt.replace(",", ".").toDoubleOrNull() ?: 0.0,
                        sensTxt.replace(",", ".").toDoubleOrNull() ?: 0.0,
                        targetTxt.replace(",", ".").toDoubleOrNull() ?: 100.0,
                        durTxt.replace(",", ".").toDoubleOrNull() ?: 4.0,
                    )
                    saveBolusFactors(ctx, factors)
                    editFactors = false
                    if (useAutoIob) iobTxt = estimateIobFromLog(data.insulin, factors.durationHours).toString()
                }, Modifier.padding(top = 6.dp))
            }
        }

        GCard(Modifier.padding(top = 10.dp)) {
            Text("O que calcular", color = g.ink, fontWeight = FontWeight.Bold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = includeMeal, onCheckedChange = { includeMeal = it })
                Text("Bolus de refeição (carb)", color = g.ink, fontSize = 13.sp)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = includeCorr, onCheckedChange = { includeCorr = it })
                Text("Correção de glicemia", color = g.ink, fontSize = 13.sp)
            }
            Text("Arredondar para", color = g.muted, fontSize = 12.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(0.5 to "0,5 U", 1.0 to "1 U").forEach { (step, label) ->
                    val sel = roundStep == step
                    Box(
                        Modifier.clip(RoundedCornerShape(12.dp)).background(if (sel) g.violet else g.inputBg)
                            .clickable {
                                roundStep = step
                                ctx.getSharedPreferences(FOOD_PREFS, Context.MODE_PRIVATE).edit()
                                    .putFloat(KEY_ROUND_STEP, step.toFloat()).apply()
                            }.padding(horizontal = 12.dp, vertical = 8.dp),
                    ) { Text(label, color = if (sel) androidx.compose.ui.graphics.Color.White else g.ink, fontSize = 13.sp) }
                }
            }
        }

        GCard(Modifier.padding(top = 10.dp)) {
            Text("Números de agora", color = g.ink, fontWeight = FontWeight.Bold)
            if (includeMeal) {
                GField("Carboidratos (g)", carbsTxt, { carbsTxt = it }, "Ex.: 45", numeric = true)
                if (lastMealCarbs != null) {
                    Text(
                        "Usar última refeição do diário (${"%.0f".format(lastMealCarbs)} g)",
                        color = g.violet, fontSize = 12.sp,
                        modifier = Modifier.clickable { carbsTxt = lastMealCarbs.toString() }.padding(bottom = 4.dp),
                    )
                }
            }
            GField("Glicemia (mg/dL)", glucoseTxt, { glucoseTxt = it }, lastMg?.let { "Última: ${it.roundToInt()}" } ?: "Ex.: 160", numeric = true)
            if (lastG != null) {
                Text(
                    "Usar última do app: ${lastMg!!.roundToInt()} mg/dL (${formatDateTime(lastG.at)})",
                    color = g.violet, fontSize = 12.sp,
                    modifier = Modifier.clickable { glucoseTxt = lastMg.roundToInt().toString() },
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = useAutoIob, onCheckedChange = {
                    useAutoIob = it
                    if (it) iobTxt = autoIob.toString()
                })
                Text("IOB automático do diário de insulina (~${"%.1f".format(autoIob)} U)", color = g.ink, fontSize = 13.sp)
            }
            if (!useAutoIob) {
                GField("IOB manual (U)", iobTxt, { iobTxt = it }, "0", numeric = true)
            }
            PrimaryButton("Calcular", g.green, { recalculate() }, Modifier.padding(top = 8.dp))
        }

        warn?.let { Text(it, color = g.orange, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) }
        err?.let { Text(it, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp)) }

        result?.let { (meal, corr, total) ->
            GCard(Modifier.padding(top = 10.dp)) {
                Text("Resultado", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                if (includeMeal) Text("Refeição: ${"%.2f".format(meal)} U", color = g.ink)
                if (includeCorr) Text("Correção: ${"%.2f".format(corr)} U", color = g.ink)
                Text("Sugestão total: ${"%.1f".format(total)} U", color = g.violetDeep, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                Text("Confira com sua equipe antes de qualquer aplicação.", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }

        if (hist.isNotEmpty()) {
            SectionTitle("Últimos cálculos")
            hist.take(8).forEach { line ->
                Text(line, color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 2.dp))
            }
        }
        Text(
            "IOB automático estima sobra de insulinas rápidas do diário (decai linear até a duração cadastrada). Basais (NPH, glargina, etc.) são ignoradas.",
            color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp, bottom = 24.dp),
        )
    }
}

@Composable
fun FoodGlucoseLinkScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val data by vm.data.collectAsStateWithLifecycle()
    val meals = data.meals.sortedByDescending { it.at }.take(30)
    val windowMs = 3L * 60 * 60 * 1000 // 3h

    ScrollScreen {
        BackTitle("Refeição × glicemia", { nav.popBackStack() })
        Text(
            "Mostra glicemias registradas até 3 h depois de cada refeição (leitura de padrão, não diagnóstico).",
            color = g.muted, fontSize = 13.sp,
        )
        if (meals.isEmpty()) Text("Sem refeições no diário.", color = g.muted)
        meals.forEach { m ->
            val after = data.glucose.filter { it.at >= m.at && it.at <= m.at + windowMs }
                .sortedBy { it.at }
            GCard(Modifier.padding(top = 8.dp)) {
                Text(m.description, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(
                    "${MEAL_OPTIONS.find { it.first == m.type }?.second ?: m.type} · " +
                        (m.carbs?.let { "${it} g carb · " } ?: "") + formatDateTime(m.at),
                    color = g.muted, fontSize = 12.sp,
                )
                if (after.isEmpty()) {
                    Text("Nenhuma glicemia nas 3 h seguintes.", color = g.muted, fontSize = 12.sp)
                } else {
                    after.forEach { gl ->
                        val mg = toMgDl(gl.value, gl.unit).roundToInt()
                        Text("→ $mg mg/dL (${formatDateTime(gl.at)})", color = g.violetDeep, fontSize = 13.sp)
                    }
                }
            }
        }
    }
}
