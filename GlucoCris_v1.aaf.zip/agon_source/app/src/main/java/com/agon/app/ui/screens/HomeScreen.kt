package com.agon.app.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.formatDateTime
import com.agon.app.data.formatLongDate
import com.agon.app.data.greeting
import com.agon.app.data.rangeStatus
import com.agon.app.data.statusLabel
import com.agon.app.data.toMgDl
import com.agon.app.data.weekdayLong
import com.agon.app.love.LOVE_PHONE_DISPLAY
import com.agon.app.love.LOVE_PHONE_TEL
import com.agon.app.love.MAIN_LOVE_MESSAGE
import com.agon.app.love.SAMU_TEL
import com.agon.app.love.openDialer
import com.agon.app.love.openWhatsApp
import com.agon.app.love.phraseForToday
import com.agon.app.ui.components.ActionButton
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GlucoseChart
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.theme.glucoColors
import kotlin.math.roundToInt

@Composable
fun HomeScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val context = LocalContext.current
    val settings = data.settings
    var phrase by remember { mutableStateOf("") }
    var showMood by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { phrase = phraseForToday(context) }
    if (showMood) {
        MoodSheet(settings.mood, onDismiss = { showMood = false }) { id ->
            vm.updateSettings { it.copy(mood = id, moodAt = System.currentTimeMillis()) }
            showMood = false
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    val latest = data.glucose.maxByOrNull { it.at }
    val mg = latest?.let { toMgDl(it.value, it.unit) }
    val status = mg?.let { rangeStatus(it, settings.targetLow, settings.targetHigh) }
    val statusColor = when (status) {
        "ok" -> g.green
        "low" -> g.orange
        "high" -> g.red
        else -> g.muted
    }

    ScrollScreen {
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(Brush.horizontalGradient(listOf(g.heroStart, g.heroEnd)))
                .padding(20.dp),
        ) {
            Column {
                Text("Gluco Cris ❤️", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(
                    com.agon.app.data.firstName(settings.displayName).let { first ->
                        if (first.isNotBlank()) "${greeting()}, $first!" else "${greeting()}!"
                    },
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 24.sp,
                    modifier = Modifier.padding(top = 4.dp),
                )
                MoodButton(settings.mood) { showMood = true }
                Text(
                    "${weekdayLong().replaceFirstChar { it.uppercase() }}, ${formatLongDate()}",
                    color = Color.White.copy(alpha = 0.85f),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 2.dp),
                )
                Text(
                    "Seu espaço de cuidado, organizado com calma e clareza.",
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 10.dp),
                )
            }
        }

        GCard(Modifier.padding(top = 14.dp)) {
            Text("Uma mensagem para você ❤️", color = g.blush, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            Text(
                MAIN_LOVE_MESSAGE,
                color = g.ink,
                fontSize = 15.sp,
                lineHeight = 22.sp,
                modifier = Modifier.padding(top = 8.dp),
            )
            if (phrase.isNotEmpty()) {
                Text(
                    phrase,
                    color = g.violetDeep,
                    fontSize = 13.sp,
                    fontStyle = FontStyle.Italic,
                    lineHeight = 19.sp,
                    modifier = Modifier.padding(top = 12.dp),
                )
                Text("Frase carinhosa de hoje", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp))
            }
        }

        // Botão fixo Cris IA na tela inicial
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 12.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Brush.horizontalGradient(listOf(g.violet, g.blush)))
                .clickable { nav.navigate(Routes.CRIS_IA) }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.Favorite, null, tint = Color.White)
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text("❤️ Conversar com a Cris IA", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text(
                    "Sua companheira inteligente da diabetes — texto e voz",
                    color = Color.White.copy(alpha = 0.92f),
                    fontSize = 12.sp,
                )
            }
        }

        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton(
                " Ligar para meu amor ❤️",
                Icons.Filled.Call,
                g.violet,
                { openDialer(context, LOVE_PHONE_TEL) },
                Modifier.weight(1f),
            )
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ActionButton(
                "falar com amor por WhatsApp ",
                Icons.Filled.Favorite,
                g.blush,
                { openWhatsApp(context) },
                Modifier.weight(1f),
            )
        }
        Text(
            "A ligação não começa sozinha: o discador abre com $LOVE_PHONE_DISPLAY para você confirmar. O WhatsApp só abre a conversa, sem enviar mensagem.",
            color = g.muted,
            fontSize = 11.sp,
            modifier = Modifier.padding(top = 6.dp, start = 4.dp, end = 4.dp),
        )

        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 14.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(g.red)
                .clickable { openDialer(context, SAMU_TEL) }
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Filled.LocalHospital, null, tint = Color.White)
            Column(Modifier.padding(start = 12.dp).weight(1f)) {
                Text(" Emergência — SAMU 192", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text(
                    "Abre o discador com 192. Não aciona o atendimento sozinho e não garante que a chamada seja completada.",
                    color = Color.White.copy(alpha = 0.92f),
                    fontSize = 12.sp,
                )
            }
        }

        GCard(Modifier.padding(top = 14.dp)) {
            Text("Última medição", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            if (latest == null || mg == null || status == null) {
                Text("Nenhuma medição ainda.", color = g.ink, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
            } else {
                Row(verticalAlignment = Alignment.Bottom, modifier = Modifier.padding(top = 4.dp)) {
                    Text(mg.roundToInt().toString(), color = statusColor, fontWeight = FontWeight.ExtraBold, fontSize = 40.sp)
                    Text(" mg/dL", color = g.muted, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp, start = 4.dp))
                }
                Text(statusLabel(status), color = statusColor, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(
                    "${GLUCOSE_CONTEXT_LABEL[latest.context] ?: latest.context} · ${formatDateTime(latest.at)}",
                    color = g.muted,
                    fontSize = 12.sp,
                    modifier = Modifier.padding(top = 2.dp),
                )
            }
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ActionButton("Registrar glicose", Icons.Filled.WaterDrop, g.violet, { nav.navigate(Routes.glucoseForm(null)) }, Modifier.weight(1f))
                ActionButton("Registrar insulina", Icons.Filled.WaterDrop, g.blue, { nav.navigate(Routes.insulinForm(null)) }, Modifier.weight(1f))
            }
        }


        // Resumo semanal rápido
        run {
            val weekMs = 7L * 24 * 60 * 60 * 1000
            val since = System.currentTimeMillis() - weekMs
            val weekG = data.glucose.filter { it.at >= since }
            val weekI = data.insulin.filter { it.at >= since }
            val low = settings.targetLow
            val high = settings.targetHigh
            val inRange = weekG.count {
                val mgv = toMgDl(it.value, it.unit)
                mgv >= low && mgv <= high
            }
            val pct = if (weekG.isNotEmpty()) inRange * 100 / weekG.size else null
            GCard(Modifier.padding(top = 12.dp).clickable { nav.navigate(Routes.CRIS_IA) }) {
                Text("Resumo dos últimos 7 dias", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
                Text(
                    if (weekG.isEmpty() && weekI.isEmpty()) "Sem registros nesta semana. Toque para falar com a Cris IA."
                    else "Glicemias: ${weekG.size}" + (pct?.let { " · $it% na meta do app" } ?: "") + " · Insulinas: ${weekI.size}",
                    color = g.muted,
                    fontSize = 13.sp,
                    modifier = Modifier.padding(top = 4.dp),
                )
                Text("Abrir Cris IA para consulta em 1 minuto →", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }

        SectionTitle("Evolução", "Ver estatísticas") { nav.navigate(Routes.STATS) }
        GCard { GlucoseChart(data.glucose, settings.targetLow, settings.targetHigh) }

        val active = data.reminders.filter { it.enabled }.sortedWith(compareBy({ it.hour }, { it.minute }))
        SectionTitle("Próximo lembrete", "Ver todos") { Routes.goTab(nav, Routes.REMINDERS) }
        GCard {
            if (active.isEmpty()) {
                Text("Nenhum lembrete ativo.", color = g.muted, fontSize = 14.sp)
            } else {
                active.take(3).forEach { r ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(r.title, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Text(
                            "${com.agon.app.data.formatClock(r.hour, r.minute)} · ${com.agon.app.data.daysLabel(r.days)}",
                            color = g.muted,
                            fontSize = 12.sp,
                        )
                        Text(
                            (if (r.kind == "glicose") "Medição de glicose" else "Aplicação de insulina") +
                                if (r.notes.isNotEmpty()) " · ${r.notes}" else "",
                            color = g.violetDeep,
                            fontSize = 12.sp,
                        )
                    }
                }
            }
        }

        SectionTitle("Histórico resumido", "Ver todos") { Routes.goTab(nav, Routes.HISTORY) }
        GCard {
            val recent = data.glucose.sortedByDescending { it.at }.take(4)
            if (recent.isEmpty()) {
                Text("Sem registros.", color = g.muted, modifier = Modifier.padding(12.dp))
            } else {
                recent.forEach { e ->
                    val v = toMgDl(e.value, e.unit)
                    val st = rangeStatus(v, settings.targetLow, settings.targetHigh)
                    val c = when (st) { "ok" -> g.green; "low" -> g.orange; else -> g.red }
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { nav.navigate(Routes.glucoseForm(e.id)) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Text(v.roundToInt().toString(), color = c, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, modifier = Modifier.padding(end = 10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(GLUCOSE_CONTEXT_LABEL[e.context] ?: e.context, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            Text("${com.agon.app.data.formatDate(e.at)} · ${com.agon.app.data.formatTime(e.at)}", color = g.muted, fontSize = 12.sp)
                        }
                        Text(statusLabel(st), color = c, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
