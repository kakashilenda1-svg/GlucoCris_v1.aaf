package com.agon.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SelectableDates
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.ProfileMed
import com.agon.app.data.Settings
import com.agon.app.data.ageFrom
import com.agon.app.data.formatBirthDate
import com.agon.app.data.formatCpf
import com.agon.app.data.isValidCpf
import com.agon.app.data.isoFromPickerMillis
import com.agon.app.data.pickerMillisFromIso
import com.agon.app.data.uid
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.GField
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.theme.glucoColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val UF_LIST = listOf(
    "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA",
    "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO",
)

private val BLOOD_TYPES = listOf("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-")
private val DIABETES_TYPES = listOf(
    "Diabetes tipo 1", "Diabetes tipo 2", "Diabetes gestacional", "Outro", "Não sei informar",
)
private val INSULIN_KINDS = listOf(
    "Insulina de ação rápida",
    "Insulina de ação ultrarrápida",
    "Insulina de ação intermediária (NPH)",
    "Insulina de ação longa",
    "Insulina de ação ultralonga",
    "Outra",
    "Não utiliza insulina",
)

private class DigitMask(private val separators: Map<Int, Char>) : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val raw = text.text
        val out = StringBuilder()
        val o2t = mutableListOf<Int>()
        val t2o = IntArray(raw.length + 1)
        raw.forEachIndexed { i, c ->
            separators[i]?.let { out.append(it); o2t.add(i) }
            t2o[i] = out.length
            out.append(c); o2t.add(i)
        }
        t2o[raw.length] = out.length
        o2t.add(raw.length)
        return TransformedText(
            AnnotatedString(out.toString()),
            object : OffsetMapping {
                override fun originalToTransformed(offset: Int) = t2o[offset.coerceIn(0, raw.length)]
                override fun transformedToOriginal(offset: Int) = o2t[offset.coerceIn(0, o2t.size - 1)]
            },
        )
    }
}

private val CPF_MASK = DigitMask(mapOf(3 to '.', 6 to '.', 9 to '-'))
private val CEP_MASK = DigitMask(mapOf(5 to '-'))
private val PHONE_MASK = DigitMask(mapOf(5 to '-'))

@Composable
private fun MaskedField(label: String, digits: String, maxLen: Int, mask: VisualTransformation, placeholder: String, onChange: (String) -> Unit) {
    val g = glucoColors()
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        BasicTextField(
            value = digits,
            onValueChange = { v -> onChange(v.filter { it.isDigit() }.take(maxLen)) },
            singleLine = true,
            visualTransformation = mask,
            textStyle = TextStyle(color = g.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(12.dp))
                .background(g.inputBg).padding(horizontal = 14.dp, vertical = 14.dp),
            decorationBox = { inner ->
                Box {
                    if (digits.isEmpty()) Text(placeholder, color = g.muted, fontSize = 15.sp)
                    inner()
                }
            },
        )
    }
}

@Composable
private fun NameField(label: String, value: String, placeholder: String, onChange: (String) -> Unit) {
    val g = glucoColors()
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        BasicTextField(
            value = value,
            onValueChange = onChange,
            singleLine = true,
            textStyle = TextStyle(color = g.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words),
            modifier = Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(12.dp))
                .background(g.inputBg).padding(horizontal = 14.dp, vertical = 14.dp),
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) Text(placeholder, color = g.muted, fontSize = 15.sp)
                    inner()
                }
            },
        )
    }
}

@Composable
private fun InfoLine(label: String, value: String) {
    val g = glucoColors()
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Text(label, color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text(value, color = g.ink, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 2.dp))
    }
}

private fun hasProfile(s: Settings) =
    s.birthDate.isNotBlank() || s.cpf.isNotBlank() || s.street.isNotBlank() || s.city.isNotBlank() ||
        s.phoneNumber.isNotBlank() || s.diabetesType.isNotBlank() || s.heightCm.isNotBlank()

private fun formatPhone(s: Settings): String {
    if (s.phoneNumber.isBlank()) return "—"
    val ddd = s.phoneDdd.ifBlank { "??" }
    val n = s.phoneNumber
    val formatted = if (n.length >= 9) "${n.take(5)}-${n.drop(5)}" else n
    return "${s.phoneCountry.ifBlank { "+55" }} ($ddd) $formatted"
}

private fun formatProfileUpdated(at: Long): String {
    if (at <= 0) return "Ainda não houve salvamento desta ficha ampliada."
    return SimpleDateFormat("dd/MM/yyyy 'às' HH:mm", Locale("pt", "BR")).format(Date(at))
}

private fun buildShareText(s: Settings, selected: Set<String>): String = buildString {
    appendLine("Ficha Gluco Cris — dados selecionados pelo usuário")
    appendLine("Gerado em ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date())}")
    appendLine("—")
    if ("name" in selected) appendLine("Nome: ${s.displayName.ifBlank { "—" }}")
    if ("phone" in selected) appendLine("Telefone: ${formatPhone(s)}")
    if ("birth" in selected) appendLine("Nascimento: ${formatBirthDate(s.birthDate).ifBlank { "—" }}")
    if ("height" in selected) appendLine("Altura: ${s.heightCm.ifBlank { "—" }} cm")
    if ("weight" in selected) appendLine("Peso: ${s.weightKg.ifBlank { "—" }} kg")
    if ("blood" in selected) appendLine("Tipo sanguíneo: ${s.bloodType.ifBlank { "—" }}")
    if ("diabetes" in selected) appendLine("Tipo de diabetes: ${s.diabetesType.ifBlank { "—" }}")
    if ("insulinKind" in selected) appendLine("Insulina (tipo): ${s.insulinKind.ifBlank { "—" }}")
    if ("insulinBasal" in selected) appendLine("Insulina basal: ${s.insulinBasalName.ifBlank { "—" }}")
    if ("insulinMeal" in selected) appendLine("Insulina refeições: ${s.insulinMealName.ifBlank { "—" }}")
    if ("allergies" in selected) {
        appendLine("Alergias: ${s.allergies.ifBlank { "—" }}")
        if (s.allergyNotes.isNotBlank()) appendLine("Obs. alergias: ${s.allergyNotes}")
    }
    if ("restrictions" in selected) appendLine("Restrições alimentares: ${s.foodRestrictions.ifBlank { "—" }}")
    if ("meds" in selected) {
        appendLine("Medicamentos de uso contínuo:")
        if (s.profileMedications.isEmpty()) appendLine("  —")
        else s.profileMedications.forEach {
            appendLine("  • ${it.name} ${it.dose} — ${it.frequency} ${it.times}".trim())
            if (it.notes.isNotBlank()) appendLine("    Obs.: ${it.notes}")
        }
    }
    if ("updated" in selected) appendLine("Última atualização da ficha: ${formatProfileUpdated(s.profileUpdatedAt)}")
    appendLine("—")
    appendLine("Informações preenchidas pelo usuário. Não substituem avaliação profissional.")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(vm: GlucoViewModel) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    val context = LocalContext.current
    val s = data.settings

    var editing by remember { mutableStateOf(!hasProfile(s)) }
    var sharing by remember { mutableStateOf(false) }
    var name by remember(s.displayName) { mutableStateOf(s.displayName) }
    var birth by remember(s.birthDate) { mutableStateOf(s.birthDate) }
    var cpf by remember(s.cpf) { mutableStateOf(s.cpf) }
    var cep by remember(s.cep) { mutableStateOf(s.cep) }
    var street by remember(s.street) { mutableStateOf(s.street) }
    var number by remember(s.number) { mutableStateOf(s.number) }
    var complement by remember(s.complement) { mutableStateOf(s.complement) }
    var district by remember(s.district) { mutableStateOf(s.district) }
    var city by remember(s.city) { mutableStateOf(s.city) }
    var uf by remember(s.state) { mutableStateOf(s.state) }
    var phoneCountry by remember(s.phoneCountry) { mutableStateOf(s.phoneCountry.ifBlank { "+55" }) }
    var phoneDdd by remember(s.phoneDdd) { mutableStateOf(s.phoneDdd) }
    var phoneNumber by remember(s.phoneNumber) { mutableStateOf(s.phoneNumber) }
    var heightCm by remember(s.heightCm) { mutableStateOf(s.heightCm) }
    var weightKg by remember(s.weightKg) { mutableStateOf(s.weightKg) }
    var bloodType by remember(s.bloodType) { mutableStateOf(s.bloodType) }
    var diabetesType by remember(s.diabetesType) { mutableStateOf(s.diabetesType) }
    var insulinKind by remember(s.insulinKind) { mutableStateOf(s.insulinKind) }
    var insulinBasal by remember(s.insulinBasalName) { mutableStateOf(s.insulinBasalName) }
    var insulinMeal by remember(s.insulinMealName) { mutableStateOf(s.insulinMealName) }
    var insulinNotes by remember(s.insulinNotes) { mutableStateOf(s.insulinNotes) }
    var allergies by remember(s.allergies) { mutableStateOf(s.allergies) }
    var allergyNotes by remember(s.allergyNotes) { mutableStateOf(s.allergyNotes) }
    var restrictions by remember(s.foodRestrictions) { mutableStateOf(s.foodRestrictions) }
    var profileMeds by remember(s.profileMedications) { mutableStateOf(s.profileMedications) }
    var newMedName by remember { mutableStateOf("") }
    var newMedDose by remember { mutableStateOf("") }
    var newMedFreq by remember { mutableStateOf("") }
    var newMedTimes by remember { mutableStateOf("") }
    var showPicker by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    var showCpf by remember { mutableStateOf(false) }
    var shareSelected by remember {
        mutableStateOf(
            setOf("name", "diabetes", "allergies", "restrictions", "updated"),
        )
    }
    var sharePreview by remember { mutableStateOf(false) }

    fun reloadFrom(s2: Settings) {
        name = s2.displayName; birth = s2.birthDate; cpf = s2.cpf; cep = s2.cep
        street = s2.street; number = s2.number; complement = s2.complement
        district = s2.district; city = s2.city; uf = s2.state
        phoneCountry = s2.phoneCountry.ifBlank { "+55" }; phoneDdd = s2.phoneDdd; phoneNumber = s2.phoneNumber
        heightCm = s2.heightCm; weightKg = s2.weightKg; bloodType = s2.bloodType
        diabetesType = s2.diabetesType; insulinKind = s2.insulinKind
        insulinBasal = s2.insulinBasalName; insulinMeal = s2.insulinMealName; insulinNotes = s2.insulinNotes
        allergies = s2.allergies; allergyNotes = s2.allergyNotes; restrictions = s2.foodRestrictions
        profileMeds = s2.profileMedications
    }

    if (showPicker) {
        val today = System.currentTimeMillis()
        val state = rememberDatePickerState(
            initialSelectedDateMillis = pickerMillisFromIso(birth),
            yearRange = 1900..java.util.Calendar.getInstance().get(java.util.Calendar.YEAR),
            selectableDates = object : SelectableDates {
                override fun isSelectableDate(utcTimeMillis: Long) = utcTimeMillis <= today
            },
        )
        DatePickerDialog(
            onDismissRequest = { showPicker = false },
            confirmButton = {
                TextButton(onClick = {
                    state.selectedDateMillis?.let { birth = isoFromPickerMillis(it) }
                    showPicker = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showPicker = false }) { Text("Cancelar") } },
        ) { DatePicker(state = state) }
    }

    ScrollScreen {
        Text("Perfil", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
        Text(
            "Ficha pessoal e de saúde — tudo opcional. Salve para atualizar a data.",
            color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp),
        )

        if (sharing) {
            SectionTitle("Compartilhar meus dados")
            GCard {
                Text("Marque só o que deseja incluir. Nada é enviado sem você confirmar.", color = g.muted, fontSize = 12.sp)
                val opts = listOf(
                    "name" to "Nome completo",
                    "phone" to "Telefone",
                    "birth" to "Data de nascimento",
                    "height" to "Altura",
                    "weight" to "Peso",
                    "blood" to "Tipo sanguíneo",
                    "diabetes" to "Tipo de diabetes",
                    "insulinKind" to "Tipo de insulina",
                    "insulinBasal" to "Insulina basal",
                    "insulinMeal" to "Insulina das refeições",
                    "allergies" to "Alergias",
                    "restrictions" to "Restrições alimentares",
                    "meds" to "Medicamentos contínuos",
                    "updated" to "Última atualização",
                )
                opts.forEach { (key, label) ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().clickable {
                        shareSelected = if (key in shareSelected) shareSelected - key else shareSelected + key
                    }) {
                        Checkbox(checked = key in shareSelected, onCheckedChange = {
                            shareSelected = if (it) shareSelected + key else shareSelected - key
                        })
                        Text(label, color = g.ink, fontSize = 14.sp)
                    }
                }
            }
            if (sharePreview) {
                SectionTitle("Prévia")
                GCard {
                    Text(buildShareText(s, shareSelected), color = g.ink, fontSize = 13.sp)
                }
            }
            PrimaryButton(if (sharePreview) "Compartilhar texto" else "Ver prévia", g.green, {
                if (!sharePreview) {
                    sharePreview = true
                } else {
                    val text = buildShareText(s, shareSelected)
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "Ficha Gluco Cris")
                        putExtra(Intent.EXTRA_TEXT, text)
                    }
                    context.startActivity(Intent.createChooser(send, "Compartilhar ficha"))
                }
            }, Modifier.padding(top = 10.dp))
            Text(
                "Voltar ao perfil", color = g.muted, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 12.dp).clickable { sharing = false; sharePreview = false }.padding(8.dp),
            )
            return@ScrollScreen
        }

        if (!editing) {
            SectionTitle("Dados pessoais")
            GCard {
                InfoLine("Nome completo", s.displayName.ifBlank { "—" })
                InfoLine("Telefone", formatPhone(s))
                InfoLine("Nascimento", formatBirthDate(s.birthDate).ifBlank { "—" })
                ageFrom(s.birthDate)?.let { InfoLine("Idade", "$it anos") }
                InfoLine("Altura", if (s.heightCm.isNotBlank()) "${s.heightCm} cm" else "—")
                InfoLine("Peso", if (s.weightKg.isNotBlank()) "${s.weightKg} kg" else "—")
                InfoLine("Tipo sanguíneo", s.bloodType.ifBlank { "—" })
                if (s.cpf.isNotBlank()) {
                    InfoLine(
                        "CPF",
                        if (showCpf) formatCpf(s.cpf) else "***.${s.cpf.drop(3).take(3)}.***-**",
                    )
                    Text(
                        if (showCpf) "Ocultar CPF" else "Mostrar CPF",
                        color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                        modifier = Modifier.padding(top = 6.dp).clickable { showCpf = !showCpf }.padding(4.dp),
                    )
                }
            }
            SectionTitle("Endereço")
            GCard {
                val line1 = listOf(s.street, s.number).filter { it.isNotBlank() }.joinToString(", ")
                InfoLine("Rua e número", line1.ifBlank { "—" })
                if (s.complement.isNotBlank()) InfoLine("Complemento", s.complement)
                InfoLine("Bairro", s.district.ifBlank { "—" })
                InfoLine("Cidade / Estado", listOf(s.city, s.state).filter { it.isNotBlank() }.joinToString(" / ").ifBlank { "—" })
                InfoLine("CEP", if (s.cep.length == 8) "${s.cep.take(5)}-${s.cep.drop(5)}" else s.cep.ifBlank { "—" })
            }
            SectionTitle("Meu diabetes")
            GCard {
                InfoLine("Tipo", s.diabetesType.ifBlank { "—" })
                InfoLine("Insulina (categoria)", s.insulinKind.ifBlank { "—" })
                InfoLine("Basal", s.insulinBasalName.ifBlank { "—" })
                InfoLine("Refeições", s.insulinMealName.ifBlank { "—" })
                if (s.insulinNotes.isNotBlank()) InfoLine("Observações", s.insulinNotes)
            }
            SectionTitle("Alergias e restrições")
            GCard {
                InfoLine("Alergias", s.allergies.ifBlank { "—" })
                if (s.allergyNotes.isNotBlank()) InfoLine("Obs. alergias", s.allergyNotes)
                InfoLine("Restrições alimentares", s.foodRestrictions.ifBlank { "—" })
            }
            SectionTitle("Medicamentos de uso contínuo")
            GCard {
                if (s.profileMedications.isEmpty()) Text("Nenhum cadastrado", color = g.muted)
                else s.profileMedications.forEach { m ->
                    Text(m.name, color = g.ink, fontWeight = FontWeight.SemiBold)
                    Text(listOf(m.dose, m.frequency, m.times).filter { it.isNotBlank() }.joinToString(" · "), color = g.muted, fontSize = 13.sp)
                    if (m.notes.isNotBlank()) Text(m.notes, color = g.muted, fontSize = 12.sp)
                }
            }
            SectionTitle("Última atualização")
            GCard {
                Text(formatProfileUpdated(s.profileUpdatedAt), color = g.ink, fontWeight = FontWeight.Medium)
            }
            message?.let { Text(it.first, color = if (it.second) g.green else g.red, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)) }
            PrimaryButton("Editar perfil", g.violet, { message = null; editing = true }, Modifier.padding(top = 12.dp))
            PrimaryButton("COMPARTILHAR MEUS DADOS", g.green, { sharing = true; sharePreview = false }, Modifier.padding(top = 8.dp))
            return@ScrollScreen
        }

        // —— Edição ——
        SectionTitle("Dados pessoais")
        GCard {
            NameField("Nome completo", name, "Seu nome completo") { name = it }
            GField("Código do país", phoneCountry, { phoneCountry = it.ifBlank { "+55" } }, "+55")
            MaskedField("DDD", phoneDdd, 2, VisualTransformation.None, "11") { phoneDdd = it }
            MaskedField("Número", phoneNumber, 9, PHONE_MASK, "99999-9999") { phoneNumber = it }
            Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                Text("Data de nascimento", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(
                    formatBirthDate(birth).ifBlank { "Toque para escolher a data" },
                    color = if (birth.isBlank()) g.muted else g.ink,
                    fontSize = if (birth.isBlank()) 15.sp else 16.sp,
                    fontWeight = if (birth.isBlank()) FontWeight.Normal else FontWeight.SemiBold,
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(12.dp))
                        .background(g.inputBg).clickable { showPicker = true }.padding(horizontal = 14.dp, vertical = 14.dp),
                )
            }
            Text(
                ageFrom(birth)?.let { "$it anos (calculada)" } ?: "Idade pela data de nascimento",
                color = g.muted, fontSize = 13.sp,
            )
            MaskedField("Altura (cm)", heightCm.filter { it.isDigit() || it == ',' || it == '.' }, 6, VisualTransformation.None, "165") {
                heightCm = it.filter { c -> c.isDigit() || c == ',' || c == '.' }
            }
            MaskedField("Peso (kg)", weightKg.filter { it.isDigit() || it == ',' || it == '.' }, 6, VisualTransformation.None, "70") {
                weightKg = it.filter { c -> c.isDigit() || c == ',' || c == '.' }
            }
            Text("Tipo sanguíneo", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            ChipRow(BLOOD_TYPES.map { it to it }, bloodType) { bloodType = if (bloodType == it) "" else it }
            MaskedField("CPF", cpf, 11, CPF_MASK, "000.000.000-00") { cpf = it }
            when {
                cpf.length == 11 && isValidCpf(cpf) -> Text("CPF válido", color = g.green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                cpf.length == 11 -> Text("CPF inválido — confira ou deixe em branco", color = g.red, fontSize = 12.sp)
                else -> {}
            }
        }

        SectionTitle("Endereço")
        GCard {
            MaskedField("CEP", cep, 8, CEP_MASK, "00000-000") { cep = it }
            GField("Rua ou avenida", street, { street = it }, "Ex.: Rua das Flores")
            GField("Número", number, { number = it }, "Ex.: 120")
            GField("Complemento (opcional)", complement, { complement = it }, "Ex.: Apto 21")
            GField("Bairro", district, { district = it }, "Ex.: Centro")
            GField("Cidade", city, { city = it }, "Ex.: Campinas")
            Text("Estado", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
            ChipRow(UF_LIST.map { it to it }, uf) { uf = if (uf == it) "" else it }
        }

        SectionTitle("Meu diabetes")
        GCard {
            Text("Tipo de diabetes", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            ChipRow(DIABETES_TYPES.map { it to it }, diabetesType) { diabetesType = if (diabetesType == it) "" else it }
            Text("Insulina que mais utiliza", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
            ChipRow(INSULIN_KINDS.map { it to it }, insulinKind) { insulinKind = if (insulinKind == it) "" else it }
            GField("Nome da insulina basal", insulinBasal, { insulinBasal = it }, "Ex.: Glargina")
            GField("Nome da insulina das refeições", insulinMeal, { insulinMeal = it }, "Ex.: Aspart")
            GField("Observações sobre insulina", insulinNotes, { insulinNotes = it }, "Opcional")
        }

        SectionTitle("Alergias e restrições")
        GCard {
            GField("Alergias (separadas por vírgula)", allergies, { allergies = it }, "Ex.: amendoim, penicilina")
            GField("Observações sobre alergias", allergyNotes, { allergyNotes = it }, "Opcional")
            GField("Restrições alimentares", restrictions, { restrictions = it }, "Ex.: lactose, glúten")
            Text("Alergia ≠ restrição/preferência. Informe com clareza.", color = g.muted, fontSize = 11.sp)
        }

        SectionTitle("Medicamentos de uso contínuo")
        GCard {
            profileMeds.forEach { m ->
                Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(m.name, color = g.ink, fontWeight = FontWeight.SemiBold)
                        Text(listOf(m.dose, m.frequency, m.times).filter { it.isNotBlank() }.joinToString(" · "), color = g.muted, fontSize = 12.sp)
                    }
                    Text("Excluir", color = g.red, fontSize = 12.sp, modifier = Modifier.clickable {
                        profileMeds = profileMeds.filter { it.id != m.id }
                    }.padding(8.dp))
                }
            }
            GField("Novo medicamento", newMedName, { newMedName = it }, "Nome")
            GField("Dosagem", newMedDose, { newMedDose = it }, "Ex.: 10 mg")
            GField("Frequência", newMedFreq, { newMedFreq = it }, "Ex.: 1x ao dia")
            GField("Horários", newMedTimes, { newMedTimes = it }, "Ex.: 8h e 20h")
            Text(
                "+ Adicionar medicamento",
                color = g.violet, fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(top = 8.dp).clickable {
                    if (newMedName.isNotBlank()) {
                        profileMeds = profileMeds + ProfileMed(
                            id = uid(),
                            name = newMedName.trim(),
                            dose = newMedDose.trim(),
                            frequency = newMedFreq.trim(),
                            times = newMedTimes.trim(),
                        )
                        newMedName = ""; newMedDose = ""; newMedFreq = ""; newMedTimes = ""
                    }
                }.padding(8.dp),
            )
            Text("Não altere doses sem orientação profissional.", color = g.muted, fontSize = 11.sp)
        }

        message?.let { Text(it.first, color = if (it.second) g.green else g.red, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp)) }
        PrimaryButton("Salvar perfil", g.violet, {
            val err = when {
                name.isBlank() -> "Informe o nome completo."
                cpf.isNotEmpty() && !isValidCpf(cpf) -> "O CPF informado não é válido. Corrija ou deixe em branco."
                cep.isNotEmpty() && cep.length != 8 -> "O CEP deve ter 8 números."
                phoneDdd.isNotEmpty() && phoneDdd.length != 2 -> "DDD deve ter 2 dígitos."
                phoneNumber.isNotEmpty() && phoneNumber.length < 8 -> "Telefone incompleto."
                else -> null
            }
            if (err != null) {
                message = err to false
            } else {
                vm.updateSettings {
                    it.copy(
                        displayName = name.trim().replace(Regex("\\s+"), " "),
                        birthDate = birth, cpf = cpf, cep = cep,
                        street = street.trim(), number = number.trim(), complement = complement.trim(),
                        district = district.trim(), city = city.trim(), state = uf,
                        phoneCountry = phoneCountry.ifBlank { "+55" },
                        phoneDdd = phoneDdd, phoneNumber = phoneNumber,
                        heightCm = heightCm, weightKg = weightKg, bloodType = bloodType,
                        diabetesType = diabetesType, insulinKind = insulinKind,
                        insulinBasalName = insulinBasal.trim(), insulinMealName = insulinMeal.trim(),
                        insulinNotes = insulinNotes.trim(),
                        allergies = allergies.trim(), allergyNotes = allergyNotes.trim(),
                        foodRestrictions = restrictions.trim(),
                        profileMedications = profileMeds,
                        profileUpdatedAt = System.currentTimeMillis(),
                    )
                }
                message = "Perfil salvo." to true
                editing = false
            }
        }, Modifier.padding(top = 12.dp))
        if (hasProfile(s)) {
            Text(
                "Cancelar edição", color = g.muted, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp)).clickable {
                    reloadFrom(s); message = null; editing = false
                }.padding(10.dp),
            )
        }
    }
}
