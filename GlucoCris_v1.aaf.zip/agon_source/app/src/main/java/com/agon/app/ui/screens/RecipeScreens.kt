package com.agon.app.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Meal
import com.agon.app.data.uid
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt

data class RecipeItem(
    val id: String,
    val name: String,
    val category: String = "",
    val area: String = "",
    val thumb: String = "",
    val ingredients: List<String> = emptyList(),
    val instructions: String = "",
    val source: String = "",
    val carbsEstimate: Double? = null,
    val kcalEstimate: Double? = null,
    val servings: String = "1 porção",
    val tags: List<String> = emptyList(), // cafe, almoco, jantar, lanche, lowcarb, doce, vegetariano, rapido
)

private const val RECIPE_PREFS = "gluco_recipe_prefs"
private const val KEY_FAV_RECIPES = "fav_recipe_ids"
private const val KEY_CACHED_RECIPES = "cached_recipes_json"

private fun loadFavRecipeIds(ctx: Context): Set<String> =
    ctx.getSharedPreferences(RECIPE_PREFS, Context.MODE_PRIVATE).getStringSet(KEY_FAV_RECIPES, emptySet()) ?: emptySet()

private fun saveFavRecipeIds(ctx: Context, ids: Set<String>) {
    ctx.getSharedPreferences(RECIPE_PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY_FAV_RECIPES, ids).apply()
}

private fun cacheRecipe(ctx: Context, r: RecipeItem) {
    try {
        val prefs = ctx.getSharedPreferences(RECIPE_PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY_CACHED_RECIPES, "[]") ?: "[]")
        val filtered = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") != r.id) filtered.put(o)
        }
        filtered.put(
            JSONObject()
                .put("id", r.id)
                .put("name", r.name)
                .put("category", r.category)
                .put("area", r.area)
                .put("instructions", r.instructions)
                .put("source", r.source)
                .put("servings", r.servings)
                .put("carbs", r.carbsEstimate ?: -1.0)
                .put("kcal", r.kcalEstimate ?: -1.0)
                .put("ingredients", JSONArray(r.ingredients))
                .put("tags", JSONArray(r.tags)),
        )
        // max 40
        val out = JSONArray()
        val start = (filtered.length() - 40).coerceAtLeast(0)
        for (i in start until filtered.length()) out.put(filtered.getJSONObject(i))
        prefs.edit().putString(KEY_CACHED_RECIPES, out.toString()).apply()
    } catch (_: Exception) {}
}

private fun loadCachedRecipes(ctx: Context): List<RecipeItem> {
    return try {
        val raw = ctx.getSharedPreferences(RECIPE_PREFS, Context.MODE_PRIVATE).getString(KEY_CACHED_RECIPES, "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val ings = o.optJSONArray("ingredients")
            val tags = o.optJSONArray("tags")
            RecipeItem(
                id = o.optString("id"),
                name = o.optString("name"),
                category = o.optString("category"),
                area = o.optString("area"),
                ingredients = if (ings != null) (0 until ings.length()).map { ings.getString(it) } else emptyList(),
                instructions = o.optString("instructions"),
                source = o.optString("source", "Cache"),
                carbsEstimate = o.optDouble("carbs", -1.0).takeIf { it >= 0 },
                kcalEstimate = o.optDouble("kcal", -1.0).takeIf { it >= 0 },
                servings = o.optString("servings", "1 porção"),
                tags = if (tags != null) (0 until tags.length()).map { tags.getString(it) } else emptyList(),
            ).takeIf { it.id.isNotBlank() && it.name.isNotBlank() }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

/** Coleção BR ampliada — carb estimado por porção típica (referência, não laboratório). */
val LOCAL_RECIPES: List<RecipeItem> = listOf(
    // Café
    RecipeItem("br-cuscuz", "Cuscuz nordestino", "Café da manhã", "Brasil", ingredients = listOf("Flocão de milho", "Água", "Sal"), instructions = "Hidrate o flocão e cozinhe no cuscuzeiro.", source = "Coleção BR", carbsEstimate = 35.0, kcalEstimate = 160.0, tags = listOf("cafe", "rapido")),
    RecipeItem("br-tapioca", "Tapioca com queijo", "Café da manhã", "Brasil", ingredients = listOf("Goma de tapioca", "Queijo minas"), instructions = "Aqueça a goma, recheie com queijo e dobre.", source = "Coleção BR", carbsEstimate = 28.0, kcalEstimate = 180.0, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br-omelete", "Omelete simples", "Café da manhã", "Brasil", ingredients = listOf("Ovos", "Sal", "Óleo"), instructions = "Bata os ovos e frite em frigideira antiaderente.", source = "Coleção BR", carbsEstimate = 2.0, kcalEstimate = 180.0, tags = listOf("cafe", "lowcarb", "rapido", "vegetariano")),
    RecipeItem("br-ovo-mexido-tomate", "Ovo mexido com tomate", "Café da manhã", "Brasil", ingredients = listOf("Ovos", "Tomate", "Cebola"), instructions = "Refogue tomate e cebola, acrescente os ovos.", source = "Coleção BR", carbsEstimate = 4.0, kcalEstimate = 200.0, tags = listOf("cafe", "lowcarb", "rapido")),
    RecipeItem("br-vitamina-banana", "Vitamina de banana", "Bebida", "Brasil", ingredients = listOf("Banana", "Leite"), instructions = "Bata no liquidificador.", source = "Coleção BR", carbsEstimate = 35.0, kcalEstimate = 200.0, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br-pao-ovo", "Pão francês com ovo", "Café da manhã", "Brasil", ingredients = listOf("Pão francês", "Ovo", "Óleo"), instructions = "Frite o ovo e sirva no pão.", source = "Coleção BR", carbsEstimate = 32.0, kcalEstimate = 280.0, tags = listOf("cafe", "rapido")),
    RecipeItem("br-aveia-leite", "Mingau de aveia", "Café da manhã", "Brasil", ingredients = listOf("Aveia", "Leite", "Canela"), instructions = "Cozinhe a aveia no leite até engrossar.", source = "Coleção BR", carbsEstimate = 30.0, kcalEstimate = 220.0, tags = listOf("cafe", "vegetariano")),
    // Almoço / jantar
    RecipeItem("br-arroz-feijao", "Arroz e feijão (PF)", "Prato principal", "Brasil", ingredients = listOf("Arroz", "Feijão carioca"), instructions = "Sirva arroz com uma concha de feijão.", source = "Coleção BR", carbsEstimate = 50.0, kcalEstimate = 280.0, tags = listOf("almoco", "jantar", "vegetariano")),
    RecipeItem("br-frango-grelhado-arroz", "Frango grelhado com arroz e salada", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Arroz", "Alface", "Tomate"), instructions = "Grelhe o frango; sirva com arroz e salada.", source = "Coleção BR", carbsEstimate = 40.0, kcalEstimate = 380.0, tags = listOf("almoco", "jantar")),
    RecipeItem("br-strogonoff", "Estrogonofe de frango", "Prato principal", "Brasil", ingredients = listOf("Frango", "Creme de leite", "Molho", "Arroz", "Batata palha"), instructions = "Refogue o frango, adicione creme e molho; sirva com arroz.", source = "Coleção BR", carbsEstimate = 40.0, kcalEstimate = 450.0, tags = listOf("almoco", "jantar")),
    RecipeItem("br-feijoada", "Feijoada", "Prato principal", "Brasil", ingredients = listOf("Feijão preto", "Carnes", "Arroz", "Couve"), instructions = "Cozinhe feijão com carnes; sirva com arroz e couve.", source = "Coleção BR", carbsEstimate = 45.0, kcalEstimate = 420.0, tags = listOf("almoco", "jantar")),
    RecipeItem("br-moqueca", "Moqueca de peixe", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Leite de coco", "Dendê", "Tomate", "Pimentão"), instructions = "Cozinhe o peixe no molho de tomate e leite de coco.", source = "Coleção BR", carbsEstimate = 12.0, kcalEstimate = 280.0, tags = listOf("almoco", "jantar", "lowcarb")),
    RecipeItem("br-baião", "Baião de dois", "Prato principal", "Brasil", ingredients = listOf("Arroz", "Feijão de corda", "Queijo coalho"), instructions = "Misture arroz e feijão com queijo.", source = "Coleção BR", carbsEstimate = 55.0, kcalEstimate = 380.0, tags = listOf("almoco", "jantar")),
    RecipeItem("br-carne-refogada-legumes", "Carne refogada com legumes", "Prato principal", "Brasil", ingredients = listOf("Carne bovina", "Cenoura", "Abobrinha", "Cebola"), instructions = "Refogue a carne e acrescente os legumes.", source = "Coleção BR", carbsEstimate = 10.0, kcalEstimate = 320.0, tags = listOf("almoco", "jantar", "lowcarb")),
    RecipeItem("br-peixe-grelhado-salada", "Peixe grelhado com salada", "Prato principal", "Brasil", ingredients = listOf("Filé de peixe", "Alface", "Tomate", "Azeite"), instructions = "Grelhe o peixe e monte a salada.", source = "Coleção BR", carbsEstimate = 6.0, kcalEstimate = 250.0, tags = listOf("almoco", "jantar", "lowcarb", "rapido")),
    RecipeItem("br-macarrao-molho", "Macarrão ao molho de tomate", "Prato principal", "Brasil", ingredients = listOf("Macarrão", "Molho de tomate"), instructions = "Cozinhe o macarrão e misture ao molho.", source = "Coleção BR", carbsEstimate = 55.0, kcalEstimate = 320.0, tags = listOf("almoco", "jantar", "vegetariano")),
    RecipeItem("br-risoto-fraco", "Risoto de frango simples", "Prato principal", "Brasil", ingredients = listOf("Arroz arbóreo ou agulhinha", "Frango", "Caldo"), instructions = "Refogue e cozinhe o arroz adicionando caldo aos poucos.", source = "Coleção BR", carbsEstimate = 48.0, kcalEstimate = 400.0, tags = listOf("almoco", "jantar")),
    RecipeItem("br-lentilha-completa", "Lentilha com legumes", "Prato principal", "Brasil", ingredients = listOf("Lentilha", "Cenoura", "Cebola", "Alho"), instructions = "Cozinhe a lentilha com os legumes.", source = "Coleção BR", carbsEstimate = 30.0, kcalEstimate = 220.0, tags = listOf("almoco", "jantar", "vegetariano")),
    // Sopas / acompanhamentos
    RecipeItem("br-canja", "Canja de galinha", "Sopa", "Brasil", ingredients = listOf("Frango", "Arroz", "Cenoura", "Batata"), instructions = "Cozinhe tudo até amaciar.", source = "Coleção BR", carbsEstimate = 30.0, kcalEstimate = 250.0, tags = listOf("almoco", "jantar")),
    RecipeItem("br-sopa-legumes", "Sopa de legumes", "Sopa", "Brasil", ingredients = listOf("Cenoura", "Batata", "Abóbora", "Cebola"), instructions = "Cozinhe e amasse parcialmente.", source = "Coleção BR", carbsEstimate = 22.0, kcalEstimate = 150.0, tags = listOf("almoco", "jantar", "vegetariano")),
    RecipeItem("br-pure", "Purê de batata", "Acompanhamento", "Brasil", ingredients = listOf("Batata", "Leite", "Manteiga"), instructions = "Cozinhe e amasse com leite.", source = "Coleção BR", carbsEstimate = 25.0, kcalEstimate = 180.0, tags = listOf("almoco", "jantar", "vegetariano")),
    RecipeItem("br-salada-frango", "Salada de frango grelhado", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Alface", "Tomate", "Pepino", "Azeite"), instructions = "Grelhe o frango e monte a salada.", source = "Coleção BR", carbsEstimate = 8.0, kcalEstimate = 220.0, tags = listOf("almoco", "jantar", "lowcarb", "rapido")),
    RecipeItem("br-salada-completa", "Salada completa com grão-de-bico", "Prato principal", "Brasil", ingredients = listOf("Grão-de-bico", "Tomate", "Pepino", "Cebola roxa", "Azeite"), instructions = "Misture os ingredientes e tempere.", source = "Coleção BR", carbsEstimate = 25.0, kcalEstimate = 280.0, tags = listOf("almoco", "jantar", "vegetariano")),
    // Lanches
    RecipeItem("br-iogurte-fruta", "Iogurte natural com fruta", "Lanche", "Brasil", ingredients = listOf("Iogurte natural", "Morango ou banana"), instructions = "Sirva o iogurte com a fruta picada.", source = "Coleção BR", carbsEstimate = 18.0, kcalEstimate = 150.0, tags = listOf("lanche", "rapido", "vegetariano")),
    RecipeItem("br-wrap-frango", "Wrap de frango e salada", "Lanche", "Brasil", ingredients = listOf("Tortilha", "Frango desfiado", "Alface", "Tomate"), instructions = "Recheie a tortilha e enrole.", source = "Coleção BR", carbsEstimate = 28.0, kcalEstimate = 300.0, tags = listOf("lanche", "almoco", "rapido")),
    RecipeItem("br-sanduiche-queijo", "Sanduíche de queijo e tomate", "Lanche", "Brasil", ingredients = listOf("Pão de forma", "Queijo", "Tomate"), instructions = "Monte o sanduíche; pode tostar.", source = "Coleção BR", carbsEstimate = 28.0, kcalEstimate = 250.0, tags = listOf("lanche", "cafe", "rapido", "vegetariano")),
    // Doces (com carb)
    RecipeItem("br-gelatina", "Gelatina", "Doce", "Brasil", ingredients = listOf("Gelatina em pó", "Água"), instructions = "Prepare conforme a embalagem e leve à geladeira.", source = "Coleção BR", carbsEstimate = 15.0, kcalEstimate = 60.0, tags = listOf("doce", "lanche", "rapido")),
    RecipeItem("br-bolo-simples", "Bolo simples de fatia", "Doce", "Brasil", ingredients = listOf("Farinha", "Açúcar", "Ovos", "Leite", "Fermento"), instructions = "Misture, asse e sirva 1 fatia média.", source = "Coleção BR", carbsEstimate = 35.0, kcalEstimate = 220.0, tags = listOf("doce", "lanche")),
    RecipeItem("br-banana-canela", "Banana assada com canela", "Doce", "Brasil", ingredients = listOf("Banana", "Canela"), instructions = "Asse a banana com canela até amaciar.", source = "Coleção BR", carbsEstimate = 27.0, kcalEstimate = 110.0, tags = listOf("doce", "lanche", "rapido", "vegetariano")),
    // Rápidas / low carb extras
    RecipeItem("br-abobrinha-refogada", "Abobrinha refogada com ovo", "Prato principal", "Brasil", ingredients = listOf("Abobrinha", "Ovo", "Alho"), instructions = "Refogue a abobrinha e acrescente ovo.", source = "Coleção BR", carbsEstimate = 6.0, kcalEstimate = 180.0, tags = listOf("almoco", "jantar", "lowcarb", "rapido", "vegetariano")),
    RecipeItem("br-sardinha-salada", "Sardinha com salada", "Prato principal", "Brasil", ingredients = listOf("Sardinha em lata (escorrida)", "Alface", "Tomate"), instructions = "Escorra a sardinha e sirva com salada.", source = "Coleção BR", carbsEstimate = 5.0, kcalEstimate = 220.0, tags = listOf("almoco", "jantar", "lowcarb", "rapido")),
)

private val recipeOnlineCache = linkedMapOf<String, Pair<Long, List<RecipeItem>>>()
private const val RECIPE_CACHE_TTL = 30 * 60_000L

private fun mealDbToRecipe(o: JSONObject): RecipeItem? {
    val id = o.optString("idMeal", "")
    val name = o.optString("strMeal", "")
    if (id.isBlank() || name.isBlank()) return null
    val ingredients = mutableListOf<String>()
    for (i in 1..20) {
        val ing = o.optString("strIngredient$i", "").trim()
        val measure = o.optString("strMeasure$i", "").trim()
        if (ing.isNotBlank()) ingredients.add(if (measure.isNotBlank()) "$measure $ing".trim() else ing)
    }
    val category = o.optString("strCategory", "")
    val tags = mutableListOf<String>()
    when {
        category.contains("Breakfast", true) -> tags.add("cafe")
        category.contains("Dessert", true) -> tags.add("doce")
        category.contains("Starter", true) || category.contains("Side", true) -> tags.add("lanche")
        else -> { tags.add("almoco"); tags.add("jantar") }
    }
    if (category.contains("Vegetarian", true) || category.contains("Vegan", true)) tags.add("vegetariano")
    return RecipeItem(
        id = "mealdb-$id",
        name = name,
        category = category,
        area = o.optString("strArea", ""),
        thumb = o.optString("strMealThumb", ""),
        ingredients = ingredients,
        instructions = o.optString("strInstructions", "").trim(),
        source = "TheMealDB",
        servings = "1 porção (estimativa)",
        tags = tags,
        carbsEstimate = null,
        kcalEstimate = null,
    )
}

suspend fun searchRecipesOnline(query: String): List<RecipeItem> = withContext(Dispatchers.IO) {
    val q = query.trim()
    if (q.length < 2) return@withContext emptyList()
    val key = q.lowercase()
    recipeOnlineCache[key]?.let { (at, list) ->
        if (System.currentTimeMillis() - at < RECIPE_CACHE_TTL) return@withContext list
    }
    try {
        val enc = URLEncoder.encode(q, "UTF-8")
        val url = URL("https://www.themealdb.com/api/json/v1/1/search.php?s=$enc")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 7000; readTimeout = 7000
            setRequestProperty("User-Agent", "GlucoCris/1.4")
        }
        if (conn.responseCode != 200) return@withContext emptyList()
        val json = JSONObject(conn.inputStream.bufferedReader().readText())
        val arr = json.optJSONArray("meals") ?: return@withContext emptyList()
        val list = mutableListOf<RecipeItem>()
        for (i in 0 until arr.length()) mealDbToRecipe(arr.getJSONObject(i))?.let { list.add(it) }
        recipeOnlineCache[key] = System.currentTimeMillis() to list
        while (recipeOnlineCache.size > 60) recipeOnlineCache.remove(recipeOnlineCache.keys.first())
        list
    } catch (_: Exception) {
        emptyList()
    }
}

suspend fun lookupRecipeOnline(id: String): RecipeItem? = withContext(Dispatchers.IO) {
    try {
        val numeric = id.removePrefix("mealdb-")
        val url = URL("https://www.themealdb.com/api/json/v1/1/lookup.php?i=$numeric")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 7000; readTimeout = 7000
        }
        if (conn.responseCode != 200) return@withContext null
        val json = JSONObject(conn.inputStream.bufferedReader().readText())
        val arr = json.optJSONArray("meals") ?: return@withContext null
        if (arr.length() == 0) return@withContext null
        mealDbToRecipe(arr.getJSONObject(0))
    } catch (_: Exception) {
        null
    }
}

fun searchLocalRecipes(query: String, tag: String?): List<RecipeItem> {
    val q = query.lowercase().trim()
    val base = if (tag.isNullOrBlank() || tag == "todos") LOCAL_RECIPES
    else if (tag == "brasil") LOCAL_RECIPES.filter { it.area.equals("Brasil", true) }
    else if (tag == "favoritos") LOCAL_RECIPES // filtrado depois
    else LOCAL_RECIPES.filter { tag in it.tags || it.category.lowercase().contains(tag) }
    if (q.isBlank()) return base
    val parts = q.split(" ").filter { it.length > 1 }
    return base.filter { r ->
        val blob = (r.name + " " + r.category + " " + r.area + " " + r.ingredients.joinToString(" ") + " " + r.tags.joinToString(" ")).lowercase()
        parts.all { blob.contains(it) } || blob.contains(q)
    }
}

private val FILTERS = listOf(
    "todos" to "Todas",
    "brasil" to "Brasil",
    "cafe" to "Café",
    "almoco" to "Almoço",
    "jantar" to "Jantar",
    "lanche" to "Lanche",
    "lowcarb" to "Low carb",
    "doce" to "Doces",
    "vegetariano" to "Vegetariano",
    "rapido" to "Rápidas",
    "favoritos" to "Favoritas",
)

@Composable
fun RecipeSearchScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("todos") }
    var favIds by remember { mutableStateOf(loadFavRecipeIds(context)) }
    var results by remember { mutableStateOf(LOCAL_RECIPES) }
    var suggestions by remember { mutableStateOf<List<RecipeItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    var job by remember { mutableStateOf<Job?>(null) }

    fun applyLists(text: String, tag: String, online: List<RecipeItem> = emptyList()) {
        var local = searchLocalRecipes(text, if (tag == "favoritos") "todos" else tag)
        val cached = loadCachedRecipes(context).filter { c ->
            val q = text.lowercase()
            q.isBlank() || c.name.lowercase().contains(q) || c.ingredients.any { it.lowercase().contains(q) }
        }
        if (tag == "favoritos") {
            local = (LOCAL_RECIPES + cached + online).filter { it.id in favIds }
            if (text.isNotBlank()) {
                val parts = text.lowercase().split(" ").filter { it.length > 1 }
                local = local.filter { r ->
                    val blob = (r.name + r.ingredients.joinToString()).lowercase()
                    parts.all { blob.contains(it) }
                }
            }
        } else {
            local = (local + cached + online).distinctBy { it.name.lowercase() }
            if (tag == "brasil") local = local.filter { it.area.contains("Brasil", true) || it.source.contains("BR") }
            else if (tag != "todos" && tag != "favoritos") {
                local = local.filter { tag in it.tags || it.category.lowercase().contains(tag) ||
                    (tag == "cafe" && it.category.contains("Breakfast", true)) ||
                    (tag == "doce" && it.category.contains("Dessert", true)) }
            }
        }
        results = local
        suggestions = if (text.isBlank()) emptyList() else local.take(8)
    }

    fun onQuery(text: String) {
        query = text
        error = null
        job?.cancel()
        applyLists(text, filter)
        if (text.length < 2) {
            loading = false
            return
        }
        job = scope.launch {
            delay(400)
            if (query != text) return@launch
            loading = true
            val online = searchRecipesOnline(text)
            if (query == text) {
                applyLists(text, filter, online)
                if (results.isEmpty()) error = "Nenhuma receita para \"$text\"."
            }
            loading = false
        }
    }

    fun open(r: RecipeItem) {
        scope.launch {
            val full = if (r.id.startsWith("mealdb-") && r.instructions.isBlank()) {
                lookupRecipeOnline(r.id) ?: r
            } else r
            cacheRecipe(context, full)
            vm.setTempRecipe(full)
            nav.navigate(Routes.FOOD_RECIPE_DETAIL)
        }
    }

    LaunchedEffect(filter) { applyLists(query, filter) }

    Column(Modifier.fillMaxSize().background(g.bg)) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.Filled.Close, null, tint = g.ink)
            }
            Text("Receitas", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
        }

        OutlinedTextField(
            value = query,
            onValueChange = { onQuery(it) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text("Nome ou ingrediente (ex.: frango, banana)…", color = g.muted) },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = g.muted) },
            trailingIcon = {
                if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = g.violet)
            },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = g.violet,
                unfocusedBorderColor = g.card,
                focusedContainerColor = g.card,
                unfocusedContainerColor = g.card,
            ),
        )

        // Filtros por tipo
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FILTERS.forEach { (key, label) ->
                val sel = filter == key
                Box(
                    Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (sel) g.violet else g.card)
                        .clickable {
                            filter = key
                            applyLists(query, key)
                        }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                ) {
                    Text(label, color = if (sel) androidx.compose.ui.graphics.Color.White else g.ink, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }
        }

        AnimatedVisibility(visible = suggestions.isNotEmpty() && query.isNotBlank()) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(14.dp)).background(g.card),
            ) {
                suggestions.take(6).forEach { r ->
                    Row(
                        Modifier.fillMaxWidth().clickable { open(r) }.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.RestaurantMenu, null, tint = g.muted, modifier = Modifier.size(16.dp))
                        Column(Modifier.padding(start = 10.dp).weight(1f)) {
                            Text(r.name, color = g.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                            Text(
                                buildString {
                                    if (r.area.isNotBlank()) append(r.area)
                                    if (r.carbsEstimate != null) {
                                        if (isNotEmpty()) append(" · ")
                                        append("~${r.carbsEstimate.roundToInt()} g carb")
                                    } else {
                                        if (isNotEmpty()) append(" · ")
                                        append("carb não informado")
                                    }
                                },
                                color = g.muted, fontSize = 12.sp, maxLines = 1,
                            )
                        }
                    }
                    HorizontalDivider(color = g.line, thickness = 0.5.dp)
                }
            }
        }

        Text(
            "${LOCAL_RECIPES.size} receitas BR offline · busca online TheMealDB · cache das abertas · filtro por tipo e ingrediente",
            color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
        )
        error?.let { Text(it, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp)) }

        LazyColumn(Modifier.padding(horizontal = 12.dp)) {
            items(results, key = { it.id }) { r ->
                val isFav = r.id in favIds
                Row(
                    Modifier.fillMaxWidth().clickable { open(r) }.padding(vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(r.name, color = g.ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                        Text(
                            buildString {
                                if (r.area.isNotBlank()) append(r.area)
                                if (r.category.isNotBlank()) {
                                    if (isNotEmpty()) append(" · "); append(r.category)
                                }
                                if (r.carbsEstimate != null) {
                                    if (isNotEmpty()) append(" · "); append("~${r.carbsEstimate.roundToInt()} g carb")
                                } else {
                                    if (isNotEmpty()) append(" · "); append("carb n/i")
                                }
                                if (isNotEmpty()) append(" · "); append(r.source)
                            },
                            color = g.muted, fontSize = 12.sp,
                        )
                    }
                    IconButton(onClick = {
                        val next = favIds.toMutableSet()
                        if (isFav) next.remove(r.id) else next.add(r.id)
                        favIds = next
                        saveFavRecipeIds(context, next)
                    }) {
                        Icon(
                            if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            null,
                            tint = if (isFav) g.blush else g.muted,
                        )
                    }
                    Text("›", color = g.muted, fontSize = 20.sp)
                }
                HorizontalDivider(color = g.line)
            }
        }
    }
}

@Composable
fun RecipeDetailScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    val recipe = vm.tempRecipe
    if (recipe == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Nenhuma receita selecionada", color = g.muted)
        }
        return
    }
    var mealType by remember { mutableStateOf("almoco") }
    var mealExpanded by remember { mutableStateOf(false) }
    var portions by remember { mutableStateOf(1.0) }
    var favIds by remember { mutableStateOf(loadFavRecipeIds(context)) }
    val isFav = recipe.id in favIds
    val carbScaled = recipe.carbsEstimate?.let { it * portions }
    val kcalScaled = recipe.kcalEstimate?.let { it * portions }
    val highCarb = (carbScaled ?: 0.0) >= 45.0

    LaunchedEffect(recipe.id) { cacheRecipe(context, recipe) }

    Column(Modifier.fillMaxSize().background(g.bg)) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.Filled.Close, null, tint = g.ink)
            }
            Text(recipe.name, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f), maxLines = 2)
            IconButton(onClick = {
                val next = favIds.toMutableSet()
                if (isFav) next.remove(recipe.id) else next.add(recipe.id)
                favIds = next
                saveFavRecipeIds(context, next)
            }) {
                Icon(if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = if (isFav) g.blush else g.muted)
            }
        }
        ScrollScreen {
            Row(
                Modifier.clip(RoundedCornerShape(20.dp)).background(g.lilacSoft).padding(horizontal = 12.dp, vertical = 6.dp),
            ) {
                Text(
                    listOfNotNull(recipe.source.ifBlank { null }, recipe.area.ifBlank { null }, recipe.category.ifBlank { null })
                        .joinToString(" · "),
                    color = g.violetDeep, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                )
            }

            SectionTitle("Porções")
            GCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.5 to "½", 1.0 to "1", 1.5 to "1½", 2.0 to "2").forEach { (v, label) ->
                        val sel = portions == v
                        Box(
                            Modifier.clip(RoundedCornerShape(12.dp)).background(if (sel) g.violet else g.inputBg)
                                .clickable { portions = v }.padding(horizontal = 14.dp, vertical = 10.dp),
                        ) {
                            Text(label, color = if (sel) androidx.compose.ui.graphics.Color.White else g.ink, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text("Porção base: ${recipe.servings}", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }

            SectionTitle("Carboidratos / energia")
            GCard {
                if (carbScaled != null) {
                    Text("~${carbScaled.roundToInt()} g de carboidrato (${portions}×)", color = g.violetDeep, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    if (highCarb) {
                        Text(
                            "Valor de carb relativamente alto nesta quantidade — use como informação, não como regra rígida.",
                            color = g.orange, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                } else {
                    Text("Carboidrato não informado nesta fonte.", color = g.ink, fontWeight = FontWeight.Medium)
                    Text(
                        "Você pode montar a refeição pelos ingredientes na aba Ferramentas → Montar refeição.",
                        color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
                    )
                    TextButton(onClick = { nav.navigate(Routes.FOOD_MEAL_BUILDER) }) {
                        Text("Abrir montar refeição", color = g.violet, fontWeight = FontWeight.Bold)
                    }
                }
                if (kcalScaled != null) {
                    Text("~${kcalScaled.roundToInt()} kcal (estimativa)", color = g.ink, modifier = Modifier.padding(top = 4.dp))
                }
                Text("Estimativas de referência — não substituem orientação profissional.", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            }

            if (recipe.ingredients.isNotEmpty()) {
                SectionTitle("Ingredientes")
                GCard {
                    recipe.ingredients.forEach { ing ->
                        Text("• $ing", color = g.ink, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp))
                    }
                }
            }

            if (recipe.instructions.isNotBlank()) {
                SectionTitle("Modo de preparo")
                GCard {
                    Text(recipe.instructions, color = g.ink, fontSize = 14.sp, lineHeight = 20.sp)
                }
            }

            SectionTitle("Registrar / bolus")
            GCard {
                Box {
                    Text(
                        MEAL_OPTIONS.find { it.first == mealType }?.second ?: "Almoço",
                        color = g.ink, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { mealExpanded = true }.padding(8.dp),
                    )
                    DropdownMenu(expanded = mealExpanded, onDismissRequest = { mealExpanded = false }) {
                        MEAL_OPTIONS.forEach { (key, label) ->
                            DropdownMenuItem(
                                text = { Text(label, color = if (key == mealType) g.green else g.ink) },
                                onClick = { mealType = key; mealExpanded = false },
                            )
                        }
                    }
                }
                PrimaryButton("Adicionar ao diário", g.green, {
                    val desc = "Receita: ${recipe.name} (${portions}× ${recipe.servings})"
                    vm.saveMeal(
                        Meal(
                            id = uid(),
                            type = mealType,
                            description = desc,
                            carbs = carbScaled,
                            at = System.currentTimeMillis(),
                            notes = "fonte=${recipe.source};receita=${recipe.id};porcoes=$portions",
                        ),
                    )
                    nav.popBackStack(Routes.FOOD, false)
                }, Modifier.padding(top = 8.dp))
                if (carbScaled != null) {
                    TextButton(onClick = {
                        context.getSharedPreferences("gluco_food_tools", Context.MODE_PRIVATE).edit()
                            .putFloat("last_meal_carbs", carbScaled.toFloat()).apply()
                        nav.navigate(Routes.FOOD_BOLUS)
                    }) {
                        Text("Usar este carb na calculadora de bolus", color = g.violet, fontWeight = FontWeight.Bold)
                    }
                }
                TextButton(onClick = { nav.navigate(Routes.FOOD_GLUCOSE_LINK) }) {
                    Text("Ver refeições × glicemia", color = g.violet, fontSize = 13.sp)
                }
            }
            Text(
                "Receitas são referência culinária. Valores nutricionais, quando existem, são estimativas.",
                color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp, bottom = 24.dp),
            )
        }
    }
}
