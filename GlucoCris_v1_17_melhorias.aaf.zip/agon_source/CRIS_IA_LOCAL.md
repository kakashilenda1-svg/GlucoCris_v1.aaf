# Cris IA local — relatório técnico (v1.8.0)

## Estado honesto desta entrega
Escrito e revisado por leitura, **mas NÃO compilado e NÃO testado em aparelho** (o ambiente de desenvolvimento não tinha SDK Android, Gradle nem internet). Nenhum teste da lista abaixo foi executado. O primeiro passo é rodar o build no GitHub Actions e corrigir eventuais erros de compilação.

## O que foi adicionado (pacote `com.agon.app.localai` + 1 tela)
| Componente | Função |
|---|---|
| `LocalModelManager` | Download do modelo (consentimento explícito), pausa/retomada por HTTP Range, verificação SHA-256, espaço livre, apagar/reinstalar. Guarda em `noBackupFilesDir/localai/models` (privado, fora do backup, preservado em atualizações). |
| `LocalAiEngine` | Motor LiteRT-LM: carrega sob demanda (GPU+visão → CPU+visão → CPU texto), descarrega por ociosidade (4 min), `onTrimMemory` e superaquecimento (status térmico ≥ SEVERE bloqueia a geração). |
| `CrisLocalAi` | Monta o prompt (regras, memória, dados reais do app via `buildCrisContext`, aviso de offline) e chama o motor. |
| `CrisSafetyGuard` | Regras no prompt; pré-filtro (emergência/autoagressão → resposta fixa com SAMU 192 / CVV 188); pós-filtro que bloqueia saída com ordem de dose. |
| `CrisToolRegistry` | Ferramentas somente-leitura que respondem direto do `AppData`: última glicemia, histórico, insulina, refeições, lembretes ativos. Extensível por `register()`. |
| `LocalMemoryManager` | Memória de longo prazo só por pedido ("lembre que…", "o que você sabe sobre mim", "esqueça…"). Editável/apagável na tela. Separada do histórico. |
| `LocalVisionManager` | OCR local (ML Kit) + modelo multimodal. Valores nutricionais só do rótulo (OCR) ou da base TACO já existente (por 100 g); porções marcadas como estimativa. |
| `LocalSpeech` | Reconhecedor no aparelho (Android 13+) e escolha de voz pt-BR sem rede. |
| `CrisConnectivityManager` | Estado online/offline para rótulos e prompt. |
| `CrisLocalAiScreen` (rota `cris_ia_config`) | Download/pausa/retomada/apagar/reinstalar/testar, privacidade, memória, histórico. Acesso: toque no status sob o nome "Cris" no chat. |

## Alterações em arquivos existentes (todas aditivas)
- `build.gradle.kts`: + `litertlm-android:latest.release`, + `mlkit:text-recognition:16.0.1`; versionCode 45→46, versionName 1.7.21→1.8.0. Pacote, assinatura, minSdk, Kotlin, AGP e Gradle **inalterados**.
- `AndroidManifest.xml`: + `ACCESS_NETWORK_STATE`, + `uses-native-library` opcionais (GPU).
- `Routes.kt`, `MainActivity.kt`: + 1 rota.
- `CrisPrefs.kt`: `CrisChatLine.source` (com padrão; histórico antigo continua lendo).
- `CrisIaScreen.kt`: `CrisMsg.source` (com padrão).
- `CrisShared.kt`: ordem de resposta = segurança → atalhos antigos → memória/ferramentas → CrisBrain → **IA local** → Gemini → servidor Emergent → CrisBrain básico. `CrisListener` tenta reconhecedor no aparelho.
- `CrisChatScreen.kt`: status offline/online, rótulo de origem, foto pela IA local primeiro (Gemini continua como alternativa).
- `CrisCloud.kt` (`CrisSpeaker`): voz da nuvem só se autorizada; voz local pt-BR preferida.
- Intocados: cálculos de glicemia/insulina, bolus, lembretes, alimentação, localizador, perfil, banco (DataStore), navegação principal.

## Mudanças de comportamento (por privacidade, pedidas no prompt)
1. Gemini/Emergent **não recebem mais** o resumo de glicemia/insulina/refeições, a menos que a usuária ligue "Enviar resumo de saúde a serviços online" (padrão: desligado).
2. A voz natural da nuvem (Emergent TTS) vem **desligada**; o app usa a voz do aparelho até a usuária ligar a opção.

## Modelo
Gemma 4 E2B (`gemma-4-E2B-it.litertlm`, repositório `litert-community/gemma-4-E2B-it-litert-lm`), 2.588.147.712 bytes (~2,59 GB), SHA-256 `181938105e0eefd105961417e8da75903eacda102c4fce9ce90f50b97139a63c` (conferido na página do repositório), licença Apache-2.0 + política de uso proibido da Gemma. Texto + imagem. Requer ~2,6 GB livres + 600 MB de margem; RAM de pico na documentação do Google é da ordem de 1,5 GB em CPU de desktop (não medido no RedMagic).

## Ativar
Chat da Cris → toque no texto de status sob "Cris" → **Baixar IA local** → confirmar (use Wi-Fi) → aguardar verificação → teste automático.

## Atualizar sem perder dados
Instale o APK novo por cima (mesmo pacote `com.agon.app` e mesma `debug.keystore`). Dados ficam no DataStore; o modelo fica em `noBackupFilesDir`, que sobrevive à atualização.

## Riscos conhecidos / a verificar no primeiro build
- `latest.release` não é reprodutível: após compilar, fixe a versão resolvida do `litertlm-android`.
- Se o merge do manifest acusar `minSdk` maior que 24 para o LiteRT-LM, é preciso subir o `minSdk` (o RedMagic não é afetado).
- Os nomes exatos da API (`EngineConfig(visionBackend=…)`, `Message.user/model`, `sendMessageAsync(String)`) foram tirados da documentação oficial, mas não compilados.
- O download roda no processo do app (sem serviço em segundo plano): se o Android encerrar o app, é preciso tocar em Continuar.
- Vosk e whisper.cpp **não** foram integrados. Sem pacote de voz pt-BR offline instalado no Android, o microfone sem internet não funciona.
- A escolha de voz "feminina" é heurística pelo nome da voz.
- Pré-filtros de segurança são por palavras-chave e podem não pegar todas as formulações.

## Testes (checklist; NENHUM executado ainda)
1 instalar · 2 abrir Gluco Cris · 3 abrir Cris IA · 4 baixar modelo · 5 integridade · 6 conversa offline (modo avião) · 7 conhecimentos gerais · 8 foto offline · 9 voz→texto offline · 10 fala offline · 11 memória ("lembre que…", reiniciar app) · 12 "qual foi minha última glicemia?" confere com a lista · 13 sem internet · 14 com internet · 15 servidor externo fora · 16 pausar/retomar/matar app no meio · 17 RAM/temperatura/bateria em conversa longa · 18 regressão (glicose, insulina, bolus, lembretes, alimentação, localizador, perfil, Cris Hidrata) · 19 atualizar por cima e conferir dados · 20 build final.


---

# v1.9.0 — Pesquisa online automática (ferramenta da Cris IA local)

## Estado honesto
Escrito e revisado por leitura. **NÃO compilado e NÃO testado em aparelho** (ambiente sem SDK Android, Gradle e internet). Os testes da seção "Testes" precisam ser executados no celular.

## Arquitetura
A IA local (Gemma/LiteRT-LM) continua sendo a única que conversa. A pesquisa é uma ferramenta: `CrisWebSearch.prepare()` busca fatos, coloca os trechos no prompt do modelo local (`extraBlock`) e a lista de fontes REAIS (título, veículo, data, link) é anexada pelo código — o modelo não escreve links.

Ordem em `crisRespond`: segurança → atalhos → memória/ferramentas do app → CrisBrain → **pesquisa (se a pergunta for atual) + IA local** → Gemini → servidor → básico. Se o modelo local não estiver instalado e a pesquisa achou resultados, mostra só os achados reais (sem outra IA).

## Quando pesquisa (CrisSearchPolicy)
- Pesquisa: notícias, "hoje/atualmente/recente/esta semana/últimas", cargos ("quem é o presidente…"), cotações, placares, medicamentos/bula/Anvisa/vacinas/diretrizes, ou pedido explícito ("pesquise…").
- Não pesquisa: conhecimento estável ("Quem descobriu o Brasil?"), data/hora (relógio do aparelho), dados do app, perguntas sem internet.

## Provedores
| Provedor | Chave | Uso |
|---|---|---|
| Google Notícias (RSS) | não | notícias e atualidades |
| Wikipédia pt (API MediaWiki) | não | conhecimento geral, cargos, ciência |
| PubMed / NIH (E-utilities) | não | literatura científica em saúde |
| Brave Search API | **opcional**, digitada pela usuária em Cris IA > configurações | busca geral; saúde priorizada em gov.br/OMS/NIH/SBD |
Fontes oficiais (.gov.br, OMS, NIH…) e veículos reconhecidos ganham prioridade e marcação "(fonte oficial)". Nenhuma chave secreta está no código/APK.

## Privacidade
- Só vão termos-chave extraídos da pergunta atual (até 8 palavras). Nunca histórico, glicemia, dose ou perfil.
- Pergunta com dado pessoal (valores com mg/dL/UI, "minha glicemia…", nome, e-mail, telefone, CPF): a Cris NÃO pesquisa; mostra os termos que enviaria e pergunta; só com "pode pesquisar" pesquisa, já sem os dados pessoais.
- HTTPS obrigatório, timeouts 6 s/8 s, corpo máx. 600 KB, mínimo 1,5 s entre buscas, máx. 20 buscas/hora, cache de 10 min, textos de terceiros tratados como dados (anti prompt-injection).
- Falha/offline: a resposta sai do modelo local com aviso "não consegui consultar informações recentes".
- A chave Brave fica em SharedPreferences privado (o manifest tem allowBackup=true; a chave pode entrar no backup do Android).

## Arquivos
Novo: `localai/CrisWebSearch.kt`. Alterados: `localai/CrisLocalAi.kt`, `localai/LocalAiSettings.kt`, `ui/screens/CrisShared.kt`, `ui/screens/CrisLocalAiScreen.kt` (card "Pesquisa online"), `app/build.gradle.kts` (versão 1.9.0 / 47), este documento. Nada mais foi tocado.

## Testes (executar no aparelho)
Wi-Fi, dados móveis e modo avião, com e sem a chave Brave:
1. "Quem é o presidente do Brasil atualmente?" → deve pesquisar (rótulo 🌐, fontes com link e data).
2. "Quais são as principais notícias de hoje?" → deve pesquisar (manchetes).
3. "O que aconteceu de importante nesta semana?" → deve pesquisar.
4. "Quem descobriu o Brasil?" → NÃO pesquisa (🔒 só local).
5. Modo avião nas 1–3 → resposta local com aviso de limitação.
6. "Minha glicemia está 250, o que diz a bula da metformina?" → pede autorização; nada é enviado antes.
7. Botão "Testar pesquisa" nas configurações.

---

# v1.10.0 — Cris IA de uso geral (complemento)

## Estado honesto
Escrito e revisado por leitura; **NÃO compilado e NÃO testado em aparelho** (sem SDK/Gradle/internet no ambiente). Lógica de contas, correção de digitação e extração de cargos foi conferida por espelho em Python (não é o código Kotlin rodando).

## O que mudou
- **Resposta direta, não resultado bruto.** Com o modelo local instalado: o prompt manda começar pela resposta (ex.: o nome), dar contexto curto, reescrever (sem copiar definições), comparar fontes e fechar com "Consulta feita em…"; as fontes com link/data são anexadas pelo código.
- **Dado estruturado de cargos (Wikidata).** "Quem é o presidente do <país>?" consulta o Wikidata (cargo sem data de término) e entrega o nome como base verificável, conferido com notícias recentes.
- **Sem modelo local instalado (ou sem resposta dele):** `composeWithoutModel` monta uma resposta direta a partir das fontes (nome + data da consulta + notícias de conferência; manchetes; ou 2 frases da fonte), dizendo claramente que NÃO foi o modelo local que redigiu. Nesse caso qualquer pergunta geral é pesquisada (Wikipédia etc.).
- **Contas exatas** (`CrisMath`): "quanto é 25 vezes 48?", %, raiz, potências — funciona offline e sem modelo; ignora mensagens de saúde/insulina (não toca nos cálculos clínicos).
- **Erros de digitação** (`CrisTypo`): corrige palavras-chave conhecidas (prezidente, atualmete, notisias, oje…) só para decidir e pesquisar; o modelo recebe a mensagem original.
- **Prompt geral:** a Cris responde qualquer assunto, sem se limitar a diabetes, mantendo personalidade/memória.
- **Mensagem honesta offline:** a frase antiga "quando a conexão voltar, a gente conversa sobre qualquer assunto" foi trocada por uma explicação verdadeira (modelo não instalado → como baixar; modelo falhou → tente de novo; nunca inventa).

## Depende do modelo local instalado
Explicações em linguagem natural (por que o céu é azul, como funciona IA), conversa, resumo/comparação de fontes e qualquer resposta geral OFFLINE. Sem o modelo: só contas, dados do app, respostas básicas e, com internet, respostas montadas das fontes.

## Arquivos
Novos: `localai/CrisTypo.kt`, `localai/CrisMath.kt`. Alterados: `localai/CrisWebSearch.kt`, `localai/CrisLocalAi.kt`, `ui/screens/CrisShared.kt`, `app/build.gradle.kts` (1.10.0/48), este documento.

## Testes a executar no aparelho
Com e sem modelo, Wi-Fi/dados/avião: histórica ("Quem descobriu o Brasil?"), matemática ("Quanto é 25 vezes 48?"), gerais ("capital da França", "por que o céu é azul"), atuais ("presidente do Brasil/EUA atualmente"), notícias de hoje, com erros ("prezidente do brazil atualmete", "notisias de oje"), offline.


---

# Revisão estática de erros (sem alterar código)

## Estado honesto
Revisão feita **somente por leitura e verificações mecânicas**. O ambiente não tinha Kotlin, Gradle, SDK Android nem internet, então **nada foi compilado e nada foi testado em aparelho**. Esta revisão não prova que o build passa.

## O que foi verificado
- Chaves, parênteses e colchetes balanceados nos 72 arquivos `.kt`.
- Todos os imports `com.agon.app.*` resolvem para declarações existentes (exceto `R` e `BuildConfig`, gerados no build).
- Assinaturas conferidas entre chamador e chamado: `crisRespond`, `CrisTurnResult`, `CrisMsg`, `CrisBrain.reply`, `CrisCloud.chat`, `CrisGemini.chatAsCris/analyzeMultimodal`, `CrisWebSearch.prepare/consumeConsent/footer/composeWithoutModel`, `LocalAiEngine`, `LocalModelManager`, `LocalMemoryManager`, `CrisToolRegistry`, `CrisMath`, `CrisTypo`, `LocalVisionManager`, `CrisLocalAiScreen`.
- Campos de `AppData`, `FoodItem`, `GlucoColors`, rotas e `MainActivity` conferem com o uso.

## Resultado
Nenhum erro de compilação **definitivo** encontrado por leitura; nenhum arquivo `.kt` foi alterado.

## Pontos que só o build real pode confirmar
- API do `litertlm-android` 0.16.1 (`EngineConfig`, `ConversationConfig`, `Message.user/model`, `Contents.of`, `Content.ImageFile`, `sendMessageAsync`): usada conforme a documentação, não compilada.
- `kotlinOptions { jvmTarget = "17" }` com Kotlin 2.2.21: se o build acusar erro de depreciação, trocar por `kotlin { compilerOptions { jvmTarget.set(JvmTarget.JVM_17) } }`.
- `onTrimMemory`: a condição `>= TRIM_MEMORY_RUNNING_CRITICAL (15)` também descarrega o modelo quando a tela fica oculta (`UI_HIDDEN`, 20). Não foi alterado.

## Pedido do prompt ainda NÃO atendido
O modelo (Gemma 4 E2B, ~2,59 GB) **não está dentro do APK**: é baixado na primeira ativação, com consentimento. Incluí-lo no APK, no AAB (Play for On-device AI) ou compartilhar por WhatsApp depende de limites de tamanho e da licença, que precisam ser conferidos e decididos antes de mudar a arquitetura.


---

# Revisão estática de erros (sem alterar código)

## Estado honesto
Revisão feita **somente por leitura e verificações mecânicas**. O ambiente não tinha Kotlin, Gradle, SDK Android nem internet, então **nada foi compilado e nada foi testado em aparelho**. Esta revisão não prova que o build passa.

## O que foi verificado
- Chaves, parênteses e colchetes balanceados nos 72 arquivos `.kt`.
- Todos os imports `com.agon.app.*` resolvem para declarações existentes (exceto `R` e `BuildConfig`, gerados no build).
- Assinaturas conferidas entre chamador e chamado: `crisRespond`, `CrisTurnResult`, `CrisMsg`, `CrisBrain.reply`, `CrisCloud.chat`, `CrisGemini.chatAsCris/analyzeMultimodal`, `CrisWebSearch.prepare/consumeConsent/footer/composeWithoutModel`, `LocalAiEngine`, `LocalModelManager`, `LocalMemoryManager`, `CrisToolRegistry`, `CrisMath`, `CrisTypo`, `LocalVisionManager`, `CrisLocalAiScreen`.
- Campos de `AppData`, `FoodItem`, `GlucoColors`, rotas e `MainActivity` conferem com o uso.

## Resultado
Nenhum erro de compilação **definitivo** encontrado por leitura; nenhum arquivo `.kt` foi alterado.

## Pontos que só o build real pode confirmar
- API do `litertlm-android` 0.16.1 (`EngineConfig`, `ConversationConfig`, `Message.user/model`, `Contents.of`, `Content.ImageFile`, `sendMessageAsync`): usada conforme a documentação, não compilada.
- `kotlinOptions { jvmTarget = "17" }` com Kotlin 2.2.21: se o build acusar erro de depreciação, trocar por `kotlin { compilerOptions { jvmTarget.set(JvmTarget.JVM_17) } }`.
- `onTrimMemory`: a condição `>= TRIM_MEMORY_RUNNING_CRITICAL (15)` também descarrega o modelo quando a tela fica oculta (`UI_HIDDEN`, 20). Não foi alterado.

## Pedido do prompt ainda NÃO atendido
O modelo (Gemma 4 E2B, ~2,59 GB) **não está dentro do APK**: é baixado na primeira ativação, com consentimento. Incluí-lo no APK, no AAB (Play for On-device AI) ou compartilhar por WhatsApp depende de limites de tamanho e da licença, que precisam ser conferidos e decididos antes de mudar a arquitetura.

---

# v1.11.0 — Pergunta de download da IA local na primeira abertura

**Não compilado e não testado em aparelho.**

- Depois do tour de ajuda (concluído ou cancelado com o X), o app mostra uma vez: "Baixar a IA da Cris?" com **Sim, baixar** / **Agora não**.
- **Sim**: inicia o download (`LocalModelManager.start()`) e abre a tela "IA da Cris" para acompanhar o progresso.
- **Não** (ou tocar fora): nada é baixado. Depois: chat da Cris > toque no status sob o nome > **Baixar IA local**.
- A pergunta não volta (guardada em `LocalAiSettings.downloadOfferAnswered`). Não aparece se o modelo já está instalado ou há download parcial.
- O download continua exigindo o app aberto e ~3,2 GB livres. O modelo continua fora do APK.
- Arquivos: novo `ui/screens/CrisLocalAiOffer.kt`; alterados `MainActivity.kt`, `localai/LocalAiSettings.kt`, `app/build.gradle.kts` (49 / 1.11.0).

---

# v1.12.0 — Download obrigatório da IA local antes do login (instalação nova)

**Não compilado e não testado em aparelho.**

- Em instalação nova (sem conta Google vinculada), antes da tela de login aparece "Preparando a Cris ❤️", que baixa a IA local e só libera o login quando o modelo está instalado e verificado (SHA-256).
- **Wi-Fi/rede sem franquia:** começa sozinho. **Dados móveis:** espera o toque em "… com dados móveis". **Sem internet:** pede para conectar ao Wi-Fi.
- Tela fica ligada durante o download. Se o app fechar, ao reabrir a tela retoma de onde parou.
- **Falha** (espaço insuficiente, conexão, arquivo corrompido): "Tentar de novo" e "Continuar sem a IA por enquanto" (evita travar quem não consegue baixar; um app de saúde não deve ficar inacessível).
- **Aparelhos com RAM total abaixo de 5 GB** não são obrigados (constante `MIN_RAM_FOR_REQUIRED_AI`, ajustável); abrem normalmente e podem baixar depois.
- **Quem já tem conta vinculada (atualização)** não é bloqueado; segue com a pergunta opcional da v1.11.0.
- Arquivos: novo `ui/screens/CrisModelGateScreen.kt`; alterados `MainActivity.kt`, `app/build.gradle.kts` (50 / 1.12.0).
- O modelo continua fora do APK; o download exige ~3,2 GB livres e o app aberto.

---

# v1.13.0 — Download da IA local em segundo plano

**Não compilado e não testado em aparelho.**

- Novo `localai/ModelDownloadService.kt`: serviço em primeiro plano (tipo `dataSync`) que mostra o progresso numa notificação com botão **Pausar** e mantém o app vivo enquanto o `LocalModelManager` baixa. O download em si continua no `LocalModelManager` (retomada por Range, SHA-256).
- Opção "Continuar baixando em segundo plano" (padrão **ligada**) na tela "Preparando a Cris" e em Configurações da IA > Download (`BackgroundDownloadSwitch`, em `CrisModelGateScreen.kt`).
- `LocalModelManager.start()` inicia o serviço quando a opção está ligada. Ao terminar, falhar ou pausar, o serviço encerra e mostra uma notificação final.
- Manifest: `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_DATA_SYNC` e o `<service>`. Versão 51 / 1.13.0.
- Limites: no Android 13+ a notificação só aparece se o app tiver permissão de notificações (o serviço roda mesmo sem ela); no Android 15+ serviços `dataSync` têm limite diário de tempo, e ao estourar o download é pausado e retoma ao reabrir o app; se o sistema matar o processo, o download também para e retoma ao reabrir.
- Dados do usuário: nenhum dado, banco, perfil ou registro foi alterado; só foram adicionadas chaves novas em SharedPreferences de configurações da IA.
