# Gluco Cris ❤️

Aplicativo Android (Kotlin + Jetpack Compose) de apoio ao dia a dia com diabetes: glicose, insulina,
lembretes, alimentação, hidratação (Cris Hidrata), relatórios e a assistente Cris IA.

> Uso de apoio. Não substitui orientação médica nem calcula dose de insulina.

## Compilar

```bash
./gradlew assembleDebug
```

O APK sai em `app/build/outputs/apk/debug/`.

## Configuração

- **Cris IA (Gemini):** a chave é lida de `local.properties` (`gemini.api.key=SUA_CHAVE`). `local.properties` já está no
  `.gitignore`. **Nunca** coloque a chave direto no código.
- **Login com Google:** crie um *ID do cliente OAuth* do tipo **Android** no Google Cloud Console com
  o pacote `com.agon.app` e o SHA-1 da chave que assina o APK (use `./gradlew signingReport`). Com a
  tela de consentimento em modo teste, adicione os e-mails de teste.
- **Assinatura:** o projeto usa `debug.keystore` para que as atualizações mantenham o mesmo SHA-1 e os dados
  do usuário. Para publicar na Play Store use uma chave de upload própria (não versionada).

## Recursos

- Tour inteligente com voz e simulação (nada é salvo)
- Cris Hidrata com relógio inteligente, alerta de glicose alta e gotinha animada
- Temas claro/escuro e azul com cinza
- Humor com emojis ou figurinhas de bruxinho (personagem original)
