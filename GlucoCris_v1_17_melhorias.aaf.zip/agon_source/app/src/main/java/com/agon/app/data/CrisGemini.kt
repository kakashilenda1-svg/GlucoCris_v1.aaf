package com.agon.app.data

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.agon.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar

/**
 * Motor complementar Gemini para a IA Cris.
 * NÃO substitui CrisBrain nem CrisCloud: é uma camada a mais, com fallback.
 * A chave vem de BuildConfig (local.properties), nunca hardcoded.
 */
object CrisGemini {
    private const val TAG = "CrisGemini"
    private const val PREFS = "cris_gemini_limits"
    private const val KEY_DAY = "day"
    private const val KEY_COUNT = "count"
    /** Limite diário conservador no dispositivo (plano gratuito). */
    private const val DAILY_LIMIT = 40

    fun isConfigured(): Boolean = BuildConfig.GEMINI_API_KEY.isNotBlank()

    fun remainingToday(context: Context): Int {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val today = dayKey()
        if (p.getString(KEY_DAY, "") != today) return DAILY_LIMIT
        return (DAILY_LIMIT - p.getInt(KEY_COUNT, 0)).coerceAtLeast(0)
    }

    private fun dayKey(): String {
        val c = Calendar.getInstance()
        return "${c.get(Calendar.YEAR)}-${c.get(Calendar.MONTH)}-${c.get(Calendar.DAY_OF_MONTH)}"
    }

    private fun consumeQuota(context: Context): Boolean {
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val today = dayKey()
        val ed = p.edit()
        if (p.getString(KEY_DAY, "") != today) {
            ed.putString(KEY_DAY, today).putInt(KEY_COUNT, 1).apply()
            return true
        }
        val n = p.getInt(KEY_COUNT, 0)
        if (n >= DAILY_LIMIT) return false
        ed.putInt(KEY_COUNT, n + 1).apply()
        return true
    }

    /**
     * Conversa como Cris. Não envia glicemia/insulina brutas além do resumo já sanitizado em [appContext].
     */
    suspend fun chatAsCris(
        context: Context,
        userMessage: String,
        history: List<Pair<Boolean, String>>,
        appContext: String,
        userName: String,
    ): String? = withContext(Dispatchers.IO) {
        if (!isConfigured()) return@withContext null
        if (!consumeQuota(context)) {
            return@withContext "Atingi o limite diário de conversas com a inteligência ampliada neste aparelho. " +
                "Posso continuar com minhas respostas locais, ou tente amanhã."
        }
        val key = BuildConfig.GEMINI_API_KEY
        val model = BuildConfig.GEMINI_MODEL.ifBlank { "gemini-3.8-flash" }
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key",
        )

        val system = """
Você é a **IA Cris**, assistente do aplicativo Gluco Cris (controle de diabetes e nutrição no Brasil).
Nunca diga que você é o Gemini, Google ou outro modelo. Seu nome é Cris.
Fale em português brasileiro, de forma amigável, clara e prestativa.
Não finja ser humana. Não invente exames, doses de insulina ou prescrições.
Não calcule dose de insulina. Não altere parâmetros médicos.
Se falar de carboidratos ou comida, baseie-se no contexto do app quando disponível e lembre que valores de foto/IA são estimativas.
Distinga: (1) o que está no contexto do app, (2) conhecimento geral, (3) incerteza.
Contexto resumido do app (já filtrado; não peça CPF ou dados sensíveis extras):
$appContext
Nome da pessoa: $userName
Respostas curtas no celular (2–6 frases), a menos que peçam detalhe.
""".trimIndent()

        val contents = JSONArray()
        // histórico recente
        history.takeLast(12).forEach { (fromUser, text) ->
            contents.put(
                JSONObject()
                    .put("role", if (fromUser) "user" else "model")
                    .put("parts", JSONArray().put(JSONObject().put("text", text.take(1500)))),
            )
        }
        contents.put(
            JSONObject()
                .put("role", "user")
                .put("parts", JSONArray().put(JSONObject().put("text", userMessage.take(4000)))),
        )

        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.7)
                    .put("maxOutputTokens", 1024),
            )

        try {
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 15000
                readTimeout = 40000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText().orEmpty()
            if (code == 429) return@withContext "Estou sem cota na inteligência ampliada no momento. Vou usar meu modo local se precisar — reformule a pergunta."
            if (code !in 200..299) {
                Log.w(TAG, "HTTP $code ${raw.take(200)}")
                return@withContext null // fallback para CrisCloud / local
            }
            extractText(raw)?.trim()?.ifBlank { null }
        } catch (e: Exception) {
            Log.w(TAG, "chat fail", e)
            null
        }
    }

    private fun extractText(resp: String): String? {
        return try {
            val root = JSONObject(resp)
            val parts = root.optJSONArray("candidates")
                ?.optJSONObject(0)
                ?.optJSONObject("content")
                ?.optJSONArray("parts") ?: return null
            buildString {
                for (i in 0 until parts.length()) append(parts.getJSONObject(i).optString("text"))
            }
        } catch (_: Exception) {
            null
        }
    }


    /**
     * Análise multimodal (imagem e/ou texto de documento/áudio transcrito).
     * Partes em [inlineParts]: Pair(mime, base64).
     */
    suspend fun analyzeMultimodal(
        context: Context,
        userMessage: String,
        appContext: String,
        userName: String,
        inlineParts: List<Pair<String, String>>,
    ): String? = withContext(Dispatchers.IO) {
        if (!isConfigured()) return@withContext null
        if (!consumeQuota(context)) {
            return@withContext "Limite diário de análises ampliada atingido neste aparelho. Tente amanhã ou use o modo local."
        }
        if (inlineParts.isEmpty() && userMessage.isBlank()) return@withContext null
        val key = BuildConfig.GEMINI_API_KEY
        val model = BuildConfig.GEMINI_MODEL.ifBlank { "gemini-3.8-flash" }
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key",
        )
        val system = """
Você é a IA Cris do app Gluco Cris (Brasil). Nunca diga que é Gemini.
Português brasileiro, clara e prestativa. Não invente o que não está no anexo.
Se for refeição: liste alimentos visíveis e diga que porções são estimativas; não invente nutrientes sem base.
Não calcule dose de insulina. Não peça dados sensíveis extras.
Contexto do app (filtrado): $appContext
Usuário: $userName
""".trimIndent()
        val parts = JSONArray()
        parts.put(JSONObject().put("text", system + "\n\nPedido do usuário:\n" + userMessage.ifBlank { "Analise o(s) anexo(s)." }))
        for ((mime, b64) in inlineParts.take(4)) {
            parts.put(
                JSONObject().put(
                    "inline_data",
                    JSONObject().put("mime_type", mime).put("data", b64),
                ),
            )
        }
        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(JSONObject().put("role", "user").put("parts", parts)),
            )
            .put(
                "generationConfig",
                JSONObject().put("temperature", 0.4).put("maxOutputTokens", 2048),
            )
        try {
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 20000
                readTimeout = 60000
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
            }
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText().orEmpty()
            if (code == 429) return@withContext "Cota da IA ampliada esgotada no momento."
            if (code !in 200..299) {
                Log.w(TAG, "multi HTTP $code ${raw.take(200)}")
                return@withContext null
            }
            extractText(raw)?.trim()?.ifBlank { null }
        } catch (e: Exception) {
            Log.w(TAG, "multi fail", e)
            null
        }
    }

    fun bitmapToJpegBase64(bitmap: Bitmap, maxSide: Int = 768, quality: Int = 82): String {
        var bmp = bitmap
        val max = maxOf(bmp.width, bmp.height)
        if (max > maxSide) {
            val scale = maxSide.toFloat() / max
            bmp = android.graphics.Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * scale).toInt().coerceAtLeast(1),
                (bmp.height * scale).toInt().coerceAtLeast(1),
                true,
            )
        }
        val baos = java.io.ByteArrayOutputStream()
        bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, quality, baos)
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }

    fun fileToBase64(bytes: ByteArray, maxBytes: Int = 4_000_000): String? {
        if (bytes.isEmpty() || bytes.size > maxBytes) return null
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    /**
     * Teste rápido de conexão (sem logar a chave).
     */
    suspend fun ping(): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        if (!isConfigured()) return@withContext false to "Chave não configurada em local.properties"
        try {
            val key = BuildConfig.GEMINI_API_KEY
            val model = BuildConfig.GEMINI_MODEL.ifBlank { "gemini-3.8-flash" }
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key",
            )
            val body = JSONObject()
                .put(
                    "contents",
                    JSONArray().put(
                        JSONObject().put(
                            "parts",
                            JSONArray().put(JSONObject().put("text", "Responda só: ok")),
                        ),
                    ),
                )
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 12000
                readTimeout = 20000
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = conn.responseCode
            val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText().orEmpty()
            if (code in 200..299) true to "Conexão Gemini OK"
            else false to "Falha HTTP $code"
        } catch (e: Exception) {
            false to (e.message ?: "erro de rede")
        }
    }
}
