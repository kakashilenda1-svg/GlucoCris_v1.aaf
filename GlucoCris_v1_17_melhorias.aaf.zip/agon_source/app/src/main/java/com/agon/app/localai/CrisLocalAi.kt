package com.agon.app.localai

import android.content.Context
import com.agon.app.data.AppData
import com.agon.app.data.CrisMemory
import com.agon.app.ui.screens.buildCrisContext

/** Orquestra a IA local: prompt, contexto do app, memória, segurança. */
object CrisLocalAi {

    /** Rótulos de origem mostrados na conversa. */
    const val SRC_LOCAL = "local"
    const val SRC_LOCAL_WEB = "local_web"
    const val SRC_CALC = "calculo"
    const val SRC_APP = "app"
    const val SRC_ONLINE = "online"
    const val SRC_SAFETY = "seguranca"
    const val SRC_BASIC = "basica"

    fun label(source: String): String = when (source) {
        SRC_LOCAL -> "🔒 IA no aparelho"
        SRC_LOCAL_WEB -> "🔒 IA no aparelho + 🌐 pesquisa online"
        SRC_CALC -> "🧮 conta exata do app"
        SRC_APP -> "📋 dados do seu app"
        SRC_ONLINE -> "🌐 consulta online"
        SRC_SAFETY -> "⚕️ aviso de segurança"
        SRC_BASIC -> "💬 respostas básicas offline"
        else -> ""
    }

    fun isReady(context: Context): Boolean =
        LocalAiSettings.enabled(context) && LocalModelManager.get(context).isInstalled()

    /** Explicação honesta quando não há como gerar uma resposta geral agora. */
    fun limitationNotice(context: Context): String {
        val online = CrisConnectivityManager.isOnline(context)
        return if (!LocalModelManager.get(context).isInstalled()) {
            "Ainda não tenho a IA local instalada neste aparelho, então só consigo respostas básicas" +
                (if (online) " e pesquisas simples" else " (e estou sem internet)") + ". " +
                "Toque no status sob meu nome, no chat, e escolha Baixar IA local (uma vez, no Wi-Fi): depois converso sobre qualquer assunto, até offline. " +
                "Enquanto isso, posso mostrar seus registros, criar lembretes ou abrir o localizador de insulina."
        } else {
            "Não consegui gerar a resposta agora: o modelo local não respondeu (pode ser memória ou aquecimento do aparelho). Tente de novo em instantes. " +
                "Não vou inventar uma resposta."
        }
    }

    fun buildSystemPrompt(context: Context, data: AppData, memory: CrisMemory, userName: String, extraBlock: String = ""): String {
        val online = CrisConnectivityManager.isOnline(context)
        return buildString {
            append("Você é a Cris ❤️, assistente pessoal do aplicativo Gluco Cris. Fale em português do Brasil, de forma carinhosa, clara e natural. ")
            append("Não diga que é Qwen, Llama, Gemma, Google ou outro modelo; seu nome é Cris. Não finja ser humana.\n")
            append("Você é uma assistente inteligente de uso geral: responde sobre QUALQUER assunto, não só diabetes. ")
            append("Entenda perguntas mesmo com erros de digitação. Seja carinhosa, mas OBJETIVA. ")
            append("Em contas, resolva passo a passo com cuidado. Se não souber, diga com honestidade e não invente.\n")
            val direct = memory.shortAnswers || LocalAiSettings.isDirectStyle(context)
            if (direct) {
                append("MODO DIRETA: responda em 1 a 3 frases. Sem introdução, sem repetir a pergunta, sem listas longas. ")
            } else {
                append("MODO EXPLICATIVA: pode usar até 6 frases claras, ainda assim sem enrolação. ")
            }
            append("Não liste fontes no corpo (elas são anexadas depois). ")
            append("Para fatos atuais (presidente, eleições, notícias, preços, resultados), use SOMENTE o bloco PESQUISA NA INTERNET se ele existir; seu conhecimento de treino pode estar desatualizado.\n")
            append("\n")
            if (userName.isNotBlank()) append("Nome da pessoa: $userName\n")
            if (!online) {
                append("Você está OFFLINE: não tem acesso à internet nem a notícias ou informações atuais. Se a pergunta depender de algo recente, diga que não pode confirmar agora.\n")
            }
            append("Data e hora atuais do aparelho: ${java.text.SimpleDateFormat("EEEE, dd/MM/yyyy HH:mm", java.util.Locale("pt", "BR")).format(java.util.Date())}.\n")
            append("Diferencie sempre: (1) o que está nos DADOS DO APP, (2) o que você sabe por treinamento, (3) o que não sabe.\n")
            append(CrisSafetyGuard.SYSTEM_RULES)
            if (extraBlock.isNotBlank()) append(extraBlock)
            val mem = LocalMemoryManager.promptBlock(context)
            if (mem.isNotBlank()) append("\n").append(mem)
            if (memory.noteToSelf.isNotBlank()) append("Preferência da pessoa: ${memory.noteToSelf}\n")
            append("\nDADOS DO APP (registros reais da pessoa, só neste aparelho):\n")
            append(try { buildCrisContext(data) } catch (_: Exception) { "indisponível\n" })
        }
    }

    /** Conversa pela IA local. Retorna null se a IA local não estiver disponível ou falhar (o chamador usa o fallback). */
    suspend fun chat(
        context: Context,
        text: String,
        history: List<Pair<Boolean, String>>,
        data: AppData,
        memory: CrisMemory,
        userName: String,
        extraBlock: String = "",
    ): String? {
        if (!isReady(context)) return null
        return try {
            val system = buildSystemPrompt(context, data, memory, userName, extraBlock)
            val out = LocalAiEngine.get(context).generate(system, history, text).trim()
            if (out.isBlank()) null else out
        } catch (t: Throwable) {
            android.util.Log.e("CrisLocalAi", "Falha na geração local", t)
            null
        }
    }
}
