package com.agon.app.localai

import android.content.ComponentCallbacks2
import android.content.Context
import android.content.res.Configuration
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.util.Log
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.nehuatl.llamacpp.LlamaHelper
import java.io.File
import java.util.concurrent.atomic.AtomicBoolean

sealed interface EngineState {
    data object Unloaded : EngineState
    data object Loading : EngineState
    data class Loaded(val backend: String, val vision: Boolean) : EngineState
    data class Error(val message: String) : EngineState
}

/**
 * Motor de IA local com llama.cpp (biblioteca llamacpp-kotlin).
 * Carrega sob demanda, descarrega por ociosidade / pressão de memória / aquecimento.
 * Nunca executa na thread principal.
 */
class LocalAiEngine private constructor(context: Context) {
    private val app = context.applicationContext
    private val mutex = Mutex()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var idleJob: Job? = null
    private var helper: LlamaHelper? = null
    private var hasVision = false
    private val loaded = AtomicBoolean(false)

    private val _state = MutableStateFlow<EngineState>(EngineState.Unloaded)
    val state: StateFlow<EngineState> = _state.asStateFlow()

    private val eventFlow = MutableSharedFlow<LlamaHelper.LLMEvent>(
        extraBufferCapacity = 256,
        onBufferOverflow = BufferOverflow.DROP_OLDEST,
    )

    init {
        app.registerComponentCallbacks(object : ComponentCallbacks2 {
            override fun onTrimMemory(level: Int) {
                if (level >= ComponentCallbacks2.TRIM_MEMORY_BACKGROUND ||
                    level >= ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL
                ) unload()
            }
            override fun onConfigurationChanged(newConfig: Configuration) {}
            @Deprecated("Deprecated in Java")
            override fun onLowMemory() { unload() }
        })
    }

    fun blockedReason(): String? {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
                if (pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE) {
                    return "O aparelho está muito quente. Deixe esfriar um pouco e tente de novo."
                }
            } catch (_: Exception) {}
        }
        return null
    }

    private suspend fun ensureLoadedLocked(): Boolean {
        if (loaded.get() && helper != null) return true
        if (!LocalModelManager.get(app).isInstalled()) {
            _state.value = EngineState.Error("Modelo não instalado.")
            return false
        }
        _state.value = EngineState.Loading
        return try {
            withContext(Dispatchers.IO) {
                val loadDone = CompletableDeferred<Boolean>()
                val h = LlamaHelper(app.contentResolver, scope, eventFlow)
                val modelFile = LocalModelManager.get(app).modelFile
                val uri = Uri.fromFile(modelFile).toString()
                val mmproj = LocalModelManager.get(app).mmprojFile
                val mmprojUri = if (mmproj.exists() && mmproj.length() > 1024L) {
                    Uri.fromFile(mmproj).toString()
                } else null

                // Observa eventos de load
                val watch = scope.launch {
                    eventFlow.collect { ev ->
                        when (ev) {
                            is LlamaHelper.LLMEvent.Loaded -> {
                                if (!loadDone.isCompleted) loadDone.complete(true)
                            }
                            is LlamaHelper.LLMEvent.Error -> {
                                if (!loadDone.isCompleted) loadDone.complete(false)
                            }
                            else -> {}
                        }
                    }
                }
                try {
                    h.load(
                        path = uri,
                        contextLength = 1536,
                        mmprojPath = mmprojUri,
                    ) { _ ->
                        if (!loadDone.isCompleted) loadDone.complete(true)
                    }
                    val ok = try {
                        withTimeout(120_000) { loadDone.await() }
                    } catch (_: Throwable) {
                        false
                    }
                    if (!ok) {
                        try { h.release() } catch (_: Throwable) {}
                        _state.value = EngineState.Error("Falha ao carregar o modelo llama.cpp.")
                        return@withContext false
                    }
                    helper = h
                    hasVision = mmprojUri != null
                    loaded.set(true)
                    _state.value = EngineState.Loaded(
                        if (hasVision) "llama.cpp + visão" else "llama.cpp",
                        hasVision,
                    )
                    true
                } finally {
                    watch.cancel()
                }
            }
        } catch (t: Throwable) {
            Log.e(TAG, "ensureLoaded", t)
            loaded.set(false)
            helper = null
            _state.value = EngineState.Error("${t.javaClass.simpleName}: ${t.message ?: "falha ao iniciar"}")
            false
        }
    }

    suspend fun generate(
        system: String,
        history: List<Pair<Boolean, String>>,
        userText: String,
        imagePath: String? = null,
        onPartial: (String) -> Unit = {},
    ): String {
        blockedReason()?.let { throw IllegalStateException(it) }
        val safeSystem = system.take(1800).let {
            if (it.length < system.length) it + "\n[contexto truncado]" else it
        }
        val safeUser = userText.take(700)
        return mutex.withLock {
            idleJob?.cancel()
            if (!ensureLoadedLocked()) {
                throw IllegalStateException(
                    (_state.value as? EngineState.Error)?.message ?: "Modelo indisponível.",
                )
            }
            val h = helper ?: throw IllegalStateException("Modelo indisponível.")
            if (imagePath != null && !hasVision) {
                throw IllegalStateException("Visão local não está disponível neste modelo.")
            }
            try {
                withTimeout(60_000) {
                    withContext(Dispatchers.Default) {
                        val prompt = buildPrompt(safeSystem, history, safeUser)
                        val result = CompletableDeferred<String>()
                        val partial = StringBuilder()

                        val watch = scope.launch {
                            eventFlow.collect { event ->
                                when (event) {
                                    is LlamaHelper.LLMEvent.Ongoing -> {
                                        partial.append(event.word)
                                        onPartial(partial.toString())
                                    }
                                    is LlamaHelper.LLMEvent.Done -> {
                                        val text = event.fullText.ifBlank { partial.toString() }.trim()
                                        if (!result.isCompleted) result.complete(text)
                                    }
                                    is LlamaHelper.LLMEvent.Error -> {
                                        if (!result.isCompleted) {
                                            result.completeExceptionally(
                                                IllegalStateException(event.message),
                                            )
                                        }
                                    }
                                    else -> {}
                                }
                            }
                        }
                        try {
                            if (imagePath != null) {
                                val imgUri = Uri.fromFile(File(imagePath)).toString()
                                h.predict(prompt = prompt, imagePath = imgUri)
                            } else {
                                h.predict(prompt = prompt)
                            }
                            result.await()
                        } finally {
                            watch.cancel()
                        }
                    }
                }
            } catch (t: Throwable) {
                if (t is kotlinx.coroutines.TimeoutCancellationException) {
                    try { helper?.stopPrediction() } catch (_: Throwable) {}
                    throw IllegalStateException("A resposta demorou demais. Tente uma pergunta mais curta.")
                }
                val msg = when {
                    t is OutOfMemoryError ||
                        (t.message?.contains("OutOfMemory", ignoreCase = true) == true) ->
                        "Memória insuficiente. Feche outros apps e tente de novo."
                    t is IllegalStateException -> t.message ?: "Falha ao gerar resposta."
                    else -> "Não consegui gerar a resposta agora (${t.javaClass.simpleName}). Tente de novo."
                }
                throw IllegalStateException(msg, t)
            } finally {
                scheduleIdleUnload()
            }
        }
    }

    private fun buildPrompt(
        system: String,
        history: List<Pair<Boolean, String>>,
        userText: String,
    ): String = buildString {
        // ChatML — compatível com Qwen2.5 e modelos instruct semelhantes
        append("<|im_start|>system\n")
        append(system.trim())
        append("\n<|im_end|>\n")
        for ((fromUser, raw) in history.takeLast(4)) {
            val role = if (fromUser) "user" else "assistant"
            val t = raw.trim().take(280)
            if (t.isEmpty()) continue
            append("<|im_start|>").append(role).append("\n")
            append(t)
            append("\n<|im_end|>\n")
        }
        append("<|im_start|>user\n")
        append(userText.trim())
        append("\n<|im_end|>\n")
        append("<|im_start|>assistant\n")
    }

    suspend fun selfTest(): String = generate(
        system = "Você é um assistente. Responda em português do Brasil, em uma frase curta.",
        history = emptyList(),
        userText = "Quanto é 2 + 3? Responda só com a frase.",
    )

    private fun scheduleIdleUnload() {
        idleJob?.cancel()
        idleJob = scope.launch {
            delay(8 * 60_000L)
            unloadInternal()
        }
    }

    fun unload() { scope.launch { unloadInternal() } }

    private suspend fun unloadInternal() {
        mutex.withLock {
            try {
                helper?.stopPrediction()
                helper?.release()
            } catch (_: Throwable) {}
            helper = null
            loaded.set(false)
            hasVision = false
            if (_state.value !is EngineState.Error) _state.value = EngineState.Unloaded
        }
    }

    companion object {
        private const val TAG = "LocalAiEngine"
        @Volatile private var inst: LocalAiEngine? = null
        fun get(context: Context): LocalAiEngine =
            inst ?: synchronized(this) { inst ?: LocalAiEngine(context).also { inst = it } }
    }
}
