package com.agon.app.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.AppData
import com.agon.app.data.CrisChatLine
import com.agon.app.data.CrisMemory
import com.agon.app.data.CrisPrefs
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Reminder
import com.agon.app.data.formatClock
import com.agon.app.data.formatDateTime
import com.agon.app.data.toMgDl
import com.agon.app.data.uid
import com.agon.app.ui.components.GField
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.roundToInt

internal data class CrisMsg(val fromUser: Boolean, val text: String, val source: String = "")

/** Ação pendente que exige confirmação do usuário antes de alterar dados. */
internal sealed class PendingAction {
    data class CreateReminder(
        val title: String,
        val kind: String,
        val hour: Int,
        val minute: Int,
        val days: List<Int> = listOf(0, 1, 2, 3, 4, 5, 6),
    ) : PendingAction()
}

/**
 * Motor local da Cris IA — sem API na nuvem.
 * Ferramentas: consulta de dados, lembretes (com confirmação), navegação.
 */
internal object CrisBrain {
    const val CLOUD = "__CLOUD__"

    fun reply(
        userText: String,
        data: AppData,
        memory: CrisMemory,
        pending: PendingAction?,
        localOnly: Boolean = false,
    ): Pair<String, PendingAction?> {
        val q = userText.lowercase().trim()
        if (q.length < 2) return "Pode escrever ou falar. Estou ouvindo." to pending

        // Confirmação de ação pendente
        if (pending is PendingAction.CreateReminder) {
            if (q in listOf("sim", "confirmo", "pode", "ok", "isso", "confirma", "pode criar")) {
                return "CONFIRM_CREATE_REMINDER" to pending
            }
            if (q in listOf("não", "nao", "cancela", "cancelar", "desiste")) {
                return "Tudo bem, não criei o lembrete." to null
            }
            return "Para criar o lembrete, responda **sim** para confirmar ou **não** para cancelar.\n\n" +
                "Pendente: ${pending.title} às ${formatClock(pending.hour, pending.minute)} (${if (pending.kind == "glicose") "glicose" else "insulina"})." to pending
        }

        // Segurança clínica
        val doseHints = listOf(
            "qual dose", "quanto de insulina", "calcular dose", "quantas unidades",
            "aumentar dose", "diminuir dose", "posso trocar", "me receita", "me prescreve",
        )
        if (doseHints.any { q.contains(it) }) {
            return ("Entendo a pergunta — e aqui eu preciso ser responsável: não calculo nem altero dose de insulina.\n\n" +
                "Isso só a sua equipe de saúde pode definir. Se quiser, monto um resumo dos seus registros para levar na consulta.") to null
        }
        val emergency = listOf("desmaiei", "desmaiando", "convuls", "dor no peito", "socorro", "emergência", "emergencia")
        if (emergency.any { q.contains(it) }) {
            return "Isso pode ser emergência. Procure ajuda agora — SAMU 192 ou serviço local. Não espere esta conversa." to null
        }

        if (!localOnly && q in listOf("oi", "olá", "ola", "eai", "e aí", "bom dia", "boa tarde", "boa noite", "oie", "opa")) {
            return ("Oi! Que bom te ver por aqui.\n\n" +
                "Pode me contar o que você precisa — registro, lembrete, dúvida sobre insulina, ou só desabafar um pouco o dia.\n\n" +
                "Estou ouvindo.") to null
        }

        // Preferências de memória (não sensíveis)
        when {
            q.contains("resposta curta") || q.contains("fale menos") ->
                return "PREF_SHORT_ON" to null
            q.contains("resposta detalhada") || q.contains("explique mais") || q.contains("fale mais") ->
                return "PREF_SHORT_OFF" to null
            q.contains("lembrar que") && q.contains("prefiro") -> {
                val note = userText.substringAfter("lembrar que", "").trim().take(120)
                if (note.isNotBlank()) return "PREF_NOTE:$note" to null
            }
            q.contains("apagar memória") || q.contains("limpar memória") || q.contains("esquecer preferências") ->
                return "PREF_CLEAR" to null
        }

        // Criar lembrete (coleta → confirmação)
        if (q.contains("criar lembrete") || q.contains("novo lembrete") ||
            (q.contains("lembrete") && (q.contains("para") || q.contains("às") || q.contains("as ")))
        ) {
            val parsed = parseReminderRequest(q, userText)
            if (parsed != null) {
                val action = PendingAction.CreateReminder(parsed.title, parsed.kind, parsed.hour, parsed.minute, parsed.days)
                val daysTxt = parsed.days.sorted().joinToString(", ") { listOf("Dom","Seg","Ter","Qua","Qui","Sex","Sáb")[it] }
                return ("Posso criar este lembrete:\n\n" +
                    "• Título: ${parsed.title}\n" +
                    "• Tipo: ${if (parsed.kind == "glicose") "Medir glicose" else "Aplicar insulina"}\n" +
                    "• Horário: ${formatClock(parsed.hour, parsed.minute)}\n" +
                    "• Dias: $daysTxt\n\n" +
                    "Responda **sim** para confirmar ou **não** para cancelar.") to action
            }
            return ("Para criar um lembrete, diga por exemplo:\n" +
                "“Criar lembrete de glicose às 7:30”\n" +
                "“Novo lembrete de insulina às 21:00”\n\n" +
                "Eu peço confirmação antes de salvar.") to null
        }

        // Consultas e ferramentas
        when {
            q.contains("registro") && (q.contains("glic") || q.contains("meus") || q.contains("minha")) ||
                q.contains("últim") && q.contains("glic") ||
                q.contains("meus registros") || q.contains("minhas glic") ->
                return maybeShort(summarizeGlucose(data), memory) to null

            q.contains("insulina") && (q.contains("últim") || q.contains("registro") || q.contains("apliquei")) ->
                return maybeShort(summarizeInsulin(data), memory) to null

            q.contains("lembrete") ->
                return maybeShort(summarizeReminders(data), memory) to null

            q.contains("resumo") && (q.contains("consulta") || q.contains("médic") || q.contains("medico")) ||
                q.contains("preparar resumo") || q.contains("resumo consulta") ->
                return maybeShort(prepForAppointment(data), memory) to null

            q.contains("encontrar insulina") || q.contains("onde comprar") || q.contains("onde compro") ||
                q.contains("comprar insulina") || q.contains("conseguir insulina") ||
                (q.contains("farmácia") && (q.contains("onde") || q.contains("comprar"))) ||
                q.contains("onde encontrar") || q.contains("pegar insulina") ->
                return (whereToGetInsulin()) to null

            q.contains("localizador") && !q.contains("abrir") && !q.contains("ir para") ->
                return ("O Localizador do app mostra farmácias, postos de saúde e hospitais perto de você, com distância, rota e telefone quando o próprio local publica. " +
                    "Ele não confirma estoque, então vale ligar antes de ir.\n\n" +
                    "Se quiser, me diga sua cidade e o tipo de insulina (NPH, Regular, glargina…) que eu te oriento por onde começar. " +
                    "Ou diga “abrir localizador” que eu abro a tela para você.") to null

            q.contains("o que você lembra") || q.contains("suas preferências") || q.contains("minha memória") ->
                return memoryStatus(memory) to null

            q.contains("resumo da semana") || q.contains("resumo semanal") || q.contains("esta semana") ->
                return maybeShort(weeklySummary(data), memory) to null

            q.contains("consulta em 1 minuto") || q.contains("consulta em um minuto") || q.contains("modo consulta") ->
                return maybeShort(oneMinuteConsult(data), memory) to null

            q.contains("pausar lembrete") || q.contains("desativar lembrete") ->
                return "PAUSE_REMINDER" to null

            q.contains("ativar lembrete") || q.contains("ligar lembrete") ->
                return "ENABLE_REMINDER" to null

            q.contains("abrir glicose") || q.contains("ir para glicose") ->
                return "NAV_GLUCOSE" to null
            q.contains("abrir insulina") || q.contains("ir para insulina") ->
                return "NAV_INSULIN" to null
            q.contains("abrir lembretes") || q.contains("ir para lembretes") ->
                return "NAV_REMINDERS" to null
            q.contains("abrir localizador") || q.contains("ir para localizador") ->
                return "NAV_LOCATOR" to null
            q.contains("abrir relatório") || q.contains("ir para relatório") || q.contains("ir para relatorio") ->
                return "NAV_REPORT" to null
        }

        if (localOnly) return CLOUD to pending

        educational(q)?.let { return maybeShort(it, memory) to null }

        // Conversa geral (IA local aberta) — fora do núcleo diabetes, ainda sem prescrever
        generalChat(q, userText, memory)?.let { return maybeShort(it, memory) to null }

        return ("""
Pode falar comigo normalmente — como com alguém que escuta e responde com clareza.

Sou mais forte em diabetes, glicose, insulina e no que está neste app. Em outros assuntos, converso com honestidade e digo quando algo pede um profissional.

Pode reformular ou me dar um pouco mais de contexto?
        """.trimIndent()) to null
    }

    private fun maybeShort(text: String, memory: CrisMemory): String {
        if (!memory.shortAnswers) return text
        val first = text.split("\n\n").first()
        return first.take(280) + if (text.length > first.length) "\n\n(Modo respostas curtas. Diga “explique mais” para detalhar.)" else ""
    }

    private fun memoryStatus(m: CrisMemory): String {
        return buildString {
            append("Preferências da Cris neste aparelho:\n\n")
            append("• Memória personalizada: ${if (m.memoryEnabled) "ligada" else "desligada"}\n")
            append("• Respostas curtas: ${if (m.shortAnswers) "sim" else "não"}\n")
            append("• Falar respostas: ${if (m.speakReplies) "sim" else "não"}\n")
            if (m.noteToSelf.isNotBlank()) append("• Nota sua: ${m.noteToSelf}\n")
            append("\nDiga “resposta curta”, “explique mais” ou “apagar memória” para alterar.")
        }
    }

    private fun parseReminderRequest(q: String, original: String): ReminderDraft? {
        val kind = when {
            q.contains("insulin") -> "insulina"
            q.contains("glic") -> "glicose"
            else -> "glicose"
        }
        val timeRegex = Regex("""(\d{1,2})[:hH](\d{2})""")
        val timeRegex2 = Regex("""às\s+(\d{1,2})(?:\s*horas?)?""")
        val match = timeRegex.find(q) ?: timeRegex.find(original.lowercase())
        val (h, m) = when {
            match != null -> match.groupValues[1].toInt() to match.groupValues[2].toInt()
            else -> {
                val m2 = timeRegex2.find(q) ?: return null
                m2.groupValues[1].toInt() to 0
            }
        }
        if (h !in 0..23 || m !in 0..59) return null
        val days = parseDays(q)
        val title = if (kind == "glicose") "Lembrete de glicose" else "Lembrete de insulina"
        return ReminderDraft(title, kind, h, m, days)
    }

    private fun parseDays(q: String): List<Int> {
        if (q.contains("útil") || q.contains("util") || q.contains("semana de trabalho")) return listOf(1, 2, 3, 4, 5)
        if (q.contains("fim de semana") || q.contains("sábado e domingo") || q.contains("sabado e domingo")) return listOf(0, 6)
        if (q.contains("todos os dias") || q.contains("todo dia") || q.contains("diariamente")) return listOf(0, 1, 2, 3, 4, 5, 6)
        val map = listOf(
            listOf("domingo", "dom") to 0,
            listOf("segunda", "seg") to 1,
            listOf("terça", "terca", "ter") to 2,
            listOf("quarta", "qua") to 3,
            listOf("quinta", "qui") to 4,
            listOf("sexta", "sex") to 5,
            listOf("sábado", "sabado", "sáb", "sab") to 6,
        )
        val found = mutableListOf<Int>()
        for ((keys, day) in map) {
            if (keys.any { q.contains(it) }) found.add(day)
        }
        return if (found.isEmpty()) listOf(0, 1, 2, 3, 4, 5, 6) else found.distinct().sorted()
    }

    private data class ReminderDraft(val title: String, val kind: String, val hour: Int, val minute: Int, val days: List<Int>)



    /** Conversa aberta local — não é LLM na nuvem; responde com bom senso e limites de segurança. */
    
    /**
     * Conversa aberta com tom profissional + amigável.
     * Não é LLM completo; prioriza naturalidade e honestidade.
     */
    private fun generalChat(q: String, original: String, memory: CrisMemory): String? {
        val risky = listOf(
            "me diagnostica", "tenho câncer", "tenho infarto", "qual remédio tomar",
            "posso parar o remédio", "dose de ", "quantos comprimidos", "me receita",
        )
        if (risky.any { q.contains(it) }) {
            return "Entendo a preocupação — e por isso preciso ser direta com carinho: " +
                "eu não fecho diagnóstico e não indico medicamento nem dose.\n\n" +
                "O caminho seguro é falar com um profissional que te examine e conheça seu histórico.\n\n" +
                "Se quiser, posso te ajudar a organizar o que anotar para a consulta, ou conversar sobre outra coisa."
        }

        if (listOf("estou triste", "to triste", "ansiosa", "ansioso", "cansada", "cansado",
                "estressada", "estressado", "mal hoje", "dia difícil", "desanimada", "desanimado",
                "não aguento", "nao aguento", "ansiedade", "chateada", "chateado").any { q.contains(it) }
        ) {
            return "Obrigada por me contar isso. Dias pesados acontecem, e você não precisa minimizar.\n\n" +
                "Eu posso ficar aqui no papo e também ajudar com coisas práticas do app (registro, lembrete, resumo).\n\n" +
                "Se a tristeza ou a ansiedade estiverem intensas ou frequentes, buscar uma pessoa de confiança ou apoio profissional faz diferença.\n\n" +
                "Quer desabafar um pouco mais ou prefere organizar só uma coisa prática agora?"
        }

        if (listOf("tudo bem", "td bem", "como você está", "como voce esta", "e aí", "eai", "beleza").any { q.contains(it) }) {
            return "Tudo bem por aqui — pronta para te ouvir com atenção.\n\nE você, como está se sentindo hoje?"
        }
        if (listOf("obrigado", "obrigada", "valeu", "agradeço", "muito obrigado", "muito obrigada").any { q.contains(it) }) {
            return "Por nada. Pode voltar quando quiser — estou por aqui ❤️"
        }
        if (listOf("quem é você", "quem e voce", "o que você é", "o que voce e", "é uma ia", "e uma ia", "você é real").any { q.contains(it) }) {
            return "Eu sou a Cris, assistente do Gluco Cris. Converso de forma natural e profissional, " +
                "ajudo com seus registros neste aparelho e com dúvidas de diabetes de forma educativa.\n\n" +
                "Não sou humana e não substituo médica ou terapeuta — mas trato você com respeito e clareza."
        }
        if (listOf("conta uma piada", "me faz rir", "piada").any { q.contains(it) }) {
            return "Uma leve: a glicose abriu um negócio… ficou no ramo alimentício.\n\n" +
                "Se a piada não pegou, sem problema — posso voltar ao modo sério na próxima frase."
        }
        if (q.contains("bom dia")) {
            return "Bom dia ❤️ Espero que seu dia comece com um pouco de calma.\n\nEm que posso te ajudar agora?"
        }
        if (q.contains("boa tarde")) {
            return "Boa tarde. Pode falar comigo à vontade — o que você precisa?"
        }
        if (q.contains("boa noite")) {
            return "Boa noite. Se for uma dúvida rápida ou um lembrete, estou aqui. Descanse quando puder."
        }
        if (listOf("como usar o app", "como funciona o app", "o que o app faz", "ajuda com o app").any { q.contains(it) }) {
            return "Claro. O Gluco Cris organiza glicemias, insulinas, lembretes, gráficos e um localizador de orientação para insulinas.\n\n" +
                "Na tela inicial você encontra mensagens carinhosas, atalho para mim e um resumo da semana.\n\n" +
                "Quer que eu te guie para registrar, criar lembrete ou tirar uma dúvida?"
        }
        if (listOf("você gosta de mim", "voce gosta de mim", "somos amigas", "sua amiga").any { q.contains(it) }) {
            return "Eu estou do seu lado neste app: para conversar, organizar e explicar com respeito.\n\n" +
                "Não sou uma pessoa de verdade, mas pode falar comigo com confiança. O que você precisa agora?"
        }
        if (listOf("estou com medo", "com medo", "preocupada", "preocupado").any { q.contains(it) }) {
            return "Medo e preocupação são sinais de que algo importa para você.\n\n" +
                "Se for sobre glicose ou insulina, podemos olhar os registros ou conversar sobre o que te assusta — sempre no campo educativo.\n\n" +
                "Se for uma emergência (desmaio, dor forte no peito, confusão grave), ligue 192 agora.\n\n" +
                "Quer me contar o que está te preocupando?"
        }

        if (original.trim().length >= 6) {
            return "Estou sem internet agora, então minha conversa fica mais limitada. Mas sigo aqui com você! " +
                "Posso mostrar seus registros, criar um lembrete ou abrir o localizador de insulina. Quando a conexão voltar, a gente conversa sobre qualquer assunto."
        }
        return null
    }

private fun whereToGetInsulin(): String {
        return """
Olha, eu te explico o caminho real — sem inventar farmácia nem telefone.

No Brasil, a insulina costuma vir de três frentes:

1) Rede pública (UBS / farmácia do município ou estado / programas do SUS)
   • Muitas vezes Regular e NPH entram pelo SUS.
   • Análogos (glargina, degludeca, lispro etc.) dependem de protocolo, laudo e regras da sua cidade/estado.
   • Vale ligar na UBS ou na Secretaria de Saúde do seu município e perguntar onde dispensam a sua insulina e quais documentos pedir.

2) Programa Farmácia Popular (quando o item estiver no elenco)
   • Algumas apresentações entram com desconto em farmácias credenciadas.
   • Confirme no portal oficial ou na farmácia se a sua insulina está no programa agora.

3) Farmácia particular
   • Compra com receita, quando exigido.
   • Ligue antes: estoque muda o tempo todo e cada apresentação (caneta, concentração) é diferente.

O que eu não faço: inventar endereço, telefone ou dizer “tem em estoque”. Isso só o estabelecimento confirma.

Me conta: você está em qual cidade/estado e qual insulina (NPH, Regular, Lantus…)? Assim eu te oriento melhor no próximo passo.
Se preferir, diga “abrir localizador” que eu abro a ferramenta do app para filtrar por município.
        """.trimIndent()
    }

    private fun weeklySummary(data: AppData): String {
        val weekMs = 7L * 24 * 60 * 60 * 1000
        val since = System.currentTimeMillis() - weekMs
        val g = data.glucose.filter { it.at >= since }
        val i = data.insulin.filter { it.at >= since }
        if (g.isEmpty() && i.isEmpty()) {
            return "Nesta semana ainda não há glicemias nem insulinas registradas neste aparelho.\n\nQuando houver dados, monto um resumo automático para a consulta."
        }
        val low = data.settings.targetLow
        val high = data.settings.targetHigh
        var inRange = 0
        for (e in g) {
            val mg = toMgDl(e.value, e.unit)
            if (mg >= low && mg <= high) inRange++
        }
        val pct = if (g.isNotEmpty()) (inRange * 100 / g.size) else 0
        val values = g.map { toMgDl(it.value, it.unit) }
        val avg = if (values.isNotEmpty()) values.average().roundToInt() else null
        return buildString {
            append("Resumo dos últimos 7 dias (só dados deste aparelho):\n\n")
            append("• Glicemias: ${g.size}")
            if (avg != null) append(" · média ≈ $avg mg/dL")
            append("\n")
            if (g.isNotEmpty()) append("• Dentro da meta do app ($low–$high): $pct% ($inRange de ${g.size})\n")
            append("• Insulinas registradas: ${i.size}\n")
            append("• Lembretes ativos: ${data.reminders.count { it.enabled }}\n\n")
            append("Isso não é diagnóstico. Leve os padrões que te preocupam para a equipe de saúde.")
        }
    }

    private fun oneMinuteConsult(data: AppData): String {
        val g = data.glucose.sortedByDescending { it.at }.take(8)
        val i = data.insulin.sortedByDescending { it.at }.take(5)
        val r = data.reminders.filter { it.enabled }.sortedWith(compareBy({ it.hour }, { it.minute }))
        return buildString {
            append("Consulta em 1 minuto (dados deste aparelho):\n\n")
            append("Meta no app: ${data.settings.targetLow}–${data.settings.targetHigh} mg/dL\n\n")
            append("Últimas glicemias:\n")
            if (g.isEmpty()) append("• Nenhuma\n") else g.forEach {
                append("• ${toMgDl(it.value, it.unit).roundToInt()} mg/dL · ${GLUCOSE_CONTEXT_LABEL[it.context] ?: it.context} · ${formatDateTime(it.at)}\n")
            }
            append("\nÚltimas insulinas:\n")
            if (i.isEmpty()) append("• Nenhuma\n") else i.forEach {
                append("• ${it.name} ${it.dose} UI · ${formatDateTime(it.at)}\n")
            }
            append("\nLembretes ativos:\n")
            if (r.isEmpty()) append("• Nenhum\n") else r.take(6).forEach {
                append("• ${it.title} ${formatClock(it.hour, it.minute)}\n")
            }
            append("\nPergunte na consulta: minha meta continua boa? há padrão fora da meta? técnica de aplicação ok?")
        }
    }

    private fun summarizeGlucose(data: AppData): String {
        val list = data.glucose.sortedByDescending { it.at }
        if (list.isEmpty()) return "Ainda não há glicemias neste aparelho. Registre pela aba Glicose."
        val latest = list.first()
        val mg = toMgDl(latest.value, latest.unit).roundToInt()
        val recent = list.take(5).joinToString("\n") {
            "• ${toMgDl(it.value, it.unit).roundToInt()} mg/dL · ${GLUCOSE_CONTEXT_LABEL[it.context] ?: it.context} · ${formatDateTime(it.at)}"
        }
        return "Glicemias (dados deste aparelho):\n\nÚltima: $mg mg/dL em ${formatDateTime(latest.at)}\nMeta no app: ${data.settings.targetLow}–${data.settings.targetHigh} mg/dL\n\n$recent\n\nTotal: ${list.size}."
    }

    private fun summarizeInsulin(data: AppData): String {
        val list = data.insulin.sortedByDescending { it.at }
        if (list.isEmpty()) return "Sem registros de insulina neste aparelho."
        val recent = list.take(5).joinToString("\n") {
            "• ${it.name} · ${it.dose} ${it.unit} · ${formatDateTime(it.at)}"
        }
        return "Insulinas registradas:\n\n$recent\n\nTotal: ${list.size}."
    }

    private fun summarizeReminders(data: AppData): String {
        if (data.reminders.isEmpty()) return "Nenhum lembrete. Diga “criar lembrete de glicose às 8:00” ou use a aba Lembretes."
        val lines = data.reminders.sortedWith(compareBy({ it.hour }, { it.minute })).joinToString("\n") {
            val on = if (it.enabled) "ativo" else "pausado"
            "• ${it.title} · ${formatClock(it.hour, it.minute)} · $on"
        }
        return "Seus lembretes:\n\n$lines"
    }

    private fun prepForAppointment(data: AppData): String {
        val lg = data.glucose.maxByOrNull { it.at }
        val li = data.insulin.maxByOrNull { it.at }
        return "Resumo para consulta (só dados deste aparelho):\n\n" +
            "• Glicemias: ${data.glucose.size}\n• Insulinas: ${data.insulin.size}\n" +
            "• Lembretes ativos: ${data.reminders.count { it.enabled }}\n" +
            "• Meta: ${data.settings.targetLow}–${data.settings.targetHigh} mg/dL\n" +
            (lg?.let { "• Última glicemia: ${toMgDl(it.value, it.unit).roundToInt()} mg/dL (${formatDateTime(it.at)})\n" } ?: "") +
            (li?.let { "• Última insulina: ${it.name} ${it.dose} UI (${formatDateTime(it.at)})\n" } ?: "") +
            "\nPerguntas úteis para o profissional: meta adequada? padrões fora da meta? técnica de aplicação?"
    }

    private fun educational(q: String): String? {
        val map = listOf(
            // —— Diabetes: visão geral ——
            listOf("o que é diabetes", "o que e diabetes", "definir diabetes", "diabetes mellitus") to
                "Diabetes mellitus é um conjunto de condições em que o controle da glicose no sangue fica alterado. Isso pode ocorrer por falta de insulina, resistência à insulina ou ambos.\n\n" +
                "Os tipos mais falados no dia a dia são o tipo 1 e o tipo 2; existem outras formas (gestacional, monogênicas etc.). O diagnóstico e o tratamento são sempre da equipe de saúde.\n\n" +
                "Eu explico conceitos. Não fecho diagnóstico.",

            listOf("tipo 1", "diabetes tipo 1", "dm1", "tipo um") to
                "No diabetes tipo 1, o pâncreas produz pouca ou nenhuma insulina, em geral por processo autoimune. Por isso a pessoa costuma depender de insulina todos os dias.\n\n" +
                "O tratamento combina insulina (basal e/ou em torno das refeições, conforme o esquema), educação em diabetes, monitoramento da glicose e acompanhamento multiprofissional.\n\n" +
                "Metas de glicemia e doses são individuais — definidas com a equipe, não pelo app.",

            listOf("tipo 2", "diabetes tipo 2", "dm2", "tipo dois") to
                "No diabetes tipo 2 há resistência à insulina e, com o tempo, a produção de insulina pode diminuir. É mais comum em adultos, mas também ocorre em jovens.\n\n" +
                "O plano pode incluir alimentação, atividade física, medicamentos orais ou injetáveis e, em alguns casos, insulina. Tudo depende da avaliação clínica.\n\n" +
                "Não existe uma única “receita” igual para todo mundo.",

            listOf("diferença tipo 1 e 2", "diferença entre tipo 1", "tipo 1 e tipo 2") to
                "De forma educativa e simplificada:\n\n" +
                "• Tipo 1: pouca/nenhuma insulina; tratamento com insulina é a base.\n" +
                "• Tipo 2: resistência à insulina (± produção reduzida); pode envolver mudanças de hábitos, comprimidos e às vezes insulina.\n\n" +
                "Só a avaliação profissional classifica o seu caso. Não use esta mensagem para se autodiagnosticar.",

            listOf("pré-diabetes", "pre diabetes", "prediabetes", "glicemia de jejum alterada") to
                "Pré-diabetes (termos como glicemia de jejum alterada ou tolerância diminuída à glicose) significa valores acima do desejado, mas ainda sem critério de diabetes no momento da avaliação.\n\n" +
                "Mudanças de hábitos e acompanhamento médico podem reduzir o risco de progressão. Quem define exames e conduta é a equipe de saúde.",

            // —— Glicose / glicemia ——
            listOf("o que é glicose", "o que e glicose", "o que é glicemia", "açúcar no sangue") to
                "Glicose é o principal açúcar que circula no sangue e alimenta as células. Glicemia é a medida dessa glicose.\n\n" +
                "A insulina ajuda a glicose a entrar nas células. Sem insulina suficiente ou com resistência, a glicose tende a subir no sangue.\n\n" +
                "Os alvos ideais variam por pessoa — combine com sua equipe.",

            listOf("jejum", "glicemia de jejum", "em jejum") to
                "Glicemia em jejum é medida após um período sem calorias (em geral 8 horas, conforme orientação do laboratório/equipe).\n\n" +
                "Serve para acompanhamento e, em contexto clínico, para diagnóstico. Interpretação e metas são da equipe — não use um número isolado do app para mudar tratamento.",

            listOf("pós-prandial", "pos prandial", "depois de comer", "após a refeição", "pos-refeicao") to
                "Glicemia pós-prandial é a medida depois da refeição (muitas orientações usam cerca de 2 horas, mas o horário certo é o que sua equipe pediu).\n\n" +
                "Ajuda a entender o efeito da comida e da insulina/medicação no seu esquema. Registre no Gluco Cris com o contexto “depois da refeição” quando fizer sentido.",

            listOf("hba1c", "hemoglobina glicada", "a1c") to
                "A hemoglobina glicada (HbA1c) reflete a média aproximada da glicose ao longo de semanas/meses.\n\n" +
                "É um exame de laboratório, não substitui as medições do dia a dia. A meta de A1c é individual (idade, risco de hipo, comorbidades). Fale com sua equipe sobre a sua meta.",

            listOf("meta de glicose", "alvo de glicemia", "valor ideal", "quanto deve ficar") to
                "Não existe um único “valor ideal” igual para todas as pessoas. Metas consideram tipo de diabetes, idade, risco de hipoglicemia, gestação, outras doenças etc.\n\n" +
                "No Gluco Cris você configura uma faixa de meta para cores e gráficos — isso não substitui a meta clínica combinada com o profissional.",

            // —— Insulina: conceitos ——
            listOf("o que é insulina", "o que e insulina", "para que serve insulina") to
                "Insulina é o hormônio que permite o uso da glicose pelas células e ajuda a controlar a glicemia.\n\n" +
                "Quem tem deficiência importante de insulina precisa repor com insulina prescrita. Existem insulinas humanas (Regular, NPH) e análogos (rápidos e basais), com tempos de ação diferentes.\n\n" +
                "Dose, horário e tipo só mudam com orientação profissional.",

            listOf("nph") to
                "Insulina humana NPH — ação intermediária. Em geral começa a agir em algumas horas, tem pico e duração de várias horas.\n\n" +
                "Costuma ser turva: homogeneíze rolando o frasco/caneta como ensinado, sem agitar com violência. Não troque por outra insulina sem orientação.",

            listOf("regular", "insulina humana regular") to
                "Insulina humana Regular — ação curta. Muitas vezes entra em esquemas pré-refeição ou em uso hospitalar, conforme protocolo.\n\n" +
                "Início, pico e duração variam entre pessoas e situações. Siga a prescrição e a técnica ensinadas.",

            listOf("lispro", "humalog") to
                "Insulina lispro é um análogo de ação rápida/ultrarrápida, em geral usada em torno das refeições no esquema prescrito.\n\n" +
                "Não assuma equivalência automática com outras rápidas ou com a Regular. Marca, concentração e dispositivo importam.",

            listOf("asparte", "novorapid", "novo rapid") to
                "Insulina asparte é análogo de ação rápida/ultrarrápida, tipicamente ligada às refeições conforme a prescrição.\n\n" +
                "Há também formulação em pré-misturas em alguns produtos — cada apresentação tem regra própria na bula e na prescrição.",

            listOf("glulisina", "apidra") to
                "Insulina glulisina é análogo de ação rápida/ultrarrápida. Uso, horário e dose vêm da equipe de saúde.\n\n" +
                "Como todo análogo, não “troque de cabeça” por outra insulina sem orientação.",

            listOf("glargina", "lantus", "toujeo") to
                "Insulina glargina é análogo basal de ação prolongada. Lantus (100 U/mL) e Toujeo (300 U/mL) não são intercambiáveis unidade a unidade sem orientação.\n\n" +
                "Serve, no esquema prescrito, para cobrir necessidade entre refeições e à noite. Não ajuste dose sozinho.",

            listOf("detemir", "levemir") to
                "Insulina detemir é análogo basal. Duração e número de aplicações dependem da prescrição individual.\n\n" +
                "Não substitua por glargina ou degludeca por conta própria.",

            listOf("degludeca", "tresiba") to
                "Insulina degludeca é análogo basal de ação ultralonga. Há apresentações em concentrações diferentes — siga exatamente a prescrita.\n\n" +
                "Flexibilidade de horário, se houver, é definida pelo profissional, não pelo app.",

            listOf("pré-mistura", "pre-mistura", "premista", "novomix", "ryzodeg") to
                "Pré-misturas combinam insulina de ação mais rápida com componente intermediário/basal em proporções fixas.\n\n" +
                "Exigem horários e refeições mais previsíveis em muitos esquemas. Não “monte” mistura em casa sem orientação explícita da equipe.",

            listOf("basal", "bolus", "basal bolus") to
                "Em muitos esquemas:\n• Basal: insulina de ação prolongada que cobre a necessidade entre refeições e à noite.\n• Bolus: insulina rápida/ultrarrápida em torno das refeições ou correções, quando prescrito.\n\n" +
                "A proporção e os horários são individualizados. Eu não calculo bolus nem fator de correção.",

            // —— Hipo / hiper ——
            listOf("hipoglicemia", "hipo", "glicose baixa", "açúcar baixo") to
                "Hipoglicemia é glicose abaixo do alvo da pessoa (muitos materiais citam <70 mg/dL, mas o corte e a conduta são individualizados).\n\n" +
                "Sinais comuns: tremor, suor frio, fome, palpitações, confusão, irritabilidade.\n\n" +
                "Siga o plano de resgate que sua equipe ensinou (ex.: glicose de ação rápida). Se houver confusão grave, convulsão ou inconsciência: emergência — SAMU 192.\n\n" +
                "Anote no app quando possível e discuta padrões na consulta.",

            listOf("hiperglicemia", "hiper", "glicose alta", "açúcar alto") to
                "Hiperglicemia é glicose acima da meta combinada com a equipe. Pode haver sede, urinar muito, cansaço, visão embaçada — ou nenhum sintoma.\n\n" +
                "Causas possíveis: alimentação, doença, estresse, dose insuficiente, técnica de aplicação, medicação esquecida etc.\n\n" +
                "Não aumente insulina por conta própria. Use os registros do Gluco Cris na consulta.",

            listOf("cetoacidose", "cetose", "hhs", "descompensação") to
                "Descompensações graves (como cetoacidose diabética) são emergências médicas: vômitos, dor abdominal, respiração profunda, sonolência, hálito anormal, glicose muito alta etc.\n\n" +
                "Se houver suspeita, procure atendimento imediato. Não tente resolver só com o app.",

            // —— Aplicação e conservação ——
            listOf("aplicar", "aplicação", "onde aplicar", "rodízio", "técnica", "agulha", "caneta") to
                "A técnica correta (local, ângulo, rodízio, troca de agulha, tempo de pressão na caneta) deve ser a ensinada pela equipe.\n\n" +
                "Locais comuns: abdômen, coxa, braço, nádega — conforme orientação. Rodízio reduz nódulos (lipodistrofia).\n\n" +
                "Peça para revisar a técnica no posto ou consultório se tiver dúvida.",

            listOf("conservar", "geladeira", "temperatura", "validade", "viajar com insulina") to
                "Em geral: frascos/canetas não abertos na geladeira, sem congelar. Em uso, muitas apresentações podem ficar em temperatura ambiente por um prazo limitado — leia a bula do seu produto.\n\n" +
                "Não use insulina congelada, vencida ou com aspecto anormal. Em viagens, planeje conservação com a equipe (bolsa térmica, documentação etc.).",

            // —— Dia a dia ——
            listOf("carboidrato", "contagem de carboidrato", "cho") to
                "Carboidratos são o nutriente que mais eleva a glicose após a refeição. A contagem de carboidratos é uma ferramenta usada em alguns esquemas de insulina.\n\n" +
                "Razão insulina/carboidrato e fator de correção são calculados pela equipe — eu não informo quantas unidades tomar.",

            listOf("exercício", "atividade física", "caminhada", "treino") to
                "Atividade física costuma ajudar a saúde e o controle da glicose, mas pode baixar ou, em alguns casos, elevar a glicemia conforme intensidade, insulina “a bordo” e alimentação.\n\n" +
                "Quem usa insulina deve combinar com a equipe quando medir a glicose e como se prevenir de hipoglicemia.",

            listOf("álcool", "alcool", "bebida") to
                "Álcool pode aumentar o risco de hipoglicemia, às vezes horas depois, especialmente em quem usa insulina ou certos antidiabéticos.\n\n" +
                "Não substitua orientação profissional: pergunte na consulta o que é seguro no seu caso.",

            listOf("doente", "gripe", "infecção", "dia de doença") to
                "Em dias de doença a glicose pode subir. Algumas pessoas têm um “plano de dia de doença” combinado com a equipe (mais medições, hidratação, quando procurar emergência).\n\n" +
                "Vômitos persistentes, sonolência intensa ou respiração muito alterada exigem avaliação médica urgente.",

            listOf("pé diabético", "ferida no pé", "cuidado com os pés") to
                "Cuidados com os pés fazem parte da educação em diabetes: inspeção diária, calçados adequados, não andar descalço em locais de risco, avaliar feridas cedo.\n\n" +
                "Qualquer ferida, dor ou mudança de cor no pé merece avaliação profissional — não só “esperar passar”.",

            listOf("retinopatia", "olho", "visão embaçada") to
                "O diabetes pode afetar os olhos (ex.: retinopatia). Visão embaçada também pode ocorrer com glicose muito alta ou baixa no momento.\n\n" +
                "Exames de fundo de olho e intervalos são definidos pela equipe. Mudança súbita de visão: avalie com urgência se orientado.",

            listOf("farmácia popular", "sus", "ubs", "conseguir insulina") to
                "No Brasil, insulinas humanas (Regular/NPH) costumam estar em programas públicos; análogos dependem de protocolo, laudo e regras locais.\n\n" +
                "Use o Localizador do app como orientação e confirme telefone, documentação e estoque no canal oficial (UBS, secretaria, farmácia credenciada).",
            listOf("lipodistrofia", "nódulo", "nodulo", "inchaço no local") to
                "Lipodistrofia são alterações no subcutâneo pelo uso repetido do mesmo local (nódulos ou afundamentos). Podem alterar a absorção da insulina.\n\nRodízio de locais e técnica correta ajudam a prevenir. Mostre à equipe se notar mudanças na pele.",

            listOf("caneta ou frasco", "caneta vs frasco", "diferença caneta") to
                "Canetas facilitam a aplicação e a contagem de unidades; frascos exigem seringa. A insulina em si (princípio e concentração) é o que importa na prescrição.\n\nNão troque dispositivo/concentração sem orientação — 100 U/mL e 200/300 U/mL não são iguais na contagem visual.",

            listOf("primeira consulta", "o que levar na consulta", "endocrino", "endócrino") to
                "Leve: lista de medicamentos/insulinas, registros de glicemia (o Gluco Cris ajuda), dúvidas anotadas, pedidos de exame anteriores e informação sobre hipoglicemias.\n\nUm resumo da semana ou o “modo consulta em 1 minuto” comigo pode organizar a conversa.",

            listOf("gestação", "gravidez", "gestacional") to
                "Diabetes na gestação (pré-existente ou gestacional) exige acompanhamento especializado. Metas e tratamento são específicos.\n\nSe estiver grávida ou planejando, fale com sua equipe — eu só oriento conceitos gerais, sem conduta individual.",
        )
        for ((keys, ans) in map) {
            if (keys.any { q.contains(it) }) {
                return ans + "\n\nSe quiser, pergunta de outro jeito ou me conta o que está te preocupando. (Orientação geral — não substitui sua equipe de saúde.)"
            }
        }
        return null
    }
}

