package com.agon.app.data

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.agon.app.BuildConfig
import com.agon.app.ui.screens.FoodItem
import com.agon.app.ui.screens.loadTacoFoods
import com.agon.app.ui.screens.searchFoodsComplete
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/** Item identificado pela IA (ainda sem nutrientes do catálogo). */
data class VisionDetectedFood(
    val name: String,
    val quantityGrams: Double?,
    val householdMeasure: String?,
    val confidence: Double?,
    val notes: String? = null,
    /** Termo genérico curto (ex.: "biscoito recheado") usado se o nome completo não achar no catálogo. */
    val searchTerm: String? = null,
)

data class VisionAnalysisResult(
    val items: List<VisionDetectedFood>,
    val provider: String,
    val rawNotes: String? = null,
)

/** Item já casado com o banco nutricional do Gluco Cris. */
data class VisionMealLine(
    val id: String,
    val detectedName: String,
    var displayName: String,
    var grams: Double,
    var household: String,
    var confidence: Double?,
    var food: FoodItem?,
    val alternatives: List<FoodItem> = emptyList(),
) {
    fun factor(): Double {
        val base = food?.servingGrams?.takeIf { it > 0 } ?: 100.0
        return grams / base
    }

    fun carbs(): Double = food?.let { it.carbs * factor() } ?: 0.0
    fun kcal(): Double = food?.let { it.kcal * factor() } ?: 0.0
    fun protein(): Double = food?.let { it.protein * factor() } ?: 0.0
    fun fat(): Double = food?.let { it.fat * factor() } ?: 0.0
    fun fiber(): Double = food?.let { it.fiber * factor() } ?: 0.0
    fun sugars(): Double = food?.let { it.sugars * factor() } ?: 0.0
    fun sodium(): Double = food?.let { it.sodium * factor() } ?: 0.0
}

object FoodVisionAi {
    private const val TAG = "FoodVisionAi"

    fun hasGeminiKey(): Boolean = BuildConfig.TAVILY_PROXY_URL.isNotBlank()

    fun providerLabel(): String =
        if (hasGeminiKey()) "Gemini (${BuildConfig.GEMINI_MODEL.ifBlank { "gemini-3.8-flash" }}) via proxy + Open Food Facts"
        else "ML Kit + Open Food Facts (sem chave Gemini)"

    private fun sampleFor(w: Int, h: Int, maxSide: Int): Int {
        var sample = 1
        val max = maxOf(w, h)
        while (max / (sample * 2) >= maxSide) sample *= 2
        return sample
    }

    private fun applyExif(bmp: Bitmap, orientation: Int): Bitmap {
        val m = android.graphics.Matrix()
        when (orientation) {
            android.media.ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
            android.media.ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
            android.media.ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
            android.media.ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
            android.media.ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            android.media.ExifInterface.ORIENTATION_TRANSPOSE -> { m.postRotate(90f); m.postScale(-1f, 1f) }
            android.media.ExifInterface.ORIENTATION_TRANSVERSE -> { m.postRotate(-90f); m.postScale(-1f, 1f) }
            else -> return bmp
        }
        return try {
            Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        } catch (_: Throwable) {
            bmp
        }
    }

    /** Foto da câmera (arquivo JPEG): decodifica reduzida e já na orientação correta. */
    fun decodeFileForAnalysis(path: String, maxSide: Int = 1600): Bitmap? {
        return try {
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            android.graphics.BitmapFactory.decodeFile(path, bounds)
            val opts = android.graphics.BitmapFactory.Options().apply {
                inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, maxSide)
            }
            val bmp = android.graphics.BitmapFactory.decodeFile(path, opts) ?: return null
            val orientation = android.media.ExifInterface(path).getAttributeInt(
                android.media.ExifInterface.TAG_ORIENTATION,
                android.media.ExifInterface.ORIENTATION_NORMAL,
            )
            applyExif(bmp, orientation)
        } catch (e: Throwable) {
            Log.w(TAG, "decodeFile", e)
            null
        }
    }

    /** Foto da galeria: decodifica reduzida e já na orientação correta. */
    fun decodeUriForAnalysis(context: Context, uri: android.net.Uri, maxSide: Int = 1600): Bitmap? {
        return try {
            val bounds = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
            context.contentResolver.openInputStream(uri)?.use {
                android.graphics.BitmapFactory.decodeStream(it, null, bounds)
            }
            val opts = android.graphics.BitmapFactory.Options().apply {
                inSampleSize = sampleFor(bounds.outWidth, bounds.outHeight, maxSide)
            }
            val bmp = context.contentResolver.openInputStream(uri)?.use {
                android.graphics.BitmapFactory.decodeStream(it, null, opts)
            } ?: return null
            val orientation = try {
                context.contentResolver.openInputStream(uri)?.use {
                    android.media.ExifInterface(it).getAttributeInt(
                        android.media.ExifInterface.TAG_ORIENTATION,
                        android.media.ExifInterface.ORIENTATION_NORMAL,
                    )
                } ?: android.media.ExifInterface.ORIENTATION_NORMAL
            } catch (_: Throwable) {
                android.media.ExifInterface.ORIENTATION_NORMAL
            }
            applyExif(bmp, orientation)
        } catch (e: Throwable) {
            Log.w(TAG, "decodeUri", e)
            null
        }
    }

    /**
     * Comprime e redimensiona a imagem antes do envio (economia de cota/custo).
     */
    fun prepareImageBase64(bitmap: Bitmap, maxSide: Int = 1280, quality: Int = 78): String {
        var bmp = bitmap
        val max = maxOf(bmp.width, bmp.height)
        if (max > maxSide) {
            val scale = maxSide.toFloat() / max
            bmp = Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * scale).toInt().coerceAtLeast(1),
                (bmp.height * scale).toInt().coerceAtLeast(1),
                true,
            )
        }
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, baos)
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun analyzeWithGemini(bitmap: Bitmap): VisionAnalysisResult = withContext(Dispatchers.IO) {
        if (BuildConfig.TAVILY_PROXY_URL.isBlank()) error("Proxy Gemini/Tavily não configurado (tavily.proxy.url).")

        val b64 = prepareImageBase64(bitmap)

        val prompt = """
Você é um assistente nutricional para o app brasileiro Gluco Cris (diabetes / contagem de carboidratos).
Identifique TODO alimento, bebida ou produto alimentício visível na foto, cada um separadamente. Pode ser prato
montado, comida solta, fruta, bebida, doce, lanche ou produto de mercado com embalagem (caixa, pacote, garrafa, lata, pote).

Responda APENAS com JSON válido, neste formato:
{
  "items": [
    {
      "name": "nome completo em português; para produto embalado inclua marca e sabor/variação lidos na embalagem",
      "search": "termo genérico curto para buscar no catálogo (ex.: biscoito recheado, refrigerante cola, iogurte natural)",
      "grams": 120,
      "household": "1 concha",
      "confidence": 0.0 a 1.0,
      "notes": "opcional"
    }
  ],
  "notes": "observação geral opcional"
}

Regras:
- LEIA os textos das embalagens (marca, sabor, peso/volume líquido) e use isso para nomear e estimar grams.
  Se a embalagem mostra o peso/volume (ex.: 350 ml, 200 g), use esse valor em grams (ml ≈ g para bebidas).
- Separe itens misturados (arroz, feijão, carne, salada etc.) e cada produto diferente em itens distintos.
- Se houver vários produtos iguais, um item só, com household indicando a quantidade (ex.: "3 unidades").
- grams é ESTIMATIVA; se incerto use null e explique em notes.
- Não invente o que não aparece; mas não deixe de listar o que está visível, mesmo parcialmente ou em segundo plano.
- Prefira nomes comuns no Brasil (arroz branco cozido, feijão carioca, frango grelhado...).
- Só use items: [] se não houver nenhum alimento, bebida ou produto alimentício na imagem.
- Precisão: copie marca, sabor e peso exatamente como estão impressos; não troque por nome parecido. Seja breve: sem texto fora do JSON, "notes" só se for necessário.
""".trimIndent()

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray()
                            .put(JSONObject().put("text", prompt))
                            .put(
                                JSONObject().put(
                                    "inline_data",
                                    JSONObject()
                                        .put("mime_type", "image/jpeg")
                                        .put("data", b64),
                                ),
                            ),
                    ),
                ),
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.1)
                    .put("responseMimeType", "application/json")
                    .put("maxOutputTokens", 2048)
                    // Ler a imagem não precisa de raciocínio longo: resposta mais rápida
                    .put("thinkingConfig", JSONObject().put("thinkingBudget", 0)),
            )

        var (code, resp) = CrisGemini.postWithFallback(body.toString(), 10_000, 30_000)
        if (code == 400 && body.has("generationConfig")) {
            // Modelo não aceitou "thinkingConfig": repete sem ele
            body.getJSONObject("generationConfig").remove("thinkingConfig")
            val again = CrisGemini.postWithFallback(body.toString(), 10_000, 30_000)
            code = again.first; resp = again.second
        }
        if (code !in 200..299) {
            Log.w(TAG, "Gemini proxy HTTP $code: ${resp.take(400)}")
            error(parseGeminiError(resp, code))
        }

        val text = extractGeminiText(resp)
        parseVisionJson(text, "Gemini")
    }

    private fun parseGeminiError(resp: String, code: Int): String {
        return try {
            val msg = JSONObject(resp).optJSONObject("error")?.optString("message")
            when {
                code == 429 -> "Limite de uso da API atingido. Tente mais tarde."
                code == 403 -> "Chave Gemini inválida ou sem permissão."
                !msg.isNullOrBlank() -> "Erro da IA: $msg"
                else -> "Erro HTTP $code na API Gemini."
            }
        } catch (_: Exception) {
            "Erro HTTP $code na API Gemini."
        }
    }

    private fun extractGeminiText(resp: String): String {
        val root = JSONObject(resp)
        val candidates = root.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            sb.append(parts.getJSONObject(i).optString("text"))
        }
        return sb.toString().trim()
    }

    private fun parseVisionJson(text: String, provider: String): VisionAnalysisResult {
        var cleaned = text.trim()
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.removePrefix("```json").removePrefix("```JSON").removePrefix("```").trim()
            if (cleaned.endsWith("```")) cleaned = cleaned.dropLast(3).trim()
        }
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        if (start < 0 || end <= start) return VisionAnalysisResult(emptyList(), provider, "Resposta sem JSON")
        val obj = JSONObject(cleaned.substring(start, end + 1))
        val arr = obj.optJSONArray("items") ?: JSONArray()
        val items = mutableListOf<VisionDetectedFood>()
        for (i in 0 until arr.length()) {
            val it = arr.getJSONObject(i)
            val name = it.optString("name", "").trim()
            if (name.isBlank()) continue
            val grams = if (it.has("grams") && !it.isNull("grams")) it.optDouble("grams") else null
            items.add(
                VisionDetectedFood(
                    name = name,
                    quantityGrams = grams?.takeIf { it > 0 },
                    householdMeasure = it.optString("household", "").ifBlank { null },
                    confidence = if (it.has("confidence")) it.optDouble("confidence") else null,
                    notes = it.optString("notes", "").ifBlank { null },
                    searchTerm = it.optString("search", "").trim().ifBlank { null },
                ),
            )
        }
        return VisionAnalysisResult(
            items = items,
            provider = provider,
            rawNotes = obj.optString("notes", "").ifBlank { null },
        )
    }


    /**
     * Fallback sem Gemini: rótulos ML Kit → nomes de alimentos → depois o catálogo OFF/local.
     */
    suspend fun analyzeWithMlKitLabels(bitmap: Bitmap): VisionAnalysisResult = withContext(Dispatchers.IO) {
        try {
            val labeler = com.google.mlkit.vision.label.ImageLabeling.getClient(
                com.google.mlkit.vision.label.defaults.ImageLabelerOptions.DEFAULT_OPTIONS,
            )
            val image = com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap, 0)
            val labels = com.google.android.gms.tasks.Tasks.await(labeler.process(image))
            labeler.close()
            val generic = setOf(
                "food", "cuisine", "dish", "ingredient", "tableware", "plate", "recipe", "meal", "produce",
                "cooking", "staple food", "comfort food", "fast food", "junk food", "finger food", "drink",
                "bowl", "table", "dishware", "serveware", "kitchen", "snack", "baked goods", "natural foods",
                "whole food", "local food", "superfood", "leaf vegetable", "vegetable", "fruit",
            )
            val pt = mapOf(
                "apple" to "maçã", "banana" to "banana", "orange" to "laranja", "bread" to "pão",
                "rice" to "arroz", "egg" to "ovo", "cheese" to "queijo", "pizza" to "pizza", "cake" to "bolo",
                "salad" to "salada", "tomato" to "tomate", "potato" to "batata", "milk" to "leite",
                "coffee" to "café", "juice" to "suco", "chicken" to "frango", "beef" to "carne bovina",
                "fish" to "peixe", "pasta" to "macarrão", "noodle" to "macarrão", "sandwich" to "sanduíche",
                "hamburger" to "hambúrguer", "cookie" to "biscoito", "biscuit" to "biscoito", "chocolate" to "chocolate",
                "strawberry" to "morango", "grape" to "uva", "lemon" to "limão", "carrot" to "cenoura",
                "beans" to "feijão", "bean" to "feijão", "soup" to "sopa", "yogurt" to "iogurte", "ice cream" to "sorvete",
                "soft drink" to "refrigerante", "soda" to "refrigerante", "water" to "água", "beer" to "cerveja",
                "wine" to "vinho", "cereal" to "cereal", "oat" to "aveia", "corn" to "milho", "mango" to "manga",
                "papaya" to "mamão", "watermelon" to "melancia", "pineapple" to "abacaxi", "avocado" to "abacate",
            )
            val foodish = labels
                .filter { it.confidence >= 0.45f }
                .filter { it.text.trim().lowercase() !in generic }
                .map { pt[it.text.trim().lowercase()] ?: it.text.trim() }
                .filter { it.length in 3..40 }
                .distinct()
                .take(8)
            if (foodish.isEmpty()) {
                return@withContext VisionAnalysisResult(
                    emptyList(),
                    "ML Kit + OFF",
                    "Não foi possível rotular alimentos na foto. Tente outra imagem ou configure Gemini.",
                )
            }
            val items = foodish.map { name ->
                VisionDetectedFood(
                    name = name,
                    quantityGrams = 100.0,
                    householdMeasure = "100 g (estimativa)",
                    confidence = 0.6,
                    notes = "Rótulo ML Kit; nutrientes vêm do catálogo OFF/local",
                )
            }
            VisionAnalysisResult(items, "ML Kit + Open Food Facts", null)
        } catch (e: Exception) {
            Log.w(TAG, "ML Kit labels", e)
            VisionAnalysisResult(
                emptyList(),
                "ML Kit + OFF",
                e.message ?: "Falha no reconhecimento local da imagem.",
            )
        }
    }

    /**
     * Preferência: Gemini → se falhar ou sem chave, ML Kit + match no Open Food Facts/local.
     */
    suspend fun analyzePlate(bitmap: Bitmap): VisionAnalysisResult {
        if (hasGeminiKey()) {
            return try {
                analyzeWithGemini(bitmap)
            } catch (e: Exception) {
                Log.w(TAG, "Gemini falhou, fallback ML Kit/OFF", e)
                val fb = analyzeWithMlKitLabels(bitmap)
                if (fb.items.isEmpty()) {
                    VisionAnalysisResult(
                        emptyList(),
                        "Gemini falhou → OFF",
                        (e.message ?: "Gemini indisponível") + " · " + (fb.rawNotes ?: ""),
                    )
                } else fb.copy(provider = "Fallback: ML Kit + Open Food Facts", rawNotes = e.message)
            }
        }
        return analyzeWithMlKitLabels(bitmap)
    }

    /**
     * Quando o código de barras não está no Open Food Facts, tenta Gemini (texto) para sugerir o produto.
     * Nutrientes só se a IA devolver números; senão null.
     */
    suspend fun lookupBarcodeWithGemini(code: String): FoodItem? = withContext(Dispatchers.IO) {
        if (BuildConfig.TAVILY_PROXY_URL.isBlank()) return@withContext null
        try {
            val prompt = """
Código de barras (EAN/UPC): $code
Pesquise esse código no Google e identifique o produto alimentício (marca, nome, sabor, peso). Se não encontrar com segurança, não chute.
Responda APENAS JSON:
{"name":"...","brand":"...","kcal_100g":0,"carbs_100g":0,"protein_100g":0,"fat_100g":0,"serving":"100 g"}
Se não souber com segurança, responda: {"name":""}
Não invente valores nutricionais se não tiver base.
""".trimIndent()
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("temperature", 0.1).put("maxOutputTokens", 600).put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))
                .put("tools", JSONArray().put(JSONObject().put("google_search", JSONObject())))
            var (codeHttp, resp) = CrisGemini.postWithFallback(body.toString(), 10_000, 25_000)
            if (codeHttp == 400) {
                // Pedido com pesquisa/raciocínio recusado: repete simples
                body.remove("tools")
                body.getJSONObject("generationConfig").remove("thinkingConfig")
                val again = CrisGemini.postWithFallback(body.toString(), 10_000, 20_000)
                codeHttp = again.first; resp = again.second
            }
            if (codeHttp !in 200..299) return@withContext null
            val text = extractGeminiText(resp)
            val jsonStr = text.substringAfter("{").substringBeforeLast("}").let { "{$it}" }
            val o = JSONObject(jsonStr)
            val name = o.optString("name", "").trim()
            if (name.isBlank()) return@withContext null
            val kcal = o.optDouble("kcal_100g", 0.0)
            val carbs = o.optDouble("carbs_100g", 0.0)
            FoodItem(
                id = "bc-gemini-$code",
                name = name,
                brand = o.optString("brand", ""),
                serving = o.optString("serving", "100 g").ifBlank { "100 g" },
                servingGrams = 100.0,
                kcal = kcal,
                kj = kcal * 4.184,
                carbs = carbs,
                protein = o.optDouble("protein_100g", 0.0),
                fat = o.optDouble("fat_100g", 0.0),
                source = "Gemini (código não achado no OFF)",
                sourceKey = "gemini",
                isGeneric = true,
                reliability = "estimada",
                category = "",
            )
        } catch (e: Exception) {
            Log.w(TAG, "barcode Gemini", e)
            null
        }
    }

    /**
     * Casa cada item detectado com o catálogo do app (searchFoodsComplete).
     * Não inventa nutrientes: se não achar, food fica null.
     */
    suspend fun matchToCatalog(
        context: Context,
        analysis: VisionAnalysisResult,
    ): List<VisionMealLine> = withContext(Dispatchers.IO) {
        val taco = loadTacoFoods(context)
        analysis.items.mapIndexed { index, det ->
            val queries = buildList {
                add(det.name)
                det.searchTerm?.let { add(it) }
                val words = det.name.split(" ").filter { it.isNotBlank() }
                if (words.size > 2) add(words.take(2).joinToString(" "))
            }.distinctBy { it.lowercase() }
            var results: List<FoodItem> = emptyList()
            for (q in queries) {
                results = try {
                    searchFoodsComplete(context, q, taco).take(8)
                } catch (_: Exception) {
                    emptyList()
                }
                if (results.isNotEmpty()) break
            }
            val best = results.firstOrNull()
            val grams = det.quantityGrams
                ?: best?.servingGrams?.takeIf { it > 0 }
                ?: 100.0
            VisionMealLine(
                id = "vision-$index-${det.name.hashCode()}",
                detectedName = det.name,
                displayName = best?.name ?: det.name,
                grams = grams,
                household = det.householdMeasure
                    ?: best?.serving
                    ?: "${grams.roundToInt()} g",
                confidence = det.confidence,
                food = best,
                alternatives = results.drop(1).take(5),
            )
        }
    }
}
