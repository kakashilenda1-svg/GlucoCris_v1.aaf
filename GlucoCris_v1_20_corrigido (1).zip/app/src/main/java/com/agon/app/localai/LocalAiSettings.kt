package com.agon.app.localai

import android.content.Context

/**
 * Preferências da IA local (SharedPreferences privado, lido de forma síncrona).
 * Padrões conservadores: nada de dados de saúde ou texto de respostas sai do aparelho sem autorização.
 */
object LocalAiSettings {
    private const val FILE = "cris_localai_settings"
    private fun p(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    /** Usa o modelo local quando ele estiver instalado. */
    fun enabled(c: Context): Boolean = p(c).getBoolean("enabled", true)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()

    /** Voz natural da nuvem (envia o texto da resposta ao servidor). Padrão: desligado. */
    fun cloudVoiceAllowed(c: Context): Boolean = p(c).getBoolean("cloud_voice", false)
    fun setCloudVoiceAllowed(c: Context, v: Boolean) = p(c).edit().putBoolean("cloud_voice", v).apply()

    /** Permite enviar o resumo de glicemia/insulina/alimentação a serviços online (Gemini/servidor). Padrão: desligado. */
    fun onlineHealthContextAllowed(c: Context): Boolean = p(c).getBoolean("online_health", false)
    fun setOnlineHealthContextAllowed(c: Context, v: Boolean) = p(c).edit().putBoolean("online_health", v).apply()

    /** Id do modelo cujo download a usuária autorizou. */
    fun consentedModel(c: Context): String = p(c).getString("consent_model", "") ?: ""
    fun setConsentedModel(c: Context, id: String) = p(c).edit().putString("consent_model", id).apply()

    /** Pesquisa online automática como ferramenta da Cris (a IA local continua respondendo). Padrão: ligada. */
    fun webSearchEnabled(c: Context): Boolean = p(c).getBoolean("web_search", true)
    fun setWebSearchEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("web_search", v).apply()

    /** Pesquisa geral (Tavily) disponível: o APK foi gerado com o endereço do proxy. A chave da Tavily NÃO fica no app. */
    fun tavilyAvailable(c: Context): Boolean = TavilySearch.isConfigured()

    /** A pergunta "baixar a IA local?" da primeira abertura já foi respondida (sim ou não). */
    fun downloadOfferAnswered(c: Context): Boolean = p(c).getBoolean("download_offer_answered", false)
    fun setDownloadOfferAnswered(c: Context, v: Boolean) = p(c).edit().putBoolean("download_offer_answered", v).apply()

    /** Mantém o download da IA local em segundo plano (serviço com notificação). Padrão: ligado. */
    fun backgroundDownload(c: Context): Boolean = p(c).getBoolean("bg_download", true)
    fun setBackgroundDownload(c: Context, v: Boolean) = p(c).edit().putBoolean("bg_download", v).apply()


    /** Estilo de resposta: "direct" (1–3 frases) ou "explain" (mais detalhe). */
    fun answerStyle(c: Context): String = p(c).getString("answer_style", "direct") ?: "direct"
    fun setAnswerStyle(c: Context, v: String) = p(c).edit().putString("answer_style", v).apply()
    fun isDirectStyle(c: Context): Boolean = answerStyle(c) != "explain"

    /** Modelo escolhido (id do LocalModels). Vazio = DEFAULT. */
    fun selectedModelId(c: Context): String = p(c).getString("selected_model", "") ?: ""
    fun setSelectedModelId(c: Context, id: String) = p(c).edit().putString("selected_model", id).apply()

}
