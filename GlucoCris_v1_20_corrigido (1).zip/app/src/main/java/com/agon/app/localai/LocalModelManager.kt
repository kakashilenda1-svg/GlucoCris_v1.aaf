package com.agon.app.localai

import android.content.Context
import android.os.StatFs
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import kotlin.coroutines.coroutineContext

/** Modelo local GGUF (llama.cpp). Tamanho conferido no repositório Hugging Face. */
data class LocalModelSpec(
    val id: String,
    val displayName: String,
    val fileName: String,
    val url: String,
    val sizeBytes: Long,
    val sha256: String,
    val license: String,
)

object LocalModels {
    /** Rápida: ~1,04 GB — ideal no dia a dia. */
    val QWEN25_1_5B = LocalModelSpec(
        id = "qwen2.5-1.5b-instruct-q4_k_m",
        displayName = "Rápida · Qwen2.5 1.5B",
        fileName = "qwen2.5-1.5b-instruct-q4_k_m.gguf",
        url = "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf",
        sizeBytes = 1_117_320_736L,
        sha256 = "",
        license = "Apache-2.0 (Qwen)",
    )
    /** Precisa: ~1,9 GB — mais qualidade, um pouco mais lenta. */
    val QWEN25_3B = LocalModelSpec(
        id = "qwen2.5-3b-instruct-q4_k_m",
        displayName = "Precisa · Qwen2.5 3B",
        fileName = "qwen2.5-3b-instruct-q4_k_m.gguf",
        url = "https://huggingface.co/Qwen/Qwen2.5-3B-Instruct-GGUF/resolve/main/qwen2.5-3b-instruct-q4_k_m.gguf",
        sizeBytes = 2_104_932_768L,
        sha256 = "",
        license = "Apache-2.0 (Qwen)",
    )
    val DEFAULT = QWEN25_1_5B
    val ALL = listOf(QWEN25_1_5B, QWEN25_3B)
    fun byId(id: String): LocalModelSpec = ALL.firstOrNull { it.id == id } ?: DEFAULT
}

sealed interface ModelState {
    data object Missing : ModelState
    data class Downloading(val done: Long, val total: Long) : ModelState
    data class Paused(val done: Long, val total: Long) : ModelState
    data class Failed(val message: String, val done: Long, val total: Long) : ModelState
    data object Verifying : ModelState
    data object Ready : ModelState
}

/**
 * Baixa, verifica e guarda o modelo em diretório privado do app (noBackupFilesDir: fora do backup automático,
 * preservado em atualizações do app). Download só começa por chamada explícita de [start] (após consentimento).
 */
class LocalModelManager private constructor(context: Context) {
    private val app = context.applicationContext
    val spec: LocalModelSpec
        get() {
            val id = LocalAiSettings.selectedModelId(app).ifBlank { LocalModels.DEFAULT.id }
            return LocalModels.byId(id)
        }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    @Volatile private var activeConn: HttpURLConnection? = null

    private val _state = MutableStateFlow<ModelState>(ModelState.Missing)
    val state: StateFlow<ModelState> = _state.asStateFlow()

    private val dir: File get() = File(app.noBackupFilesDir, "localai/models").apply { mkdirs() }
    val modelFile: File get() = File(dir, spec.fileName)
    /** Projetor multimodal opcional (mmproj) para visão via llama.cpp. */
    val mmprojFile: File get() = File(dir, "mmproj-" + spec.id + ".gguf")
    private val partFile: File get() = File(dir, spec.fileName + ".part")

    init { refresh() }

    /** Reavalia o estado a partir do disco (chamar ao abrir a tela). */
    fun refresh() {
        if (_state.value is ModelState.Downloading || _state.value is ModelState.Verifying) return
        _state.value = when {
            modelFile.exists() && modelFile.length() == spec.sizeBytes -> ModelState.Ready
            partFile.exists() && partFile.length() > 0 -> ModelState.Paused(partFile.length(), spec.sizeBytes)
            else -> ModelState.Missing
        }
    }

    fun isInstalled(): Boolean = modelFile.exists() && modelFile.length() == spec.sizeBytes

    fun freeBytes(): Long = try { StatFs(dir.path).availableBytes } catch (_: Exception) { 0L }

    /** Bytes que ainda precisam ser baixados + margem de 400 MB para o motor llama.cpp. */
    fun requiredFreeBytes(): Long {
        val have = if (partFile.exists()) partFile.length() else 0L
        return (spec.sizeBytes - have).coerceAtLeast(0L) + 400L * 1024 * 1024
    }

    fun hasEnoughSpace(): Boolean = freeBytes() >= requiredFreeBytes()

    /** Inicia ou retoma o download. Só deve ser chamado depois da autorização da usuária. */
    fun start() {
        if (job?.isActive == true || isInstalled()) return
        LocalAiSettings.setConsentedModel(app, spec.id)
        job = scope.launch { runDownload() }
        if (LocalAiSettings.backgroundDownload(app)) ModelDownloadService.begin(app)
    }

    fun pause() {
        job?.cancel()
        try { activeConn?.disconnect() } catch (_: Exception) {}
        val d = if (partFile.exists()) partFile.length() else 0L
        _state.value = ModelState.Paused(d, spec.sizeBytes)
    }

    /** Remove o modelo e o download parcial (a usuária pode reinstalar depois). */
    fun delete() {
        job?.cancel()
        try { activeConn?.disconnect() } catch (_: Exception) {}
        LocalAiEngine.get(app).unload()
        modelFile.delete()
        partFile.delete()
        _state.value = ModelState.Missing
    }

    private suspend fun runDownload() {
        val total = spec.sizeBytes
        try {
            if (freeBytes() < requiredFreeBytes()) {
                _state.value = ModelState.Failed("Espaço insuficiente. Libere pelo menos ${fmtBytes(requiredFreeBytes())}.", partLen(), total)
                return
            }
            var existing = partLen()
            _state.value = ModelState.Downloading(existing, total)

            if (existing < total) {
                val conn = openWithRedirects(spec.url, existing)
                activeConn = conn
                try {
                    val code = conn.responseCode
                    when {
                        code == 206 -> {}
                        code == 200 -> { partFile.delete(); existing = 0L }   // servidor ignorou o Range: recomeça
                        code == 416 -> { partFile.delete(); existing = 0L; throw IllegalStateException("Retomada recusada pelo servidor; tente de novo.") }
                        else -> throw IllegalStateException("Servidor respondeu HTTP $code.")
                    }
                    RandomAccessFile(partFile, "rw").use { raf ->
                        raf.seek(existing)
                        var done = existing
                        val buf = ByteArray(256 * 1024)
                        var lastEmit = 0L
                        conn.inputStream.use { input ->
                            while (true) {
                                if (!coroutineContext.isActive) return
                                val n = input.read(buf)
                                if (n < 0) break
                                raf.write(buf, 0, n)
                                done += n
                                val now = System.currentTimeMillis()
                                if (now - lastEmit > 300) {
                                    lastEmit = now
                                    _state.value = ModelState.Downloading(done, total)
                                }
                            }
                        }
                    }
                } finally {
                    try { conn.disconnect() } catch (_: Exception) {}
                    activeConn = null
                }
            }

            if (!coroutineContext.isActive) return
            if (partLen() != total) {
                _state.value = ModelState.Failed("Download incompleto (${fmtBytes(partLen())} de ${fmtBytes(total)}). Toque em continuar.", partLen(), total)
                return
            }

            _state.value = ModelState.Verifying
            if (spec.sha256.isNotBlank()) {
                val hash = sha256(partFile)
                if (!hash.equals(spec.sha256, ignoreCase = true)) {
                    partFile.delete()
                    _state.value = ModelState.Failed(
                        "A verificação de integridade falhou (arquivo corrompido). O download parcial foi apagado; tente de novo.",
                        0L,
                        total,
                    )
                    return
                }
            }
            modelFile.delete()
            if (!partFile.renameTo(modelFile)) {
                _state.value = ModelState.Failed("Não consegui instalar o arquivo no armazenamento privado.", 0L, total)
                return
            }
            // Remove modelo antigo LiteRT se existir (migração Gemma → llama.cpp)
            try {
                File(dir, "gemma-4-E2B-it.litertlm").delete()
            } catch (_: Exception) {}
            _state.value = ModelState.Ready
        } catch (e: kotlinx.coroutines.CancellationException) {
            _state.value = ModelState.Paused(partLen(), total)
            throw e
        } catch (e: Exception) {
            if (!coroutineContext.isActive) {            // pausa pedida pela usuária (a conexão foi fechada)
                _state.value = ModelState.Paused(partLen(), total)
                return
            }
            _state.value = ModelState.Failed(
                (e.message ?: "Falha de conexão") + " O que já foi baixado foi mantido; toque em continuar.",
                partLen(), total,
            )
        }
    }

    private fun partLen(): Long = if (partFile.exists()) partFile.length() else 0L

    /** Segue redirecionamentos manualmente para manter o cabeçalho Range (o Hugging Face redireciona para um CDN). */
    private fun openWithRedirects(start: String, from: Long): HttpURLConnection {
        var url = start
        repeat(6) {
            val c = URL(url).openConnection() as HttpURLConnection
            c.instanceFollowRedirects = false
            c.connectTimeout = 20_000
            c.readTimeout = 30_000
            c.setRequestProperty("User-Agent", "GlucoCris/1.0 (Android)")
            if (from > 0) c.setRequestProperty("Range", "bytes=$from-")
            val code = c.responseCode
            if (code in intArrayOf(301, 302, 303, 307, 308)) {
                val loc = c.getHeaderField("Location") ?: throw IllegalStateException("Redirecionamento sem destino.")
                url = URL(URL(url), loc).toString()
                c.disconnect()
            } else {
                return c
            }
        }
        throw IllegalStateException("Redirecionamentos demais.")
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins ->
            val buf = ByteArray(1024 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    companion object {
        @Volatile private var inst: LocalModelManager? = null
        fun get(context: Context): LocalModelManager =
            inst ?: synchronized(this) { inst ?: LocalModelManager(context).also { inst = it } }

        fun fmtBytes(b: Long): String = when {
            b >= 1L shl 30 -> "%.2f GB".format(b / (1024.0 * 1024.0 * 1024.0))
            b >= 1L shl 20 -> "%.0f MB".format(b / (1024.0 * 1024.0))
            else -> "$b B"
        }
    }
}
