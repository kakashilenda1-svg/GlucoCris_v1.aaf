package com.agon.app.ui.screens

import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.agon.app.localai.LocalAiSettings
import com.agon.app.localai.LocalModelManager
import com.agon.app.localai.ModelState

/**
 * Pergunta única, na primeira abertura, se a pessoa autoriza baixar a IA local.
 * Sim: inicia o download (e abre a tela com o progresso). Não: nada é baixado; a pessoa pode baixar depois
 * tocando no status sob o nome "Cris" no chat > Baixar IA local.
 */
@Composable
fun CrisLocalAiOfferDialog(onAccepted: () -> Unit) {
    val context = LocalContext.current
    val mgr = remember { LocalModelManager.get(context) }
    val state by mgr.state.collectAsState()
    var show by remember {
        mutableStateOf(!LocalAiSettings.downloadOfferAnswered(context) && !mgr.isInstalled() && state is ModelState.Missing)
    }
    if (!show) return

    val size = LocalModelManager.fmtBytes(mgr.spec.sizeBytes)
    AlertDialog(
        onDismissRequest = {
            LocalAiSettings.setDownloadOfferAnswered(context, true)
            show = false
        },
        title = { Text("Baixar a IA da Cris?") },
        text = {
            Text(
                "Para a Cris conversar sobre qualquer assunto, até sem internet, o aparelho precisa baixar a IA local (" + size + "). " +
                    "Use Wi-Fi e mantenha o app aberto durante o download. " +
                    "Você pode pausar ou apagar quando quiser.\n\n" +
                    "Se escolher agora não, tudo bem: depois é só tocar no texto de status embaixo do nome Cris, no chat, e escolher Baixar IA local.",
            )
        },
        confirmButton = {
            TextButton(onClick = {
                LocalAiSettings.setDownloadOfferAnswered(context, true)
                show = false
                mgr.start()
                onAccepted()
            }) { Text("Sim, baixar") }
        },
        dismissButton = {
            TextButton(onClick = {
                LocalAiSettings.setDownloadOfferAnswered(context, true)
                show = false
            }) { Text("Agora não") }
        },
    )
}
