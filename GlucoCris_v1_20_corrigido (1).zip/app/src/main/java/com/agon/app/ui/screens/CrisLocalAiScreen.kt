package com.agon.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.data.CrisPrefs
import com.agon.app.localai.CrisConnectivityManager
import com.agon.app.localai.CrisFact
import com.agon.app.localai.CrisConversationStore
import com.agon.app.localai.CrisWebSearch
import com.agon.app.localai.EngineState
import com.agon.app.localai.LocalAiEngine
import com.agon.app.localai.LocalAiSettings
import com.agon.app.localai.LocalMemoryManager
import com.agon.app.localai.LocalModelManager
import com.agon.app.localai.LocalModels
import java.io.File
import com.agon.app.localai.LocalSpeech
import com.agon.app.localai.ModelState
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.launch

/** Configurações da IA local: modelo (download/pausa/retomada/apagar), privacidade, memória e voz. */
@Composable
fun CrisLocalAiScreen(nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val mgr = remember { LocalModelManager.get(context) }
    val engine = remember { LocalAiEngine.get(context) }
    val state by mgr.state.collectAsState()
    val engineState by engine.state.collectAsState()
    val online by remember { CrisConnectivityManager.observe(context) }
        .collectAsState(initial = CrisConnectivityManager.isOnline(context))

    var enabled by remember { mutableStateOf(LocalAiSettings.enabled(context)) }
    var cloudVoice by remember { mutableStateOf(LocalAiSettings.cloudVoiceAllowed(context)) }
    var onlineHealth by remember { mutableStateOf(LocalAiSettings.onlineHealthContextAllowed(context)) }
    var webSearch by remember { mutableStateOf(LocalAiSettings.webSearchEnabled(context)) }
    var webTesting by remember { mutableStateOf(false) }
    var webTestResult by remember { mutableStateOf<String?>(null) }
    var facts by remember { mutableStateOf(LocalMemoryManager.load(context)) }
    var showConsent by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var editing by remember { mutableStateOf<CrisFact?>(null) }
    var adding by remember { mutableStateOf(false) }
    var confirmClearAll by remember { mutableStateOf(false) }
    var historyCleared by remember { mutableStateOf(false) }
    var wasVerifying by remember { mutableStateOf(false) }

    fun runTest() {
        if (testing) return
        testing = true
        testResult = null
        scope.launch {
            testResult = try {
                "Funcionou. Resposta do modelo: " + engine.selfTest().trim().take(200)
            } catch (e: Exception) {
                "Falhou: ${e.message ?: "erro desconhecido"}"
            }
            testing = false
        }
    }

    LaunchedEffect(Unit) { mgr.refresh() }
    LaunchedEffect(state) {
        if (state is ModelState.Verifying) wasVerifying = true
        if (state is ModelState.Ready && wasVerifying) { wasVerifying = false; runTest() }
    }

    @Composable
    fun Card(content: @Composable () -> Unit) {
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(g.card).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) { content() }
    }

    Column(Modifier.fillMaxSize().background(g.bg)) {
        Row(Modifier.fillMaxWidth().background(g.card).padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = g.ink) }
            Text("IA da Cris", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
        }
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            // ---- Modelo
            item {
                Card {
                    Text("Modelo no aparelho", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(mgr.spec.displayName, color = g.ink, fontSize = 14.sp)
                    Text(
                        "Tamanho: ${LocalModelManager.fmtBytes(mgr.spec.sizeBytes)} · Licença: ${mgr.spec.license}",
                        color = g.muted, fontSize = 12.sp,
                    )
                    Text("Escolha o perfil:", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 4.dp)) {
                        LocalModels.ALL.forEach { m ->
                            val selected = mgr.spec.id == m.id
                            val installed = File(File(context.applicationContext.noBackupFilesDir, "localai/models"), m.fileName).let {
                                it.exists() && it.length() == m.sizeBytes
                            }
                            OutlinedButton(
                                onClick = {
                                    LocalAiSettings.setSelectedModelId(context, m.id)
                                    LocalAiEngine.get(context).unload()
                                    mgr.refresh()
                                },
                            ) {
                                Text(
                                    m.displayName.split("·").first().trim() + if (installed) " ✓" else "",
                                    color = if (selected) g.violet else g.ink,
                                    fontSize = 12.sp,
                                )
                            }
                        }
                    }
                    Text("Espaço livre: ${LocalModelManager.fmtBytes(mgr.freeBytes())}", color = g.muted, fontSize = 12.sp)
                    Text(
                        "Conexão: " + if (online) "online" else "offline",
                        color = g.muted, fontSize = 12.sp,
                    )
                    when (val st = state) {
                        ModelState.Missing -> {
                            Text("Não instalado. A Cris usa as respostas básicas offline e, se houver internet, os serviços online.", color = g.ink, fontSize = 13.sp)
                            Button(onClick = { showConsent = true }) { Text("Baixar IA local") }
                        }
                        is ModelState.Downloading -> {
                            val frac = if (st.total > 0) st.done.toFloat() / st.total else 0f
                            LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                            Text("Baixando… ${LocalModelManager.fmtBytes(st.done)} de ${LocalModelManager.fmtBytes(st.total)} (${(frac * 100).toInt()}%)", color = g.ink, fontSize = 13.sp)
                            Text("Mantenha o app aberto durante o download. Se fechar, é só continuar depois.", color = g.muted, fontSize = 12.sp)
                            OutlinedButton(onClick = { mgr.pause() }) { Text("Pausar") }
                        }
                        is ModelState.Paused -> {
                            val frac = if (st.total > 0) st.done.toFloat() / st.total else 0f
                            LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                            Text("Pausado em ${LocalModelManager.fmtBytes(st.done)} de ${LocalModelManager.fmtBytes(st.total)}.", color = g.ink, fontSize = 13.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { showConsent = true }) { Text("Continuar") }
                                OutlinedButton(onClick = { mgr.delete() }) { Text("Descartar") }
                            }
                        }
                        is ModelState.Failed -> {
                            Text(st.message, color = g.red, fontSize = 13.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { mgr.start() }) { Text("Tentar de novo") }
                                OutlinedButton(onClick = { mgr.delete() }) { Text("Descartar") }
                            }
                        }
                        ModelState.Verifying -> {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            Text("Verificando a integridade do arquivo (SHA-256)…", color = g.ink, fontSize = 13.sp)
                        }
                        ModelState.Ready -> {
                            Text(
                                when (val e = engineState) {
                                    EngineState.Unloaded -> "Instalado e verificado. Carrega na memória só quando você conversa."
                                    EngineState.Loading -> "Carregando na memória…"
                                    is EngineState.Loaded -> "Carregado (${e.backend}${if (e.vision) ", com visão" else ", só texto"})."
                                    is EngineState.Error -> "Instalado, mas não iniciou: ${e.message}"
                                },
                                color = g.ink, fontSize = 13.sp,
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { runTest() }, enabled = !testing) { Text(if (testing) "Testando…" else "Testar") }
                                OutlinedButton(onClick = { engine.unload() }) { Text("Liberar memória") }
                            }
                            testResult?.let { Text(it, color = g.ink, fontSize = 12.sp) }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(onClick = { mgr.delete(); testResult = null }) { Text("Apagar modelo") }
                                OutlinedButton(onClick = { mgr.delete(); testResult = null; showConsent = true }) { Text("Reinstalar") }
                            }
                        }
                    }
                }
            }

            // ---- Preferências e privacidade
            item {
                Card {
                    Text("Privacidade", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Usar a IA local", color = g.ink, fontSize = 14.sp)
                            Text("Quando instalada, responde primeiro no aparelho.", color = g.muted, fontSize = 12.sp)
                        }
                        Switch(checked = enabled, onCheckedChange = { enabled = it; LocalAiSettings.setEnabled(context, it) })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Enviar resumo de saúde a serviços online", color = g.ink, fontSize = 14.sp)
                            Text("Glicemias, insulina e refeições só vão a Gemini/servidor se você ligar isto. Desligado por padrão.", color = g.muted, fontSize = 12.sp)
                        }
                        Switch(checked = onlineHealth, onCheckedChange = { onlineHealth = it; LocalAiSettings.setOnlineHealthContextAllowed(context, it) })
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Voz natural online", color = g.ink, fontSize = 14.sp)
                            Text("Envia o texto das respostas ao servidor de voz. Desligado: usa a voz do aparelho, que funciona offline.", color = g.muted, fontSize = 12.sp)
                        }
                        Switch(checked = cloudVoice, onCheckedChange = { cloudVoice = it; LocalAiSettings.setCloudVoiceAllowed(context, it) })
                    }
                }
            }

            // ---- Download em segundo plano
            item {
                Card {
                    Text("Download", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    BackgroundDownloadSwitch()
                }
            }

            // ---- Pesquisa online (ferramenta da Cris; a IA local continua respondendo)
            item {
                Card {
                    Text("Pesquisa online", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Pesquisar sozinha quando precisar", color = g.ink, fontSize = 14.sp)
                            Text(
                                "Com internet, a Cris pesquisa notícias e informações atuais e responde com as palavras dela, citando fontes e datas. Sem internet, segue 100% local. Seus registros de saúde e seu histórico nunca são enviados.",
                                color = g.muted, fontSize = 12.sp,
                            )
                        }
                        Switch(checked = webSearch, onCheckedChange = { webSearch = it; LocalAiSettings.setWebSearchEnabled(context, it) })
                    }
                    Text(
                        (if (LocalAiSettings.tavilyAvailable(context)) "Busca geral na web (Tavily): ativa quando necessário (créditos estimados restantes no mês: ${com.agon.app.localai.TavilyCredits.remaining(context)}). " else "Busca geral na web: indisponível neste aplicativo. ") +
                            "Também usa Google Notícias, Wikipédia, Wikidata e PubMed (saúde). Status: " + if (online) "online" else "sem internet",
                        color = g.ink, fontSize = 12.sp,
                    )
                    OutlinedButton(
                        enabled = !webTesting,
                        onClick = {
                            webTesting = true; webTestResult = null
                            scope.launch { webTestResult = CrisWebSearch.selfTest(context); webTesting = false }
                        },
                    ) { Text(if (webTesting) "Testando..." else "Testar pesquisa") }
                    webTestResult?.let { Text(it, color = g.ink, fontSize = 12.sp) }
                }
            }

            // ---- Voz
            item {
                Card {
                    Text("Voz", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text(
                        if (LocalSpeech.onDeviceRecognitionAvailable(context))
                            "Reconhecimento no aparelho: disponível neste Android. Se o pacote de português do Brasil não estiver instalado, instale em Configurações > Idioma > Voz."
                        else
                            "Reconhecimento no aparelho: não disponível neste Android (precisa do Android 13 ou mais). O reconhecimento padrão do sistema pode exigir internet.",
                        color = g.ink, fontSize = 13.sp,
                    )
                    Text("Fala: usa uma voz pt-BR instalada que não precise de internet. O Android não informa o gênero da voz; a escolha é aproximada.", color = g.muted, fontSize = 12.sp)
                }
            }

            // ---- Memória
            item {
                Card {
                    Text("Memória da Cris", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Só guarda o que você pedir (\"lembre que ...\"). Fica neste aparelho. O histórico da conversa é separado.", color = g.muted, fontSize = 12.sp)
                    if (facts.isEmpty()) Text("Nada guardado ainda.", color = g.ink, fontSize = 13.sp)
                    facts.forEach { f ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(f.text, color = g.ink, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            IconButton(onClick = { editing = f }) { Icon(Icons.Filled.Edit, "Editar", tint = g.violet, modifier = Modifier.size(20.dp)) }
                            IconButton(onClick = { LocalMemoryManager.remove(context, f.id); facts = LocalMemoryManager.load(context) }) {
                                Icon(Icons.Filled.Delete, "Apagar", tint = g.muted, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { adding = true }) { Text("Adicionar") }
                        if (facts.isNotEmpty()) OutlinedButton(onClick = { confirmClearAll = true }) { Text("Apagar tudo") }
                    }
                    OutlinedButton(onClick = {
                        scope.launch { CrisPrefs.clearChat(context); CrisConversationStore.clearAll(context); historyCleared = true }
                    }) { Text(if (historyCleared) "Histórico apagado" else "Apagar histórico de conversas") }
                }
            }
        }
    }

    if (showConsent) {
        val have = mgr.freeBytes()
        val need = mgr.requiredFreeBytes()
        AlertDialog(
            onDismissRequest = { showConsent = false },
            title = { Text("Baixar a IA local?") },
            text = {
                Text(
                    "Vai baixar ${LocalModelManager.fmtBytes(mgr.spec.sizeBytes)} de ${mgr.spec.displayName}. " +
                        "Use Wi-Fi. Precisa de pelo menos ${LocalModelManager.fmtBytes(need)} livres (você tem ${LocalModelManager.fmtBytes(have)}).\n\n" +
                        "O modelo fica guardado no armazenamento privado do app, é verificado por SHA-256, pode ser pausado e retomado, e você pode apagá-lo quando quiser. " +
                        "Depois de instalado, a IA funciona sem internet.",
                )
            },
            confirmButton = {
                TextButton(enabled = have >= need, onClick = { showConsent = false; mgr.start() }) { Text("Baixar") }
            },
            dismissButton = { TextButton(onClick = { showConsent = false }) { Text("Cancelar") } },
        )
    }

    if (confirmClearAll) {
        AlertDialog(
            onDismissRequest = { confirmClearAll = false },
            title = { Text("Apagar toda a memória?") },
            text = { Text("A Cris vai esquecer tudo o que você pediu para ela guardar.") },
            confirmButton = {
                TextButton(onClick = { LocalMemoryManager.clear(context); facts = emptyList(); confirmClearAll = false }) { Text("Apagar") }
            },
            dismissButton = { TextButton(onClick = { confirmClearAll = false }) { Text("Cancelar") } },
        )
    }

    if (adding || editing != null) {
        var text by remember(editing, adding) { mutableStateOf(editing?.text ?: "") }
        AlertDialog(
            onDismissRequest = { adding = false; editing = null },
            title = { Text(if (editing != null) "Editar memória" else "Nova memória") },
            text = { OutlinedTextField(value = text, onValueChange = { text = it.take(300) }, modifier = Modifier.fillMaxWidth()) },
            confirmButton = {
                TextButton(onClick = {
                    val e = editing
                    if (e != null) LocalMemoryManager.update(context, e.id, text) else LocalMemoryManager.add(context, text)
                    facts = LocalMemoryManager.load(context)
                    adding = false; editing = null
                }) { Text("Salvar") }
            },
            dismissButton = { TextButton(onClick = { adding = false; editing = null }) { Text("Cancelar") } },
        )
    }
}