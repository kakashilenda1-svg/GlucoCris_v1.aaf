package com.agon.app.ui.screens

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.localai.CrisConnectivityManager
import com.agon.app.localai.LocalAiSettings
import com.agon.app.localai.LocalModelManager
import com.agon.app.localai.ModelDownloadService
import com.agon.app.localai.ModelState
import com.agon.app.ui.theme.glucoColors

/** RAM total mínima (bytes) para exigir a IA local na instalação. Abaixo disso o app abre normalmente, sem obrigar o download. */
private const val MIN_RAM_FOR_REQUIRED_AI = 5_000_000_000L

fun deviceCanRunLocalAi(context: Context): Boolean = try {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    mi.totalMem >= MIN_RAM_FOR_REQUIRED_AI
} catch (_: Exception) {
    true
}

private fun isMetered(context: Context): Boolean = try {
    (context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager).isActiveNetworkMetered
} catch (_: Exception) {
    true
}

/**
 * Tela de preparação da primeira abertura (antes do login com Google): baixa a IA local.
 * Começa sozinha no Wi-Fi; em dados móveis espera a pessoa tocar. Só libera o app quando o modelo
 * está instalado e verificado. Se falhar (espaço, conexão), aparece "Continuar sem a IA por enquanto".
 */
@Composable
fun CrisModelGateScreen(onDone: () -> Unit) {
    val g = glucoColors()
    val context = LocalContext.current
    val mgr = remember { LocalModelManager.get(context) }
    val state by mgr.state.collectAsState()
    val online by remember { CrisConnectivityManager.observe(context) }
        .collectAsState(initial = CrisConnectivityManager.isOnline(context))
    val metered = remember(online) { isMetered(context) }
    var autoTried by remember { mutableStateOf(false) }

    val view = LocalView.current
    DisposableEffect(Unit) {
        view.keepScreenOn = true
        onDispose { view.keepScreenOn = false }
    }

    LaunchedEffect(Unit) { mgr.refresh() }
    LaunchedEffect(online, metered) {
        val st = mgr.state.value
        if (online && !metered && !autoTried && (st is ModelState.Missing || st is ModelState.Paused)) {
            autoTried = true
            mgr.start()
        }
    }
    LaunchedEffect(state) { if (state is ModelState.Ready) onDone() }

    val size = LocalModelManager.fmtBytes(mgr.spec.sizeBytes)
    Column(
        Modifier.fillMaxSize().background(g.bg).padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text("Preparando a Cris ❤️", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Text(
            "Na primeira vez, o app baixa a inteligência da Cris ($size) para ela conversar com você, até sem internet. " +
                "Use Wi-Fi e deixe o app aberto. É só uma vez.",
            color = g.muted, fontSize = 14.sp, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))

        when (val st = state) {
            is ModelState.Downloading -> {
                val frac = if (st.total > 0) st.done.toFloat() / st.total else 0f
                LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("${LocalModelManager.fmtBytes(st.done)} de ${LocalModelManager.fmtBytes(st.total)} (${(frac * 100).toInt()}%)", color = g.ink, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = { mgr.pause() }) { Text("Pausar") }
            }
            is ModelState.Verifying -> {
                LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("Conferindo se o arquivo está íntegro…", color = g.ink, fontSize = 14.sp)
            }
            is ModelState.Ready -> {
                Text("Tudo pronto! 💜", color = g.ink, fontSize = 16.sp)
            }
            is ModelState.Failed -> {
                Text(st.message, color = g.red, fontSize = 14.sp, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { mgr.start() }) { Text("Tentar de novo") }
                TextButton(onClick = onDone) { Text("Continuar sem a IA por enquanto") }
            }
            is ModelState.Paused -> {
                val frac = if (st.total > 0) st.done.toFloat() / st.total else 0f
                LinearProgressIndicator(progress = { frac }, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                Text("Pausado em ${LocalModelManager.fmtBytes(st.done)} de ${LocalModelManager.fmtBytes(st.total)}.", color = g.ink, fontSize = 14.sp)
                Spacer(Modifier.height(12.dp))
                StartControls(online, metered, mgr, g.ink, g.muted, "Continuar")
            }
            is ModelState.Missing -> {
                StartControls(online, metered, mgr, g.ink, g.muted, "Baixar agora")
            }
        }
        Spacer(Modifier.height(24.dp))
        BackgroundDownloadSwitch()
    }
}

/** Opção "continuar baixando em segundo plano" (serviço com notificação). Usada na tela de preparação e nas configurações da IA. */
@Composable
fun BackgroundDownloadSwitch() {
    val g = glucoColors()
    val context = LocalContext.current
    val mgr = remember { LocalModelManager.get(context) }
    val state by mgr.state.collectAsState()
    var on by remember { mutableStateOf(LocalAiSettings.backgroundDownload(context)) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text("Continuar baixando em segundo plano", color = g.ink, fontSize = 14.sp)
            Text("Mostra o progresso numa notificação e segue baixando mesmo se você sair do app.", color = g.muted, fontSize = 12.sp)
        }
        Switch(
            checked = on,
            onCheckedChange = { v ->
                on = v
                LocalAiSettings.setBackgroundDownload(context, v)
                if (v && state is ModelState.Downloading) ModelDownloadService.begin(context)
                if (!v) context.stopService(android.content.Intent(context, ModelDownloadService::class.java))
            },
        )
    }
}

@Composable
private fun StartControls(
    online: Boolean,
    metered: Boolean,
    mgr: LocalModelManager,
    ink: androidx.compose.ui.graphics.Color,
    muted: androidx.compose.ui.graphics.Color,
    label: String,
) {
    if (!online) {
        Text("Sem internet. Conecte-se ao Wi-Fi para continuar.", color = ink, fontSize = 14.sp, textAlign = TextAlign.Center)
        return
    }
    if (metered) {
        Text(
            "Você está usando dados móveis. Este download é grande e pode consumir seu plano. Prefere esperar o Wi-Fi?",
            color = muted, fontSize = 13.sp, textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(10.dp))
        Button(onClick = { mgr.start() }) { Text("$label com dados móveis") }
    } else {
        Button(onClick = { mgr.start() }) { Text(label) }
    }
}
