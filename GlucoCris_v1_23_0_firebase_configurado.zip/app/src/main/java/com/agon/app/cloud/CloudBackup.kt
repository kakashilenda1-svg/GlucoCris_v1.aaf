package com.agon.app.cloud

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.agon.app.data.AppData
import com.google.android.gms.tasks.Task
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.FirebaseFirestoreSettings
import com.google.firebase.firestore.MemoryCacheSettings
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.Source
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

enum class CloudState { SIGNED_OUT, IDLE, SYNCING, OK, OFFLINE, QUOTA, ACCOUNT_MISMATCH, ERROR }

data class CloudStatus(
    val state: CloudState,
    val message: String = "",
    val lastSyncAt: Long = 0L,
)

private class LocalQuotaException(message: String) : Exception(message)

/**
 * Backup/sincronização no Firestore (plano Spark).
 *
 * Caminho: users/{uid}/records/{tipo}__{id}  e  users/{uid}.
 * A fonte da verdade é SEMPRE o armazenamento local (DataStore). A nuvem é cópia:
 * qualquer falha (offline, cota, permissão) só muda o status; nada local é apagado ou alterado.
 */
class CloudBackup(context: Context) {
    private val ctx = context.applicationContext
    private val prefs = ctx.getSharedPreferences("cloud_sync", Context.MODE_PRIVATE)
    private val mutex = Mutex()

    private val auth: FirebaseAuth get() = FirebaseAuth.getInstance()

    // Cache só em memória: não cria segunda cópia persistente dos dados de saúde no aparelho
    // e não deixa o SDK enfileirar escritas "para sempre". Quem controla o reenvio é este código.
    private val db: FirebaseFirestore by lazy {
        val fs = FirebaseFirestore.getInstance()
        try {
            fs.firestoreSettings = FirebaseFirestoreSettings.Builder()
                .setLocalCacheSettings(MemoryCacheSettings.newBuilder().build())
                .build()
        } catch (_: IllegalStateException) {
            // já inicializado nesta execução; segue com as configurações atuais
        }
        fs
    }

    // ---------- Login (sempre Google; nunca anônimo) ----------

    /** UID do Firebase da pessoa logada com Google; null se ninguém ou se (por engano) for anônimo. */
    fun currentUid(): String? = auth.currentUser?.takeIf { !it.isAnonymous }?.uid

    suspend fun signInWithGoogleIdToken(idToken: String): String {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        val result = net { auth.signInWithCredential(credential).awaitValue() }
        val user = result.user ?: throw IllegalStateException("Login sem usuário")
        if (user.isAnonymous) {
            auth.signOut()
            throw IllegalStateException("Login anônimo não é permitido")
        }
        return user.uid
    }

    fun signOut() {
        try { auth.signOut() } catch (_: Exception) {}
    }

    // ---------- Estado local do sync (SharedPreferences, por UID) ----------

    fun initialStatus(): CloudStatus {
        val uid = currentUid() ?: return CloudStatus(CloudState.SIGNED_OUT, "Entre com o Google para ativar o backup.")
        return CloudStatus(CloudState.IDLE, "", prefs.getLong("lastsync_$uid", 0L))
    }

    /** Dados deste aparelho passam a pertencer à conta atual (decisão explícita da pessoa). */
    fun adoptCurrentAccount(resetCursors: Boolean) {
        val uid = currentUid() ?: return
        val ed = prefs.edit()
        ed.putString("owner_uid", uid)
        if (resetCursors) {
            ed.remove("cursor_$uid")
            ed.remove("lastpush_$uid")
        }
        ed.apply()
    }

    private fun readCursor(uid: String): Timestamp {
        val raw = prefs.getString("cursor_$uid", null) ?: return Timestamp(0, 0)
        val p = raw.split(":")
        val s = p.getOrNull(0)?.toLongOrNull() ?: return Timestamp(0, 0)
        val n = p.getOrNull(1)?.toIntOrNull() ?: 0
        return Timestamp(s, n)
    }

    private fun saveCursor(uid: String, ts: Timestamp) {
        prefs.edit().putString("cursor_$uid", "${ts.seconds}:${ts.nanoseconds}").apply()
    }

    // ---------- Cota do Spark (limites diários: 50 mil leituras, 20 mil gravações) ----------

    private fun dayKey(): String = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    private fun counter(prefix: String): Int = prefs.getInt("${prefix}_${dayKey()}", 0)

    private fun addCount(prefix: String, n: Int) {
        val day = dayKey()
        val ed = prefs.edit()
        prefs.all.keys.filter { (it.startsWith("r_") || it.startsWith("w_")) && !it.endsWith(day) }.forEach { ed.remove(it) }
        ed.putInt("${prefix}_$day", counter(prefix) + n).apply()
    }

    private fun nextMorning(): Long = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, 1)
        set(Calendar.HOUR_OF_DAY, 6); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun checkBudget(reads: Int, writes: Int) {
        if (counter("r") + reads > READ_BUDGET || counter("w") + writes > WRITE_BUDGET) {
            prefs.edit().putLong("blocked_until", nextMorning()).apply()
            throw LocalQuotaException("Limite diário gratuito quase no fim; o backup volta amanhã.")
        }
    }

    // ---------- Rede ----------

    fun isOnline(): Boolean {
        val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private suspend fun <T : Any> net(block: suspend () -> T): T =
        withTimeoutOrNull(NET_TIMEOUT_MS) { block() } ?: throw IOException("tempo esgotado")

    private suspend fun <T : Any> Task<T>.awaitValue(): T = suspendCancellableCoroutine { c ->
        addOnSuccessListener { v -> if (v != null) c.resume(v) else c.resumeWithException(IllegalStateException("vazio")) }
        addOnFailureListener { e -> c.resumeWithException(e) }
        addOnCanceledListener { c.cancel() }
    }

    private suspend fun Task<*>.awaitDone(): Boolean = suspendCancellableCoroutine { c ->
        addOnSuccessListener { c.resume(true) }
        addOnFailureListener { e -> c.resumeWithException(e) }
        addOnCanceledListener { c.cancel() }
    }

    // ---------- Firestore ----------

    private fun records(uid: String) = db.collection("users").document(uid).collection("records")

    private class Pulled(val docs: List<RemoteDoc>, val cursor: Timestamp)

    private suspend fun pull(uid: String, restore: Boolean): Pulled {
        val start = if (restore) Timestamp(0, 0) else readCursor(uid)
        var maxTs = start
        var last: DocumentSnapshot? = null
        val out = ArrayList<RemoteDoc>()
        while (true) {
            checkBudget(reads = PAGE, writes = 0)
            var q: Query = records(uid).whereGreaterThan("syncedAt", start).orderBy("syncedAt").limit(PAGE.toLong())
            if (last != null) q = q.startAfter(last)
            val snap = net { q.get(Source.SERVER).awaitValue() }
            addCount("r", maxOf(1, snap.size()))
            for (d in snap.documents) {
                val type = d.getString("type") ?: continue
                val id = d.getString("id") ?: continue
                if (type !in SyncMerge.TYPES) continue
                val upd = d.getLong("updatedAt") ?: continue
                out += RemoteDoc(type, id, upd, d.getBoolean("deleted") ?: false, d.getString("payload").orEmpty())
                d.getTimestamp("syncedAt")?.let { if (it > maxTs) maxTs = it }
            }
            if (snap.size() < PAGE) break
            last = snap.documents.last()
        }
        return Pulled(out, maxTs)
    }

    private suspend fun push(uid: String, docs: List<RemoteDoc>) {
        if (docs.isEmpty()) return
        val chunks = docs.chunked(400)
        chunks.forEachIndexed { index, chunk ->
            checkBudget(reads = 0, writes = chunk.size + 1)
            val batch = db.batch()
            for (d in chunk) {
                batch.set(
                    records(uid).document(d.docId),
                    mapOf(
                        "type" to d.type,
                        "id" to d.id,
                        "updatedAt" to d.updatedAt,
                        "deleted" to d.deleted,
                        "payload" to d.payload,
                        "schema" to 1L,
                        "syncedAt" to FieldValue.serverTimestamp(),
                    ),
                )
            }
            if (index == chunks.lastIndex) {
                batch.set(
                    db.collection("users").document(uid),
                    mapOf("lastBackupAt" to FieldValue.serverTimestamp(), "schema" to 1L),
                )
            }
            net { batch.commit().awaitDone() }
            addCount("w", chunk.size + if (index == chunks.lastIndex) 1 else 0)
        }
    }

    /**
     * Um ciclo completo: baixar o que mudou na nuvem, enviar o que mudou aqui, aplicar o baixado.
     * [applyRemote] devolve false se não pôde aplicar agora (ex.: modo simulação); aí nada é marcado como feito.
     * Nunca lança: devolve o status.
     */
    suspend fun sync(
        getLocal: () -> AppData,
        applyRemote: (docs: List<RemoteDoc>, pruneBefore: Long) -> Boolean,
        restore: Boolean = false,
    ): CloudStatus = mutex.withLock {
        val uid = currentUid()
            ?: return@withLock CloudStatus(CloudState.SIGNED_OUT, "Entre com o Google para ativar o backup.")
        if (!isOnline()) {
            return@withLock CloudStatus(CloudState.OFFLINE, "Sem internet. Seus dados continuam salvos no aparelho.", prefs.getLong("lastsync_$uid", 0L))
        }
        val now = System.currentTimeMillis()
        val blocked = prefs.getLong("blocked_until", 0L)
        if (blocked > now) {
            return@withLock CloudStatus(CloudState.QUOTA, "Limite diário gratuito do Firebase atingido. O backup tenta de novo mais tarde; nada foi perdido.", prefs.getLong("lastsync_$uid", 0L))
        }
        val owner = prefs.getString("owner_uid", null)
        if (owner != null && owner != uid) {
            return@withLock CloudStatus(CloudState.ACCOUNT_MISMATCH, "Os dados deste aparelho pertencem a outra conta Google.")
        }
        try {
            if (owner == null) prefs.edit().putString("owner_uid", uid).apply()
            val t0 = System.currentTimeMillis()
            val prevPush = prefs.getLong("lastpush_$uid", -1L)
            val lastPush = if (restore) -1L else prevPush
            val pulled = pull(uid, restore)
            val seen = HashMap<String, Long>()
            pulled.docs.forEach { seen[it.docId] = it.updatedAt }
            val toPush = SyncMerge.pending(getLocal(), seen, lastPush)
            push(uid, toPush)
            val pruneBefore = if (prevPush > 0) minOf(prevPush, t0 - PRUNE_MS) else -1L
            if (!applyRemote(pulled.docs, pruneBefore)) {
                return@withLock CloudStatus(CloudState.IDLE, "Backup adiado.", prefs.getLong("lastsync_$uid", 0L))
            }
            saveCursor(uid, pulled.cursor)
            val done = System.currentTimeMillis()
            prefs.edit().putLong("lastpush_$uid", t0 - 1).putLong("lastsync_$uid", done).apply()
            CloudStatus(CloudState.OK, "Backup em dia.", done)
        } catch (e: CancellationException) {
            throw e
        } catch (e: LocalQuotaException) {
            CloudStatus(CloudState.QUOTA, e.message.orEmpty(), prefs.getLong("lastsync_$uid", 0L))
        } catch (e: FirebaseFirestoreException) {
            val last = prefs.getLong("lastsync_$uid", 0L)
            when (e.code) {
                FirebaseFirestoreException.Code.RESOURCE_EXHAUSTED -> {
                    prefs.edit().putLong("blocked_until", System.currentTimeMillis() + 3 * 3_600_000L).apply()
                    CloudStatus(CloudState.QUOTA, "Cota gratuita do Firebase esgotada hoje. Seus dados seguem no aparelho; o backup retoma sozinho.", last)
                }
                FirebaseFirestoreException.Code.UNAVAILABLE,
                FirebaseFirestoreException.Code.DEADLINE_EXCEEDED ->
                    CloudStatus(CloudState.OFFLINE, "Sem conexão com o servidor. Seus dados continuam no aparelho.", last)
                FirebaseFirestoreException.Code.PERMISSION_DENIED ->
                    CloudStatus(CloudState.ERROR, "Permissão negada pelo Firebase. Confira se as regras foram publicadas e se o login é Google.", last)
                FirebaseFirestoreException.Code.UNAUTHENTICATED ->
                    CloudStatus(CloudState.SIGNED_OUT, "Sessão expirada. Entre com o Google de novo.", last)
                else -> CloudStatus(CloudState.ERROR, "Falha no backup (${e.code}). Seus dados continuam no aparelho.", last)
            }
        } catch (e: IOException) {
            CloudStatus(CloudState.OFFLINE, "Conexão instável. Seus dados continuam no aparelho.", prefs.getLong("lastsync_$uid", 0L))
        } catch (e: Exception) {
            CloudStatus(CloudState.ERROR, "Falha no backup. Seus dados continuam no aparelho.", prefs.getLong("lastsync_$uid", 0L))
        }
    }

    companion object {
        private const val PAGE = 500
        private const val NET_TIMEOUT_MS = 25_000L
        private const val PRUNE_MS = 90L * 24 * 3_600_000L

        // Margem de segurança sobre os limites do Spark (50.000 leituras e 20.000 gravações por dia)
        private const val READ_BUDGET = 40_000
        private const val WRITE_BUDGET = 16_000
    }
}
