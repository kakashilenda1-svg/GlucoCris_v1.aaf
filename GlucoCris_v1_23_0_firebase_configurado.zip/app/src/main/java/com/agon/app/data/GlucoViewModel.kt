package com.agon.app.data

import android.app.Application
import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.agon.app.cloud.CloudBackup
import com.agon.app.cloud.CloudState
import com.agon.app.cloud.CloudStatus
import com.agon.app.cloud.RemoteDoc
import com.agon.app.cloud.SyncMerge
import com.agon.app.reminders.ReminderScheduler
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.receiveAsFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.glucoDataStore by preferencesDataStore(name = "gluco_store")

object GlucoStorage {
    val KEY = stringPreferencesKey("gluco.maria-cristina.v1")
    val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
        coerceInputValues = true
    }

    suspend fun read(context: Context): AppData? {
        val prefs = context.glucoDataStore.data.first()
        val text = prefs[KEY] ?: return null
        return try {
            json.decodeFromString<AppData>(text)
        } catch (e: Exception) {
            null
        }
    }
}

class GlucoViewModel(app: Application) : AndroidViewModel(app) {
    private val _data = MutableStateFlow(defaultData())
    val data: StateFlow<AppData> = _data.asStateFlow()

    private val _ready = MutableStateFlow(false)
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    private val _unlocked = MutableStateFlow(false)
    val unlocked: StateFlow<Boolean> = _unlocked.asStateFlow()

    // Tour de ajuda: null = fechado, -1 = convite, 0.. = card do passo
    private val _tourStep = MutableStateFlow<Int?>(null)
    val tourStep: StateFlow<Int?> = _tourStep.asStateFlow()

    fun offerTour() {
        if (_tourStep.value == null) _tourStep.value = -1
    }

    fun setTourStep(step: Int) {
        _tourStep.value = step
    }

    fun closeTour() {
        _tourStep.value = null
        if (!_data.value.settings.tourSeen) updateSettings { it.copy(tourSeen = true) }
    }

    fun linkGoogle(email: String, name: String) {
        updateSettings { it.copy(googleEmail = email, googleName = name) }
    }

    // ---------- Backup na nuvem (Firebase Spark) ----------
    private val backup = CloudBackup(app)
    private val _cloud = MutableStateFlow(backup.initialStatus())
    val cloud: StateFlow<CloudStatus> = _cloud.asStateFlow()
    private var debounce: Job? = null
    private var syncRunning = false
    private var syncAgain = false

    /** Troca o login do Google pelo login do Firebase (necessário para as regras do Firestore). */
    fun startBackup(idToken: String?) {
        if (idToken.isNullOrBlank()) {
            _cloud.value = CloudStatus(
                CloudState.ERROR,
                "Backup indisponível: faltam o cliente OAuth e o SHA-1 no Firebase (google-services.json). Seus dados continuam no aparelho.",
            )
            return
        }
        viewModelScope.launch {
            _cloud.value = CloudStatus(CloudState.SYNCING, "Ativando o backup...")
            try {
                backup.signInWithGoogleIdToken(idToken)
                _cloud.value = backup.initialStatus()
                syncNow()
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                _cloud.value = CloudStatus(CloudState.ERROR, "Não foi possível ativar o backup agora. Seus dados continuam no aparelho.")
            }
        }
    }

    fun scheduleSync(delayMs: Long = 45_000L) {
        if (_practice.value || backup.currentUid() == null) return
        debounce?.cancel()
        debounce = viewModelScope.launch {
            delay(delayMs)
            runSync(false)
        }
    }

    fun syncNow(restore: Boolean = false) {
        if (_practice.value) return
        viewModelScope.launch { runSync(restore) }
    }

    private suspend fun runSync(restore: Boolean) {
        if (_practice.value || !_ready.value) return
        if (syncRunning) { syncAgain = true; return }
        syncRunning = true
        try {
            _cloud.value = _cloud.value.copy(state = CloudState.SYNCING, message = "Sincronizando...")
            _cloud.value = withContext(Dispatchers.Default) {
                backup.sync(getLocal = { _data.value }, applyRemote = { docs, prune -> applyRemote(docs, prune) }, restore = restore)
            }
        } finally {
            syncRunning = false
        }
        if (syncAgain) { syncAgain = false; scheduleSync() }
    }

    /** Aplica o que veio da nuvem. Não passa por update(), para não disparar outro envio. */
    private fun applyRemote(docs: List<RemoteDoc>, pruneBefore: Long): Boolean {
        if (_practice.value) return false
        val old = _data.value
        val next = SyncMerge.mergeRemote(old, docs, pruneBefore)
        if (next != old) {
            _data.value = next
            saveQueue.trySend(next)
            if (old.reminders != next.reminders) {
                ReminderScheduler.sync(getApplication(), old.reminders, next.reminders)
            }
        }
        return true
    }

    /** Conta Google diferente da dona dos dados deste aparelho: a pessoa escolhe o que fazer. */
    fun resolveAccountMismatch(replaceLocalWithCloud: Boolean) {
        if (_practice.value || backup.currentUid() == null) return
        backup.adoptCurrentAccount(resetCursors = true)
        if (replaceLocalWithCloud) {
            val old = _data.value
            val fresh = AppData(settings = old.settings.copy(settingsUpdatedAt = 0L))
            _data.value = fresh
            saveQueue.trySend(fresh)
            ReminderScheduler.sync(getApplication(), old.reminders, fresh.reminders)
            syncNow(restore = true)
        } else {
            syncNow()
        }
    }

    /** Sai da conta: volta para a tela de login com o Google. Os dados continuam no aparelho. */
    fun logout() {
        if (_practice.value) endPractice()
        debounce?.cancel()
        backup.signOut()
        _cloud.value = CloudStatus(CloudState.SIGNED_OUT, "Entre com o Google para ativar o backup.")
        updateSettings { it.copy(googleEmail = "", googleName = "") }
        _tourStep.value = null
    }

    // Voz do tour (ligada por padrão)
    private val _tourVoice = MutableStateFlow(true)
    val tourVoice: StateFlow<Boolean> = _tourVoice.asStateFlow()
    fun setTourVoice(on: Boolean) { _tourVoice.value = on }

    // Simulação do tour: dados de exemplo, nada é salvo
    private val _practice = MutableStateFlow(false)
    val practice: StateFlow<Boolean> = _practice.asStateFlow()
    private var practiceBackup: AppData? = null

    fun startPractice() {
        if (_practice.value || !_ready.value) return
        val real = _data.value
        practiceBackup = real
        PracticeMode.names.toList().forEach { getApplication<Application>().deleteSharedPreferences(it) }
        PracticeMode.names.clear()
        PracticeMode.active = true
        _practice.value = true
        _plate.value = emptyList()
        _data.value = defaultData().copy(settings = real.settings)
    }

    fun endPractice() {
        if (!_practice.value) return
        PracticeMode.active = false
        _practice.value = false
        PracticeMode.names.toList().forEach { getApplication<Application>().deleteSharedPreferences(it) }
        PracticeMode.names.clear()
        practiceBackup?.let { _data.value = it }
        practiceBackup = null
        _plate.value = emptyList()
    }

    var tempFood: com.agon.app.ui.screens.FoodItem? = null
    var tempMealType: String = "cafe"
    @set:JvmName("assignTempRecipe")
    var tempRecipe: com.agon.app.ui.screens.RecipeItem? = null
    fun setTempRecipe(r: com.agon.app.ui.screens.RecipeItem) { tempRecipe = r }
    fun setTempFood(food: com.agon.app.ui.screens.FoodItem, meal: String) {
        tempFood = food
        tempMealType = meal
    }

    // Prato em montagem (compartilhado entre busca, tela do prato e bolus)
    private val _plate = MutableStateFlow<List<com.agon.app.ui.screens.PlateLine>>(emptyList())
    val plate: StateFlow<List<com.agon.app.ui.screens.PlateLine>> = _plate.asStateFlow()
    var plateMealType: String = "cafe"

    fun togglePlate(food: com.agon.app.ui.screens.FoodItem) {
        val cur = _plate.value
        _plate.value = if (cur.any { it.food.id == food.id }) {
            cur.filter { it.food.id != food.id }
        } else {
            cur + com.agon.app.ui.screens.PlateLine(food)
        }
    }

    fun setPlateQty(id: String, qty: Double) {
        _plate.value = _plate.value.map {
            if (it.food.id == id) it.copy(qty = qty.coerceAtLeast(0.5), grams = null) else it
        }
    }

    fun setPlateGrams(id: String, grams: Double) {
        _plate.value = _plate.value.map {
            if (it.food.id != id) it
            else {
                val q = if (it.food.servingGrams > 0) (grams / it.food.servingGrams).coerceAtLeast(0.01) else it.qty
                it.copy(grams = grams.coerceAtLeast(0.1), qty = q)
            }
        }
    }

    /** Adiciona ao prato (ou atualiza qtd/peso se já estiver). Não remove. */
    fun addToPlate(food: com.agon.app.ui.screens.FoodItem, qty: Double = 1.0, grams: Double? = null) {
        val cur = _plate.value
        _plate.value = if (cur.any { it.food.id == food.id }) {
            cur.map {
                if (it.food.id == food.id) it.copy(qty = qty.coerceAtLeast(0.5), grams = grams) else it
            }
        } else {
            cur + com.agon.app.ui.screens.PlateLine(food, qty.coerceAtLeast(0.5), grams)
        }
    }

    fun removeFromPlate(id: String) {
        _plate.value = _plate.value.filter { it.food.id != id }
    }

    fun clearPlate() {
        _plate.value = emptyList()
    }

    private val saveQueue = Channel<AppData>(Channel.UNLIMITED)

    init {
        viewModelScope.launch {
            saveQueue.receiveAsFlow().conflate().collect { snapshot ->
                val text = withContext(Dispatchers.Default) { GlucoStorage.json.encodeToString(snapshot) }
                getApplication<Application>().glucoDataStore.edit { it[GlucoStorage.KEY] = text }
            }
        }
        viewModelScope.launch {
            val loaded = try {
                withContext(Dispatchers.Default) { GlucoStorage.read(getApplication()) }
            } catch (e: Exception) {
                null
            }
            val initial = loaded ?: defaultData()
            _data.value = initial
            _unlocked.value = !initial.settings.pinEnabled
            _ready.value = true
            ReminderScheduler.ensureChannels(getApplication())
            ReminderScheduler.sync(getApplication(), emptyList(), initial.reminders)
            if (loaded == null) saveQueue.trySend(initial)
            scheduleSync(3_000L)
        }
    }

    private fun update(block: (AppData) -> AppData) {
        if (!_ready.value) return
        val old = _data.value
        val next = block(old)
        _data.value = next
        if (_practice.value) return
        saveQueue.trySend(next)
        if (old.reminders != next.reminders) {
            ReminderScheduler.sync(getApplication(), old.reminders, next.reminders)
        }
        scheduleSync()
    }

    private fun AppData.withTomb(col: String, id: String): AppData = copy(
        tombstones = tombstones.filterNot { it.col == col && it.id == id } + Tombstone(col, id, System.currentTimeMillis()),
    )

    fun unlock(pin: String): Boolean {
        val s = _data.value.settings
        if (s.pinEnabled && pin != s.pin) return false
        _unlocked.value = true
        return true
    }

    fun lock() {
        if (_data.value.settings.pinEnabled) _unlocked.value = false
    }

    fun updateSettings(block: (Settings) -> Settings) {
        update { it.copy(settings = block(it.settings).copy(settingsUpdatedAt = System.currentTimeMillis())) }
    }

    fun saveGlucose(id: String?, value: Double, unit: String, at: Long, context: String, notes: String) {
        if (id == null && !_practice.value) {
            val mg = toMgDl(value, unit)
            if (mg > _data.value.settings.targetHigh) {
                com.agon.app.reminders.WaterAlert.notifyHighGlucose(getApplication<Application>(), mg)
            }
        }
        update { d ->
            val now = System.currentTimeMillis()
            if (id == null) {
                d.copy(glucose = listOf(GlucoseEntry(uid(), value, unit, at, context, notes, now, now)) + d.glucose)
            } else {
                d.copy(glucose = d.glucose.map { e ->
                    if (e.id == id) e.copy(value = value, unit = unit, at = at, context = context, notes = notes, updatedAt = now) else e
                })
            }
        }
    }

    fun deleteGlucose(id: String) = update { it.copy(glucose = it.glucose.filter { e -> e.id != id }).withTomb(SyncMerge.GLUCOSE, id) }

    fun saveInsulin(id: String?, kind: String, name: String, dose: Double, at: Long, notes: String) {
        update { d ->
            val now = System.currentTimeMillis()
            if (id == null) {
                d.copy(insulin = listOf(InsulinEntry(uid(), kind, name, dose, "UI", at, notes, now, now)) + d.insulin)
            } else {
                d.copy(insulin = d.insulin.map { e ->
                    if (e.id == id) e.copy(kind = kind, name = name, dose = dose, at = at, notes = notes, updatedAt = now) else e
                })
            }
        }
    }

    fun deleteInsulin(id: String) = update { it.copy(insulin = it.insulin.filter { e -> e.id != id }).withTomb(SyncMerge.INSULIN, id) }

    fun saveReminder(r0: Reminder) = update { d ->
        val r = r0.copy(updatedAt = System.currentTimeMillis())
        if (d.reminders.none { it.id == r.id }) d.copy(reminders = listOf(r) + d.reminders)
        else d.copy(reminders = d.reminders.map { if (it.id == r.id) r else it })
    }

    fun deleteReminder(id: String) = update { it.copy(reminders = it.reminders.filter { r -> r.id != id }).withTomb(SyncMerge.REMINDERS, id) }

    fun toggleReminder(id: String) = update { d ->
        d.copy(reminders = d.reminders.map { if (it.id == id) it.copy(enabled = !it.enabled, updatedAt = System.currentTimeMillis()) else it })
    }

    fun saveMeal(m0: Meal) = update { d ->
        val m = m0.copy(updatedAt = System.currentTimeMillis())
        if (d.meals.none { it.id == m.id }) d.copy(meals = listOf(m) + d.meals)
        else d.copy(meals = d.meals.map { if (it.id == m.id) m else it })
    }

    fun deleteMeal(id: String) = update { it.copy(meals = it.meals.filter { m -> m.id != id }).withTomb(SyncMerge.MEALS, id) }

    fun saveSymptom(s0: Symptom) = update { d ->
        val s = s0.copy(updatedAt = System.currentTimeMillis())
        if (d.symptoms.none { it.id == s.id }) d.copy(symptoms = listOf(s) + d.symptoms)
        else d.copy(symptoms = d.symptoms.map { if (it.id == s.id) s else it })
    }

    fun deleteSymptom(id: String) = update { it.copy(symptoms = it.symptoms.filter { s -> s.id != id }).withTomb(SyncMerge.SYMPTOMS, id) }

    fun saveMedication(m0: Medication) = update { d ->
        val m = m0.copy(updatedAt = System.currentTimeMillis())
        if (d.medications.none { it.id == m.id }) d.copy(medications = listOf(m) + d.medications)
        else d.copy(medications = d.medications.map { if (it.id == m.id) m else it })
    }

    fun deleteMedication(id: String) = update { it.copy(medications = it.medications.filter { m -> m.id != id }).withTomb(SyncMerge.MEDICATIONS, id) }

    fun resetAll() {
        if (_practice.value) return
        val old = _data.value
        // Mantém a conta Google vinculada e o tour já visto
        val fresh = defaultData().let {
            it.copy(settings = it.settings.copy(
                googleEmail = old.settings.googleEmail,
                googleName = old.settings.googleName,
                tourSeen = old.settings.tourSeen,
            ))
        }
        _data.value = fresh
        saveQueue.trySend(fresh)
        _unlocked.value = true
        ReminderScheduler.sync(getApplication(), old.reminders, fresh.reminders)
    }
}
