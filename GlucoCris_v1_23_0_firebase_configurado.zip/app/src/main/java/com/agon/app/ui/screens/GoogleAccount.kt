package com.agon.app.ui.screens

import android.app.Activity
import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.cloud.CloudState
import com.agon.app.cloud.CloudStatus
import com.agon.app.data.GlucoViewModel
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.tourTarget
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.agon.app.ui.theme.glucoColors
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException

/** ID do cliente web gerado pelo google-services.json (existe só depois de ativar o Google no Firebase Auth). */
private fun webClientId(context: Context): String? {
    val id = context.resources.getIdentifier("default_web_client_id", "string", context.packageName)
    return if (id != 0) context.getString(id) else null
}

/** Cliente de login Google (e-mail, nome e o token que o Firebase Auth troca pela sessão do backup). */
private fun googleClient(context: Context): GoogleSignInClient {
    val builder = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
        .requestEmail()
        .requestProfile()
    webClientId(context)?.let { builder.requestIdToken(it) }
    return GoogleSignIn.getClient(context, builder.build())
}

private fun googleErrorText(e: ApiException): String = when (e.statusCode) {
    12501, 12502 -> "Login cancelado."
    7 -> "Sem conexão com a internet. Conecte-se e tente de novo."
    10 -> "Login Google ainda não configurado para este app (cliente OAuth do Google Cloud)."
    else -> "Não foi possível entrar com o Google (código ${e.statusCode})."
}

/**
 * Inicia o login Google. [forceChooser] = true desconecta antes para sempre
 * mostrar a lista de contas (usado em "Alterar conta").
 */
@Composable
private fun rememberGoogleSignIn(
    onSuccess: (email: String, name: String, idToken: String?) -> Unit,
    onError: (String) -> Unit,
): (forceChooser: Boolean) -> Unit {
    val context = LocalContext.current
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode != Activity.RESULT_OK && result.data == null) {
            onError("Login cancelado.")
            return@rememberLauncherForActivityResult
        }
        try {
            val account = GoogleSignIn.getSignedInAccountFromIntent(result.data).getResult(ApiException::class.java)
            val email = account.email.orEmpty()
            if (email.isBlank()) {
                onError("O Google não retornou um e-mail. Tente outra conta.")
            } else {
                onSuccess(email, account.displayName.orEmpty(), account.idToken)
            }
        } catch (e: ApiException) {
            onError(googleErrorText(e))
        } catch (e: Exception) {
            onError("Não foi possível entrar com o Google.")
        }
    }
    return { forceChooser ->
        val client = googleClient(context)
        if (forceChooser) {
            client.signOut().addOnCompleteListener { launcher.launch(client.signInIntent) }
        } else {
            launcher.launch(client.signInIntent)
        }
    }
}

/** Primeira abertura: única opção é entrar com o Google (cria/vincula a conta ao app). */
@Composable
fun LoginScreen(vm: GlucoViewModel) {
    val g = glucoColors()
    var error by remember { mutableStateOf<String?>(null) }
    val signIn = rememberGoogleSignIn(
        onSuccess = { email, name, token ->
            vm.linkGoogle(email, name)
            vm.startBackup(token)
        },
        onError = { error = it },
    )
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(g.heroStart, g.bg))).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Gluco Cris ❤️", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 30.sp)
        Text(
            "Bem-vinda! Entre com sua conta Google para criar sua conta e vinculá-la ao app.",
            color = Color.White.copy(alpha = 0.92f),
            fontSize = 15.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 10.dp, bottom = 28.dp),
        )
        Row(
            Modifier
                .fillMaxWidth()
                .height(54.dp)
                .clip(RoundedCornerShape(27.dp))
                .background(Color.White)
                .clickable { error = null; signIn(false) }
                .padding(horizontal = 20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
            Box(Modifier.size(28.dp).clip(CircleShape).background(Color(0xFFF1F3F4)), contentAlignment = Alignment.Center) {
                Text("G", color = Color(0xFF4285F4), fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
            }
            Text(
                "Entrar com Google",
                color = Color(0xFF1F1F1F),
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                modifier = Modifier.padding(start = 12.dp),
            )
        }
        error?.let {
            Text(
                it,
                color = Color(0xFFFECACA),
                fontSize = 13.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(top = 16.dp),
            )
        }
        Text(
            "Seus registros continuam salvos neste aparelho.",
            color = Color.White.copy(alpha = 0.8f),
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 24.dp),
        )
    }
}

/** Card do Perfil: mostra a conta Google vinculada, com opção de alterar e de sair. */
@Composable
fun GoogleAccountCard(vm: GlucoViewModel, email: String, name: String) {
    val g = glucoColors()
    val practice by vm.practice.collectAsStateWithLifecycle()
    val cloud by vm.cloud.collectAsStateWithLifecycle()
    var message by remember { mutableStateOf<Pair<String, Boolean>?>(null) }
    val signIn = rememberGoogleSignIn(
        onSuccess = { newEmail, newName, token ->
            vm.linkGoogle(newEmail, newName)
            vm.startBackup(token)
            message = "Conta alterada para $newEmail." to true
        },
        onError = { message = it to false },
    )
    GCard(Modifier.tourTarget("profile_account")) {
        Text("Conta Google", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        if (name.isNotBlank()) {
            Text(name, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, modifier = Modifier.padding(top = 6.dp))
        }
        Text("E-mail", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 8.dp))
        Row(
            Modifier
                .fillMaxWidth()
                .padding(top = 6.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(g.inputBg)
                .padding(start = 14.dp, top = 6.dp, bottom = 6.dp, end = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                email,
                color = g.ink,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            Text(
                "Alterar",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier
                    .padding(start = 6.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(g.violet)
                    .clickable {
                        if (practice) message = "Simulação: o Alterar não é executado." to true
                        else { message = null; signIn(true) }
                    }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            )
            Text(
                "Sair",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier
                    .padding(start = 6.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(g.red)
                    .clickable {
                        if (practice) message = "Simulação: o Sair não é executado." to true
                        else vm.logout()
                    }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
            )
        }
        message?.let { (text, ok) ->
            Text(text, color = if (ok) g.green else g.red, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
        }
        Text("Backup na nuvem", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 14.dp))
        Text(
            cloudLine(cloud),
            color = if (cloud.state == CloudState.OK) g.green else if (cloud.state == CloudState.ERROR) g.red else g.ink,
            fontSize = 13.sp,
            modifier = Modifier.padding(top = 4.dp),
        )
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            when (cloud.state) {
                CloudState.SIGNED_OUT -> CloudButton("Ativar backup", g.violet) {
                    if (practice) message = "Simulação: o backup não é executado." to true else signIn(false)
                }
                CloudState.ACCOUNT_MISMATCH -> {
                    CloudButton("Usar dados desta conta", g.red) { vm.resolveAccountMismatch(replaceLocalWithCloud = true) }
                    CloudButton("Juntar com esta conta", g.violet) { vm.resolveAccountMismatch(replaceLocalWithCloud = false) }
                }
                CloudState.SYNCING -> {}
                else -> {
                    CloudButton("Sincronizar agora", g.violet) { vm.syncNow() }
                    CloudButton("Restaurar da nuvem", g.muted) { vm.syncNow(restore = true) }
                }
            }
        }
        if (cloud.state == CloudState.ACCOUNT_MISMATCH) {
            Text(
                "\"Usar dados desta conta\" troca os dados do aparelho pelos da conta atual. \"Juntar\" envia os do aparelho e traz os da conta.",
                color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp),
            )
        }
    }
}

private fun cloudLine(s: CloudStatus): String {
    val last = if (s.lastSyncAt > 0) " Último backup: " + java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale("pt", "BR")).format(java.util.Date(s.lastSyncAt)) + "." else ""
    return when (s.state) {
        CloudState.OK -> "Em dia." + last
        CloudState.IDLE -> if (s.message.isBlank()) "Pronto para sincronizar." + last else s.message + last
        CloudState.SYNCING -> "Sincronizando..."
        else -> s.message + last
    }
}

@Composable
private fun CloudButton(text: String, color: Color, onClick: () -> Unit) {
    Text(
        text,
        color = Color.White,
        fontWeight = FontWeight.Bold,
        fontSize = 12.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(color)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
    )
}
