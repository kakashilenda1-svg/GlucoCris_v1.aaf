package com.agon.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.core.view.WindowCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.agon.app.data.GlucoViewModel
import com.agon.app.ui.components.LoadingState
import com.agon.app.ui.screens.CareScreen
import com.agon.app.ui.screens.GlucoseFormScreen
import com.agon.app.ui.screens.GlucoseListScreen
import com.agon.app.ui.screens.HistoryScreen
import com.agon.app.ui.screens.HomeScreen
import com.agon.app.ui.screens.InsulinFormScreen
import com.agon.app.ui.screens.InsulinListScreen
import com.agon.app.ui.screens.LockScreen
import com.agon.app.ui.screens.LoginScreen
import com.agon.app.ui.screens.TourOverlay
import com.agon.app.ui.screens.MedsScreen
import com.agon.app.ui.screens.MoreScreen
import com.agon.app.ui.screens.RemindersScreen
import com.agon.app.ui.screens.ReportScreen
import com.agon.app.ui.screens.SettingsScreen
import com.agon.app.ui.screens.StatsScreen
import com.agon.app.ui.screens.InsulinLocatorScreen
import com.agon.app.ui.screens.CrisIaScreen
import com.agon.app.ui.theme.AgonAppTheme
import com.agon.app.ui.components.tourTarget
import com.agon.app.ui.theme.glucoColors

class MainActivity : ComponentActivity() {
    /** Na simulação do tour as preferências vão para arquivos temporários (nada real é alterado). */
    override fun getSharedPreferences(name: String, mode: Int): android.content.SharedPreferences =
        super.getSharedPreferences(com.agon.app.data.PracticeMode.map(name), mode)

    private fun handleCrisIntent(i: android.content.Intent?) {
        if (i != null && i.hasExtra(com.agon.app.localai.CrisBackgroundTasks.EXTRA_CONV_ID)) {
            com.agon.app.localai.CrisOpenRequest.convId.value =
                i.getStringExtra(com.agon.app.localai.CrisBackgroundTasks.EXTRA_CONV_ID).orEmpty()
            i.removeExtra(com.agon.app.localai.CrisBackgroundTasks.EXTRA_CONV_ID)
        }
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleCrisIntent(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        handleCrisIntent(intent)
        setContent {
            val vm: GlucoViewModel = viewModel()
            val data by vm.data.collectAsStateWithLifecycle()
            val ready by vm.ready.collectAsStateWithLifecycle()
            val unlocked by vm.unlocked.collectAsStateWithLifecycle()
            val appContext = androidx.compose.ui.platform.LocalContext.current
            // Instalação nova: a IA local é baixada antes do login (aparelhos com pouca RAM não são obrigados)
            var gateDone by remember {
                mutableStateOf(
                    com.agon.app.localai.LocalModelManager.get(appContext).isInstalled() ||
                        !com.agon.app.ui.screens.deviceCanRunLocalAi(appContext),
                )
            }
            val dark = data.settings.darkMode ?: androidx.compose.foundation.isSystemInDarkTheme()
            AgonAppTheme(darkTheme = dark, blueTheme = data.settings.blueTheme) {
                val g = glucoColors()
                val view = androidx.compose.ui.platform.LocalView.current
                if (!view.isInEditMode) {
                    SideEffect {
                        val window = (view.context as? android.app.Activity)?.window ?: return@SideEffect
                        WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !dark && ready && unlocked && data.settings.googleEmail.isNotBlank()
                    }
                }
                when {
                    !ready -> Box(
                        Modifier
                            .fillMaxSize()
                            .background(g.bg),
                    ) { LoadingState() }
                    data.settings.googleEmail.isBlank() && !gateDone ->
                        com.agon.app.ui.screens.CrisModelGateScreen { gateDone = true }
                    data.settings.googleEmail.isBlank() -> LoginScreen(vm)
                    !unlocked -> LockScreen(vm, data.settings.displayName)
                    else -> MainApp(vm)
                }
            }
        }
    }
}

private data class Tab(val route: String, val label: String, val icon: ImageVector)

@Composable
private fun MainApp(vm: GlucoViewModel) {
    val nav = rememberNavController()
    // A tela principal aparece primeiro; a IA local é preparada depois, em segundo plano e sem bloquear a interface.
    val appCtx = androidx.compose.ui.platform.LocalContext.current
    // Gemini: conexão com o proxy e modelo que funciona ficam prontos já na abertura (em segundo plano, sem atraso na tela).
    androidx.compose.runtime.LaunchedEffect(Unit) { com.agon.app.data.CrisGemini.warmUp(appCtx) }
    androidx.compose.runtime.LaunchedEffect(Unit) {
        kotlinx.coroutines.delay(4_000)
        com.agon.app.localai.LocalAiEngine.get(appCtx).prewarm()
    }
    val g = glucoColors()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val tab = Routes.tabOf(route)
    val showBar = route == null || route in Routes.tabs
    LaunchedEffect(Unit) {
        if (!vm.data.value.settings.tourSeen) vm.offerTour()
    }
    // Toque na notificação da Cris: abre a conversa correspondente com a resposta já salva.
    val openReq by com.agon.app.localai.CrisOpenRequest.convId
    LaunchedEffect(openReq) {
        val id = openReq ?: return@LaunchedEffect
        if (id.isNotBlank()) com.agon.app.localai.CrisConversationStore.setActive(appCtx, id)
        nav.navigate(Routes.CRIS_IA) {
            popUpTo(Routes.CRIS_IA) { inclusive = true }
            launchSingleTop = true
        }
        com.agon.app.localai.CrisOpenRequest.convId.value = null
    }
    Box(Modifier.fillMaxSize()) {
    Scaffold(
        containerColor = g.bg,
        bottomBar = {
            if (showBar) {
                NavigationBar(containerColor = g.card) {
                    listOf(
                        Tab(Routes.HOME, "Início", Icons.Filled.Home),
                        Tab(Routes.GLUCOSE, "Glicose", Icons.Filled.WaterDrop),
                        Tab(Routes.INSULIN, "Insulina", Icons.Filled.Vaccines),
                        Tab(Routes.REMINDERS, "Lembretes", Icons.Filled.Notifications),
                        Tab(Routes.HISTORY, "Histórico", Icons.Filled.History),
                        Tab(Routes.FOOD, "Alimentação", Icons.Filled.Restaurant),
                        Tab(Routes.MORE, "Mais", Icons.Filled.MoreHoriz),
                    ).forEach { item ->
                        NavigationBarItem(
                            selected = tab == item.route,
                            onClick = { Routes.goTab(nav, item.route) },
                            modifier = Modifier.tourTarget("tab_" + item.route),
                            icon = { Icon(item.icon, item.label) },
                            label = { Text(item.label, maxLines = 1, style = androidx.compose.material3.MaterialTheme.typography.labelSmall) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = g.violet,
                                selectedTextColor = g.violet,
                                indicatorColor = g.lilacSoft,
                                unselectedIconColor = g.muted,
                                unselectedTextColor = g.muted,
                            ),
                        )
                    }
                }
            }
        },
    ) { padding ->
        AppNav(vm, nav, Modifier.padding(padding).consumeWindowInsets(padding))
    }
    TourOverlay(vm, nav)
    // Depois do tour (concluído ou cancelado), pergunta uma única vez se pode baixar a IA local
    val tourSeen = vm.data.collectAsStateWithLifecycle().value.settings.tourSeen
    if (tourSeen) com.agon.app.ui.screens.CrisLocalAiOfferDialog { nav.navigate(Routes.CRIS_AI_SETTINGS) }
    }
}

@Composable
private fun AppNav(vm: GlucoViewModel, nav: NavHostController, modifier: Modifier) {
    NavHost(
        nav,
        startDestination = Routes.HOME,
        modifier = modifier,
        enterTransition = { androidx.compose.animation.EnterTransition.None },
        exitTransition = { androidx.compose.animation.ExitTransition.None },
        popEnterTransition = { androidx.compose.animation.EnterTransition.None },
        popExitTransition = { androidx.compose.animation.ExitTransition.None },
    ) {
        composable(Routes.HOME) { HomeScreen(vm, nav) }
        composable(Routes.GLUCOSE) { GlucoseListScreen(vm, nav) }
        composable(Routes.INSULIN) { InsulinListScreen(vm, nav) }
        composable(Routes.REMINDERS) { RemindersScreen(vm) }
        composable(Routes.HISTORY) { HistoryScreen(vm, nav) }
        composable(Routes.MORE) { MoreScreen(nav) }
        composable(Routes.PROFILE) { com.agon.app.ui.screens.ProfileScreen(vm) }
        composable(Routes.STATS) { StatsScreen(vm, nav) }
        composable(Routes.CARE) { CareScreen(vm, nav) }
        composable(Routes.MEDS) { MedsScreen(vm, nav) }
        composable(Routes.REPORT) { ReportScreen(vm, nav) }
        composable(Routes.SETTINGS) { SettingsScreen(vm, nav) }
        composable(Routes.LOCATOR) { InsulinLocatorScreen(nav) }
        composable(Routes.CRIS_IA) { CrisIaScreen(vm, nav) }
        composable(Routes.CRIS_VOICE) { com.agon.app.ui.screens.CrisVoiceScreen(vm, nav) }
        composable(Routes.CRIS_AI_SETTINGS) { com.agon.app.ui.screens.CrisLocalAiScreen(nav) }
        composable(Routes.FOOD) { com.agon.app.ui.screens.FoodMainScreen(vm, nav) }
        composable(Routes.FOOD_SEARCH) { com.agon.app.ui.screens.FoodSearchScreen(vm, nav) }
        composable(Routes.FOOD_DETAIL) { com.agon.app.ui.screens.FoodDetailScreen(vm, nav) }
        composable(Routes.FOOD_DIARY) { com.agon.app.ui.screens.FoodDiaryScreen(vm, nav) }
        composable(Routes.FOOD_REPORTS) { com.agon.app.ui.screens.FoodReportsScreen(vm, nav) }
        composable(Routes.FOOD_BARCODE) { com.agon.app.ui.screens.FoodBarcodeScreen(vm, nav) }
        composable(Routes.FOOD_SMART_SCAN) { com.agon.app.ui.screens.FoodSmartScannerScreen(vm, nav) }
        composable(Routes.FOOD_RECIPES) { com.agon.app.ui.screens.RecipeSearchScreen(vm, nav) }
        composable(Routes.FOOD_RECIPE_DETAIL) { com.agon.app.ui.screens.RecipeDetailScreen(vm, nav) }
        composable(Routes.FOOD_MEAL_PLAN_DETAIL) { com.agon.app.ui.screens.MealPlanDetailScreen(vm, nav) }
        composable(Routes.HELP_CENTER) { com.agon.app.ui.screens.HelpCenterScreen(nav, vm) }
        composable(Routes.FOOD_TOOLS) { com.agon.app.ui.screens.FoodToolsHubScreen(vm, nav) }
        composable(Routes.FOOD_CUSTOM) { com.agon.app.ui.screens.FoodCustomScreen(nav) }
        composable(Routes.FOOD_MEAL_BUILDER) { com.agon.app.ui.screens.FoodMealBuilderScreen(vm, nav) }
        composable(Routes.FOOD_FAV_MEALS) { com.agon.app.ui.screens.FoodFavMealsScreen(vm, nav) }
        composable(Routes.FOOD_BOLUS) { com.agon.app.ui.screens.FoodBolusScreen(vm, nav) }
        composable(Routes.FOOD_GLUCOSE_LINK) { com.agon.app.ui.screens.FoodGlucoseLinkScreen(vm, nav) }
        composable(Routes.FOOD_PLATE) { com.agon.app.ui.screens.FoodPlateScreen(vm, nav) }
        composable(Routes.WATER) { com.agon.app.ui.screens.WaterTrackerScreen(vm, nav) }
        composable(
            "glicose_form?id={id}",
            arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null }),
        ) { entry ->
            GlucoseFormScreen(vm, nav, entry.arguments?.getString("id"))
        }
        composable(Routes.GLUCOSE_FORM) { GlucoseFormScreen(vm, nav, null) }
        composable(
            "insulina_form?id={id}",
            arguments = listOf(navArgument("id") { type = NavType.StringType; nullable = true; defaultValue = null }),
        ) { entry ->
            InsulinFormScreen(vm, nav, entry.arguments?.getString("id"))
        }
        composable(Routes.INSULIN_FORM) { InsulinFormScreen(vm, nav, null) }
    }
}

@Suppress("unused")
private val keepWhite = Color.White
