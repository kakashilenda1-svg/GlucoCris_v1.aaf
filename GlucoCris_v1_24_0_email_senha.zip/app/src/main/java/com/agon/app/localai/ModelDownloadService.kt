package com.agon.app.localai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.agon.app.MainActivity
import com.agon.app.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Mantém o processo vivo (serviço em primeiro plano, tipo dataSync) enquanto o [LocalModelManager] baixa o modelo,
 * mostrando o progresso numa notificação com botão Pausar. O download em si continua sendo feito pelo LocalModelManager.
 */
class ModelDownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var watcher: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureChannel()
        ServiceCompat.startForeground(
            this, NOTIF_ID, build("Preparando o download…", 0, 0, true),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC,
        )
        val mgr = LocalModelManager.get(this)
        if (intent?.action == ACTION_PAUSE) {
            mgr.pause()
            finish(null)
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_CANCEL) {
            mgr.cancel()
            finish(null)
            return START_NOT_STICKY
        }
        if (watcher?.isActive == true) return START_NOT_STICKY
        watcher = scope.launch {
            var seen = false
            var lastPct = -1
            // Se o download não chegar a começar, não deixa o serviço preso
            val guard = launch { delay(20_000); if (!seen) finish(null) }
            mgr.state.collect { st ->
                when (st) {
                    is ModelState.Downloading -> {
                        seen = true
                        guard.cancel()
                        val pct = if (st.total > 0) (st.done * 100 / st.total).toInt() else 0
                        val sp = mgr.speedBytesPerSec.value
                        val key = pct * 1000 + (sp / (256 * 1024)).toInt().coerceAtMost(999)
                        if (key != lastPct) {
                            lastPct = key
                            val speedTxt = if (sp > 0) " · " + LocalModelManager.fmtBytes(sp) + "/s" else ""
                            notifyNow(build(LocalModelManager.fmtBytes(st.done) + " de " + LocalModelManager.fmtBytes(st.total) + " (" + pct + "%)" + speedTxt, pct, 100, false))
                        }
                    }
                    is ModelState.Verifying -> {
                        seen = true
                        guard.cancel()
                        notifyNow(build("Conferindo se o arquivo está íntegro…", 0, 0, true))
                    }
                    is ModelState.Ready -> finish("A IA da Cris está pronta! 💜")
                    is ModelState.Failed -> finish("Download interrompido. Abra o app para continuar.")
                    is ModelState.Paused -> if (seen) finish(null)
                    is ModelState.Missing -> if (seen) finish(null)
                }
            }
        }
        return START_NOT_STICKY
    }

    /** Android 15+: serviços dataSync têm limite de tempo por dia; ao estourar, pausa (retoma ao reabrir o app). */
    override fun onTimeout(startId: Int, fgsType: Int) {
        LocalModelManager.get(this).pause()
        finish("Download pausado pelo Android. Abra o app para continuar.")
    }

    override fun onDestroy() {
        watcher?.cancel()
        super.onDestroy()
    }

    private fun finish(message: String?) {
        watcher?.cancel()
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        if (message != null) {
            val n = NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(R.drawable.ic_stat_drop)
                .setContentTitle("IA da Cris")
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setContentIntent(openAppIntent())
                .build()
            notifyNow(n, DONE_ID)
        }
        stopSelf()
    }

    private fun notifyNow(n: Notification, id: Int = NOTIF_ID) {
        try {
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, n)
        } catch (_: Exception) {
        }
    }

    private fun openAppIntent(): PendingIntent =
        PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )

    private fun build(text: String, progress: Int, max: Int, indeterminate: Boolean): Notification {
        val pause = PendingIntent.getService(
            this, 1,
            Intent(this, ModelDownloadService::class.java).setAction(ACTION_PAUSE),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val cancel = PendingIntent.getService(
            this, 2,
            Intent(this, ModelDownloadService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_drop)
            .setContentTitle("Baixando a IA da Cris")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(max, progress, indeterminate)
            .setContentIntent(openAppIntent())
            .addAction(0, "Pausar", pause)
            .addAction(0, "Cancelar", cancel)
            .build()
    }

    private fun ensureChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (nm.getNotificationChannel(CHANNEL) == null) {
                nm.createNotificationChannel(NotificationChannel(CHANNEL, "Download da IA da Cris", NotificationManager.IMPORTANCE_LOW))
            }
        }
    }

    companion object {
        private const val CHANNEL = "cris_ai_download"
        private const val NOTIF_ID = 4711
        private const val DONE_ID = 4712
        const val ACTION_PAUSE = "com.agon.app.localai.PAUSE_DOWNLOAD"
        const val ACTION_CANCEL = "com.agon.app.localai.CANCEL_DOWNLOAD"

        fun begin(context: Context) {
            try {
                ContextCompat.startForegroundService(context, Intent(context, ModelDownloadService::class.java))
            } catch (_: Exception) {
            }
        }
    }
}
