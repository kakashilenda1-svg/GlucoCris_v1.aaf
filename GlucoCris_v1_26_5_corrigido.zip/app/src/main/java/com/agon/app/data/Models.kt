package com.agon.app.data

import kotlinx.serialization.Serializable
import java.util.Calendar
import java.util.UUID

@Serializable
data class GlucoseEntry(
    val id: String,
    val value: Double,
    val unit: String,
    val at: Long,
    val context: String,
    val notes: String = "",
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
)

@Serializable
data class InsulinEntry(
    val id: String,
    val kind: String,
    val name: String,
    val dose: Double,
    val unit: String = "UI",
    val at: Long,
    val notes: String = "",
    val createdAt: Long = 0L,
    val updatedAt: Long = 0L,
)

@Serializable
data class Reminder(
    val id: String,
    val kind: String,
    val title: String,
    val hour: Int,
    val minute: Int,
    val days: List<Int>,
    val enabled: Boolean = true,
    val soundId: String = "suave",
    val notes: String = "",
    val updatedAt: Long = 0L,
)

@Serializable
data class Meal(
    val id: String,
    val type: String,
    val description: String,
    val carbs: Double? = null,
    val at: Long,
    val notes: String = "",
    val updatedAt: Long = 0L,
)

@Serializable
data class Symptom(
    val id: String,
    val name: String,
    val intensity: String,
    val at: Long,
    val notes: String = "",
    val updatedAt: Long = 0L,
)

@Serializable
data class Medication(
    val id: String,
    val name: String,
    val dose: String,
    val schedule: String,
    val notes: String = "",
    val active: Boolean = true,
    val updatedAt: Long = 0L,
)

@Serializable
data class ProfileMed(
    val id: String = "",
    val name: String = "",
    val dose: String = "",
    val frequency: String = "",
    val times: String = "",
    val notes: String = "",
)

@Serializable
data class Settings(
    val pinEnabled: Boolean = false,
    val pin: String = "",
    val darkMode: Boolean? = null,
    val targetLow: Int = 70,
    val targetHigh: Int = 180,
    val preferredUnit: String = "mg/dL",
    val displayName: String = "Maria Cristina",
    // Perfil (o nome completo é o próprio displayName)
    val birthDate: String = "",
    val cpf: String = "",
    val cep: String = "",
    val street: String = "",
    val number: String = "",
    val complement: String = "",
    val district: String = "",
    val city: String = "",
    val state: String = "",
    // Humor escolhido na tela inicial
    val mood: String = "",
    val moodAt: Long = 0L,
    // Ficha ampliada (opcional)
    val phoneCountry: String = "+55",
    val phoneDdd: String = "",
    val phoneNumber: String = "",
    val heightCm: String = "",
    val weightKg: String = "",
    val bloodType: String = "",
    val diabetesType: String = "",
    val insulinKind: String = "",
    val insulinBasalName: String = "",
    val insulinMealName: String = "",
    val insulinNotes: String = "",
    val allergies: String = "",
    val allergyNotes: String = "",
    val foodRestrictions: String = "",
    val profileMedications: List<ProfileMed> = emptyList(),
    val profileUpdatedAt: Long = 0L,
    val sharePhoneByDefault: Boolean = false,
    // Conta Google vinculada ao app e controle do tour de ajuda
    val googleEmail: String = "",
    val googleName: String = "",
    val tourSeen: Boolean = false,
    // Tema azul com cinza discreto (alternativa às cores originais)
    val blueTheme: Boolean = false,
    // Figurinhas do humor: "emoji" (padrão) ou "bruxo" (bruxinho)
    val moodStyle: String = "emoji",
    // Carimbo da última alteração dos ajustes/perfil (usado só na sincronização)
    val settingsUpdatedAt: Long = 0L,
)

/** Registro de exclusão (precisa ir à nuvem para a exclusão valer nos outros aparelhos). */
@Serializable
data class Tombstone(val col: String, val id: String, val at: Long)

@Serializable
data class AppData(
    val glucose: List<GlucoseEntry> = emptyList(),
    val insulin: List<InsulinEntry> = emptyList(),
    val reminders: List<Reminder> = emptyList(),
    val meals: List<Meal> = emptyList(),
    val symptoms: List<Symptom> = emptyList(),
    val medications: List<Medication> = emptyList(),
    val settings: Settings = Settings(),
    val tombstones: List<Tombstone> = emptyList(),
)

val GLUCOSE_CONTEXT_LABEL = linkedMapOf(
    "jejum" to "Em jejum",
    "antes_refeicao" to "Antes da refeição",
    "depois_refeicao" to "Depois da refeição",
    "antes_dormir" to "Antes de dormir",
    "madrugada" to "Madrugada",
    "outro" to "Outro momento",
)

val MEAL_LABEL = linkedMapOf(
    "cafe" to "Café da manhã",
    "almoco" to "Almoço",
    "lanche" to "Lanche",
    "jantar" to "Jantar",
    "ceia" to "Ceia",
    "outro" to "Outro",
)

val INTENSITY_LABEL = linkedMapOf(
    "leve" to "Leve",
    "moderado" to "Moderado",
    "forte" to "Forte",
)

val WEEKDAYS = listOf("Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb")

fun uid(): String = UUID.randomUUID().toString()

/** Registros de exemplo da primeira abertura: o prefixo "demo-" os mantém FORA do backup na nuvem. */
fun demoId(): String = "demo-" + UUID.randomUUID().toString()

fun defaultData(): AppData {
    val now = System.currentTimeMillis()
    fun at(daysAgo: Int, hour: Int, minute: Int): Long {
        val c = Calendar.getInstance()
        c.timeInMillis = now
        c.add(Calendar.DAY_OF_YEAR, -daysAgo)
        c.set(Calendar.HOUR_OF_DAY, hour)
        c.set(Calendar.MINUTE, minute)
        c.set(Calendar.SECOND, 0)
        c.set(Calendar.MILLISECOND, 0)
        return c.timeInMillis
    }
    fun g(value: Double, daysAgo: Int, hour: Int, minute: Int, context: String, notes: String = ""): GlucoseEntry {
        val t = at(daysAgo, hour, minute)
        return GlucoseEntry(demoId(), value, "mg/dL", t, context, notes, t, t)
    }
    fun ins(name: String, dose: Double, daysAgo: Int, hour: Int, minute: Int): InsulinEntry {
        val t = at(daysAgo, hour, minute)
        return InsulinEntry(demoId(), "aplicacao", name, dose, "UI", t, "", t, t)
    }
    return AppData(
        glucose = listOf(
            g(118.0, 0, 7, 10, "jejum", "Acordou bem"),
            g(142.0, 0, 12, 40, "depois_refeicao", "Almoço com arroz"),
            g(126.0, 1, 7, 5, "jejum"),
            g(168.0, 1, 20, 15, "depois_refeicao"),
            g(109.0, 2, 7, 20, "jejum"),
            g(134.0, 2, 13, 5, "depois_refeicao"),
            g(98.0, 3, 22, 40, "antes_dormir"),
            g(121.0, 3, 7, 0, "jejum"),
            g(155.0, 4, 19, 30, "depois_refeicao"),
            g(112.0, 5, 7, 15, "jejum"),
            g(139.0, 6, 12, 50, "depois_refeicao"),
        ).sortedByDescending { it.at },
        insulin = listOf(
            ins("Insulina glargina", 14.0, 0, 21, 30),
            ins("Insulina asparte", 6.0, 0, 12, 10),
            ins("Insulina glargina", 14.0, 1, 21, 25),
            ins("Insulina asparte", 5.0, 1, 19, 0),
            ins("Insulina glargina", 14.0, 2, 21, 40),
        ),
        reminders = listOf(
            Reminder(demoId(), "glicose", "Glicemia em jejum", 7, 0, listOf(0, 1, 2, 3, 4, 5, 6), true, "suave", "Medir antes do café"),
            Reminder(demoId(), "glicose", "Glicemia pós-almoço", 14, 0, listOf(1, 2, 3, 4, 5), true, "claro", "Cerca de 2 horas após a refeição"),
            Reminder(demoId(), "insulina", "Glargina à noite", 21, 30, listOf(0, 1, 2, 3, 4, 5, 6), true, "pulso", "Dose basal"),
        ),
        meals = listOf(
            Meal(demoId(), "cafe", "Café, pão integral e queijo branco", 28.0, at(0, 7, 40), ""),
            Meal(demoId(), "almoco", "Arroz, feijão, frango grelhado e salada", 55.0, at(0, 12, 15), ""),
        ),
        symptoms = listOf(Symptom(demoId(), "Sede", "leve", at(2, 16, 20), "Passou após água")),
        medications = listOf(
            Medication(demoId(), "Insulina glargina", "14 UI", "Todos os dias, 21:30", "Basal. Não misturar com outras insulinas.", true),
            Medication(demoId(), "Insulina asparte", "Conforme refeição", "Antes das principais refeições", "Ajustar com a equipe de saúde.", true),
            Medication(demoId(), "Metformina", "500 mg", "Café e jantar", "Tomar junto com a refeição.", true),
        ),
        settings = Settings(),
    )
}
