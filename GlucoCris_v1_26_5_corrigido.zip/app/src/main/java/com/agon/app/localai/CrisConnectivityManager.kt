package com.agon.app.localai

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/** Informa se há internet de verdade (com capacidade validada) para rotular respostas e decidir fallback. */
object CrisConnectivityManager {
    fun isOnline(context: Context): Boolean = try {
        val cm = context.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val caps = cm.getNetworkCapabilities(cm.activeNetwork)
        caps != null &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
    } catch (_: Exception) {
        false
    }

    fun observe(context: Context): Flow<Boolean> = callbackFlow {
        val app = context.applicationContext
        val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { trySend(isOnline(app)) }
            override fun onLost(network: Network) { trySend(isOnline(app)) }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) { trySend(isOnline(app)) }
        }
        trySend(isOnline(app))
        try { cm.registerDefaultNetworkCallback(cb) } catch (_: Exception) {}
        awaitClose { try { cm.unregisterNetworkCallback(cb) } catch (_: Exception) {} }
    }.distinctUntilChanged()
}
