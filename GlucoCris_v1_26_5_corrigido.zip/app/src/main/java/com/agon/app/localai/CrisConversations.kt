package com.agon.app.localai

import android.content.Context
import com.agon.app.data.CrisPrefs
import com.agon.app.data.uid
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.util.concurrent.Executors

@Serializable
data class CrisConvMsg(val fromUser: Boolean, val text: String, val source: String = "", val media: String = "")

/** Linha da lista de histórico (leve: não carrega as mensagens). */
@Serializable
data class CrisConvMeta(
    val id: String,
    val title: String,
    val preview: String,
    val createdAt: Long,
    val updatedAt: Long,
)

@Serializable
data class CrisConversation(
    val id: String,
    val createdAt: Long,
    val updatedAt: Long,
    val title: String,
    val messages: List<CrisConvMsg>,
)

/**
 * Histórico de conversas da Cris IA. Cada conversa é um arquivo JSON próprio (id único) em filesDir,
 * mais um índice leve para listar. Tudo roda em uma única thread de IO (ordem garantida) e a gravação
 * é atômica (arquivo temporário + rename). Os dados ficam só neste aparelho e sobrevivem a reinício.
 */
object CrisConversationStore {
    private const val DIR = "cris_conversations"
    private const val INDEX = "index.json"
    private const val PREFS = "cris_conv_state"
    private const val MAX_MSGS = 500
    private const val WINDOW = 8

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private val io = Executors.newSingleThreadExecutor { r -> Thread(r, "cris-conv-io").apply { isDaemon = true } }
        .asCoroutineDispatcher()
    private val scope = CoroutineScope(SupervisorJob() + io)

    private fun dir(c: Context): File = File(c.applicationContext.filesDir, DIR).apply { mkdirs() }
    private fun safeId(id: String) = id.filter { it.isLetterOrDigit() || it == '-' || it == '_' }
    private fun file(c: Context, id: String) = File(dir(c), safeId(id) + ".json")
    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun writeAtomic(f: File, text: String) {
        val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(text, Charsets.UTF_8)
        if (!tmp.renameTo(f)) {
            f.delete()
            tmp.renameTo(f)
        }
    }

    private fun readConv(c: Context, id: String): CrisConversation? {
        val f = file(c, id)
        if (!f.exists()) return null
        return try {
            json.decodeFromString<CrisConversation>(f.readText(Charsets.UTF_8))
        } catch (_: Exception) {
            null
        }
    }

    private fun metaOf(conv: CrisConversation) = CrisConvMeta(
        id = conv.id,
        title = conv.title,
        preview = conv.messages.lastOrNull()?.text.orEmpty().replace(Regex("\\s+"), " ").trim().take(90),
        createdAt = conv.createdAt,
        updatedAt = conv.updatedAt,
    )

    private fun readIndex(c: Context): MutableList<CrisConvMeta> {
        val f = File(dir(c), INDEX)
        if (f.exists()) {
            try {
                return json.decodeFromString<List<CrisConvMeta>>(f.readText(Charsets.UTF_8)).toMutableList()
            } catch (_: Exception) {
                // cai para a reconstrução abaixo
            }
        }
        val rebuilt = (dir(c).listFiles { x -> x.name.endsWith(".json") && x.name != INDEX } ?: emptyArray())
            .mapNotNull { f -> readConv(c, f.nameWithoutExtension)?.let { metaOf(it) } }
            .toMutableList()
        writeIndex(c, rebuilt)
        return rebuilt
    }

    private fun writeIndex(c: Context, list: List<CrisConvMeta>) {
        writeAtomic(File(dir(c), INDEX), json.encodeToString(list))
    }

    fun makeTitle(msgs: List<CrisConvMsg>): String {
        val raw = msgs.firstOrNull { it.fromUser }?.text.orEmpty()
        val hadAttach = raw.contains("[Anexo:")
        val first = raw.replace(Regex("\\[Anexo:[^\\]]*\\]"), " ").replace(Regex("\\s+"), " ").trim()
        if (first.isBlank()) return if (hadAttach) "Conversa com anexo" else "Nova conversa"
        if (first.length <= 42) return first.trimEnd('?', '!', '.', ',', ';', ':').ifBlank { first }
        val cut = first.take(42)
        val sp = cut.lastIndexOf(' ')
        return (if (sp > 20) cut.take(sp) else cut).trimEnd(',', ';', ':', '.', ' ') + "…"
    }

    /** Conversa ativa (a última aberta). Na primeira execução importa o chat antigo, sem apagá-lo. */
    suspend fun loadActive(c: Context): CrisConversation? = withContext(io) {
        val p = prefs(c)
        val active = p.getString("active", "").orEmpty()
        if (active.isNotBlank()) return@withContext readConv(c, active)
        if (!p.getBoolean("legacy_migrated", false)) {
            p.edit().putBoolean("legacy_migrated", true).apply()
            val legacy = try { CrisPrefs.loadChat(c) } catch (_: Exception) { emptyList() }
            if (legacy.any { it.fromUser }) {
                val msgs = legacy.map { CrisConvMsg(it.fromUser, it.text, it.source) }
                val now = System.currentTimeMillis()
                val conv = CrisConversation(uid(), now, now, makeTitle(msgs), msgs)
                writeAtomic(file(c, conv.id), json.encodeToString(conv))
                val idx = readIndex(c)
                idx.add(metaOf(conv))
                writeIndex(c, idx)
                p.edit().putString("active", conv.id).apply()
                return@withContext conv
            }
        }
        null
    }

    suspend fun load(c: Context, id: String): CrisConversation? = withContext(io) { readConv(c, id) }

    suspend fun list(c: Context): List<CrisConvMeta> = withContext(io) {
        readIndex(c).sortedByDescending { it.updatedAt }
    }

    fun setActive(c: Context, id: String) {
        prefs(c).edit().putString("active", id).apply()
    }

    /** Grava em segundo plano (sobrevive ao fechamento da tela). Só salva se já houver mensagem da pessoa. */
    fun saveAsync(c: Context, id: String, createdAt: Long, msgs: List<CrisConvMsg>) {
        if (id.isBlank() || msgs.none { it.fromUser }) return
        val app = c.applicationContext
        val snapshot = msgs.takeLast(MAX_MSGS)
        scope.launch {
            try {
                val conv = CrisConversation(id, createdAt, System.currentTimeMillis(), makeTitle(snapshot), snapshot)
                writeAtomic(file(app, id), json.encodeToString(conv))
                val idx = readIndex(app)
                idx.removeAll { it.id == id }
                idx.add(metaOf(conv))
                writeIndex(app, idx)
                prefs(app).edit().putString("active", id).apply()
            } catch (t: Throwable) {
                android.util.Log.e("CrisConv", "Falha ao salvar conversa", t)
            }
        }
    }

    suspend fun delete(c: Context, id: String) = withContext(io) {
        file(c, id).delete()
        val idx = readIndex(c)
        idx.removeAll { it.id == id }
        writeIndex(c, idx)
        val p = prefs(c)
        if (p.getString("active", "") == id) p.edit().putString("active", "").apply()
    }

    /** Apaga todas as conversas salvas (usado por "Apagar histórico de conversas" nas configurações). */
    suspend fun clearAll(c: Context) = withContext(io) {
        dir(c).listFiles()?.forEach { it.delete() }
        prefs(c).edit().putString("active", "").apply()
    }

    private val PERSONAL = Regex(
        "\\b(meu|minha|meus|minhas|me chamo|sou|tenho|prefiro|quero|objetivo|preciso|lembre)\\b",
        RegexOption.IGNORE_CASE,
    )

    /**
     * Resumo contextual das mensagens ANTIGAS (fora da janela recente enviada ao modelo).
     * Extrativo (sem chamar o modelo, então não custa tempo): guarda o assunto inicial, dados pessoais e
     * perguntas/respostas anteriores em forma compacta. Só usa mensagens desta conversa.
     */
    fun contextSummary(all: List<CrisConvMsg>): String {
        val body = if (all.isNotEmpty() && !all.first().fromUser) all.drop(1) else all
        if (body.size <= WINDOW) return ""
        val older = body.dropLast(WINDOW)
        val lines = older.map { m ->
            val t = m.text.replace(Regex("\\s+"), " ").trim()
            if (m.fromUser) {
                "Pessoa: " + t.take(if (PERSONAL.containsMatchIn(t)) 200 else 110)
            } else {
                val firstSentence = t.split(Regex("(?<=[.!?])\\s+")).firstOrNull().orEmpty()
                "Cris: " + firstSentence.take(110)
            }
        }
        val budget = 1100
        var total = lines.sumOf { it.length + 1 }
        if (total <= budget) return lines.joinToString("\n")
        // Mantém o começo (assunto) e o fim (o mais recente); descarta o meio.
        val head = lines.take(2).toMutableList()
        val tail = ArrayDeque<String>()
        var used = head.sumOf { it.length + 1 }
        for (l in lines.drop(2).reversed()) {
            if (used + l.length + 1 > budget) break
            tail.addFirst(l)
            used += l.length + 1
        }
        return (head + "(…)" + tail).joinToString("\n")
    }
}
