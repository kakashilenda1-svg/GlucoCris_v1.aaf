package com.agon.app.localai

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Pesquisa geral na web via Tavily Search API (POST https://api.tavily.com/search).
 *
 * A CHAVE DA TAVILY NUNCA FICA NO APP. O app fala com um proxy próprio (pasta backend/tavily-proxy) que guarda
 * a chave em variável de ambiente e só repassa parâmetros permitidos. Sem proxy configurado, esta pesquisa fica
 * desligada e a Cris segue com Google Notícias, Wikipédia, Wikidata e PubMed.
 *
 * O Tavily só BUSCA. Quem lê os trechos e redige a resposta continua sendo o modelo local.
 */
enum class TavilyDepth(val wire: String, val credits: Int) { BASIC("basic", 1), ADVANCED("advanced", 2) }

/** Falha tipada, para a Cris explicar o motivo sem expor detalhes técnicos. */
sealed class TavilyResult {
    data class Ok(val hits: List<WebHit>, val credits: Int, val fromCache: Boolean) : TavilyResult()
    /** Busca feita, mas sem resultados (não é erro). */
    object Empty : TavilyResult()
    object Disabled : TavilyResult()
    object QuotaBlocked : TavilyResult()
    object InvalidKey : TavilyResult()
    object Timeout : TavilyResult()
    object Offline : TavilyResult()
    data class Failed(val code: Int) : TavilyResult()
}

/** Contador local (estimado) de créditos do mês. Reinicia sozinho na virada do mês. */
object TavilyCredits {
    private const val FILE = "cris_tavily_credits"
    private fun p(c: Context) = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    private fun month(now: Long = System.currentTimeMillis()) = SimpleDateFormat("yyyy-MM", Locale.US).format(Date(now))

    /** Cota mensal configurável (padrão 1.000 — mude conforme o plano da Tavily). */
    fun limit(c: Context): Int = p(c).getInt("limit", DEFAULT_LIMIT).coerceAtLeast(0)
    fun setLimit(c: Context, v: Int) = p(c).edit().putInt("limit", v.coerceAtLeast(0)).apply()

    /** Reserva de segurança: as buscas bloqueiam antes de chegar no teto. */
    fun reserve(c: Context): Int = p(c).getInt("reserve", DEFAULT_RESERVE).coerceAtLeast(0)
    fun setReserve(c: Context, v: Int) = p(c).edit().putInt("reserve", v.coerceAtLeast(0)).apply()

    @Synchronized
    fun used(c: Context): Int {
        val sp = p(c)
        return if (sp.getString("month", "") == month()) sp.getInt("used", 0) else 0
    }

    fun remaining(c: Context): Int = (limit(c) - reserve(c) - used(c)).coerceAtLeast(0)

    /** Reserva [cost] créditos ANTES da chamada (evita estourar a cota com chamadas simultâneas). Falso = bloqueado. */
    @Synchronized
    fun tryReserve(c: Context, cost: Int): Boolean {
        val sp = p(c)
        val now = month()
        val used = if (sp.getString("month", "") == now) sp.getInt("used", 0) else 0
        if (used + cost > limit(c) - reserve(c)) return false
        sp.edit().putString("month", now).putInt("used", used + cost).apply()
        return true
    }

    /** Ajusta a reserva com o valor real informado pelo servidor (ou devolve tudo se a chamada nem chegou lá). */
    @Synchronized
    fun settle(c: Context, reserved: Int, actual: Int) {
        val sp = p(c)
        val now = month()
        val used = if (sp.getString("month", "") == now) sp.getInt("used", 0) else 0
        sp.edit().putString("month", now).putInt("used", (used - reserved + actual).coerceAtLeast(0)).apply()
    }

    const val DEFAULT_LIMIT = 1_000
    const val DEFAULT_RESERVE = 50
}

object TavilySearch {
    private const val UA = "GlucoCris/1.19 (Android; pesquisa de apoio da Cris IA)"
    private const val CONNECT_MS = 6_000
    private const val READ_MS = 12_000          // Advanced é mais lento que Basic
    private const val MAX_RESULTS = 5
    private const val MAX_BODY = 400_000

    // Cache em memória: pesquisas repetidas não gastam crédito. Notícias vencem rápido; o resto dura mais.
    private const val CACHE_NEWS_MS = 15 * 60_000L
    private const val CACHE_DEFAULT_MS = 6 * 3_600_000L
    private class Entry(val at: Long, val hits: List<WebHit>)
    private val cache = HashMap<String, Entry>()

    // No máximo 1 chamada por vez ao Tavily (poupa créditos e a rede do aparelho).
    private val gate = Semaphore(1)

    fun isConfigured(): Boolean = proxyUrl().isNotBlank()

    private fun proxyUrl(): String = com.agon.app.BuildConfig.TAVILY_PROXY_URL.trim()
    private fun appToken(): String = com.agon.app.BuildConfig.TAVILY_APP_TOKEN.trim()

    /** Advanced só quando a pergunta realmente pede profundidade (estudos, diretrizes, comparação técnica). */
    private val DEEP = Regex(
        "(?<!\\p{L})(estudos?|ensaios? cl[ií]nicos?|revis[aã]o sistem[aá]tica|meta-?an[aá]lise|evid[eê]ncias?|artigos? cient[ií]ficos?|" +
            "pesquisas? cient[ií]ficas?|diretrizes?|consenso|detalhad[oa]s?|aprofundad[oa]s?|em detalhes?)(?!\\p{L})",
        RegexOption.IGNORE_CASE,
    )

    fun chooseDepth(intent: SearchIntent, original: String): TavilyDepth =
        if ((intent == SearchIntent.HEALTH || intent == SearchIntent.GENERAL || intent == SearchIntent.CURRENT) && DEEP.containsMatchIn(original))
            TavilyDepth.ADVANCED else TavilyDepth.BASIC

    /**
     * [query] já vem SEM dados pessoais (CrisSearchPolicy.neutralize). Nada além dela é enviado.
     * Sempre devolve um [TavilyResult]; nunca lança exceção.
     */
    suspend fun search(context: Context, query: String, intent: SearchIntent, window: String, depth: TavilyDepth): TavilyResult {
        if (!isConfigured()) return TavilyResult.Disabled
        if (query.isBlank()) return TavilyResult.Empty

        val key = "${depth.wire}|$intent|$window|${query.lowercase().trim()}"
        cached(key, intent)?.let { return if (it.isEmpty()) TavilyResult.Empty else TavilyResult.Ok(it, 0, true) }

        return gate.withPermit {
            // Outra chamada igual pode ter terminado enquanto esperávamos a vez.
            cached(key, intent)?.let { return@withPermit if (it.isEmpty()) TavilyResult.Empty else TavilyResult.Ok(it, 0, true) }
            if (!TavilyCredits.tryReserve(context, depth.credits)) return@withPermit TavilyResult.QuotaBlocked
            var actual = 0
            try {
                // HttpURLConnection é bloqueante: sempre fora da thread principal (na Main vira NetworkOnMainThreadException).
                val res = withContext(Dispatchers.IO) { call(query, intent, window, depth) }
                // 200 = crédito consumido; falha antes do servidor aceitar = devolve a reserva.
                actual = when (res) {
                    is Raw.Ok -> res.credits ?: depth.credits
                    is Raw.Http -> if (res.code in 200..299) depth.credits else 0
                    is Raw.Net -> 0
                }
                when (res) {
                    is Raw.Ok -> {
                        val hits = parse(res.body)
                        put(key, hits)
                        if (hits.isEmpty()) TavilyResult.Empty else TavilyResult.Ok(hits, actual, false)
                    }
                    is Raw.Http -> when (res.code) {
                        401, 403 -> TavilyResult.InvalidKey
                        429, 432, 433 -> TavilyResult.QuotaBlocked
                        else -> TavilyResult.Failed(res.code)
                    }
                    is Raw.Net -> if (res.timeout) TavilyResult.Timeout else TavilyResult.Offline
                }
            } finally {
                TavilyCredits.settle(context, depth.credits, actual)
            }
        }
    }

    // ---- cache

    private fun ttl(intent: SearchIntent) = if (intent == SearchIntent.NEWS || intent == SearchIntent.CURRENT) CACHE_NEWS_MS else CACHE_DEFAULT_MS

    private fun cached(key: String, intent: SearchIntent): List<WebHit>? = synchronized(cache) {
        val e = cache[key] ?: return null
        if (System.currentTimeMillis() - e.at > ttl(intent)) { cache.remove(key); return null }
        e.hits
    }

    private fun put(key: String, hits: List<WebHit>) = synchronized(cache) {
        if (cache.size > 60) cache.clear()
        cache[key] = Entry(System.currentTimeMillis(), hits)
    }

    // ---- rede

    private sealed class Raw {
        class Ok(val body: String, val credits: Int?) : Raw()
        class Http(val code: Int) : Raw()
        class Net(val timeout: Boolean) : Raw()
    }

    /**
     * Corpo enviado ao proxy: só os campos abaixo. O proxy monta o pedido final ao Tavily com opções fixas
     * (sem resposta gerada, sem conteúdo bruto, sem imagens) para não gastar créditos à toa.
     */
    private fun call(query: String, intent: SearchIntent, window: String, depth: TavilyDepth): Raw {
        val body = JSONObject().apply {
            put("query", query.take(200))
            put("depth", depth.wire)
            put("maxResults", MAX_RESULTS)
            put("topic", if (intent == SearchIntent.NEWS) "news" else "general")
            put("health", intent == SearchIntent.HEALTH)
            when (window) {
                "when:1d" -> put("timeRange", "day")
                "when:7d" -> put("timeRange", "week")
                else -> if (intent == SearchIntent.NEWS || intent == SearchIntent.CURRENT) put("timeRange", "month")
            }
        }.toString()

        val c = URL(proxyUrl()).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = CONNECT_MS
            c.readTimeout = if (depth == TavilyDepth.ADVANCED) READ_MS + 6_000 else READ_MS
            c.instanceFollowRedirects = false
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            c.setRequestProperty("Accept", "application/json")
            c.setRequestProperty("User-Agent", UA)
            if (appToken().isNotBlank()) c.setRequestProperty("X-App-Token", appToken())
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val code = c.responseCode
            if (code !in 200..299) return Raw.Http(code)
            val text = String(c.inputStream.use { readLimited(it) }, Charsets.UTF_8)
            val credits = try { JSONObject(text).optJSONObject("usage")?.optInt("credits", -1)?.takeIf { it >= 0 } } catch (_: Exception) { null }
            Raw.Ok(text, credits)
        } catch (_: java.net.SocketTimeoutException) {
            Raw.Net(true)
        } catch (e: Exception) {
            android.util.Log.w("TavilySearch", "falha de rede: ${e.javaClass.simpleName}")
            Raw.Net(false)
        } finally {
            c.disconnect()
        }
    }

    private fun readLimited(i: java.io.InputStream): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (out.size() < MAX_BODY) {
            val n = i.read(buf)
            if (n < 0) break
            out.write(buf, 0, n)
        }
        return out.toByteArray()
    }

    // ---- resposta

    private fun parse(body: String): List<WebHit> {
        val arr: JSONArray = (try { JSONObject(body).optJSONArray("results") } catch (_: Exception) { null }) ?: return emptyList()
        val out = ArrayList<WebHit>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val url = o.optString("url")
            if (!url.startsWith("https://")) continue
            val title = clean(o.optString("title"))
            val snippet = clean(o.optString("content"))
            if (title.isBlank() && snippet.isBlank()) continue
            val host = try { URL(url).host.removePrefix("www.") } catch (_: Exception) { "web" }
            val relevance = (o.optDouble("score", 0.0) * 20).toInt().coerceIn(0, 20)   // 0..1 → 0..20
            val (sc, official) = CrisWebSearch.scoreOf(url, 4 + relevance)
            val date = o.optString("published_date").takeIf { it.isNotBlank() && it != "null" }?.let { CrisWebSearch.formatDate(it) } ?: ""
            out += WebHit(title.ifBlank { host }, snippet, url, host, date, official, sc)
        }
        return out
    }

    /** Texto vindo da internet é dado, nunca instrução: remove marcação e quebras que poderiam imitar o prompt. */
    private fun clean(s: String): String = s
        .replace(Regex("<[^>]+>"), " ")
        .replace(Regex("\\[\\.\\.\\.]"), " ")
        .replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&nbsp;", " ")
        .replace(Regex("\\s+"), " ")
        .trim()
}
