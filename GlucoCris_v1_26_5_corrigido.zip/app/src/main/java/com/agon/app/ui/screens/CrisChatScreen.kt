package com.agon.app.ui.screens

import android.Manifest
import android.graphics.BitmapFactory
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.TextButton
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.agon.app.localai.CrisBackgroundTasks
import com.agon.app.ui.components.tourTarget
import com.agon.app.localai.CrisTask
import com.agon.app.localai.AttKind
import com.agon.app.localai.AttachException
import com.agon.app.localai.CrisAttachment
import com.agon.app.localai.CrisAttachments
import com.agon.app.localai.CrisConvMeta
import com.agon.app.localai.CrisConvMsg
import com.agon.app.localai.CrisConversationStore
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.CrisChatLine
import com.agon.app.data.CrisMemory
import com.agon.app.data.CrisPrefs
import com.agon.app.data.CrisSpeaker
import com.agon.app.data.CrisGemini
import com.agon.app.localai.CrisConnectivityManager
import com.agon.app.localai.CrisLocalAi
import com.agon.app.localai.CrisSafetyGuard
import com.agon.app.localai.EngineState
import com.agon.app.localai.LocalAiEngine
import com.agon.app.localai.LocalAiSettings
import com.agon.app.localai.LocalVisionManager
import com.agon.app.data.GlucoViewModel
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.launch
import kotlinx.coroutines.plus
import android.util.Log

private val CRIS_GREEN = Color(0xFF34D399)
private val CRIS_GREEN_DEEP = Color(0xFF065F46)

private val QUICK_TIPS = listOf(
    "Como estou essa semana?" to "resumo semanal",
    "Consulta em 1 min" to "consulta em 1 minuto",
    "Meus lembretes" to "meus lembretes",
    "Achar insulina" to "abrir localizador",
    "Criar lembrete" to "criar lembrete",
)

@Composable
fun CrisIaScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    val aiExceptionHandler = remember {
        CoroutineExceptionHandler { _, t ->
            Log.e("CrisIa", "Erro não capturado na IA", t)
        }
    }
    val scope = rememberCoroutineScope() + aiExceptionHandler

    val messages = remember { mutableStateListOf<CrisMsg>() }
    var input by remember { mutableStateOf("") }
    var thinking by remember { mutableStateOf(false) }
    var memory by remember { mutableStateOf(CrisMemory()) }
    var pending by remember { mutableStateOf<PendingAction?>(null) }
    var listening by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    var micBlocked by remember { mutableStateOf(false) }
    var ready by remember { mutableStateOf(false) }
    var pendingAtts by remember { mutableStateOf<List<CrisAttachment>>(emptyList()) }
    val pendingAttachName: String? = if (pendingAtts.isEmpty()) null else pendingAtts.joinToString(", ") { it.name }
    var attachNotice by remember { mutableStateOf<String?>(null) }
    var convId by remember { mutableStateOf("") }
    var convCreatedAt by remember { mutableStateOf(0L) }
    var menuOpen by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }
    var historyList by remember { mutableStateOf<List<CrisConvMeta>>(emptyList()) }
    var confirmDeleteId by remember { mutableStateOf<String?>(null) }
    var streamingText by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()

    // Tarefas em segundo plano: a conversa só é considerada "na tela" se a tela existe E o app está à frente.
    val lifecycleOwner = LocalLifecycleOwner.current
    val alive = remember { booleanArrayOf(true) }
    fun looking(): Boolean = alive[0] && lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)
    var showTasks by remember { mutableStateOf(false) }
    var taskList by remember { mutableStateOf<List<CrisTask>>(emptyList()) }
    val notifPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun askNotifPermissionOnce() {
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            val sp = context.getSharedPreferences("cris_bg_tasks_ui", android.content.Context.MODE_PRIVATE)
            if (!sp.getBoolean("asked_notif", false)) {
                sp.edit().putBoolean("asked_notif", true).apply()
                notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    val speaker = remember { CrisSpeaker(context) }
    val listener = remember {
        CrisListener(
            context,
            onLevel = {},
            onPartial = { input = it },
            onResult = { input = it; listening = false },
            onFail = { notice = it; listening = false },
        )
    }
    DisposableEffect(Unit) {
        onDispose {
            alive[0] = false
            listener.stop()
            speaker.release()
        }
    }

    fun greeting(): CrisMsg {
        val first = vm.data.value.settings.displayName.split(" ").firstOrNull().orEmpty()
        return CrisMsg(false, "Oi${if (first.isNotBlank()) ", $first" else ""}! Eu sou a Cris ❤️ Pode falar comigo do jeito que quiser, sobre o seu dia, sua glicose ou qualquer coisa. Se preferir conversar por voz, toca no botão verde lá em cima.")
    }

    LaunchedEffect(Unit) {
        memory = CrisPrefs.loadMemory(context)
        CrisBackgroundTasks.recoverInterrupted(context)
        val active = CrisConversationStore.loadActive(context)
        if (active != null && active.messages.isNotEmpty()) {
            convId = active.id
            convCreatedAt = active.createdAt
            messages.addAll(active.messages.map { CrisMsg(it.fromUser, cleanCrisText(it.text), it.source, it.media) })
        } else {
            messages.add(greeting())
        }
        // Contexto automático vindo do Cris Scanner / rótulo
        val pendingCtx = vm.consumeCrisPendingPrompt()
        if (!pendingCtx.isNullOrBlank()) {
            input = "Com base neste rótulo, me explique os pontos mais importantes para quem acompanha a glicemia:\n\n" + pendingCtx
            messages.add(
                CrisMsg(
                    false,
                    "Recebi o contexto do produto que você analisou no scanner. Revise a mensagem abaixo e toque em enviar, ou edite antes.",
                ),
            )
        }
        ready = true
        // Prepara a IA em segundo plano enquanto a pessoa lê/digita (não bloqueia a tela)
        LocalAiEngine.get(context).prewarm()
    }

    fun persist() {
        if (vm.practice.value) return   // simulação do tour: nada é gravado
        if (convId.isBlank()) {
            convId = com.agon.app.data.uid()
            convCreatedAt = System.currentTimeMillis()
        }
        CrisConversationStore.saveAsync(
            context, convId, convCreatedAt,
            messages.map { CrisConvMsg(it.fromUser, it.text, it.source, it.media) },
        )
    }

    fun startNewConversation() {
        if (vm.practice.value) { notice = "Na simulação isso não é executado."; return }
        if (thinking) { notice = "Aguarde a resposta terminar."; return }
        speaker.stop()
        messages.clear()
        messages.add(greeting())
        convId = ""
        convCreatedAt = 0L
        pending = null
        CrisAttachments.cleanup(pendingAtts)
        pendingAtts = emptyList()
        attachNotice = null
        notice = null
        CrisConversationStore.setActive(context, "")
    }

    fun openConversation(id: String) {
        if (vm.practice.value) { notice = "Na simulação isso não é executado."; return }
        if (thinking) { notice = "Aguarde a resposta terminar."; return }
        scope.launch {
            val conv = CrisConversationStore.load(context, id) ?: run { notice = "Não consegui abrir essa conversa."; return@launch }
            speaker.stop()
            messages.clear()
            messages.addAll(conv.messages.map { CrisMsg(it.fromUser, cleanCrisText(it.text), it.source, it.media) })
            convId = conv.id
            convCreatedAt = conv.createdAt
            pending = null
            CrisAttachments.cleanup(pendingAtts)
            pendingAtts = emptyList()
            attachNotice = null
            notice = null
            CrisConversationStore.setActive(context, conv.id)
            showHistory = false
        }
    }

    fun deleteConversation(id: String) {
        if (vm.practice.value) { notice = "Na simulação nada é apagado."; return }
        scope.launch {
            CrisConversationStore.delete(context, id)
            historyList = CrisConversationStore.list(context)
            if (id == convId) startNewConversation()
        }
    }

    fun send(raw: String) {
        val t = raw.trim()
        val hasAttach = pendingAtts.isNotEmpty()
        if (vm.practice.value) { notice = "Na simulação a Cris não envia mensagens de verdade."; return }
        if ((t.isEmpty() && !hasAttach) || thinking) return
        val history = messages.toList()
        val ctxSummary = CrisConversationStore.contextSummary(history.map { CrisConvMsg(it.fromUser, it.text, it.source, it.media) })
        val userShow = if (hasAttach) {
            val n = pendingAtts.joinToString(", ") { it.name }.ifBlank { "anexo" }
            if (t.isBlank()) "[Anexo: $n]" else "[Anexo: $n]\n$t"
        } else t
        messages.add(CrisMsg(true, userShow))
        persist()
        input = ""
        notice = null
        attachNotice = null
        thinking = true
        speaker.stop()
        val atts = pendingAtts.toList()
        pendingAtts = emptyList()
        askNotifPermissionOnce()
        val taskId = CrisBackgroundTasks.begin(context, convId, userShow)
        var taskError: String? = null
        // Escopo do processo (não da tela): a pergunta continua se a pessoa sair da conversa ou apagar a tela.
        (CrisBackgroundTasks.scope + aiExceptionHandler).launch {
            try {
                if (atts.isNotEmpty()) {
                    // Anexo (foto, PDF, áudio, vídeo, Word, texto): SEMPRE passa pela leitura de anexos.
                    // Nunca cai no chat de texto (era isso que fazia a Cris dizer "não tenho acesso a imagens").
                    val userName = com.agon.app.data.firstName(vm.data.value.settings.displayName)
                    val ctx = if (LocalAiSettings.onlineHealthContextAllowed(context)) {
                        try { buildCrisContext(vm.data.value) } catch (_: Exception) { "" }
                    } else "Dados de saúde do app não foram compartilhados (privacidade)."
                    val sys = try {
                        CrisLocalAi.buildSystemPrompt(context, vm.data.value, memory, userName)
                    } catch (_: Exception) { "" }
                    val res = try {
                        CrisAttachments.analyze(
                            context, atts, t, ctx, userName,
                            history.map { it.fromUser to it.text }, sys,
                        )
                    } finally {
                        CrisAttachments.cleanup(atts)
                    }
                    val reply = cleanCrisText(res.text)
                    streamingText = null
                    thinking = false
                    messages.add(CrisMsg(false, reply, res.source))
                    persist()
                    if (looking() && memory.speakReplies) speaker.speak(reply)
                    return@launch
                }
                val r = crisRespond(
                    context, vm, t.ifBlank { userShow }, memory, pending, history, voice = false,
                    summary = ctxSummary, onPartial = { streamingText = it.takeIf { x -> x.isNotBlank() } },
                )
                memory = r.memory
                pending = r.pending
                messages.add(CrisMsg(false, r.reply, r.source, r.media))
                persist()
                // A resposta final já está na lista: some com a bolha ao vivo e o "digitando…" ANTES de falar a resposta
                // (a fala bloqueia até terminar e antes deixava a mensagem duplicada na tela).
                streamingText = null
                thinking = false
                if (r.navigateTo != null) {
                    if (looking()) nav.navigate(r.navigateTo)
                } else if (looking() && memory.speakReplies) {
                    speaker.speak(r.reply)
                }
            } catch (t: Throwable) {
                Log.e("CrisIa", "Falha ao responder", t)
                val msg = when {
                    t is OutOfMemoryError -> "Memória insuficiente. Feche outros apps e tente de novo."
                    else -> "Não consegui responder agora. Tente novamente em instantes."
                }
                taskError = msg
                messages.add(CrisMsg(false, msg, CrisLocalAi.SRC_BASIC))
                persist()
            } finally {
                streamingText = null
                thinking = false
                CrisBackgroundTasks.finish(context, taskId, taskError, looking())
            }
        }
    }


    val attachPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris: List<Uri> ->
        if (uris.isEmpty()) return@rememberLauncherForActivityResult
        scope.launch {
            val added = ArrayList<CrisAttachment>()
            var problem: String? = null
            attachNotice = "Preparando o arquivo…"
            for (uri in uris) {
                if (pendingAtts.size + added.size >= CrisAttachments.MAX_ATTACHMENTS) {
                    problem = "Máximo de ${CrisAttachments.MAX_ATTACHMENTS} arquivos por mensagem."
                    break
                }
                try {
                    added.add(CrisAttachments.prepare(context, uri))
                } catch (e: AttachException) {
                    problem = e.message
                } catch (e: Throwable) {
                    problem = "Falha ao anexar (${e.message ?: "erro"})."
                }
            }
            if (added.isNotEmpty()) pendingAtts = pendingAtts + added
            attachNotice = when {
                problem != null -> problem
                added.size == 1 -> when (added[0].kind) {
                    AttKind.IMAGE -> "Foto anexada: ${added[0].name} — escreva a pergunta (ou só envie) e eu leio."
                    AttKind.PDF -> "PDF anexado: ${added[0].name} — pergunte o que quiser (ou só envie) e eu explico."
                    AttKind.AUDIO -> "Áudio anexado: ${added[0].name} — peça a transcrição ou um resumo."
                    AttKind.VIDEO -> "Vídeo anexado: ${added[0].name} — pergunte o que quiser sobre ele."
                    else -> "Arquivo anexado: ${added[0].name} — pergunte o que quiser sobre ele."
                }
                added.isNotEmpty() -> "${added.size} arquivos anexados — escreva a pergunta e envie."
                else -> null
            }
        }
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
                micBlocked = false
                listening = true
                listener.start()
        } else {
                val act = context.findActivity()
                val canAsk = act != null && ActivityCompat.shouldShowRequestPermissionRationale(act, Manifest.permission.RECORD_AUDIO)
                micBlocked = !canAsk
                notice = if (canAsk) "Sem o microfone eu não consigo te ouvir, mas você pode digitar." else "O microfone está bloqueado. Libere nas configurações para falar comigo."
        }
    }

    fun toggleDictation() {
        if (listening) {
                listener.stop(); listening = false; return
        }
        notice = null
        speaker.stop()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                listening = true
                listener.start()
        } else {
                micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(messages.size, thinking, (streamingText?.length ?: 0) / 60) {
        val count = messages.size + if (thinking) 1 else 0
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    if (!ready) {
        Box(Modifier.fillMaxSize().background(g.bg), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = g.violet)
        }
        return
    }

    Column(Modifier.fillMaxSize().background(g.bg).imePadding()) {
        // Cabeçalho fixo
        Row(
                Modifier.fillMaxWidth().background(g.card).padding(horizontal = 8.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
        ) {
                IconButton(onClick = { nav.popBackStack() }, modifier = Modifier.size(40.dp)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = g.ink)
                }
                Box(
                Modifier.size(40.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(CRIS_GREEN, CRIS_GREEN_DEEP))),
                contentAlignment = Alignment.Center,
                ) {
                Text("C", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                }
                Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text("Cris", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                val online by remember { CrisConnectivityManager.observe(context) }.collectAsState(initial = CrisConnectivityManager.isOnline(context))
                val engineState by LocalAiEngine.get(context).state.collectAsState()
                val localReady = CrisLocalAi.isReady(context)
                Text(
                    when {
                        listening -> "ouvindo você…"
                        thinking -> "digitando…"
                        engineState is EngineState.Loading -> "carregando a IA…"
                        localReady && online -> "IA no aparelho · online"
                        localReady -> "IA no aparelho · offline"
                        online -> "online · toque para ativar a IA local"
                        else -> "offline · IA local não instalada"
                    },
                    color = if (listening || thinking) g.green else g.muted,
                    fontSize = 11.sp,
                    maxLines = 2,
                    modifier = Modifier.clickable { nav.navigate(Routes.CRIS_AI_SETTINGS) },
                )
                }
                IconButton(modifier = Modifier.size(40.dp), onClick = {
                    val next = !memory.shortAnswers
                    memory = memory.copy(shortAnswers = next)
                    LocalAiSettings.setAnswerStyle(context, if (next) "direct" else "explain")
                    scope.launch { CrisPrefs.saveMemory(context, memory) }
                    notice = if (next) "Modo direta: respostas curtas." else "Modo explicativa: mais detalhe."
                }) {
                    Text(
                        if (memory.shortAnswers) "1×" else "A+",
                        color = g.violet,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                    )
                }
                IconButton(modifier = Modifier.size(40.dp), onClick = {
                memory = memory.copy(speakReplies = !memory.speakReplies)
                scope.launch { CrisPrefs.saveMemory(context, memory) }
                if (!memory.speakReplies) speaker.stop()
                }) {
                Icon(if (memory.speakReplies) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff, "Voz das respostas", tint = g.violet)
                }
                Box {
                IconButton(onClick = { menuOpen = true }, modifier = Modifier.size(40.dp).tourTarget("cris_menu")) {
                Icon(Icons.Filled.MoreVert, "Mais opções", tint = g.muted)
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(
                        text = { Text("Histórico de conversas") },
                        leadingIcon = { Icon(Icons.Filled.History, null, tint = g.violet) },
                        onClick = {
                            menuOpen = false
                            scope.launch { historyList = CrisConversationStore.list(context); showHistory = true }
                        },
                    )
                    DropdownMenuItem(
                        text = { Text("Tarefas da Cris") },
                        leadingIcon = { Icon(Icons.Filled.History, null, tint = g.violet) },
                        onClick = { menuOpen = false; taskList = CrisBackgroundTasks.all(context); showTasks = true },
                    )
                    DropdownMenuItem(
                        text = { Text("Nova conversa") },
                        leadingIcon = { Icon(Icons.Filled.AddComment, null, tint = g.violet) },
                        onClick = { menuOpen = false; startNewConversation() },
                    )
                    DropdownMenuItem(
                        text = { Text("Excluir esta conversa") },
                        leadingIcon = { Icon(Icons.Filled.DeleteOutline, null, tint = g.muted) },
                        onClick = {
                            menuOpen = false
                            if (thinking) notice = "Aguarde a resposta terminar."
                            else if (convId.isBlank()) startNewConversation()
                            else confirmDeleteId = convId
                        },
                    )
                }
                }
                Row(
                Modifier.heightIn(min = 40.dp).clip(RoundedCornerShape(20.dp)).background(CRIS_GREEN_DEEP)
                    .clickable { speaker.stop(); listener.stop(); listening = false; nav.navigate(Routes.CRIS_VOICE) }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                ) {
                Icon(Icons.Filled.GraphicEq, null, tint = CRIS_GREEN, modifier = Modifier.size(18.dp))
                Text("Voz", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp))
                }
        }

        LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
                itemsIndexed(messages) { _, msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                    Box(
                        Modifier.widthIn(max = 300.dp)
                            .clip(
                                RoundedCornerShape(
                                    topStart = 18.dp, topEnd = 18.dp,
                                    bottomStart = if (msg.fromUser) 18.dp else 4.dp,
                                    bottomEnd = if (msg.fromUser) 4.dp else 18.dp,
                                ),
                            )
                            .background(if (msg.fromUser) g.violet else g.card)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                    ) {
                        Column {
                            Text(msg.text, color = if (msg.fromUser) Color.White else g.ink, fontSize = 15.sp, lineHeight = 21.sp)
                            if (!msg.fromUser && msg.media.isNotBlank()) CrisMediaBlock(msg.media)
                            if (!msg.fromUser && msg.source in setOf(CrisLocalAi.SRC_SAFETY, CrisLocalAi.SRC_CALC, CrisLocalAi.SRC_APP, CrisLocalAi.SRC_BASIC)) {
                                Text(
                                    CrisLocalAi.label(msg.source),
                                    color = g.muted,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(top = 4.dp),
                                )
                            }
                        }
                    }
                }
                }
                if (thinking) {
                item {
                    val live = streamingText
                    if (live == null) TypingBubble() else {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Start) {
                            Box(
                                Modifier.widthIn(max = 300.dp)
                                    .clip(RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp, bottomStart = 4.dp, bottomEnd = 18.dp))
                                    .background(g.card)
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                            ) {
                                Text(live, color = g.ink, fontSize = 15.sp, lineHeight = 21.sp)
                            }
                        }
                    }
                }
                }
        }

        LazyRow(
                Modifier.fillMaxWidth().height(48.dp),
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
        ) {
                items(QUICK_TIPS) { (label, cmd) ->
                Text(
                    label,
                    color = g.violet,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(g.lilacSoft)
                        .clickable { send(cmd) }
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                )
                }
        }

        notice?.let {
                Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(it, color = g.orange, fontSize = 12.sp, modifier = Modifier.weight(1f))
                if (micBlocked) {
                    Text(
                        "Abrir configurações",
                        color = g.violet,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.clickable {
                            context.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        }.padding(8.dp),
                    )
                }
                }
        }

        attachNotice?.let {
                Text(it, color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
        }
        pendingAttachName?.let {
                Text(
                    "Anexo: $it — toque aqui para remover",
                    color = g.violet, fontSize = 12.sp,
                    modifier = Modifier
                        .clickable { CrisAttachments.cleanup(pendingAtts); pendingAtts = emptyList(); attachNotice = null }
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                )
        }
        Row(
                Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 10.dp),
                verticalAlignment = Alignment.Bottom,
        ) {
                IconButton(onClick = { attachPicker.launch("*/*") }) {
                Icon(Icons.Filled.AttachFile, "Anexar", tint = g.violet)
                }
                Box(
                Modifier.weight(1f).heightIn(min = 48.dp).tourTarget("cris_input").clip(RoundedCornerShape(24.dp)).background(g.card)
                    .border(1.dp, if (listening) CRIS_GREEN else g.line, RoundedCornerShape(24.dp))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                contentAlignment = Alignment.CenterStart,
                ) {
                if (input.isEmpty()) {
                    Text(if (listening) "Pode falar, estou ouvindo…" else "Escreva para a Cris…", color = g.muted, fontSize = 15.sp)
                }
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    maxLines = 5,
                    textStyle = TextStyle(color = g.ink, fontSize = 15.sp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { send(input) }),
                    modifier = Modifier.fillMaxWidth(),
                )
                }
                Spacer(Modifier.width(8.dp))
                val showSend = (input.isNotBlank() || pendingAttachName != null) && !listening
                Box(
                Modifier.size(48.dp).clip(CircleShape)
                    .background(if (showSend) g.violet else if (listening) CRIS_GREEN else g.lilacSoft)
                    .clickable { if (showSend) send(input) else toggleDictation() },
                contentAlignment = Alignment.Center,
                ) {
                Icon(
                    if (showSend) Icons.AutoMirrored.Filled.Send else Icons.Filled.Mic,
                    if (showSend) "Enviar" else "Falar",
                    tint = if (showSend || listening) Color.White else g.violet,
                )
                }
        }
    }

    if (showHistory) {
        AlertDialog(
            onDismissRequest = { showHistory = false },
            title = { Text("Histórico de conversas", color = g.ink, fontWeight = FontWeight.Bold) },
            text = {
                if (historyList.isEmpty()) {
                    Text("Nenhuma conversa salva ainda.", color = g.muted, fontSize = 14.sp)
                } else {
                    LazyColumn(Modifier.heightIn(max = 420.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(historyList, key = { it.id }) { m ->
                            val selected = m.id == convId
                            Row(
                                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                                    .background(if (selected) g.lilacSoft else Color.Transparent)
                                    .border(1.dp, if (selected) g.violet else g.line, RoundedCornerShape(14.dp))
                                    .clickable { openConversation(m.id) }
                                    .padding(start = 12.dp, top = 8.dp, bottom = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                Column(Modifier.weight(1f)) {
                                    Text(m.title, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
                                    if (m.preview.isNotBlank()) {
                                        Text(m.preview, color = g.muted, fontSize = 12.sp, maxLines = 2)
                                    }
                                    Text(
                                        (if (selected) "Aberta agora · " else "") +
                                            java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale("pt", "BR")).format(m.updatedAt),
                                        color = g.violet, fontSize = 11.sp,
                                    )
                                }
                                IconButton(onClick = { confirmDeleteId = m.id }) {
                                    Icon(Icons.Filled.DeleteOutline, "Excluir conversa", tint = g.muted)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showHistory = false; startNewConversation() }) { Text("Nova conversa") }
            },
            dismissButton = { TextButton(onClick = { showHistory = false }) { Text("Fechar") } },
        )
    }

    if (showTasks) {
        AlertDialog(
            onDismissRequest = { showTasks = false },
            title = { Text("Tarefas da Cris") },
            text = {
                if (taskList.isEmpty()) {
                    Text("Nenhuma pergunta em segundo plano ainda. Envie uma pergunta e pode sair do app: eu aviso quando terminar.", fontSize = 13.sp)
                } else {
                    LazyColumn(Modifier.heightIn(max = 380.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(taskList.size) { i ->
                            val tk = taskList[i]
                            val whenTxt = java.text.SimpleDateFormat("dd/MM HH:mm", java.util.Locale("pt", "BR")).format(java.util.Date(tk.requestedAt))
                            val stateTxt = when (tk.state) {
                                "RUNNING" -> "⏳ Em andamento"
                                "DONE" -> "✅ Concluída · resposta na conversa"
                                else -> "⚠️ Com erro" + if (tk.error.isNotBlank()) ": " + tk.error else ""
                            }
                            Column {
                                Text(tk.question.replace(Regex("\\s+"), " ").take(90), fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Text("$whenTxt · " + (if (tk.online) "com internet" else "sem internet na hora do pedido"), fontSize = 11.sp, color = g.muted)
                                Text(stateTxt, fontSize = 12.sp)
                                Row {
                                    if (tk.state == "DONE" && tk.convId.isNotBlank() && tk.convId != convId) {
                                        TextButton(onClick = { showTasks = false; openConversation(tk.convId) }) { Text("Abrir conversa") }
                                    }
                                    if (tk.state == "ERROR") {
                                        TextButton(onClick = {
                                            CrisBackgroundTasks.discard(context, tk.id)
                                            showTasks = false
                                            send(tk.question)
                                        }) { Text("Tentar de novo") }
                                    }
                                    if (tk.state != "RUNNING") {
                                        TextButton(onClick = {
                                            CrisBackgroundTasks.discard(context, tk.id)
                                            taskList = CrisBackgroundTasks.all(context)
                                        }) { Text("Limpar") }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showTasks = false }) { Text("Fechar") } },
        )
    }

    confirmDeleteId?.let { id ->
        AlertDialog(
            onDismissRequest = { confirmDeleteId = null },
            title = { Text("Excluir conversa?") },
            text = { Text("Essa conversa será apagada deste aparelho e não poderá ser recuperada.") },
            confirmButton = {
                TextButton(onClick = { confirmDeleteId = null; deleteConversation(id) }) { Text("Excluir") }
            },
            dismissButton = { TextButton(onClick = { confirmDeleteId = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun TypingBubble() {
    val g = glucoColors()
    val t = rememberInfiniteTransition(label = "typing")
    val phase by t.animateFloat(0f, 3f, infiniteRepeatable(tween(900), RepeatMode.Restart), label = "dots")
    Row(
        Modifier.clip(RoundedCornerShape(18.dp)).background(g.card).padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        repeat(3) { i ->
                Box(
                Modifier.size(8.dp).alpha(if (phase.toInt() == i) 1f else 0.35f).clip(CircleShape).background(g.violet),
                )
        }
    }
}
