package com.agon.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.net.Uri
import android.util.Log
import java.io.File
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material3.LocalTextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.FoodVisionAi
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Meal
import com.agon.app.data.VisionMealLine
import com.agon.app.data.LabelAnalysisResult
import com.agon.app.data.LabelIngredient
import com.agon.app.data.LabelNutrition
import com.agon.app.data.NutritionValues
import com.agon.app.data.LabelScanStore
import com.agon.app.data.uid
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import kotlin.math.roundToInt

private const val PREFS_VISION = "gluco_vision_prefs"
private const val KEY_CONSENT = "gemini_photo_consent"

@Composable
fun FoodSmartScannerScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var hasCam by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED,
        )
    }
    var consent by remember {
        mutableStateOf(
            context.getSharedPreferences(PREFS_VISION, 0).getBoolean(KEY_CONSENT, false),
        )
    }
    var showConsent by remember { mutableStateOf(!consent) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var phase by remember { mutableStateOf(0) } // 0 capture 1 preview 2 loading 3 result
    var progressMsg by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var lines by remember { mutableStateOf<List<VisionMealLine>>(emptyList()) }
    var providerUsed by remember { mutableStateOf("") }
    var mealType by remember { mutableStateOf("almoco") }
    var mealExpanded by remember { mutableStateOf(false) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }

    // Modo: "plate" = reconhecimento de prato/refeição (atual)
    //       "label" = leitura de rótulo (tabela nutricional + ingredientes)
    var scanMode by remember { mutableStateOf("plate") }
    var labelResult by remember { mutableStateOf<LabelAnalysisResult?>(null) }
    // Comparação lado a lado
    var compareSlot by remember { mutableStateOf(1) } // 1 ou 2
    var labelA by remember { mutableStateOf<LabelAnalysisResult?>(null) }
    var labelB by remember { mutableStateOf<LabelAnalysisResult?>(null) }
    var historyEntries by remember { mutableStateOf<List<LabelScanStore.Entry>>(emptyList()) }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasCam = it
    }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            val decoded = FoodVisionAi.decodeUriForAnalysis(context, uri)
            if (decoded == null) {
                error = "Não foi possível abrir a imagem."
            } else {
                bitmap = decoded
                phase = 1
                error = null
            }
        } catch (e: Exception) {
            error = "Não foi possível abrir a imagem."
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCam) perm.launch(Manifest.permission.CAMERA)
    }

    fun startAnalysis(bmp: Bitmap) {
        // Gemini (se houver chave) → fallback ML Kit; nutrientes sempre via catálogo OFF/local
        if (FoodVisionAi.hasGeminiKey() && !consent) {
            showConsent = true
            return
        }
        phase = 2
        error = null
        labelResult = null
        lines = emptyList()

        if (scanMode == "label" || scanMode == "compare") {
            progressMsg = "Lendo o rótulo…"
            scope.launch {
                try {
                    progressMsg = when {
                        scanMode == "compare" && compareSlot == 2 ->
                            if (FoodVisionAi.hasGeminiKey()) "Lendo o 2º produto…" else "OCR local do 2º produto…"
                        FoodVisionAi.hasGeminiKey() -> "Extraindo tabela nutricional e ingredientes…"
                        else -> "Lendo rótulo com OCR local (sem internet)…"
                    }
                    val result = FoodVisionAi.analyzeLabel(bmp)
                    // Histórico persistente
                    try { LabelScanStore.add(context, result) } catch (_: Exception) {}
                    labelResult = result
                    providerUsed = result.provider
                    if (result.confidenceNotes != null &&
                        result.nutrition?.per100g == null &&
                        result.nutrition?.perServing == null &&
                        result.ingredients.isEmpty()
                    ) {
                        error = result.confidenceNotes
                        phase = 1
                        return@launch
                    }
                    if (scanMode == "compare") {
                        if (compareSlot == 1) {
                            labelA = result
                            compareSlot = 2
                            phase = 1
                            bitmap = null
                            progressMsg = ""
                            error = null
                            // pede segunda foto
                            return@launch
                        } else {
                            labelB = result
                            phase = 5 // tela de comparação
                            progressMsg = ""
                            return@launch
                        }
                    }
                    progressMsg = "Preparando o resultado…"
                    phase = 3
                } catch (e: Exception) {
                    Log.w("SmartScan", "label analyze", e)
                    error = e.message ?: "Falha na leitura do rótulo."
                    phase = 1
                }
            }
            return
        }

        // Modo prato / refeição (comportamento original)
        progressMsg = "Analisando sua refeição…"
        scope.launch {
            try {
                progressMsg = if (FoodVisionAi.hasGeminiKey())
                    "Identificando alimentos (Gemini)…"
                else
                    "Identificando alimentos (ML Kit) e consultando Open Food Facts…"
                val analysis = FoodVisionAi.analyzePlate(bmp)
                providerUsed = analysis.provider
                if (analysis.items.isEmpty()) {
                    error = analysis.rawNotes
                        ?: "Nenhum alimento identificado. Tente outra foto com boa luz."
                    phase = 1
                    return@launch
                }
                progressMsg = "Buscando nutrientes no catálogo (Open Food Facts / local)…"
                val matched = FoodVisionAi.matchToCatalog(context, analysis)
                lines = matched
                progressMsg = "Preparando o resultado…"
                phase = 3
            } catch (e: Exception) {
                Log.w("SmartScan", "analyze", e)
                error = e.message ?: "Falha na análise."
                phase = 1
            }
        }
    }

    fun captureStill() {
        val cap = imageCapture ?: run {
            error = "Câmera ainda não está pronta. Aguarde um instante e tente de novo."
            return
        }
        progressMsg = "Capturando…"
        error = null
        // Salva em arquivo JPEG (mais confiável que converter ImageProxy YUV)
        val photoFile = File(context.cacheDir, "smart_scan_${System.currentTimeMillis()}.jpg")
        val output = ImageCapture.OutputFileOptions.Builder(photoFile).build()
        cap.takePicture(
            output,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    try {
                        var bmp = FoodVisionAi.decodeFileForAnalysis(photoFile.absolutePath)
                        if (bmp == null) {
                            error = "Foto capturada, mas não foi possível ler a imagem."
                            progressMsg = ""
                            return
                        }
                        // Limita tamanho para análise
                        val maxSide = 1600
                        val max = maxOf(bmp.width, bmp.height)
                        if (max > maxSide) {
                            val scale = maxSide.toFloat() / max
                            bmp = Bitmap.createScaledBitmap(
                                bmp,
                                (bmp.width * scale).toInt().coerceAtLeast(1),
                                (bmp.height * scale).toInt().coerceAtLeast(1),
                                true,
                            )
                        }
                        bitmap = bmp
                        phase = 1
                        error = null
                        progressMsg = ""
                    } catch (e: Exception) {
                        error = "Erro ao processar a foto."
                        progressMsg = ""
                        Log.w("SmartScan", "decode", e)
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    error = "Falha na câmera: ${exception.message ?: "tente de novo"}"
                    progressMsg = ""
                    Log.w("SmartScan", "capture", exception)
                }
            },
        )
    }

    val totalCarbs = lines.sumOf { it.carbs() }
    val totalKcal = lines.sumOf { it.kcal() }
    val totalProt = lines.sumOf { it.protein() }
    val totalFat = lines.sumOf { it.fat() }

    if (showConsent) {
        AlertDialog(
            onDismissRequest = { showConsent = false },
            title = { Text("Análise por IA (internet)") },
            text = {
                Text(
                    "A foto será enviada pela internet ao serviço Gemini (Google) para identificar alimentos. " +
                        "Não envie dados pessoais na imagem. Estimativas de peso não são precisas. " +
                        "Você deve conferir tudo antes de salvar. Não use isso para dose de insulina.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    consent = true
                    context.getSharedPreferences(PREFS_VISION, 0).edit().putBoolean(KEY_CONSENT, true).apply()
                    showConsent = false
                }) { Text("Concordo e continuar") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showConsent = false
                    nav.popBackStack()
                }) { Text("Cancelar") }
            },
        )
    }

    Column(Modifier.fillMaxSize().background(g.bg)) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.Filled.Close, null, tint = g.ink)
            }
            Column(Modifier.weight(1f)) {
                Text(
                    if (scanMode == "label") "Cris Scanner · Rótulo ❤️" else "Reconhecimento por imagem",
                    color = g.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp,
                )
                Text(
                    if (FoodVisionAi.hasGeminiKey()) FoodVisionAi.providerLabel() else "Configure o proxy (tavily.proxy.url)",
                    color = g.muted, fontSize = 11.sp,
                )
            }
        }

        // Seletor de modo (só na captura/preview)
        if (phase == 0 || phase == 1) {
            Row(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                listOf(
                    "plate" to "🍽️ Prato",
                    "label" to "🏷️ Rótulo",
                    "compare" to "⚖️ Comparar",
                    "history" to "📚 Histórico",
                ).forEach { (mode, label) ->
                    val selected = scanMode == mode
                    Surface(
                        onClick = {
                            if (scanMode != mode || mode == "history") {
                                scanMode = mode
                                bitmap = null
                                lines = emptyList()
                                labelResult = null
                                error = null
                                phase = if (mode == "history") 4 else 0
                            }
                        },
                        shape = RoundedCornerShape(20.dp),
                        color = if (selected) g.violet else g.card,
                        modifier = Modifier.weight(1f),
                    ) {
                        Text(
                            label,
                            color = if (selected) Color.White else g.ink,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            fontSize = 13.sp,
                            modifier = Modifier.padding(vertical = 10.dp).fillMaxWidth(),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        )
                    }
                }
            }
        }

        when (phase) {
            0, 1 -> {
                if (phase == 0 && hasCam) {
                    Box(
                        Modifier.fillMaxWidth().height(260.dp).padding(horizontal = 16.dp)
                            .clip(RoundedCornerShape(16.dp)).background(Color.Black),
                    ) {
                        AndroidView(
                            factory = { ctx ->
                                PreviewView(ctx).apply {
                                    scaleType = PreviewView.ScaleType.FILL_CENTER
                                }
                            },
                            modifier = Modifier.fillMaxSize(),
                            update = { previewView ->
                                if (previewView.tag == true) return@AndroidView
                                previewView.tag = true
                                val future = ProcessCameraProvider.getInstance(context)
                                future.addListener({
                                    try {
                                        val provider = future.get()
                                        val preview = Preview.Builder().build().also {
                                            it.surfaceProvider = previewView.surfaceProvider
                                        }
                                        val capture = ImageCapture.Builder()
                                            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                                            .build()
                                        imageCapture = capture
                                        provider.unbindAll()
                                        provider.bindToLifecycle(
                                            lifecycleOwner,
                                            CameraSelector.DEFAULT_BACK_CAMERA,
                                            preview,
                                            capture,
                                        )
                                    } catch (_: Exception) {
                                        previewView.tag = null
                                        error = "Câmera indisponível."
                                    }
                                }, ContextCompat.getMainExecutor(context))
                            },
                        )
                        Text(
                            when (scanMode) {
                                "label" -> "Boa luz · tabela nutricional ou ingredientes · bem enquadrado"
                                "compare" -> if (compareSlot == 1) "Produto 1 de 2 · tabela nutricional"
                                             else "Produto 2 de 2 · tabela nutricional"
                                else -> "Boa luz · prato inteiro · de cima"
                            },
                            color = Color.White, fontSize = 12.sp,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp)
                                .clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(0.45f)).padding(6.dp),
                        )
                    }
                } else if (bitmap != null) {
                    Image(
                        bitmap = bitmap!!.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxWidth().height(240.dp).padding(horizontal = 16.dp)
                            .clip(RoundedCornerShape(16.dp)),
                        contentScale = ContentScale.Crop,
                    )
                }

                Text(
                    if (scanMode == "label")
                        "Fotografe a tabela nutricional e/ou a lista de ingredientes. Valores só são usados se legíveis no rótulo."
                    else
                        "Estimativas de porção são aproximadas. Confira sempre os itens e os carboidratos.",
                    color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp, 8.dp),
                )
                error?.let { Text(it, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp)) }

                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedButton(
                        onClick = { gallery.launch("image/*") },
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Filled.PhotoLibrary, null, tint = g.violet, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Galeria", color = g.violet)
                    }
                    if (phase == 0) {
                        Button(
                            onClick = { captureStill() },
                            colors = ButtonDefaults.buttonColors(containerColor = g.violet),
                            shape = CircleShape,
                            modifier = Modifier.size(64.dp),
                            contentPadding = PaddingValues(0.dp),
                        ) {
                            Icon(Icons.Filled.PhotoCamera, null, tint = Color.White)
                        }
                    } else {
                        Button(
                            onClick = { bitmap?.let { startAnalysis(it) } },
                            colors = ButtonDefaults.buttonColors(containerColor = g.green),
                            modifier = Modifier.weight(1.2f),
                        ) { Text("Analisar refeição") }
                    }
                }
                if (phase == 1) {
                    TextButton(onClick = { bitmap = null; phase = 0; error = null }) {
                        Text("Tirar outra foto", color = g.violet)
                    }
                    TextButton(onClick = { nav.navigate(Routes.FOOD_SEARCH) }) {
                        Text("Busca manual no catálogo", color = g.muted)
                    }
                }
            }

            2 -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = g.violet)
                        Spacer(Modifier.height(16.dp))
                        Text(progressMsg, color = g.ink, fontWeight = FontWeight.Medium)
                        Text("Aguarde…", color = g.muted, fontSize = 13.sp)
                    }
                }
            }

            3 -> {
                if (scanMode == "label" && labelResult != null) {
                    LabelResultContent(
                        result = labelResult!!,
                        bitmap = bitmap,
                        providerUsed = providerUsed,
                        g = g,
                        onNewScan = { phase = 1; labelResult = null },
                        onAskCris = {
                            val r = labelResult!!
                            vm.setCrisPendingPrompt(LabelScanStore.buildCrisContext(r))
                            nav.navigate(Routes.CRIS_IA)
                        },
                        onBolus = { carbs ->
                            context.getSharedPreferences("gluco_food_tools", android.content.Context.MODE_PRIVATE)
                                .edit()
                                .putFloat("last_meal_carbs", carbs.toFloat())
                                .apply()
                            nav.navigate(Routes.FOOD_BOLUS)
                        },
                    )
                } else {
                LazyColumn(Modifier.padding(horizontal = 12.dp)) {
                    item {
                        bitmap?.let {
                            Image(
                                bitmap = it.asImageBitmap(),
                                contentDescription = null,
                                modifier = Modifier.fillMaxWidth().height(140.dp)
                                    .clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.Crop,
                            )
                        }
                        Text(
                            "IA: $providerUsed · toque nos itens para ajustar · valores do catálogo Gluco Cris",
                            color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp),
                        )
                        GCard {
                            Text("Totais da refeição", color = g.ink, fontWeight = FontWeight.Bold)
                            Text("Carboidratos: ${"%.1f".format(totalCarbs)} g", color = g.violetDeep, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("Calorias: ${totalKcal.roundToInt()} kcal · Prot ${"%.1f".format(totalProt)} g · Gord ${"%.1f".format(totalFat)} g", color = g.ink, fontSize = 13.sp)
                            Text(
                                "Estimativas. Confira antes de usar para contagem de carb. Não define dose de insulina.",
                                color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp),
                            )
                        }
                        Box {
                            Text(
                                "Refeição: ${MEAL_OPTIONS.find { it.first == mealType }?.second}",
                                color = g.ink, fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { mealExpanded = true }.padding(8.dp),
                            )
                            DropdownMenu(mealExpanded, { mealExpanded = false }) {
                                MEAL_OPTIONS.forEach { (k, l) ->
                                    DropdownMenuItem(text = { Text(l) }, onClick = { mealType = k; mealExpanded = false })
                                }
                            }
                        }
                        SectionTitle("Alimentos identificados (${lines.size})")
                    }
                    items(lines, key = { it.id }) { line ->
                        VisionLineCard(line, g, onChange = { updated ->
                            lines = lines.map { if (it.id == updated.id) updated else it }
                        }, onRemove = {
                            lines = lines.filter { it.id != line.id }
                        })
                    }
                    item {
                        PrimaryButton("Salvar no diário alimentar", g.green, {
                            if (lines.isEmpty()) return@PrimaryButton
                            val desc = lines.joinToString(" + ") {
                                "${it.displayName} (${it.grams.roundToInt()} g)"
                            }
                            vm.saveMeal(
                                Meal(
                                    id = uid(),
                                    type = mealType,
                                    description = "Foto: $desc",
                                    carbs = totalCarbs,
                                    at = System.currentTimeMillis(),
                                    notes = "kcal=${totalKcal.roundToInt()};fonte=vision-$providerUsed;itens=${lines.size}",
                                ),
                            )
                            nav.popBackStack(Routes.FOOD, false)
                        }, Modifier.padding(vertical = 12.dp))
                        TextButton(onClick = { phase = 1 }) {
                            Text("Nova análise", color = g.violet)
                        }
                        Spacer(Modifier.height(24.dp))
                    }
                }
                } // fim else (modo plate)
            }
            4 -> {
                // Histórico de análises de rótulo
                LaunchedEffect(Unit) {
                    historyEntries = LabelScanStore.load(context)
                }
                LazyColumn(Modifier.padding(horizontal = 12.dp)) {
                    item {
                        SectionTitle("Histórico de rótulos (${historyEntries.size})")
                        Text(
                            "Análises salvas neste aparelho. Não se misturam com glicemia.",
                            color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp),
                        )
                        if (historyEntries.isEmpty()) {
                            GCard {
                                Text("Nenhuma análise de rótulo ainda.", color = g.muted)
                            }
                        }
                    }
                    items(historyEntries, key = { it.id }) { e ->
                        GCard(Modifier.padding(bottom = 8.dp)) {
                            Text(e.productName ?: "Produto", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                            if (!e.brand.isNullOrBlank()) Text(e.brand!!, color = g.violet, fontSize = 12.sp)
                            Text(
                                buildString {
                                    e.carbs?.let { append("Carb ${it} g · ") }
                                    e.sugars?.let { append("Açúc ${it} g · ") }
                                    e.kcal?.let { append("${it.toInt()} kcal") }
                                }.trim(' ', '·'),
                                color = g.violetDeep, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                            )
                            e.ingredientsSummary?.let {
                                Text(it.take(120), color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
                            }
                            Text(
                                java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale("pt", "BR")).format(java.util.Date(e.at))
                                    + (e.provider?.let { " · $it" } ?: ""),
                                color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp),
                            )
                            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                Text("Perguntar à Cris", color = g.violet, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.clickable {
                                        vm.setCrisPendingPrompt(LabelScanStore.buildCrisContextFromEntry(e))
                                        nav.navigate(Routes.CRIS_IA)
                                    })
                                Text("Excluir", color = g.red, fontSize = 12.sp,
                                    modifier = Modifier.clickable {
                                        LabelScanStore.delete(context, e.id)
                                        historyEntries = LabelScanStore.load(context)
                                    })
                            }
                        }
                    }
                    item {
                        if (historyEntries.isNotEmpty()) {
                            TextButton(onClick = {
                                LabelScanStore.clear(context)
                                historyEntries = emptyList()
                            }) { Text("Limpar histórico", color = g.red) }
                        }
                        TextButton(onClick = { scanMode = "label"; phase = 0 }) {
                            Text("Nova análise de rótulo", color = g.violet)
                        }
                        Spacer(Modifier.height(24.dp))
                    }
                }
            }
            5 -> {
                // Comparação lado a lado
                val a = labelA
                val b = labelB
                LazyColumn(Modifier.padding(horizontal = 12.dp)) {
                    item {
                        SectionTitle("Comparação de produtos")
                        if (a == null || b == null) {
                            Text("Escaneie dois produtos para comparar.", color = g.muted)
                        } else {
                            fun valOf(r: LabelAnalysisResult, pick: (com.agon.app.data.NutritionValues) -> Double?): String {
                                val n = r.nutrition?.perServing ?: r.nutrition?.per100g
                                val v = n?.let { pick(it) }
                                return v?.let { "%.1f".format(it) } ?: "—"
                            }
                            GCard {
                                Text("Produto A", color = g.violet, fontWeight = FontWeight.Bold)
                                Text(a.productName ?: "—", color = g.ink, fontWeight = FontWeight.SemiBold)
                                if (!a.brand.isNullOrBlank()) Text(a.brand!!, color = g.muted, fontSize = 12.sp)
                            }
                            GCard {
                                Text("Produto B", color = g.violet, fontWeight = FontWeight.Bold)
                                Text(b.productName ?: "—", color = g.ink, fontWeight = FontWeight.SemiBold)
                                if (!b.brand.isNullOrBlank()) Text(b.brand!!, color = g.muted, fontSize = 12.sp)
                            }
                            SectionTitle("Lado a lado")
                            GCard {
                                Row(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
                                    Text("Nutriente", color = g.muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1.2f))
                                    Text("A", color = g.muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    Text("B", color = g.muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                }
                                data class RowCmp(val label: String, val fa: (com.agon.app.data.NutritionValues) -> Double?)
                                listOf(
                                    RowCmp("Carboidratos (g)") { it.carbs },
                                    RowCmp("Açúcares (g)") { it.sugars },
                                    RowCmp("Açúc. adic. (g)") { it.addedSugars },
                                    RowCmp("Proteínas (g)") { it.protein },
                                    RowCmp("Gorduras (g)") { it.fat },
                                    RowCmp("Gord. sat. (g)") { it.satFat },
                                    RowCmp("Fibras (g)") { it.fiber },
                                    RowCmp("Sódio (mg)") { it.sodium },
                                    RowCmp("Calorias (kcal)") { it.kcal },
                                ).forEach { row ->
                                    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
                                        Text(row.label, color = g.ink, fontSize = 12.sp, modifier = Modifier.weight(1.2f))
                                        Text(valOf(a, row.fa), color = g.violetDeep, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                                        Text(valOf(b, row.fa), color = g.violetDeep, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                                    }
                                }
                                Text(
                                    "Comparação com base nos valores lidos (por porção se disponível, senão por 100 g). Não declara vencedor quando faltam dados.",
                                    color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp),
                                )
                            }
                            PrimaryButton("💬 Perguntar à Cris sobre a comparação", g.violet, {
                                val ctx = buildString {
                                    append("Compare estes dois produtos para quem acompanha a glicemia.\n\n")
                                    append("PRODUTO A:\n")
                                    append(LabelScanStore.buildCrisContext(a))
                                    append("\n\nPRODUTO B:\n")
                                    append(LabelScanStore.buildCrisContext(b))
                                    append("\n\nExplique diferenças de carboidratos, açúcares e pontos de atenção, sem declarar um alimento como saudável para todos.")
                                }
                                vm.setCrisPendingPrompt(ctx)
                                nav.navigate(Routes.CRIS_IA)
                            })
                        }
                        Spacer(Modifier.height(8.dp))
                        TextButton(onClick = {
                            labelA = null; labelB = null; compareSlot = 1
                            scanMode = "compare"; phase = 0; bitmap = null
                        }) { Text("Nova comparação", color = g.violet) }
                        Spacer(Modifier.height(24.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun VisionLineCard(
    line: VisionMealLine,
    g: com.agon.app.ui.theme.GlucoColors,
    onChange: (VisionMealLine) -> Unit,
    onRemove: () -> Unit,
) {
    var gramsText by remember(line.id, line.grams) { mutableStateOf(line.grams.let { if (it == it.toLong().toDouble()) it.toLong().toString() else "%.0f".format(it) }) }
    GCard(Modifier.padding(bottom = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(line.displayName, color = g.ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                if (line.displayName != line.detectedName) {
                    Text("Detectado: ${line.detectedName}", color = g.muted, fontSize = 11.sp)
                }
                line.confidence?.let {
                    Text("Confiança ~${(it * 100).roundToInt()}%", color = g.muted, fontSize = 11.sp)
                }
            }
            Text("Remover", color = g.red, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onRemove))
        }
        if (line.food == null) {
            Text(
                "Não encontrado no catálogo — ajuste o nome ou busque manualmente. Nutrientes não inventados.",
                color = g.orange, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
            )
        } else {
            Text(
                "${line.food!!.source} · base ${line.food!!.serving}",
                color = g.muted, fontSize = 11.sp,
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
            Text("g", color = g.muted, modifier = Modifier.width(20.dp))
            OutlinedTextField(
                value = gramsText,
                onValueChange = { raw ->
                    gramsText = raw.filter { it.isDigit() || it == ',' || it == '.' }
                    gramsText.replace(",", ".").toDoubleOrNull()?.let { gVal ->
                        if (gVal > 0) onChange(line.copy(grams = gVal, household = "${gVal.roundToInt()} g"))
                    }
                },
                modifier = Modifier.width(100.dp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            )
            IconButton(onClick = {
                val n = (line.grams - 10).coerceAtLeast(5.0)
                onChange(line.copy(grams = n, household = "${n.roundToInt()} g"))
                gramsText = n.roundToInt().toString()
            }) { Text("−", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
            IconButton(onClick = {
                val n = line.grams + 10
                onChange(line.copy(grams = n, household = "${n.roundToInt()} g"))
                gramsText = n.roundToInt().toString()
            }) { Text("+", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
        }
        if (line.food != null) {
            Text(
                "Carb ${"%.1f".format(line.carbs())} g · ${line.kcal().roundToInt()} kcal · " +
                    "Prot ${"%.1f".format(line.protein())} g · Gord ${"%.1f".format(line.fat())} g",
                color = g.violetDeep, fontWeight = FontWeight.Medium, fontSize = 13.sp,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
        if (line.alternatives.isNotEmpty()) {
            Text("Trocar por:", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            line.alternatives.take(3).forEach { alt ->
                Text(
                    "→ ${alt.name} (${alt.source})",
                    color = g.violet, fontSize = 12.sp,
                    modifier = Modifier.clickable {
                        onChange(
                            line.copy(
                                displayName = alt.name,
                                food = alt,
                                household = alt.serving,
                            ),
                        )
                    }.padding(vertical = 2.dp),
                )
            }
        }
    }
}

private fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
    return try {
        val yBuffer = image.planes[0].buffer
        val uBuffer = image.planes[1].buffer
        val vBuffer = image.planes[2].buffer
        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()
        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)
        val yuv = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
        val out = ByteArrayOutputStream()
        yuv.compressToJpeg(Rect(0, 0, image.width, image.height), 88, out)
        val bytes = out.toByteArray()
        var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        val rotation = image.imageInfo.rotationDegrees
        if (rotation != 0) {
            val m = Matrix().apply { postRotate(rotation.toFloat()) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        bmp
    } catch (_: Exception) {
        null
    }
}



@Composable
private fun LabelResultContent(
    result: LabelAnalysisResult,
    bitmap: Bitmap?,
    providerUsed: String,
    g: com.agon.app.ui.theme.GlucoColors,
    onNewScan: () -> Unit,
    onAskCris: () -> Unit,
    onBolus: (carbs: Double) -> Unit,
) {
    val context = LocalContext.current

    var name by remember(result) {
        mutableStateOf(
            buildString {
                result.productName?.let { append(it) }
                if (!result.brand.isNullOrBlank()) {
                    if (isNotEmpty()) append(" – ")
                    append(result.brand)
                }
                if (isEmpty()) append("Produto do rótulo")
            },
        )
    }
    var serving by remember(result) {
        mutableStateOf(result.nutrition?.servingSize?.takeIf { it.isNotBlank() } ?: "1 porção")
    }
    val base = result.nutrition?.perServing ?: result.nutrition?.per100g
    var carbsTxt by remember(result) { mutableStateOf(base?.carbs?.let { fmtNum(it) } ?: "") }
    var proteinTxt by remember(result) { mutableStateOf(base?.protein?.let { fmtNum(it) } ?: "") }
    var fatTxt by remember(result) { mutableStateOf(base?.fat?.let { fmtNum(it) } ?: "") }
    var kcalTxt by remember(result) { mutableStateOf(base?.kcal?.let { fmtNum(it) } ?: "") }
    var sugarsTxt by remember(result) { mutableStateOf(base?.sugars?.let { fmtNum(it) } ?: "") }
    var fiberTxt by remember(result) { mutableStateOf(base?.fiber?.let { fmtNum(it) } ?: "") }
    var sodiumTxt by remember(result) { mutableStateOf(base?.sodium?.let { fmtNum(it) } ?: "") }
    var satFatTxt by remember(result) { mutableStateOf(base?.satFat?.let { fmtNum(it) } ?: "") }
    var savedMsg by remember { mutableStateOf<String?>(null) }
    var saveError by remember { mutableStateOf<String?>(null) }

    fun parseDec(s: String): Double? = s.replace(",", ".").trim().toDoubleOrNull()

    LazyColumn(Modifier.padding(horizontal = 12.dp)) {
        item {
            bitmap?.let {
                Image(
                    bitmap = it.asImageBitmap(),
                    contentDescription = null,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(140.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    contentScale = ContentScale.Crop,
                )
            }
            Text(
                "IA: $providerUsed · confira e corrija os valores antes de salvar",
                color = g.muted,
                fontSize = 11.sp,
                modifier = Modifier.padding(vertical = 8.dp),
            )

            GCard {
                Text("Nome do alimento", color = g.muted, fontSize = 12.sp)
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                    singleLine = true,
                    textStyle = LocalTextStyle.current.copy(fontWeight = FontWeight.Bold, fontSize = 17.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = g.violet,
                        unfocusedBorderColor = g.line,
                        focusedContainerColor = g.inputBg,
                        unfocusedContainerColor = g.inputBg,
                    ),
                )
                if (!result.brand.isNullOrBlank() || !result.netWeight.isNullOrBlank()) {
                    Text(
                        listOfNotNull(
                            result.brand?.takeIf { it.isNotBlank() }?.let { "Marca: $it" },
                            result.netWeight?.takeIf { it.isNotBlank() }?.let { "Peso: $it" },
                        ).joinToString(" · "),
                        color = g.muted,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
                result.confidenceNotes?.let {
                    Text("⚠️ $it", color = g.red, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
                }
            }

            Spacer(Modifier.height(8.dp))

            SectionTitle("Valores nutricionais (editáveis)")
            GCard {
                Text("Porção de referência", color = g.muted, fontSize = 12.sp)
                OutlinedTextField(
                    value = serving,
                    onValueChange = { serving = it },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    singleLine = true,
                    placeholder = { Text("Ex.: 30 g (2 biscoitos)") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = g.violet,
                        unfocusedBorderColor = g.line,
                        focusedContainerColor = g.inputBg,
                        unfocusedContainerColor = g.inputBg,
                    ),
                )
                EditableNutrientRow("Carboidratos (g)", carbsTxt, { carbsTxt = it }, g)
                EditableNutrientRow("Proteínas (g)", proteinTxt, { proteinTxt = it }, g)
                EditableNutrientRow("Gorduras (g)", fatTxt, { fatTxt = it }, g)
                EditableNutrientRow("Calorias (kcal)", kcalTxt, { kcalTxt = it }, g)
                EditableNutrientRow("Açúcares (g)", sugarsTxt, { sugarsTxt = it }, g)
                EditableNutrientRow("Fibras (g)", fiberTxt, { fiberTxt = it }, g)
                EditableNutrientRow("Sódio (mg)", sodiumTxt, { sodiumTxt = it }, g)
                EditableNutrientRow("Gord. saturadas (g)", satFatTxt, { satFatTxt = it }, g)
                Text(
                    "Corrija se a leitura estiver errada. Os valores salvos no catálogo usam esta porção.",
                    color = g.muted,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(top = 6.dp),
                )
            }

            Spacer(Modifier.height(8.dp))

            if (result.ingredients.isNotEmpty()) {
                SectionTitle("Ingredientes (${result.ingredients.size})")
                result.ingredients.forEach { ing ->
                    GCard(Modifier.padding(bottom = 6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                ing.name,
                                color = g.ink,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 14.sp,
                                modifier = Modifier.weight(1f),
                            )
                            if (ing.isSugarOrSweetener) {
                                Text(
                                    "açúcar/adoçante",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(g.violet)
                                        .padding(horizontal = 6.dp, vertical = 2.dp),
                                )
                            } else if (ing.mayRaiseGlucose) {
                                Text(
                                    "pode ↑ glicemia",
                                    color = Color.White,
                                    fontSize = 10.sp,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(g.violet.copy(alpha = 0.7f))
                                        .padding(horizontal = 6.dp, vertical = 2.dp),
                                )
                            }
                            if (ing.attention) {
                                Text(" ⚠", color = g.red, fontSize = 14.sp)
                            }
                        }
                        Text(
                            ing.simpleExplanation,
                            color = g.muted,
                            fontSize = 12.sp,
                            modifier = Modifier.padding(top = 4.dp),
                        )
                    }
                }
            }

            if (result.allergens.isNotEmpty()) {
                SectionTitle("Alergênicos")
                GCard {
                    result.allergens.forEach { Text("• $it", color = g.ink, fontSize = 13.sp) }
                }
            }
            if (result.warnings.isNotEmpty()) {
                SectionTitle("Avisos do rótulo")
                GCard {
                    result.warnings.forEach { Text("• $it", color = g.red, fontSize = 13.sp) }
                }
            }

            savedMsg?.let {
                Text(it, color = g.green, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            }
            saveError?.let {
                Text(it, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            }

            Spacer(Modifier.height(12.dp))

            PrimaryButton("➕ Adicionar ao catálogo Gluco Cris", g.green, {
                val c = parseDec(carbsTxt)
                if (name.isBlank()) {
                    saveError = "Informe o nome do alimento."
                    savedMsg = null
                    return@PrimaryButton
                }
                if (c == null) {
                    saveError = "Carboidratos são obrigatórios para salvar no catálogo."
                    savedMsg = null
                    return@PrimaryButton
                }
                val item = CustomFood(
                    id = uid(),
                    name = name.trim(),
                    serving = serving.trim().ifBlank { "1 porção" },
                    carbs = c,
                    protein = parseDec(proteinTxt) ?: 0.0,
                    fat = parseDec(fatTxt) ?: 0.0,
                    kcal = parseDec(kcalTxt) ?: 0.0,
                )
                val list = loadCustomFoods(context)
                saveCustomFoods(context, listOf(item) + list)
                savedMsg = "✅ Salvo no catálogo: ${item.name}"
                saveError = null
            })

            Spacer(Modifier.height(8.dp))

            PrimaryButton("💉 Calculadora de Bolus", g.violet, {
                val c = parseDec(carbsTxt) ?: 0.0
                onBolus(c)
            })

            Spacer(Modifier.height(8.dp))
            PrimaryButton("💬 Perguntar à Cris IA sobre este alimento", g.violet.copy(alpha = 0.85f), onAskCris)

            Spacer(Modifier.height(8.dp))
            TextButton(onClick = onNewScan) {
                Text("Nova análise", color = g.violet)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

private fun fmtNum(v: Double): String =
    if (v == v.toLong().toDouble()) v.toLong().toString() else "%.1f".format(v)

@Composable
private fun EditableNutrientRow(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    g: com.agon.app.ui.theme.GlucoColors,
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(label, color = g.ink, fontSize = 13.sp, modifier = Modifier.weight(1.2f))
        OutlinedTextField(
            value = value,
            onValueChange = { raw -> onChange(raw.filter { it.isDigit() || it == ',' || it == '.' }) },
            modifier = Modifier.weight(1f),
            singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = g.violet,
                unfocusedBorderColor = g.line,
                focusedContainerColor = g.inputBg,
                unfocusedContainerColor = g.inputBg,
            ),
        )
    }
}
