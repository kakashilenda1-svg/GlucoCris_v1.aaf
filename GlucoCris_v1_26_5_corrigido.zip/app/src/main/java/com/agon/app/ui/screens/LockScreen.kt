package com.agon.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.GlucoViewModel
import com.agon.app.ui.theme.glucoColors

@Composable
fun LockScreen(vm: GlucoViewModel, displayName: String) {
    val g = glucoColors()
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(g.heroStart, g.bg))).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Gluco Cris ❤️", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
        Text(displayName, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
        Text("Área pessoal protegida por PIN", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        Text(
            "● ".repeat(pin.length) + "○ ".repeat(4 - pin.length),
            color = Color.White,
            fontSize = 22.sp,
            modifier = Modifier.padding(vertical = 20.dp),
        )
        if (error) Text("PIN incorreto. Tente novamente.", color = Color(0xFFFECACA), fontSize = 13.sp)
        val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫")
        keys.chunked(3).forEach { row ->
            androidx.compose.foundation.layout.Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                row.forEach { key ->
                    Box(
                        Modifier
                            .padding(6.dp)
                            .size(72.dp)
                            .clip(CircleShape)
                            .background(if (key.isEmpty()) Color.Transparent else Color.White.copy(alpha = 0.16f))
                            .clickable(enabled = key.isNotEmpty()) {
                                when (key) {
                                    "⌫" -> {
                                        if (pin.isNotEmpty()) pin = pin.dropLast(1)
                                        error = false
                                    }
                                    else -> if (pin.length < 4) {
                                        pin += key
                                        error = false
                                        if (pin.length == 4) {
                                            if (!vm.unlock(pin)) {
                                                error = true
                                                pin = ""
                                            }
                                        }
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(if (key == "⌫") "Apagar" else key, color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (key == "⌫") 12.sp else 22.sp, textAlign = TextAlign.Center)
                    }
                }
            }
        }
        Text(
            "A personalização visual não substitui o PIN. Seus registros ficam neste aparelho.",
            color = Color.White.copy(alpha = 0.8f),
            fontSize = 12.sp,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 18.dp),
        )
        Box(Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp)))
    }
}
