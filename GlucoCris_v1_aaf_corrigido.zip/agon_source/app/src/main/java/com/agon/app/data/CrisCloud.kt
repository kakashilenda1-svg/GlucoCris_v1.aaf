package com.agon.app.data

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Conexão da Cris com a IA na nuvem (conversa natural + voz natural).
 * Se a internet cair, o app usa a Cris local automaticamente.
 *
 * BASE_URL: endereço do servidor da Cris. Depois de publicar o servidor,
 * troque aqui pelo endereço definitivo.
 */
object CrisCloud {
    const val BASE_URL = "https://insulina-voz.preview.emergentagent.com"

    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    @Serializable
    data class Turn(val fromUser: Boolean, val text: String)

    @Serializable
    private data class ChatReq(
        val message: String,
        val history: List<Turn>,
        val context: String,
        val voice: Boolean,
        val userName: String,
    )

    @Serializable
    private data class ChatRes(val reply: String)

    @Serializable
    private data class TtsReq(val text: String)

    suspend fun chat(message: String, history: List<Turn>, context: String, voice: Boolean, userName: String): String? =
        withContext(Dispatchers.IO) {
            try {
                val body = json.encodeToString(ChatReq(message, history.takeLast(16), context, voice, userName))
                val bytes = post("/api/cris/chat", body, 30_000)
                json.decodeFromString<ChatRes>(String(bytes, Charsets.UTF_8)).reply.ifBlank { null }
            } catch (_: Exception) {
                null
            }
        }

    suspend fun tts(context: Context, text: String): File? = withContext(Dispatchers.IO) {
        try {
            val bytes = post("/api/cris/tts", json.encodeToString(TtsReq(text.take(3800))), 20_000)
            if (bytes.size < 500) return@withContext null
            val f = File(context.cacheDir, "cris_voice_${System.currentTimeMillis()}.mp3")
            f.writeBytes(bytes)
            f
        } catch (_: Exception) {
            null
        }
    }

    private fun post(path: String, body: String, timeoutMs: Int): ByteArray {
        val conn = URL(BASE_URL + path).openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.connectTimeout = 12_000
            conn.readTimeout = timeoutMs
            conn.doOutput = true
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode !in 200..299) throw IllegalStateException("HTTP ${conn.responseCode}")
            return conn.inputStream.use { it.readBytes() }
        } finally {
            conn.disconnect()
        }
    }
}

/**
 * Fala da Cris: voz natural da nuvem; se falhar, usa a voz do aparelho.
 * Só um áudio toca por vez.
 */
class CrisSpeaker(private val context: Context) {
    private var player: MediaPlayer? = null
    private var deviceTts: TextToSpeech? = null
    private var deviceReady = false
    private var waiting: CancellableContinuation<Boolean>? = null
    private var lastFile: File? = null

    init {
        deviceTts = TextToSpeech(context.applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                deviceTts?.language = Locale("pt", "BR")
                deviceReady = true
            }
        }
    }

    /** Suspende até terminar de falar. Retorna false se foi interrompida. */
    suspend fun speak(text: String, onStart: () -> Unit = {}): Boolean {
        stop()
        val clean = text.replace("**", "").replace("•", "").trim()
        if (clean.isBlank()) return true
        val file = CrisCloud.tts(context, clean)
        if (file != null) {
            lastFile?.delete()
            lastFile = file
            val ok = playFile(file, onStart)
            if (ok) return true
        }
        return speakDevice(clean.take(900), onStart)
    }

    private suspend fun playFile(f: File, onStart: () -> Unit): Boolean = suspendCancellableCoroutine { cont ->
        waiting = cont
        try {
            val mp = MediaPlayer()
            player = mp
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build(),
            )
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { finish(true) }
            mp.setOnErrorListener { _, _, _ -> finish(false); true }
            mp.prepare()
            mp.start()
            onStart()
        } catch (_: Exception) {
            finish(false)
        }
        cont.invokeOnCancellation { stopPlayerOnly() }
    }

    private suspend fun speakDevice(text: String, onStart: () -> Unit): Boolean {
        val engine = deviceTts ?: return false
        if (!deviceReady) return false
        return suspendCancellableCoroutine { cont ->
            waiting = cont
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { finish(true) }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { finish(false) }
            })
            onStart()
            engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, "cris")
            cont.invokeOnCancellation { engine.stop() }
        }
    }

    private fun finish(ok: Boolean) {
        val c = waiting
        waiting = null
        if (c != null && c.isActive) c.resume(ok)
    }

    private fun stopPlayerOnly() {
        try { player?.stop() } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    fun stop() {
        stopPlayerOnly()
        try { deviceTts?.stop() } catch (_: Exception) {}
        finish(false)
    }

    fun release() {
        stop()
        try { deviceTts?.shutdown() } catch (_: Exception) {}
        deviceTts = null
        lastFile?.delete()
    }
}
