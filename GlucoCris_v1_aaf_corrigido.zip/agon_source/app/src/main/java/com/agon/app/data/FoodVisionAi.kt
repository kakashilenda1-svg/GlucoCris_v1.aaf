package com.agon.app.data

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import android.util.Log
import com.agon.app.BuildConfig
import com.agon.app.ui.screens.FoodItem
import com.agon.app.ui.screens.loadTacoFoods
import com.agon.app.ui.screens.searchFoodsComplete
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.roundToInt

/** Item identificado pela IA (ainda sem nutrientes do catálogo). */
data class VisionDetectedFood(
    val name: String,
    val quantityGrams: Double?,
    val householdMeasure: String?,
    val confidence: Double?,
    val notes: String? = null,
)

data class VisionAnalysisResult(
    val items: List<VisionDetectedFood>,
    val provider: String,
    val rawNotes: String? = null,
)

/** Item já casado com o banco nutricional do Gluco Cris. */
data class VisionMealLine(
    val id: String,
    val detectedName: String,
    var displayName: String,
    var grams: Double,
    var household: String,
    var confidence: Double?,
    var food: FoodItem?,
    val alternatives: List<FoodItem> = emptyList(),
) {
    fun factor(): Double {
        val base = food?.servingGrams?.takeIf { it > 0 } ?: 100.0
        return grams / base
    }

    fun carbs(): Double = food?.let { it.carbs * factor() } ?: 0.0
    fun kcal(): Double = food?.let { it.kcal * factor() } ?: 0.0
    fun protein(): Double = food?.let { it.protein * factor() } ?: 0.0
    fun fat(): Double = food?.let { it.fat * factor() } ?: 0.0
    fun fiber(): Double = food?.let { it.fiber * factor() } ?: 0.0
    fun sugars(): Double = food?.let { it.sugars * factor() } ?: 0.0
    fun sodium(): Double = food?.let { it.sodium * factor() } ?: 0.0
}

object FoodVisionAi {
    private const val TAG = "FoodVisionAi"

    fun hasGeminiKey(): Boolean = BuildConfig.GEMINI_API_KEY.isNotBlank()

    fun providerLabel(): String =
        if (hasGeminiKey()) "Gemini (${BuildConfig.GEMINI_MODEL}) + Open Food Facts"
        else "ML Kit + Open Food Facts (sem chave Gemini)"

    /**
     * Comprime e redimensiona a imagem antes do envio (economia de cota/custo).
     */
    fun prepareImageBase64(bitmap: Bitmap, maxSide: Int = 768, quality: Int = 82): String {
        var bmp = bitmap
        val max = maxOf(bmp.width, bmp.height)
        if (max > maxSide) {
            val scale = maxSide.toFloat() / max
            bmp = Bitmap.createScaledBitmap(
                bmp,
                (bmp.width * scale).toInt().coerceAtLeast(1),
                (bmp.height * scale).toInt().coerceAtLeast(1),
                true,
            )
        }
        val baos = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, baos)
        return Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun analyzeWithGemini(bitmap: Bitmap): VisionAnalysisResult = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY
        if (key.isBlank()) error("Chave Gemini não configurada. Defina gemini.api.key em local.properties.")

        val b64 = prepareImageBase64(bitmap)
        val model = BuildConfig.GEMINI_MODEL.ifBlank { "gemini-3.8-flash" }
        val url = URL(
            "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key",
        )

        val prompt = """
Você é um assistente nutricional para o app brasileiro Gluco Cris (diabetes / contagem de carboidratos).
Analise a foto da refeição e identifique CADA alimento visível separadamente (comida brasileira quando possível).

Responda APENAS com JSON válido (sem markdown), neste formato:
{
  "items": [
    {
      "name": "nome do alimento em português",
      "grams": 120,
      "household": "1 concha",
      "confidence": 0.0 a 1.0,
      "notes": "opcional"
    }
  ],
  "notes": "observação geral opcional"
}

Regras:
- Separe itens misturados (arroz, feijão, carne, salada, etc.).
- grams é ESTIMATIVA; se incerto use null e explique em notes.
- Não invente alimentos que não aparecem na foto.
- Prefira nomes comuns no Brasil (arroz branco cozido, feijão carioca, frango grelhado...).
- Se a imagem não for comida, items: [].
""".trimIndent()

        val body = JSONObject()
            .put(
                "contents",
                JSONArray().put(
                    JSONObject().put(
                        "parts",
                        JSONArray()
                            .put(JSONObject().put("text", prompt))
                            .put(
                                JSONObject().put(
                                    "inline_data",
                                    JSONObject()
                                        .put("mime_type", "image/jpeg")
                                        .put("data", b64),
                                ),
                            ),
                    ),
                ),
            )
            .put(
                "generationConfig",
                JSONObject()
                    .put("temperature", 0.2)
                    .put("maxOutputTokens", 2048),
            )

        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 25000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Content-Type", "application/json; charset=utf-8")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val resp = stream?.bufferedReader()?.readText().orEmpty()
        if (code !in 200..299) {
            Log.w(TAG, "Gemini HTTP $code: ${resp.take(400)}")
            error(parseGeminiError(resp, code))
        }

        val text = extractGeminiText(resp)
        parseVisionJson(text, "Gemini")
    }

    private fun parseGeminiError(resp: String, code: Int): String {
        return try {
            val msg = JSONObject(resp).optJSONObject("error")?.optString("message")
            when {
                code == 429 -> "Limite de uso da API atingido. Tente mais tarde."
                code == 403 -> "Chave Gemini inválida ou sem permissão."
                !msg.isNullOrBlank() -> "Erro da IA: $msg"
                else -> "Erro HTTP $code na API Gemini."
            }
        } catch (_: Exception) {
            "Erro HTTP $code na API Gemini."
        }
    }

    private fun extractGeminiText(resp: String): String {
        val root = JSONObject(resp)
        val candidates = root.optJSONArray("candidates") ?: return ""
        if (candidates.length() == 0) return ""
        val parts = candidates.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts")
            ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            sb.append(parts.getJSONObject(i).optString("text"))
        }
        return sb.toString().trim()
    }

    private fun parseVisionJson(text: String, provider: String): VisionAnalysisResult {
        var cleaned = text.trim()
        if (cleaned.startsWith("```")) {
            cleaned = cleaned.removePrefix("```json").removePrefix("```JSON").removePrefix("```").trim()
            if (cleaned.endsWith("```")) cleaned = cleaned.dropLast(3).trim()
        }
        val start = cleaned.indexOf('{')
        val end = cleaned.lastIndexOf('}')
        if (start < 0 || end <= start) return VisionAnalysisResult(emptyList(), provider, "Resposta sem JSON")
        val obj = JSONObject(cleaned.substring(start, end + 1))
        val arr = obj.optJSONArray("items") ?: JSONArray()
        val items = mutableListOf<VisionDetectedFood>()
        for (i in 0 until arr.length()) {
            val it = arr.getJSONObject(i)
            val name = it.optString("name", "").trim()
            if (name.isBlank()) continue
            val grams = if (it.has("grams") && !it.isNull("grams")) it.optDouble("grams") else null
            items.add(
                VisionDetectedFood(
                    name = name,
                    quantityGrams = grams?.takeIf { it > 0 },
                    householdMeasure = it.optString("household", "").ifBlank { null },
                    confidence = if (it.has("confidence")) it.optDouble("confidence") else null,
                    notes = it.optString("notes", "").ifBlank { null },
                ),
            )
        }
        return VisionAnalysisResult(
            items = items,
            provider = provider,
            rawNotes = obj.optString("notes", "").ifBlank { null },
        )
    }


    /**
     * Fallback sem Gemini: rótulos ML Kit → nomes de alimentos → depois o catálogo OFF/local.
     */
    suspend fun analyzeWithMlKitLabels(bitmap: Bitmap): VisionAnalysisResult = withContext(Dispatchers.IO) {
        try {
            val labeler = com.google.mlkit.vision.label.ImageLabeling.getClient(
                com.google.mlkit.vision.label.defaults.ImageLabelerOptions.DEFAULT_OPTIONS,
            )
            val image = com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap, 0)
            val labels = com.google.android.gms.tasks.Tasks.await(labeler.process(image))
            labeler.close()
            val foodish = labels
                .filter { it.confidence >= 0.55f }
                .map { it.text.trim() }
                .filter { it.length in 3..40 }
                .distinct()
                .take(8)
            if (foodish.isEmpty()) {
                return@withContext VisionAnalysisResult(
                    emptyList(),
                    "ML Kit + OFF",
                    "Não foi possível rotular alimentos na foto. Tente outra imagem ou configure Gemini.",
                )
            }
            val items = foodish.map { name ->
                VisionDetectedFood(
                    name = name,
                    quantityGrams = 100.0,
                    householdMeasure = "100 g (estimativa)",
                    confidence = 0.6,
                    notes = "Rótulo ML Kit; nutrientes vêm do catálogo OFF/local",
                )
            }
            VisionAnalysisResult(items, "ML Kit + Open Food Facts", null)
        } catch (e: Exception) {
            Log.w(TAG, "ML Kit labels", e)
            VisionAnalysisResult(
                emptyList(),
                "ML Kit + OFF",
                e.message ?: "Falha no reconhecimento local da imagem.",
            )
        }
    }

    /**
     * Preferência: Gemini → se falhar ou sem chave, ML Kit + match no Open Food Facts/local.
     */
    suspend fun analyzePlate(bitmap: Bitmap): VisionAnalysisResult {
        if (hasGeminiKey()) {
            return try {
                analyzeWithGemini(bitmap)
            } catch (e: Exception) {
                Log.w(TAG, "Gemini falhou, fallback ML Kit/OFF", e)
                val fb = analyzeWithMlKitLabels(bitmap)
                if (fb.items.isEmpty()) {
                    VisionAnalysisResult(
                        emptyList(),
                        "Gemini falhou → OFF",
                        (e.message ?: "Gemini indisponível") + " · " + (fb.rawNotes ?: ""),
                    )
                } else fb.copy(provider = "Fallback: ML Kit + Open Food Facts", rawNotes = e.message)
            }
        }
        return analyzeWithMlKitLabels(bitmap)
    }

    /**
     * Quando o código de barras não está no Open Food Facts, tenta Gemini (texto) para sugerir o produto.
     * Nutrientes só se a IA devolver números; senão null.
     */
    suspend fun lookupBarcodeWithGemini(code: String): FoodItem? = withContext(Dispatchers.IO) {
        val key = BuildConfig.GEMINI_API_KEY
        if (key.isBlank()) return@withContext null
        try {
            val model = BuildConfig.GEMINI_MODEL.ifBlank { "gemini-2.0-flash" }
            val url = URL(
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$key",
            )
            val prompt = """
Código de barras (EAN/UPC): $code
Se você reconhecer o produto alimentício vendido no Brasil ou no mundo, responda APENAS JSON:
{"name":"...","brand":"...","kcal_100g":0,"carbs_100g":0,"protein_100g":0,"fat_100g":0,"serving":"100 g"}
Se não souber com segurança, responda: {"name":""}
Não invente valores nutricionais se não tiver base.
""".trimIndent()
            val body = JSONObject()
                .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))))
                .put("generationConfig", JSONObject().put("temperature", 0.2).put("maxOutputTokens", 512))
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                connectTimeout = 12000
                readTimeout = 15000
                doOutput = true
            }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val codeHttp = conn.responseCode
            val resp = (if (codeHttp in 200..299) conn.inputStream else conn.errorStream)
                ?.bufferedReader()?.readText().orEmpty()
            if (codeHttp !in 200..299) return@withContext null
            val text = extractGeminiText(resp)
            val jsonStr = text.substringAfter("{").substringBeforeLast("}").let { "{$it}" }
            val o = JSONObject(jsonStr)
            val name = o.optString("name", "").trim()
            if (name.isBlank()) return@withContext null
            val kcal = o.optDouble("kcal_100g", 0.0)
            val carbs = o.optDouble("carbs_100g", 0.0)
            FoodItem(
                id = "bc-gemini-$code",
                name = name,
                brand = o.optString("brand", ""),
                serving = o.optString("serving", "100 g").ifBlank { "100 g" },
                servingGrams = 100.0,
                kcal = kcal,
                kj = kcal * 4.184,
                carbs = carbs,
                protein = o.optDouble("protein_100g", 0.0),
                fat = o.optDouble("fat_100g", 0.0),
                source = "Gemini (código não achado no OFF)",
                sourceKey = "gemini",
                isGeneric = true,
                reliability = "estimada",
                category = "",
            )
        } catch (e: Exception) {
            Log.w(TAG, "barcode Gemini", e)
            null
        }
    }

    /**
     * Casa cada item detectado com o catálogo do app (searchFoodsComplete).
     * Não inventa nutrientes: se não achar, food fica null.
     */
    suspend fun matchToCatalog(
        context: Context,
        analysis: VisionAnalysisResult,
    ): List<VisionMealLine> = withContext(Dispatchers.IO) {
        val taco = loadTacoFoods(context)
        analysis.items.mapIndexed { index, det ->
            val results = try {
                searchFoodsComplete(context, det.name, taco).take(8)
            } catch (_: Exception) {
                emptyList()
            }
            val best = results.firstOrNull()
            val grams = det.quantityGrams
                ?: best?.servingGrams?.takeIf { it > 0 }
                ?: 100.0
            VisionMealLine(
                id = "vision-$index-${det.name.hashCode()}",
                detectedName = det.name,
                displayName = best?.name ?: det.name,
                grams = grams,
                household = det.householdMeasure
                    ?: best?.serving
                    ?: "${grams.roundToInt()} g",
                confidence = det.confidence,
                food = best,
                alternatives = results.drop(1).take(5),
            )
        }
    }
}
