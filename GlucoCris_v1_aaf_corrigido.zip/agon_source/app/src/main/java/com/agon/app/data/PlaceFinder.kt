package com.agon.app.data

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Looper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

enum class PlaceKind(val label: String) {
    FARMACIA("Farmácia"),
    UBS("Posto / UBS"),
    HOSPITAL("Hospital / UPA"),
    CLINICA("Clínica"),
}

data class HealthPlace(
    val id: String,
    val name: String,
    val kind: PlaceKind,
    val lat: Double,
    val lon: Double,
    val distanceKm: Double,
    val address: String,
    val phone: String,
    val hours: String,
    val is24h: Boolean,
    val website: String,
    val brand: String,
)

/** Dados públicos OSM. Otimizado para velocidade: cache, timeouts curtos, race entre mirrors. */
object PlaceFinder {
    private val json = Json { ignoreUnknownKeys = true }
    private const val UA = "GlucoCris/1.4 (localizador insulina; Android)"

    // Mirrors Overpass mais responsivos (ordem por prioridade de tentativa paralela)
    private val OVERPASS = listOf(
        "https://overpass.kumi.systems/api/interpreter",
        "https://overpass-api.de/api/interpreter",
        "https://overpass.private.coffee/api/interpreter",
    )

    // Cache em memória: chave ~100m, TTL 8 min
    private data class CacheEntry(val at: Long, val places: List<HealthPlace>)
    private val cache = ConcurrentHashMap<String, CacheEntry>()
    private const val CACHE_TTL_MS = 8 * 60_000L

    private fun cacheKey(lat: Double, lon: Double, radiusKm: Int): String {
        // grade ~110m
        val glat = (lat * 1000).toInt()
        val glon = (lon * 1000).toInt()
        return "$glat|$glon|$radiusKm"
    }

    @SuppressLint("MissingPermission")
    suspend fun currentLocation(context: Context): Location? {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
            .filter { runCatching { lm.isProviderEnabled(it) }.getOrDefault(false) }

        // Aceita lastKnown até 15 min (muito mais rápido que esperar GPS fresco)
        val last = providers.mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
        if (last != null && System.currentTimeMillis() - last.time < 15 * 60_000) return last

        // NETWORK primeiro (rápido), GPS com timeout curto
        for (p in listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)) {
            if (p !in providers) continue
            val timeout = if (p == LocationManager.NETWORK_PROVIDER) 4_000L else 6_000L
            val fresh = withTimeoutOrNull(timeout) { single(lm, p) }
            if (fresh != null) return fresh
        }
        return last
    }

    fun locationEnabled(context: Context): Boolean {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return runCatching {
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) ||
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
        }.getOrDefault(false)
    }

    @SuppressLint("MissingPermission")
    private suspend fun single(lm: LocationManager, provider: String): Location? =
        suspendCancellableCoroutine { cont ->
            try {
                if (Build.VERSION.SDK_INT >= 30) {
                    lm.getCurrentLocation(
                        provider, null,
                        java.util.concurrent.Executors.newSingleThreadExecutor(),
                    ) { loc -> if (cont.isActive) cont.resume(loc) }
                } else {
                    val l = object : LocationListener {
                        override fun onLocationChanged(location: Location) {
                            if (cont.isActive) cont.resume(location)
                        }
                        @Deprecated("Deprecated in Java")
                        override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
                        override fun onProviderEnabled(provider: String) {}
                        override fun onProviderDisabled(provider: String) {
                            if (cont.isActive) cont.resume(null)
                        }
                    }
                    @Suppress("DEPRECATION")
                    lm.requestSingleUpdate(provider, l, Looper.getMainLooper())
                    cont.invokeOnCancellation { lm.removeUpdates(l) }
                }
            } catch (_: Exception) {
                if (cont.isActive) cont.resume(null)
            }
        }

    suspend fun geocode(query: String): Pair<Double, Double>? = withContext(Dispatchers.IO) {
        try {
            val q = URLEncoder.encode("$query, Brasil", "UTF-8")
            val body = get("https://nominatim.openstreetmap.org/search?format=json&limit=1&q=$q", 6_000, 8_000)
            val arr = json.parseToJsonElement(body).jsonArray
            val o = arr.firstOrNull()?.jsonObject ?: return@withContext null
            val lat = o["lat"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull() ?: return@withContext null
            val lon = o["lon"]?.jsonPrimitive?.contentOrNull?.toDoubleOrNull() ?: return@withContext null
            lat to lon
        } catch (_: Exception) {
            null
        }
    }

    suspend fun reverse(lat: Double, lon: Double): String? = withContext(Dispatchers.IO) {
        try {
            val body = get(
                "https://nominatim.openstreetmap.org/reverse?format=json&zoom=14&lat=$lat&lon=$lon",
                5_000, 6_000,
            )
            val a = json.parseToJsonElement(body).jsonObject["address"]?.jsonObject ?: return@withContext null
            fun s(k: String) = a[k]?.jsonPrimitive?.contentOrNull
            val area = s("suburb") ?: s("neighbourhood") ?: s("city_district")
            val city = s("city") ?: s("town") ?: s("municipality") ?: s("village")
            listOfNotNull(area, city).joinToString(", ").ifBlank { null }
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Busca rápida:
     * 1) cache
     * 2) raio pedido, consulta paralela a 3 mirrors — usa o 1º que responder
     * 3) query enxuta (pharmacy prioritário + hospital/UBS)
     */
    suspend fun search(lat: Double, lon: Double, radiusKm: Int): List<HealthPlace> = withContext(Dispatchers.IO) {
        val key = cacheKey(lat, lon, radiusKm)
        cache[key]?.let { entry ->
            if (System.currentTimeMillis() - entry.at < CACHE_TTL_MS) {
                // Recalcula distância com lat/lon atual (usuário pode ter se movido um pouco)
                return@withContext entry.places.map { p ->
                    p.copy(distanceKm = distanceKm(lat, lon, p.lat, p.lon))
                }.sortedBy { it.distanceKm }
            }
        }

        val r = (radiusKm * 1000).coerceIn(500, 50_000)
        // Query enxuta: farmácias primeiro (insulina), depois saúde essencial
        val a = "(around:$r,$lat,$lon)"
        val q = "[out:json][timeout:20];(" +
            "node[amenity=pharmacy]$a;way[amenity=pharmacy]$a;" +
            "node[healthcare=pharmacy]$a;" +
            "node[amenity=hospital]$a;node[amenity=clinic]$a;" +
            "node[healthcare=hospital]$a;node[healthcare=centre]$a;" +
            "node[amenity=doctors]$a;" +
            ");out center tags 350;"
        val body = "data=" + URLEncoder.encode(q, "UTF-8")

        val result = raceOverpass(body, lat, lon)
            ?: throw IllegalStateException("Falha na busca — tente de novo")

        cache[key] = CacheEntry(System.currentTimeMillis(), result)
        // Limpa cache antigo
        if (cache.size > 40) {
            val now = System.currentTimeMillis()
            cache.entries.removeIf { now - it.value.at > CACHE_TTL_MS }
        }
        result
    }

    private suspend fun raceOverpass(body: String, lat: Double, lon: Double): List<HealthPlace>? =
        coroutineScope {
            val jobs = OVERPASS.map { ep ->
                async(Dispatchers.IO) {
                    runCatching {
                        withTimeoutOrNull(18_000) {
                            parse(post(ep, body), lat, lon)
                        }
                    }.getOrNull()?.takeIf { it.isNotEmpty() }
                }
            }
            // Primeiro resultado não-nulo ganha
            var winner: List<HealthPlace>? = null
            for (j in jobs) {
                val r = runCatching { j.await() }.getOrNull()
                if (r != null) {
                    winner = r
                    jobs.forEach { it.cancel() }
                    break
                }
            }
            winner
        }

    private fun parse(body: String, lat: Double, lon: Double): List<HealthPlace> {
        val els = json.parseToJsonElement(body).jsonObject["elements"]?.jsonArray ?: return emptyList()
        val seen = HashSet<String>(els.size * 2)
        return els.mapNotNull { el ->
            val o = el.jsonObject
            val tags = o["tags"]?.jsonObject ?: return@mapNotNull null
            fun t(k: String) = tags[k]?.jsonPrimitive?.contentOrNull.orEmpty()
            val (plat, plon) = coords(o) ?: return@mapNotNull null
            val name = t("name").ifBlank { t("brand") }.ifBlank { null } ?: return@mapNotNull null
            val amenity = t("amenity")
            val hc = t("healthcare")
            val n = name.lowercase()
            val kind = when {
                amenity == "pharmacy" || hc == "pharmacy" -> PlaceKind.FARMACIA
                amenity == "hospital" || hc == "hospital" ||
                    n.contains("upa") || n.contains("pronto") || n.contains("hospital") -> PlaceKind.HOSPITAL
                hc == "centre" || n.contains("ubs") || n.contains("usf") || n.contains("esf") ||
                    n.contains("unidade basica") || n.contains("unidade básica") ||
                    n.contains("posto de saude") || n.contains("posto de saúde") ||
                    n.contains("saude da familia") || n.contains("saúde da família") ||
                    n.contains("caps") -> PlaceKind.UBS
                else -> PlaceKind.CLINICA
            }
            val key = "${n}_${"%.4f".format(plat)}_${"%.4f".format(plon)}"
            if (!seen.add(key)) return@mapNotNull null
            val street = t("addr:street")
            val number = t("addr:housenumber")
            val district = t("addr:suburb").ifBlank { t("addr:district") }
            val city = t("addr:city")
            val address = listOf(
                listOf(street, number).filter { it.isNotBlank() }.joinToString(", "),
                district, city,
            ).filter { it.isNotBlank() }.joinToString(" · ")
            val hours = t("opening_hours")
            HealthPlace(
                id = "${o["type"]?.jsonPrimitive?.contentOrNull}_${o["id"]?.jsonPrimitive?.contentOrNull}",
                name = name,
                kind = kind,
                lat = plat,
                lon = plon,
                distanceKm = distanceKm(lat, lon, plat, plon),
                address = address,
                phone = t("phone").ifBlank { t("contact:phone") }.ifBlank { t("contact:mobile") }
                    .split(";").first().trim(),
                hours = hours,
                is24h = hours.trim() == "24/7",
                website = t("website").ifBlank { t("contact:website") },
                brand = t("brand"),
            )
        }.sortedBy { it.distanceKm }
    }

    private fun coords(o: JsonObject): Pair<Double, Double>? {
        val lat = o["lat"]?.jsonPrimitive?.doubleOrNull
            ?: o["center"]?.jsonObject?.get("lat")?.jsonPrimitive?.doubleOrNull
        val lon = o["lon"]?.jsonPrimitive?.doubleOrNull
            ?: o["center"]?.jsonObject?.get("lon")?.jsonPrimitive?.doubleOrNull
        return if (lat != null && lon != null) lat to lon else null
    }

    fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371.0
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) * sin(dLon / 2) * sin(dLon / 2)
        return r * 2 * atan2(sqrt(a), sqrt(1 - a))
    }

    private fun get(url: String, connectMs: Int = 8_000, readMs: Int = 12_000): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = connectMs
            c.readTimeout = readMs
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Accept-Language", "pt-BR")
            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun post(url: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"
            c.connectTimeout = 3_500
            c.readTimeout = 10_000
            c.doOutput = true
            c.setRequestProperty("User-Agent", UA)
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded; charset=utf-8")
            c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            if (c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
