package com.agon.app.ui.screens

import android.Manifest
import android.graphics.BitmapFactory
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.CrisChatLine
import com.agon.app.data.CrisMemory
import com.agon.app.data.CrisPrefs
import com.agon.app.data.CrisSpeaker
import com.agon.app.data.CrisGemini
import com.agon.app.data.GlucoViewModel
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.launch

private val CRIS_GREEN = Color(0xFF34D399)
private val CRIS_GREEN_DEEP = Color(0xFF065F46)

private val QUICK_TIPS = listOf(
    "Como estou essa semana?" to "resumo semanal",
    "Consulta em 1 min" to "consulta em 1 minuto",
    "Meus lembretes" to "meus lembretes",
    "Achar insulina" to "abrir localizador",
    "Criar lembrete" to "criar lembrete",
)

@Composable
fun CrisIaScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val messages = remember { mutableStateListOf<CrisMsg>() }
    var input by remember { mutableStateOf("") }
    var thinking by remember { mutableStateOf(false) }
    var memory by remember { mutableStateOf(CrisMemory()) }
    var pending by remember { mutableStateOf<PendingAction?>(null) }
    var listening by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf<String?>(null) }
    var micBlocked by remember { mutableStateOf(false) }
    var ready by remember { mutableStateOf(false) }
    var pendingAttachName by remember { mutableStateOf<String?>(null) }
    var pendingInline by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var attachNotice by remember { mutableStateOf<String?>(null) }
    val listState = rememberLazyListState()

    val speaker = remember { CrisSpeaker(context) }
    val listener = remember {
        CrisListener(
            context,
            onLevel = {},
            onPartial = { input = it },
            onResult = { input = it; listening = false },
            onFail = { notice = it; listening = false },
        )
    }
    DisposableEffect(Unit) {
        onDispose {
            listener.stop()
            speaker.release()
        }
    }

    LaunchedEffect(Unit) {
        memory = CrisPrefs.loadMemory(context)
        val saved = CrisPrefs.loadChat(context)
        if (saved.isNotEmpty()) {
            messages.addAll(saved.map { CrisMsg(it.fromUser, cleanCrisText(it.text)) })
        } else {
            val first = vm.data.value.settings.displayName.split(" ").firstOrNull().orEmpty()
            messages.add(
                CrisMsg(false, "Oi${if (first.isNotBlank()) ", $first" else ""}! Eu sou a Cris ❤️ Pode falar comigo do jeito que quiser, sobre o seu dia, sua glicose ou qualquer coisa. Se preferir conversar por voz, toca no botão verde lá em cima."),
            )
        }
        ready = true
    }

    fun persist() {
        scope.launch { CrisPrefs.saveChat(context, messages.map { CrisChatLine(it.fromUser, it.text) }) }
    }

    fun send(raw: String) {
        val t = raw.trim()
        val hasAttach = pendingInline.isNotEmpty()
        if ((t.isEmpty() && !hasAttach) || thinking) return
        val history = messages.toList()
        val userShow = if (hasAttach) {
            val n = pendingAttachName ?: "anexo"
            if (t.isBlank()) "[Anexo: $n]" else "[Anexo: $n]\n$t"
        } else t
        messages.add(CrisMsg(true, userShow))
        persist()
        input = ""
        notice = null
        attachNotice = null
        thinking = true
        speaker.stop()
        val inline = pendingInline.toList()
        pendingInline = emptyList()
        pendingAttachName = null
        scope.launch {
            if (inline.isNotEmpty() && CrisGemini.isConfigured()) {
                val ctx = try {
                    buildCrisContext(vm.data.value)
                } catch (_: Exception) {
                    ""
                }
                val multi = CrisGemini.analyzeMultimodal(
                    context,
                    t.ifBlank { "Analise o anexo e explique o que é relevante." },
                    ctx,
                    com.agon.app.data.firstName(vm.data.value.settings.displayName),
                    inline,
                )
                thinking = false
                if (!multi.isNullOrBlank()) {
                    messages.add(CrisMsg(false, cleanCrisText(multi)))
                    persist()
                    if (memory.speakReplies) speaker.speak(multi)
                    return@launch
                }
                messages.add(CrisMsg(false, "Não consegui analisar o anexo agora (rede/cota/modelo). Pode descrever por texto que eu ajudo no modo local."))
                persist()
                return@launch
            }
            val r = crisRespond(context, vm, t.ifBlank { userShow }, memory, pending, history, voice = false)
            memory = r.memory
            pending = r.pending
            thinking = false
            messages.add(CrisMsg(false, r.reply))
            persist()
            if (r.navigateTo != null) {
                nav.navigate(r.navigateTo)
            } else if (memory.speakReplies) {
                speaker.speak(r.reply)
            }
        }
    }

    
    val attachPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        scope.launch {
            try {
                val cr = context.contentResolver
                val mime = cr.getType(uri) ?: "application/octet-stream"
                var name = "anexo"
                cr.query(uri, null, null, null, null)?.use { c ->
                    val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (i >= 0 && c.moveToFirst()) name = c.getString(i) ?: name
                }
                val bytes = cr.openInputStream(uri)?.use { it.readBytes() } ?: run {
                    attachNotice = "Não consegui ler o arquivo."
                    return@launch
                }
                if (bytes.size > 4_000_000) {
                    attachNotice = "Arquivo grande demais (máx. ~4 MB)."
                    return@launch
                }
                when {
                    mime.startsWith("image/") -> {
                        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        if (bmp == null) {
                            attachNotice = "Imagem inválida."
                            return@launch
                        }
                        val b64 = CrisGemini.bitmapToJpegBase64(bmp)
                        pendingInline = listOf("image/jpeg" to b64)
                        pendingAttachName = name
                        attachNotice = "Foto anexada: $name — escreva a pergunta e envie."
                    }
                    mime == "application/pdf" || mime.startsWith("text/") || name.endsWith(".txt") || name.endsWith(".csv") -> {
                        val b64 = CrisGemini.fileToBase64(bytes) ?: run {
                            attachNotice = "Arquivo não pôde ser codificado."
                            return@launch
                        }
                        val m = if (mime == "application/pdf") "application/pdf" else "text/plain"
                        pendingInline = listOf(m to b64)
                        pendingAttachName = name
                        attachNotice = "Arquivo anexado: $name — pergunte o que quiser sobre ele."
                    }
                    mime.startsWith("audio/") -> {
                        val b64 = CrisGemini.fileToBase64(bytes) ?: run {
                            attachNotice = "Áudio grande demais ou inválido."
                            return@launch
                        }
                        pendingInline = listOf(mime to b64)
                        pendingAttachName = name
                        attachNotice = "Áudio anexado: $name — peça um resumo ou transcrição."
                    }
                    else -> {
                        attachNotice = "Formato não suportado ainda ($mime). Use foto, PDF, TXT, CSV ou áudio."
                    }
                }
            } catch (e: Exception) {
                attachNotice = "Falha ao anexar."
            }
        }
    }

    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            micBlocked = false
            listening = true
            listener.start()
        } else {
            val act = context.findActivity()
            val canAsk = act != null && ActivityCompat.shouldShowRequestPermissionRationale(act, Manifest.permission.RECORD_AUDIO)
            micBlocked = !canAsk
            notice = if (canAsk) "Sem o microfone eu não consigo te ouvir, mas você pode digitar." else "O microfone está bloqueado. Libere nas configurações para falar comigo."
        }
    }

    fun toggleDictation() {
        if (listening) {
            listener.stop(); listening = false; return
        }
        notice = null
        speaker.stop()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            listening = true
            listener.start()
        } else {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    LaunchedEffect(messages.size, thinking) {
        val count = messages.size + if (thinking) 1 else 0
        if (count > 0) listState.animateScrollToItem(count - 1)
    }

    if (!ready) {
        Box(Modifier.fillMaxSize().background(g.bg), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = g.violet)
        }
        return
    }

    Column(Modifier.fillMaxSize().background(g.bg).imePadding()) {
        // Cabeçalho fixo
        Row(
            Modifier.fillMaxWidth().background(g.card).padding(horizontal = 8.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = g.ink)
            }
            Box(
                Modifier.size(40.dp).clip(CircleShape)
                    .background(Brush.radialGradient(listOf(CRIS_GREEN, CRIS_GREEN_DEEP))),
                contentAlignment = Alignment.Center,
            ) {
                Text("C", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            }
            Column(Modifier.weight(1f).padding(start = 10.dp)) {
                Text("Cris", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text(
                    when {
                        listening -> "ouvindo você…"
                        thinking -> "digitando…"
                        else -> "online"
                    },
                    color = if (listening || thinking) g.green else g.muted,
                    fontSize = 12.sp,
                )
            }
            IconButton(onClick = {
                memory = memory.copy(speakReplies = !memory.speakReplies)
                scope.launch { CrisPrefs.saveMemory(context, memory) }
                if (!memory.speakReplies) speaker.stop()
            }) {
                Icon(if (memory.speakReplies) Icons.Filled.VolumeUp else Icons.Filled.VolumeOff, "Voz das respostas", tint = g.violet)
            }
            IconButton(onClick = {
                speaker.stop()
                messages.clear()
                messages.add(CrisMsg(false, "Conversa nova! Me conta, o que você quer falar agora?"))
                pending = null
                scope.launch { CrisPrefs.clearChat(context) }
            }) {
                Icon(Icons.Filled.DeleteOutline, "Limpar conversa", tint = g.muted)
            }
            Row(
                Modifier.heightIn(min = 40.dp).clip(RoundedCornerShape(20.dp)).background(CRIS_GREEN_DEEP)
                    .clickable { speaker.stop(); listener.stop(); listening = false; nav.navigate(Routes.CRIS_VOICE) }
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.GraphicEq, null, tint = CRIS_GREEN, modifier = Modifier.size(18.dp))
                Text("Voz", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 4.dp))
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            itemsIndexed(messages) { _, msg ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start) {
                    Box(
                        Modifier.widthIn(max = 300.dp)
                            .clip(
                                RoundedCornerShape(
                                    topStart = 18.dp, topEnd = 18.dp,
                                    bottomStart = if (msg.fromUser) 18.dp else 4.dp,
                                    bottomEnd = if (msg.fromUser) 4.dp else 18.dp,
                                ),
                            )
                            .background(if (msg.fromUser) g.violet else g.card)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                    ) {
                        Text(msg.text, color = if (msg.fromUser) Color.White else g.ink, fontSize = 15.sp, lineHeight = 21.sp)
                    }
                }
            }
            if (thinking) {
                item { TypingBubble() }
            }
        }

        LazyRow(
            Modifier.fillMaxWidth().height(48.dp),
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            items(QUICK_TIPS) { (label, cmd) ->
                Text(
                    label,
                    color = g.violet,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    maxLines = 1,
                    softWrap = false,
                    modifier = Modifier.clip(RoundedCornerShape(18.dp)).background(g.lilacSoft)
                        .clickable { send(cmd) }
                        .padding(horizontal = 14.dp, vertical = 9.dp),
                )
            }
        }

        notice?.let {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(it, color = g.orange, fontSize = 12.sp, modifier = Modifier.weight(1f))
                if (micBlocked) {
                    Text(
                        "Abrir configurações",
                        color = g.violet,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        modifier = Modifier.clickable {
                            context.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                            )
                        }.padding(8.dp),
                    )
                }
            }
        }

        attachNotice?.let {
            Text(it, color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
        }
        pendingAttachName?.let {
            Text("Anexo: $it — envie com a pergunta", color = g.violet, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp))
        }
        Row(
            Modifier.fillMaxWidth().padding(start = 4.dp, end = 12.dp, top = 4.dp, bottom = 10.dp),
            verticalAlignment = Alignment.Bottom,
        ) {
            IconButton(onClick = { attachPicker.launch("*/*") }) {
                Icon(Icons.Filled.AttachFile, "Anexar", tint = g.violet)
            }
            Box(
                Modifier.weight(1f).heightIn(min = 48.dp).clip(RoundedCornerShape(24.dp)).background(g.card)
                    .border(1.dp, if (listening) CRIS_GREEN else g.line, RoundedCornerShape(24.dp))
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                contentAlignment = Alignment.CenterStart,
            ) {
                if (input.isEmpty()) {
                    Text(if (listening) "Pode falar, estou ouvindo…" else "Escreva para a Cris…", color = g.muted, fontSize = 15.sp)
                }
                BasicTextField(
                    value = input,
                    onValueChange = { input = it },
                    maxLines = 5,
                    textStyle = TextStyle(color = g.ink, fontSize = 15.sp),
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { send(input) }),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            Spacer(Modifier.width(8.dp))
            val showSend = (input.isNotBlank() || pendingAttachName != null) && !listening
            Box(
                Modifier.size(48.dp).clip(CircleShape)
                    .background(if (showSend) g.violet else if (listening) CRIS_GREEN else g.lilacSoft)
                    .clickable { if (showSend) send(input) else toggleDictation() },
                contentAlignment = Alignment.Center,
            ) {
                Icon(
                    if (showSend) Icons.AutoMirrored.Filled.Send else Icons.Filled.Mic,
                    if (showSend) "Enviar" else "Falar",
                    tint = if (showSend || listening) Color.White else g.violet,
                )
            }
        }
    }
}

@Composable
private fun TypingBubble() {
    val g = glucoColors()
    val t = rememberInfiniteTransition(label = "typing")
    val phase by t.animateFloat(0f, 3f, infiniteRepeatable(tween(900), RepeatMode.Restart), label = "dots")
    Row(
        Modifier.clip(RoundedCornerShape(18.dp)).background(g.card).padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        repeat(3) { i ->
            Box(
                Modifier.size(8.dp).alpha(if (phase.toInt() == i) 1f else 0.35f).clip(CircleShape).background(g.violet),
            )
        }
    }
}
