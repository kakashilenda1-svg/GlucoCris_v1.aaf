package com.agon.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.net.Uri
import android.util.Log
import java.io.File
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.FoodVisionAi
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Meal
import com.agon.app.data.VisionMealLine
import com.agon.app.data.uid
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.launch
import java.io.ByteArrayOutputStream
import kotlin.math.roundToInt

private const val PREFS_VISION = "gluco_vision_prefs"
private const val KEY_CONSENT = "gemini_photo_consent"

@Composable
fun FoodSmartScannerScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val scope = rememberCoroutineScope()

    var hasCam by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) ==
                PackageManager.PERMISSION_GRANTED,
        )
    }
    var consent by remember {
        mutableStateOf(
            context.getSharedPreferences(PREFS_VISION, 0).getBoolean(KEY_CONSENT, false),
        )
    }
    var showConsent by remember { mutableStateOf(!consent) }
    var bitmap by remember { mutableStateOf<Bitmap?>(null) }
    var phase by remember { mutableStateOf(0) } // 0 capture 1 preview 2 loading 3 result
    var progressMsg by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var lines by remember { mutableStateOf<List<VisionMealLine>>(emptyList()) }
    var providerUsed by remember { mutableStateOf("") }
    var mealType by remember { mutableStateOf("almoco") }
    var mealExpanded by remember { mutableStateOf(false) }
    var imageCapture by remember { mutableStateOf<ImageCapture?>(null) }

    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        hasCam = it
    }
    val gallery = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        try {
            context.contentResolver.openInputStream(uri)?.use { ins ->
                bitmap = BitmapFactory.decodeStream(ins)
                phase = 1
                error = null
            }
        } catch (e: Exception) {
            error = "Não foi possível abrir a imagem."
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCam) perm.launch(Manifest.permission.CAMERA)
    }

    fun startAnalysis(bmp: Bitmap) {
        // Gemini (se houver chave) → fallback ML Kit; nutrientes sempre via catálogo OFF/local
        if (FoodVisionAi.hasGeminiKey() && !consent) {
            showConsent = true
            return
        }
        phase = 2
        error = null
        progressMsg = "Analisando sua refeição…"
        scope.launch {
            try {
                progressMsg = if (FoodVisionAi.hasGeminiKey())
                    "Identificando alimentos (Gemini)…"
                else
                    "Identificando alimentos (ML Kit) e consultando Open Food Facts…"
                val analysis = FoodVisionAi.analyzePlate(bmp)
                providerUsed = analysis.provider
                if (analysis.items.isEmpty()) {
                    error = analysis.rawNotes
                        ?: "Nenhum alimento identificado. Tente outra foto com boa luz."
                    phase = 1
                    return@launch
                }
                progressMsg = "Buscando nutrientes no catálogo (Open Food Facts / local)…"
                val matched = FoodVisionAi.matchToCatalog(context, analysis)
                lines = matched
                progressMsg = "Preparando o resultado…"
                phase = 3
            } catch (e: Exception) {
                Log.w("SmartScan", "analyze", e)
                error = e.message ?: "Falha na análise."
                phase = 1
            }
        }
    }

    fun captureStill() {
        val cap = imageCapture ?: run {
            error = "Câmera ainda não está pronta. Aguarde um instante e tente de novo."
            return
        }
        progressMsg = "Capturando…"
        error = null
        // Salva em arquivo JPEG (mais confiável que converter ImageProxy YUV)
        val photoFile = File(context.cacheDir, "smart_scan_${System.currentTimeMillis()}.jpg")
        val output = ImageCapture.OutputFileOptions.Builder(photoFile).build()
        cap.takePicture(
            output,
            ContextCompat.getMainExecutor(context),
            object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(outputFileResults: ImageCapture.OutputFileResults) {
                    try {
                        var bmp = BitmapFactory.decodeFile(photoFile.absolutePath)
                        if (bmp == null) {
                            error = "Foto capturada, mas não foi possível ler a imagem."
                            progressMsg = ""
                            return
                        }
                        // Limita tamanho para análise
                        val maxSide = 1600
                        val max = maxOf(bmp.width, bmp.height)
                        if (max > maxSide) {
                            val scale = maxSide.toFloat() / max
                            bmp = Bitmap.createScaledBitmap(
                                bmp,
                                (bmp.width * scale).toInt().coerceAtLeast(1),
                                (bmp.height * scale).toInt().coerceAtLeast(1),
                                true,
                            )
                        }
                        bitmap = bmp
                        phase = 1
                        error = null
                        progressMsg = ""
                    } catch (e: Exception) {
                        error = "Erro ao processar a foto."
                        progressMsg = ""
                        Log.w("SmartScan", "decode", e)
                    }
                }

                override fun onError(exception: ImageCaptureException) {
                    error = "Falha na câmera: ${exception.message ?: "tente de novo"}"
                    progressMsg = ""
                    Log.w("SmartScan", "capture", exception)
                }
            },
        )
    }

    val totalCarbs = lines.sumOf { it.carbs() }
    val totalKcal = lines.sumOf { it.kcal() }
    val totalProt = lines.sumOf { it.protein() }
    val totalFat = lines.sumOf { it.fat() }

    if (showConsent) {
        AlertDialog(
            onDismissRequest = { showConsent = false },
            title = { Text("Análise por IA (internet)") },
            text = {
                Text(
                    "A foto será enviada pela internet ao serviço Gemini (Google) para identificar alimentos. " +
                        "Não envie dados pessoais na imagem. Estimativas de peso não são precisas. " +
                        "Você deve conferir tudo antes de salvar. Não use isso para dose de insulina.",
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    consent = true
                    context.getSharedPreferences(PREFS_VISION, 0).edit().putBoolean(KEY_CONSENT, true).apply()
                    showConsent = false
                }) { Text("Concordo e continuar") }
            },
            dismissButton = {
                TextButton(onClick = {
                    showConsent = false
                    nav.popBackStack()
                }) { Text("Cancelar") }
            },
        )
    }

    Column(Modifier.fillMaxSize().background(g.bg)) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.Filled.Close, null, tint = g.ink)
            }
            Column(Modifier.weight(1f)) {
                Text("Reconhecimento por imagem", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                Text(
                    if (FoodVisionAi.hasGeminiKey()) FoodVisionAi.providerLabel() else "Configure gemini.api.key",
                    color = g.muted, fontSize = 11.sp,
                )
            }
        }

        when (phase) {
            0, 1 -> {
                if (phase == 0 && hasCam) {
                    Box(
                        Modifier.fillMaxWidth().height(260.dp).padding(horizontal = 16.dp)
                            .clip(RoundedCornerShape(16.dp)).background(Color.Black),
                    ) {
                        AndroidView(
                            factory = { ctx ->
                                PreviewView(ctx).apply {
                                    scaleType = PreviewView.ScaleType.FILL_CENTER
                                }
                            },
                            modifier = Modifier.fillMaxSize(),
                            update = { previewView ->
                                val future = ProcessCameraProvider.getInstance(context)
                                future.addListener({
                                    try {
                                        val provider = future.get()
                                        val preview = Preview.Builder().build().also {
                                            it.surfaceProvider = previewView.surfaceProvider
                                        }
                                        val capture = ImageCapture.Builder()
                                            .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                                            .build()
                                        imageCapture = capture
                                        provider.unbindAll()
                                        provider.bindToLifecycle(
                                            lifecycleOwner,
                                            CameraSelector.DEFAULT_BACK_CAMERA,
                                            preview,
                                            capture,
                                        )
                                    } catch (_: Exception) {
                                        error = "Câmera indisponível."
                                    }
                                }, ContextCompat.getMainExecutor(context))
                            },
                        )
                        Text(
                            "Boa luz · prato inteiro · de cima",
                            color = Color.White, fontSize = 12.sp,
                            modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp)
                                .clip(RoundedCornerShape(8.dp)).background(Color.Black.copy(0.45f)).padding(6.dp),
                        )
                    }
                } else if (bitmap != null) {
                    Image(
                        bitmap = bitmap!!.asImageBitmap(),
                        contentDescription = null,
                        modifier = Modifier.fillMaxWidth().height(240.dp).padding(horizontal = 16.dp)
                            .clip(RoundedCornerShape(16.dp)),
                        contentScale = ContentScale.Crop,
                    )
                }

                Text(
                    "Estimativas de porção são aproximadas. Confira sempre os itens e os carboidratos.",
                    color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp, 8.dp),
                )
                error?.let { Text(it, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp)) }

                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    OutlinedButton(
                        onClick = { gallery.launch("image/*") },
                        modifier = Modifier.weight(1f),
                    ) {
                        Icon(Icons.Filled.PhotoLibrary, null, tint = g.violet, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Galeria", color = g.violet)
                    }
                    if (phase == 0) {
                        Button(
                            onClick = { captureStill() },
                            colors = ButtonDefaults.buttonColors(containerColor = g.violet),
                            shape = CircleShape,
                            modifier = Modifier.size(64.dp),
                            contentPadding = PaddingValues(0.dp),
                        ) {
                            Icon(Icons.Filled.PhotoCamera, null, tint = Color.White)
                        }
                    } else {
                        Button(
                            onClick = { bitmap?.let { startAnalysis(it) } },
                            colors = ButtonDefaults.buttonColors(containerColor = g.green),
                            modifier = Modifier.weight(1.2f),
                        ) { Text("Analisar refeição") }
                    }
                }
                if (phase == 1) {
                    TextButton(onClick = { bitmap = null; phase = 0; error = null }) {
                        Text("Tirar outra foto", color = g.violet)
                    }
                    TextButton(onClick = { nav.navigate(Routes.FOOD_SEARCH) }) {
                        Text("Busca manual no catálogo", color = g.muted)
                    }
                }
            }

            2 -> {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = g.violet)
                        Spacer(Modifier.height(16.dp))
                        Text(progressMsg, color = g.ink, fontWeight = FontWeight.Medium)
                        Text("Aguarde…", color = g.muted, fontSize = 13.sp)
                    }
                }
            }

            3 -> {
                LazyColumn(Modifier.padding(horizontal = 12.dp)) {
                    item {
                        bitmap?.let {
                            Image(
                                bitmap = it.asImageBitmap(),
                                contentDescription = null,
                                modifier = Modifier.fillMaxWidth().height(140.dp)
                                    .clip(RoundedCornerShape(12.dp)),
                                contentScale = ContentScale.Crop,
                            )
                        }
                        Text(
                            "IA: $providerUsed · toque nos itens para ajustar · valores do catálogo Gluco Cris",
                            color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 8.dp),
                        )
                        GCard {
                            Text("Totais da refeição", color = g.ink, fontWeight = FontWeight.Bold)
                            Text("Carboidratos: ${"%.1f".format(totalCarbs)} g", color = g.violetDeep, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                            Text("Calorias: ${totalKcal.roundToInt()} kcal · Prot ${"%.1f".format(totalProt)} g · Gord ${"%.1f".format(totalFat)} g", color = g.ink, fontSize = 13.sp)
                            Text(
                                "Estimativas. Confira antes de usar para contagem de carb. Não define dose de insulina.",
                                color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp),
                            )
                        }
                        Box {
                            Text(
                                "Refeição: ${MEAL_OPTIONS.find { it.first == mealType }?.second}",
                                color = g.ink, fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { mealExpanded = true }.padding(8.dp),
                            )
                            DropdownMenu(mealExpanded, { mealExpanded = false }) {
                                MEAL_OPTIONS.forEach { (k, l) ->
                                    DropdownMenuItem(text = { Text(l) }, onClick = { mealType = k; mealExpanded = false })
                                }
                            }
                        }
                        SectionTitle("Alimentos identificados (${lines.size})")
                    }
                    items(lines, key = { it.id }) { line ->
                        VisionLineCard(line, g, onChange = { updated ->
                            lines = lines.map { if (it.id == updated.id) updated else it }
                        }, onRemove = {
                            lines = lines.filter { it.id != line.id }
                        })
                    }
                    item {
                        PrimaryButton("Salvar no diário alimentar", g.green, {
                            if (lines.isEmpty()) return@PrimaryButton
                            val desc = lines.joinToString(" + ") {
                                "${it.displayName} (${it.grams.roundToInt()} g)"
                            }
                            vm.saveMeal(
                                Meal(
                                    id = uid(),
                                    type = mealType,
                                    description = "Foto: $desc",
                                    carbs = totalCarbs,
                                    at = System.currentTimeMillis(),
                                    notes = "kcal=${totalKcal.roundToInt()};fonte=vision-$providerUsed;itens=${lines.size}",
                                ),
                            )
                            nav.popBackStack(Routes.FOOD, false)
                        }, Modifier.padding(vertical = 12.dp))
                        TextButton(onClick = { phase = 1 }) {
                            Text("Nova análise", color = g.violet)
                        }
                        Spacer(Modifier.height(24.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun VisionLineCard(
    line: VisionMealLine,
    g: com.agon.app.ui.theme.GlucoColors,
    onChange: (VisionMealLine) -> Unit,
    onRemove: () -> Unit,
) {
    var gramsText by remember(line.id, line.grams) { mutableStateOf(line.grams.let { if (it == it.toLong().toDouble()) it.toLong().toString() else "%.0f".format(it) }) }
    GCard(Modifier.padding(bottom = 8.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Column(Modifier.weight(1f)) {
                Text(line.displayName, color = g.ink, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                if (line.displayName != line.detectedName) {
                    Text("Detectado: ${line.detectedName}", color = g.muted, fontSize = 11.sp)
                }
                line.confidence?.let {
                    Text("Confiança ~${(it * 100).roundToInt()}%", color = g.muted, fontSize = 11.sp)
                }
            }
            Text("Remover", color = g.red, fontSize = 12.sp, modifier = Modifier.clickable(onClick = onRemove))
        }
        if (line.food == null) {
            Text(
                "Não encontrado no catálogo — ajuste o nome ou busque manualmente. Nutrientes não inventados.",
                color = g.orange, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
            )
        } else {
            Text(
                "${line.food!!.source} · base ${line.food!!.serving}",
                color = g.muted, fontSize = 11.sp,
            )
        }
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
            Text("g", color = g.muted, modifier = Modifier.width(20.dp))
            OutlinedTextField(
                value = gramsText,
                onValueChange = { raw ->
                    gramsText = raw.filter { it.isDigit() || it == ',' || it == '.' }
                    gramsText.replace(",", ".").toDoubleOrNull()?.let { gVal ->
                        if (gVal > 0) onChange(line.copy(grams = gVal, household = "${gVal.roundToInt()} g"))
                    }
                },
                modifier = Modifier.width(100.dp),
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            )
            IconButton(onClick = {
                val n = (line.grams - 10).coerceAtLeast(5.0)
                onChange(line.copy(grams = n, household = "${n.roundToInt()} g"))
                gramsText = n.roundToInt().toString()
            }) { Text("−", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
            IconButton(onClick = {
                val n = line.grams + 10
                onChange(line.copy(grams = n, household = "${n.roundToInt()} g"))
                gramsText = n.roundToInt().toString()
            }) { Text("+", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 20.sp) }
        }
        if (line.food != null) {
            Text(
                "Carb ${"%.1f".format(line.carbs())} g · ${line.kcal().roundToInt()} kcal · " +
                    "Prot ${"%.1f".format(line.protein())} g · Gord ${"%.1f".format(line.fat())} g",
                color = g.violetDeep, fontWeight = FontWeight.Medium, fontSize = 13.sp,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
        if (line.alternatives.isNotEmpty()) {
            Text("Trocar por:", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            line.alternatives.take(3).forEach { alt ->
                Text(
                    "→ ${alt.name} (${alt.source})",
                    color = g.violet, fontSize = 12.sp,
                    modifier = Modifier.clickable {
                        onChange(
                            line.copy(
                                displayName = alt.name,
                                food = alt,
                                household = alt.serving,
                            ),
                        )
                    }.padding(vertical = 2.dp),
                )
            }
        }
    }
}

private fun imageProxyToBitmap(image: ImageProxy): Bitmap? {
    return try {
        val yBuffer = image.planes[0].buffer
        val uBuffer = image.planes[1].buffer
        val vBuffer = image.planes[2].buffer
        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()
        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)
        val yuv = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
        val out = ByteArrayOutputStream()
        yuv.compressToJpeg(Rect(0, 0, image.width, image.height), 88, out)
        val bytes = out.toByteArray()
        var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return null
        val rotation = image.imageInfo.rotationDegrees
        if (rotation != 0) {
            val m = Matrix().apply { postRotate(rotation.toFloat()) }
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        bmp
    } catch (_: Exception) {
        null
    }
}
