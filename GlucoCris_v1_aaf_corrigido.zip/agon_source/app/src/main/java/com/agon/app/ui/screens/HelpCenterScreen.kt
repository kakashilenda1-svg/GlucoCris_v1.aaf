package com.agon.app.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.ui.components.BackTitle
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.components.SectionTitle
import com.agon.app.ui.theme.glucoColors

data class HelpLesson(
    val title: String,
    val focus: String,
    val steps: List<String>,
    val route: String?,
    val demoSteps: List<String>,
)

private const val HELP_PREFS = "gluco_help_v1"
private const val KEY_ONBOARD_DONE = "onboard_done"

fun isHelpOnboardDone(ctx: Context): Boolean =
    ctx.getSharedPreferences(HELP_PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ONBOARD_DONE, false)

fun setHelpOnboardDone(ctx: Context) {
    ctx.getSharedPreferences(HELP_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ONBOARD_DONE, true).apply()
}

fun helpLessons(): List<HelpLesson> = listOf(
    HelpLesson(
        "Início",
        "Tela inicial · resumo e atalhos",
        listOf(
            "Veja a última glicose e o status (ok / baixa / alta).",
            "Use os botões de registrar glicose e insulina.",
            "O card azul embaixo é o Cris Hidrata (água).",
            "O ? no canto abre esta Central de aprendizado.",
        ),
        Routes.HOME,
        listOf("Imagine o card azul: toque em um copo de 250 ml (simulação).", "Meta sobe no visor (fake).", "Nada foi salvo no diário real."),
    ),
    HelpLesson(
        "Glicose",
        "Aba Glicose · medições",
        listOf(
            "Abra a aba Glicose na barra inferior.",
            "Toque para adicionar valor, unidade e contexto (jejum, pós-refeição…).",
            "Registros aparecem no Histórico e no Início.",
        ),
        Routes.GLUCOSE,
        listOf("Simulação: digite 120 mg/dL · contexto jejum.", "Toque Salvar (fake) — não grava no aparelho."),
    ),
    HelpLesson(
        "Insulina",
        "Aba Insulina · aplicações",
        listOf(
            "Registre tipo e dose conforme a orientação da sua equipe.",
            "Não substitui prescrição médica.",
        ),
        Routes.INSULIN,
        listOf("Simulação: dose 4 U (fake).", "Confirme mentalmente e saia sem gravar."),
    ),
    HelpLesson(
        "Lembretes",
        "Aba Lembretes",
        listOf("Crie alertas de medição ou medicação.", "Ative/desative conforme a rotina."),
        Routes.REMINDERS,
        listOf("Simulação: lembrete às 08:00 (fake)."),
    ),
    HelpLesson(
        "Histórico",
        "Aba Histórico",
        listOf("Linha do tempo de glicose, insulina e outros registros."),
        Routes.HISTORY,
        listOf("Simulação: role a lista (fake)."),
    ),
    HelpLesson(
        "Alimentação · Pesquisa",
        "Aba Alimentação · lupa",
        listOf(
            "Digite o alimento; sugestões aparecem enquanto escreve.",
            "Wi‑Fi: catálogo online (Open Food Facts / USDA).",
            "Dados móveis/offline: TACO, local e cache.",
            "Favoritos e usados recentemente no topo.",
            "Caixinha = montar prato; toque no nome = tabela nutricional.",
        ),
        Routes.FOOD_SEARCH,
        listOf("Simulação: digite “arroz”.", "Toque no resultado fake e veja kcal/carb (exemplo)."),
    ),
    HelpLesson(
        "Prato",
        "Montagem de refeição",
        listOf(
            "Marque itens na busca ou “Adicionar ao prato”.",
            "Ajuste gramas; totais e gráficos atualizam.",
            "Alerta se cruzar alergia do perfil.",
            "Salvar no diário ou enviar ao bolus.",
        ),
        Routes.FOOD_PLATE,
        listOf("Simulação: 100 g arroz + 50 g feijão (fake).", "Total de carb só na tela de treino."),
    ),
    HelpLesson(
        "Diário alimentar",
        "Refeições do dia",
        listOf("Veja e edite o que foi salvo.", "Use com a contagem de carb da sua equipe."),
        Routes.FOOD_DIARY,
        listOf("Simulação: abra um item do dia (fake)."),
    ),
    HelpLesson(
        "Bolus",
        "Calculadora de apoio",
        listOf(
            "Informe carb, glicose e fatores (razão, sensibilidade, meta, IOB).",
            "Resultado é conta de apoio — não prescrição.",
            "Histórico das últimas contas no aparelho.",
        ),
        Routes.FOOD_BOLUS,
        listOf("Simulação: 40 g carb · glicose 160 (fake).", "Veja a conta exemplo e descarte."),
    ),
    HelpLesson(
        "Código de barras",
        "Leitura de produtos",
        listOf("Aponte a câmera ou digite o código.", "Busca Open Food Facts; se faltar e houver Gemini, tenta a IA."),
        Routes.FOOD_BARCODE,
        listOf("Simulação: código 7891000100103 (fake)."),
    ),
    HelpLesson(
        "Scanner de prato",
        "Foto da refeição",
        listOf(
            "Tire a foto com boa luz.",
            "Gemini (se configurado) ou ML Kit + catálogo.",
            "Revise, troque ou remova itens antes de salvar.",
        ),
        Routes.FOOD_SMART_SCAN,
        listOf("Simulação: prato com arroz e frango (fake).", "Confirme a lista sem salvar."),
    ),
    HelpLesson(
        "Receitas",
        "Grade e preparo",
        listOf(
            "Abas Receitas / Planos / Marmitas.",
            "Grade com foto, tempo e macros.",
            "Porções ½–2 ou quantidade digitada (recalcula).",
            "Foto opcional da galeria.",
        ),
        Routes.FOOD_RECIPES,
        listOf("Simulação: abra “Cuscuz” (fake) e mude porção para 1½."),
    ),
    HelpLesson(
        "Planos alimentares",
        "Aba Planos",
        listOf("Filtros, nutricionista, importar dia ou só uma refeição.", "Lista de compras."),
        Routes.FOOD_RECIPES,
        listOf("Simulação: importar só café (fake — não grava)."),
    ),
    HelpLesson(
        "Marmitas Cris DM",
        "Aba Marmitas",
        listOf("Opções para o dia a dia com diabetes.", "WhatsApp Maria Cristina · pedir de novo a última."),
        Routes.FOOD_RECIPES,
        listOf("Simulação: ver card de marmita (fake)."),
    ),
    HelpLesson(
        "Cris Hidrata",
        "Contador de água (Início)",
        listOf(
            "Card azul embaixo no Início · puxe para cima.",
            "Toque nos copos; desfazer em 5 s.",
            "Incline o celular: água balança; ponta-cabeça: gotas depois derrame (não muda ml).",
            "Toque na gotinha: dança, sorriso e som de cócegas (desligável).",
            "Meta manual ou ~35 ml/kg; modo calor +400 ml no dia.",
            "Lembrete suave se a meta não fechou.",
        ),
        Routes.WATER,
        listOf("Simulação: toque 300 ml (fake).", "Imagine a gotinha dançando nas cócegas."),
    ),
    HelpLesson(
        "Relatórios",
        "Mais · Relatório",
        listOf("Texto, PDF ou CSV com glicose, insulina, refeições e água."),
        Routes.REPORT,
        listOf("Simulação: pré-visualizar 7 dias (fake)."),
    ),
    HelpLesson(
        "Perfil",
        "Mais · Perfil",
        listOf(
            "Dados, alergias, medicamentos, peso (meta de água).",
            "Compartilhar ficha (selecionar campos).",
            "Botão Sair ao lado do contato volta à tela de entrada.",
        ),
        Routes.PROFILE,
        listOf("Simulação: ver nome e telefone (fake).", "Sair de verdade só no botão real do Perfil."),
    ),
    HelpLesson(
        "IA Cris",
        "Assistente",
        listOf("Conversa por texto/voz.", "Não substitui médico."),
        Routes.CRIS_IA,
        listOf("Simulação: pergunta “o que é contagem de carb?” (fake)."),
    ),
    HelpLesson(
        "Localizador de insulina",
        "Farmácias próximas",
        listOf("Usa localização do aparelho.", "Abra mapa ou telefone com cuidado."),
        Routes.LOCATOR,
        listOf("Simulação: lista de farmácia exemplo (fake)."),
    ),
    HelpLesson(
        "Configurações",
        "Mais · Ajustes",
        listOf("Metas de glicemia, unidade, PIN de proteção."),
        Routes.SETTINGS,
        listOf("Simulação: ver meta 70–180 (fake)."),
    ),
)

@Composable
fun HelpCenterScreen(nav: NavHostController) {
    val g = glucoColors()
    val lessons = remember { helpLessons() }
    var openTitle by remember { mutableStateOf<String?>(null) }
    var demoTitle by remember { mutableStateOf<String?>(null) }
    var demoStep by remember { mutableIntStateOf(0) }

    val open = lessons.find { it.title == openTitle }
    val demo = lessons.find { it.title == demoTitle }

    ScrollScreen {
        BackTitle("Central de aprendizado", { nav.popBackStack() })
        Text(
            "Cada tema foca um ponto da tela. Use “Ir para a tela” ou “Teste guiado (simulação)” — a simulação não grava dados reais.",
            color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp),
        )

        if (demo != null) {
            GCard {
                Text("Teste guiado · ${demo.title}", color = g.violetDeep, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Foco: ${demo.focus}", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                Text(
                    "Passo ${demoStep + 1} de ${demo.demoSteps.size}",
                    color = g.ink, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 10.dp),
                )
                Text(demo.demoSteps[demoStep], color = g.ink, fontSize = 15.sp, lineHeight = 22.sp, modifier = Modifier.padding(top = 6.dp))
                Box(
                    Modifier
                        .fillMaxWidth()
                        .padding(top = 12.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(g.lilacSoft)
                        .padding(14.dp),
                ) {
                    Text(
                        "Área de foco (simulação)\n→ ${demo.focus}",
                        color = g.violetDeep,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                    )
                }
                Row(Modifier.padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (demoStep > 0) {
                        TextButton(onClick = { demoStep-- }) { Text("Anterior", color = g.muted) }
                    }
                    if (demoStep < demo.demoSteps.lastIndex) {
                        PrimaryButton("Próximo passo", g.violet, { demoStep++ }, Modifier.weight(1f))
                    } else {
                        PrimaryButton("Concluir teste", g.green, {
                            demoTitle = null
                            demoStep = 0
                        }, Modifier.weight(1f))
                    }
                }
                TextButton(onClick = { demoTitle = null; demoStep = 0 }) {
                    Text("Fechar simulação", color = g.muted)
                }
            }
            return@ScrollScreen
        }

        if (open != null) {
            GCard {
                Text(open.title, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text("Onde olhar: ${open.focus}", color = g.violetDeep, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                open.steps.forEachIndexed { i, s ->
                    Text("${i + 1}. $s", color = g.ink, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 6.dp))
                }
                if (open.route != null) {
                    PrimaryButton("Ir para a tela", g.violet, {
                        nav.navigate(open.route!!)
                    }, Modifier.padding(top = 12.dp))
                }
                PrimaryButton("Teste guiado (simulação)", g.green, {
                    demoTitle = open.title
                    demoStep = 0
                    openTitle = null
                }, Modifier.padding(top = 8.dp))
                TextButton(onClick = { openTitle = null }) {
                    Text("Voltar à lista", color = g.muted)
                }
            }
            return@ScrollScreen
        }

        lessons.forEach { lesson ->
            GCard(Modifier.padding(bottom = 8.dp).clickable { openTitle = lesson.title }) {
                Text(lesson.title, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text(lesson.focus, color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                Text("Toque para detalhes · teste · ir à tela", color = g.violet, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
        Text("Gluco Cris · uso de apoio · simulações não alteram seus dados", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp))
    }
}

/** Overlay de primeiro uso no Início — foca pontos da tela com mais detalhe. */
@Composable
fun FirstLaunchCoach(onFinish: () -> Unit) {
    val g = glucoColors()
    val steps = listOf(
        "Início" to "Aqui fica o resumo do dia, atalhos de glicose/insulina e o humor.",
        "Barra inferior" to "Início · Glicose · Insulina · Lembretes · Histórico · Alimentação · Mais — são as portas principais.",
        "Cris Hidrata" to "Card azul embaixo: toque nos copos para somar água. Puxe para cima para ver mais.",
        "Ajuda (?)" to "Sempre que algo mudar no app, a explicação entra na Central de aprendizado. Você pode repetir testes simulados.",
        "Perfil · Sair" to "Em Mais → Perfil, o botão Sair volta à tela de entrada sem apagar dados.",
    )
    var i by remember { mutableIntStateOf(0) }
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .background(Color(0xEE1E1B4B))
            .padding(16.dp),
    ) {
        Column {
            Text("Bem-vindo ao Gluco Cris", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            Text("Passo ${i + 1} de ${steps.size} · foco na tela", color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
            Text(steps[i].first, color = Color(0xFFA5B4FC), fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 12.dp))
            Text(steps[i].second, color = Color.White, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(top = 6.dp))
            Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (i > 0) {
                    TextButton(onClick = { i-- }) { Text("Voltar", color = Color.White.copy(alpha = 0.8f)) }
                }
                PrimaryButton(
                    if (i < steps.lastIndex) "Próximo" else "Começar a usar",
                    Color(0xFF818CF8),
                    {
                        if (i < steps.lastIndex) i++ else onFinish()
                    },
                    Modifier.weight(1f),
                )
            }
        }
    }
}
