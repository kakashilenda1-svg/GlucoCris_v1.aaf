package com.agon.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Summarize
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GLUCOSE_CONTEXT_LABEL
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.INTENSITY_LABEL
import com.agon.app.data.MEAL_LABEL
import com.agon.app.data.formatDateTime
import com.agon.app.data.fmtNum
import com.agon.app.ui.components.ChipRow
import com.agon.app.ui.components.EmptyState
import com.agon.app.ui.components.GCard
import com.agon.app.ui.components.ScrollScreen
import com.agon.app.ui.theme.glucoColors

private data class HistoryRow(val at: Long, val kind: String, val title: String, val subtitle: String, val route: String?)

@Composable
fun HistoryScreen(vm: GlucoViewModel, nav: NavHostController) {
    val data by vm.data.collectAsStateWithLifecycle()
    val g = glucoColors()
    var kind by remember { mutableStateOf("todos") }
    var period by remember { mutableStateOf("tudo") }
    val now = System.currentTimeMillis()
    val rows = buildList {
        data.glucose.forEach { add(HistoryRow(it.at, "glicose", "${fmtNum(it.value)} ${it.unit}", "${GLUCOSE_CONTEXT_LABEL[it.context] ?: it.context}${if (it.notes.isBlank()) "" else " · ${it.notes}"}", Routes.glucoseForm(it.id))) }
        data.insulin.forEach { add(HistoryRow(it.at, "insulina", it.name, "${fmtNum(it.dose)} ${it.unit} · ${if (it.kind == "aplicacao") "Aplicação" else "Lembrete"}", Routes.insulinForm(it.id))) }
        data.meals.forEach { add(HistoryRow(it.at, "refeicao", MEAL_LABEL[it.type] ?: it.type, it.description + (it.carbs?.let { c -> " · ${fmtNum(c)} g carb." } ?: ""), Routes.CARE)) }
        data.symptoms.forEach { add(HistoryRow(it.at, "sintoma", it.name, INTENSITY_LABEL[it.intensity] ?: it.intensity, Routes.CARE)) }
    }.sortedByDescending { it.at }.filter { row ->
        (kind == "todos" || row.kind == kind) && when (period) {
            "7" -> row.at >= now - 7L * 86_400_000L
            "30" -> row.at >= now - 30L * 86_400_000L
            "90" -> row.at >= now - 90L * 86_400_000L
            else -> true
        }
    }
    ScrollScreen {
        Text("Histórico", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
        ChipRow(listOf("todos" to "Tudo", "glicose" to "Glicose", "insulina" to "Insulina", "refeicao" to "Refeições", "sintoma" to "Sintomas"), kind) { kind = it }
        ChipRow(listOf("7" to "7 dias", "30" to "30 dias", "90" to "90 dias", "tudo" to "Tudo"), period) { period = it }
        if (rows.isEmpty()) EmptyState("Nada neste filtro", "Ajuste o período ou o tipo de registro.")
        rows.forEach { row ->
            GCard(
                Modifier
                    .padding(top = 8.dp)
                    .clickable(enabled = row.route != null) { row.route?.let { nav.navigate(it) } },
            ) {
                Text(row.title, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text(row.subtitle, color = g.muted, fontSize = 13.sp)
                Text(formatDateTime(row.at), color = g.violet, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun MoreScreen(nav: NavHostController) {
    val g = glucoColors()
    ScrollScreen {
        Text("Organização", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 26.sp)
        Text("Organização do tratamento, sem complicar o dia.", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
        MoreRow(Icons.Filled.Person, "Perfil", "Dados pessoais e preferências", g.violet) { nav.navigate(Routes.PROFILE) }
        MoreRow(Icons.Filled.Favorite, "Cris IA ❤️", "Sua companheira inteligente da diabetes", g.violet) { nav.navigate(Routes.CRIS_IA) }
        MoreRow(Icons.Filled.LocationOn, "Localizador de Insulinas 💉", "Busca nacional de estabelecimentos", g.violet) { nav.navigate(Routes.LOCATOR) }
        MoreRow(Icons.Filled.BarChart, "Estatísticas", "Médias, faixas e evolução", g.violet) { nav.navigate(Routes.STATS) }
        MoreRow(Icons.Filled.Restaurant, "Alimentação e sintomas (legado)", "Registros manuais simples", g.orange) { nav.navigate(Routes.CARE) }
        MoreRow(Icons.Filled.Medication, "Medicamentos", "Cadastro e horários pessoais", g.blue) { nav.navigate(Routes.MEDS) }
        MoreRow(Icons.Filled.Summarize, "Relatório", "Texto claro para compartilhar", g.green) { nav.navigate(Routes.REPORT) }
        MoreRow(Icons.Filled.Settings, "Ajustes", "Tema, meta, PIN e sons", g.violetDeep) { nav.navigate(Routes.SETTINGS) }
    }
}

@Composable
private fun MoreRow(icon: ImageVector, title: String, text: String, color: androidx.compose.ui.graphics.Color, onClick: () -> Unit) {
    val g = glucoColors()
    GCard(Modifier.padding(top = 8.dp).clickable(onClick = onClick)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = color)
            Column(Modifier.padding(start = 12.dp)) {
                Text(title, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text(text, color = g.muted, fontSize = 13.sp)
            }
        }
    }
}
