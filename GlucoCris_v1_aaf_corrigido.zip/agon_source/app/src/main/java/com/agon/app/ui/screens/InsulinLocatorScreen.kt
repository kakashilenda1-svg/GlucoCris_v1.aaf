package com.agon.app.ui.screens

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.LocationCity
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Vaccines
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import com.agon.app.data.CrisPrefs
import com.agon.app.data.HealthPlace
import com.agon.app.data.OpenStatus
import com.agon.app.data.OpeningHours
import com.agon.app.data.PlaceFinder
import com.agon.app.data.PlaceKind
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.Normalizer


// Favoritos e preferências do localizador (não mexem em lembretes)
private const val LOC_PREFS = "gluco_locator_prefs"
private const val KEY_FAV_PLACES = "fav_place_ids"

private fun loadFavPlaceIds(ctx: android.content.Context): Set<String> =
    ctx.getSharedPreferences(LOC_PREFS, android.content.Context.MODE_PRIVATE)
        .getStringSet(KEY_FAV_PLACES, emptySet()) ?: emptySet()

private fun saveFavPlaceIds(ctx: android.content.Context, ids: Set<String>) {
    ctx.getSharedPreferences(LOC_PREFS, android.content.Context.MODE_PRIVATE)
        .edit().putStringSet(KEY_FAV_PLACES, ids).apply()
}

private data class InsulinOption(val id: String, val label: String, val human: Boolean, val aliases: List<String>)

private val INSULINS = listOf(
    InsulinOption("nph", "NPH", true, listOf("nph", "humana nph", "humulin n", "novolin n")),
    InsulinOption("regular", "Regular", true, listOf("regular", "humana regular", "humulin r", "novolin r")),
    InsulinOption("glargina", "Glargina", false, listOf("glargina", "lantus", "basaglar", "toujeo")),
    InsulinOption("degludeca", "Degludeca", false, listOf("degludeca", "tresiba")),
    InsulinOption("detemir", "Detemir", false, listOf("detemir", "levemir")),
    InsulinOption("lispro", "Lispro", false, listOf("lispro", "humalog")),
    InsulinOption("asparte", "Asparte", false, listOf("asparte", "novorapid", "fiasp")),
    InsulinOption("glulisina", "Glulisina", false, listOf("glulisina", "apidra")),
)

private val RADII = listOf(1, 2, 5, 10, 20)

private val UFS = listOf(
    "AC", "AL", "AP", "AM", "BA", "CE", "DF", "ES", "GO", "MA", "MT", "MS", "MG", "PA",
    "PB", "PR", "PE", "PI", "RJ", "RN", "RS", "RO", "RR", "SC", "SP", "SE", "TO",
)

private enum class LocState { CHECKING, NEED_PERMISSION, BLOCKED, GPS_OFF, LOCATING, READY, CITY }

private fun norm(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

private fun recommendedFor(ins: InsulinOption?, kind: PlaceKind): Boolean = when {
    ins == null -> false
    ins.human -> kind == PlaceKind.UBS || kind == PlaceKind.FARMACIA
    else -> kind == PlaceKind.FARMACIA
}

private fun kindIcon(k: PlaceKind): ImageVector = when (k) {
    PlaceKind.FARMACIA -> Icons.Filled.LocalPharmacy
    PlaceKind.UBS -> Icons.Filled.MedicalServices
    PlaceKind.HOSPITAL -> Icons.Filled.LocalHospital
    PlaceKind.CLINICA -> Icons.Filled.Vaccines
}

private fun fmtKm(km: Double): String = if (km < 1) "${(km * 1000).toInt()} m" else "%.1f km".format(km).replace('.', ',')

@Composable
fun InsulinLocatorScreen(nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    val listState = rememberLazyListState()

    var locState by remember { mutableStateOf(LocState.CHECKING) }
    var center by remember { mutableStateOf<Pair<Double, Double>?>(null) }
    var placeLabel by remember { mutableStateOf("") }
    var places by remember { mutableStateOf<List<HealthPlace>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var fetchedRadius by remember { mutableStateOf(0) }

    var query by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf<PlaceKind?>(null) }
    var radius by remember { mutableStateOf(5) }
    var only24h by remember { mutableStateOf(false) }
    var onlyPhone by remember { mutableStateOf(false) }
    var sortByName by remember { mutableStateOf(false) }
    var insulin by remember { mutableStateOf<InsulinOption?>(null) }
    var showFilters by remember { mutableStateOf(false) }
    var openNow by remember { mutableStateOf(false) }
    var showMap by remember { mutableStateOf(false) }
    var selectedId by remember { mutableStateOf<String?>(null) }
    var minuteTick by remember { mutableStateOf(0) }

    var cityInput by remember { mutableStateOf("") }
    var uf by remember { mutableStateOf("") }
    var showCityForm by remember { mutableStateOf(false) }
    var cityError by remember { mutableStateOf<String?>(null) }

    fun hasPermission() =
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun runSearch() {
        val c = center ?: return
        loading = true
        error = null
        scope.launch {
            try {
                places = PlaceFinder.search(c.first, c.second, radius)
                fetchedRadius = radius
            } catch (_: Exception) {
                error = "Não consegui buscar agora. Verifique a internet e tente de novo."
            }
            loading = false
            listState.scrollToItem(0)
        }
    }

    fun locate() {
        if (!PlaceFinder.locationEnabled(context)) { locState = LocState.GPS_OFF; return }
        locState = LocState.LOCATING
        scope.launch {
            val loc = PlaceFinder.currentLocation(context)
            if (loc == null) {
                locState = LocState.GPS_OFF
                return@launch
            }
            center = loc.latitude to loc.longitude
            fetchedRadius = 0
            locState = LocState.READY
            showCityForm = false
            placeLabel = "perto de você"
            runSearch()
            PlaceFinder.reverse(loc.latitude, loc.longitude)?.let { placeLabel = "perto de você · $it" }
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { res ->
        if (res.values.any { it }) {
            locate()
        } else {
            val act = context.findActivity()
            val canAsk = act != null && ActivityCompat.shouldShowRequestPermissionRationale(act, Manifest.permission.ACCESS_COARSE_LOCATION)
            locState = if (canAsk) LocState.NEED_PERMISSION else LocState.BLOCKED
        }
    }

    fun askLocation() {
        if (hasPermission()) locate()
        else permLauncher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
    }

    fun searchCity() {
        val city = cityInput.trim()
        if (city.length < 2) { cityError = "Digite o nome da cidade."; return }
        cityError = null
        focus.clearFocus()
        loading = true
        scope.launch {
            val label = if (uf.isNotBlank()) "$city, $uf" else city
            val c = PlaceFinder.geocode(label)
            if (c == null) {
                loading = false
                cityError = "Não encontrei essa cidade. Confira o nome e o estado."
                return@launch
            }
            val mem = CrisPrefs.loadMemory(context)
            CrisPrefs.saveMemory(context, mem.copy(lastLocatorCity = city, lastLocatorState = uf))
            center = c
            fetchedRadius = 0
            placeLabel = "em $label"
            locState = LocState.CITY
            showCityForm = false
            runSearch()
        }
    }

    var favIds by remember { mutableStateOf(loadFavPlaceIds(context)) }
    var showFavOnly by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val mem = CrisPrefs.loadMemory(context)
        cityInput = mem.lastLocatorCity
        uf = mem.lastLocatorState.takeIf { it in UFS }.orEmpty()
        if (mem.lastLocatorRadius in RADII) radius = mem.lastLocatorRadius
        if (mem.lastLocatorInsulinId.isNotBlank()) {
            insulin = INSULINS.firstOrNull { it.id == mem.lastLocatorInsulinId }
        }
        if (hasPermission()) locate() else locState = LocState.NEED_PERMISSION
    }

    // Lembra raio e insulina escolhida
    LaunchedEffect(radius, insulin?.id) {
        val mem = CrisPrefs.loadMemory(context)
        CrisPrefs.saveMemory(
            context,
            mem.copy(
                lastLocatorRadius = radius,
                lastLocatorInsulinId = insulin?.id.orEmpty(),
            ),
        )
    }

    LaunchedEffect(Unit) {
        while (true) { delay(60_000); minuteTick++ }
    }

    LaunchedEffect(radius) { if (center != null && radius > fetchedRadius) runSearch() }

    // ---------- filtros (todos aplicados em tempo real) ----------
    val q = norm(query.trim())
    val matchedInsulin = INSULINS.firstOrNull { o -> q.isNotEmpty() && o.aliases.any { norm(it).startsWith(q) || q.contains(norm(it)) } }
    val effectiveInsulin = insulin ?: matchedInsulin
    val textFilter = if (matchedInsulin != null && insulin == null) "" else q
    val statusOf: Map<String, OpenStatus?> = remember(places, minuteTick) { places.associate { it.id to OpeningHours.status(it.hours) } }
    val inRadius = places.filter { it.distanceKm <= radius }
    val hiddenUnknown = if (openNow) inRadius.count { statusOf[it.id] == null } else 0
    val base = places.filter { p ->
        p.distanceKm <= radius &&
            (!openNow || statusOf[p.id]?.open == true) &&
            (!only24h || p.is24h) &&
            (!onlyPhone || p.phone.isNotBlank()) &&
            (textFilter.isEmpty() || norm(p.name + " " + p.address + " " + p.brand + " " + p.kind.label).contains(textFilter))
    }
    val counts = PlaceKind.entries.associateWith { k -> base.count { it.kind == k } }
    val baseFav = if (showFavOnly) base.filter { it.id in favIds } else base
    val shown = baseFav.filter { kind == null || it.kind == kind }.let { list ->
        when {
            sortByName -> list.sortedBy { norm(it.name) }
            effectiveInsulin != null -> list.sortedWith(compareByDescending<HealthPlace> { recommendedFor(effectiveInsulin, it.kind) }.thenBy { it.distanceKm })
            // Favoritos primeiro na lista geral
            else -> list.sortedWith(compareByDescending<HealthPlace> { it.id in favIds }.thenBy { it.distanceKm })
        }
    }
    val activeFilters = listOf(openNow, only24h, onlyPhone, sortByName, insulin != null, radius != 5).count { it }

    Column(Modifier.fillMaxSize().background(g.bg).imePadding()) {
        // ---------- cabeçalho fixo ----------
        Column(Modifier.fillMaxWidth().background(g.card).padding(bottom = 8.dp)) {
            Row(Modifier.fillMaxWidth().padding(start = 4.dp, end = 16.dp, top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(48.dp).clip(CircleShape).clickable { nav.popBackStack() },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Voltar", tint = g.ink) }
                Column(Modifier.weight(1f)) {
                    Text("Localizador de insulina", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text(
                        if (center == null) "Farmácias, postos e hospitais perto de você" else placeLabel,
                        color = g.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(g.lilacSoft).clickable { showCityForm = !showCityForm },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.LocationCity, "Buscar em outra cidade", tint = g.violet) }
                Spacer(Modifier.width(8.dp))
                Box(
                    Modifier.size(44.dp).clip(CircleShape).background(g.lilacSoft).clickable { askLocation() },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Filled.MyLocation, "Usar minha localização", tint = g.violet) }
            }

            // Busca
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).heightIn(min = 48.dp)
                    .clip(RoundedCornerShape(14.dp)).background(g.inputBg).padding(horizontal = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Icon(Icons.Filled.Search, null, tint = g.muted, modifier = Modifier.size(20.dp))
                Box(Modifier.weight(1f).padding(horizontal = 10.dp, vertical = 12.dp)) {
                    if (query.isEmpty()) Text("Nome, bairro, rede ou insulina (ex.: glargina)", color = g.muted, fontSize = 14.sp, maxLines = 1)
                    BasicTextField(
                        value = query,
                        onValueChange = { query = it },
                        singleLine = true,
                        textStyle = TextStyle(color = g.ink, fontSize = 15.sp),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
                        modifier = Modifier.fillMaxWidth(),
                    )
                }
                if (query.isNotEmpty()) {
                    Box(Modifier.size(36.dp).clip(CircleShape).clickable { query = "" }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Close, "Limpar busca", tint = g.muted, modifier = Modifier.size(18.dp))
                    }
                }
            }

            // Tipo de local
            LazyRow(
                Modifier.fillMaxWidth().height(48.dp),
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                item { FilterChip("Todos · ${base.size}", kind == null) { kind = null } }
                items(PlaceKind.entries.toList()) { k ->
                    FilterChip("${k.label} · ${counts[k] ?: 0}", kind == k) { kind = if (kind == k) null else k }
                }
            }

            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
                Row(
                    Modifier.height(36.dp).clip(RoundedCornerShape(18.dp))
                        .background(if (showFilters || activeFilters > 0) g.violet else g.lilacSoft)
                        .clickable { showFilters = !showFilters }.padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Tune, null, tint = if (showFilters || activeFilters > 0) Color.White else g.violet, modifier = Modifier.size(16.dp))
                    Text(
                        if (activeFilters > 0) "Filtros ($activeFilters)" else "Filtros",
                        color = if (showFilters || activeFilters > 0) Color.White else g.violet,
                        fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp),
                    )
                }
                Spacer(Modifier.width(8.dp))
                Row(
                    Modifier.height(36.dp).clip(RoundedCornerShape(18.dp))
                        .background(if (openNow) g.green else g.lilacSoft)
                        .clickable { openNow = !openNow }.padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Filled.Schedule, null, tint = if (openNow) Color.White else g.green, modifier = Modifier.size(16.dp))
                    Text("Aberto agora", color = if (openNow) Color.White else g.ink, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, softWrap = false, modifier = Modifier.padding(start = 6.dp))
                }
                Spacer(Modifier.width(8.dp))
                Row(
                    Modifier.height(36.dp).clip(RoundedCornerShape(18.dp))
                        .background(if (showFavOnly) g.violet else g.lilacSoft)
                        .clickable { showFavOnly = !showFavOnly }.padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        "★ Favoritos",
                        color = if (showFavOnly) Color.White else g.ink,
                        fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1,
                    )
                }
                Spacer(Modifier.weight(1f))
                Row(Modifier.height(36.dp).clip(RoundedCornerShape(18.dp)).background(g.lilacSoft)) {
                    listOf(false to Icons.AutoMirrored.Filled.List, true to Icons.Filled.Map).forEach { (isMap, icon) ->
                        Box(
                            Modifier.height(36.dp).width(44.dp).clip(RoundedCornerShape(18.dp))
                                .background(if (showMap == isMap) g.violet else Color.Transparent)
                                .clickable { showMap = isMap; focus.clearFocus() },
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(icon, if (isMap) "Ver no mapa" else "Ver em lista", tint = if (showMap == isMap) Color.White else g.violet, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "Raio $radius km · ${if (sortByName) "A–Z" else if (effectiveInsulin != null) "Indicados primeiro" else "Mais perto"}",
                    color = g.muted, fontSize = 12.sp, modifier = Modifier.weight(1f), maxLines = 1,
                )
                if (activeFilters > 0) {
                    Text(
                        "Limpar filtros", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable {
                            openNow = false; only24h = false; onlyPhone = false; sortByName = false; insulin = null; radius = 5; showFavOnly = false
                        }.padding(8.dp),
                    )
                }
            }

            AnimatedVisibility(showFilters) {
                Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
                    FilterLabel("Distância máxima")
                    ChipLine(RADII.map { "$it km" to (radius == it) }) { radius = RADII[it] }
                    FilterLabel("Mostrar só")
                    ChipLine(listOf("Aberto agora" to openNow, "Abertos 24 horas" to only24h, "Com telefone" to onlyPhone)) {
                        when (it) { 0 -> openNow = !openNow; 1 -> only24h = !only24h; else -> onlyPhone = !onlyPhone }
                    }
                    FilterLabel("Ordenar por")
                    ChipLine(listOf("Mais perto" to !sortByName, "Nome A–Z" to sortByName)) { sortByName = it == 1 }
                    FilterLabel("Qual insulina você procura?")
                    ChipLine(INSULINS.map { it.label to (insulin?.id == it.id) }) { i ->
                        insulin = if (insulin?.id == INSULINS[i].id) null else INSULINS[i]
                    }
                }
            }
        }

        // ---------- mapa ----------
        val mapCenter = center
        if (showMap && mapCenter != null && !loading && error == null) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                PlacesMap(
                    center = mapCenter,
                    places = shown,
                    selectedId = selectedId,
                    colorFor = { p ->
                        when (p.kind) {
                            PlaceKind.FARMACIA -> g.green
                            PlaceKind.UBS -> g.blue
                            PlaceKind.HOSPITAL -> g.red
                            PlaceKind.CLINICA -> g.violet
                        }
                    },
                    userColor = g.orange,
                    onSelect = { selectedId = it.id },
                    modifier = Modifier.fillMaxSize(),
                )
                Text(
                    "${shown.size} no mapa · toque num ponto",
                    color = g.ink, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.TopStart).padding(12.dp).clip(RoundedCornerShape(12.dp)).background(g.card).padding(horizontal = 10.dp, vertical = 6.dp),
                )
                val sel = shown.firstOrNull { it.id == selectedId }
                if (sel != null) {
                    Box(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp)) {
                        PlaceCard(sel, recommendedFor(effectiveInsulin, sel.kind), effectiveInsulin, statusOf[sel.id], onClose = { selectedId = null })
                    }
                }
            }
            return@Column
        }

        // ---------- conteúdo ----------
        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            if (showCityForm || (center == null && (locState == LocState.BLOCKED || locState == LocState.GPS_OFF || locState == LocState.NEED_PERMISSION))) {
                item {
                    InfoCard {
                        if (center == null) {
                            when (locState) {
                                LocState.NEED_PERMISSION -> {
                                    Text("Ache insulina perto de você", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                    Text("Com a sua localização eu mostro as farmácias, postos de saúde e hospitais mais próximos, com distância e rota. Ela é usada só durante a busca.", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                                    BigButton("Usar minha localização", g.violet, Icons.Filled.MyLocation) { askLocation() }
                                }
                                LocState.BLOCKED -> {
                                    Text("Localização bloqueada", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                    Text("Para ver os locais perto de você, libere a localização nas configurações. Ou busque por cidade aqui embaixo.", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                                    BigButton("Abrir configurações", g.violet, Icons.Filled.MyLocation) {
                                        context.startActivity(
                                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
                                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                                        )
                                    }
                                }
                                LocState.GPS_OFF -> {
                                    Text("Não consegui pegar sua localização", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                    Text("Ative a localização do celular e tente de novo, ou busque por cidade.", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                                    BigButton("Ativar localização", g.violet, Icons.Filled.MyLocation) {
                                        context.startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                    }
                                    Text(
                                        "Tentar de novo", color = g.violet, fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(top = 6.dp).clip(RoundedCornerShape(8.dp)).clickable { askLocation() }.padding(8.dp),
                                    )
                                }
                                else -> {}
                            }
                            Spacer(Modifier.height(14.dp))
                        }
                        Text("Buscar em uma cidade", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Box(
                            Modifier.fillMaxWidth().padding(top = 8.dp).heightIn(min = 48.dp).clip(RoundedCornerShape(12.dp))
                                .background(g.inputBg).padding(horizontal = 14.dp, vertical = 14.dp),
                        ) {
                            if (cityInput.isEmpty()) Text("Ex.: Campinas", color = g.muted, fontSize = 15.sp)
                            BasicTextField(
                                value = cityInput,
                                onValueChange = { cityInput = it },
                                singleLine = true,
                                textStyle = TextStyle(color = g.ink, fontSize = 15.sp),
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                keyboardActions = KeyboardActions(onSearch = { searchCity() }),
                                modifier = Modifier.fillMaxWidth(),
                            )
                        }
                        Text("Estado (opcional)", color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.height(44.dp), verticalAlignment = Alignment.CenterVertically) {
                            items(UFS) { s -> FilterChip(s, uf == s) { uf = if (uf == s) "" else s } }
                        }
                        cityError?.let { Text(it, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp)) }
                        BigButton("Buscar nesta cidade", g.blue, Icons.Filled.Search) { searchCity() }
                    }
                }
            }

            when {
                locState == LocState.CHECKING || locState == LocState.LOCATING || loading -> item {
                    Column(Modifier.fillMaxWidth().padding(vertical = 40.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = g.violet)
                        Text(
                            if (locState == LocState.LOCATING) "Pegando sua localização…" else "Procurando locais em até $radius km… pode levar alguns segundos",
                            color = g.muted, fontSize = 14.sp, modifier = Modifier.padding(top = 12.dp),
                        )
                    }
                }
                error != null -> item {
                    InfoCard {
                        Text("Ops, a busca falhou", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                        Text(error.orEmpty(), color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                        BigButton("Tentar de novo", g.violet, Icons.Filled.Search) { runSearch() }
                    }
                }
                center != null -> {
                    effectiveInsulin?.let { ins ->
                        item { InsulinHint(ins) }
                    }
                    if (shown.isEmpty()) {
                        item {
                            InfoCard {
                                Text("Nenhum local com esses filtros", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                                Text(if (openNow) "Nenhum local confirmado como aberto agora. Muitos locais não informam horário no mapa — desligue \"Aberto agora\" para ver todos." else "Tente aumentar a distância ou limpar os filtros.", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                                if (radius < 20) {
                                    BigButton("Aumentar para ${RADII.first { it > radius }} km", g.violet, Icons.Filled.Tune) { radius = RADII.first { it > radius } }
                                }
                            }
                        }
                    } else {
                        item {
                            Text(
                                "${shown.size} ${if (shown.size == 1) "local encontrado" else "locais encontrados"}" +
                                    if (hiddenUnknown > 0) " · $hiddenUnknown sem horário informado ocultos" else "",
                                color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            )
                        }
                        items(shown, key = { it.id }) { p ->
                            PlaceCard(p, recommendedFor(effectiveInsulin, p.kind), effectiveInsulin, statusOf[p.id]) {
                                selectedId = p.id; showMap = true
                            }
                        }
                    }
                }
            }

            item { OfficialChannels() }
        }
    }
}

@Composable
private fun FilterChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val g = glucoColors()
    Box(
        Modifier.height(36.dp).clip(RoundedCornerShape(18.dp))
            .background(if (selected) g.violet else g.lilacSoft)
            .border(1.dp, if (selected) g.violet else g.line, RoundedCornerShape(18.dp))
            .clickable(onClick = onClick).padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(label, color = if (selected) Color.White else g.ink, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun FilterLabel(text: String) {
    val g = glucoColors()
    Text(text, color = g.muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 16.dp, top = 8.dp, bottom = 2.dp))
}

@Composable
private fun ChipLine(options: List<Pair<String, Boolean>>, onClick: (Int) -> Unit) {
    LazyRow(
        Modifier.fillMaxWidth().height(44.dp),
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        items(options.size) { i -> FilterChip(options[i].first, options[i].second) { onClick(i) } }
    }
}

@Composable
private fun InfoCard(content: @Composable () -> Unit) {
    val g = glucoColors()
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(g.card).padding(16.dp)) { content() }
}

@Composable
private fun BigButton(text: String, color: Color, icon: ImageVector, onClick: () -> Unit) {
    Row(
        Modifier.padding(top = 12.dp).fillMaxWidth().height(48.dp).clip(RoundedCornerShape(14.dp)).background(color).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
        Text(text, color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp, modifier = Modifier.padding(start = 8.dp))
    }
}

@Composable
private fun InsulinHint(ins: InsulinOption) {
    val g = glucoColors()
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(g.greenSoft).padding(14.dp)) {
        Text("Onde costuma ter ${ins.label}", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
        Text(
            if (ins.human) {
                "Insulina humana é gratuita pelo SUS: retire na UBS (posto de saúde) com receita, documento e Cartão SUS. Também é vendida em farmácias, e pode entrar no Farmácia Popular conforme o elenco vigente."
            } else {
                "Análogos como ${ins.label.lowercase()} normalmente são vendidos em farmácias. Pelo SUS, a liberação é feita pela farmácia de alto custo do estado, mediante cadastro e protocolo."
            },
            color = g.ink, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 4.dp),
        )
        Text("Os locais indicados aparecem primeiro. Ligue antes para confirmar o estoque.", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun PlaceCard(
    p: HealthPlace,
    recommended: Boolean,
    ins: InsulinOption?,
    status: OpenStatus?,
    onClose: (() -> Unit)? = null,
    onShowOnMap: (() -> Unit)? = null,
) {
    val g = glucoColors()
    val context = LocalContext.current
    var isFav by remember(p.id) { mutableStateOf(p.id in loadFavPlaceIds(context)) }
    val tint = when (p.kind) {
        PlaceKind.FARMACIA -> g.green
        PlaceKind.UBS -> g.blue
        PlaceKind.HOSPITAL -> g.red
        PlaceKind.CLINICA -> g.violet
    }
    fun open(uri: String) {
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(uri)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(g.card)
            .border(1.dp, if (recommended) g.green else Color.Transparent, RoundedCornerShape(18.dp))
            .padding(14.dp),
    ) {
        Row(verticalAlignment = Alignment.Top) {
            Box(Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(tint.copy(alpha = 0.14f)), contentAlignment = Alignment.Center) {
                Icon(kindIcon(p.kind), null, tint = tint, modifier = Modifier.size(22.dp))
            }
            Column(Modifier.weight(1f).padding(start = 12.dp)) {
                Text(p.name, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                Row(Modifier.padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(p.kind.label, color = tint, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    if (p.is24h) Text("  ·  24 horas", color = g.green, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }
            }
            Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(start = 8.dp)) {
                Text(fmtKm(p.distanceKm), color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                if (onShowOnMap != null) {
                    Text("ver no mapa", color = g.violet, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onShowOnMap).padding(4.dp))
                }
                if (onClose != null) {
                    Box(Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                        Icon(Icons.Filled.Close, "Fechar", tint = g.muted, modifier = Modifier.size(18.dp))
                    }
                }
            }
        }
        Text(
            status?.label ?: "Horário não informado — ligue antes",
            color = when (status?.open) { true -> g.green; false -> g.red; null -> g.muted },
            fontWeight = FontWeight.Bold, fontSize = 12.sp,
            modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp))
                .background(when (status?.open) { true -> g.greenSoft; false -> g.redSoft; null -> g.inputBg })
                .padding(horizontal = 8.dp, vertical = 4.dp),
        )
        if (recommended && ins != null) {
            Text(
                "Indicado para ${ins.label}",
                color = g.green, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                modifier = Modifier.padding(top = 8.dp).clip(RoundedCornerShape(8.dp)).background(g.greenSoft).padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
        if (p.address.isNotBlank()) Text(p.address, color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
        if (p.hours.isNotBlank() && !p.is24h) Text("Horário: ${p.hours}", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp), maxLines = 2, overflow = TextOverflow.Ellipsis)
        if (p.phone.isNotBlank()) Text("Tel.: ${p.phone}", color = g.ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 2.dp))
        Text(
            if (isFav) "★ Remover dos favoritos" else "☆ Salvar nos favoritos",
            color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp,
            modifier = Modifier.padding(top = 8.dp).clickable {
                val cur = loadFavPlaceIds(context).toMutableSet()
                if (isFav) cur.remove(p.id) else cur.add(p.id)
                saveFavPlaceIds(context, cur)
                isFav = !isFav
            },
        )

        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            CardAction("Rota", Icons.Filled.Directions, g.violet, Modifier.weight(1f)) {
                open("geo:${p.lat},${p.lon}?q=${p.lat},${p.lon}(${Uri.encode(p.name)})")
            }
            if (p.phone.isNotBlank()) {
                CardAction("Ligar", Icons.Filled.Call, g.green, Modifier.weight(1f)) {
                    open("tel:${p.phone.filter { it.isDigit() || it == '+' }}")
                }
            } else {
                CardAction("Pesquisar", Icons.Filled.Search, g.blue, Modifier.weight(1f)) {
                    open("https://www.google.com/search?q=" + Uri.encode("${p.name} ${p.address} telefone"))
                }
            }
            CardAction("Enviar", Icons.Filled.Share, g.muted, Modifier.weight(1f)) {
                val text = buildString {
                    append(p.name); append(" (${p.kind.label})\n")
                    if (p.address.isNotBlank()) append(p.address).append("\n")
                    if (p.phone.isNotBlank()) append("Tel.: ${p.phone}\n")
                    append("https://www.google.com/maps/search/?api=1&query=${p.lat},${p.lon}")
                }
                try {
                    context.startActivity(
                        Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text), "Compartilhar local")
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                    )
                } catch (_: Exception) {}
            }
        }
    }
}

@Composable
private fun CardAction(label: String, icon: ImageVector, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.height(44.dp).clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.12f)).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
    ) {
        Icon(icon, null, tint = color, modifier = Modifier.size(18.dp))
        Text(label, color = color, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(start = 6.dp), maxLines = 1)
    }
}

@Composable
private fun OfficialChannels() {
    val g = glucoColors()
    val context = LocalContext.current
    fun open(url: String) {
        try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }
    Column(Modifier.fillMaxWidth().padding(top = 6.dp).clip(RoundedCornerShape(18.dp)).background(g.card).padding(16.dp)) {
        Text("Canais oficiais", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
        Text("Para confirmar disponibilidade pelo SUS e Farmácia Popular.", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 6.dp))
        listOf(
            "Disque Saúde 136" to "tel:136",
            "Farmácia Popular (gov.br)" to "https://www.gov.br/saude/pt-br/composicao/sectics/farmacia-popular",
            "Buscar UBS no CNES" to "https://cnes.datasus.gov.br/",
            "Emergência: SAMU 192" to "tel:192",
        ).forEach { (label, url) ->
            Text(
                label, color = g.violet, fontWeight = FontWeight.Bold, fontSize = 14.sp,
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { open(url) }.padding(vertical = 10.dp),
            )
        }
        Text("Dados de locais: OpenStreetMap (colaborativo). O app não confirma estoque — ligue antes de ir.", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    }
}
