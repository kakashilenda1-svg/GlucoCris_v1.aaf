package com.agon.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.agon.app.data.GlucoViewModel
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.theme.glucoColors

@Composable
fun LockScreen(vm: GlucoViewModel, displayName: String) {
    val g = glucoColors()
    val data by vm.data.collectAsStateWithLifecycle()
    val pinEnabled = data.settings.pinEnabled
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }

    fun tryUnlock(code: String) {
        if (vm.unlock(code)) {
            error = false
        } else {
            error = true
            pin = ""
        }
    }

    Column(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(g.heroStart, g.bg))).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("Gluco Cris ❤️", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 28.sp)
        Text(displayName.ifBlank { "Bem-vindo(a)" }, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 4.dp))
        if (pinEnabled) {
            Text("Área pessoal protegida por PIN", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            Text(
                "● ".repeat(pin.length) + "○ ".repeat((4 - pin.length).coerceAtLeast(0)),
                color = Color.White,
                fontSize = 22.sp,
                modifier = Modifier.padding(vertical = 20.dp),
            )
            if (error) Text("PIN incorreto. Tente novamente.", color = Color(0xFFFECACA), fontSize = 13.sp)
            val keys = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫")
            keys.chunked(3).forEach { row ->
                androidx.compose.foundation.layout.Row(
                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                ) {
                    row.forEach { k ->
                        Box(
                            Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(if (k.isEmpty()) Color.Transparent else Color.White.copy(alpha = 0.18f))
                                .clickable(enabled = k.isNotEmpty()) {
                                    when (k) {
                                        "⌫" -> { pin = pin.dropLast(1); error = false }
                                        else -> {
                                            if (pin.length < 4) {
                                                pin += k
                                                if (pin.length == 4) tryUnlock(pin)
                                            }
                                        }
                                    }
                                },
                            contentAlignment = Alignment.Center,
                        ) {
                            if (k.isNotEmpty()) Text(k, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        } else {
            Text("Toque para entrar na sua área", color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp, modifier = Modifier.padding(top = 12.dp, bottom = 20.dp), textAlign = TextAlign.Center)
            PrimaryButton("Entrar", Color.White, {
                vm.unlock("")
            }, Modifier.fillMaxWidth().padding(horizontal = 24.dp))
        }
    }
}
