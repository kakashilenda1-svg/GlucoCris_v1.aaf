package com.agon.app.ui.screens

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Meal
import com.agon.app.data.uid
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.glucoColors
import kotlin.math.roundToInt

/* ═══════════════════════════════════════════════════════════════
 * SCHEMA (JSON lógico) — Plano alimentar + nutricionista
 *
 * Nutricionista {
 *   id, nome, crn, especialidade, verificado, bioCurta, fotoUrl?
 * }
 * NutrientesDia {
 *   kcal, carbG, protG, fatG, pctCarb, pctProt, pctFat
 * }
 * ItemRefeicao {
 *   nome, porcao, carbG, kcal, recipeId?  // link opcional à receita do app
 * }
 * RefeicaoPlano {
 *   tipo: cafe|almoco|lanche|jantar|ceia
 *   titulo, itens[], carbTotalG, kcalTotal
 * }
 * PlanoAlimentar {
 *   id, titulo, resumo, objetivos[], estilos[],
 *   kcalAlvo, frequencia: diario|semanal,
 *   nutrientes: NutrientesDia,
 *   refeicoes: RefeicaoPlano[],   // 1 dia modelo (ou 7 no futuro)
 *   listaCompras: String[],
 *   nutricionista: Nutricionista,
 *   avisos
 * }
 * ═══════════════════════════════════════════════════════════════ */

data class Nutricionista(
    val id: String,
    val nome: String,
    val crn: String,
    val especialidade: String,
    val verificado: Boolean = true,
    val bioCurta: String = "",
)

data class NutrientesDia(
    val kcal: Int,
    val carbG: Double,
    val protG: Double,
    val fatG: Double,
) {
    val macroSum get() = (carbG * 4 + protG * 4 + fatG * 9).coerceAtLeast(1.0)
    val pctCarb get() = ((carbG * 4) / macroSum * 100).toFloat()
    val pctProt get() = ((protG * 4) / macroSum * 100).toFloat()
    val pctFat get() = ((fatG * 9) / macroSum * 100).toFloat()
}

data class ItemRefeicaoPlano(
    val nome: String,
    val porcao: String,
    val carbG: Double,
    val kcal: Int,
    val recipeId: String? = null,
)

data class RefeicaoPlano(
    val tipo: String,
    val titulo: String,
    val itens: List<ItemRefeicaoPlano>,
) {
    val carbTotalG get() = itens.sumOf { it.carbG }
    val kcalTotal get() = itens.sumOf { it.kcal }
}

data class PlanoAlimentar(
    val id: String,
    val titulo: String,
    val resumo: String,
    val objetivos: List<String>,
    val estilos: List<String>,
    val kcalAlvo: Int,
    val frequencia: String,
    val nutrientes: NutrientesDia,
    val refeicoes: List<RefeicaoPlano>,
    val listaCompras: List<String>,
    val nutricionista: Nutricionista,
    val avisos: String = "Conteúdo elaborado por nutricionista. Não substitui consulta individual. Ajuste com sua equipe, especialmente se usa insulina.",
)

val OBJETIVOS_PLANO = listOf(
    "emagrecimento" to "Emagrecimento",
    "massa" to "Ganho de massa",
    "glicemia" to "Controle de glicemia",
    "hipertensao" to "Hipertensão",
    "renal" to "Saúde renal",
    "reeducacao" to "Reeducação alimentar",
)

val ESTILOS_PLANO = listOf(
    "lowcarb" to "Low carb",
    "ceto" to "Cetogênica",
    "vegana" to "Vegana",
    "vegetariana" to "Vegetariana",
    "mediterranea" to "Mediterrânea",
    "sem_gluten" to "Sem glúten/lactose",
    "jejum" to "Jejum intermitente",
)

val KCAL_FAIXAS = listOf(1500 to "≈1500 kcal", 1800 to "≈1800 kcal", 2000 to "≈2000 kcal", 2200 to "≈2200 kcal")

private val NUTRI_A = Nutricionista(
    "nut-ana", "Dra. Ana Paula Mendes", "CRN-3 12345",
    "Diabetes e metabolismo", true,
    "Especialista em contagem de carboidratos e planos práticos.",
)
private val NUTRI_B = Nutricionista(
    "nut-bruno", "Dr. Bruno Oliveira", "CRN-3 23456",
    "Esportiva e composição corporal", true,
    "Foco em performance com controle glicêmico.",
)
private val NUTRI_C = Nutricionista(
    "nut-carla", "Dra. Carla Nogueira", "CRN-2 34567",
    "Renal e hipertensão", true,
    "Planos com atenção a sódio e potássio.",
)

/**
 * Catálogo inicial de planos (conteúdo profissional de referência no app).
 * Valores são exemplos estruturados para UX — o usuário deve validar com a equipe.
 */
val CATALOGO_PLANOS: List<PlanoAlimentar> = listOf(
    PlanoAlimentar(
        id = "plano-dm-1800",
        titulo = "Controle glicêmico 1800 kcal",
        resumo = "Dia modelo com carboidrato distribuído nas refeições, fibras e proteína em todas as refeições principais.",
        objetivos = listOf("glicemia", "reeducacao"),
        estilos = listOf("mediterranea"),
        kcalAlvo = 1800,
        frequencia = "diario",
        nutrientes = NutrientesDia(1800, 180.0, 100.0, 60.0),
        refeicoes = listOf(
            RefeicaoPlano("cafe", "Café da manhã", listOf(
                ItemRefeicaoPlano("Ovo cozido", "2 unidades", 1.0, 140, "br-omelete"),
                ItemRefeicaoPlano("Pão integral", "1 fatia", 12.0, 70, null),
                ItemRefeicaoPlano("Mamão", "1 fatia média", 12.0, 50, null),
            )),
            RefeicaoPlano("almoco", "Almoço", listOf(
                ItemRefeicaoPlano("Arroz integral", "3 colheres de servir", 30.0, 140, null),
                ItemRefeicaoPlano("Feijão", "1 concha", 15.0, 90, null),
                ItemRefeicaoPlano("Frango grelhado", "120 g", 0.0, 190, "br-frango-grelhado"),
                ItemRefeicaoPlano("Salada crua", "à vontade", 5.0, 30, null),
            )),
            RefeicaoPlano("lanche", "Lanche", listOf(
                ItemRefeicaoPlano("Iogurte natural", "1 pote", 8.0, 90, null),
                ItemRefeicaoPlano("Castanhas", "1 colher de sopa", 3.0, 80, null),
            )),
            RefeicaoPlano("jantar", "Jantar", listOf(
                ItemRefeicaoPlano("Peixe assado", "120 g", 0.0, 160, null),
                ItemRefeicaoPlano("Batata-doce", "1 unidade pequena", 25.0, 110, null),
                ItemRefeicaoPlano("Legumes refogados", "1 prato", 10.0, 60, null),
            )),
            RefeicaoPlano("ceia", "Ceia (opcional)", listOf(
                ItemRefeicaoPlano("Chá sem açúcar", "1 xícara", 0.0, 2, null),
            )),
        ),
        listaCompras = listOf(
            "Ovos", "Pão integral", "Mamão", "Arroz integral", "Feijão", "Peito de frango",
            "Folhas para salada", "Iogurte natural", "Castanhas", "Peixe", "Batata-doce", "Legumes variados",
        ),
        nutricionista = NUTRI_A,
    ),
    PlanoAlimentar(
        id = "plano-lowcarb-1500",
        titulo = "Low carb consciente 1500 kcal",
        resumo = "Redução moderada de amido, ênfase em vegetais e proteína. Não é cetogênica estrita.",
        objetivos = listOf("emagrecimento", "glicemia"),
        estilos = listOf("lowcarb"),
        kcalAlvo = 1500,
        frequencia = "diario",
        nutrientes = NutrientesDia(1500, 90.0, 110.0, 70.0),
        refeicoes = listOf(
            RefeicaoPlano("cafe", "Café da manhã", listOf(
                ItemRefeicaoPlano("Omelete com espinafre", "2 ovos", 3.0, 200, "br-omelete"),
                ItemRefeicaoPlano("Queijo minas", "1 fatia", 1.0, 70, null),
            )),
            RefeicaoPlano("almoco", "Almoço", listOf(
                ItemRefeicaoPlano("Carne magra grelhada", "120 g", 0.0, 200, null),
                ItemRefeicaoPlano("Couve-flor e brócolis", "1 prato", 12.0, 50, null),
                ItemRefeicaoPlano("Azeite", "1 colher de sopa", 0.0, 90, null),
            )),
            RefeicaoPlano("lanche", "Lanche", listOf(
                ItemRefeicaoPlano("Iogurte integral", "1 pote", 6.0, 110, null),
            )),
            RefeicaoPlano("jantar", "Jantar", listOf(
                ItemRefeicaoPlano("Frango desfiado", "100 g", 0.0, 165, null),
                ItemRefeicaoPlano("Salada completa", "1 prato", 8.0, 40, null),
            )),
        ),
        listaCompras = listOf("Ovos", "Espinafre", "Queijo minas", "Carne magra", "Brócolis", "Couve-flor", "Azeite", "Iogurte", "Frango"),
        nutricionista = NUTRI_A,
    ),
    PlanoAlimentar(
        id = "plano-massa-2200",
        titulo = "Ganho de massa com controle 2200 kcal",
        resumo = "Maior aporte calórico e proteico, carboidrato em treinos, com marcação de porções.",
        objetivos = listOf("massa"),
        estilos = listOf("mediterranea"),
        kcalAlvo = 2200,
        frequencia = "diario",
        nutrientes = NutrientesDia(2200, 250.0, 140.0, 70.0),
        refeicoes = listOf(
            RefeicaoPlano("cafe", "Café da manhã", listOf(
                ItemRefeicaoPlano("Aveia com leite", "1 tigela", 35.0, 280, "br-aveia-leite"),
                ItemRefeicaoPlano("Banana", "1 unidade", 25.0, 90, null),
                ItemRefeicaoPlano("Pasta de amendoim", "1 colher", 3.0, 90, null),
            )),
            RefeicaoPlano("almoco", "Almoço", listOf(
                ItemRefeicaoPlano("Arroz", "4 colheres", 40.0, 180, null),
                ItemRefeicaoPlano("Feijão", "1 concha", 15.0, 90, null),
                ItemRefeicaoPlano("Frango", "150 g", 0.0, 240, null),
            )),
            RefeicaoPlano("lanche", "Lanche pré-treino", listOf(
                ItemRefeicaoPlano("Pão francês", "1 unidade", 29.0, 150, null),
                ItemRefeicaoPlano("Ovo", "1 unidade", 0.5, 70, null),
            )),
            RefeicaoPlano("jantar", "Jantar", listOf(
                ItemRefeicaoPlano("Batata-doce", "1 média", 35.0, 150, null),
                ItemRefeicaoPlano("Carne", "120 g", 0.0, 220, null),
                ItemRefeicaoPlano("Salada", "1 prato", 5.0, 25, null),
            )),
        ),
        listaCompras = listOf("Aveia", "Leite", "Banana", "Pasta de amendoim", "Arroz", "Feijão", "Frango", "Pão", "Ovos", "Batata-doce", "Carne"),
        nutricionista = NUTRI_B,
    ),
    PlanoAlimentar(
        id = "plano-hipertensao-1800",
        titulo = "Hipertensão e coração 1800 kcal",
        resumo = "Baixo sódio relativo, vegetais, gorduras boas e porções estáveis.",
        objetivos = listOf("hipertensao", "reeducacao"),
        estilos = listOf("mediterranea"),
        kcalAlvo = 1800,
        frequencia = "diario",
        nutrientes = NutrientesDia(1800, 190.0, 95.0, 60.0),
        refeicoes = listOf(
            RefeicaoPlano("cafe", "Café da manhã", listOf(
                ItemRefeicaoPlano("Iogurte natural", "1 pote", 8.0, 90, null),
                ItemRefeicaoPlano("Fruta", "1 porção", 15.0, 60, null),
                ItemRefeicaoPlano("Aveia", "2 colheres", 15.0, 80, null),
            )),
            RefeicaoPlano("almoco", "Almoço", listOf(
                ItemRefeicaoPlano("Peixe", "120 g", 0.0, 160, null),
                ItemRefeicaoPlano("Arroz integral", "3 colheres", 30.0, 140, null),
                ItemRefeicaoPlano("Salada e legumes", "1 prato", 12.0, 50, null),
            )),
            RefeicaoPlano("jantar", "Jantar", listOf(
                ItemRefeicaoPlano("Frango", "100 g", 0.0, 165, null),
                ItemRefeicaoPlano("Legumes", "1 prato", 15.0, 70, null),
            )),
        ),
        listaCompras = listOf("Iogurte", "Frutas", "Aveia", "Peixe", "Arroz integral", "Legumes", "Frango", "Azeite"),
        nutricionista = NUTRI_C,
    ),
    PlanoAlimentar(
        id = "plano-veg-1600",
        titulo = "Vegetariano equilibrado 1600 kcal",
        resumo = "Proteína vegetal, ferro com vitamina C e carboidrato em porções marcadas.",
        objetivos = listOf("reeducacao", "emagrecimento"),
        estilos = listOf("vegetariana"),
        kcalAlvo = 1600,
        frequencia = "diario",
        nutrientes = NutrientesDia(1600, 180.0, 70.0, 55.0),
        refeicoes = listOf(
            RefeicaoPlano("cafe", "Café da manhã", listOf(
                ItemRefeicaoPlano("Tapioca com queijo", "1 unidade", 28.0, 180, "br-tapioca"),
                ItemRefeicaoPlano("Suco de laranja natural", "1 copo pequeno", 15.0, 60, null),
            )),
            RefeicaoPlano("almoco", "Almoço", listOf(
                ItemRefeicaoPlano("Arroz", "3 colheres", 30.0, 140, null),
                ItemRefeicaoPlano("Feijão", "1 concha", 15.0, 90, null),
                ItemRefeicaoPlano("Ovo", "2 unidades", 1.0, 140, null),
                ItemRefeicaoPlano("Salada", "1 prato", 5.0, 25, null),
            )),
            RefeicaoPlano("jantar", "Jantar", listOf(
                ItemRefeicaoPlano("Lentilha", "1 concha", 20.0, 120, null),
                ItemRefeicaoPlano("Legumes", "1 prato", 12.0, 50, null),
            )),
        ),
        listaCompras = listOf("Goma de tapioca", "Queijo", "Laranja", "Arroz", "Feijão", "Ovos", "Lentilha", "Legumes"),
        nutricionista = NUTRI_A,
    ),
    PlanoAlimentar(
        id = "plano-renal-leve-1700",
        titulo = "Saúde renal — ajuste leve 1700 kcal",
        resumo = "Atenção a porções de proteína e sódio. Use apenas com orientação do seu nefrologista/nutricionista.",
        objetivos = listOf("renal"),
        estilos = listOf("mediterranea"),
        kcalAlvo = 1700,
        frequencia = "diario",
        nutrientes = NutrientesDia(1700, 200.0, 70.0, 55.0),
        refeicoes = listOf(
            RefeicaoPlano("cafe", "Café da manhã", listOf(
                ItemRefeicaoPlano("Pão", "1 fatia", 15.0, 70, null),
                ItemRefeicaoPlano("Ovo", "1 unidade", 0.5, 70, null),
                ItemRefeicaoPlano("Fruta", "1 porção", 15.0, 60, null),
            )),
            RefeicaoPlano("almoco", "Almoço", listOf(
                ItemRefeicaoPlano("Arroz", "3 colheres", 30.0, 140, null),
                ItemRefeicaoPlano("Proteína magra", "80 g", 0.0, 130, null),
                ItemRefeicaoPlano("Vegetais", "1 prato", 10.0, 40, null),
            )),
            RefeicaoPlano("jantar", "Jantar", listOf(
                ItemRefeicaoPlano("Macarrão", "1 prato pequeno", 40.0, 180, null),
                ItemRefeicaoPlano("Molho de tomate caseiro", "2 colheres", 5.0, 30, null),
            )),
        ),
        listaCompras = listOf("Pão", "Ovos", "Frutas", "Arroz", "Proteína magra", "Vegetais", "Macarrão", "Tomate"),
        nutricionista = NUTRI_C,
    ),
)

/** Estado temporário do plano aberto (detalhe). */
object MealPlanHolder {
    var current: PlanoAlimentar? = null
}

@Composable
fun MealPlanCatalogTab(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    var query by remember { mutableStateOf("") }
    var obj by remember { mutableStateOf<String?>(null) }
    var estilo by remember { mutableStateOf<String?>(null) }
    var kcal by remember { mutableStateOf<Int?>(null) }

    val filtered = remember(query, obj, estilo, kcal) {
        CATALOGO_PLANOS.filter { p ->
            val q = query.trim().lowercase()
            val matchQ = q.isBlank() || p.titulo.lowercase().contains(q) ||
                p.resumo.lowercase().contains(q) || p.nutricionista.nome.lowercase().contains(q)
            val matchO = obj == null || obj in p.objetivos
            val matchE = estilo == null || estilo in p.estilos
            val matchK = kcal == null || kotlin.math.abs(p.kcalAlvo - kcal!!) <= 150
            matchQ && matchO && matchE && matchK
        }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            placeholder = { Text("Buscar plano ou nutricionista…", color = g.muted) },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = g.muted) },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
        )
        Text("Objetivo", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChipPlano("Todos", obj == null, g) { obj = null }
            OBJETIVOS_PLANO.forEach { (k, lab) ->
                FilterChipPlano(lab, obj == k, g) { obj = if (obj == k) null else k }
            }
        }
        Text("Estilo", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, top = 4.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChipPlano("Todos", estilo == null, g) { estilo = null }
            ESTILOS_PLANO.forEach { (k, lab) ->
                FilterChipPlano(lab, estilo == k, g) { estilo = if (estilo == k) null else k }
            }
        }
        Text("Calorias", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp, top = 4.dp))
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChipPlano("Todas", kcal == null, g) { kcal = null }
            KCAL_FAIXAS.forEach { (k, lab) ->
                FilterChipPlano(lab, kcal == k, g) { kcal = if (kcal == k) null else k }
            }
        }
        Text(
            "${filtered.size} plano(s) · conteúdo de nutricionistas · ajuste com sua equipe",
            color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(16.dp, 8.dp),
        )
        Column(Modifier.verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            filtered.forEach { plano ->
                PlanoCard(plano, g) {
                    MealPlanHolder.current = plano
                    nav.navigate(Routes.FOOD_MEAL_PLAN_DETAIL)
                }
                Spacer(Modifier.height(10.dp))
            }
            if (filtered.isEmpty()) {
                Text("Nenhum plano com esses filtros. Limpe os filtros ou busque outro termo.", color = g.muted)
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}

@Composable
private fun FilterChipPlano(label: String, selected: Boolean, g: com.agon.app.ui.theme.GlucoColors, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (selected) g.violet else g.card)
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
        Text(label, color = if (selected) Color.White else g.ink, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun PlanoCard(plano: PlanoAlimentar, g: com.agon.app.ui.theme.GlucoColors, onOpen: () -> Unit) {
    GCard(Modifier.clickable(onClick = onOpen)) {
        Text(plano.titulo, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
        Text(plano.resumo, color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
        Text(
            "${plano.kcalAlvo} kcal · C ${plano.nutrientes.carbG.roundToInt()} g · P ${plano.nutrientes.protG.roundToInt()} g · G ${plano.nutrientes.fatG.roundToInt()} g",
            color = g.violetDeep, fontWeight = FontWeight.SemiBold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp),
        )
        Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(40.dp).clip(RoundedCornerShape(20.dp)).background(g.lilacSoft),
                contentAlignment = Alignment.Center,
            ) {
                Text(plano.nutricionista.nome.take(1), color = g.violet, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.padding(start = 10.dp).weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(plano.nutricionista.nome, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    if (plano.nutricionista.verificado) {
                        Icon(Icons.Filled.Verified, null, tint = g.green, modifier = Modifier.padding(start = 4.dp).size(16.dp))
                    }
                }
                Text("${plano.nutricionista.crn} · ${plano.nutricionista.especialidade}", color = g.muted, fontSize = 11.sp)
            }
        }
        Text("Ver plano completo ›", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
fun MealPlanDetailScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    val plano = MealPlanHolder.current
    if (plano == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Plano não encontrado", color = g.muted)
        }
        return
    }
    var msg by remember { mutableStateOf<String?>(null) }
    val n = plano.nutrientes

    Column(Modifier.fillMaxSize().background(g.bg)) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.Filled.Close, null, tint = g.ink)
            }
            Text("Plano alimentar", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        }
        Column(Modifier.verticalScroll(rememberScrollState()).padding(16.dp)) {
            Text(plano.titulo, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            Text(plano.resumo, color = g.muted, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp))
            GCard(Modifier.padding(top = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(48.dp).clip(RoundedCornerShape(24.dp)).background(g.lilacSoft), contentAlignment = Alignment.Center) {
                        Text(plano.nutricionista.nome.take(1), color = g.violet, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Column(Modifier.padding(start = 12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(plano.nutricionista.nome, color = g.ink, fontWeight = FontWeight.Bold)
                            if (plano.nutricionista.verificado) {
                                Icon(Icons.Filled.Verified, null, tint = g.green, modifier = Modifier.padding(start = 4.dp).size(18.dp))
                            }
                        }
                        Text(plano.nutricionista.crn, color = g.muted, fontSize = 12.sp)
                        Text(plano.nutricionista.especialidade, color = g.muted, fontSize = 12.sp)
                    }
                }
                if (plano.nutricionista.bioCurta.isNotBlank()) {
                    Text(plano.nutricionista.bioCurta, color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
                }
            }

            SectionTitle("Visão geral do dia")
            GCard {
                Text("${n.kcal} kcal · Carb ${n.carbG.roundToInt()} g · Prot ${n.protG.roundToInt()} g · Gord ${n.fatG.roundToInt()} g", color = g.ink, fontWeight = FontWeight.SemiBold)
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(88.dp), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            val stroke = size.minDimension * 0.16f
                            val diam = size.minDimension - stroke
                            val topLeft = Offset((size.width - diam) / 2f, (size.height - diam) / 2f)
                            val arcSize = Size(diam, diam)
                            var start = -90f
                            listOf(
                                n.pctCarb to Color(0xFF38BDF8),
                                n.pctFat to Color(0xFFFBBF24),
                                n.pctProt to Color(0xFFF472B6),
                            ).forEach { (pct, col) ->
                                val sweep = 360f * (pct / 100f).coerceIn(0f, 1f)
                                if (sweep > 0.4f) {
                                    drawArc(col, start, sweep, false, topLeft, arcSize, style = Stroke(width = stroke))
                                }
                                start += sweep
                            }
                        }
                        Text("Macros", color = g.muted, fontSize = 10.sp)
                    }
                    Column(Modifier.padding(start = 12.dp)) {
                        Text("Carb ${n.pctCarb.roundToInt()}%", color = g.ink, fontSize = 13.sp)
                        Text("Gord ${n.pctFat.roundToInt()}%", color = g.ink, fontSize = 13.sp)
                        Text("Prot ${n.pctProt.roundToInt()}%", color = g.ink, fontSize = 13.sp)
                    }
                }
            }

            SectionTitle("Cronograma do dia")
            plano.refeicoes.forEach { ref ->
                GCard(Modifier.padding(bottom = 8.dp)) {
                    Text(ref.titulo, color = g.violetDeep, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    Text(
                        "Carb total: ${"%.1f".format(ref.carbTotalG)} g · ${ref.kcalTotal} kcal",
                        color = g.green, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 6.dp),
                    )
                    ref.itens.forEach { item ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(item.nome, color = g.ink, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                                Text("${item.porcao} · C ${item.carbG} g · ${item.kcal} kcal", color = g.muted, fontSize = 12.sp)
                            }
                            if (item.recipeId != null) {
                                Text(
                                    "Receita",
                                    color = g.violet,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.clickable {
                                        val r = LOCAL_RECIPES.find { it.id == item.recipeId }
                                        if (r != null) {
                                            vm.setTempRecipe(r)
                                            nav.navigate(Routes.FOOD_RECIPE_DETAIL)
                                        }
                                    }.padding(6.dp),
                                )
                            }
                        }
                    }
                }
            }

            SectionTitle("Lista de compras")
            GCard {
                plano.listaCompras.forEach { Text("• $it", color = g.ink, fontSize = 14.sp) }
                PrimaryButton("Compartilhar lista", g.violet, {
                    val text = buildString {
                        appendLine("Lista de compras — ${plano.titulo}")
                        appendLine("Nutri: ${plano.nutricionista.nome} (${plano.nutricionista.crn})")
                        appendLine()
                        plano.listaCompras.forEach { appendLine("• $it") }
                    }
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, text)
                    }
                    context.startActivity(Intent.createChooser(send, "Lista de compras"))
                }, Modifier.padding(top = 10.dp))
            }

            Text(plano.avisos, color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 12.dp))
            msg?.let { Text(it, color = g.green, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp)) }
            fun importRefs(filterTipo: String?) {
                val now = System.currentTimeMillis()
                val refs = if (filterTipo == null) plano.refeicoes else plano.refeicoes.filter { it.tipo == filterTipo }
                refs.forEachIndexed { idx, ref ->
                    val type = when (ref.tipo) {
                        "cafe" -> "cafe"
                        "almoco" -> "almoco"
                        "jantar" -> "jantar"
                        else -> "lanche"
                    }
                    val desc = ref.itens.joinToString(" + ") { it.nome }
                    vm.saveMeal(
                        Meal(
                            id = uid(),
                            type = type,
                            description = "[Plano] ${ref.titulo}: $desc",
                            carbs = ref.carbTotalG,
                            at = now + idx * 1000L,
                            notes = "kcal=${ref.kcalTotal};fonte=plano:${plano.id};nutri=${plano.nutricionista.crn}",
                        ),
                    )
                }
                msg = when (filterTipo) {
                    "cafe" -> "Café do plano importado ao diário."
                    "almoco" -> "Almoço do plano importado ao diário."
                    "jantar" -> "Jantar do plano importado ao diário."
                    else -> "Refeições do plano adicionadas ao diário. Confira e ajuste as porções."
                }
            }
            PrimaryButton("Importar para o meu dia (diário)", g.green, { importRefs(null) })
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TextButton(onClick = { importRefs("cafe") }) { Text("Só café", color = g.violet, fontSize = 12.sp) }
                TextButton(onClick = { importRefs("almoco") }) { Text("Só almoço", color = g.violet, fontSize = 12.sp) }
                TextButton(onClick = { importRefs("jantar") }) { Text("Só jantar", color = g.violet, fontSize = 12.sp) }
            }
            PrimaryButton("Bolus com carb do plano (dia)", g.violet, {
                context.getSharedPreferences("gluco_food_tools", android.content.Context.MODE_PRIVATE)
                    .edit().putFloat("last_meal_carbs", plano.nutrientes.carbG.toFloat()).apply()
                nav.navigate(Routes.FOOD_BOLUS)
            }, Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(32.dp))
        }
    }
}
