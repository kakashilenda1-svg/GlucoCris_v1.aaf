package com.agon.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.agon.app.data.MOODS
import com.agon.app.data.moodOf
import com.agon.app.ui.theme.glucoColors

/** Indicação do humor ao lado da saudação (dentro do cartão roxo da tela inicial). */
@Composable
fun MoodButton(moodId: String, onClick: () -> Unit) {
    val mood = moodOf(moodId)
    Row(
        Modifier.padding(top = 8.dp).height(36.dp).clip(RoundedCornerShape(18.dp))
            .background(Color.White.copy(alpha = 0.18f))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (mood != null) {
            Text(mood.emoji, fontSize = 18.sp)
            Text(
                "${mood.label} · trocar",
                color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp,
                modifier = Modifier.padding(start = 6.dp), maxLines = 1,
            )
        } else {
            Text("🙂", fontSize = 16.sp)
            Text(
                "Como você está se sentindo?",
                color = Color.White.copy(alpha = 0.92f), fontWeight = FontWeight.SemiBold, fontSize = 13.sp,
                modifier = Modifier.padding(start = 6.dp), maxLines = 1,
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoodSheet(selected: String, onDismiss: () -> Unit, onPick: (String) -> Unit) {
    val g = glucoColors()
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = g.card,
    ) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).navigationBarsPadding().padding(bottom = 16.dp)) {
            Text("Como você está se sentindo?", color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
            Text("Escolha quando quiser. Dá para trocar a qualquer momento.", color = g.muted, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp, bottom = 12.dp))
            MOODS.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { m ->
                        val on = m.id == selected
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(16.dp))
                                .background(if (on) g.lilacSoft else g.inputBg)
                                .border(2.dp, if (on) g.violet else Color.Transparent, RoundedCornerShape(16.dp))
                                .clickable { onPick(m.id) }
                                .padding(vertical = 12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Box(Modifier.size(48.dp).clip(CircleShape).background(g.card), contentAlignment = Alignment.Center) {
                                Text(m.emoji, fontSize = 28.sp)
                            }
                            Text(
                                m.label, color = if (on) g.violet else g.ink, fontWeight = FontWeight.Bold, fontSize = 12.sp,
                                textAlign = TextAlign.Center, maxLines = 2, modifier = Modifier.padding(top = 6.dp, start = 2.dp, end = 2.dp),
                            )
                        }
                    }
                }
            }
        }
    }
}
