package com.agon.app.ui.screens

import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.graphics.Color
import coil3.compose.AsyncImage
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.RestaurantMenu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GlucoViewModel
import com.agon.app.data.Meal
import com.agon.app.data.uid
import com.agon.app.ui.components.*
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.roundToInt


private const val CRIS_WHATSAPP = "5511970782491"
private const val CRIS_WHATSAPP_DISPLAY = "(11) 97078-2491"

data class MarmitaCris(
    val id: String,
    val name: String,
    val desc: String,
    val carbsNote: String,
    val highlight: String,
)

/** Marmitas orientadas ao dia a dia com diabetes — pedido via WhatsApp Maria Cristina. */
private val MARMITAS_CRIS_DM = listOf(
    MarmitaCris("m1", "Marmita equilíbrio do dia", "Proteína magra, vegetais e porção controlada de carboidrato complexo.", "Porção de carb moderada · ideal almoço", "Mais pedida"),
    MarmitaCris("m2", "Low carb consciente", "Foco em proteína e fibras, com menos amido. Confirme com sua equipe se faz sentido para você.", "Baixo amido · não é dieta prescrita", "Low carb"),
    MarmitaCris("m3", "Executiva leve", "Prato completo para rotina corrida, com legenda de porção e sugestão de horários.", "Prático · monte sua rotina", "Rotina"),
    MarmitaCris("m4", "Jantar sereno", "Refeição noturna mais leve, para quem prefere jantar com menos volume de carb.", "Jantar · porção ajustável", "Noite"),
    MarmitaCris("m5", "Fit fibras", "Vegetais variados e grãos integrais em porção marcada.", "Fibras · saciedade", "Fibras"),
    MarmitaCris("m6", "Proteína em foco", "Ênfase em peixe, frango ou ovo, com acompanhamento de folhas.", "Alto proteína · carb à parte", "Proteína"),
)

fun saveLastMarmita(context: android.content.Context, name: String) {
    context.getSharedPreferences(RECIPE_PREFS, android.content.Context.MODE_PRIVATE)
        .edit().putString("last_marmita", name).apply()
}
fun loadLastMarmita(context: android.content.Context): String? =
    context.getSharedPreferences(RECIPE_PREFS, android.content.Context.MODE_PRIVATE).getString("last_marmita", null)

fun openCrisWhatsApp(context: android.content.Context, marmitaName: String) {
    saveLastMarmita(context, marmitaName)

    val msg = android.net.Uri.encode(
        "Olá Maria Cristina! Vi no Gluco Cris a aba Marmitas Cris DM e quero solicitar: $marmitaName. Pode me passar opções e valores?",
    )
    val uri = android.net.Uri.parse("https://wa.me/$CRIS_WHATSAPP?text=$msg")
    try {
        context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, uri))
    } catch (_: Exception) {
        try {
            context.startActivity(
                android.content.Intent(
                    android.content.Intent.ACTION_VIEW,
                    android.net.Uri.parse("https://api.whatsapp.com/send?phone=$CRIS_WHATSAPP&text=$msg"),
                ),
            )
        } catch (_: Exception) { }
    }
}


data class RecipeItem(
    val id: String,
    val name: String,
    val category: String = "",
    val area: String = "",
    val thumb: String = "",
    val ingredients: List<String> = emptyList(),
    val instructions: String = "",
    val source: String = "",
    val carbsEstimate: Double? = null,
    val kcalEstimate: Double? = null,
    val proteinEstimate: Double? = null,
    val fatEstimate: Double? = null,
    val servings: String = "1 porção",
    val tags: List<String> = emptyList(), // cafe, almoco, jantar, lanche, lowcarb, doce, vegetariano, rapido
)

private const val RECIPE_PREFS = "gluco_recipe_prefs"
private const val KEY_FAV_RECIPES = "fav_recipe_ids"
private const val KEY_CACHED_RECIPES = "cached_recipes_json"

private fun loadRecipeUserThumb(ctx: Context, id: String): String? =
    ctx.getSharedPreferences(RECIPE_PREFS, Context.MODE_PRIVATE).getString("thumb_$id", null)
private fun saveRecipeUserThumb(ctx: Context, id: String, uri: String?) {
    val ed = ctx.getSharedPreferences(RECIPE_PREFS, Context.MODE_PRIVATE).edit()
    if (uri.isNullOrBlank()) ed.remove("thumb_$id") else ed.putString("thumb_$id", uri)
    ed.apply()
}

private fun loadFavRecipeIds(ctx: Context): Set<String> =
    ctx.getSharedPreferences(RECIPE_PREFS, Context.MODE_PRIVATE).getStringSet(KEY_FAV_RECIPES, emptySet()) ?: emptySet()

private fun saveFavRecipeIds(ctx: Context, ids: Set<String>) {
    ctx.getSharedPreferences(RECIPE_PREFS, Context.MODE_PRIVATE).edit().putStringSet(KEY_FAV_RECIPES, ids).apply()
}

private fun cacheRecipe(ctx: Context, r: RecipeItem) {
    try {
        val prefs = ctx.getSharedPreferences(RECIPE_PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY_CACHED_RECIPES, "[]") ?: "[]")
        val filtered = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") != r.id) filtered.put(o)
        }
        filtered.put(
            JSONObject()
                .put("id", r.id)
                .put("name", r.name)
                .put("category", r.category)
                .put("area", r.area)
                .put("instructions", r.instructions)
                .put("source", r.source)
                .put("servings", r.servings)
                .put("carbs", r.carbsEstimate ?: -1.0)
                .put("kcal", r.kcalEstimate ?: -1.0)
                .put("ingredients", JSONArray(r.ingredients))
                .put("tags", JSONArray(r.tags)),
        )
        // max 40
        val out = JSONArray()
        val start = (filtered.length() - 40).coerceAtLeast(0)
        for (i in start until filtered.length()) out.put(filtered.getJSONObject(i))
        prefs.edit().putString(KEY_CACHED_RECIPES, out.toString()).apply()
    } catch (_: Exception) {}
}

private fun loadCachedRecipes(ctx: Context): List<RecipeItem> {
    return try {
        val raw = ctx.getSharedPreferences(RECIPE_PREFS, Context.MODE_PRIVATE).getString(KEY_CACHED_RECIPES, "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val ings = o.optJSONArray("ingredients")
            val tags = o.optJSONArray("tags")
            RecipeItem(
                id = o.optString("id"),
                name = o.optString("name"),
                category = o.optString("category"),
                area = o.optString("area"),
                ingredients = if (ings != null) (0 until ings.length()).map { ings.getString(it) } else emptyList(),
                instructions = o.optString("instructions"),
                source = o.optString("source", "Cache"),
                carbsEstimate = o.optDouble("carbs", -1.0).takeIf { it >= 0 },
                kcalEstimate = o.optDouble("kcal", -1.0).takeIf { it >= 0 },
                servings = o.optString("servings", "1 porção"),
                tags = if (tags != null) (0 until tags.length()).map { tags.getString(it) } else emptyList(),
            ).takeIf { it.id.isNotBlank() && it.name.isNotBlank() }
        }
    } catch (_: Exception) {
        emptyList()
    }
}

/** Coleção BR ampliada — carb estimado por porção típica (referência, não laboratório). */
val LOCAL_RECIPES: List<RecipeItem> = listOf(
    // Café
    RecipeItem("br-cuscuz", "Cuscuz nordestino", "Café da manhã", "Brasil", ingredients = listOf("Flocão de milho", "Água", "Sal"), instructions = "Hidrate o flocão e cozinhe no cuscuzeiro.", source = "Coleção BR", carbsEstimate = 35.0, kcalEstimate = 160.0, tags = listOf("cafe", "rapido")),
    RecipeItem("br-tapioca", "Tapioca com queijo", "Café da manhã", "Brasil", ingredients = listOf("Goma de tapioca", "Queijo minas"), instructions = "Aqueça a goma, recheie com queijo e dobre.", source = "Coleção BR", carbsEstimate = 28.0, kcalEstimate = 180.0, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br-omelete", "Omelete simples", "Café da manhã", "Brasil", ingredients = listOf("Ovos", "Sal", "Óleo"), instructions = "Bata os ovos e frite em frigideira antiaderente.", source = "Coleção BR", carbsEstimate = 2.0, kcalEstimate = 180.0, tags = listOf("cafe", "lowcarb", "rapido", "vegetariano")),
    RecipeItem("br-ovo-mexido-tomate", "Ovo mexido com tomate", "Café da manhã", "Brasil", ingredients = listOf("Ovos", "Tomate", "Cebola"), instructions = "Refogue tomate e cebola, acrescente os ovos.", source = "Coleção BR", carbsEstimate = 4.0, kcalEstimate = 200.0, tags = listOf("cafe", "lowcarb", "rapido")),
    RecipeItem("br-vitamina-banana", "Vitamina de banana", "Bebida", "Brasil", ingredients = listOf("Banana", "Leite"), instructions = "Bata no liquidificador.", source = "Coleção BR", carbsEstimate = 35.0, kcalEstimate = 200.0, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br-pao-ovo", "Pão francês com ovo", "Café da manhã", "Brasil", ingredients = listOf("Pão francês", "Ovo", "Óleo"), instructions = "Frite o ovo e sirva no pão.", source = "Coleção BR", carbsEstimate = 32.0, kcalEstimate = 280.0, tags = listOf("cafe", "rapido")),
    RecipeItem("br-aveia-leite", "Mingau de aveia", "Café da manhã", "Brasil", ingredients = listOf("Aveia", "Leite", "Canela"), instructions = "Cozinhe a aveia no leite até engrossar.", source = "Coleção BR", carbsEstimate = 30.0, kcalEstimate = 220.0, tags = listOf("cafe", "vegetariano")),
    // Almoço / jantar
    RecipeItem("br-arroz-feijao", "Arroz e feijão (PF)", "Prato principal", "Brasil", ingredients = listOf("Arroz", "Feijão carioca"), instructions = "Sirva arroz com uma concha de feijão.", source = "Coleção BR", carbsEstimate = 50.0, kcalEstimate = 280.0, tags = listOf("almoco", "jantar", "vegetariano")),
    RecipeItem("br-frango-grelhado-arroz", "Frango grelhado com arroz e salada", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Arroz", "Alface", "Tomate"), instructions = "Grelhe o frango; sirva com arroz e salada.", source = "Coleção BR", carbsEstimate = 40.0, kcalEstimate = 380.0, tags = listOf("almoco", "jantar")),
    RecipeItem("br-strogonoff", "Estrogonofe de frango", "Prato principal", "Brasil", ingredients = listOf("Frango", "Creme de leite", "Molho", "Arroz", "Batata palha"), instructions = "Refogue o frango, adicione creme e molho; sirva com arroz.", source = "Coleção BR", carbsEstimate = 40.0, kcalEstimate = 450.0, tags = listOf("almoco", "jantar")),
    RecipeItem("br-feijoada", "Feijoada", "Prato principal", "Brasil", ingredients = listOf("Feijão preto", "Carnes", "Arroz", "Couve"), instructions = "Cozinhe feijão com carnes; sirva com arroz e couve.", source = "Coleção BR", carbsEstimate = 45.0, kcalEstimate = 420.0, tags = listOf("almoco", "jantar")),
    RecipeItem("br-moqueca", "Moqueca de peixe", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Leite de coco", "Dendê", "Tomate", "Pimentão"), instructions = "Cozinhe o peixe no molho de tomate e leite de coco.", source = "Coleção BR", carbsEstimate = 12.0, kcalEstimate = 280.0, tags = listOf("almoco", "jantar", "lowcarb")),
    RecipeItem("br-baião", "Baião de dois", "Prato principal", "Brasil", ingredients = listOf("Arroz", "Feijão de corda", "Queijo coalho"), instructions = "Misture arroz e feijão com queijo.", source = "Coleção BR", carbsEstimate = 55.0, kcalEstimate = 380.0, tags = listOf("almoco", "jantar")),
    RecipeItem("br-carne-refogada-legumes", "Carne refogada com legumes", "Prato principal", "Brasil", ingredients = listOf("Carne bovina", "Cenoura", "Abobrinha", "Cebola"), instructions = "Refogue a carne e acrescente os legumes.", source = "Coleção BR", carbsEstimate = 10.0, kcalEstimate = 320.0, tags = listOf("almoco", "jantar", "lowcarb")),
    RecipeItem("br-peixe-grelhado-salada", "Peixe grelhado com salada", "Prato principal", "Brasil", ingredients = listOf("Filé de peixe", "Alface", "Tomate", "Azeite"), instructions = "Grelhe o peixe e monte a salada.", source = "Coleção BR", carbsEstimate = 6.0, kcalEstimate = 250.0, tags = listOf("almoco", "jantar", "lowcarb", "rapido")),
    RecipeItem("br-macarrao-molho", "Macarrão ao molho de tomate", "Prato principal", "Brasil", ingredients = listOf("Macarrão", "Molho de tomate"), instructions = "Cozinhe o macarrão e misture ao molho.", source = "Coleção BR", carbsEstimate = 55.0, kcalEstimate = 320.0, tags = listOf("almoco", "jantar", "vegetariano")),
    RecipeItem("br-risoto-fraco", "Risoto de frango simples", "Prato principal", "Brasil", ingredients = listOf("Arroz arbóreo ou agulhinha", "Frango", "Caldo"), instructions = "Refogue e cozinhe o arroz adicionando caldo aos poucos.", source = "Coleção BR", carbsEstimate = 48.0, kcalEstimate = 400.0, tags = listOf("almoco", "jantar")),
    RecipeItem("br-lentilha-completa", "Lentilha com legumes", "Prato principal", "Brasil", ingredients = listOf("Lentilha", "Cenoura", "Cebola", "Alho"), instructions = "Cozinhe a lentilha com os legumes.", source = "Coleção BR", carbsEstimate = 30.0, kcalEstimate = 220.0, tags = listOf("almoco", "jantar", "vegetariano")),
    // Sopas / acompanhamentos
    RecipeItem("br-canja", "Canja de galinha", "Sopa", "Brasil", ingredients = listOf("Frango", "Arroz", "Cenoura", "Batata"), instructions = "Cozinhe tudo até amaciar.", source = "Coleção BR", carbsEstimate = 30.0, kcalEstimate = 250.0, tags = listOf("almoco", "jantar")),
    RecipeItem("br-sopa-legumes", "Sopa de legumes", "Sopa", "Brasil", ingredients = listOf("Cenoura", "Batata", "Abóbora", "Cebola"), instructions = "Cozinhe e amasse parcialmente.", source = "Coleção BR", carbsEstimate = 22.0, kcalEstimate = 150.0, tags = listOf("almoco", "jantar", "vegetariano")),
    RecipeItem("br-pure", "Purê de batata", "Acompanhamento", "Brasil", ingredients = listOf("Batata", "Leite", "Manteiga"), instructions = "Cozinhe e amasse com leite.", source = "Coleção BR", carbsEstimate = 25.0, kcalEstimate = 180.0, tags = listOf("almoco", "jantar", "vegetariano")),
    RecipeItem("br-salada-frango", "Salada de frango grelhado", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Alface", "Tomate", "Pepino", "Azeite"), instructions = "Grelhe o frango e monte a salada.", source = "Coleção BR", carbsEstimate = 8.0, kcalEstimate = 220.0, tags = listOf("almoco", "jantar", "lowcarb", "rapido")),
    RecipeItem("br-salada-completa", "Salada completa com grão-de-bico", "Prato principal", "Brasil", ingredients = listOf("Grão-de-bico", "Tomate", "Pepino", "Cebola roxa", "Azeite"), instructions = "Misture os ingredientes e tempere.", source = "Coleção BR", carbsEstimate = 25.0, kcalEstimate = 280.0, tags = listOf("almoco", "jantar", "vegetariano")),
    // Lanches
    RecipeItem("br-iogurte-fruta", "Iogurte natural com fruta", "Lanche", "Brasil", ingredients = listOf("Iogurte natural", "Morango ou banana"), instructions = "Sirva o iogurte com a fruta picada.", source = "Coleção BR", carbsEstimate = 18.0, kcalEstimate = 150.0, tags = listOf("lanche", "rapido", "vegetariano")),
    RecipeItem("br-wrap-frango", "Wrap de frango e salada", "Lanche", "Brasil", ingredients = listOf("Tortilha", "Frango desfiado", "Alface", "Tomate"), instructions = "Recheie a tortilha e enrole.", source = "Coleção BR", carbsEstimate = 28.0, kcalEstimate = 300.0, tags = listOf("lanche", "almoco", "rapido")),
    RecipeItem("br-sanduiche-queijo", "Sanduíche de queijo e tomate", "Lanche", "Brasil", ingredients = listOf("Pão de forma", "Queijo", "Tomate"), instructions = "Monte o sanduíche; pode tostar.", source = "Coleção BR", carbsEstimate = 28.0, kcalEstimate = 250.0, tags = listOf("lanche", "cafe", "rapido", "vegetariano")),
    // Doces (com carb)
    RecipeItem("br-gelatina", "Gelatina", "Doce", "Brasil", ingredients = listOf("Gelatina em pó", "Água"), instructions = "Prepare conforme a embalagem e leve à geladeira.", source = "Coleção BR", carbsEstimate = 15.0, kcalEstimate = 60.0, tags = listOf("doce", "lanche", "rapido")),
    RecipeItem("br-bolo-simples", "Bolo simples de fatia", "Doce", "Brasil", ingredients = listOf("Farinha", "Açúcar", "Ovos", "Leite", "Fermento"), instructions = "Misture, asse e sirva 1 fatia média.", source = "Coleção BR", carbsEstimate = 35.0, kcalEstimate = 220.0, tags = listOf("doce", "lanche")),
    RecipeItem("br-banana-canela", "Banana assada com canela", "Doce", "Brasil", ingredients = listOf("Banana", "Canela"), instructions = "Asse a banana com canela até amaciar.", source = "Coleção BR", carbsEstimate = 27.0, kcalEstimate = 110.0, tags = listOf("doce", "lanche", "rapido", "vegetariano")),
    // Rápidas / low carb extras
    RecipeItem("br-abobrinha-refogada", "Abobrinha refogada com ovo", "Prato principal", "Brasil", ingredients = listOf("Abobrinha", "Ovo", "Alho"), instructions = "Refogue a abobrinha e acrescente ovo.", source = "Coleção BR", carbsEstimate = 6.0, kcalEstimate = 180.0, tags = listOf("almoco", "jantar", "lowcarb", "rapido", "vegetariano")),
    RecipeItem("br-sardinha-salada", "Sardinha com salada", "Prato principal", "Brasil", ingredients = listOf("Sardinha em lata (escorrida)", "Alface", "Tomate"), instructions = "Escorra a sardinha e sirva com salada.", source = "Coleção BR", carbsEstimate = 5.0, kcalEstimate = 220.0, tags = listOf("almoco", "jantar", "lowcarb", "rapido")),
) + EXTRA_LOCAL_RECIPES


private val EXTRA_LOCAL_RECIPES: List<RecipeItem> = listOf(
    RecipeItem("br2-cuscuz-ovo", "Cuscuz com ovo", "Café da manhã", "Brasil", ingredients = listOf("Flocão", "Ovo", "Sal"), instructions = """1. Hidrate o flocão
2. Cozinhe no cuscuzeiro
3. Frite o ovo e sirva""", source = "Coleção BR+", carbsEstimate = 32, kcalEstimate = 250, proteinEstimate = 12, fatEstimate = 10, tags = listOf("cafe", "rapido")),
    RecipeItem("br2-tapioca-frango", "Tapioca de frango", "Café da manhã", "Brasil", ingredients = listOf("Goma", "Frango desfiado", "Requeijão light"), instructions = """1. Aqueça a goma
2. Recheie e dobre""", source = "Coleção BR+", carbsEstimate = 30, kcalEstimate = 280, proteinEstimate = 18, fatEstimate = 8, tags = listOf("cafe", "lanche")),
    RecipeItem("br2-pao-integral-ovo", "Pão integral com ovo", "Café da manhã", "Brasil", ingredients = listOf("Pão integral", "Ovo"), instructions = """1. Torre o pão
2. Frite o ovo""", source = "Coleção BR+", carbsEstimate = 22, kcalEstimate = 220, proteinEstimate = 12, fatEstimate = 9, tags = listOf("cafe", "rapido")),
    RecipeItem("br2-mingau-aveia-maca", "Mingau de aveia com maçã", "Café da manhã", "Brasil", ingredients = listOf("Aveia", "Leite", "Maçã", "Canela"), instructions = """1. Cozinhe aveia no leite
2. Acrecente maçã ralada""", source = "Coleção BR+", carbsEstimate = 40, kcalEstimate = 260, proteinEstimate = 10, fatEstimate = 6, tags = listOf("cafe", "vegetariano")),
    RecipeItem("br2-wrap-ovo", "Wrap de ovo e folhas", "Café da manhã", "Brasil", ingredients = listOf("Tortilha", "Ovo", "Alface"), instructions = """1. Frite o ovo
2. Enrole no wrap""", source = "Coleção BR+", carbsEstimate = 28, kcalEstimate = 300, proteinEstimate = 14, fatEstimate = 12, tags = listOf("cafe", "rapido")),
    RecipeItem("br2-smoothie-verde", "Smoothie verde", "Bebida", "Brasil", ingredients = listOf("Espinafre", "Banana", "Iogurte"), instructions = """1. Bata tudo no liquidificador""", source = "Coleção BR+", carbsEstimate = 28, kcalEstimate = 180, proteinEstimate = 8, fatEstimate = 3, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-cafe-queijo", "Café da manhã com queijo minas", "Café da manhã", "Brasil", ingredients = listOf("Pão", "Queijo minas", "Café"), instructions = """1. Monte o lanche
2. Sirva o café""", source = "Coleção BR+", carbsEstimate = 30, kcalEstimate = 240, proteinEstimate = 12, fatEstimate = 8, tags = listOf("cafe", "rapido")),
    RecipeItem("br2-ovos-mexidos-espinafre", "Ovos mexidos com espinafre", "Café da manhã", "Brasil", ingredients = listOf("Ovos", "Espinafre", "Azeite"), instructions = """1. Refogue espinafre
2. Junte ovos""", source = "Coleção BR+", carbsEstimate = 3, kcalEstimate = 210, proteinEstimate = 16, fatEstimate = 15, tags = listOf("cafe", "lowcarb", "rapido")),
    RecipeItem("br2-pf-frango", "PF frango grelhado", "Prato principal", "Brasil", ingredients = listOf("Arroz", "Feijão", "Frango", "Salada"), instructions = """1. Grelhe o frango
2. Sirva com arroz, feijão e salada""", source = "Coleção BR+", carbsEstimate = 55, kcalEstimate = 450, proteinEstimate = 35, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-strogonoff-light", "Strogonoff light de frango", "Prato principal", "Brasil", ingredients = listOf("Frango", "Iogurte", "Extrato de tomate", "Arroz"), instructions = """1. Refogue o frango
2. Adicione molho
3. Sirva com arroz""", source = "Coleção BR+", carbsEstimate = 45, kcalEstimate = 420, proteinEstimate = 32, fatEstimate = 14, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-carne-molho", "Carne magra ao molho", "Prato principal", "Brasil", ingredients = listOf("Patinho", "Cebola", "Tomate"), instructions = """1. Sele a carne
2. Cozinhe no molho""", source = "Coleção BR+", carbsEstimate = 8, kcalEstimate = 320, proteinEstimate = 40, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-peixe-assado", "Peixe assado com legumes", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Abobrinha", "Cenoura", "Azeite"), instructions = """1. Tempere o peixe
2. Asse com legumes""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 300, proteinEstimate = 35, fatEstimate = 10, tags = listOf("almoco", "jantar", "lowcarb")),
    RecipeItem("br2-feijoada-leve", "Feijoada leve (porção controlada)", "Prato principal", "Brasil", ingredients = listOf("Feijão preto", "Carne magra", "Arroz", "Couve"), instructions = """1. Cozinhe o feijão com carnes magras
2. Sirva porção moderada com arroz e couve""", source = "Coleção BR+", carbsEstimate = 50, kcalEstimate = 480, proteinEstimate = 30, fatEstimate = 16, tags = listOf("almoco")),
    RecipeItem("br2-macarrao-integral", "Macarrão integral ao sugo", "Prato principal", "Brasil", ingredients = listOf("Macarrão integral", "Molho de tomate", "Manjericão"), instructions = """1. Cozinhe o macarrão
2. Misture o molho""", source = "Coleção BR+", carbsEstimate = 55, kcalEstimate = 380, proteinEstimate = 14, fatEstimate = 8, tags = listOf("almoco", "jantar", "vegetariano")),
    RecipeItem("br2-omelete-forno", "Omelete de forno", "Prato principal", "Brasil", ingredients = listOf("Ovos", "Queijo", "Legumes"), instructions = """1. Misture
2. Asse até firmar""", source = "Coleção BR+", carbsEstimate = 6, kcalEstimate = 280, proteinEstimate = 22, fatEstimate = 18, tags = listOf("almoco", "lowcarb", "vegetariano")),
    RecipeItem("br2-salada-completa", "Salada completa com grão-de-bico", "Prato principal", "Brasil", ingredients = listOf("Grão-de-bico", "Alface", "Tomate", "Azeite"), instructions = """1. Misture os ingredientes
2. Tempere""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 320, proteinEstimate = 15, fatEstimate = 12, tags = listOf("almoco", "vegetariano")),
    RecipeItem("br2-risoto-abobrinha", "Risoto de abobrinha", "Prato principal", "Brasil", ingredients = listOf("Arroz arbóreo", "Abobrinha", "Caldo"), instructions = """1. Refogue
2. Adicione caldo aos poucos""", source = "Coleção BR+", carbsEstimate = 48, kcalEstimate = 400, proteinEstimate = 10, fatEstimate = 10, tags = listOf("almoco", "jantar", "vegetariano")),
    RecipeItem("br2-yakisoba-caseiro", "Yakisoba caseiro light", "Prato principal", "Brasil", ingredients = listOf("Macarrão", "Legumes", "Frango"), instructions = """1. Refogue legumes e frango
2. Misture o macarrão""", source = "Coleção BR+", carbsEstimate = 50, kcalEstimate = 430, proteinEstimate = 28, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-iogurte-chia", "Iogurte com chia", "Lanche", "Brasil", ingredients = listOf("Iogurte", "Chia", "Morango"), instructions = """1. Misture e deixe hidratar 10 min""", source = "Coleção BR+", carbsEstimate = 15, kcalEstimate = 150, proteinEstimate = 10, fatEstimate = 5, tags = listOf("lanche", "rapido", "vegetariano")),
    RecipeItem("br2-mix-castanhas", "Mix de castanhas (porção)", "Lanche", "Brasil", ingredients = listOf("Castanhas variadas"), instructions = """1. Separe 1 colher de sopa""", source = "Coleção BR+", carbsEstimate = 5, kcalEstimate = 120, proteinEstimate = 4, fatEstimate = 10, tags = listOf("lanche", "lowcarb", "rapido")),
    RecipeItem("br2-banana-aveia", "Banana com aveia", "Lanche", "Brasil", ingredients = listOf("Banana", "Aveia"), instructions = """1. Pique a banana
2. Polvilhe aveia""", source = "Coleção BR+", carbsEstimate = 30, kcalEstimate = 180, proteinEstimate = 4, fatEstimate = 2, tags = listOf("lanche", "rapido")),
    RecipeItem("br2-cottage-tomate", "Cottage com tomate", "Lanche", "Brasil", ingredients = listOf("Cottage", "Tomate"), instructions = """1. Sirva frio""", source = "Coleção BR+", carbsEstimate = 4, kcalEstimate = 100, proteinEstimate = 14, fatEstimate = 3, tags = listOf("lanche", "lowcarb", "rapido")),
    RecipeItem("br2-vitamina-mamao", "Vitamina de mamão", "Bebida", "Brasil", ingredients = listOf("Mamão", "Leite"), instructions = """1. Bata no liquidificador""", source = "Coleção BR+", carbsEstimate = 25, kcalEstimate = 160, proteinEstimate = 6, fatEstimate = 3, tags = listOf("lanche", "cafe", "rapido")),
    RecipeItem("br2-pao-queijo-forno", "Pão de queijo assado (2 un.)", "Lanche", "Brasil", ingredients = listOf("Polvilho", "Queijo", "Ovo", "Leite"), instructions = """1. Misture a massa
2. Asse até dourar""", source = "Coleção BR+", carbsEstimate = 20, kcalEstimate = 180, proteinEstimate = 8, fatEstimate = 8, tags = listOf("lanche", "cafe")),
    RecipeItem("br2-sopa-legumes", "Sopa de legumes", "Jantar", "Brasil", ingredients = listOf("Legumes", "Caldo"), instructions = """1. Cozinhe até amolecer
2. Amasse levemente""", source = "Coleção BR+", carbsEstimate = 25, kcalEstimate = 180, proteinEstimate = 6, fatEstimate = 4, tags = listOf("jantar", "vegetariano")),
    RecipeItem("br2-frango-ervas", "Frango com ervas", "Jantar", "Brasil", ingredients = listOf("Frango", "Ervas", "Azeite"), instructions = """1. Tempere
2. Grelhe ou asse""", source = "Coleção BR+", carbsEstimate = 2, kcalEstimate = 220, proteinEstimate = 35, fatEstimate = 8, tags = listOf("jantar", "lowcarb")),
    RecipeItem("br2-omelete-jantar", "Omelete recheada jantar", "Jantar", "Brasil", ingredients = listOf("Ovos", "Queijo", "Tomate"), instructions = """1. Bata os ovos
2. Recheie na frigideira""", source = "Coleção BR+", carbsEstimate = 5, kcalEstimate = 250, proteinEstimate = 20, fatEstimate = 16, tags = listOf("jantar", "rapido", "lowcarb")),
    RecipeItem("br2-salmao-padrao", "Salmão grelhado", "Jantar", "Brasil", ingredients = listOf("Salmão", "Limão", "Aspargos"), instructions = """1. Grelhe o peixe
2. Sirva com aspargos""", source = "Coleção BR+", carbsEstimate = 3, kcalEstimate = 350, proteinEstimate = 30, fatEstimate = 22, tags = listOf("jantar", "lowcarb")),
    RecipeItem("br2-wrap-frango-jantar", "Wrap de frango no jantar", "Jantar", "Brasil", ingredients = listOf("Tortilha", "Frango", "Salada"), instructions = """1. Monte o wrap""", source = "Coleção BR+", carbsEstimate = 30, kcalEstimate = 340, proteinEstimate = 25, fatEstimate = 10, tags = listOf("jantar")),
    RecipeItem("br2-bolo-banana-aveia", "Bolo de banana com aveia", "Sobremesa", "Brasil", ingredients = listOf("Banana", "Aveia", "Ovo"), instructions = """1. Amasse bananas
2. Misture
3. Asse 30–40 min""", source = "Coleção BR+", carbsEstimate = 40, kcalEstimate = 220, proteinEstimate = 6, fatEstimate = 6, tags = listOf("doce", "cafe")),
    RecipeItem("br2-muffin-cenoura", "Muffin de cenoura", "Sobremesa", "Brasil", ingredients = listOf("Cenoura", "Farinha de aveia", "Ovo"), instructions = """1. Rale a cenoura
2. Misture
3. Asse em forminhas""", source = "Coleção BR+", carbsEstimate = 28, kcalEstimate = 180, proteinEstimate = 5, fatEstimate = 5, tags = listOf("doce")),
    RecipeItem("br2-mousse-chocolate-light", "Mousse de chocolate light", "Sobremesa", "Brasil", ingredients = listOf("Cacau", "Clara", "Adoçante culinário"), instructions = """1. Bata as claras
2. Incorpore cacau""", source = "Coleção BR+", carbsEstimate = 8, kcalEstimate = 120, proteinEstimate = 6, fatEstimate = 4, tags = listOf("doce")),
    RecipeItem("br2-geleia-chia", "Geleia de chia com frutas", "Sobremesa", "Brasil", ingredients = listOf("Chia", "Morango", "Adoçante"), instructions = """1. Misture e leve à geladeira""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 90, proteinEstimate = 2, fatEstimate = 3, tags = listOf("doce", "rapido")),
    RecipeItem("br2-auto-1", "Frango grelhado com arroz", "Prato principal", "Brasil", ingredients = listOf("Frango", "Arroz", "Temperos"), instructions = """1. Prepare o frango grelhado
2. Cozinhe o acompanhamento (arroz)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 340, proteinEstimate = 28, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-2", "Frango assado com arroz", "Prato principal", "Brasil", ingredients = listOf("Frango", "Arroz", "Temperos"), instructions = """1. Prepare o frango assado
2. Cozinhe o acompanhamento (arroz)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 360, proteinEstimate = 28, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-3", "Frango grelhado com arroz integral", "Prato principal", "Brasil", ingredients = listOf("Frango", "Arroz integral", "Temperos"), instructions = """1. Prepare o frango grelhado
2. Cozinhe o acompanhamento (arroz integral)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 380, proteinEstimate = 28, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-4", "Frango assado com arroz integral", "Prato principal", "Brasil", ingredients = listOf("Frango", "Arroz integral", "Temperos"), instructions = """1. Prepare o frango assado
2. Cozinhe o acompanhamento (arroz integral)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 400, proteinEstimate = 28, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-5", "Frango grelhado com batata-doce", "Prato principal", "Brasil", ingredients = listOf("Frango", "Batata-doce", "Temperos"), instructions = """1. Prepare o frango grelhado
2. Cozinhe o acompanhamento (batata-doce)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 320, proteinEstimate = 28, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-6", "Frango assado com batata-doce", "Prato principal", "Brasil", ingredients = listOf("Frango", "Batata-doce", "Temperos"), instructions = """1. Prepare o frango assado
2. Cozinhe o acompanhamento (batata-doce)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 340, proteinEstimate = 28, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-7", "Frango grelhado com quinoa", "Prato principal", "Brasil", ingredients = listOf("Frango", "Quinoa", "Temperos"), instructions = """1. Prepare o frango grelhado
2. Cozinhe o acompanhamento (quinoa)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 360, proteinEstimate = 28, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-8", "Frango assado com quinoa", "Prato principal", "Brasil", ingredients = listOf("Frango", "Quinoa", "Temperos"), instructions = """1. Prepare o frango assado
2. Cozinhe o acompanhamento (quinoa)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 380, proteinEstimate = 28, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-9", "Frango grelhado com salada", "Prato principal", "Brasil", ingredients = listOf("Frango", "Salada", "Temperos"), instructions = """1. Prepare o frango grelhado
2. Cozinhe o acompanhamento (salada)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 400, proteinEstimate = 28, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-10", "Frango assado com salada", "Prato principal", "Brasil", ingredients = listOf("Frango", "Salada", "Temperos"), instructions = """1. Prepare o frango assado
2. Cozinhe o acompanhamento (salada)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 320, proteinEstimate = 28, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-11", "Frango grelhado com legumes no vapor", "Prato principal", "Brasil", ingredients = listOf("Frango", "Legumes no vapor", "Temperos"), instructions = """1. Prepare o frango grelhado
2. Cozinhe o acompanhamento (legumes no vapor)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 340, proteinEstimate = 28, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-12", "Frango assado com legumes no vapor", "Prato principal", "Brasil", ingredients = listOf("Frango", "Legumes no vapor", "Temperos"), instructions = """1. Prepare o frango assado
2. Cozinhe o acompanhamento (legumes no vapor)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 360, proteinEstimate = 28, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-13", "Peito de frango grelhado com arroz", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Arroz", "Temperos"), instructions = """1. Prepare o peito de frango grelhado
2. Cozinhe o acompanhamento (arroz)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 380, proteinEstimate = 28, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-14", "Peito de frango assado com arroz", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Arroz", "Temperos"), instructions = """1. Prepare o peito de frango assado
2. Cozinhe o acompanhamento (arroz)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 400, proteinEstimate = 28, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-15", "Peito de frango grelhado com arroz integral", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Arroz integral", "Temperos"), instructions = """1. Prepare o peito de frango grelhado
2. Cozinhe o acompanhamento (arroz integral)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 320, proteinEstimate = 28, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-16", "Peito de frango assado com arroz integral", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Arroz integral", "Temperos"), instructions = """1. Prepare o peito de frango assado
2. Cozinhe o acompanhamento (arroz integral)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 340, proteinEstimate = 28, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-17", "Peito de frango grelhado com batata-doce", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Batata-doce", "Temperos"), instructions = """1. Prepare o peito de frango grelhado
2. Cozinhe o acompanhamento (batata-doce)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 360, proteinEstimate = 28, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-18", "Peito de frango assado com batata-doce", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Batata-doce", "Temperos"), instructions = """1. Prepare o peito de frango assado
2. Cozinhe o acompanhamento (batata-doce)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 380, proteinEstimate = 28, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-19", "Peito de frango grelhado com quinoa", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Quinoa", "Temperos"), instructions = """1. Prepare o peito de frango grelhado
2. Cozinhe o acompanhamento (quinoa)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 400, proteinEstimate = 28, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-20", "Peito de frango assado com quinoa", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Quinoa", "Temperos"), instructions = """1. Prepare o peito de frango assado
2. Cozinhe o acompanhamento (quinoa)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 320, proteinEstimate = 28, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-21", "Peito de frango grelhado com salada", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Salada", "Temperos"), instructions = """1. Prepare o peito de frango grelhado
2. Cozinhe o acompanhamento (salada)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 340, proteinEstimate = 28, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-22", "Peito de frango assado com salada", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Salada", "Temperos"), instructions = """1. Prepare o peito de frango assado
2. Cozinhe o acompanhamento (salada)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 360, proteinEstimate = 28, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-23", "Peito de frango grelhado com legumes no vapor", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Legumes no vapor", "Temperos"), instructions = """1. Prepare o peito de frango grelhado
2. Cozinhe o acompanhamento (legumes no vapor)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 380, proteinEstimate = 28, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-24", "Peito de frango assado com legumes no vapor", "Prato principal", "Brasil", ingredients = listOf("Peito de frango", "Legumes no vapor", "Temperos"), instructions = """1. Prepare o peito de frango assado
2. Cozinhe o acompanhamento (legumes no vapor)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 400, proteinEstimate = 28, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-25", "Carne magra grelhado com arroz", "Prato principal", "Brasil", ingredients = listOf("Carne magra", "Arroz", "Temperos"), instructions = """1. Prepare o carne magra grelhado
2. Cozinhe o acompanhamento (arroz)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 320, proteinEstimate = 28, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-26", "Carne magra assado com arroz", "Prato principal", "Brasil", ingredients = listOf("Carne magra", "Arroz", "Temperos"), instructions = """1. Prepare o carne magra assado
2. Cozinhe o acompanhamento (arroz)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 340, proteinEstimate = 28, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-27", "Carne magra grelhado com arroz integral", "Prato principal", "Brasil", ingredients = listOf("Carne magra", "Arroz integral", "Temperos"), instructions = """1. Prepare o carne magra grelhado
2. Cozinhe o acompanhamento (arroz integral)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 360, proteinEstimate = 28, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-28", "Carne magra assado com arroz integral", "Prato principal", "Brasil", ingredients = listOf("Carne magra", "Arroz integral", "Temperos"), instructions = """1. Prepare o carne magra assado
2. Cozinhe o acompanhamento (arroz integral)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 380, proteinEstimate = 28, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-29", "Carne magra grelhado com batata-doce", "Prato principal", "Brasil", ingredients = listOf("Carne magra", "Batata-doce", "Temperos"), instructions = """1. Prepare o carne magra grelhado
2. Cozinhe o acompanhamento (batata-doce)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 400, proteinEstimate = 28, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-30", "Carne magra assado com batata-doce", "Prato principal", "Brasil", ingredients = listOf("Carne magra", "Batata-doce", "Temperos"), instructions = """1. Prepare o carne magra assado
2. Cozinhe o acompanhamento (batata-doce)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 320, proteinEstimate = 28, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-31", "Carne magra grelhado com quinoa", "Prato principal", "Brasil", ingredients = listOf("Carne magra", "Quinoa", "Temperos"), instructions = """1. Prepare o carne magra grelhado
2. Cozinhe o acompanhamento (quinoa)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 340, proteinEstimate = 28, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-32", "Carne magra assado com quinoa", "Prato principal", "Brasil", ingredients = listOf("Carne magra", "Quinoa", "Temperos"), instructions = """1. Prepare o carne magra assado
2. Cozinhe o acompanhamento (quinoa)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 360, proteinEstimate = 28, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-33", "Carne magra grelhado com salada", "Prato principal", "Brasil", ingredients = listOf("Carne magra", "Salada", "Temperos"), instructions = """1. Prepare o carne magra grelhado
2. Cozinhe o acompanhamento (salada)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 380, proteinEstimate = 28, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-34", "Carne magra assado com salada", "Prato principal", "Brasil", ingredients = listOf("Carne magra", "Salada", "Temperos"), instructions = """1. Prepare o carne magra assado
2. Cozinhe o acompanhamento (salada)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 400, proteinEstimate = 28, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-35", "Carne magra grelhado com legumes no vapor", "Prato principal", "Brasil", ingredients = listOf("Carne magra", "Legumes no vapor", "Temperos"), instructions = """1. Prepare o carne magra grelhado
2. Cozinhe o acompanhamento (legumes no vapor)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 320, proteinEstimate = 28, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-36", "Carne magra assado com legumes no vapor", "Prato principal", "Brasil", ingredients = listOf("Carne magra", "Legumes no vapor", "Temperos"), instructions = """1. Prepare o carne magra assado
2. Cozinhe o acompanhamento (legumes no vapor)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 340, proteinEstimate = 28, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-37", "Peixe grelhado com arroz", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Arroz", "Temperos"), instructions = """1. Prepare o peixe grelhado
2. Cozinhe o acompanhamento (arroz)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 360, proteinEstimate = 28, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-38", "Peixe assado com arroz", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Arroz", "Temperos"), instructions = """1. Prepare o peixe assado
2. Cozinhe o acompanhamento (arroz)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 380, proteinEstimate = 28, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-39", "Peixe grelhado com arroz integral", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Arroz integral", "Temperos"), instructions = """1. Prepare o peixe grelhado
2. Cozinhe o acompanhamento (arroz integral)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 400, proteinEstimate = 28, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-40", "Peixe assado com arroz integral", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Arroz integral", "Temperos"), instructions = """1. Prepare o peixe assado
2. Cozinhe o acompanhamento (arroz integral)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 320, proteinEstimate = 28, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-41", "Peixe grelhado com batata-doce", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Batata-doce", "Temperos"), instructions = """1. Prepare o peixe grelhado
2. Cozinhe o acompanhamento (batata-doce)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 340, proteinEstimate = 28, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-42", "Peixe assado com batata-doce", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Batata-doce", "Temperos"), instructions = """1. Prepare o peixe assado
2. Cozinhe o acompanhamento (batata-doce)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 360, proteinEstimate = 28, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-43", "Peixe grelhado com quinoa", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Quinoa", "Temperos"), instructions = """1. Prepare o peixe grelhado
2. Cozinhe o acompanhamento (quinoa)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 380, proteinEstimate = 28, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-44", "Peixe assado com quinoa", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Quinoa", "Temperos"), instructions = """1. Prepare o peixe assado
2. Cozinhe o acompanhamento (quinoa)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 400, proteinEstimate = 28, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-45", "Peixe grelhado com salada", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Salada", "Temperos"), instructions = """1. Prepare o peixe grelhado
2. Cozinhe o acompanhamento (salada)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 320, proteinEstimate = 28, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-46", "Peixe assado com salada", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Salada", "Temperos"), instructions = """1. Prepare o peixe assado
2. Cozinhe o acompanhamento (salada)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 340, proteinEstimate = 28, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-47", "Peixe grelhado com legumes no vapor", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Legumes no vapor", "Temperos"), instructions = """1. Prepare o peixe grelhado
2. Cozinhe o acompanhamento (legumes no vapor)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 360, proteinEstimate = 28, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-48", "Peixe assado com legumes no vapor", "Prato principal", "Brasil", ingredients = listOf("Peixe", "Legumes no vapor", "Temperos"), instructions = """1. Prepare o peixe assado
2. Cozinhe o acompanhamento (legumes no vapor)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 380, proteinEstimate = 28, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-49", "Ovo grelhado com arroz", "Prato principal", "Brasil", ingredients = listOf("Ovo", "Arroz", "Temperos"), instructions = """1. Prepare o ovo grelhado
2. Cozinhe o acompanhamento (arroz)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 400, proteinEstimate = 14, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-50", "Ovo assado com arroz", "Prato principal", "Brasil", ingredients = listOf("Ovo", "Arroz", "Temperos"), instructions = """1. Prepare o ovo assado
2. Cozinhe o acompanhamento (arroz)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 320, proteinEstimate = 14, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-51", "Ovo grelhado com arroz integral", "Prato principal", "Brasil", ingredients = listOf("Ovo", "Arroz integral", "Temperos"), instructions = """1. Prepare o ovo grelhado
2. Cozinhe o acompanhamento (arroz integral)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 340, proteinEstimate = 14, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-52", "Ovo assado com arroz integral", "Prato principal", "Brasil", ingredients = listOf("Ovo", "Arroz integral", "Temperos"), instructions = """1. Prepare o ovo assado
2. Cozinhe o acompanhamento (arroz integral)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 360, proteinEstimate = 14, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-53", "Ovo grelhado com batata-doce", "Prato principal", "Brasil", ingredients = listOf("Ovo", "Batata-doce", "Temperos"), instructions = """1. Prepare o ovo grelhado
2. Cozinhe o acompanhamento (batata-doce)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 380, proteinEstimate = 14, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-54", "Ovo assado com batata-doce", "Prato principal", "Brasil", ingredients = listOf("Ovo", "Batata-doce", "Temperos"), instructions = """1. Prepare o ovo assado
2. Cozinhe o acompanhamento (batata-doce)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 400, proteinEstimate = 14, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-55", "Ovo grelhado com quinoa", "Prato principal", "Brasil", ingredients = listOf("Ovo", "Quinoa", "Temperos"), instructions = """1. Prepare o ovo grelhado
2. Cozinhe o acompanhamento (quinoa)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 320, proteinEstimate = 14, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-56", "Ovo assado com quinoa", "Prato principal", "Brasil", ingredients = listOf("Ovo", "Quinoa", "Temperos"), instructions = """1. Prepare o ovo assado
2. Cozinhe o acompanhamento (quinoa)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 35, kcalEstimate = 340, proteinEstimate = 14, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-57", "Ovo grelhado com salada", "Prato principal", "Brasil", ingredients = listOf("Ovo", "Salada", "Temperos"), instructions = """1. Prepare o ovo grelhado
2. Cozinhe o acompanhamento (salada)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 360, proteinEstimate = 14, fatEstimate = 11, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-58", "Ovo assado com salada", "Prato principal", "Brasil", ingredients = listOf("Ovo", "Salada", "Temperos"), instructions = """1. Prepare o ovo assado
2. Cozinhe o acompanhamento (salada)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 380, proteinEstimate = 14, fatEstimate = 12, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-59", "Ovo grelhado com legumes no vapor", "Prato principal", "Brasil", ingredients = listOf("Ovo", "Legumes no vapor", "Temperos"), instructions = """1. Prepare o ovo grelhado
2. Cozinhe o acompanhamento (legumes no vapor)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 400, proteinEstimate = 14, fatEstimate = 13, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-auto-60", "Ovo assado com legumes no vapor", "Prato principal", "Brasil", ingredients = listOf("Ovo", "Legumes no vapor", "Temperos"), instructions = """1. Prepare o ovo assado
2. Cozinhe o acompanhamento (legumes no vapor)
3. Monte o prato e ajuste o tempero""", source = "Coleção BR+", carbsEstimate = 12, kcalEstimate = 320, proteinEstimate = 14, fatEstimate = 10, tags = listOf("almoco", "jantar")),
    RecipeItem("br2-extra-cafe-1", "Panqueca de banana", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 30, kcalEstimate = 200, proteinEstimate = 8, fatEstimate = 5, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-2", "Crepioca simples", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 20, kcalEstimate = 180, proteinEstimate = 12, fatEstimate = 6, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-3", "Tapioca de queijo e tomate", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 28, kcalEstimate = 200, proteinEstimate = 10, fatEstimate = 7, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-4", "Aveia overnight", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 32, kcalEstimate = 220, proteinEstimate = 10, fatEstimate = 5, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-5", "Iogurte com granola light", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 28, kcalEstimate = 190, proteinEstimate = 9, fatEstimate = 4, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-6", "Sanduíche natural de frango", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 30, kcalEstimate = 280, proteinEstimate = 20, fatEstimate = 8, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-7", "Wrap integral de atum", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 28, kcalEstimate = 260, proteinEstimate = 22, fatEstimate = 7, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-8", "Torrada com abacate", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 22, kcalEstimate = 240, proteinEstimate = 6, fatEstimate = 14, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-9", "Omelete de forno com legumes", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 8, kcalEstimate = 220, proteinEstimate = 18, fatEstimate = 12, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-10", "Vitamina de morango", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 25, kcalEstimate = 150, proteinEstimate = 6, fatEstimate = 2, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-11", "Café com leite e pão integral", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 28, kcalEstimate = 210, proteinEstimate = 9, fatEstimate = 5, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-12", "Cuscuz com queijo coalho", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 34, kcalEstimate = 270, proteinEstimate = 12, fatEstimate = 10, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-13", "Mingau de fubá light", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 36, kcalEstimate = 200, proteinEstimate = 6, fatEstimate = 3, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-14", "Biscoito de arroz com pasta de amendoim", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 22, kcalEstimate = 180, proteinEstimate = 6, fatEstimate = 8, tags = listOf("cafe", "lanche", "rapido")),
    RecipeItem("br2-extra-cafe-15", "Salada de frutas controlada", "Café da manhã", "Brasil", ingredients = listOf("Ingredientes variados conforme receita"), instructions = """1. Separe os ingredientes
2. Prepare conforme o nome do prato
3. Ajuste porções ao seu plano""", source = "Coleção BR+", carbsEstimate = 30, kcalEstimate = 120, proteinEstimate = 1, fatEstimate = 0, tags = listOf("cafe", "lanche", "rapido")),
)

private val recipeOnlineCache = linkedMapOf<String, Pair<Long, List<RecipeItem>>>()
private const val RECIPE_CACHE_TTL = 30 * 60_000L

private fun mealDbToRecipe(o: JSONObject): RecipeItem? {
    val id = o.optString("idMeal", "")
    val name = o.optString("strMeal", "")
    if (id.isBlank() || name.isBlank()) return null
    val ingredients = mutableListOf<String>()
    for (i in 1..20) {
        val ing = o.optString("strIngredient$i", "").trim()
        val measure = o.optString("strMeasure$i", "").trim()
        if (ing.isNotBlank()) ingredients.add(if (measure.isNotBlank()) "$measure $ing".trim() else ing)
    }
    val category = o.optString("strCategory", "")
    val tags = mutableListOf<String>()
    when {
        category.contains("Breakfast", true) -> tags.add("cafe")
        category.contains("Dessert", true) -> tags.add("doce")
        category.contains("Starter", true) || category.contains("Side", true) -> tags.add("lanche")
        else -> { tags.add("almoco"); tags.add("jantar") }
    }
    if (category.contains("Vegetarian", true) || category.contains("Vegan", true)) tags.add("vegetariano")
    return RecipeItem(
        id = "mealdb-$id",
        name = name,
        category = category,
        area = o.optString("strArea", ""),
        thumb = o.optString("strMealThumb", ""),
        ingredients = ingredients,
        instructions = o.optString("strInstructions", "").trim(),
        source = "TheMealDB",
        servings = "1 porção (estimativa)",
        tags = tags,
        carbsEstimate = null,
        kcalEstimate = null,
    )
}

suspend fun searchRecipesOnline(query: String): List<RecipeItem> = withContext(Dispatchers.IO) {
    val q = query.trim()
    if (q.length < 2) return@withContext emptyList()
    val key = q.lowercase()
    recipeOnlineCache[key]?.let { (at, list) ->
        if (System.currentTimeMillis() - at < RECIPE_CACHE_TTL) return@withContext list
    }
    try {
        val enc = URLEncoder.encode(q, "UTF-8")
        val url = URL("https://www.themealdb.com/api/json/v1/1/search.php?s=$enc")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 3000; readTimeout = 4000
            setRequestProperty("User-Agent", "GlucoCris/1.4")
        }
        if (conn.responseCode != 200) return@withContext emptyList()
        val json = JSONObject(conn.inputStream.bufferedReader().readText())
        val arr = json.optJSONArray("meals") ?: return@withContext emptyList()
        val list = mutableListOf<RecipeItem>()
        for (i in 0 until arr.length()) mealDbToRecipe(arr.getJSONObject(i))?.let { list.add(it) }
        recipeOnlineCache[key] = System.currentTimeMillis() to list
        while (recipeOnlineCache.size > 60) recipeOnlineCache.remove(recipeOnlineCache.keys.first())
        list
    } catch (_: Exception) {
        emptyList()
    }
}

suspend fun lookupRecipeOnline(id: String): RecipeItem? = withContext(Dispatchers.IO) {
    try {
        val numeric = id.removePrefix("mealdb-")
        val url = URL("https://www.themealdb.com/api/json/v1/1/lookup.php?i=$numeric")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 3000; readTimeout = 4000
        }
        if (conn.responseCode != 200) return@withContext null
        val json = JSONObject(conn.inputStream.bufferedReader().readText())
        val arr = json.optJSONArray("meals") ?: return@withContext null
        if (arr.length() == 0) return@withContext null
        mealDbToRecipe(arr.getJSONObject(0))
    } catch (_: Exception) {
        null
    }
}

fun searchLocalRecipes(query: String, tag: String?): List<RecipeItem> {
    val q = query.lowercase().trim()
    val base = if (tag.isNullOrBlank() || tag == "todos") LOCAL_RECIPES
    else if (tag == "brasil") LOCAL_RECIPES.filter { it.area.equals("Brasil", true) }
    else if (tag == "favoritos") LOCAL_RECIPES // filtrado depois
    else LOCAL_RECIPES.filter { tag in it.tags || it.category.lowercase().contains(tag) }
    if (q.isBlank()) return base
    val parts = q.split(" ").filter { it.length > 1 }
    return base.filter { r ->
        val blob = (r.name + " " + r.category + " " + r.area + " " + r.ingredients.joinToString(" ") + " " + r.tags.joinToString(" ")).lowercase()
        parts.all { blob.contains(it) } || blob.contains(q)
    }
}

private fun recipeMinutes(r: RecipeItem): Int {
    if ("rapido" in r.tags) return 15
    if ("cafe" in r.tags) return 12
    if ("doce" in r.tags) return 40
    if ("lanche" in r.tags) return 10
    val n = r.name.lowercase()
    if ("smoothie" in n || "vitamina" in n || "suco" in n) return 10
    if ("bolo" in n || "muffin" in n) return 35
    if ("omelete" in n || "ovo" in n) return 12
    return 25
}

private fun recipeCoverColor(r: RecipeItem): Color {
    val palette = listOf(
        Color(0xFF334155), Color(0xFF3B0764), Color(0xFF064E3B), Color(0xFF7C2D12),
        Color(0xFF1E3A5F), Color(0xFF4A044E), Color(0xFF14532D),
    )
    return palette[kotlin.math.abs(r.id.hashCode()) % palette.size]
}

private val FILTERS = listOf(

    "todos" to "Todas",
    "brasil" to "Brasil",
    "cafe" to "Café",
    "almoco" to "Almoço",
    "jantar" to "Jantar",
    "lanche" to "Lanche",
    "lowcarb" to "Low carb",
    "doce" to "Doces",
    "vegetariano" to "Vegetariano",
    "rapido" to "Rápidas",
    "favoritos" to "Favoritas",
)

@Composable
fun RecipeSearchScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("todos") }
    var favIds by remember { mutableStateOf(loadFavRecipeIds(context)) }
    var results by remember { mutableStateOf(LOCAL_RECIPES) }
    var suggestions by remember { mutableStateOf<List<RecipeItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    var job by remember { mutableStateOf<Job?>(null) }

    fun applyLists(text: String, tag: String, online: List<RecipeItem> = emptyList()) {
        var local = searchLocalRecipes(text, if (tag == "favoritos") "todos" else tag)
        val cached = loadCachedRecipes(context).filter { c ->
            val q = text.lowercase()
            q.isBlank() || c.name.lowercase().contains(q) || c.ingredients.any { it.lowercase().contains(q) }
        }
        if (tag == "favoritos") {
            local = (LOCAL_RECIPES + cached + online).filter { it.id in favIds }
            if (text.isNotBlank()) {
                val parts = text.lowercase().split(" ").filter { it.length > 1 }
                local = local.filter { r ->
                    val blob = (r.name + r.ingredients.joinToString()).lowercase()
                    parts.all { blob.contains(it) }
                }
            }
        } else {
            local = (local + cached + online).distinctBy { it.name.lowercase() }
            if (tag == "brasil") local = local.filter { it.area.contains("Brasil", true) || it.source.contains("BR") }
            else if (tag != "todos" && tag != "favoritos") {
                local = local.filter { tag in it.tags || it.category.lowercase().contains(tag) ||
                    (tag == "cafe" && it.category.contains("Breakfast", true)) ||
                    (tag == "doce" && it.category.contains("Dessert", true)) }
            }
        }
        results = local
        suggestions = if (text.isBlank()) emptyList() else local.take(8)
    }

    fun onQuery(text: String) {
        query = text
        error = null
        job?.cancel()
        applyLists(text, filter)
        if (text.length < 2) {
            loading = false
            return
        }
        job = scope.launch {
            delay(200)
            if (query != text) return@launch
            loading = true
            val online = searchRecipesOnline(text)
            if (query == text) {
                applyLists(text, filter, online)
                if (results.isEmpty()) error = "Nenhuma receita para \"$text\"."
            }
            loading = false
        }
    }

    fun open(r: RecipeItem) {
        scope.launch {
            val full = if (r.id.startsWith("mealdb-") && r.instructions.isBlank()) {
                lookupRecipeOnline(r.id) ?: r
            } else r
            cacheRecipe(context, full)
            vm.setTempRecipe(full)
            nav.navigate(Routes.FOOD_RECIPE_DETAIL)
        }
    }

    LaunchedEffect(filter) { applyLists(query, filter) }

    var recipeTab by remember { mutableStateOf(0) } // 0 receitas 1 planos 2 marmitas

    Column(Modifier.fillMaxSize().background(g.bg)) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.Filled.Close, null, tint = g.ink)
            }
            Text(
                when (recipeTab) {
                    1 -> "Planos alimentares"
                    2 -> "Marmitas Cris DM"
                    else -> "Receitas"
                },
                color = g.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f),
            )
        }
        TabRow(selectedTabIndex = recipeTab, containerColor = g.bg, contentColor = g.violet) {
            Tab(selected = recipeTab == 0, onClick = { recipeTab = 0 }, text = { Text("Receitas", fontSize = 12.sp) })
            Tab(selected = recipeTab == 1, onClick = { recipeTab = 1 }, text = { Text("Planos", fontSize = 12.sp) })
            Tab(selected = recipeTab == 2, onClick = { recipeTab = 2 }, text = { Text("Marmitas", fontSize = 12.sp) })
        }

        if (recipeTab == 1) {
            MealPlanCatalogTab(vm, nav)
            return@Column
        }
        if (recipeTab == 2) {
            MarmitasCrisDmTab()
            return@Column
        }

        OutlinedTextField(
            value = query,
            onValueChange = { onQuery(it) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
            placeholder = { Text("Pesquisar receitas", color = g.muted) },
            leadingIcon = { Icon(Icons.Filled.Search, null, tint = g.muted) },
            trailingIcon = {
                if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = g.violet)
            },
            singleLine = true,
            shape = RoundedCornerShape(28.dp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { }),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = g.violet,
                unfocusedBorderColor = g.card,
                focusedContainerColor = g.card,
                unfocusedContainerColor = g.card,
            ),
        )

        // Filtros por tipo
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FILTERS.forEach { (key, label) ->
                val sel = filter == key
                Box(
                    Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (sel) g.violet else g.card)
                        .clickable {
                            filter = key
                            applyLists(query, key)
                        }
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                ) {
                    Text(label, color = if (sel) androidx.compose.ui.graphics.Color.White else g.ink, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                }
            }
        }

        AnimatedVisibility(visible = suggestions.isNotEmpty() && query.isNotBlank()) {
            Column(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(14.dp)).background(g.card),
            ) {
                suggestions.take(6).forEach { r ->
                    Row(
                        Modifier.fillMaxWidth().clickable { open(r) }.padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Filled.RestaurantMenu, null, tint = g.muted, modifier = Modifier.size(16.dp))
                        Column(Modifier.padding(start = 10.dp).weight(1f)) {
                            Text(r.name, color = g.ink, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
                            Text(
                                buildString {
                                    if (r.area.isNotBlank()) append(r.area)
                                    if (r.carbsEstimate != null) {
                                        if (isNotEmpty()) append(" · ")
                                        append("~${r.carbsEstimate.roundToInt()} g carb")
                                    } else {
                                        if (isNotEmpty()) append(" · ")
                                        append("carb não informado")
                                    }
                                },
                                color = g.muted, fontSize = 12.sp, maxLines = 1,
                            )
                        }
                    }
                    HorizontalDivider(color = g.line, thickness = 0.5.dp)
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                "${results.size} receita(s)",
                color = g.muted, fontSize = 12.sp, modifier = Modifier.weight(1f),
            )
            Text("Ordenar · grade", color = g.muted, fontSize = 12.sp)
        }
        error?.let { Text(it, color = g.red, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp)) }

        // Grade estilo FatSecret: foto + tempo + nome (mantém busca, filtros e favoritos)
        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(bottom = 24.dp, top = 4.dp),
        ) {
            gridItems(results, key = { it.id }) { r ->
                val isFav = r.id in favIds
                val mins = recipeMinutes(r)
                Column(Modifier.clickable { open(r) }) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(recipeCoverColor(r)),
                    ) {
                        val userThumb = loadRecipeUserThumb(context, r.id)
                        val cover = userThumb ?: r.thumb
                        if (cover.isNotBlank()) {
                            AsyncImage(
                                model = cover,
                                contentDescription = r.name,
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop,
                            )
                        } else {
                            Text(
                                r.name.take(1).uppercase(),
                                color = Color.White.copy(alpha = 0.9f),
                                fontWeight = FontWeight.Bold,
                                fontSize = 36.sp,
                                modifier = Modifier.align(Alignment.Center),
                            )
                        }
                        Text(
                            "$mins min",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(8.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color.Black.copy(alpha = 0.45f))
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                        )
                        Icon(
                            if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                            null,
                            tint = if (isFav) g.blush else Color.White,
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(6.dp)
                                .clickable {
                                    val next = favIds.toMutableSet()
                                    if (isFav) next.remove(r.id) else next.add(r.id)
                                    favIds = next
                                    saveFavRecipeIds(context, next)
                                }
                                .size(22.dp),
                        )
                    }
                    Text(
                        r.name,
                        color = g.ink,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        maxLines = 2,
                        modifier = Modifier.padding(top = 6.dp, start = 2.dp, end = 2.dp),
                    )
                    Text(
                        buildString {
                            r.carbsEstimate?.let { append("C ${it.roundToInt()}g") }
                            r.proteinEstimate?.let {
                                if (isNotEmpty()) append(" · ")
                                append("P ${it.roundToInt()}g")
                            }
                            r.fatEstimate?.let {
                                if (isNotEmpty()) append(" · ")
                                append("G ${it.roundToInt()}g")
                            }
                            if (isEmpty()) {
                                r.kcalEstimate?.let { append("~${it.roundToInt()} kcal") }
                                    ?: append(r.area.ifBlank { "Receita" })
                            }
                        },
                        color = g.muted,
                        fontSize = 11.sp,
                        maxLines = 2,
                        modifier = Modifier.padding(start = 2.dp, end = 2.dp, top = 2.dp),
                    )
                }
            }
        }
    }
}

@Composable
fun RecipeDetailScreen(vm: GlucoViewModel, nav: NavHostController) {
    val g = glucoColors()
    val context = LocalContext.current
    val recipe = vm.tempRecipe
    if (recipe == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Nenhuma receita selecionada", color = g.muted)
        }
        return
    }
    var mealType by remember { mutableStateOf("almoco") }
    var mealExpanded by remember { mutableStateOf(false) }
    var portions by remember { mutableStateOf(1.0) }
    var portionsText by remember { mutableStateOf("1") }
    var favIds by remember { mutableStateOf(loadFavRecipeIds(context)) }
    val isFav = recipe.id in favIds
    val carbScaled = recipe.carbsEstimate?.let { it * portions }
    val kcalScaled = recipe.kcalEstimate?.let { it * portions }
    val highCarb = (carbScaled ?: 0.0) >= 45.0
    fun setPortions(v: Double) {
        val q = v.coerceIn(0.1, 20.0)
        portions = q
        portionsText = if (q == q.toLong().toDouble()) q.toLong().toString()
        else String.format(java.util.Locale.US, "%.2f", q).trimEnd('0').trimEnd('.')
    }

    LaunchedEffect(recipe.id) { cacheRecipe(context, recipe) }

    Column(Modifier.fillMaxSize().background(g.bg)) {
        Row(Modifier.fillMaxWidth().padding(4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.Filled.Close, null, tint = g.ink)
            }
            Text(recipe.name, color = g.ink, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f), maxLines = 2)
            IconButton(onClick = {
                val next = favIds.toMutableSet()
                if (isFav) next.remove(recipe.id) else next.add(recipe.id)
                favIds = next
                saveFavRecipeIds(context, next)
            }) {
                Icon(if (isFav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, null, tint = if (isFav) g.blush else g.muted)
            }
        }
        ScrollScreen {
            Row(
                Modifier.clip(RoundedCornerShape(20.dp)).background(g.lilacSoft).padding(horizontal = 12.dp, vertical = 6.dp),
            ) {
                Text(
                    listOfNotNull(recipe.source.ifBlank { null }, recipe.area.ifBlank { null }, recipe.category.ifBlank { null })
                        .joinToString(" · "),
                    color = g.violetDeep, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                )
            }

            var userPhoto by remember { mutableStateOf(loadRecipeUserThumb(context, recipe.id)) }
            val pickPhoto = androidx.activity.compose.rememberLauncherForActivityResult(
                androidx.activity.result.contract.ActivityResultContracts.GetContent(),
            ) { uri ->
                if (uri != null) {
                    saveRecipeUserThumb(context, recipe.id, uri.toString())
                    userPhoto = uri.toString()
                }
            }
            GCard {
                Text("Foto da receita (opcional, só neste aparelho)", color = g.ink, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                if (!userPhoto.isNullOrBlank()) {
                    coil3.compose.AsyncImage(
                        model = userPhoto,
                        contentDescription = null,
                        modifier = Modifier.fillMaxWidth().height(140.dp).clip(RoundedCornerShape(12.dp)).padding(top = 8.dp),
                        contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    )
                }
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TextButton(onClick = { pickPhoto.launch("image/*") }) {
                        Text(if (userPhoto.isNullOrBlank()) "Escolher foto" else "Trocar foto", color = g.violet)
                    }
                    if (!userPhoto.isNullOrBlank()) {
                        TextButton(onClick = {
                            saveRecipeUserThumb(context, recipe.id, null)
                            userPhoto = null
                        }) { Text("Remover", color = g.muted) }
                    }
                }
            }

            SectionTitle("Porções")
            GCard {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.5 to "½", 1.0 to "1", 1.5 to "1½", 2.0 to "2").forEach { (v, label) ->
                        val sel = kotlin.math.abs(portions - v) < 0.001
                        Box(
                            Modifier.clip(RoundedCornerShape(12.dp)).background(if (sel) g.violet else g.inputBg)
                                .clickable { setPortions(v) }.padding(horizontal = 14.dp, vertical = 10.dp),
                        ) {
                            Text(label, color = if (sel) androidx.compose.ui.graphics.Color.White else g.ink, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                Text("Ou digite a quantidade desejada (ex.: 0,75 · 3)", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
                OutlinedTextField(
                    value = portionsText,
                    onValueChange = { raw ->
                        val cleaned = raw.filter { it.isDigit() || it == ',' || it == '.' }
                        portionsText = cleaned
                        cleaned.replace(",", ".").toDoubleOrNull()?.let { v ->
                            if (v > 0) {
                                portions = v.coerceIn(0.1, 20.0)
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                    singleLine = true,
                    label = { Text("Quantidade (× porção base)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    suffix = { Text("×", color = g.muted) },
                )
                Text("Porção base: ${recipe.servings} · tabela recalcula ao mudar a quantidade", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }

            SectionTitle("Informação nutricional (estimativa)")
            GCard {
                val protS = recipe.proteinEstimate?.let { it * portions }
                val fatS = recipe.fatEstimate?.let { it * portions }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Calorias", color = g.muted, fontSize = 11.sp)
                        Text(if (kcalScaled != null) "${kcalScaled.roundToInt()}" else "—", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Column {
                        Text("Carb (g)", color = g.muted, fontSize = 11.sp)
                        Text(if (carbScaled != null) "${carbScaled.roundToInt()}" else "—", color = g.violetDeep, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Column {
                        Text("Prot (g)", color = g.muted, fontSize = 11.sp)
                        Text(if (protS != null) "${protS.roundToInt()}" else "—", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                    Column {
                        Text("Gord (g)", color = g.muted, fontSize = 11.sp)
                        Text(if (fatS != null) "${fatS.roundToInt()}" else "—", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    }
                }
                Text("Para ${portions}× a porção · referência, não prescrição", color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 8.dp))
                if (highCarb) {
                    Text("Carb relativamente alto nesta quantidade — confira com sua equipe.", color = g.orange, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }

            if (recipe.ingredients.isNotEmpty()) {
                SectionTitle("Ingredientes")
                GCard {
                    recipe.ingredients.forEach { ing ->
                        Text("• $ing", color = g.ink, fontSize = 14.sp, modifier = Modifier.padding(vertical = 2.dp))
                    }
                }
            }

            if (recipe.instructions.isNotBlank()) {
                SectionTitle("Modo de preparo")
                GCard {
                val raw = recipe.instructions.ifBlank { "Instruções não disponíveis." }
                val steps = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }.ifEmpty {
                    raw.split(Regex("(?<=\\.)\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
                }
                if (steps.size <= 1) {
                    Text(raw, color = g.ink, fontSize = 14.sp, lineHeight = 22.sp)
                } else {
                    steps.forEachIndexed { i, step ->
                        val clean = step.removePrefix("${i + 1}.").removePrefix("${i + 1})").trim()
                        Row(Modifier.padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
                            Box(
                                Modifier.size(28.dp).clip(RoundedCornerShape(14.dp)).background(g.lilacSoft),
                                contentAlignment = Alignment.Center,
                            ) {
                                Text("${i + 1}", color = g.violet, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Text(clean, color = g.ink, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(start = 10.dp))
                        }
                    }
                }
                Text("Tempo estimado: ~${recipeMinutes(recipe)} min", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            }
            }

            SectionTitle("Registrar / bolus")
            GCard {
                Box {
                    Text(
                        MEAL_OPTIONS.find { it.first == mealType }?.second ?: "Almoço",
                        color = g.ink, fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { mealExpanded = true }.padding(8.dp),
                    )
                    DropdownMenu(expanded = mealExpanded, onDismissRequest = { mealExpanded = false }) {
                        MEAL_OPTIONS.forEach { (key, label) ->
                            DropdownMenuItem(
                                text = { Text(label, color = if (key == mealType) g.green else g.ink) },
                                onClick = { mealType = key; mealExpanded = false },
                            )
                        }
                    }
                }
                PrimaryButton("Adicionar ao diário", g.green, {
                    val desc = "Receita: ${recipe.name} (${portions}× ${recipe.servings})"
                    vm.saveMeal(
                        Meal(
                            id = uid(),
                            type = mealType,
                            description = desc,
                            carbs = carbScaled,
                            at = System.currentTimeMillis(),
                            notes = "fonte=${recipe.source};receita=${recipe.id};porcoes=$portions",
                        ),
                    )
                    nav.popBackStack(Routes.FOOD, false)
                }, Modifier.padding(top = 8.dp))
                if (carbScaled != null) {
                    TextButton(onClick = {
                        context.getSharedPreferences("gluco_food_tools", Context.MODE_PRIVATE).edit()
                            .putFloat("last_meal_carbs", carbScaled.toFloat()).apply()
                        nav.navigate(Routes.FOOD_BOLUS)
                    }) {
                        Text("Usar este carb na calculadora de bolus", color = g.violet, fontWeight = FontWeight.Bold)
                    }
                }
                TextButton(onClick = { nav.navigate(Routes.FOOD_GLUCOSE_LINK) }) {
                    Text("Ver refeições × glicemia", color = g.violet, fontSize = 13.sp)
                }
            }
            Text(
                "Receitas são referência culinária. Valores nutricionais, quando existem, são estimativas.",
                color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(top = 12.dp, bottom = 24.dp),
            )
        }
    }
}


@Composable
private fun MarmitasCrisDmTab() {
    val g = glucoColors()
    val context = LocalContext.current
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
    ) {
        GCard {
            Text("Marmitas Cris DM", color = g.violetDeep, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
            Text(
                "Alimentação prática para quem vive com diabetes — porções pensadas, sabor de comida de verdade e pedido direto com a Maria Cristina.",
                color = g.ink, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp),
            )
            Text(
                "Não é prescrição médica. Combine com sua equipe os carboidratos e horários. Cada marmita abaixo tem o WhatsApp oficial para solicitar.",
                color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp),
            )
            Text(
                "WhatsApp fixo: $CRIS_WHATSAPP_DISPLAY",
                color = g.green, fontWeight = FontWeight.Bold, fontSize = 14.sp, modifier = Modifier.padding(top = 10.dp),
            )
            PrimaryButton("Falar no WhatsApp agora", g.green, {
                openCrisWhatsApp(context, "informações gerais sobre as Marmitas Cris DM")
            }, Modifier.padding(top = 10.dp))
            val last = loadLastMarmita(context)
            if (!last.isNullOrBlank()) {
                PrimaryButton("Pedir de novo: $last", g.violet, {
                    openCrisWhatsApp(context, last)
                }, Modifier.padding(top = 8.dp))
            }
        }
        Text(
            "Por que escolher Marmitas Cris DM?",
            color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
        )
        GCard {
            Text("• Rotina sem adivinhar porção na correria", color = g.ink, fontSize = 13.sp)
            Text("• Opções alinhadas ao controle de carboidrato do dia a dia", color = g.ink, fontSize = 13.sp)
            Text("• Atendimento humano pelo WhatsApp da Maria Cristina", color = g.ink, fontSize = 13.sp)
            Text("• Ideal para quem quer praticidade com responsabilidade", color = g.ink, fontSize = 13.sp)
        }
        Text("Cardápio de marmitas", color = g.ink, fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
        MARMITAS_CRIS_DM.forEach { m ->
            GCard(Modifier.padding(bottom = 10.dp)) {
                Text(m.highlight, color = g.violet, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(m.name, color = g.ink, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
                Text(m.desc, color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
                Text(m.carbsNote, color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                Text("Pedido: WhatsApp $CRIS_WHATSAPP_DISPLAY", color = g.green, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                PrimaryButton("Solicitar no WhatsApp", g.violet, {
                    openCrisWhatsApp(context, m.name)
                }, Modifier.padding(top = 8.dp))
            }
        }
        Text(
            "Gluco Cris · Marmitas Cris DM · uso de apoio, não substitui orientação clínica.",
            color = g.muted, fontSize = 11.sp, modifier = Modifier.padding(vertical = 12.dp),
        )
    }
}
