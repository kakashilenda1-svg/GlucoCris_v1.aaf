package com.agon.app.ui.screens

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavHostController
import com.agon.app.Routes
import com.agon.app.data.GlucoViewModel
import com.agon.app.ui.components.PrimaryButton
import com.agon.app.ui.theme.glucoColors
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.sin

private val WaterBlue = Color(0xFF0EA5E9)
private val WaterBlueDeep = Color(0xFF0284C7)
private val WaterBlueSoft = Color(0xFFBAE6FD)
private val WaterBlueBg = Color(0xFF0C4A6E)
private val WaterSurface = Color(0xFFE0F2FE)

data class WaterCupPreset(val ml: Int, val label: String, val kind: String)
data class WaterEntry(val id: String, val ml: Int, val at: Long, val kind: String)

private val CUP_PRESETS = listOf(
    WaterCupPreset(150, "150 ml", "tea"),
    WaterCupPreset(200, "200 ml", "glass"),
    WaterCupPreset(250, "250 ml", "glass"),
    WaterCupPreset(300, "300 ml", "glass"),
    WaterCupPreset(400, "400 ml", "cup"),
    WaterCupPreset(500, "500 ml", "bottle"),
    WaterCupPreset(600, "600 ml", "bottle"),
    WaterCupPreset(700, "700 ml", "bottle"),
    WaterCupPreset(800, "800 ml", "bottle"),
    WaterCupPreset(1000, "1 L", "bottle"),
)

private const val WATER_PREFS = "gluco_water_v1"
private const val KEY_GOAL = "goal_ml"
private const val KEY_ENTRIES = "entries_json"

private const val KEY_FAV_CUPS = "fav_cups"
private const val KEY_SOUNDS = "sounds_on"
private const val KEY_HEAT_DAY = "heat_day"
private const val KEY_HEAT_ON = "heat_on"
private const val KEY_LAST_REMIND = "last_remind_at"
private const val KEY_ASK_MEAL = "ask_after_meal"
private const val KEY_REMIND_HOURS = "remind_hours"
private const val HEAT_BONUS_ML = 400

fun waterSoundsOn(ctx: Context): Boolean =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SOUNDS, true)

fun setWaterSoundsOn(ctx: Context, on: Boolean) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_SOUNDS, on).apply()
}

fun loadFavCups(ctx: Context): List<Int> {
    val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE)
        .getString(KEY_FAV_CUPS, "250,300,500") ?: "250,300,500"
    return raw.split(",").mapNotNull { it.trim().toIntOrNull() }.filter { it in 50..2000 }.distinct().take(4)
}

fun saveFavCups(ctx: Context, list: List<Int>) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putString(KEY_FAV_CUPS, list.distinct().take(4).joinToString(",")).apply()
}

fun toggleFavCup(ctx: Context, ml: Int) {
    val cur = loadFavCups(ctx).toMutableList()
    if (ml in cur) cur.remove(ml) else {
        if (cur.size >= 4) cur.removeAt(0)
        cur.add(ml)
    }
    saveFavCups(ctx, cur)
}

fun isHeatModeToday(ctx: Context): Boolean {
    val p = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE)
    return p.getBoolean(KEY_HEAT_ON, false) && p.getString(KEY_HEAT_DAY, "") == dayKey()
}

fun setHeatModeToday(ctx: Context, on: Boolean) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putBoolean(KEY_HEAT_ON, on).putString(KEY_HEAT_DAY, dayKey()).apply()
}

fun effectiveWaterGoal(ctx: Context): Int {
    val base = loadWaterGoal(ctx)
    return if (isHeatModeToday(ctx)) base + HEAT_BONUS_ML else base
}

fun suggestedWaterGoalMl(weightKg: String?): Int? {
    val w = weightKg?.replace(",", ".")?.toDoubleOrNull() ?: return null
    if (w < 30 || w > 250) return null
    return (w * 35.0).toInt().coerceIn(1500, 4500)
}

fun waterMorningLow(ctx: Context): Boolean {
    val entries = loadWaterEntries(ctx)
    val morning = entries.filter {
        val c = Calendar.getInstance().apply { timeInMillis = it.at }
        c.get(Calendar.HOUR_OF_DAY) < 12
    }.sumOf { it.ml }
    val goal = effectiveWaterGoal(ctx)
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return hour >= 12 && morning < (goal * 0.25)
}

fun waterRemindHours(ctx: Context): Int =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getInt(KEY_REMIND_HOURS, 2).coerceIn(1, 6)

fun setWaterRemindHours(ctx: Context, h: Int) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putInt(KEY_REMIND_HOURS, h.coerceIn(1, 6)).apply()
}

fun shouldSoftWaterRemind(ctx: Context): Boolean {
    val total = waterTodayTotal(ctx)
    val goal = effectiveWaterGoal(ctx)
    if (total >= goal) return false
    val last = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getLong(KEY_LAST_REMIND, 0L)
    val gap = waterRemindHours(ctx) * 60L * 60L * 1000L
    return System.currentTimeMillis() - last > gap
}

fun markWaterReminded(ctx: Context) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putLong(KEY_LAST_REMIND, System.currentTimeMillis()).apply()
}

fun askWaterAfterMeal(ctx: Context): Boolean =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ASK_MEAL, true)

fun setAskWaterAfterMeal(ctx: Context, on: Boolean) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_ASK_MEAL, on).apply()
}

fun waterInsightLine(ctx: Context): String? {
    val total = waterTodayTotal(ctx)
    val goal = effectiveWaterGoal(ctx)
    if (total >= goal) return "Meta batida hoje — lembretes suaves em silêncio."
    if (waterMorningLow(ctx)) return "Pouco de manhã no histórico de hoje. Que tal um copo agora?"
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    if (hour in 14..17 && total < goal * 0.5) return "Tarde: ainda abaixo da metade da meta."
    if (shouldSoftWaterRemind(ctx)) return "Lembrete suave: ainda falta água para a meta."
    return null
}

fun waterMood(progress: Float): Int = when {
    progress >= 1f -> 2
    progress >= 0.5f -> 1
    else -> 0
}

fun waterWeekTotal(ctx: Context): Int {
    return try {
        val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getString(KEY_ENTRIES, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val cutoff = System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000
        (0 until arr.length()).sumOf { i ->
            val o = arr.getJSONObject(i)
            val at = o.optLong("at")
            if (at >= cutoff) o.optInt("ml") else 0
        }
    } catch (_: Exception) { 0 }
}


private fun dayKey(ts: Long = System.currentTimeMillis()): String {
    val c = Calendar.getInstance().apply { timeInMillis = ts }
    return "%04d-%02d-%02d".format(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
}

fun loadWaterGoal(ctx: Context): Int =
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getInt(KEY_GOAL, 2000)

fun saveWaterGoal(ctx: Context, ml: Int) {
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit()
        .putInt(KEY_GOAL, ml.coerceIn(500, 8000)).apply()
}

fun loadWaterEntries(ctx: Context): List<WaterEntry> {
    return try {
        val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getString(KEY_ENTRIES, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val today = dayKey()
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val at = o.optLong("at")
            if (dayKey(at) != today) return@mapNotNull null
            WaterEntry(o.optString("id"), o.optInt("ml"), at, o.optString("kind", "glass"))
        }.sortedByDescending { it.at }
    } catch (_: Exception) {
        emptyList()
    }
}

fun saveWaterEntries(ctx: Context, list: List<WaterEntry>) {
    // keep today + last 7 days
    val cutoff = System.currentTimeMillis() - 8L * 24 * 60 * 60 * 1000
    val allRaw = try {
        val raw = ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).getString(KEY_ENTRIES, "[]") ?: "[]"
        val arr = JSONArray(raw)
        val old = (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val at = o.optLong("at")
            if (at < cutoff) null else WaterEntry(o.optString("id"), o.optInt("ml"), at, o.optString("kind", "glass"))
        }
        val today = dayKey()
        old.filter { dayKey(it.at) != today } + list
    } catch (_: Exception) {
        list
    }
    val arr = JSONArray()
    allRaw.forEach { e ->
        arr.put(JSONObject().put("id", e.id).put("ml", e.ml).put("at", e.at).put("kind", e.kind))
    }
    ctx.getSharedPreferences(WATER_PREFS, Context.MODE_PRIVATE).edit().putString(KEY_ENTRIES, arr.toString()).apply()
}

fun waterTodayTotal(ctx: Context): Int = loadWaterEntries(ctx).sumOf { it.ml }

/** roll, pitch, inverted (celular de ponta-cabeça → água “derrama”). */
data class DeviceTilt(val roll: Float, val pitch: Float, val inverted: Boolean)

@Composable
fun rememberDeviceTilt(): DeviceTilt {
    val ctx = LocalContext.current
    var roll by remember { mutableFloatStateOf(0f) }
    var pitch by remember { mutableFloatStateOf(0f) }
    var inverted by remember { mutableStateOf(false) }
    DisposableEffect(Unit) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val listener = object : SensorEventListener {
            override fun onSensorChanged(event: SensorEvent?) {
                if (event == null) return
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values.getOrNull(2) ?: 0f
                // suaviza e limita
                val targetRoll = (-x * 7f).coerceIn(-22f, 22f)
                val targetPitch = ((y - 9.5f) * 2.2f).coerceIn(-12f, 12f)
                roll = roll * 0.78f + targetRoll * 0.22f
                pitch = pitch * 0.78f + targetPitch * 0.22f
                // ponta-cabeça: eixo Y negativo (gravidade invertida)
                inverted = y < -3.5f || (kotlin.math.abs(y) < 3f && z < -6f)
            }
            override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
        }
        if (sensor != null) {
            sm.registerListener(listener, sensor, SensorManager.SENSOR_DELAY_GAME)
        }
        onDispose { sm.unregisterListener(listener) }
    }
    return DeviceTilt(roll, pitch, inverted)
}

@Composable
fun WaterBuddy(
    modifier: Modifier = Modifier,
    happy: Boolean = true,
    mood: Int = 1,
    roll: Float = 0f,
    inverted: Boolean = false,
) {
    val infinite = rememberInfiniteTransition(label = "buddy")
    // pernas se mexendo embaixo (sem subir/descer o corpo)
    val leg by infinite.animateFloat(
        initialValue = -12f, targetValue = 12f,
        animationSpec = infiniteRepeatable(tween(420, easing = LinearEasing), RepeatMode.Reverse),
        label = "leg",
    )
    val blink by infinite.animateFloat(
        initialValue = 1f, targetValue = 0.12f,
        animationSpec = infiniteRepeatable(tween(100, delayMillis = 2400), RepeatMode.Reverse),
        label = "blink",
    )
    var tickling by remember { mutableStateOf(false) }
    val laugh = remember { Animatable(0f) }
    val danceWiggle = remember { Animatable(0f) }
    val danceBounce = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val ctx = LocalContext.current

    fun playDropGiggle() {
        if (!waterSoundsOn(ctx)) return
        try {
            val tg = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 90)
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                try {
                    tg.startTone(ToneGenerator.TONE_DTMF_1, 60)
                    android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                        try {
                            tg.startTone(ToneGenerator.TONE_PROP_ACK, 120)
                            tg.release()
                        } catch (_: Exception) { }
                    }, 80)
                } catch (_: Exception) {
                    try { tg.release() } catch (_: Exception) { }
                }
            }, 100)
        } catch (_: Exception) { }
    }

    LaunchedEffect(tickling) {
        if (tickling) {
            laugh.snapTo(0f)
            danceWiggle.snapTo(0f)
            danceBounce.snapTo(0f)
            // dança + sorriso amplo nas cócegas
            laugh.animateTo(1f, tween(200))
            repeat(6) {
                danceWiggle.animateTo(14f, tween(70))
                danceBounce.animateTo(-8f, tween(70))
                danceWiggle.animateTo(-14f, tween(70))
                danceBounce.animateTo(0f, tween(70))
            }
            danceWiggle.animateTo(0f, tween(80))
            delay(200)
            tickling = false
            laugh.snapTo(0f)
        }
    }

    val baseRot = if (inverted) 180f else roll * 0.45f
    Box(
        modifier = modifier
            .size(96.dp)
            .offset(y = danceBounce.value.dp)
            .rotate(baseRot + danceWiggle.value)
            .clickable {
                tickling = true
                playDropGiggle()
            },
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            // copo fundo
            drawRoundRect(
                color = Color.White.copy(alpha = 0.85f),
                topLeft = Offset(w * 0.06f, h * 0.08f),
                size = Size(w * 0.42f, h * 0.72f),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(10f, 10f),
            )
            val waterP = Path().apply {
                moveTo(w * 0.1f, h * 0.48f)
                cubicTo(w * 0.2f, h * 0.42f, w * 0.32f, h * 0.55f, w * 0.44f, h * 0.45f)
                lineTo(w * 0.44f, h * 0.74f)
                lineTo(w * 0.1f, h * 0.74f)
                close()
            }
            drawPath(waterP, WaterBlue.copy(alpha = 0.85f))
            // corpo gota
            val cx = w * 0.62f
            val cy = h * 0.48f
            val r = w * 0.26f
            drawCircle(
                Brush.radialGradient(listOf(Color(0xFF7DD3FC), WaterBlueDeep), center = Offset(cx, cy - r * 0.2f), radius = r * 1.15f),
                radius = r,
                center = Offset(cx, cy),
            )
            // olhos
            val eyeY = cy - r * 0.12f
            val eyeH = r * 0.2f * blink
            drawCircle(Color.White, radius = r * 0.15f, center = Offset(cx - r * 0.28f, eyeY))
            drawCircle(Color.White, radius = r * 0.15f, center = Offset(cx + r * 0.28f, eyeY))
            drawOval(Color(0xFF0F172A), topLeft = Offset(cx - r * 0.34f, eyeY - eyeH / 2), size = Size(r * 0.11f, eyeH))
            drawOval(Color(0xFF0F172A), topLeft = Offset(cx + r * 0.23f, eyeY - eyeH / 2), size = Size(r * 0.11f, eyeH))
            // boca: sorriso normal ou risada de cócegas
            if (tickling || laugh.value > 0.2f) {
                // sorriso largo de cócegas
                drawOval(
                    Color(0xFF0F172A),
                    topLeft = Offset(cx - r * 0.28f, cy + r * 0.08f),
                    size = Size(r * 0.56f, r * 0.42f * (0.7f + laugh.value * 0.5f)),
                )
                // dentes / brilho da risada
                drawOval(
                    Color.White.copy(alpha = 0.85f),
                    topLeft = Offset(cx - r * 0.18f, cy + r * 0.14f),
                    size = Size(r * 0.36f, r * 0.12f),
                )
                // notas de risada
                drawCircle(Color.White.copy(alpha = 0.95f), 3.5f, Offset(cx + r * 0.55f, cy - r * 0.45f))
                drawCircle(Color(0xFF7DD3FC).copy(alpha = 0.9f), 3f, Offset(cx + r * 0.72f, cy - r * 0.2f))
                drawCircle(Color.White.copy(alpha = 0.8f), 2.5f, Offset(cx - r * 0.6f, cy - r * 0.35f))
            } else if (mood >= 2) {
                drawArc(
                    color = Color(0xFF0F172A),
                    startAngle = 15f,
                    sweepAngle = 150f,
                    useCenter = false,
                    topLeft = Offset(cx - r * 0.28f, cy + r * 0.05f),
                    size = Size(r * 0.56f, r * 0.4f),
                    style = Stroke(width = 3.5f),
                )
                drawCircle(Color(0xFFFBBF24), 3.5f, Offset(cx - r * 0.7f, cy - r * 0.5f))
                drawCircle(Color(0xFFFBBF24), 3f, Offset(cx + r * 0.75f, cy - r * 0.35f))
                drawCircle(Color.White, 2.5f, Offset(cx + r * 0.55f, cy - r * 0.65f))
            } else if (mood <= 0) {
                drawArc(
                    color = Color(0xFF0F172A),
                    startAngle = 200f,
                    sweepAngle = 140f,
                    useCenter = false,
                    topLeft = Offset(cx - r * 0.26f, cy + r * 0.22f),
                    size = Size(r * 0.52f, r * 0.3f),
                    style = Stroke(width = 3.5f),
                )
            } else if (happy) {
                drawArc(
                    color = Color(0xFF0F172A),
                    startAngle = 25f,
                    sweepAngle = 130f,
                    useCenter = false,
                    topLeft = Offset(cx - r * 0.26f, cy + r * 0.08f),
                    size = Size(r * 0.52f, r * 0.36f),
                    style = Stroke(width = 3.5f),
                )
            }
            // pernas animadas embaixo
            val legBaseY = cy + r * 0.85f
            val swing = leg * (Math.PI / 180.0).toFloat()
            val legLen = r * 0.55f
            // perna esq
            val lx = cx - r * 0.22f + kotlin.math.sin(swing) * 6f
            val ly = legBaseY + kotlin.math.cos(swing) * 2f
            drawLine(WaterBlueDeep, Offset(cx - r * 0.18f, legBaseY - 4f), Offset(lx, ly + legLen), strokeWidth = 5f)
            drawCircle(WaterBlueDeep, 5f, Offset(lx, ly + legLen))
            // perna dir
            val rx = cx + r * 0.22f - kotlin.math.sin(swing) * 6f
            val ry = legBaseY + kotlin.math.cos(swing) * 2f
            drawLine(WaterBlueDeep, Offset(cx + r * 0.18f, legBaseY - 4f), Offset(rx, ry + legLen), strokeWidth = 5f)
            drawCircle(WaterBlueDeep, 5f, Offset(rx, ry + legLen))
            // brilho
            drawCircle(Color.White.copy(alpha = 0.55f), radius = r * 0.1f, center = Offset(cx - r * 0.32f, cy - r * 0.32f))
        }
    }
}

@Composable
fun TiltingCup(
    ml: Int,
    kind: String,
    timeLabel: String,
    roll: Float,
    pitch: Float,
    inverted: Boolean = false,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    val wave = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            wave.animateTo(1f, tween(1800, easing = LinearEasing))
            wave.snapTo(0f)
        }
    }
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = modifier
            .width(84.dp)
            .height(118.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.18f))
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp, vertical = 6.dp),
    ) {
        // Card externo SEMPRE iguais; o desenho do copo escala pelo ml
        val cupBox = when {
            ml <= 150 -> 40.dp
            ml <= 250 -> 48.dp
            ml <= 350 -> 54.dp
            ml <= 500 -> 58.dp
            ml <= 700 -> 62.dp
            else -> 66.dp
        }
        Box(
            Modifier
                .size(66.dp),
            contentAlignment = Alignment.BottomCenter,
        ) {
            Box(
                Modifier
                    .size(cupBox)
                    .rotate(roll * 0.9f)
                    .offset(y = (pitch * 0.4f).dp),
                contentAlignment = Alignment.BottomCenter,
            ) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val tilt = roll / 18f
                val slim = if (ml <= 200) 0.28f else if (ml >= 700) 0.18f else 0.22f
                val left = w * slim
                val right = w * (1f - slim)
                val top = h * (if (kind == "bottle") 0.18f else 0.10f)
                val bottom = h * 0.92f
                val glass = Path().apply {
                    moveTo(left, top)
                    lineTo(right, top)
                    lineTo(right + 3f, bottom)
                    lineTo(left - 3f, bottom)
                    close()
                }
                drawPath(glass, Color.White.copy(alpha = 0.35f))
                drawPath(glass, Color.White.copy(alpha = 0.7f), style = Stroke(2.5f))
                val fill = (0.35f + (ml / 1000f) * 0.4f).coerceIn(0.35f, 0.78f)
                val phase = wave.value * Math.PI.toFloat() * 2f
                if (inverted) {
                    // Fase 1: só gotas · Fase 2: água derramando (ml do registro NÃO muda)
                    val spillPhase = wave.value // 0..1 ciclo
                    val dropsOnly = spillPhase < 0.35f
                    // ainda resta um pouco no fundo do copo (não esvazia o valor)
                    val remain = Path().apply {
                        val y0 = bottom - (bottom - top) * 0.12f
                        moveTo(left - 2f, bottom)
                        lineTo(left - 2f, y0)
                        lineTo(right + 2f, y0)
                        lineTo(right + 2f, bottom)
                        close()
                    }
                    drawPath(remain, WaterBlue.copy(alpha = 0.35f))
                    val dropN = if (dropsOnly) 4 else 8
                    for (i in 0 until dropN) {
                        val dx = left + (right - left) * ((i + 0.5f) / dropN) + tilt * 5f
                        val fall = ((wave.value * 1.4f + i * 0.12f) % 1f)
                        val dy = top + fall * (h * 0.95f)
                        val rr = 2.5f + (i % 3)
                        drawCircle(WaterBlue.copy(alpha = 0.85f), radius = rr, center = Offset(dx, dy))
                    }
                    if (!dropsOnly) {
                        // filete / jato saindo da boca do copo
                        val stream = Path().apply {
                            val mx = (left + right) / 2f + tilt * 8f
                            moveTo(left + 4f, top)
                            lineTo(right - 4f, top)
                            lineTo(mx + 10f, bottom + h * 0.15f)
                            lineTo(mx - 10f, bottom + h * 0.15f)
                            close()
                        }
                        drawPath(stream, Brush.verticalGradient(listOf(WaterBlueSoft, WaterBlue.copy(alpha = 0.55f))))
                        // poça embaixo
                        drawOval(
                            WaterBlue.copy(alpha = 0.35f),
                            topLeft = Offset(w * 0.15f, h * 0.88f),
                            size = Size(w * 0.7f, h * 0.1f),
                        )
                    }
                } else {
                    val waterTop = bottom - (bottom - top) * fill
                    val water = Path().apply {
                        val yL = waterTop + tilt * 8f
                        val yR = waterTop - tilt * 8f
                        moveTo(left - 2f, bottom)
                        lineTo(left - 2f, yL)
                        cubicTo(
                            left + (right - left) * 0.33f,
                            yL + sin(phase) * 3f,
                            left + (right - left) * 0.66f,
                            yR - sin(phase) * 3f,
                            right + 2f,
                            yR,
                        )
                        lineTo(right + 2f, bottom)
                        close()
                    }
                    drawPath(water, Brush.verticalGradient(listOf(WaterBlueSoft, WaterBlue, WaterBlueDeep)))
                }
                if (kind == "bottle" || ml >= 500) {
                    drawRoundRect(WaterBlueDeep, Offset(w * 0.36f, h * 0.02f), Size(w * 0.28f, h * 0.12f), androidx.compose.ui.geometry.CornerRadius(6f, 6f))
                }
            }
            }
        }
        Text("$ml ml", color = WaterBlueDeep, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        Text(timeLabel, color = Color(0xFF64748B), fontSize = 11.sp)
    }
}

@Composable
fun WaterHomeSheet(
    expanded: Boolean,
    onExpandChange: (Boolean) -> Unit,
    onOpenFull: () -> Unit,
) {
    val ctx = LocalContext.current
    val g = glucoColors()
    var goal by remember { mutableIntStateOf(effectiveWaterGoal(ctx)) }
    var entries by remember { mutableStateOf(loadWaterEntries(ctx)) }
    var showUndo by remember { mutableStateOf(false) }
    var lastRemoved by remember { mutableStateOf<WaterEntry?>(null) }
    var insight by remember { mutableStateOf(waterInsightLine(ctx)) }
    val total = entries.sumOf { it.ml }
    val progress = (total.toFloat() / goal.coerceAtLeast(1)).coerceIn(0f, 1.2f)
    val mood = waterMood(progress.coerceAtMost(1f))
    val tiltState = rememberDeviceTilt()
    val roll = tiltState.roll
    val pitch = tiltState.pitch
    val inverted = tiltState.inverted
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val favs = remember { mutableStateOf(loadFavCups(ctx)) }
    val scope = rememberCoroutineScope()

    fun refresh() {
        goal = effectiveWaterGoal(ctx)
        entries = loadWaterEntries(ctx)
        insight = waterInsightLine(ctx)
        favs.value = loadFavCups(ctx)
    }

    fun addMl(ml: Int, kind: String) {
        val e = WaterEntry(SystemClock.uptimeMillis().toString(), ml, System.currentTimeMillis(), kind)
        val next = listOf(e) + entries
        saveWaterEntries(ctx, next)
        entries = loadWaterEntries(ctx)
        lastRemoved = e
        showUndo = true
        goal = effectiveWaterGoal(ctx)
        insight = waterInsightLine(ctx)
        if (entries.sumOf { it.ml } >= goal) markWaterReminded(ctx)
        scope.launch {
            delay(5000)
            showUndo = false
        }
    }

    fun undoLast() {
        val e = lastRemoved ?: return
        val next = entries.filter { it.id != e.id }
        saveWaterEntries(ctx, next)
        entries = loadWaterEntries(ctx)
        showUndo = false
        lastRemoved = null
        insight = waterInsightLine(ctx)
        goal = effectiveWaterGoal(ctx)
    }

    LaunchedEffect(Unit) {
        if (shouldSoftWaterRemind(ctx)) {
            insight = waterInsightLine(ctx)
            markWaterReminded(ctx)
        }
    }

    Column(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(Brush.verticalGradient(listOf(WaterBlue, WaterBlueDeep)))
            .pointerInput(Unit) {
                detectVerticalDragGestures { _, dragAmount ->
                    if (dragAmount < -12) onExpandChange(true)
                    if (dragAmount > 18) onExpandChange(false)
                }
            }
            .padding(horizontal = 16.dp, vertical = 12.dp),
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Box(Modifier.width(40.dp).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color.White.copy(alpha = 0.55f)))
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            WaterBuddy(Modifier, happy = mood >= 1 && !inverted, mood = mood, roll = roll, inverted = inverted)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("Cris Hidrata", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
                Text(
                    when (mood) {
                        2 -> "Meta batida! Você se hidratou bem hoje"
                        1 -> "Bom ritmo — continue com os copos"
                        else -> "Lembrá-lo de beber água todos os dias"
                    },
                    color = Color.White.copy(alpha = 0.9f),
                    fontSize = 12.sp,
                )
                Text(
                    "$total / $goal ml",
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 20.sp,
                    modifier = Modifier.padding(top = 4.dp),
                )
            }
            IconButton(onClick = { onExpandChange(!expanded) }) {
                Icon(Icons.Filled.KeyboardArrowUp, null, tint = Color.White, modifier = Modifier.rotate(if (expanded) 180f else 0f))
            }
        }
        if (progress >= 1f) {
            Text(
                "★ Conquista do dia · meta batida",
                color = Color(0xFFFDE68A),
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
        insight?.let {
            Text(it, color = Color.White.copy(alpha = 0.95f), fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
        }
        LinearProgressIndicator(
            progress = { progress.coerceAtMost(1f) },
            modifier = Modifier.fillMaxWidth().padding(top = 10.dp).height(10.dp).clip(RoundedCornerShape(8.dp)),
            color = Color.White,
            trackColor = Color.White.copy(alpha = 0.25f),
        )
        if (showUndo) {
            TextButton(onClick = { undoLast() }) {
                Text("Desfazer último copo", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        // favoritos no topo
        val quick = (favs.value + listOf(150, 250, 300, 500)).distinct().take(4)
        Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            quick.forEach { ml ->
                TiltingCup(
                    ml = ml,
                    kind = if (ml >= 500) "bottle" else "glass",
                    timeLabel = if (ml in favs.value) "★" else "toque",
                    roll = roll,
                    pitch = pitch,
                    inverted = inverted,
                    onClick = { addMl(ml, if (ml >= 500) "bottle" else "glass") },
                )
            }
        }
        if (expanded) {
            Text("Registros de hoje · puxe para recolher", color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.fillMaxWidth().height(220.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                items(entries.take(12)) { e ->
                    TiltingCup(
                        ml = e.ml,
                        kind = e.kind,
                        timeLabel = timeFmt.format(Date(e.at)),
                        roll = roll,
                        pitch = pitch,
                        inverted = inverted,
                        onClick = {},
                    )
                }
                items(CUP_PRESETS.take(4)) { p ->
                    TiltingCup(
                        ml = p.ml,
                        kind = p.kind,
                        timeLabel = "＋",
                        roll = roll,
                        pitch = pitch,
                        inverted = inverted,
                        onClick = { addMl(p.ml, p.kind) },
                    )
                }
            }
            PrimaryButton("Abrir Cris Hidrata", WaterBlueSoft, onOpenFull, Modifier.padding(top = 8.dp))
        } else {
            TextButton(onClick = { onExpandChange(true) }, modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Text("Puxar para cima · ver mais copos", color = Color.White)
            }
        }
    }
}

@Composable
fun WaterTrackerScreen(vm: GlucoViewModel, nav: NavHostController) {
    val ctx = LocalContext.current
    val g = glucoColors()
    val data by vm.data.collectAsStateWithLifecycle()
    var goal by remember { mutableIntStateOf(loadWaterGoal(ctx)) }
    var goalText by remember { mutableStateOf(goal.toString()) }
    var entries by remember { mutableStateOf(loadWaterEntries(ctx)) }
    var customMl by remember { mutableStateOf("") }
    var showUndo by remember { mutableStateOf(false) }
    var lastEntry by remember { mutableStateOf<WaterEntry?>(null) }
    var sounds by remember { mutableStateOf(waterSoundsOn(ctx)) }
    var heat by remember { mutableStateOf(isHeatModeToday(ctx)) }
    var askMeal by remember { mutableStateOf(askWaterAfterMeal(ctx)) }
    var favs by remember { mutableStateOf(loadFavCups(ctx)) }
    var remindH by remember { mutableIntStateOf(waterRemindHours(ctx)) }
    val effective = effectiveWaterGoal(ctx)
    val total = entries.sumOf { it.ml }
    val progress = (total.toFloat() / effective.coerceAtLeast(1)).coerceIn(0f, 1.2f)
    val mood = waterMood(progress.coerceAtMost(1f))
    val tiltState = rememberDeviceTilt()
    val roll = tiltState.roll
    val pitch = tiltState.pitch
    val inverted = tiltState.inverted
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val scope = rememberCoroutineScope()
    val suggested = suggestedWaterGoalMl(data.settings.weightKg)
    val insight = waterInsightLine(ctx)

    fun persist(list: List<WaterEntry>) {
        saveWaterEntries(ctx, list)
        entries = loadWaterEntries(ctx)
    }

    fun addEntry(ml: Int, kind: String) {
        val e = WaterEntry(SystemClock.uptimeMillis().toString(), ml, System.currentTimeMillis(), kind)
        persist(listOf(e) + entries)
        lastEntry = e
        showUndo = true
        if (entries.sumOf { it.ml } >= effectiveWaterGoal(ctx)) markWaterReminded(ctx)
        scope.launch {
            delay(5000)
            showUndo = false
        }
    }

    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF0369A1), WaterBlueDeep, Color(0xFF0C4A6E))))) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { nav.popBackStack() }) {
                Icon(Icons.Filled.Close, null, tint = Color.White)
            }
            Text("Cris Hidrata", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
            WaterBuddy(Modifier.size(56.dp), happy = mood >= 1 && !inverted, mood = mood, roll = roll, inverted = inverted)
        }
        Column(
            Modifier
                .fillMaxSize()
                .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
                .background(WaterSurface)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
        ) {
            Text("META", color = WaterBlueDeep, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("$total / $effective ml", color = Color(0xFF0F172A), fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, modifier = Modifier.weight(1f))
            }
            if (heat) {
                Text("Modo calor/exercício: +$HEAT_BONUS_ML ml só hoje", color = WaterBlueDeep, fontSize = 12.sp)
            }
            LinearProgressIndicator(
                progress = { progress.coerceAtMost(1f) },
                modifier = Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(8.dp)).padding(vertical = 8.dp),
                color = WaterBlue,
                trackColor = WaterBlueSoft,
            )
            if (progress >= 1f) {
                Text("★ Conquista do dia · meta batida", color = Color(0xFFB45309), fontWeight = FontWeight.Bold, fontSize = 14.sp)
            }
            insight?.let {
                Text(it, color = g.ink, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
            if (showUndo) {
                TextButton(onClick = {
                    val e = lastEntry ?: return@TextButton
                    persist(entries.filter { it.id != e.id })
                    showUndo = false
                    lastEntry = null
                }) {
                    Text("Desfazer último copo", color = WaterBlueDeep, fontWeight = FontWeight.Bold)
                }
            }

            Text("Editar meta base (ml)", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = goalText,
                    onValueChange = { goalText = it.filter { ch -> ch.isDigit() }.take(4) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                TextButton(onClick = {
                    val v = goalText.toIntOrNull() ?: return@TextButton
                    saveWaterGoal(ctx, v)
                    goal = loadWaterGoal(ctx)
                    goalText = goal.toString()
                }) { Text("Salvar", color = WaterBlueDeep, fontWeight = FontWeight.Bold) }
            }
            if (suggested != null) {
                TextButton(onClick = {
                    saveWaterGoal(ctx, suggested)
                    goal = suggested
                    goalText = suggested.toString()
                }) {
                    Text("Usar meta sugerida (~35 ml/kg): $suggested ml", color = WaterBlueDeep)
                }
            } else {
                Text("Preencha o peso no Perfil para sugerir meta automática.", color = g.muted, fontSize = 12.sp)
            }

            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Modo calor / exercício (+${HEAT_BONUS_ML} ml hoje)", color = g.ink, modifier = Modifier.weight(1f), fontSize = 13.sp)
                androidx.compose.material3.Switch(checked = heat, onCheckedChange = {
                    heat = it
                    setHeatModeToday(ctx, it)
                })
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Sons (gota e cócegas)", color = g.ink, modifier = Modifier.weight(1f), fontSize = 13.sp)
                androidx.compose.material3.Switch(checked = sounds, onCheckedChange = {
                    sounds = it
                    setWaterSoundsOn(ctx, it)
                })
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Perguntar água ao salvar refeição", color = g.ink, modifier = Modifier.weight(1f), fontSize = 13.sp)
                androidx.compose.material3.Switch(checked = askMeal, onCheckedChange = {
                    askMeal = it
                    setAskWaterAfterMeal(ctx, it)
                })
            }
            Text("Lembrete suave a cada $remindH h (só se meta aberta)", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            Row {
                listOf(1, 2, 3, 4).forEach { h ->
                    TextButton(onClick = {
                        remindH = h
                        setWaterRemindHours(ctx, h)
                    }) {
                        Text("${h}h", color = if (remindH == h) WaterBlueDeep else g.muted, fontWeight = if (remindH == h) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }

            Text("Copos favoritos (topo)", color = WaterBlueDeep, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(top = 12.dp))
            Text("Toque longo no ml abaixo não — use +/− nos chips", color = g.muted, fontSize = 11.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                favs.forEach { ml ->
                    Text(
                        "$ml ml ★",
                        color = WaterBlueDeep,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(WaterBlueSoft)
                            .clickable {
                                toggleFavCup(ctx, ml)
                                favs = loadFavCups(ctx)
                            }
                            .padding(horizontal = 10.dp, vertical = 8.dp),
                    )
                }
            }
            Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(150, 200, 250, 300, 400, 500, 600, 700).forEach { ml ->
                    if (ml !in favs) {
                        Text(
                            "+$ml",
                            color = g.ink,
                            fontSize = 12.sp,
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.White)
                                .clickable {
                                    toggleFavCup(ctx, ml)
                                    favs = loadFavCups(ctx)
                                }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                        )
                    }
                }
            }

            Text("Copos Cris Hidrata · incline o celular", color = WaterBlueDeep, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(top = 16.dp, bottom = 8.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(4),
                modifier = Modifier.fillMaxWidth().height(320.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
                userScrollEnabled = false,
            ) {
                items(CUP_PRESETS) { pr ->
                    TiltingCup(
                        ml = pr.ml,
                        kind = pr.kind,
                        timeLabel = if (pr.ml in favs) "★" else "＋",
                        roll = roll,
                        pitch = pitch,
                        inverted = inverted,
                        onClick = { addEntry(pr.ml, pr.kind) },
                    )
                }
            }

            Text("Quantidade personalizada", color = g.muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = customMl,
                    onValueChange = { customMl = it.filter { ch -> ch.isDigit() }.take(4) },
                    modifier = Modifier.weight(1f),
                    singleLine = true,
                    label = { Text("ml") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                IconButton(onClick = {
                    val ml = customMl.toIntOrNull() ?: return@IconButton
                    if (ml in 1..2000) {
                        addEntry(ml, "custom")
                        customMl = ""
                    }
                }) {
                    Icon(Icons.Filled.Add, null, tint = WaterBlueDeep)
                }
            }

            Text("Hoje", color = WaterBlueDeep, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(top = 16.dp))
            if (entries.isEmpty()) {
                Text("Nenhum copo ainda. Toque em um copo acima.", color = g.muted)
            } else {
                entries.forEach { e ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        TiltingCup(e.ml, e.kind, timeFmt.format(Date(e.at)), roll, pitch, inverted, onClick = {}, modifier = Modifier.width(72.dp))
                        Column(Modifier.weight(1f).padding(start = 8.dp)) {
                            Text("${e.ml} ml", color = g.ink, fontWeight = FontWeight.Bold)
                            Text(timeFmt.format(Date(e.at)), color = g.muted, fontSize = 12.sp)
                        }
                        IconButton(onClick = { persist(entries.filter { it.id != e.id }) }) {
                            Icon(Icons.Filled.Delete, null, tint = g.muted)
                        }
                    }
                }
            }
            Text(
                "Hidratação de apoio. Efeitos visuais não alteram o ml registrado. Não substitui orientação médica.",
                color = g.muted,
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 12.dp, bottom = 24.dp),
            )
        }
    }
}
